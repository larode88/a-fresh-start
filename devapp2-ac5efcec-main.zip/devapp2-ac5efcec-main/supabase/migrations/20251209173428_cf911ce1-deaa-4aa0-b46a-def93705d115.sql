
-- Create enum for brand category
CREATE TYPE public.merke_kategori AS ENUM ('kjemi', 'produkt', 'begge');

-- Leverandører (hovedleverandører)
CREATE TABLE public.leverandorer (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  navn TEXT NOT NULL UNIQUE,
  aktiv BOOLEAN DEFAULT true,
  hubspot_company_id TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Merker under leverandører
CREATE TABLE public.leverandor_merker (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  leverandor_id UUID NOT NULL REFERENCES public.leverandorer(id) ON DELETE CASCADE,
  navn TEXT NOT NULL,
  kategori merke_kategori DEFAULT 'begge',
  aktiv BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(leverandor_id, navn)
);

-- Salong-leverandør kobling
CREATE TABLE public.salong_leverandorer (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  salon_id UUID NOT NULL REFERENCES public.salons(id) ON DELETE CASCADE,
  leverandor_id UUID NOT NULL REFERENCES public.leverandorer(id) ON DELETE CASCADE,
  har_kjemi BOOLEAN DEFAULT false,
  har_produkter BOOLEAN DEFAULT false,
  avtale_startdato DATE,
  bonusstruktur TEXT,
  spesialavtale_detaljer TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(salon_id, leverandor_id)
);

-- Salong-merke kobling
CREATE TABLE public.salong_merker (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  salon_id UUID NOT NULL REFERENCES public.salons(id) ON DELETE CASCADE,
  merke_id UUID NOT NULL REFERENCES public.leverandor_merker(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(salon_id, merke_id)
);

-- Enable RLS
ALTER TABLE public.leverandorer ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.leverandor_merker ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.salong_leverandorer ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.salong_merker ENABLE ROW LEVEL SECURITY;

-- RLS policies for leverandorer (read-only for authenticated, manage for admin)
CREATE POLICY "Authenticated can view leverandorer" ON public.leverandorer FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "Admins can manage leverandorer" ON public.leverandorer FOR ALL USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- RLS policies for leverandor_merker
CREATE POLICY "Authenticated can view merker" ON public.leverandor_merker FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "Admins can manage merker" ON public.leverandor_merker FOR ALL USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- RLS policies for salong_leverandorer
CREATE POLICY "Admins can manage salong_leverandorer" ON public.salong_leverandorer FOR ALL USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "DMs can manage their district salong_leverandorer" ON public.salong_leverandorer FOR ALL USING (has_role(auth.uid(), 'district_manager'::app_role) AND salon_id IN (SELECT get_district_salon_ids(auth.uid()))) WITH CHECK (has_role(auth.uid(), 'district_manager'::app_role) AND salon_id IN (SELECT get_district_salon_ids(auth.uid())));
CREATE POLICY "Salon owners can view their salong_leverandorer" ON public.salong_leverandorer FOR SELECT USING (salon_id = get_user_salon_id(auth.uid()));

-- RLS policies for salong_merker
CREATE POLICY "Admins can manage salong_merker" ON public.salong_merker FOR ALL USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "DMs can manage their district salong_merker" ON public.salong_merker FOR ALL USING (has_role(auth.uid(), 'district_manager'::app_role) AND salon_id IN (SELECT get_district_salon_ids(auth.uid()))) WITH CHECK (has_role(auth.uid(), 'district_manager'::app_role) AND salon_id IN (SELECT get_district_salon_ids(auth.uid())));
CREATE POLICY "Salon owners can view their salong_merker" ON public.salong_merker FOR SELECT USING (salon_id = get_user_salon_id(auth.uid()));

-- Triggers for updated_at
CREATE TRIGGER update_leverandorer_updated_at BEFORE UPDATE ON public.leverandorer FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_salong_leverandorer_updated_at BEFORE UPDATE ON public.salong_leverandorer FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Indexes
CREATE INDEX idx_leverandor_merker_leverandor ON public.leverandor_merker(leverandor_id);
CREATE INDEX idx_salong_leverandorer_salon ON public.salong_leverandorer(salon_id);
CREATE INDEX idx_salong_leverandorer_leverandor ON public.salong_leverandorer(leverandor_id);
CREATE INDEX idx_salong_merker_salon ON public.salong_merker(salon_id);
CREATE INDEX idx_salong_merker_merke ON public.salong_merker(merke_id);

-- SEED DATA: Insert all 14 suppliers
INSERT INTO public.leverandorer (navn) VALUES
('CUTRIN'),
('ByWe'),
('Head Brands'),
('Heidenstrøm'),
('ICON Hairspa'),
('In Good Hands'),
('KAO'),
('L''Oréal'),
('Maria Nila'),
('Pretty Good'),
('Tendenz'),
('Verdant'),
('We Are One'),
('Wella');

-- SEED DATA: Insert all brands with their suppliers
-- CUTRIN
INSERT INTO public.leverandor_merker (leverandor_id, navn) 
SELECT id, unnest(ARRAY['Cutrin', 'Hold Fast', 'Moroccanoil', 'Paul Mitchell', 'Promise', 'QIQI', 'R&Detail', 'REF Stockholm Sweden', 'Special 1'])
FROM public.leverandorer WHERE navn = 'CUTRIN';

-- ByWe
INSERT INTO public.leverandor_merker (leverandor_id, navn)
SELECT id, unnest(ARRAY['Alterna', 'Attitude', 'Beardburys', 'Björk', 'Color WOW', 'Lanza', 'Mm Kollagen', 'MyDentity', 'Nanokeratin System', 'Olaplex', 'OnFleek', 'Renati', 'Schwarzkopf Professional', 'Sexy Hair', 'Toppik'])
FROM public.leverandorer WHERE navn = 'ByWe';

-- Head Brands
INSERT INTO public.leverandor_merker (leverandor_id, navn)
SELECT id, unnest(ARRAY['American Crew', 'Amika', 'Argan Secret', 'B.fresh', 'Celeb Luxury', 'Fanola', 'Four Reasons', 'Gold', 'Goldwell', 'Gorgeous', 'Kocostar', 'Löwengrip', 'Macadamia Pro', 'Muvo', 'Nioxin', 'Nordbo', 'Orofluido', 'Saphira', 'Sayran', 'Sebastian', 'Tigi', 'Zenz'])
FROM public.leverandorer WHERE navn = 'Head Brands';

-- Heidenstrøm
INSERT INTO public.leverandor_merker (leverandor_id, navn)
SELECT id, unnest(ARRAY['Matrix', 'Vision Haircare', 'HairPearl', 'Nõberu of Sweden'])
FROM public.leverandorer WHERE navn = 'Heidenstrøm';

-- ICON Hairspa
INSERT INTO public.leverandor_merker (leverandor_id, navn)
SELECT id, unnest(ARRAY['OWay', 'Hufs', 'Zenz Therapy', 'O&M', 'Living Proof', 'Dapper Dan', 'Toppik', 'Organic Hairspa'])
FROM public.leverandorer WHERE navn = 'ICON Hairspa';

-- In Good Hands
INSERT INTO public.leverandor_merker (leverandor_id, navn)
SELECT id, unnest(ARRAY['Milk_Shake', 'Depot', 'Insight'])
FROM public.leverandorer WHERE navn = 'In Good Hands';

-- KAO
INSERT INTO public.leverandor_merker (leverandor_id, navn)
SELECT id, unnest(ARRAY['Goldwell', 'Oribe', 'Kerasilk'])
FROM public.leverandorer WHERE navn = 'KAO';

-- L'Oréal
INSERT INTO public.leverandor_merker (leverandor_id, navn)
SELECT id, unnest(ARRAY['Redken', 'L''Oréal Professionnel', 'Kérastase', 'Shu Uemura'])
FROM public.leverandorer WHERE navn = 'L''Oréal';

-- Maria Nila
INSERT INTO public.leverandor_merker (leverandor_id, navn)
SELECT id, unnest(ARRAY['Maria Nila'])
FROM public.leverandorer WHERE navn = 'Maria Nila';

-- Pretty Good
INSERT INTO public.leverandor_merker (leverandor_id, navn)
SELECT id, unnest(ARRAY['Miriam Quevedo', 'NOIR'])
FROM public.leverandorer WHERE navn = 'Pretty Good';

-- Tendenz
INSERT INTO public.leverandor_merker (leverandor_id, navn)
SELECT id, unnest(ARRAY['KMS', 'Joico', 'Blomdahl', 'Sayran Professional'])
FROM public.leverandorer WHERE navn = 'Tendenz';

-- Verdant
INSERT INTO public.leverandor_merker (leverandor_id, navn)
SELECT id, unnest(ARRAY['Eleven Australia', 'Davines', 'Kevin Murphy', 'K18', 'Omniblonde'])
FROM public.leverandorer WHERE navn = 'Verdant';

-- We Are One
INSERT INTO public.leverandor_merker (leverandor_id, navn)
SELECT id, unnest(ARRAY['Aveda', 'Bumble and Bumble'])
FROM public.leverandorer WHERE navn = 'We Are One';

-- Wella
INSERT INTO public.leverandor_merker (leverandor_id, navn)
SELECT id, unnest(ARRAY['Wella Professionals', 'Sebastian Professional', 'Sassoon Professional', 'System Professional', 'Nioxin Professional', 'WeDo/ Professional', 'SP Classic', 'GHD'])
FROM public.leverandorer WHERE navn = 'Wella';
