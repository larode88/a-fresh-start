-- Fix: Restrict badges table to authenticated users only
DROP POLICY IF EXISTS "Everyone can view badges" ON public.badges;

CREATE POLICY "Authenticated users can view badges" 
ON public.badges 
FOR SELECT 
USING (auth.uid() IS NOT NULL);