-- CRITICAL FIX: Remove public access to insurance_power_of_attorney table
-- Edge functions use service role key so they will continue to work

-- Drop overly permissive public policies
DROP POLICY IF EXISTS "Public can insert POA" ON public.insurance_power_of_attorney;
DROP POLICY IF EXISTS "Public can read POA for verification" ON public.insurance_power_of_attorney;
DROP POLICY IF EXISTS "Public can update POA for verification" ON public.insurance_power_of_attorney;