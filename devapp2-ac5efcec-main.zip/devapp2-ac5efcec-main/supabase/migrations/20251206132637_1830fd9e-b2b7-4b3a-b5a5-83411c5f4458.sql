-- Add 'registered' status for health insurance orders (Ergo registration workflow)
ALTER TYPE insurance_order_status ADD VALUE IF NOT EXISTS 'registered';