-- Add postal_code to salons table
ALTER TABLE public.salons ADD COLUMN IF NOT EXISTS postal_code text;

-- Add address fields to insurance_quotes
ALTER TABLE public.insurance_quotes ADD COLUMN IF NOT EXISTS salon_address text;
ALTER TABLE public.insurance_quotes ADD COLUMN IF NOT EXISTS salon_postal_code text;
ALTER TABLE public.insurance_quotes ADD COLUMN IF NOT EXISTS salon_city text;

-- Add address fields and order_category to insurance_orders
ALTER TABLE public.insurance_orders ADD COLUMN IF NOT EXISTS salon_address text;
ALTER TABLE public.insurance_orders ADD COLUMN IF NOT EXISTS salon_postal_code text;
ALTER TABLE public.insurance_orders ADD COLUMN IF NOT EXISTS salon_city text;
ALTER TABLE public.insurance_orders ADD COLUMN IF NOT EXISTS order_category text DEFAULT 'bedrift' CHECK (order_category IN ('bedrift', 'helse'));