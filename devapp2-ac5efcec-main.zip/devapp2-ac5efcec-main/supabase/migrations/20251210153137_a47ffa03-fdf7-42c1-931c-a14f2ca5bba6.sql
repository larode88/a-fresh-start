-- Add GDPR consent tracking columns to users table
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS gdpr_consent_given_at timestamptz;
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS gdpr_consent_ip text;
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS gdpr_consent_source text;