-- Fase 1: Database-utvidelser - Enums og ansattfelter

-- 1.1 Nye ENUMS for HR-modulen
CREATE TYPE frisorfunksjon AS ENUM ('frisor', 'senior_frisor', 'laerling');

CREATE TYPE fravaerstype AS ENUM (
  'egenmelding', 
  'sykmelding', 
  'lege_helse', 
  'velferdspermisjon', 
  'foreldrepermisjon', 
  'ulonnet_permisjon', 
  'annet'
);

CREATE TYPE ferie_status AS ENUM ('planlagt', 'godkjent', 'avslatt', 'avviklet');

CREATE TYPE budsjett_stillingsprosent_kilde AS ENUM ('ansatt', 'turnus');

-- 1.2 Utvide users-tabellen med ansattfelter
ALTER TABLE public.users 
ADD COLUMN IF NOT EXISTS frisorfunksjon frisorfunksjon,
ADD COLUMN IF NOT EXISTS stillingsprosent numeric(5,2) DEFAULT 100.00,
ADD COLUMN IF NOT EXISTS ansettelsesdato date,
ADD COLUMN IF NOT EXISTS fodselsdato date,
ADD COLUMN IF NOT EXISTS fastlonn numeric(10,2),
ADD COLUMN IF NOT EXISTS timesats numeric(10,2),
ADD COLUMN IF NOT EXISTS fagbrev boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS aktiv boolean DEFAULT true;

-- 1.3 Ny tabell: stylist_kpi_config (KPI-konfigurasjon per frisør)
CREATE TABLE public.stylist_kpi_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  salon_id uuid NOT NULL REFERENCES public.salons(id) ON DELETE CASCADE,
  effektivitet_prosent_mal numeric(5,2) DEFAULT 75.00,
  omsetning_per_time_mal numeric(10,2) DEFAULT 800.00,
  varesalg_prosent_mal numeric(5,2) DEFAULT 15.00,
  rebooking_prosent_mal numeric(5,2) DEFAULT 70.00,
  budsjett_stillingsprosent_kilde budsjett_stillingsprosent_kilde DEFAULT 'ansatt',
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now(),
  UNIQUE(user_id, salon_id)
);

-- 1.4 Utvid salon_goals med flere målverdier
ALTER TABLE public.salon_goals
ADD COLUMN IF NOT EXISTS target_efficiency_percent numeric(5,2),
ADD COLUMN IF NOT EXISTS target_varesalg_percent numeric(5,2);

-- 1.5 Enable RLS på stylist_kpi_config
ALTER TABLE public.stylist_kpi_config ENABLE ROW LEVEL SECURITY;

-- RLS Policies for stylist_kpi_config
CREATE POLICY "Admins can manage all stylist_kpi_config"
ON public.stylist_kpi_config
FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Salon owners can manage their salon's stylist_kpi_config"
ON public.stylist_kpi_config
FOR ALL
USING (
  salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid())
)
WITH CHECK (
  salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid())
);

CREATE POLICY "District managers can view stylist_kpi_config in their district"
ON public.stylist_kpi_config
FOR SELECT
USING (
  has_role(auth.uid(), 'district_manager'::app_role) AND
  salon_id IN (SELECT get_district_salon_ids(auth.uid()))
);

CREATE POLICY "Users can view their own stylist_kpi_config"
ON public.stylist_kpi_config
FOR SELECT
USING (user_id = auth.uid());

-- 1.6 Trigger for updated_at
CREATE TRIGGER update_stylist_kpi_config_updated_at
BEFORE UPDATE ON public.stylist_kpi_config
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- 1.7 Database-funksjon for å sjekke om bruker er admin eller manager
CREATE OR REPLACE FUNCTION public.is_admin_or_manager(p_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles 
    WHERE user_id = p_user_id 
    AND role IN ('admin', 'district_manager', 'salon_owner', 'daglig_leder', 'avdelingsleder')
  )
$$;

-- 1.8 Database-funksjon for å beregne ansiennitet
CREATE OR REPLACE FUNCTION public.get_ansiennitet_aar(p_user_id uuid)
RETURNS numeric
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COALESCE(
    EXTRACT(YEAR FROM age(CURRENT_DATE, ansettelsesdato)),
    0
  )::numeric
  FROM public.users
  WHERE id = p_user_id
$$;

-- 1.9 Database-funksjon for å beregne alder
CREATE OR REPLACE FUNCTION public.get_alder(p_user_id uuid)
RETURNS integer
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COALESCE(
    EXTRACT(YEAR FROM age(CURRENT_DATE, fodselsdato))::integer,
    0
  )
  FROM public.users
  WHERE id = p_user_id
$$;