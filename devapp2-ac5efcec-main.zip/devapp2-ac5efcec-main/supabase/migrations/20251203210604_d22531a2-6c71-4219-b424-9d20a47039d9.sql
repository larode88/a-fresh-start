-- Add fagbrevdato column to users table
ALTER TABLE public.users 
ADD COLUMN IF NOT EXISTS fagbrevdato date;

-- Update ansiennitet function to use fagbrevdato if available (for tariff purposes)
CREATE OR REPLACE FUNCTION public.get_ansiennitet_aar(p_user_id uuid)
 RETURNS numeric
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT COALESCE(
    EXTRACT(YEAR FROM age(CURRENT_DATE, 
      COALESCE(fagbrevdato, ansettelsesdato)
    )),
    0
  )::numeric
  FROM public.users
  WHERE id = p_user_id
$function$;

-- Add comment explaining the logic
COMMENT ON FUNCTION public.get_ansiennitet_aar(uuid) IS 'Beregner ansiennitet i år. Bruker fagbrevdato hvis tilgjengelig, ellers ansettelsesdato.';