-- Fix trigger function to use renamed column (innmeldt_dato -> start_medlemskap_dato)
CREATE OR REPLACE FUNCTION public.check_trenger_oppfolging()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  -- Sett trenger_oppfolging = true hvis siste_kontakt_dato er > 45 dager gammel
  IF NEW.siste_kontakt_dato IS NOT NULL THEN
    NEW.trenger_oppfolging := (NEW.siste_kontakt_dato < CURRENT_DATE - INTERVAL '45 days');
  ELSE
    -- Hvis aldri kontaktet og innmeldt, trenger oppfølging
    NEW.trenger_oppfolging := (NEW.start_medlemskap_dato IS NOT NULL);
  END IF;
  RETURN NEW;
END;
$function$;