-- Migration: HR and Min Salong Tables
-- This migration extends existing HR functionality with additional tables for comprehensive HR management

-- Create table for employee goals (Mål)
CREATE TABLE IF NOT EXISTS public.ansatt_mal (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  salon_id UUID NOT NULL REFERENCES public.salons(id) ON DELETE CASCADE,
  mal_type TEXT NOT NULL CHECK (mal_type IN ('omsetning', 'kundetilfredshet', 'produktivitet', 'varesalg', 'annet')),
  mal_beskrivelse TEXT NOT NULL,
  mal_verdi NUMERIC,
  enhet TEXT, -- 'kr', 'prosent', 'antall', etc.
  periode_start DATE NOT NULL,
  periode_slutt DATE,
  status TEXT DEFAULT 'aktiv' CHECK (status IN ('aktiv', 'fullfort', 'kansellert')),
  oppnaadd_verdi NUMERIC,
  budsjett_id UUID REFERENCES public.budsjett_versjoner(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  opprettet_av UUID REFERENCES public.users(id) ON DELETE SET NULL
);

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_ansatt_mal_user_id ON public.ansatt_mal(user_id);
CREATE INDEX IF NOT EXISTS idx_ansatt_mal_salon_id ON public.ansatt_mal(salon_id);
CREATE INDEX IF NOT EXISTS idx_ansatt_mal_status ON public.ansatt_mal(status);

-- Create table for employee development and conversations (Utvikling & Samtaler)
CREATE TABLE IF NOT EXISTS public.ansatt_samtaler (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  salon_id UUID NOT NULL REFERENCES public.salons(id) ON DELETE CASCADE,
  samtale_type TEXT NOT NULL CHECK (samtale_type IN ('utviklingssamtale', 'performance_review', 'medarbeidersamtale', 'lonnsamtale', 'karrieresamtale', 'annet')),
  dato DATE NOT NULL,
  varighet_minutter INTEGER,
  samtale_leder UUID REFERENCES public.users(id) ON DELETE SET NULL,
  notater TEXT,
  handlingsplan TEXT,
  oppfolging_dato DATE,
  status TEXT DEFAULT 'planlagt' CHECK (status IN ('planlagt', 'gjennomfort', 'kansellert')),
  dokumenter_url TEXT[],
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_ansatt_samtaler_user_id ON public.ansatt_samtaler(user_id);
CREATE INDEX IF NOT EXISTS idx_ansatt_samtaler_salon_id ON public.ansatt_samtaler(salon_id);
CREATE INDEX IF NOT EXISTS idx_ansatt_samtaler_dato ON public.ansatt_samtaler(dato);

-- Create table for employee training and courses
CREATE TABLE IF NOT EXISTS public.ansatt_kurs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  kurs_navn TEXT NOT NULL,
  kurs_type TEXT CHECK (kurs_type IN ('intern', 'ekstern', 'online', 'sertifisering')),
  leverandor TEXT,
  startdato DATE NOT NULL,
  sluttdato DATE,
  varighet_timer NUMERIC,
  kostnad NUMERIC,
  godkjent_av UUID REFERENCES public.users(id) ON DELETE SET NULL,
  status TEXT DEFAULT 'planlagt' CHECK (status IN ('planlagt', 'pameldt', 'gjennomfort', 'kansellert')),
  resultat TEXT,
  sertifikat_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_ansatt_kurs_user_id ON public.ansatt_kurs(user_id);
CREATE INDEX IF NOT EXISTS idx_ansatt_kurs_status ON public.ansatt_kurs(status);

-- Create table for salary history (Lønnshistorikk)
CREATE TABLE IF NOT EXISTS public.lonn_historikk (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  gyldig_fra DATE NOT NULL,
  gyldig_til DATE,
  timesats NUMERIC NOT NULL,
  fastlonn NUMERIC,
  stillingsprosent NUMERIC CHECK (stillingsprosent >= 0 AND stillingsprosent <= 100),
  tariff_id UUID REFERENCES public.tariff_maler(id) ON DELETE SET NULL,
  begrunnelse TEXT,
  godkjent_av UUID REFERENCES public.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_lonn_historikk_user_id ON public.lonn_historikk(user_id);
CREATE INDEX IF NOT EXISTS idx_lonn_historikk_gyldig_fra ON public.lonn_historikk(gyldig_fra);

-- Create trigger to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Add triggers for all new tables
DROP TRIGGER IF EXISTS update_ansatt_mal_updated_at ON public.ansatt_mal;
CREATE TRIGGER update_ansatt_mal_updated_at
  BEFORE UPDATE ON public.ansatt_mal
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_ansatt_samtaler_updated_at ON public.ansatt_samtaler;
CREATE TRIGGER update_ansatt_samtaler_updated_at
  BEFORE UPDATE ON public.ansatt_samtaler
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_ansatt_kurs_updated_at ON public.ansatt_kurs;
CREATE TRIGGER update_ansatt_kurs_updated_at
  BEFORE UPDATE ON public.ansatt_kurs
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_lonn_historikk_updated_at ON public.lonn_historikk;
CREATE TRIGGER update_lonn_historikk_updated_at
  BEFORE UPDATE ON public.lonn_historikk
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Enable Row Level Security
ALTER TABLE public.ansatt_mal ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ansatt_samtaler ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ansatt_kurs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lonn_historikk ENABLE ROW LEVEL SECURITY;

-- RLS Policies for ansatt_mal
CREATE POLICY "Users can view their own goals"
  ON public.ansatt_mal FOR SELECT
  USING (auth.uid() = user_id OR has_salon_access(salon_id, auth.uid()));

CREATE POLICY "Managers can insert goals"
  ON public.ansatt_mal FOR INSERT
  WITH CHECK (has_salon_access(salon_id, auth.uid()) AND is_admin_or_manager(auth.uid()));

CREATE POLICY "Managers can update goals"
  ON public.ansatt_mal FOR UPDATE
  USING (has_salon_access(salon_id, auth.uid()) AND is_admin_or_manager(auth.uid()));

-- RLS Policies for ansatt_samtaler
CREATE POLICY "Users can view their conversations"
  ON public.ansatt_samtaler FOR SELECT
  USING (auth.uid() = user_id OR has_salon_access(salon_id, auth.uid()));

CREATE POLICY "Managers can manage conversations"
  ON public.ansatt_samtaler FOR ALL
  USING (has_salon_access(salon_id, auth.uid()) AND is_admin_or_manager(auth.uid()));

-- RLS Policies for ansatt_kurs
CREATE POLICY "Users can view their courses"
  ON public.ansatt_kurs FOR SELECT
  USING (auth.uid() = user_id OR has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'salon_owner'::app_role));

CREATE POLICY "Managers can manage courses"
  ON public.ansatt_kurs FOR ALL
  USING (is_admin_or_manager(auth.uid()));

-- RLS Policies for lonn_historikk
CREATE POLICY "Users can view their salary history"
  ON public.lonn_historikk FOR SELECT
  USING (auth.uid() = user_id OR is_admin_or_manager(auth.uid()));

CREATE POLICY "Only admins can manage salary history"
  ON public.lonn_historikk FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'salon_owner'::app_role));

-- Add comments for documentation
COMMENT ON TABLE public.ansatt_mal IS 'Employee goals and targets linked to budgets';
COMMENT ON TABLE public.ansatt_samtaler IS 'Employee development conversations and meetings';
COMMENT ON TABLE public.ansatt_kurs IS 'Employee training courses and certifications';
COMMENT ON TABLE public.lonn_historikk IS 'Historical salary data for employees';
