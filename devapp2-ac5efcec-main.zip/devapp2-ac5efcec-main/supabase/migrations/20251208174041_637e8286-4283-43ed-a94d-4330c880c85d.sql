
-- FASE 1.1: Utvid eksisterende tabeller

-- 1. Utvid salong_apningstider med bemanningsfelter
ALTER TABLE public.salong_apningstider 
ADD COLUMN IF NOT EXISTS min_bemanning INTEGER DEFAULT 2,
ADD COLUMN IF NOT EXISTS ideell_bemanning INTEGER DEFAULT 3,
ADD COLUMN IF NOT EXISTS merknad TEXT;

-- 2. Utvid salong_apningstider_unntak med flere felter
ALTER TABLE public.salong_apningstider_unntak 
ADD COLUMN IF NOT EXISTS min_bemanning INTEGER,
ADD COLUMN IF NOT EXISTS ideell_bemanning INTEGER,
ADD COLUMN IF NOT EXISTS kilde TEXT,
ADD COLUMN IF NOT EXISTS opprinnelig_helligdag TEXT;

-- 3. Utvid ansatt_turnus med nye felter
ALTER TABLE public.ansatt_turnus
ADD COLUMN IF NOT EXISTS pause_minutter INTEGER DEFAULT 30,
ADD COLUMN IF NOT EXISTS laast BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS helligdag_opplaast BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS merknad TEXT,
ADD COLUMN IF NOT EXISTS created_by UUID REFERENCES auth.users(id);

-- 4. Legg til manglende kolonner på turnus_preferanser hvis tabellen eksisterer
DO $$ 
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.tables WHERE table_name = 'turnus_preferanser') THEN
    -- Legg til gyldig_til hvis den mangler
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'turnus_preferanser' AND column_name = 'gyldig_til') THEN
      ALTER TABLE public.turnus_preferanser ADD COLUMN gyldig_til DATE;
    END IF;
    -- Legg til turnus_type hvis den mangler
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'turnus_preferanser' AND column_name = 'turnus_type') THEN
      ALTER TABLE public.turnus_preferanser ADD COLUMN turnus_type TEXT CHECK (turnus_type IN ('touke', 'treuke', 'fireuke')) DEFAULT 'touke';
    END IF;
    -- Legg til jobber hvis den mangler
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'turnus_preferanser' AND column_name = 'jobber') THEN
      ALTER TABLE public.turnus_preferanser ADD COLUMN jobber BOOLEAN NOT NULL DEFAULT true;
    END IF;
    -- Legg til uke_type hvis den mangler
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'turnus_preferanser' AND column_name = 'uke_type') THEN
      ALTER TABLE public.turnus_preferanser ADD COLUMN uke_type TEXT CHECK (uke_type IN ('partall', 'oddetall', 'uke1', 'uke2', 'uke3', 'uke4'));
    END IF;
    -- Legg til kommentar hvis den mangler
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'turnus_preferanser' AND column_name = 'kommentar') THEN
      ALTER TABLE public.turnus_preferanser ADD COLUMN kommentar TEXT;
    END IF;
  ELSE
    -- Opprett turnus_preferanser tabell (turnusmaler) hvis den ikke finnes
    CREATE TABLE public.turnus_preferanser (
      id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
      user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
      salon_id UUID NOT NULL REFERENCES public.salons(id) ON DELETE CASCADE,
      ukedag INTEGER NOT NULL CHECK (ukedag >= 1 AND ukedag <= 7),
      uke_type TEXT CHECK (uke_type IN ('partall', 'oddetall', 'uke1', 'uke2', 'uke3', 'uke4')),
      turnus_type TEXT CHECK (turnus_type IN ('touke', 'treuke', 'fireuke')) DEFAULT 'touke',
      jobber BOOLEAN NOT NULL DEFAULT true,
      onsket_start_tid TIME,
      onsket_slutt_tid TIME,
      prioritet INTEGER NOT NULL DEFAULT 3 CHECK (prioritet >= 1 AND prioritet <= 5),
      gyldig_fra DATE NOT NULL DEFAULT CURRENT_DATE,
      gyldig_til DATE,
      kommentar TEXT,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
      updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
      UNIQUE(user_id, salon_id, ukedag, uke_type, gyldig_fra)
    );
    
    -- Enable RLS
    ALTER TABLE public.turnus_preferanser ENABLE ROW LEVEL SECURITY;
    
    -- RLS Policies
    CREATE POLICY "turnus_pref_admin" ON public.turnus_preferanser
    FOR ALL USING (has_role(auth.uid(), 'admin'::app_role))
    WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

    CREATE POLICY "turnus_pref_leder" ON public.turnus_preferanser
    FOR ALL USING (is_salong_leder(auth.uid(), salon_id))
    WITH CHECK (is_salong_leder(auth.uid(), salon_id));

    CREATE POLICY "turnus_pref_salon_select" ON public.turnus_preferanser
    FOR SELECT USING (has_salong_access(auth.uid(), salon_id));

    CREATE POLICY "turnus_pref_own_select" ON public.turnus_preferanser
    FOR SELECT USING (user_id = auth.uid());

    -- Trigger for updated_at
    CREATE TRIGGER update_turnus_preferanser_updated_at
    BEFORE UPDATE ON public.turnus_preferanser
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();
  END IF;
END $$;

-- 5. Opprett indekser for ytelse (kun på eksisterende kolonner)
CREATE INDEX IF NOT EXISTS idx_turnus_preferanser_user ON public.turnus_preferanser(user_id);
CREATE INDEX IF NOT EXISTS idx_turnus_preferanser_salon ON public.turnus_preferanser(salon_id);
CREATE INDEX IF NOT EXISTS idx_turnus_preferanser_gyldig_fra ON public.turnus_preferanser(gyldig_fra);
CREATE INDEX IF NOT EXISTS idx_ansatt_turnus_user_salon ON public.ansatt_turnus(user_id, salon_id);
