-- Add phone and domain columns to salons table
ALTER TABLE public.salons 
  ADD COLUMN IF NOT EXISTS phone text,
  ADD COLUMN IF NOT EXISTS domain text;

-- Add comment for clarity
COMMENT ON COLUMN public.salons.phone IS 'Telefonnummer fra HubSpot';
COMMENT ON COLUMN public.salons.domain IS 'Hjemmeside/website fra HubSpot domain-felt';