-- Create table for automatic pulse survey plans
CREATE TABLE public.puls_automatisk_plan (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  salon_id UUID NOT NULL REFERENCES salons(id) ON DELETE CASCADE,
  puls_type public.puls_type NOT NULL,
  frekvens TEXT NOT NULL CHECK (frekvens IN ('annenhver_uke', 'maanedlig')),
  neste_utsendelse DATE NOT NULL,
  aktiv BOOLEAN DEFAULT true,
  siste_sporsmal_ids UUID[] DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(salon_id, puls_type)
);

-- Enable RLS
ALTER TABLE public.puls_automatisk_plan ENABLE ROW LEVEL SECURITY;

-- RLS policies
CREATE POLICY "puls_auto_admin" ON public.puls_automatisk_plan
  FOR ALL USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "puls_auto_leder" ON public.puls_automatisk_plan
  FOR ALL USING (is_salong_leder(auth.uid(), salon_id))
  WITH CHECK (is_salong_leder(auth.uid(), salon_id));

CREATE POLICY "puls_auto_select" ON public.puls_automatisk_plan
  FOR SELECT USING (has_salong_access(auth.uid(), salon_id));

-- Trigger for updated_at
CREATE TRIGGER update_puls_automatisk_plan_updated_at
  BEFORE UPDATE ON public.puls_automatisk_plan
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Seed automatic plans for HÅR1. KJEDEN AS
INSERT INTO public.puls_automatisk_plan (salon_id, puls_type, frekvens, neste_utsendelse, aktiv)
VALUES 
  ('1b0f8827-8a75-442d-889c-a139be04caa7', 'hurtigpuls', 'annenhver_uke', 
   (CURRENT_DATE + ((8 - EXTRACT(DOW FROM CURRENT_DATE)::integer) % 7))::date, true),
  ('1b0f8827-8a75-442d-889c-a139be04caa7', 'dyppuls', 'maanedlig',
   (DATE_TRUNC('month', CURRENT_DATE) + INTERVAL '1 month')::date, true);