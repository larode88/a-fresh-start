-- Legg til "søknad" i ferie_status enum
ALTER TYPE ferie_status ADD VALUE IF NOT EXISTS 'søknad' BEFORE 'planlagt';