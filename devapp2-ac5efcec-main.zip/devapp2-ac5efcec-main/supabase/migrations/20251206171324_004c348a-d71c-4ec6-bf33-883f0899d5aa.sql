-- Create storage bucket for email assets (logos, images)
INSERT INTO storage.buckets (id, name, public)
VALUES ('email-assets', 'email-assets', true)
ON CONFLICT (id) DO NOTHING;

-- Allow authenticated users to view email assets
CREATE POLICY "Anyone can view email assets"
ON storage.objects FOR SELECT
USING (bucket_id = 'email-assets');

-- Allow admins to upload email assets
CREATE POLICY "Admins can upload email assets"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'email-assets' AND has_role(auth.uid(), 'admin'::app_role));

-- Allow admins to update email assets
CREATE POLICY "Admins can update email assets"
ON storage.objects FOR UPDATE
USING (bucket_id = 'email-assets' AND has_role(auth.uid(), 'admin'::app_role));

-- Allow admins to delete email assets
CREATE POLICY "Admins can delete email assets"
ON storage.objects FOR DELETE
USING (bucket_id = 'email-assets' AND has_role(auth.uid(), 'admin'::app_role));

-- Add new email modules to library
INSERT INTO email_module_library (type, name, description, is_system_module, default_content, default_styles)
VALUES 
  ('heading', 'Overskrift', 'Stor overskrift med valgfri størrelse og farge', true, 
   '{"text": "Overskrift", "level": "h1"}', 
   '{"textAlign": "center", "color": "#1a1a1a"}'),
  
  ('spacer', 'Mellomrom', 'Tomt mellomrom med justerbar høyde', true,
   '{"height": "24"}',
   '{}'),
  
  ('note-box', 'Notis-boks', 'Informasjonsboks med ikon og innhold', true,
   '{"icon": "info", "title": "Merk", "content": "Viktig informasjon her..."}',
   '{"backgroundColor": "#f0f9ff", "borderColor": "#0ea5e9"}'),
  
  ('salon-info', 'Salonginfo', 'Viser salongdetaljer med kontaktinfo', true,
   '{"salonName": "{salongnavn}", "orgNumber": "{org_nummer}", "contactName": "{kontaktperson}", "email": "{epost}", "phone": "{telefon}"}',
   '{"backgroundColor": "#faf8f5"}'),

  ('divider', 'Skillelinje', 'Horisontal skillelinje', true,
   '{"style": "solid"}',
   '{"color": "#e5e5e5", "margin": "16"}'),

  ('quote-box', 'Sitatboks', 'Fremhevet sitat eller viktig melding', true,
   '{"text": "Viktig melding her...", "author": ""}',
   '{"borderColor": "#8B7355", "backgroundColor": "#faf8f5"}'),

  ('icon-list', 'Ikonliste', 'Liste med ikoner (check, star, arrow)', true,
   '{"icon": "check", "items": ["Punkt 1", "Punkt 2", "Punkt 3"]}',
   '{"iconColor": "#22c55e"}')
ON CONFLICT DO NOTHING;