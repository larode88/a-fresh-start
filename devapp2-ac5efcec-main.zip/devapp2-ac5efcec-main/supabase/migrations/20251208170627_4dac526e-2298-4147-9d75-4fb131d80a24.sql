-- Add lonn_sist_justert column to ansatte table
ALTER TABLE public.ansatte ADD COLUMN IF NOT EXISTS lonn_sist_justert DATE;

-- Update ansatte_utvidet view to include the new column
DROP VIEW IF EXISTS public.ansatte_utvidet;

CREATE VIEW public.ansatte_utvidet AS
SELECT 
  a.*,
  s.name AS salong_navn,
  -- Calculated fields
  CASE 
    WHEN a.fodselsdato IS NOT NULL THEN 
      EXTRACT(YEAR FROM age(CURRENT_DATE, a.fodselsdato))::INTEGER
    ELSE NULL
  END AS alder,
  CASE 
    WHEN a.fagbrev_dato IS NOT NULL THEN 
      ROUND(EXTRACT(EPOCH FROM age(CURRENT_DATE, a.fagbrev_dato)) / (365.25 * 24 * 60 * 60), 1)
    WHEN a.ansatt_dato IS NOT NULL THEN 
      ROUND(EXTRACT(EPOCH FROM age(CURRENT_DATE, a.ansatt_dato)) / (365.25 * 24 * 60 * 60), 1)
    ELSE NULL
  END AS ansiennitet_aar,
  CASE 
    WHEN a.ansatt_dato IS NOT NULL THEN 
      EXTRACT(MONTH FROM age(CURRENT_DATE, a.ansatt_dato))::INTEGER
    ELSE NULL
  END AS ansiennitet_maneder,
  -- Display fields
  CASE 
    WHEN a.fodselsdato IS NOT NULL THEN 
      TO_CHAR(a.fodselsdato, 'MM-DD')
    ELSE NULL
  END AS bursdag_md,
  CONCAT(a.fornavn, COALESCE(' ' || a.etternavn, '')) AS navn,
  CASE 
    WHEN a.frisorfunksjon = 'frisor' THEN 'Frisør'
    WHEN a.frisorfunksjon = 'senior_frisor' THEN 'Seniorfrisør'
    WHEN a.frisorfunksjon = 'laerling' THEN 'Lærling'
    ELSE NULL
  END || COALESCE(' / ' || CASE 
    WHEN a.lederstilling = 'daglig_leder' THEN 'Daglig leder'
    WHEN a.lederstilling = 'avdelingsleder' THEN 'Avdelingsleder'
    WHEN a.lederstilling = 'styreleder' THEN 'Styreleder'
    ELSE NULL
  END, '') AS rolle_display,
  CASE 
    WHEN a.status = 'Aktiv' AND a.provetid_til IS NOT NULL AND a.provetid_til > CURRENT_DATE THEN 'Prøvetid'
    ELSE a.status::TEXT
  END AS status_display
FROM public.ansatte a
LEFT JOIN public.salons s ON a.salong_id = s.id;