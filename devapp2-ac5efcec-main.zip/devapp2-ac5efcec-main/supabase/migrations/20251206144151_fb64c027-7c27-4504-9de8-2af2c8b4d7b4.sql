
-- Create email_module_library table for reusable modules
CREATE TABLE public.email_module_library (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  description TEXT,
  default_content JSONB NOT NULL DEFAULT '{}',
  default_styles JSONB DEFAULT '{}',
  is_system_module BOOLEAN DEFAULT false,
  preview_image_url TEXT,
  created_by UUID REFERENCES public.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create email_templates table
CREATE TABLE public.email_templates (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  description TEXT,
  category TEXT NOT NULL DEFAULT 'general',
  structure JSONB NOT NULL DEFAULT '{"modules": []}',
  subject_template TEXT,
  status TEXT NOT NULL DEFAULT 'draft',
  is_system_template BOOLEAN DEFAULT false,
  tags TEXT[] DEFAULT '{}',
  created_by UUID REFERENCES public.users(id),
  published_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  CONSTRAINT valid_status CHECK (status IN ('draft', 'published', 'archived'))
);

-- Create email_template_versions table for version history
CREATE TABLE public.email_template_versions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  template_id UUID NOT NULL REFERENCES public.email_templates(id) ON DELETE CASCADE,
  version_number INTEGER NOT NULL,
  structure JSONB NOT NULL,
  subject_template TEXT,
  change_notes TEXT,
  created_by UUID REFERENCES public.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE(template_id, version_number)
);

-- Enable RLS
ALTER TABLE public.email_module_library ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.email_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.email_template_versions ENABLE ROW LEVEL SECURITY;

-- RLS policies for email_module_library
CREATE POLICY "Admins can manage all modules"
  ON public.email_module_library FOR ALL
  USING (has_role(auth.uid(), 'admin'))
  WITH CHECK (has_role(auth.uid(), 'admin'));

CREATE POLICY "Authenticated users can view modules"
  ON public.email_module_library FOR SELECT
  USING (auth.uid() IS NOT NULL);

-- RLS policies for email_templates
CREATE POLICY "Admins can manage all templates"
  ON public.email_templates FOR ALL
  USING (has_role(auth.uid(), 'admin'))
  WITH CHECK (has_role(auth.uid(), 'admin'));

CREATE POLICY "Authenticated users can view published templates"
  ON public.email_templates FOR SELECT
  USING (auth.uid() IS NOT NULL AND (status = 'published' OR has_role(auth.uid(), 'admin')));

-- RLS policies for email_template_versions
CREATE POLICY "Admins can manage all versions"
  ON public.email_template_versions FOR ALL
  USING (has_role(auth.uid(), 'admin'))
  WITH CHECK (has_role(auth.uid(), 'admin'));

CREATE POLICY "Authenticated users can view versions"
  ON public.email_template_versions FOR SELECT
  USING (auth.uid() IS NOT NULL);

-- Triggers for updated_at
CREATE TRIGGER update_email_module_library_updated_at
  BEFORE UPDATE ON public.email_module_library
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_email_templates_updated_at
  BEFORE UPDATE ON public.email_templates
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Insert system modules (Hår1 standard modules)
INSERT INTO public.email_module_library (name, type, description, is_system_module, default_content, default_styles) VALUES
('Header med logo', 'header-logo', 'Hår1 Forsikring logo header med beige bakgrunn', true, 
  '{"logoUrl": "https://asaiahiimtsazwbekako.supabase.co/storage/v1/object/public/public-assets/haar1-forsikring-email-logo.png", "logoAlt": "Hår1 Forsikring", "backgroundColor": "#FAF8F5"}',
  '{"padding": "32px", "textAlign": "center"}'),

('Portalen Header', 'header-portalen', 'Hår1 Portalen logo header', true,
  '{"logoUrl": "https://asaiahiimtsazwbekako.supabase.co/storage/v1/object/public/public-assets/haar1-portalen-logo.png", "logoAlt": "Hår1 Portalen", "backgroundColor": "#FAF8F5"}',
  '{"padding": "32px", "textAlign": "center"}'),

('Tekst', 'text', 'Tekstblokk med rik formatering', true,
  '{"content": "<p>Skriv din tekst her...</p>"}',
  '{"padding": "24px 32px", "fontSize": "16px", "lineHeight": "1.6", "color": "#3D3D3D"}'),

('CTA-knapp', 'cta-button', 'Call-to-action knapp med gradient', true,
  '{"text": "Klikk her", "url": "#", "style": "primary"}',
  '{"padding": "16px 32px", "textAlign": "center"}'),

('Infoboks', 'info-box', 'Beige infoboks for viktig informasjon', true,
  '{"title": "Viktig informasjon", "content": "<p>Innhold her...</p>", "icon": "info"}',
  '{"backgroundColor": "#FAF7F2", "borderRadius": "12px", "padding": "24px", "margin": "16px 32px"}'),

('Suksess-banner', 'success-banner', 'Grønn banner for bekreftelser', true,
  '{"icon": "check", "text": "Vellykket!"}',
  '{"backgroundColor": "#E8F5E8", "color": "#2E7D32", "padding": "16px", "borderRadius": "8px", "textAlign": "center"}'),

('Advarsel-banner', 'warning-banner', 'Gul advarselsbanner', true,
  '{"icon": "warning", "text": "Obs!"}',
  '{"backgroundColor": "#FFF8E1", "color": "#F57C00", "padding": "16px", "borderRadius": "8px", "textAlign": "center"}'),

('Produkttabell', 'product-table', 'Tabell for forsikringsprodukter', true,
  '{"headers": ["Produkt", "Antall", "Pris"], "rows": []}',
  '{"margin": "16px 32px"}'),

('Fordeler-liste', 'benefits-list', 'Liste med checkmarks', true,
  '{"items": ["Fordel 1", "Fordel 2", "Fordel 3"]}',
  '{"padding": "16px 32px"}'),

('Footer med signatur', 'footer-signature', 'Standard Hår1 footer med kontaktinfo', true,
  '{"signature": "Med vennlig hilsen,<br><strong>Hår1-teamet</strong>", "contact": {"phone": "22 00 81 00", "email": "forsikring@har1.no", "website": "www.har1.no"}}',
  '{"backgroundColor": "#FAF8F5", "padding": "32px", "textAlign": "center", "borderTop": "1px solid #E8E0D5"}'),

('Juridisk disclaimer', 'footer-disclaimer', 'Juridisk tekst og personvern', true,
  '{"text": "Denne e-posten er sendt fra Hår1. Dersom du har mottatt denne e-posten ved en feil, vennligst slett den."}',
  '{"fontSize": "12px", "color": "#8B8B8B", "padding": "16px 32px", "textAlign": "center"}'),

('Separator', 'separator', 'Horisontal linje', true,
  '{"style": "solid", "color": "#E8E0D5"}',
  '{"margin": "16px 32px"}'),

('Bilde', 'image', 'Bildemodul', true,
  '{"src": "", "alt": "", "width": "100%"}',
  '{"textAlign": "center", "padding": "16px 32px"}'),

('To-kolonner', 'two-columns', 'To kolonner side ved side', true,
  '{"left": {"content": "<p>Venstre kolonne</p>"}, "right": {"content": "<p>Høyre kolonne</p>"}}',
  '{"padding": "16px 32px"}'),

('OTP-boks', 'otp-box', 'Boks for engangskode', true,
  '{"code": "{otp_code}", "expiryMinutes": 10}',
  '{"textAlign": "center", "padding": "24px"}');
