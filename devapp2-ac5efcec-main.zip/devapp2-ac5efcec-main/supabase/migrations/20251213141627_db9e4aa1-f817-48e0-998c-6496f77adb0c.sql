-- Del 1: turnus_skift - legg til ansatt_id hvis mangler
ALTER TABLE public.turnus_skift ADD COLUMN IF NOT EXISTS ansatt_id uuid REFERENCES public.ansatte(id);
ALTER TABLE public.turnus_skift ALTER COLUMN user_id DROP NOT NULL;
UPDATE public.turnus_skift ts SET ansatt_id = a.id FROM public.ansatte a WHERE ts.user_id = a.user_id AND ts.ansatt_id IS NULL;
CREATE INDEX IF NOT EXISTS idx_turnus_skift_ansatt_id ON public.turnus_skift(ansatt_id);

-- Del 2: ansatt_mal - legg til ansatt_id
ALTER TABLE public.ansatt_mal ADD COLUMN IF NOT EXISTS ansatt_id uuid REFERENCES public.ansatte(id);
ALTER TABLE public.ansatt_mal ALTER COLUMN user_id DROP NOT NULL;
UPDATE public.ansatt_mal am SET ansatt_id = a.id FROM public.ansatte a WHERE am.user_id = a.user_id AND am.ansatt_id IS NULL;
CREATE INDEX IF NOT EXISTS idx_ansatt_mal_ansatt_id ON public.ansatt_mal(ansatt_id);

-- Del 3: pulsundersokelse_svar - legg til ansatt_id
ALTER TABLE public.pulsundersokelse_svar ADD COLUMN IF NOT EXISTS ansatt_id uuid REFERENCES public.ansatte(id);
ALTER TABLE public.pulsundersokelse_svar ALTER COLUMN user_id DROP NOT NULL;
UPDATE public.pulsundersokelse_svar ps SET ansatt_id = a.id FROM public.ansatte a WHERE ps.user_id = a.user_id AND ps.ansatt_id IS NULL;
CREATE INDEX IF NOT EXISTS idx_pulsundersokelse_svar_ansatt_id ON public.pulsundersokelse_svar(ansatt_id);

-- Del 4: ansatt_samtaler - allerede har user_id, legger til ansatt_id
ALTER TABLE public.ansatt_samtaler ADD COLUMN IF NOT EXISTS ansatt_id uuid REFERENCES public.ansatte(id);
ALTER TABLE public.ansatt_samtaler ALTER COLUMN user_id DROP NOT NULL;
UPDATE public.ansatt_samtaler s SET ansatt_id = a.id FROM public.ansatte a WHERE s.user_id = a.user_id AND s.ansatt_id IS NULL;
CREATE INDEX IF NOT EXISTS idx_ansatt_samtaler_ansatt_id ON public.ansatt_samtaler(ansatt_id);

-- Del 5: weekly_kpis - legg til ansatt_id (bruker stylist_id som user_id)
ALTER TABLE public.weekly_kpis ADD COLUMN IF NOT EXISTS ansatt_id uuid REFERENCES public.ansatte(id);
UPDATE public.weekly_kpis wk SET ansatt_id = a.id FROM public.ansatte a WHERE wk.stylist_id = a.user_id AND wk.ansatt_id IS NULL;
CREATE INDEX IF NOT EXISTS idx_weekly_kpis_ansatt_id ON public.weekly_kpis(ansatt_id);