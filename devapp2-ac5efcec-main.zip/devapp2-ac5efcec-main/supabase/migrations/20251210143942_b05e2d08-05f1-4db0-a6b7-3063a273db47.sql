-- Create innmelding_utkast table for saving enrollment drafts
CREATE TABLE public.innmelding_utkast (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Wizard data stored as JSON
  wizard_data JSONB NOT NULL DEFAULT '{}'::jsonb,
  current_step INTEGER NOT NULL DEFAULT 1,
  
  -- Identification
  org_nummer TEXT NOT NULL,
  salongnavn TEXT NOT NULL,
  prospekt_id UUID REFERENCES public.prospekter(id) ON DELETE SET NULL,
  
  -- Status
  status TEXT NOT NULL DEFAULT 'utkast' CHECK (status IN ('utkast', 'venter_signering', 'ferdig')),
  avtale_status TEXT,
  
  -- Metadata
  created_by UUID REFERENCES public.users(id) NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.innmelding_utkast ENABLE ROW LEVEL SECURITY;

-- RLS policies
CREATE POLICY "Admin can manage all drafts"
  ON public.innmelding_utkast FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "District managers can manage their drafts"
  ON public.innmelding_utkast FOR ALL
  USING (has_role(auth.uid(), 'district_manager'::app_role))
  WITH CHECK (has_role(auth.uid(), 'district_manager'::app_role));

-- Trigger for updated_at
CREATE TRIGGER update_innmelding_utkast_updated_at
  BEFORE UPDATE ON public.innmelding_utkast
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Index for faster lookups
CREATE INDEX idx_innmelding_utkast_status ON public.innmelding_utkast(status);
CREATE INDEX idx_innmelding_utkast_created_by ON public.innmelding_utkast(created_by);