
-- =============================================
-- SYKEFRAVÆRSOPPFØLGING - NAV-KOMPATIBEL MODUL
-- =============================================

-- 1. ENUMS
-- =============================================

-- Sykmelding status
CREATE TYPE sykmelding_status AS ENUM ('aktiv', 'avsluttet', 'avbrutt');

-- Dialogmøte type
CREATE TYPE dialogmote_type AS ENUM ('dialogmote_1', 'dialogmote_2', 'dialogmote_3');

-- Dialogmøte status
CREATE TYPE dialogmote_status AS ENUM ('planlagt', 'gjennomfort', 'utsatt', 'avlyst');

-- Tilrettelegging type
CREATE TYPE tilretteleggingstype AS ENUM ('fysisk', 'organisatorisk', 'sosial', 'teknisk');

-- Tiltak status
CREATE TYPE tiltak_status AS ENUM ('planlagt', 'igang', 'fullfort', 'avbrutt');

-- Fase type
CREATE TYPE sykmelding_fase AS ENUM ('tidlig', 'aktiv', 'midt', 'sen');

-- 2. HOVEDTABELL: sykemeldinger
-- =============================================

CREATE TABLE public.sykemeldinger (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  salon_id UUID NOT NULL REFERENCES public.salons(id) ON DELETE CASCADE,
  fravar_id UUID REFERENCES public.fravaer(id) ON DELETE SET NULL,
  
  -- Datoer
  startdato DATE NOT NULL,
  forventet_sluttdato DATE,
  faktisk_sluttdato DATE,
  
  -- Sykmelding detaljer
  grad INTEGER NOT NULL DEFAULT 100 CHECK (grad IN (20, 40, 50, 60, 80, 100)),
  beskrivelse TEXT,
  dokument_url TEXT,
  status sykmelding_status NOT NULL DEFAULT 'aktiv',
  
  -- Oppfølgingsløp
  oppfolgingslop_startet BOOLEAN DEFAULT false,
  oppfolgingslop_startet_dato TIMESTAMP WITH TIME ZONE,
  oppfolgingslop_startet_av UUID REFERENCES public.users(id),
  
  -- Avslutning
  avsluttet_dato TIMESTAMP WITH TIME ZONE,
  avslutningstype TEXT CHECK (avslutningstype IN ('friskmeldt', 'gradert_retur', 'aap', 'annet')),
  avslutnings_oppsummering TEXT,
  
  -- Metadata
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- 3. OPPFØLGINGSPLANER
-- =============================================

CREATE TABLE public.sykmelding_oppfolgingsplaner (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  sykmelding_id UUID NOT NULL REFERENCES public.sykemeldinger(id) ON DELETE CASCADE,
  versjon INTEGER NOT NULL DEFAULT 1,
  
  -- Mål
  maal_kort_sikt TEXT,
  maal_lang_sikt TEXT,
  
  -- Arbeid
  arbeid_kan_utfores TEXT,
  arbeid_kan_ikke_utfores TEXT,
  gradert_arbeid_plan TEXT,
  
  -- Kartlegging - Ansatt
  ansatt_oppgaver_kan TEXT,
  ansatt_oppgaver_kan_ikke TEXT,
  ansatt_hindringer TEXT,
  ansatt_gradert_onske TEXT,
  ansatt_tilrettelegging_behov TEXT,
  ansatt_kartlagt_dato TIMESTAMP WITH TIME ZONE,
  
  -- Kartlegging - Leder
  leder_vurdering TEXT,
  leder_fysiske_tiltak TEXT,
  leder_organisatoriske_tiltak TEXT,
  leder_sosiale_tiltak TEXT,
  leder_alternative_oppgaver TEXT,
  leder_returforventning TEXT,
  leder_kartlagt_dato TIMESTAMP WITH TIME ZONE,
  leder_kartlagt_av UUID REFERENCES public.users(id),
  
  -- Status
  laast BOOLEAN DEFAULT false,
  laast_dato TIMESTAMP WITH TIME ZONE,
  laast_av UUID REFERENCES public.users(id),
  bekreftet_av_ansatt BOOLEAN DEFAULT false,
  bekreftet_av_ansatt_dato TIMESTAMP WITH TIME ZONE,
  
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- 4. DIALOGMØTER
-- =============================================

CREATE TABLE public.sykmelding_dialogmoter (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  sykmelding_id UUID NOT NULL REFERENCES public.sykemeldinger(id) ON DELETE CASCADE,
  
  motetype dialogmote_type NOT NULL,
  status dialogmote_status NOT NULL DEFAULT 'planlagt',
  
  -- Tidspunkt
  planlagt_dato TIMESTAMP WITH TIME ZONE,
  gjennomfort_dato TIMESTAMP WITH TIME ZONE,
  
  -- Deltakere
  deltakere TEXT[],
  nav_invitert BOOLEAN DEFAULT false,
  
  -- Innhold
  agenda TEXT,
  forberedelse_ansatt TEXT,
  forberedelse_leder TEXT,
  referat TEXT,
  
  -- Sjekkliste (for dialogmøte 1)
  sjekkliste JSONB DEFAULT '{}',
  
  -- Oppfølging
  oppfolging_tiltak TEXT,
  neste_steg TEXT,
  
  opprettet_av UUID REFERENCES public.users(id),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- 5. AKTIVITETSKRAV (Uke 8)
-- =============================================

CREATE TABLE public.sykmelding_aktivitetskrav (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  sykmelding_id UUID NOT NULL REFERENCES public.sykemeldinger(id) ON DELETE CASCADE,
  
  vurdert_dato DATE,
  vurdert_av UUID REFERENCES public.users(id),
  
  -- Vurdering
  kan_utfore_aktivitet BOOLEAN,
  aktivitetsmuligheter TEXT,
  begrunnelse TEXT,
  
  -- Dokumentasjon
  dokumentert BOOLEAN DEFAULT false,
  dokumentasjon_url TEXT,
  
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- 6. TILTAK
-- =============================================

CREATE TABLE public.sykmelding_tiltak (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  sykmelding_id UUID NOT NULL REFERENCES public.sykemeldinger(id) ON DELETE CASCADE,
  oppfolgingsplan_id UUID REFERENCES public.sykmelding_oppfolgingsplaner(id) ON DELETE SET NULL,
  
  tittel TEXT NOT NULL,
  beskrivelse TEXT,
  type tilretteleggingstype NOT NULL,
  status tiltak_status NOT NULL DEFAULT 'planlagt',
  
  ansvarlig_id UUID REFERENCES public.users(id),
  frist DATE,
  fullfort_dato DATE,
  
  kommentar TEXT,
  
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- 7. FASEVURDERINGER
-- =============================================

CREATE TABLE public.sykmelding_fasevurderinger (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  sykmelding_id UUID NOT NULL REFERENCES public.sykemeldinger(id) ON DELETE CASCADE,
  
  fase sykmelding_fase NOT NULL,
  vurdert_dato TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  vurdert_av UUID REFERENCES public.users(id),
  
  -- Vurdering
  status_vurdering TEXT,
  fremgang TEXT,
  utfordringer TEXT,
  neste_steg TEXT,
  
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- 8. EVALUERINGER (ved avslutning)
-- =============================================

CREATE TABLE public.sykmelding_evalueringer (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  sykmelding_id UUID NOT NULL REFERENCES public.sykemeldinger(id) ON DELETE CASCADE,
  
  evaluert_dato TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  evaluert_av UUID REFERENCES public.users(id),
  
  -- Evaluering
  hva_fungerte TEXT,
  hva_kunne_vaert_bedre TEXT,
  laeringspunkter TEXT,
  forebyggende_tiltak TEXT,
  
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- 9. VARSLER (til leder om ny sykmelding)
-- =============================================

CREATE TABLE public.sykmelding_varsler (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  sykmelding_id UUID NOT NULL REFERENCES public.sykemeldinger(id) ON DELETE CASCADE,
  mottaker_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  
  lest BOOLEAN DEFAULT false,
  lest_dato TIMESTAMP WITH TIME ZONE,
  
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- 10. NOTIFIKASJONER (automatiske varsler om frister)
-- =============================================

CREATE TABLE public.sykmelding_notifikasjoner (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  sykmelding_id UUID NOT NULL REFERENCES public.sykemeldinger(id) ON DELETE CASCADE,
  mottaker_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  
  type TEXT NOT NULL,
  melding TEXT NOT NULL,
  uke_nummer INTEGER,
  
  lest BOOLEAN DEFAULT false,
  lest_dato TIMESTAMP WITH TIME ZONE,
  
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- =============================================
-- INDEXES
-- =============================================

CREATE INDEX idx_sykemeldinger_user_id ON public.sykemeldinger(user_id);
CREATE INDEX idx_sykemeldinger_salon_id ON public.sykemeldinger(salon_id);
CREATE INDEX idx_sykemeldinger_status ON public.sykemeldinger(status);
CREATE INDEX idx_sykemeldinger_startdato ON public.sykemeldinger(startdato);

CREATE INDEX idx_oppfolgingsplaner_sykmelding_id ON public.sykmelding_oppfolgingsplaner(sykmelding_id);
CREATE INDEX idx_dialogmoter_sykmelding_id ON public.sykmelding_dialogmoter(sykmelding_id);
CREATE INDEX idx_tiltak_sykmelding_id ON public.sykmelding_tiltak(sykmelding_id);
CREATE INDEX idx_varsler_mottaker_id ON public.sykmelding_varsler(mottaker_id);
CREATE INDEX idx_notifikasjoner_mottaker_id ON public.sykmelding_notifikasjoner(mottaker_id);

-- =============================================
-- TRIGGERS for updated_at
-- =============================================

CREATE TRIGGER update_sykemeldinger_updated_at
  BEFORE UPDATE ON public.sykemeldinger
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_oppfolgingsplaner_updated_at
  BEFORE UPDATE ON public.sykmelding_oppfolgingsplaner
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_dialogmoter_updated_at
  BEFORE UPDATE ON public.sykmelding_dialogmoter
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_aktivitetskrav_updated_at
  BEFORE UPDATE ON public.sykmelding_aktivitetskrav
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_tiltak_updated_at
  BEFORE UPDATE ON public.sykmelding_tiltak
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =============================================
-- ROW LEVEL SECURITY
-- =============================================

ALTER TABLE public.sykemeldinger ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sykmelding_oppfolgingsplaner ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sykmelding_dialogmoter ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sykmelding_aktivitetskrav ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sykmelding_tiltak ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sykmelding_fasevurderinger ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sykmelding_evalueringer ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sykmelding_varsler ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sykmelding_notifikasjoner ENABLE ROW LEVEL SECURITY;

-- Sykemeldinger policies
CREATE POLICY "Ansatt ser egen sykmelding" ON public.sykemeldinger
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Ansatt kan opprette egen sykmelding" ON public.sykemeldinger
  FOR INSERT WITH CHECK (user_id = auth.uid());

CREATE POLICY "Ledere ser salongens sykmeldinger" ON public.sykemeldinger
  FOR SELECT USING (
    (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()))
    OR has_role(auth.uid(), 'admin'::app_role)
  );

CREATE POLICY "Ledere kan oppdatere salongens sykmeldinger" ON public.sykemeldinger
  FOR UPDATE USING (
    (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()))
    OR has_role(auth.uid(), 'admin'::app_role)
  );

CREATE POLICY "Admin kan slette sykmeldinger" ON public.sykemeldinger
  FOR DELETE USING (has_role(auth.uid(), 'admin'::app_role));

-- Oppfølgingsplaner policies
CREATE POLICY "Ansatt ser egen oppfolgingsplan" ON public.sykmelding_oppfolgingsplaner
  FOR SELECT USING (
    sykmelding_id IN (SELECT id FROM public.sykemeldinger WHERE user_id = auth.uid())
  );

CREATE POLICY "Ledere administrerer oppfolgingsplaner" ON public.sykmelding_oppfolgingsplaner
  FOR ALL USING (
    sykmelding_id IN (
      SELECT id FROM public.sykemeldinger 
      WHERE (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()))
         OR has_role(auth.uid(), 'admin'::app_role)
    )
  );

CREATE POLICY "Ansatt kan oppdatere kartlegging" ON public.sykmelding_oppfolgingsplaner
  FOR UPDATE USING (
    sykmelding_id IN (SELECT id FROM public.sykemeldinger WHERE user_id = auth.uid())
  );

-- Dialogmøter policies
CREATE POLICY "Ansatt ser egne dialogmoter" ON public.sykmelding_dialogmoter
  FOR SELECT USING (
    sykmelding_id IN (SELECT id FROM public.sykemeldinger WHERE user_id = auth.uid())
  );

CREATE POLICY "Ledere administrerer dialogmoter" ON public.sykmelding_dialogmoter
  FOR ALL USING (
    sykmelding_id IN (
      SELECT id FROM public.sykemeldinger 
      WHERE (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()))
         OR has_role(auth.uid(), 'admin'::app_role)
    )
  );

-- Aktivitetskrav policies
CREATE POLICY "Ansatt ser eget aktivitetskrav" ON public.sykmelding_aktivitetskrav
  FOR SELECT USING (
    sykmelding_id IN (SELECT id FROM public.sykemeldinger WHERE user_id = auth.uid())
  );

CREATE POLICY "Ledere administrerer aktivitetskrav" ON public.sykmelding_aktivitetskrav
  FOR ALL USING (
    sykmelding_id IN (
      SELECT id FROM public.sykemeldinger 
      WHERE (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()))
         OR has_role(auth.uid(), 'admin'::app_role)
    )
  );

-- Tiltak policies
CREATE POLICY "Ansatt ser egne tiltak" ON public.sykmelding_tiltak
  FOR SELECT USING (
    sykmelding_id IN (SELECT id FROM public.sykemeldinger WHERE user_id = auth.uid())
  );

CREATE POLICY "Ledere administrerer tiltak" ON public.sykmelding_tiltak
  FOR ALL USING (
    sykmelding_id IN (
      SELECT id FROM public.sykemeldinger 
      WHERE (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()))
         OR has_role(auth.uid(), 'admin'::app_role)
    )
  );

-- Fasevurderinger policies
CREATE POLICY "Ansatt ser egne fasevurderinger" ON public.sykmelding_fasevurderinger
  FOR SELECT USING (
    sykmelding_id IN (SELECT id FROM public.sykemeldinger WHERE user_id = auth.uid())
  );

CREATE POLICY "Ledere administrerer fasevurderinger" ON public.sykmelding_fasevurderinger
  FOR ALL USING (
    sykmelding_id IN (
      SELECT id FROM public.sykemeldinger 
      WHERE (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()))
         OR has_role(auth.uid(), 'admin'::app_role)
    )
  );

-- Evalueringer policies
CREATE POLICY "Ansatt ser egen evaluering" ON public.sykmelding_evalueringer
  FOR SELECT USING (
    sykmelding_id IN (SELECT id FROM public.sykemeldinger WHERE user_id = auth.uid())
  );

CREATE POLICY "Ledere administrerer evalueringer" ON public.sykmelding_evalueringer
  FOR ALL USING (
    sykmelding_id IN (
      SELECT id FROM public.sykemeldinger 
      WHERE (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()))
         OR has_role(auth.uid(), 'admin'::app_role)
    )
  );

-- Varsler policies
CREATE POLICY "Mottaker ser egne varsler" ON public.sykmelding_varsler
  FOR SELECT USING (mottaker_id = auth.uid());

CREATE POLICY "Mottaker kan oppdatere egne varsler" ON public.sykmelding_varsler
  FOR UPDATE USING (mottaker_id = auth.uid());

CREATE POLICY "System kan opprette varsler" ON public.sykmelding_varsler
  FOR INSERT WITH CHECK (true);

-- Notifikasjoner policies
CREATE POLICY "Mottaker ser egne notifikasjoner" ON public.sykmelding_notifikasjoner
  FOR SELECT USING (mottaker_id = auth.uid());

CREATE POLICY "Mottaker kan oppdatere egne notifikasjoner" ON public.sykmelding_notifikasjoner
  FOR UPDATE USING (mottaker_id = auth.uid());

CREATE POLICY "System kan opprette notifikasjoner" ON public.sykmelding_notifikasjoner
  FOR INSERT WITH CHECK (true);
