-- =============================================================================
-- Migration: Fix RLS infinite recursion on salons table
-- Problem: Direct subquery against users table triggers RLS on users,
--          which triggers RLS on salons → infinite loop
-- Solution: Use SECURITY DEFINER function get_user_salon_id() instead
-- =============================================================================

-- Drop the problematic policy
DROP POLICY IF EXISTS "Users can view their associated salon" ON public.salons;

-- Recreate with SECURITY DEFINER function call (breaks recursion)
CREATE POLICY "Users can view their associated salon"
ON public.salons
FOR SELECT
TO authenticated
USING (
  has_role(auth.uid(), 'admin'::app_role)
  OR id = get_user_salon_id(auth.uid())
  OR id IN (SELECT get_user_accessible_salon_ids(auth.uid()))
);