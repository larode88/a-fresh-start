-- Drop existing policy
DROP POLICY IF EXISTS "Salon owners can view their insurance data" ON salon_insurance;

-- Create updated policy including daglig_leder and avdelingsleder
CREATE POLICY "Salon managers can view their insurance data" 
ON salon_insurance 
FOR SELECT 
USING (
  salon_id = get_user_salon_id(auth.uid()) 
  AND (
    is_salon_owner(auth.uid()) 
    OR has_role(auth.uid(), 'daglig_leder'::app_role)
    OR has_role(auth.uid(), 'avdelingsleder'::app_role)
  )
);