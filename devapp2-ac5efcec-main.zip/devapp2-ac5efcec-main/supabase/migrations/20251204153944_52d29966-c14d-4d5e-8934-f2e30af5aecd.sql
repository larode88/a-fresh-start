-- Add seniorfrisor to app_role enum
ALTER TYPE app_role ADD VALUE 'seniorfrisor';

-- Update is_salon_owner function to include daglig_leder and avdelingsleder
CREATE OR REPLACE FUNCTION public.is_salon_owner(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.users
    WHERE id = _user_id
      AND role IN ('salon_owner', 'daglig_leder', 'avdelingsleder')
  )
$$;