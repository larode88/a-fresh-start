-- Create table for time-based staffing requirements
CREATE TABLE salong_bemanning_per_time (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  salon_id UUID NOT NULL REFERENCES salons(id) ON DELETE CASCADE,
  ukedag INTEGER NOT NULL CHECK (ukedag >= 1 AND ukedag <= 7),
  time_fra TIME NOT NULL,
  time_til TIME NOT NULL,
  min_bemanning INTEGER NOT NULL DEFAULT 1 CHECK (min_bemanning >= 0),
  ideell_bemanning INTEGER NOT NULL DEFAULT 2 CHECK (ideell_bemanning >= 0),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  CONSTRAINT valid_time_range CHECK (time_til > time_fra),
  CONSTRAINT unique_salon_day_time UNIQUE (salon_id, ukedag, time_fra, time_til)
);

-- Enable RLS
ALTER TABLE salong_bemanning_per_time ENABLE ROW LEVEL SECURITY;

-- RLS policies
CREATE POLICY "Users can view staffing for their salons"
  ON salong_bemanning_per_time FOR SELECT
  USING (has_salon_access(auth.uid(), salon_id));

CREATE POLICY "Salon owners and admins can manage staffing"
  ON salong_bemanning_per_time FOR ALL
  USING (is_salong_leder(auth.uid(), salon_id) OR has_role(auth.uid(), 'admin'));

-- Trigger for updated_at
CREATE TRIGGER update_bemanning_per_time_updated_at
  BEFORE UPDATE ON salong_bemanning_per_time
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Add index
CREATE INDEX idx_bemanning_per_time_salon_day ON salong_bemanning_per_time(salon_id, ukedag);