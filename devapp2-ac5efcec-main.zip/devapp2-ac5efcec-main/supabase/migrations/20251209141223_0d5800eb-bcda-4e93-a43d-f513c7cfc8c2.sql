-- ============================================
-- Fase 7: Onboarding og Offboarding system
-- ============================================

-- Enum for oppgavestatus
CREATE TYPE public.sjekkliste_oppgave_status AS ENUM (
  'ikke_startet',
  'pagar',
  'fullfort',
  'hoppet_over'
);

-- Enum for prosesstype
CREATE TYPE public.ansatt_prosess_type AS ENUM (
  'onboarding',
  'offboarding'
);

-- ============================================
-- Sjekkliste-maler (global admin)
-- ============================================
CREATE TABLE public.sjekkliste_maler (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  prosess_type public.ansatt_prosess_type NOT NULL,
  navn TEXT NOT NULL,
  beskrivelse TEXT,
  er_aktiv BOOLEAN DEFAULT true,
  opprettet_av UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Oppgave-maler (tilhører en sjekkliste-mal)
CREATE TABLE public.sjekkliste_oppgave_maler (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  mal_id UUID NOT NULL REFERENCES public.sjekkliste_maler(id) ON DELETE CASCADE,
  tittel TEXT NOT NULL,
  beskrivelse TEXT,
  ansvarlig_rolle TEXT, -- 'daglig_leder', 'hr', 'it', 'ansatt' etc.
  frist_dager INTEGER, -- Antall dager fra prosess-start
  prioritet INTEGER DEFAULT 0,
  kategori TEXT, -- 'dokumenter', 'utstyr', 'tilganger', 'opplæring', etc.
  obligatorisk BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================
-- Ansatt-prosesser (aktiv onboarding/offboarding)
-- ============================================
CREATE TABLE public.ansatt_prosesser (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  ansatt_id UUID NOT NULL REFERENCES public.ansatte(id) ON DELETE CASCADE,
  salon_id UUID NOT NULL REFERENCES public.salons(id),
  prosess_type public.ansatt_prosess_type NOT NULL,
  mal_id UUID REFERENCES public.sjekkliste_maler(id),
  start_dato DATE NOT NULL DEFAULT CURRENT_DATE,
  forventet_slutt DATE,
  faktisk_slutt DATE,
  status TEXT DEFAULT 'aktiv' CHECK (status IN ('aktiv', 'fullfort', 'avbrutt')),
  notater TEXT,
  opprettet_av UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Prosess-oppgaver (konkrete oppgaver for en prosess)
CREATE TABLE public.prosess_oppgaver (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  prosess_id UUID NOT NULL REFERENCES public.ansatt_prosesser(id) ON DELETE CASCADE,
  mal_oppgave_id UUID REFERENCES public.sjekkliste_oppgave_maler(id),
  tittel TEXT NOT NULL,
  beskrivelse TEXT,
  ansvarlig_rolle TEXT,
  ansvarlig_bruker_id UUID REFERENCES auth.users(id),
  frist DATE,
  status public.sjekkliste_oppgave_status DEFAULT 'ikke_startet',
  fullfort_av UUID REFERENCES auth.users(id),
  fullfort_dato TIMESTAMPTZ,
  kategori TEXT,
  prioritet INTEGER DEFAULT 0,
  obligatorisk BOOLEAN DEFAULT true,
  kommentar TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============================================
-- RLS Policies
-- ============================================
ALTER TABLE public.sjekkliste_maler ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sjekkliste_oppgave_maler ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ansatt_prosesser ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.prosess_oppgaver ENABLE ROW LEVEL SECURITY;

-- Sjekkliste-maler: alle kan lese, admin kan endre
CREATE POLICY "Alle kan lese sjekkliste-maler"
  ON public.sjekkliste_maler FOR SELECT
  USING (true);

CREATE POLICY "Admin kan administrere sjekkliste-maler"
  ON public.sjekkliste_maler FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM public.user_roles 
      WHERE user_id = auth.uid() AND role = 'admin'
    )
  );

-- Oppgave-maler: alle kan lese, admin kan endre
CREATE POLICY "Alle kan lese oppgave-maler"
  ON public.sjekkliste_oppgave_maler FOR SELECT
  USING (true);

CREATE POLICY "Admin kan administrere oppgave-maler"
  ON public.sjekkliste_oppgave_maler FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM public.user_roles 
      WHERE user_id = auth.uid() AND role = 'admin'
    )
  );

-- Ansatt-prosesser: salon-tilgang
CREATE POLICY "Ledere kan se prosesser i egen salong"
  ON public.ansatt_prosesser FOR SELECT
  USING (
    salon_id IN (
      SELECT salon_id FROM public.users WHERE id = auth.uid()
    )
    OR EXISTS (
      SELECT 1 FROM public.user_roles 
      WHERE user_id = auth.uid() AND role IN ('admin', 'district_manager')
    )
  );

CREATE POLICY "Ledere kan administrere prosesser i egen salong"
  ON public.ansatt_prosesser FOR ALL
  USING (
    salon_id IN (
      SELECT salon_id FROM public.users WHERE id = auth.uid()
    )
    OR EXISTS (
      SELECT 1 FROM public.user_roles 
      WHERE user_id = auth.uid() AND role IN ('admin', 'district_manager')
    )
  );

-- Prosess-oppgaver: via prosess
CREATE POLICY "Tilgang til oppgaver via prosess"
  ON public.prosess_oppgaver FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.ansatt_prosesser ap
      WHERE ap.id = prosess_id
      AND (
        ap.salon_id IN (SELECT salon_id FROM public.users WHERE id = auth.uid())
        OR EXISTS (
          SELECT 1 FROM public.user_roles 
          WHERE user_id = auth.uid() AND role IN ('admin', 'district_manager')
        )
      )
    )
  );

CREATE POLICY "Administrere oppgaver via prosess"
  ON public.prosess_oppgaver FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM public.ansatt_prosesser ap
      WHERE ap.id = prosess_id
      AND (
        ap.salon_id IN (SELECT salon_id FROM public.users WHERE id = auth.uid())
        OR EXISTS (
          SELECT 1 FROM public.user_roles 
          WHERE user_id = auth.uid() AND role IN ('admin', 'district_manager')
        )
      )
    )
  );

-- ============================================
-- Triggers for updated_at
-- ============================================
CREATE TRIGGER update_sjekkliste_maler_updated_at
  BEFORE UPDATE ON public.sjekkliste_maler
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_ansatt_prosesser_updated_at
  BEFORE UPDATE ON public.ansatt_prosesser
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_prosess_oppgaver_updated_at
  BEFORE UPDATE ON public.prosess_oppgaver
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ============================================
-- Seed standard onboarding-mal
-- ============================================
INSERT INTO public.sjekkliste_maler (prosess_type, navn, beskrivelse) VALUES
  ('onboarding', 'Standard onboarding', 'Standard sjekkliste for nyansatte frisører'),
  ('offboarding', 'Standard offboarding', 'Standard sjekkliste for ansatte som slutter');

-- Seed onboarding-oppgaver
INSERT INTO public.sjekkliste_oppgave_maler (mal_id, tittel, kategori, ansvarlig_rolle, frist_dager, prioritet, obligatorisk)
SELECT 
  id,
  oppgave.tittel,
  oppgave.kategori,
  oppgave.ansvarlig_rolle,
  oppgave.frist_dager,
  oppgave.prioritet,
  oppgave.obligatorisk
FROM public.sjekkliste_maler, 
LATERAL (VALUES
  ('Arbeidskontrakt signert', 'dokumenter', 'daglig_leder', -3, 1, true),
  ('Personnummer og bankinfo registrert', 'dokumenter', 'daglig_leder', 0, 2, true),
  ('Nøkkel/adgangskort utlevert', 'utstyr', 'daglig_leder', 0, 3, true),
  ('Kassesystem-tilgang opprettet', 'tilganger', 'daglig_leder', 0, 4, true),
  ('Bookingsystem-tilgang opprettet', 'tilganger', 'daglig_leder', 0, 5, true),
  ('Hår1 Portalen bruker opprettet', 'tilganger', 'daglig_leder', 0, 6, true),
  ('Uniform bestilt/utlevert', 'utstyr', 'daglig_leder', 3, 7, false),
  ('HMS-opplæring gjennomført', 'opplæring', 'ansatt', 7, 8, true),
  ('Introduksjon til salongens rutiner', 'opplæring', 'daglig_leder', 3, 9, true),
  ('Produktopplæring', 'opplæring', 'daglig_leder', 14, 10, true),
  ('Mentor tildelt', 'opplæring', 'daglig_leder', 7, 11, false),
  ('Prøvetidsevaluering planlagt', 'dokumenter', 'daglig_leder', 7, 12, true)
) AS oppgave(tittel, kategori, ansvarlig_rolle, frist_dager, prioritet, obligatorisk)
WHERE prosess_type = 'onboarding';

-- Seed offboarding-oppgaver
INSERT INTO public.sjekkliste_oppgave_maler (mal_id, tittel, kategori, ansvarlig_rolle, frist_dager, prioritet, obligatorisk)
SELECT 
  id,
  oppgave.tittel,
  oppgave.kategori,
  oppgave.ansvarlig_rolle,
  oppgave.frist_dager,
  oppgave.prioritet,
  oppgave.obligatorisk
FROM public.sjekkliste_maler, 
LATERAL (VALUES
  ('Oppsigelse mottatt/sendt', 'dokumenter', 'daglig_leder', 0, 1, true),
  ('Sluttdato bekreftet', 'dokumenter', 'daglig_leder', 0, 2, true),
  ('Feriedager avklart', 'dokumenter', 'daglig_leder', 3, 3, true),
  ('Kundeoverlevering planlagt', 'opplæring', 'daglig_leder', 7, 4, true),
  ('Nøkkel/adgangskort innlevert', 'utstyr', 'ansatt', -1, 5, true),
  ('Kassesystem-tilgang deaktivert', 'tilganger', 'daglig_leder', 0, 6, true),
  ('Bookingsystem-tilgang deaktivert', 'tilganger', 'daglig_leder', 0, 7, true),
  ('Hår1 Portalen tilgang deaktivert', 'tilganger', 'daglig_leder', 0, 8, true),
  ('Sluttoppgjør beregnet', 'dokumenter', 'daglig_leder', 0, 9, true),
  ('Arbeidsattest utstedt', 'dokumenter', 'daglig_leder', 3, 10, true),
  ('Sluttsamtale gjennomført', 'dokumenter', 'daglig_leder', -3, 11, true),
  ('Uniform returnert', 'utstyr', 'ansatt', 0, 12, false)
) AS oppgave(tittel, kategori, ansvarlig_rolle, frist_dager, prioritet, obligatorisk)
WHERE prosess_type = 'offboarding';