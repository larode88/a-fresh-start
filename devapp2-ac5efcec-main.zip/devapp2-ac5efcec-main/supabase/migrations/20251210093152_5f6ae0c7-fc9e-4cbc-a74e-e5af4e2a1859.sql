
-- ============================================
-- SALONS TABLE COMPLETE CLEANUP MIGRATION
-- All-in-one migration with correct column references
-- ============================================

-- PHASE 1: Drop the RLS policy that depends on owner_id
DROP POLICY IF EXISTS "Users can view their associated salon" ON public.salons;

-- PHASE 2: Rename existing columns to match HubSpot field names
ALTER TABLE public.salons RENAME COLUMN hubspot_company_id TO hs_object_id;
ALTER TABLE public.salons RENAME COLUMN innmeldt_dato TO start_medlemskap_dato;
ALTER TABLE public.salons RENAME COLUMN oppsigelse_dato TO oppsigelsesdato_for_medlemskap;
ALTER TABLE public.salons RENAME COLUMN avsluttet_dato TO avsluttet_medlemskap_dato;
ALTER TABLE public.salons RENAME COLUMN arlig_omsetning TO reg_omsetning;

-- PHASE 3: Add new columns
ALTER TABLE public.salons ADD COLUMN IF NOT EXISTS hubspot_owner_id text;
ALTER TABLE public.salons ADD COLUMN IF NOT EXISTS registreringsdato date;
ALTER TABLE public.salons ADD COLUMN IF NOT EXISTS utlpsdato_for_medlemskap date;
ALTER TABLE public.salons ADD COLUMN IF NOT EXISTS ar_reg_omsetning numeric;
ALTER TABLE public.salons ADD COLUMN IF NOT EXISTS reg_resultat numeric;

-- PHASE 4: Migrate district_id data to hubspot_owner_id via mapping table
UPDATE public.salons s
SET hubspot_owner_id = m.hubspot_owner_id
FROM public.hubspot_owner_district_mapping m
WHERE s.district_id = m.district_id
AND s.hubspot_owner_id IS NULL;

-- PHASE 5: Drop unused columns
ALTER TABLE public.salons DROP COLUMN IF EXISTS tripletex_kunde_id;
ALTER TABLE public.salons DROP COLUMN IF EXISTS tripletex_synced_at;
ALTER TABLE public.salons DROP COLUMN IF EXISTS eierskap;
ALTER TABLE public.salons DROP COLUMN IF EXISTS owner_id;

-- PHASE 6: Recreate RLS policy without owner_id reference
CREATE POLICY "Users can view their associated salon" 
ON public.salons 
FOR SELECT 
USING (
  has_role(auth.uid(), 'admin'::app_role)
  OR id IN (SELECT salon_id FROM public.users WHERE id = auth.uid())
  OR id IN (SELECT get_user_accessible_salon_ids(auth.uid()))
);

-- PHASE 7: Create helper functions for hubspot_owner_id lookups
CREATE OR REPLACE FUNCTION public.get_district_name_from_owner(p_hubspot_owner_id text)
RETURNS text
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT d.name
  FROM public.districts d
  JOIN public.hubspot_owner_district_mapping m ON m.district_id = d.id
  WHERE m.hubspot_owner_id = p_hubspot_owner_id
  LIMIT 1
$$;

CREATE OR REPLACE FUNCTION public.get_district_manager_from_owner(p_hubspot_owner_id text)
RETURNS text
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT m.hubspot_owner_name
  FROM public.hubspot_owner_district_mapping m
  WHERE m.hubspot_owner_id = p_hubspot_owner_id
  LIMIT 1
$$;

CREATE OR REPLACE FUNCTION public.get_district_id_from_owner(p_hubspot_owner_id text)
RETURNS uuid
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
  SELECT district_id
  FROM public.hubspot_owner_district_mapping
  WHERE hubspot_owner_id = p_hubspot_owner_id
  LIMIT 1
$$;

-- Add index for hubspot_owner_id lookups
CREATE INDEX IF NOT EXISTS idx_salons_hubspot_owner_id ON public.salons(hubspot_owner_id);

-- Add comments
COMMENT ON COLUMN public.salons.hs_object_id IS 'HubSpot company object ID';
COMMENT ON COLUMN public.salons.hubspot_owner_id IS 'HubSpot owner ID - lookup district/manager via mapping';
COMMENT ON COLUMN public.salons.start_medlemskap_dato IS 'Membership start date';
COMMENT ON COLUMN public.salons.oppsigelsesdato_for_medlemskap IS 'Membership termination notice date';
COMMENT ON COLUMN public.salons.avsluttet_medlemskap_dato IS 'Membership end date';
COMMENT ON COLUMN public.salons.registreringsdato IS 'Membership registration date';
COMMENT ON COLUMN public.salons.utlpsdato_for_medlemskap IS 'Membership expiry date';
COMMENT ON COLUMN public.salons.reg_omsetning IS 'Annual revenue from BRREG';
COMMENT ON COLUMN public.salons.ar_reg_omsetning IS 'Year of BRREG revenue data';
COMMENT ON COLUMN public.salons.reg_resultat IS 'Annual profit/loss from BRREG';
