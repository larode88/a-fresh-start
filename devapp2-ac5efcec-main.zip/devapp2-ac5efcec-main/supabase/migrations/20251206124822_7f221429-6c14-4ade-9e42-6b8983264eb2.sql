-- Add business info columns to insurance_quotes table
ALTER TABLE public.insurance_quotes 
ADD COLUMN IF NOT EXISTS antall_ansatte integer,
ADD COLUMN IF NOT EXISTS antall_arsverk numeric,
ADD COLUMN IF NOT EXISTS aarlig_omsetning numeric;