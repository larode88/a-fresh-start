-- Add individual health insurance agreement number per employee
ALTER TABLE public.users 
ADD COLUMN IF NOT EXISTS helseforsikring_avtalenummer text;