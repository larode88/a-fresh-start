CREATE EXTENSION IF NOT EXISTS "pg_graphql";
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "plpgsql";
CREATE EXTENSION IF NOT EXISTS "supabase_vault";
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
--
-- PostgreSQL database dump
--


-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.7

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--



--
-- Name: app_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.app_role AS ENUM (
    'admin',
    'district_manager',
    'salon_owner',
    'stylist',
    'apprentice',
    'supplier_admin',
    'supplier_sales',
    'supplier_business_dev',
    'daglig_leder',
    'avdelingsleder',
    'styreleder',
    'chain_owner'
);


--
-- Name: calculate_weekly_kpi(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.calculate_weekly_kpi() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE
  v_total_revenue NUMERIC(10,2);
  v_addon_share NUMERIC(5,2);
  v_rebooking NUMERIC(5,2);
  v_efficiency NUMERIC(5,2);
  v_revenue_per_customer NUMERIC(10,2);
  v_revenue_per_hour NUMERIC(10,2);
BEGIN
  -- Calculate KPIs
  v_total_revenue := NEW.treatment_revenue + NEW.retail_revenue;
  
  v_addon_share := CASE 
    WHEN NEW.visit_count > 0 THEN (NEW.visits_with_addon::NUMERIC / NEW.visit_count::NUMERIC) * 100
    ELSE 0 
  END;
  
  v_rebooking := CASE 
    WHEN NEW.visit_count > 0 THEN (NEW.rebooked_visits::NUMERIC / NEW.visit_count::NUMERIC) * 100
    ELSE 0 
  END;
  
  v_efficiency := CASE 
    WHEN NEW.hours_worked > 0 THEN (NEW.hours_with_client / NEW.hours_worked) * 100
    ELSE 0 
  END;
  
  v_revenue_per_customer := CASE 
    WHEN NEW.visit_count > 0 THEN v_total_revenue / NEW.visit_count
    ELSE 0 
  END;
  
  v_revenue_per_hour := CASE 
    WHEN NEW.hours_with_client > 0 THEN v_total_revenue / NEW.hours_with_client
    ELSE 0 
  END;

  -- Insert or update weekly_kpis
  INSERT INTO public.weekly_kpis (
    salon_id, stylist_id, year, week,
    total_revenue, addon_share_percent, rebooking_percent,
    efficiency_percent, revenue_per_customer, revenue_per_hour
  ) VALUES (
    NEW.salon_id, NEW.stylist_id, NEW.year, NEW.week,
    v_total_revenue, v_addon_share, v_rebooking,
    v_efficiency, v_revenue_per_customer, v_revenue_per_hour
  )
  ON CONFLICT (salon_id, stylist_id, year, week) 
  DO UPDATE SET
    total_revenue = v_total_revenue,
    addon_share_percent = v_addon_share,
    rebooking_percent = v_rebooking,
    efficiency_percent = v_efficiency,
    revenue_per_customer = v_revenue_per_customer,
    revenue_per_hour = v_revenue_per_hour,
    updated_at = now();

  RETURN NEW;
END;
$$;


--
-- Name: check_and_award_badges(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.check_and_award_badges() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE
  badge_record RECORD;
  already_has_badge BOOLEAN;
  weeks_count INTEGER;
BEGIN
  -- Loop through all badges and check criteria
  FOR badge_record IN SELECT * FROM badges LOOP
    -- Check if user already has this badge
    SELECT EXISTS(
      SELECT 1 FROM user_badges 
      WHERE user_id = NEW.stylist_id AND badge_id = badge_record.id
    ) INTO already_has_badge;
    
    -- Skip if already has badge
    IF already_has_badge THEN
      CONTINUE;
    END IF;
    
    -- Check criteria based on type
    CASE badge_record.criteria_type
      -- Addon share badges
      WHEN 'addon_share', 'addon_share_percent' THEN
        IF NEW.addon_share_percent >= badge_record.criteria_value THEN
          INSERT INTO user_badges (user_id, badge_id) VALUES (NEW.stylist_id, badge_record.id);
        END IF;
        
      -- Rebooking badges
      WHEN 'rebooking', 'rebooking_percent' THEN
        IF NEW.rebooking_percent >= badge_record.criteria_value THEN
          INSERT INTO user_badges (user_id, badge_id) VALUES (NEW.stylist_id, badge_record.id);
        END IF;
        
      -- Efficiency badges
      WHEN 'efficiency', 'efficiency_percent' THEN
        IF NEW.efficiency_percent >= badge_record.criteria_value THEN
          INSERT INTO user_badges (user_id, badge_id) VALUES (NEW.stylist_id, badge_record.id);
        END IF;
        
      -- Revenue badges
      WHEN 'total_revenue' THEN
        IF NEW.total_revenue >= badge_record.criteria_value THEN
          INSERT INTO user_badges (user_id, badge_id) VALUES (NEW.stylist_id, badge_record.id);
        END IF;
        
      -- Weeks completed badge
      WHEN 'weeks_completed' THEN
        SELECT COUNT(*) INTO weeks_count
        FROM weekly_kpis 
        WHERE stylist_id = NEW.stylist_id;
        
        IF weeks_count >= badge_record.criteria_value THEN
          INSERT INTO user_badges (user_id, badge_id) VALUES (NEW.stylist_id, badge_record.id);
        END IF;
        
      ELSE
        -- Skip unknown criteria types
        NULL;
    END CASE;
  END LOOP;
  
  RETURN NEW;
END;
$$;


--
-- Name: create_announcement_notifications(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.create_announcement_notifications() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
BEGIN
  -- Only create notifications when announcement becomes visible (published and published_at <= now())
  IF NEW.published = true AND (NEW.published_at IS NULL OR NEW.published_at <= now()) THEN
    -- Check if this is a new publication (was draft or scheduled in the past)
    IF OLD.published = false OR (OLD.published_at IS NOT NULL AND OLD.published_at > now()) THEN
      -- Insert notifications for all users matching target roles
      INSERT INTO public.announcement_notifications (announcement_id, user_id)
      SELECT NEW.id, u.id
      FROM public.users u
      WHERE NEW.target_roles IS NULL 
         OR array_length(NEW.target_roles, 1) IS NULL 
         OR u.role::text = ANY(NEW.target_roles)
      ON CONFLICT (announcement_id, user_id) DO NOTHING;
    END IF;
  END IF;
  RETURN NEW;
END;
$$;


--
-- Name: get_district_salon_ids(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_district_salon_ids(_user_id uuid) RETURNS SETOF uuid
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT s.id
  FROM salons s
  WHERE s.district_id = (SELECT district_id FROM users WHERE id = _user_id)
$$;


--
-- Name: get_invitation_by_token(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_invitation_by_token(_token text) RETURNS TABLE(id uuid, token text, email text, role public.app_role, salon_id uuid, district_id uuid, supplier_id uuid, accepted boolean, expires_at timestamp with time zone, created_at timestamp with time zone)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT 
    i.id,
    i.token,
    i.email,
    i.role,
    i.salon_id,
    i.district_id,
    i.supplier_id,
    i.accepted,
    i.expires_at,
    i.created_at
  FROM public.invitations i
  WHERE i.token = _token
    AND i.accepted = false
    AND (i.expires_at IS NULL OR i.expires_at > now())
  LIMIT 1
$$;


--
-- Name: get_salon_supplier_user_ids(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_salon_supplier_user_ids(_salon_id uuid) RETURNS SETOF uuid
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT stu.user_id
  FROM supplier_team_users stu
  WHERE stu.supplier_id IN (
    SELECT ss.supplier_id
    FROM salon_suppliers ss
    WHERE ss.salon_id = _salon_id
  )
$$;


--
-- Name: get_supplier_salon_ids(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_supplier_salon_ids(_user_id uuid) RETURNS SETOF uuid
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT ss.salon_id
  FROM salon_suppliers ss
  WHERE ss.supplier_id = (
    SELECT supplier_id 
    FROM supplier_team_users 
    WHERE user_id = _user_id 
    LIMIT 1
  )
$$;


--
-- Name: get_thread_participant_user_ids(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_thread_participant_user_ids(p_user_id uuid) RETURNS SETOF uuid
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT DISTINCT tp2.user_id
  FROM thread_participants tp1
  JOIN thread_participants tp2 ON tp1.thread_id = tp2.thread_id
  WHERE tp1.user_id = p_user_id
$$;


--
-- Name: get_user_accessible_salon_ids(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_user_accessible_salon_ids(_user_id uuid) RETURNS SETOF uuid
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  -- Direct salon roles
  SELECT salon_id FROM user_salon_roles WHERE user_id = _user_id
  UNION
  -- Via chain ownership
  SELECT s.id FROM salons s
  JOIN user_chain_roles ucr ON s.chain_id = ucr.chain_id
  WHERE ucr.user_id = _user_id
  UNION
  -- Backward compatibility: existing salon_id on users table
  SELECT salon_id FROM users WHERE id = _user_id AND salon_id IS NOT NULL
$$;


--
-- Name: get_user_district_id(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_user_district_id(_user_id uuid) RETURNS uuid
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT district_id
  FROM public.users
  WHERE id = _user_id
  LIMIT 1
$$;


--
-- Name: get_user_role(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_user_role(user_uuid uuid) RETURNS public.app_role
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT role 
  FROM public.user_roles 
  WHERE user_id = user_uuid 
  LIMIT 1
$$;


--
-- Name: get_user_role_from_users(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_user_role_from_users(_user_id uuid) RETURNS public.app_role
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT role
  FROM public.users
  WHERE id = _user_id
  LIMIT 1
$$;


--
-- Name: get_user_salon_id(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_user_salon_id(_user_id uuid) RETURNS uuid
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT salon_id
  FROM public.users
  WHERE id = _user_id
  LIMIT 1
$$;


--
-- Name: get_user_supplier_id(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_user_supplier_id(_user_id uuid) RETURNS uuid
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT supplier_id
  FROM public.supplier_team_users
  WHERE user_id = _user_id
  LIMIT 1
$$;


--
-- Name: handle_new_user(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.handle_new_user() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE
  invitation_record RECORD;
  user_role app_role;
  user_salon_id uuid;
  user_district_id uuid;
  user_supplier_id uuid;
BEGIN
  -- Check for pending invitation
  SELECT * INTO invitation_record
  FROM public.invitations
  WHERE email = NEW.email
    AND accepted = false
    AND (expires_at IS NULL OR expires_at > now())
  LIMIT 1;

  IF FOUND THEN
    user_role := invitation_record.role;
    user_salon_id := invitation_record.salon_id;
    user_district_id := invitation_record.district_id;
    user_supplier_id := invitation_record.supplier_id;
    
    -- Mark invitation as accepted
    UPDATE public.invitations
    SET accepted = true, accepted_at = now()
    WHERE id = invitation_record.id;
  ELSE
    -- Default to stylist if no invitation
    user_role := 'stylist';
    user_salon_id := NULL;
    user_district_id := NULL;
    user_supplier_id := NULL;
  END IF;

  -- Create user in public.users (including role column)
  INSERT INTO public.users (id, email, name, salon_id, district_id, role)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1)),
    user_salon_id,
    user_district_id,
    user_role
  );

  -- Insert role into user_roles table
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, user_role);

  -- If supplier role, create entry in supplier_team_users
  IF user_supplier_id IS NOT NULL AND user_role IN ('supplier_admin', 'supplier_sales', 'supplier_business_dev') THEN
    INSERT INTO public.supplier_team_users (user_id, supplier_id, role)
    VALUES (NEW.id, user_supplier_id, user_role);
  END IF;

  RETURN NEW;
END;
$$;


--
-- Name: has_role(uuid, public.app_role); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.has_role(_user_id uuid, _role public.app_role) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$$;


--
-- Name: has_salon_access(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.has_salon_access(_user_id uuid, _salon_id uuid) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.get_user_accessible_salon_ids(_user_id) AS accessible_salon_id
    WHERE accessible_salon_id = _salon_id
  )
$$;


--
-- Name: is_chain_owner(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.is_chain_owner(_user_id uuid, _chain_id uuid) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_chain_roles
    WHERE user_id = _user_id AND chain_id = _chain_id
  )
$$;


--
-- Name: is_salon_owner(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.is_salon_owner(_user_id uuid) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.users
    WHERE id = _user_id
      AND role = 'salon_owner'::app_role
  )
$$;


--
-- Name: is_supplier_admin(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.is_supplier_admin(_user_id uuid, _supplier_id uuid) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.supplier_team_users
    WHERE user_id = _user_id
      AND supplier_id = _supplier_id
      AND role = 'supplier_admin'::app_role
  )
$$;


--
-- Name: is_thread_participant(uuid, uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.is_thread_participant(_user_id uuid, _thread_id uuid) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.thread_participants
    WHERE user_id = _user_id
      AND thread_id = _thread_id
  )
$$;


--
-- Name: update_challenge_progress(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_challenge_progress() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE
  current_challenge RECORD;
  current_month INTEGER;
  current_year INTEGER;
  salon_avg NUMERIC;
  goal_value NUMERIC;
  is_achieved BOOLEAN;
BEGIN
  -- Get current month and year
  current_month := EXTRACT(MONTH FROM CURRENT_DATE);
  current_year := EXTRACT(YEAR FROM CURRENT_DATE);
  
  -- Find current month's challenge
  SELECT * INTO current_challenge
  FROM monthly_challenges
  WHERE month = current_month AND year = current_year
  LIMIT 1;
  
  -- Exit if no challenge for current month
  IF NOT FOUND OR NEW.salon_id IS NULL THEN
    RETURN NEW;
  END IF;
  
  -- Calculate salon's average for the focused KPI this month
  -- Get all weeks that fall in the current month
  CASE current_challenge.kpi_focus
    WHEN 'addon_share', 'addon_share_percent' THEN
      SELECT COALESCE(AVG(addon_share_percent), 0) INTO salon_avg
      FROM weekly_kpis
      WHERE salon_id = NEW.salon_id
        AND year = current_year
        AND week >= (current_month - 1) * 4 + 1
        AND week <= current_month * 4 + 4;
      goal_value := 70; -- Default goal
      
    WHEN 'rebooking', 'rebooking_percent' THEN
      SELECT COALESCE(AVG(rebooking_percent), 0) INTO salon_avg
      FROM weekly_kpis
      WHERE salon_id = NEW.salon_id
        AND year = current_year
        AND week >= (current_month - 1) * 4 + 1
        AND week <= current_month * 4 + 4;
      goal_value := 85;
      
    WHEN 'efficiency', 'efficiency_percent' THEN
      SELECT COALESCE(AVG(efficiency_percent), 0) INTO salon_avg
      FROM weekly_kpis
      WHERE salon_id = NEW.salon_id
        AND year = current_year
        AND week >= (current_month - 1) * 4 + 1
        AND week <= current_month * 4 + 4;
      goal_value := 80;
      
    WHEN 'total_revenue' THEN
      SELECT COALESCE(AVG(total_revenue), 0) INTO salon_avg
      FROM weekly_kpis
      WHERE salon_id = NEW.salon_id
        AND year = current_year
        AND week >= (current_month - 1) * 4 + 1
        AND week <= current_month * 4 + 4;
      goal_value := 50000;
      
    ELSE
      RETURN NEW;
  END CASE;
  
  -- Check if goal is achieved
  is_achieved := salon_avg >= goal_value;
  
  -- Insert or update challenge progress
  INSERT INTO challenge_progress (salon_id, year, month, progress_value, achieved)
  VALUES (NEW.salon_id, current_year, current_month, salon_avg, is_achieved)
  ON CONFLICT (salon_id, year, month) 
  DO UPDATE SET
    progress_value = salon_avg,
    achieved = is_achieved,
    updated_at = now();
  
  RETURN NEW;
END;
$$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;


SET default_table_access_method = heap;

--
-- Name: announcement_notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.announcement_notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    announcement_id uuid NOT NULL,
    user_id uuid NOT NULL,
    read_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: announcements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.announcements (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title text NOT NULL,
    description text,
    image_url text,
    content text,
    link_type text DEFAULT 'internal'::text NOT NULL,
    external_url text,
    slug text NOT NULL,
    published boolean DEFAULT false NOT NULL,
    published_at timestamp with time zone,
    expires_at timestamp with time zone,
    display_order integer DEFAULT 0 NOT NULL,
    target_roles text[],
    created_by_user_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: badges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.badges (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    icon_key text NOT NULL,
    criteria_type text NOT NULL,
    criteria_value numeric(10,2),
    description text,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: chains; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chains (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    org_number text,
    logo_url text,
    hubspot_company_id text,
    hubspot_synced_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: challenge_progress; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.challenge_progress (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    salon_id uuid,
    year integer NOT NULL,
    month integer NOT NULL,
    progress_value numeric(10,2),
    achieved boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    period_type text DEFAULT 'month'::text NOT NULL,
    CONSTRAINT challenge_progress_period_type_check CHECK ((period_type = ANY (ARRAY['month'::text, 'quarter'::text, 'half_year'::text, 'year'::text])))
);


--
-- Name: districts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.districts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: historical_imports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.historical_imports (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    salon_id uuid,
    file_name text NOT NULL,
    imported_by_user_id uuid,
    imported_at timestamp with time zone DEFAULT now(),
    rows_imported integer DEFAULT 0,
    status text DEFAULT 'pending'::text,
    error_message text
);


--
-- Name: hubspot_oauth_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hubspot_oauth_tokens (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    access_token text NOT NULL,
    refresh_token text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: hubspot_owner_district_mapping; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hubspot_owner_district_mapping (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    hubspot_owner_id text NOT NULL,
    hubspot_owner_email text,
    hubspot_owner_name text,
    district_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: invitations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invitations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email text NOT NULL,
    role public.app_role NOT NULL,
    salon_id uuid,
    district_id uuid,
    created_by_user_id uuid,
    token text NOT NULL,
    accepted boolean DEFAULT false,
    accepted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone DEFAULT (now() + '7 days'::interval),
    supplier_id uuid,
    hubspot_contact_id text
);


--
-- Name: message_read_states; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_read_states (
    message_id uuid NOT NULL,
    user_id uuid NOT NULL,
    read_at timestamp with time zone DEFAULT now()
);


--
-- Name: message_threads; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_threads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    salon_id uuid,
    supplier_id uuid,
    district_id uuid,
    created_by_user_id uuid,
    subject text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    thread_id uuid,
    sender_user_id uuid,
    message_text text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    attachment_url text,
    attachment_name text
);


--
-- Name: monthly_challenges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.monthly_challenges (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    year integer NOT NULL,
    month integer NOT NULL,
    title text NOT NULL,
    description text,
    kpi_focus text NOT NULL,
    goal_description text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    period_type text DEFAULT 'month'::text NOT NULL,
    target_value numeric DEFAULT 75,
    CONSTRAINT monthly_challenges_month_check CHECK (((month >= 1) AND (month <= 12))),
    CONSTRAINT monthly_challenges_period_type_check CHECK ((period_type = ANY (ARRAY['month'::text, 'quarter'::text, 'half_year'::text, 'year'::text])))
);


--
-- Name: role_change_audit; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_change_audit (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    user_email text NOT NULL,
    user_name text NOT NULL,
    old_role text NOT NULL,
    new_role text NOT NULL,
    changed_by_user_id uuid NOT NULL,
    changed_by_name text NOT NULL,
    changed_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: salon_goals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.salon_goals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    salon_id uuid,
    year integer NOT NULL,
    target_addon_share_percent numeric(5,2),
    target_revenue_per_customer numeric(10,2),
    target_revenue_per_hour numeric(10,2),
    target_total_revenue numeric(10,2),
    target_rebooking_percent numeric(5,2),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: salon_suppliers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.salon_suppliers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    salon_id uuid,
    supplier_id uuid,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: salons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.salons (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    address text,
    city text,
    org_number text,
    district_id uuid,
    owner_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    logo_url text,
    legal_name text,
    founded_date date,
    employee_count integer,
    hubspot_company_id text,
    hubspot_synced_at timestamp with time zone,
    chain_id uuid
);


--
-- Name: supplier_team_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplier_team_users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    supplier_id uuid,
    role public.app_role NOT NULL,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT supplier_team_users_role_check CHECK ((role = ANY (ARRAY['supplier_admin'::public.app_role, 'supplier_sales'::public.app_role, 'supplier_business_dev'::public.app_role])))
);


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suppliers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    contact_name text,
    contact_email text,
    active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    hubspot_company_id text,
    hubspot_synced_at timestamp with time zone
);


--
-- Name: thread_participants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.thread_participants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    thread_id uuid NOT NULL,
    user_id uuid NOT NULL,
    added_at timestamp with time zone DEFAULT now(),
    last_read_at timestamp with time zone,
    archived_at timestamp with time zone
);


--
-- Name: user_badges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_badges (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    badge_id uuid,
    earned_at timestamp with time zone DEFAULT now()
);


--
-- Name: user_chain_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_chain_roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    chain_id uuid NOT NULL,
    role public.app_role DEFAULT 'chain_owner'::public.app_role NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: user_notification_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_notification_preferences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    email_on_new_message boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    role public.app_role NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: user_salon_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_salon_roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    salon_id uuid NOT NULL,
    role public.app_role NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    name text NOT NULL,
    email text NOT NULL,
    phone text,
    role public.app_role NOT NULL,
    salon_id uuid,
    district_id uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    avatar_url text,
    hubspot_contact_id text,
    hubspot_synced_at timestamp with time zone
);


--
-- Name: weekly_kpi_inputs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.weekly_kpi_inputs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    salon_id uuid,
    stylist_id uuid,
    year integer NOT NULL,
    week integer NOT NULL,
    treatment_revenue numeric(10,2) DEFAULT 0 NOT NULL,
    retail_revenue numeric(10,2) DEFAULT 0 NOT NULL,
    addon_count integer DEFAULT 0 NOT NULL,
    visit_count integer DEFAULT 0 NOT NULL,
    visits_with_addon integer DEFAULT 0 NOT NULL,
    hours_worked numeric(5,2) DEFAULT 0 NOT NULL,
    hours_with_client numeric(5,2) DEFAULT 0 NOT NULL,
    rebooked_visits integer DEFAULT 0 NOT NULL,
    submitted_by_user_id uuid,
    submitted_at timestamp with time zone DEFAULT now(),
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT weekly_kpi_inputs_week_check CHECK (((week >= 1) AND (week <= 53)))
);


--
-- Name: weekly_kpis; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.weekly_kpis (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    salon_id uuid,
    stylist_id uuid,
    year integer NOT NULL,
    week integer NOT NULL,
    total_revenue numeric(10,2) DEFAULT 0 NOT NULL,
    addon_share_percent numeric(5,2) DEFAULT 0 NOT NULL,
    rebooking_percent numeric(5,2) DEFAULT 0 NOT NULL,
    efficiency_percent numeric(5,2) DEFAULT 0 NOT NULL,
    revenue_per_customer numeric(10,2) DEFAULT 0 NOT NULL,
    revenue_per_hour numeric(10,2) DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: announcement_notifications announcement_notifications_announcement_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcement_notifications
    ADD CONSTRAINT announcement_notifications_announcement_id_user_id_key UNIQUE (announcement_id, user_id);


--
-- Name: announcement_notifications announcement_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcement_notifications
    ADD CONSTRAINT announcement_notifications_pkey PRIMARY KEY (id);


--
-- Name: announcements announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);


--
-- Name: announcements announcements_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_slug_key UNIQUE (slug);


--
-- Name: badges badges_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.badges
    ADD CONSTRAINT badges_name_key UNIQUE (name);


--
-- Name: badges badges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.badges
    ADD CONSTRAINT badges_pkey PRIMARY KEY (id);


--
-- Name: chains chains_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chains
    ADD CONSTRAINT chains_pkey PRIMARY KEY (id);


--
-- Name: challenge_progress challenge_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.challenge_progress
    ADD CONSTRAINT challenge_progress_pkey PRIMARY KEY (id);


--
-- Name: challenge_progress challenge_progress_salon_period_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.challenge_progress
    ADD CONSTRAINT challenge_progress_salon_period_unique UNIQUE (salon_id, year, month, period_type);


--
-- Name: challenge_progress challenge_progress_salon_year_month_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.challenge_progress
    ADD CONSTRAINT challenge_progress_salon_year_month_key UNIQUE (salon_id, year, month);


--
-- Name: districts districts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.districts
    ADD CONSTRAINT districts_pkey PRIMARY KEY (id);


--
-- Name: historical_imports historical_imports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.historical_imports
    ADD CONSTRAINT historical_imports_pkey PRIMARY KEY (id);


--
-- Name: hubspot_oauth_tokens hubspot_oauth_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hubspot_oauth_tokens
    ADD CONSTRAINT hubspot_oauth_tokens_pkey PRIMARY KEY (id);


--
-- Name: hubspot_owner_district_mapping hubspot_owner_district_mapping_hubspot_owner_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hubspot_owner_district_mapping
    ADD CONSTRAINT hubspot_owner_district_mapping_hubspot_owner_id_key UNIQUE (hubspot_owner_id);


--
-- Name: hubspot_owner_district_mapping hubspot_owner_district_mapping_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hubspot_owner_district_mapping
    ADD CONSTRAINT hubspot_owner_district_mapping_pkey PRIMARY KEY (id);


--
-- Name: invitations invitations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invitations
    ADD CONSTRAINT invitations_pkey PRIMARY KEY (id);


--
-- Name: invitations invitations_token_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invitations
    ADD CONSTRAINT invitations_token_key UNIQUE (token);


--
-- Name: message_read_states message_read_states_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_read_states
    ADD CONSTRAINT message_read_states_pkey PRIMARY KEY (message_id, user_id);


--
-- Name: message_threads message_threads_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_threads
    ADD CONSTRAINT message_threads_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: monthly_challenges monthly_challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monthly_challenges
    ADD CONSTRAINT monthly_challenges_pkey PRIMARY KEY (id);


--
-- Name: monthly_challenges monthly_challenges_year_month_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.monthly_challenges
    ADD CONSTRAINT monthly_challenges_year_month_key UNIQUE (year, month);


--
-- Name: role_change_audit role_change_audit_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_change_audit
    ADD CONSTRAINT role_change_audit_pkey PRIMARY KEY (id);


--
-- Name: salon_goals salon_goals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salon_goals
    ADD CONSTRAINT salon_goals_pkey PRIMARY KEY (id);


--
-- Name: salon_goals salon_goals_salon_id_year_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salon_goals
    ADD CONSTRAINT salon_goals_salon_id_year_key UNIQUE (salon_id, year);


--
-- Name: salon_suppliers salon_suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salon_suppliers
    ADD CONSTRAINT salon_suppliers_pkey PRIMARY KEY (id);


--
-- Name: salon_suppliers salon_suppliers_salon_id_supplier_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salon_suppliers
    ADD CONSTRAINT salon_suppliers_salon_id_supplier_id_key UNIQUE (salon_id, supplier_id);


--
-- Name: salons salons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salons
    ADD CONSTRAINT salons_pkey PRIMARY KEY (id);


--
-- Name: supplier_team_users supplier_team_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_team_users
    ADD CONSTRAINT supplier_team_users_pkey PRIMARY KEY (id);


--
-- Name: supplier_team_users supplier_team_users_user_id_supplier_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_team_users
    ADD CONSTRAINT supplier_team_users_user_id_supplier_id_key UNIQUE (user_id, supplier_id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: thread_participants thread_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.thread_participants
    ADD CONSTRAINT thread_participants_pkey PRIMARY KEY (id);


--
-- Name: thread_participants thread_participants_thread_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.thread_participants
    ADD CONSTRAINT thread_participants_thread_id_user_id_key UNIQUE (thread_id, user_id);


--
-- Name: user_badges user_badges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_badges
    ADD CONSTRAINT user_badges_pkey PRIMARY KEY (id);


--
-- Name: user_badges user_badges_user_id_badge_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_badges
    ADD CONSTRAINT user_badges_user_id_badge_id_key UNIQUE (user_id, badge_id);


--
-- Name: user_chain_roles user_chain_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_chain_roles
    ADD CONSTRAINT user_chain_roles_pkey PRIMARY KEY (id);


--
-- Name: user_chain_roles user_chain_roles_user_id_chain_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_chain_roles
    ADD CONSTRAINT user_chain_roles_user_id_chain_id_key UNIQUE (user_id, chain_id);


--
-- Name: user_notification_preferences user_notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_notification_preferences
    ADD CONSTRAINT user_notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: user_notification_preferences user_notification_preferences_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_notification_preferences
    ADD CONSTRAINT user_notification_preferences_user_id_key UNIQUE (user_id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_user_id_role_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_role_key UNIQUE (user_id, role);


--
-- Name: user_salon_roles user_salon_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_salon_roles
    ADD CONSTRAINT user_salon_roles_pkey PRIMARY KEY (id);


--
-- Name: user_salon_roles user_salon_roles_user_id_salon_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_salon_roles
    ADD CONSTRAINT user_salon_roles_user_id_salon_id_key UNIQUE (user_id, salon_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: weekly_kpi_inputs weekly_kpi_inputs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weekly_kpi_inputs
    ADD CONSTRAINT weekly_kpi_inputs_pkey PRIMARY KEY (id);


--
-- Name: weekly_kpi_inputs weekly_kpi_inputs_salon_id_stylist_id_year_week_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weekly_kpi_inputs
    ADD CONSTRAINT weekly_kpi_inputs_salon_id_stylist_id_year_week_key UNIQUE (salon_id, stylist_id, year, week);


--
-- Name: weekly_kpis weekly_kpis_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weekly_kpis
    ADD CONSTRAINT weekly_kpis_pkey PRIMARY KEY (id);


--
-- Name: weekly_kpis weekly_kpis_salon_id_stylist_id_year_week_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weekly_kpis
    ADD CONSTRAINT weekly_kpis_salon_id_stylist_id_year_week_key UNIQUE (salon_id, stylist_id, year, week);


--
-- Name: idx_role_change_audit_changed_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_role_change_audit_changed_at ON public.role_change_audit USING btree (changed_at DESC);


--
-- Name: idx_salons_hubspot_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_salons_hubspot_company_id ON public.salons USING btree (hubspot_company_id);


--
-- Name: idx_suppliers_hubspot_company_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_suppliers_hubspot_company_id ON public.suppliers USING btree (hubspot_company_id);


--
-- Name: idx_users_hubspot_contact_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_hubspot_contact_id ON public.users USING btree (hubspot_contact_id);


--
-- Name: weekly_kpis award_badges_on_kpi_update; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER award_badges_on_kpi_update AFTER INSERT OR UPDATE ON public.weekly_kpis FOR EACH ROW EXECUTE FUNCTION public.check_and_award_badges();


--
-- Name: weekly_kpi_inputs trg_calculate_kpi; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_calculate_kpi AFTER INSERT OR UPDATE ON public.weekly_kpi_inputs FOR EACH ROW EXECUTE FUNCTION public.calculate_weekly_kpi();


--
-- Name: announcements trigger_create_announcement_notifications; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trigger_create_announcement_notifications AFTER UPDATE ON public.announcements FOR EACH ROW EXECUTE FUNCTION public.create_announcement_notifications();


--
-- Name: announcements update_announcements_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_announcements_updated_at BEFORE UPDATE ON public.announcements FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: chains update_chains_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_chains_updated_at BEFORE UPDATE ON public.chains FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: weekly_kpis update_challenge_on_kpi_change; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_challenge_on_kpi_change AFTER INSERT OR UPDATE ON public.weekly_kpis FOR EACH ROW EXECUTE FUNCTION public.update_challenge_progress();


--
-- Name: salons update_salons_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_salons_updated_at BEFORE UPDATE ON public.salons FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: user_notification_preferences update_user_notification_preferences_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_user_notification_preferences_updated_at BEFORE UPDATE ON public.user_notification_preferences FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: weekly_kpi_inputs update_weekly_kpi_inputs_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_weekly_kpi_inputs_updated_at BEFORE UPDATE ON public.weekly_kpi_inputs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: announcement_notifications announcement_notifications_announcement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcement_notifications
    ADD CONSTRAINT announcement_notifications_announcement_id_fkey FOREIGN KEY (announcement_id) REFERENCES public.announcements(id) ON DELETE CASCADE;


--
-- Name: announcement_notifications announcement_notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcement_notifications
    ADD CONSTRAINT announcement_notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: announcements announcements_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.announcements
    ADD CONSTRAINT announcements_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id);


--
-- Name: challenge_progress challenge_progress_salon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.challenge_progress
    ADD CONSTRAINT challenge_progress_salon_id_fkey FOREIGN KEY (salon_id) REFERENCES public.salons(id) ON DELETE CASCADE;


--
-- Name: users fk_users_salon; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk_users_salon FOREIGN KEY (salon_id) REFERENCES public.salons(id) ON DELETE SET NULL;


--
-- Name: historical_imports historical_imports_imported_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.historical_imports
    ADD CONSTRAINT historical_imports_imported_by_user_id_fkey FOREIGN KEY (imported_by_user_id) REFERENCES public.users(id);


--
-- Name: historical_imports historical_imports_salon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.historical_imports
    ADD CONSTRAINT historical_imports_salon_id_fkey FOREIGN KEY (salon_id) REFERENCES public.salons(id) ON DELETE CASCADE;


--
-- Name: hubspot_owner_district_mapping hubspot_owner_district_mapping_district_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hubspot_owner_district_mapping
    ADD CONSTRAINT hubspot_owner_district_mapping_district_id_fkey FOREIGN KEY (district_id) REFERENCES public.districts(id) ON DELETE SET NULL;


--
-- Name: invitations invitations_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invitations
    ADD CONSTRAINT invitations_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id);


--
-- Name: invitations invitations_district_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invitations
    ADD CONSTRAINT invitations_district_id_fkey FOREIGN KEY (district_id) REFERENCES public.districts(id);


--
-- Name: invitations invitations_salon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invitations
    ADD CONSTRAINT invitations_salon_id_fkey FOREIGN KEY (salon_id) REFERENCES public.salons(id);


--
-- Name: invitations invitations_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invitations
    ADD CONSTRAINT invitations_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id);


--
-- Name: message_read_states message_read_states_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_read_states
    ADD CONSTRAINT message_read_states_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(id) ON DELETE CASCADE;


--
-- Name: message_read_states message_read_states_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_read_states
    ADD CONSTRAINT message_read_states_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: message_threads message_threads_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_threads
    ADD CONSTRAINT message_threads_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public.users(id);


--
-- Name: message_threads message_threads_district_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_threads
    ADD CONSTRAINT message_threads_district_id_fkey FOREIGN KEY (district_id) REFERENCES public.districts(id);


--
-- Name: message_threads message_threads_salon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_threads
    ADD CONSTRAINT message_threads_salon_id_fkey FOREIGN KEY (salon_id) REFERENCES public.salons(id);


--
-- Name: message_threads message_threads_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_threads
    ADD CONSTRAINT message_threads_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id);


--
-- Name: messages messages_sender_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_sender_user_id_fkey FOREIGN KEY (sender_user_id) REFERENCES public.users(id);


--
-- Name: messages messages_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.message_threads(id) ON DELETE CASCADE;


--
-- Name: salon_goals salon_goals_salon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salon_goals
    ADD CONSTRAINT salon_goals_salon_id_fkey FOREIGN KEY (salon_id) REFERENCES public.salons(id) ON DELETE CASCADE;


--
-- Name: salon_suppliers salon_suppliers_salon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salon_suppliers
    ADD CONSTRAINT salon_suppliers_salon_id_fkey FOREIGN KEY (salon_id) REFERENCES public.salons(id) ON DELETE CASCADE;


--
-- Name: salon_suppliers salon_suppliers_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salon_suppliers
    ADD CONSTRAINT salon_suppliers_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON DELETE CASCADE;


--
-- Name: salons salons_chain_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salons
    ADD CONSTRAINT salons_chain_id_fkey FOREIGN KEY (chain_id) REFERENCES public.chains(id) ON DELETE SET NULL;


--
-- Name: salons salons_district_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salons
    ADD CONSTRAINT salons_district_id_fkey FOREIGN KEY (district_id) REFERENCES public.districts(id);


--
-- Name: salons salons_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.salons
    ADD CONSTRAINT salons_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id);


--
-- Name: supplier_team_users supplier_team_users_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_team_users
    ADD CONSTRAINT supplier_team_users_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id) ON DELETE CASCADE;


--
-- Name: supplier_team_users supplier_team_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_team_users
    ADD CONSTRAINT supplier_team_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: thread_participants thread_participants_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.thread_participants
    ADD CONSTRAINT thread_participants_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.message_threads(id) ON DELETE CASCADE;


--
-- Name: thread_participants thread_participants_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.thread_participants
    ADD CONSTRAINT thread_participants_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_badges user_badges_badge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_badges
    ADD CONSTRAINT user_badges_badge_id_fkey FOREIGN KEY (badge_id) REFERENCES public.badges(id) ON DELETE CASCADE;


--
-- Name: user_badges user_badges_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_badges
    ADD CONSTRAINT user_badges_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_chain_roles user_chain_roles_chain_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_chain_roles
    ADD CONSTRAINT user_chain_roles_chain_id_fkey FOREIGN KEY (chain_id) REFERENCES public.chains(id) ON DELETE CASCADE;


--
-- Name: user_chain_roles user_chain_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_chain_roles
    ADD CONSTRAINT user_chain_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_notification_preferences user_notification_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_notification_preferences
    ADD CONSTRAINT user_notification_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: user_salon_roles user_salon_roles_salon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_salon_roles
    ADD CONSTRAINT user_salon_roles_salon_id_fkey FOREIGN KEY (salon_id) REFERENCES public.salons(id) ON DELETE CASCADE;


--
-- Name: user_salon_roles user_salon_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_salon_roles
    ADD CONSTRAINT user_salon_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_district_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_district_id_fkey FOREIGN KEY (district_id) REFERENCES public.districts(id);


--
-- Name: users users_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: weekly_kpi_inputs weekly_kpi_inputs_salon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weekly_kpi_inputs
    ADD CONSTRAINT weekly_kpi_inputs_salon_id_fkey FOREIGN KEY (salon_id) REFERENCES public.salons(id) ON DELETE CASCADE;


--
-- Name: weekly_kpi_inputs weekly_kpi_inputs_stylist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weekly_kpi_inputs
    ADD CONSTRAINT weekly_kpi_inputs_stylist_id_fkey FOREIGN KEY (stylist_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: weekly_kpi_inputs weekly_kpi_inputs_submitted_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weekly_kpi_inputs
    ADD CONSTRAINT weekly_kpi_inputs_submitted_by_user_id_fkey FOREIGN KEY (submitted_by_user_id) REFERENCES public.users(id);


--
-- Name: weekly_kpis weekly_kpis_salon_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weekly_kpis
    ADD CONSTRAINT weekly_kpis_salon_id_fkey FOREIGN KEY (salon_id) REFERENCES public.salons(id) ON DELETE CASCADE;


--
-- Name: weekly_kpis weekly_kpis_stylist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.weekly_kpis
    ADD CONSTRAINT weekly_kpis_stylist_id_fkey FOREIGN KEY (stylist_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: invitations Admins and owners can create invitations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins and owners can create invitations" ON public.invitations FOR INSERT WITH CHECK ((public.get_user_role(auth.uid()) = ANY (ARRAY['admin'::public.app_role, 'salon_owner'::public.app_role])));


--
-- Name: districts Admins can delete districts; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can delete districts" ON public.districts FOR DELETE USING (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: invitations Admins can delete invitations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can delete invitations" ON public.invitations FOR DELETE USING (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: salons Admins can delete salons; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can delete salons" ON public.salons FOR DELETE USING (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: users Admins can delete users; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can delete users" ON public.users FOR DELETE USING (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: role_change_audit Admins can insert audit logs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can insert audit logs" ON public.role_change_audit FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: salons Admins can insert salons; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can insert salons" ON public.salons FOR INSERT WITH CHECK ((public.get_user_role(auth.uid()) = 'admin'::public.app_role));


--
-- Name: hubspot_oauth_tokens Admins can manage HubSpot tokens; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage HubSpot tokens" ON public.hubspot_oauth_tokens USING (public.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: historical_imports Admins can manage all historical imports; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all historical imports" ON public.historical_imports USING (public.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: salon_goals Admins can manage all salon goals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all salon goals" ON public.salon_goals USING (public.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: salon_suppliers Admins can manage all salon-supplier relationships; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all salon-supplier relationships" ON public.salon_suppliers USING (public.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: supplier_team_users Admins can manage all supplier team users; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all supplier team users" ON public.supplier_team_users USING (public.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: user_chain_roles Admins can manage all user_chain_roles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all user_chain_roles" ON public.user_chain_roles USING (public.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: user_salon_roles Admins can manage all user_salon_roles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all user_salon_roles" ON public.user_salon_roles USING (public.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: announcements Admins can manage announcements; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage announcements" ON public.announcements USING (public.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: badges Admins can manage badges; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage badges" ON public.badges TO authenticated USING (public.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: chains Admins can manage chains; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage chains" ON public.chains USING (public.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: districts Admins can manage districts; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage districts" ON public.districts USING (public.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: hubspot_owner_district_mapping Admins can manage hubspot owner mapping; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage hubspot owner mapping" ON public.hubspot_owner_district_mapping USING (public.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: monthly_challenges Admins can manage monthly challenges; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage monthly challenges" ON public.monthly_challenges TO authenticated USING (public.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: suppliers Admins can manage suppliers; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage suppliers" ON public.suppliers USING ((public.get_user_role(auth.uid()) = 'admin'::public.app_role));


--
-- Name: users Admins can update any user; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can update any user" ON public.users FOR UPDATE USING (public.has_role(auth.uid(), 'admin'::public.app_role)) WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: salons Admins can update salons; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can update salons" ON public.salons FOR UPDATE USING ((public.get_user_role(auth.uid()) = 'admin'::public.app_role));


--
-- Name: invitations Admins can view all invitations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view all invitations" ON public.invitations FOR SELECT USING ((public.get_user_role(auth.uid()) = 'admin'::public.app_role));


--
-- Name: salons Admins can view all salons; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view all salons" ON public.salons FOR SELECT USING (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: user_roles Admins can view all user roles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view all user roles" ON public.user_roles FOR SELECT USING (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: users Admins can view all users; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view all users" ON public.users FOR SELECT USING (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: role_change_audit Admins can view audit logs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view audit logs" ON public.role_change_audit FOR SELECT USING (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: message_threads Authenticated users can create threads; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Authenticated users can create threads" ON public.message_threads FOR INSERT WITH CHECK ((auth.uid() = created_by_user_id));


--
-- Name: chains Authenticated users can view all chains; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Authenticated users can view all chains" ON public.chains FOR SELECT USING ((auth.uid() IS NOT NULL));


--
-- Name: announcements Authenticated users can view published announcements; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Authenticated users can view published announcements" ON public.announcements FOR SELECT USING (((published = true) AND ((published_at IS NULL) OR (published_at <= now())) AND ((expires_at IS NULL) OR (expires_at > now()))));


--
-- Name: users District managers can view admins; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "District managers can view admins" ON public.users FOR SELECT TO authenticated USING ((public.has_role(auth.uid(), 'district_manager'::public.app_role) AND (role = 'admin'::public.app_role)));


--
-- Name: salons District managers can view all salons; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "District managers can view all salons" ON public.salons FOR SELECT USING (public.has_role(auth.uid(), 'district_manager'::public.app_role));


--
-- Name: users District managers can view users in their district salons; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "District managers can view users in their district salons" ON public.users FOR SELECT TO authenticated USING ((public.has_role(auth.uid(), 'district_manager'::public.app_role) AND (salon_id IN ( SELECT public.get_district_salon_ids(auth.uid()) AS get_district_salon_ids))));


--
-- Name: suppliers Everyone can view active suppliers; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Everyone can view active suppliers" ON public.suppliers FOR SELECT USING (((active = true) OR (public.get_user_role(auth.uid()) = 'admin'::public.app_role)));


--
-- Name: badges Everyone can view badges; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Everyone can view badges" ON public.badges FOR SELECT TO authenticated USING (true);


--
-- Name: districts Everyone can view districts; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Everyone can view districts" ON public.districts FOR SELECT USING (true);


--
-- Name: hubspot_owner_district_mapping Everyone can view hubspot owner mapping; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Everyone can view hubspot owner mapping" ON public.hubspot_owner_district_mapping FOR SELECT USING (true);


--
-- Name: monthly_challenges Everyone can view monthly challenges; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Everyone can view monthly challenges" ON public.monthly_challenges FOR SELECT TO authenticated USING (true);


--
-- Name: user_roles Only admins can delete roles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Only admins can delete roles" ON public.user_roles FOR DELETE TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.user_roles user_roles_1
  WHERE ((user_roles_1.user_id = auth.uid()) AND (user_roles_1.role = 'admin'::public.app_role)))));


--
-- Name: user_roles Only admins can insert roles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Only admins can insert roles" ON public.user_roles FOR INSERT TO authenticated WITH CHECK ((EXISTS ( SELECT 1
   FROM public.user_roles user_roles_1
  WHERE ((user_roles_1.user_id = auth.uid()) AND (user_roles_1.role = 'admin'::public.app_role)))));


--
-- Name: user_roles Only admins can update roles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Only admins can update roles" ON public.user_roles FOR UPDATE TO authenticated USING ((EXISTS ( SELECT 1
   FROM public.user_roles user_roles_1
  WHERE ((user_roles_1.user_id = auth.uid()) AND (user_roles_1.role = 'admin'::public.app_role)))));


--
-- Name: historical_imports Salon owners can create imports for their salon; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Salon owners can create imports for their salon" ON public.historical_imports FOR INSERT WITH CHECK (((salon_id = public.get_user_salon_id(auth.uid())) AND public.is_salon_owner(auth.uid())));


--
-- Name: salon_goals Salon owners can manage their salon goals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Salon owners can manage their salon goals" ON public.salon_goals USING (((salon_id = public.get_user_salon_id(auth.uid())) AND public.is_salon_owner(auth.uid()))) WITH CHECK (((salon_id = public.get_user_salon_id(auth.uid())) AND public.is_salon_owner(auth.uid())));


--
-- Name: salon_suppliers Salon owners can manage their supplier relationships; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Salon owners can manage their supplier relationships" ON public.salon_suppliers USING (((salon_id = public.get_user_salon_id(auth.uid())) AND public.is_salon_owner(auth.uid())));


--
-- Name: challenge_progress Salon owners can update their salon's challenge progress; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Salon owners can update their salon's challenge progress" ON public.challenge_progress USING ((((salon_id = public.get_user_salon_id(auth.uid())) AND public.is_salon_owner(auth.uid())) OR public.has_role(auth.uid(), 'admin'::public.app_role))) WITH CHECK ((((salon_id = public.get_user_salon_id(auth.uid())) AND public.is_salon_owner(auth.uid())) OR public.has_role(auth.uid(), 'admin'::public.app_role)));


--
-- Name: users Salon owners can view linked supplier users; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Salon owners can view linked supplier users" ON public.users FOR SELECT TO authenticated USING ((public.is_salon_owner(auth.uid()) AND (id IN ( SELECT public.get_salon_supplier_user_ids(public.get_user_salon_id(auth.uid())) AS get_salon_supplier_user_ids))));


--
-- Name: historical_imports Salon owners can view their salon imports; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Salon owners can view their salon imports" ON public.historical_imports FOR SELECT USING (((salon_id = public.get_user_salon_id(auth.uid())) AND public.is_salon_owner(auth.uid())));


--
-- Name: supplier_team_users Supplier admins can manage their team; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Supplier admins can manage their team" ON public.supplier_team_users USING (public.is_supplier_admin(auth.uid(), supplier_id)) WITH CHECK (public.is_supplier_admin(auth.uid(), supplier_id));


--
-- Name: users Suppliers can view Hår1 staff; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Suppliers can view Hår1 staff" ON public.users FOR SELECT TO authenticated USING (((public.get_user_role_from_users(auth.uid()) = ANY (ARRAY['supplier_admin'::public.app_role, 'supplier_sales'::public.app_role, 'supplier_business_dev'::public.app_role])) AND (role = ANY (ARRAY['admin'::public.app_role, 'district_manager'::public.app_role]))));


--
-- Name: salon_suppliers Suppliers can view their relationships; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Suppliers can view their relationships" ON public.salon_suppliers FOR SELECT USING ((supplier_id = public.get_user_supplier_id(auth.uid())));


--
-- Name: users Suppliers can view users in linked salons; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Suppliers can view users in linked salons" ON public.users FOR SELECT TO authenticated USING (((public.get_user_role_from_users(auth.uid()) = ANY (ARRAY['supplier_admin'::public.app_role, 'supplier_sales'::public.app_role, 'supplier_business_dev'::public.app_role])) AND (salon_id IN ( SELECT public.get_supplier_salon_ids(auth.uid()) AS get_supplier_salon_ids))));


--
-- Name: user_badges System can award badges to users; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "System can award badges to users" ON public.user_badges FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: announcement_notifications System can insert notifications; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "System can insert notifications" ON public.announcement_notifications FOR INSERT WITH CHECK (true);


--
-- Name: invitations Users can accept their own invitations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can accept their own invitations" ON public.invitations FOR UPDATE USING ((email = auth.email()));


--
-- Name: thread_participants Users can add participants to their threads; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can add participants to their threads" ON public.thread_participants FOR INSERT WITH CHECK (((EXISTS ( SELECT 1
   FROM public.thread_participants tp
  WHERE ((tp.thread_id = thread_participants.thread_id) AND (tp.user_id = auth.uid())))) OR (EXISTS ( SELECT 1
   FROM public.message_threads mt
  WHERE ((mt.id = thread_participants.thread_id) AND (mt.created_by_user_id = auth.uid()))))));


--
-- Name: thread_participants Users can delete their own participation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can delete their own participation" ON public.thread_participants FOR DELETE TO authenticated USING ((user_id = auth.uid()));


--
-- Name: weekly_kpi_inputs Users can insert their own KPI inputs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can insert their own KPI inputs" ON public.weekly_kpi_inputs FOR INSERT WITH CHECK (((stylist_id = auth.uid()) OR ((salon_id = public.get_user_salon_id(auth.uid())) AND public.is_salon_owner(auth.uid()))));


--
-- Name: user_notification_preferences Users can insert their own preferences; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can insert their own preferences" ON public.user_notification_preferences FOR INSERT WITH CHECK ((user_id = auth.uid()));


--
-- Name: users Users can insert their own profile; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can insert their own profile" ON public.users FOR INSERT WITH CHECK ((auth.uid() = id));


--
-- Name: message_read_states Users can manage their own read states; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can manage their own read states" ON public.message_read_states USING ((user_id = auth.uid())) WITH CHECK ((user_id = auth.uid()));


--
-- Name: messages Users can send messages to threads they have access to; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can send messages to threads they have access to" ON public.messages FOR INSERT WITH CHECK (((auth.uid() = sender_user_id) AND (public.is_thread_participant(auth.uid(), thread_id) OR public.has_role(auth.uid(), 'admin'::public.app_role))));


--
-- Name: weekly_kpi_inputs Users can update their own KPI inputs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can update their own KPI inputs" ON public.weekly_kpi_inputs FOR UPDATE USING (((stylist_id = auth.uid()) OR ((salon_id = public.get_user_salon_id(auth.uid())) AND (public.is_salon_owner(auth.uid()) OR public.has_role(auth.uid(), 'district_manager'::public.app_role)))));


--
-- Name: announcement_notifications Users can update their own notifications; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can update their own notifications" ON public.announcement_notifications FOR UPDATE USING ((user_id = auth.uid()));


--
-- Name: thread_participants Users can update their own participation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can update their own participation" ON public.thread_participants FOR UPDATE TO authenticated USING ((user_id = auth.uid())) WITH CHECK ((user_id = auth.uid()));


--
-- Name: user_notification_preferences Users can update their own preferences; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can update their own preferences" ON public.user_notification_preferences FOR UPDATE USING ((user_id = auth.uid()));


--
-- Name: users Users can update their own profile; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can update their own profile" ON public.users FOR UPDATE USING ((auth.uid() = id)) WITH CHECK (((auth.uid() = id) AND (role = public.get_user_role_from_users(auth.uid()))));


--
-- Name: weekly_kpis Users can view KPIs for their salon; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view KPIs for their salon" ON public.weekly_kpis FOR SELECT USING (((stylist_id = auth.uid()) OR ((salon_id = public.get_user_salon_id(auth.uid())) AND (public.is_salon_owner(auth.uid()) OR public.has_role(auth.uid(), 'district_manager'::public.app_role) OR public.has_role(auth.uid(), 'admin'::public.app_role))) OR (public.has_role(auth.uid(), 'district_manager'::public.app_role) AND (salon_id IN ( SELECT s.id
   FROM public.salons s
  WHERE (s.district_id = public.get_user_district_id(auth.uid()))))) OR public.has_role(auth.uid(), 'admin'::public.app_role)));


--
-- Name: challenge_progress Users can view challenge progress for their salon; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view challenge progress for their salon" ON public.challenge_progress FOR SELECT USING (((salon_id = public.get_user_salon_id(auth.uid())) OR public.has_role(auth.uid(), 'admin'::public.app_role) OR public.has_role(auth.uid(), 'district_manager'::public.app_role)));


--
-- Name: invitations Users can view invitations sent to their email; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view invitations sent to their email" ON public.invitations FOR SELECT USING ((email = auth.email()));


--
-- Name: messages Users can view messages in their threads; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view messages in their threads" ON public.messages FOR SELECT USING ((public.is_thread_participant(auth.uid(), thread_id) OR public.has_role(auth.uid(), 'admin'::public.app_role)));


--
-- Name: thread_participants Users can view participants in their threads; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view participants in their threads" ON public.thread_participants FOR SELECT TO authenticated USING ((public.is_thread_participant(auth.uid(), thread_id) OR public.has_role(auth.uid(), 'admin'::public.app_role)));


--
-- Name: salons Users can view their associated salon; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their associated salon" ON public.salons FOR SELECT USING (((owner_id = auth.uid()) OR (id = public.get_user_salon_id(auth.uid()))));


--
-- Name: weekly_kpi_inputs Users can view their own KPI inputs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their own KPI inputs" ON public.weekly_kpi_inputs FOR SELECT USING (((stylist_id = auth.uid()) OR ((salon_id = public.get_user_salon_id(auth.uid())) AND (public.is_salon_owner(auth.uid()) OR public.has_role(auth.uid(), 'district_manager'::public.app_role) OR public.has_role(auth.uid(), 'admin'::public.app_role))) OR (public.has_role(auth.uid(), 'district_manager'::public.app_role) AND (salon_id IN ( SELECT s.id
   FROM public.salons s
  WHERE (s.district_id = public.get_user_district_id(auth.uid()))))) OR public.has_role(auth.uid(), 'admin'::public.app_role)));


--
-- Name: user_badges Users can view their own badges; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their own badges" ON public.user_badges FOR SELECT TO authenticated USING (((user_id = auth.uid()) OR public.has_role(auth.uid(), 'admin'::public.app_role)));


--
-- Name: user_chain_roles Users can view their own chain roles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their own chain roles" ON public.user_chain_roles FOR SELECT USING ((user_id = auth.uid()));


--
-- Name: announcement_notifications Users can view their own notifications; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their own notifications" ON public.announcement_notifications FOR SELECT USING ((user_id = auth.uid()));


--
-- Name: thread_participants Users can view their own participations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their own participations" ON public.thread_participants FOR SELECT USING ((user_id = auth.uid()));


--
-- Name: user_notification_preferences Users can view their own preferences; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their own preferences" ON public.user_notification_preferences FOR SELECT USING ((user_id = auth.uid()));


--
-- Name: users Users can view their own profile; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their own profile" ON public.users FOR SELECT USING ((auth.uid() = id));


--
-- Name: user_roles Users can view their own roles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their own roles" ON public.user_roles FOR SELECT TO authenticated USING ((user_id = auth.uid()));


--
-- Name: user_salon_roles Users can view their own salon roles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their own salon roles" ON public.user_salon_roles FOR SELECT USING ((user_id = auth.uid()));


--
-- Name: supplier_team_users Users can view their own supplier membership; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their own supplier membership" ON public.supplier_team_users FOR SELECT USING ((user_id = auth.uid()));


--
-- Name: salon_goals Users can view their salon goals; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their salon goals" ON public.salon_goals FOR SELECT USING ((salon_id = public.get_user_salon_id(auth.uid())));


--
-- Name: users Users can view thread participants; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view thread participants" ON public.users FOR SELECT TO authenticated USING ((id IN ( SELECT public.get_thread_participant_user_ids(auth.uid()) AS get_thread_participant_user_ids)));


--
-- Name: message_threads Users can view threads they are part of; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view threads they are part of" ON public.message_threads FOR SELECT USING ((public.is_thread_participant(auth.uid(), id) OR public.has_role(auth.uid(), 'admin'::public.app_role)));


--
-- Name: announcement_notifications; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.announcement_notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: announcements; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;

--
-- Name: badges; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.badges ENABLE ROW LEVEL SECURITY;

--
-- Name: chains; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.chains ENABLE ROW LEVEL SECURITY;

--
-- Name: challenge_progress; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.challenge_progress ENABLE ROW LEVEL SECURITY;

--
-- Name: districts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.districts ENABLE ROW LEVEL SECURITY;

--
-- Name: historical_imports; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.historical_imports ENABLE ROW LEVEL SECURITY;

--
-- Name: hubspot_oauth_tokens; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.hubspot_oauth_tokens ENABLE ROW LEVEL SECURITY;

--
-- Name: hubspot_owner_district_mapping; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.hubspot_owner_district_mapping ENABLE ROW LEVEL SECURITY;

--
-- Name: invitations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.invitations ENABLE ROW LEVEL SECURITY;

--
-- Name: message_read_states; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.message_read_states ENABLE ROW LEVEL SECURITY;

--
-- Name: message_threads; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.message_threads ENABLE ROW LEVEL SECURITY;

--
-- Name: messages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

--
-- Name: monthly_challenges; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.monthly_challenges ENABLE ROW LEVEL SECURITY;

--
-- Name: role_change_audit; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.role_change_audit ENABLE ROW LEVEL SECURITY;

--
-- Name: salon_goals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.salon_goals ENABLE ROW LEVEL SECURITY;

--
-- Name: salon_suppliers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.salon_suppliers ENABLE ROW LEVEL SECURITY;

--
-- Name: salons; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.salons ENABLE ROW LEVEL SECURITY;

--
-- Name: supplier_team_users; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.supplier_team_users ENABLE ROW LEVEL SECURITY;

--
-- Name: suppliers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.suppliers ENABLE ROW LEVEL SECURITY;

--
-- Name: thread_participants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.thread_participants ENABLE ROW LEVEL SECURITY;

--
-- Name: user_badges; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.user_badges ENABLE ROW LEVEL SECURITY;

--
-- Name: user_chain_roles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.user_chain_roles ENABLE ROW LEVEL SECURITY;

--
-- Name: user_notification_preferences; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.user_notification_preferences ENABLE ROW LEVEL SECURITY;

--
-- Name: user_roles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

--
-- Name: user_salon_roles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.user_salon_roles ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

--
-- Name: weekly_kpi_inputs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.weekly_kpi_inputs ENABLE ROW LEVEL SECURITY;

--
-- Name: weekly_kpis; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.weekly_kpis ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--


