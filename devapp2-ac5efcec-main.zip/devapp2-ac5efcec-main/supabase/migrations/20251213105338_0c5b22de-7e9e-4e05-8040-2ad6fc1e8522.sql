-- Add ansatt_id column to ansatt_turnus table
ALTER TABLE public.ansatt_turnus 
ADD COLUMN ansatt_id uuid REFERENCES public.ansatte(id);

-- Update existing rows to link ansatt_id based on user_id
UPDATE public.ansatt_turnus t 
SET ansatt_id = a.id 
FROM public.ansatte a 
WHERE t.user_id = a.user_id AND t.user_id IS NOT NULL;

-- Create index for performance
CREATE INDEX idx_ansatt_turnus_ansatt_id ON public.ansatt_turnus(ansatt_id);