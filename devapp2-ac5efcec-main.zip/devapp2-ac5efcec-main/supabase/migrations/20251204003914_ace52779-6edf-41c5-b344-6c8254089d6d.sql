-- Add health insurance fields to users table
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS helseforsikring_status TEXT;
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS helseforsikring_oppstartsdato DATE;
ALTER TABLE public.users ADD COLUMN IF NOT EXISTS helseforsikring_oppsigelsesdato DATE;

-- Add health insurance count to salon_insurance
ALTER TABLE public.salon_insurance ADD COLUMN IF NOT EXISTS helse_antall_aktive INTEGER DEFAULT 0;