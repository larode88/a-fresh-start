-- Add personnummer column for temporary storage during health insurance enrollment
ALTER TABLE public.users 
ADD COLUMN IF NOT EXISTS helseforsikring_personnummer TEXT;

COMMENT ON COLUMN public.users.helseforsikring_personnummer 
IS 'Midlertidig lagring av personnummer til forsikring er bekreftet. Slettes automatisk når avtalenummer settes.';

-- Create trigger function to automatically clear personnummer when avtalenummer is set
CREATE OR REPLACE FUNCTION public.clear_personnummer_on_avtalenummer()
RETURNS TRIGGER AS $$
BEGIN
  -- If avtalenummer is set (goes from NULL/empty to a value), clear personnummer
  IF (OLD.helseforsikring_avtalenummer IS NULL OR OLD.helseforsikring_avtalenummer = '') 
     AND NEW.helseforsikring_avtalenummer IS NOT NULL 
     AND NEW.helseforsikring_avtalenummer != '' THEN
    NEW.helseforsikring_personnummer = NULL;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Create the trigger
DROP TRIGGER IF EXISTS clear_personnummer_on_avtalenummer_trigger ON public.users;
CREATE TRIGGER clear_personnummer_on_avtalenummer_trigger
  BEFORE UPDATE ON public.users
  FOR EACH ROW
  EXECUTE FUNCTION public.clear_personnummer_on_avtalenummer();

-- Create security definer function to read personnummer (admin only)
CREATE OR REPLACE FUNCTION public.get_helseforsikring_personnummer(p_user_id UUID)
RETURNS TEXT
LANGUAGE sql
STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT CASE 
    WHEN has_role(auth.uid(), 'admin'::app_role) THEN helseforsikring_personnummer
    ELSE NULL
  END
  FROM public.users
  WHERE id = p_user_id
$$;