-- Drop the existing overly permissive policy
DROP POLICY IF EXISTS "Anyone can view insurance documents" ON storage.objects;

-- Create new policy requiring authentication to view insurance documents
CREATE POLICY "Authenticated users can view insurance documents"
ON storage.objects
FOR SELECT
USING (
  bucket_id = 'insurance-documents'
  AND auth.uid() IS NOT NULL
);