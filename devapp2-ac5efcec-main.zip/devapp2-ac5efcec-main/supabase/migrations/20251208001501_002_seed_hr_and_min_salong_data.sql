-- Seed data for HR and Min Salong integration
-- Using fixed demo IDs for testing and validation

-- First, let's create a demo salon if it doesn't exist
INSERT INTO public.salons (id, name, org_number, address, city, postal_code, employee_count, created_at)
VALUES 
  ('550e8400-e29b-41d4-a716-446655440000', 'Demo Salong AS', '987654321', 'Storgata 1', 'Oslo', '0150', 5, NOW())
ON CONFLICT (id) DO NOTHING;

-- Create demo employees if they don't exist
INSERT INTO public.users (id, name, email, role, salon_id, aktiv, ansettelsesdato, stillingsprosent, timesats, fagbrev, frisorfunksjon, created_at)
VALUES 
  ('550e8400-e29b-41d4-a716-446655440001', 'Kari Nordmann', 'kari@demosalong.no', 'stylist', '550e8400-e29b-41d4-a716-446655440000', true, '2020-01-15', 100, 200, true, 'senior_frisor', NOW()),
  ('550e8400-e29b-41d4-a716-446655440002', 'Per Hansen', 'per@demosalong.no', 'stylist', '550e8400-e29b-41d4-a716-446655440000', true, '2021-06-01', 80, 180, true, 'frisor', NOW()),
  ('550e8400-e29b-41d4-a716-446655440003', 'Lise Olsen', 'lise@demosalong.no', 'apprentice', '550e8400-e29b-41d4-a716-446655440000', true, '2023-08-01', 100, 150, false, 'laerling', NOW()),
  ('550e8400-e29b-41d4-a716-446655440004', 'Ola Berg', 'ola@demosalong.no', 'daglig_leder', '550e8400-e29b-41d4-a716-446655440000', true, '2019-03-01', 100, 250, true, 'senior_frisor', NOW())
ON CONFLICT (id) DO NOTHING;

-- Create budget version for demo
INSERT INTO public.budsjett_versjoner (id, salon_id, aar, versjon_navn, versjon_nummer, er_aktiv, beskrivelse, created_at)
VALUES 
  ('550e8400-e29b-41d4-a716-446655440010', '550e8400-e29b-41d4-a716-446655440000', 2025, 'Hovedbudsjett 2025', 1, true, 'Demo budsjettversjon for testing', NOW())
ON CONFLICT (id) DO NOTHING;

-- Seed employee goals (ansatt_mal)
INSERT INTO public.ansatt_mal (user_id, salon_id, mal_type, mal_beskrivelse, mal_verdi, enhet, periode_start, periode_slutt, status, budsjett_id, created_at)
VALUES 
  ('550e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440000', 'omsetning', 'Månedlig omsetning mål', 50000, 'kr', '2025-01-01', '2025-12-31', 'aktiv', '550e8400-e29b-41d4-a716-446655440010', NOW()),
  ('550e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440000', 'varesalg', 'Øke varesalg andel', 15, 'prosent', '2025-01-01', '2025-06-30', 'aktiv', '550e8400-e29b-41d4-a716-446655440010', NOW()),
  ('550e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440000', 'kundetilfredshet', 'Kundetilfredshet score', 4.5, 'score', '2025-01-01', '2025-12-31', 'aktiv', NULL, NOW()),
  ('550e8400-e29b-41d4-a716-446655440003', '550e8400-e29b-41d4-a716-446655440000', 'produktivitet', 'Fullføre fagbrev', 1, 'antall', '2025-01-01', '2025-12-31', 'aktiv', NULL, NOW());

-- Seed employee conversations (ansatt_samtaler)
INSERT INTO public.ansatt_samtaler (user_id, salon_id, samtale_type, dato, varighet_minutter, samtale_leder, notater, status, created_at)
VALUES 
  ('550e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440000', 'medarbeidersamtale', '2024-12-01', 60, '550e8400-e29b-41d4-a716-446655440004', 'Diskutert årets mål og utvikling. Kari ønsker mer ansvar i opplæring av lærlinger.', 'gjennomfort', NOW()),
  ('550e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440000', 'utviklingssamtale', '2025-01-15', 45, '550e8400-e29b-41d4-a716-446655440004', 'Planlagt opplæring i fargeteknikker', 'planlagt', NOW()),
  ('550e8400-e29b-41d4-a716-446655440003', '550e8400-e29b-41d4-a716-446655440000', 'karrieresamtale', '2024-11-20', 30, '550e8400-e29b-41d4-a716-446655440004', 'Diskutert fagbrevplan og milepæler', 'gjennomfort', NOW());

-- Seed employee courses (ansatt_kurs)
INSERT INTO public.ansatt_kurs (user_id, kurs_navn, kurs_type, leverandor, startdato, sluttdato, varighet_timer, kostnad, status, created_at)
VALUES 
  ('550e8400-e29b-41d4-a716-446655440001', 'Avansert fargeteknikk', 'ekstern', 'Fagskolen Oslo', '2024-09-01', '2024-09-03', 24, 8500, 'gjennomfort', NOW()),
  ('550e8400-e29b-41d4-a716-446655440002', 'Balayage mesterkurs', 'ekstern', 'Hair Academy', '2025-02-10', '2025-02-12', 20, 12000, 'pameldt', NOW()),
  ('550e8400-e29b-41d4-a716-446655440003', 'Grunnleggende klipp teknikk', 'intern', 'Demo Salong AS', '2024-10-01', '2024-12-31', 40, 0, 'gjennomfort', NOW()),
  ('550e8400-e29b-41d4-a716-446655440001', 'Lederutvikling', 'online', 'Lederskolen', '2025-03-01', '2025-05-31', 60, 15000, 'planlagt', NOW());

-- Seed salary history (lonn_historikk)
INSERT INTO public.lonn_historikk (user_id, gyldig_fra, gyldig_til, timesats, fastlonn, stillingsprosent, begrunnelse, created_at)
VALUES 
  ('550e8400-e29b-41d4-a716-446655440001', '2020-01-15', '2021-12-31', 180, NULL, 100, 'Startlønn', NOW()),
  ('550e8400-e29b-41d4-a716-446655440001', '2022-01-01', '2023-12-31', 190, NULL, 100, 'Årlig justering', NOW()),
  ('550e8400-e29b-41d4-a716-446655440001', '2024-01-01', NULL, 200, NULL, 100, 'Oppjustering senior frisør', NOW()),
  ('550e8400-e29b-41d4-a716-446655440002', '2021-06-01', '2023-12-31', 170, NULL, 80, 'Startlønn deltid', NOW()),
  ('550e8400-e29b-41d4-a716-446655440002', '2024-01-01', NULL, 180, NULL, 80, 'Årlig justering', NOW()),
  ('550e8400-e29b-41d4-a716-446655440003', '2023-08-01', NULL, 150, NULL, 100, 'Lærling startlønn', NOW()),
  ('550e8400-e29b-41d4-a716-446655440004', '2019-03-01', '2023-12-31', 230, NULL, 100, 'Daglig leder startlønn', NOW()),
  ('550e8400-e29b-41d4-a716-446655440004', '2024-01-01', NULL, 250, NULL, 100, 'Årlig justering', NOW());

-- Seed vacation (ferie) data
INSERT INTO public.ferie (user_id, salon_id, aar, startdato, sluttdato, antall_dager, status, created_at)
VALUES 
  ('550e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440000', 2025, '2025-07-01', '2025-07-21', 15, 'planlagt', NOW()),
  ('550e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440000', 2025, '2025-06-15', '2025-06-28', 10, 'godkjent', NOW()),
  ('550e8400-e29b-41d4-a716-446655440003', '550e8400-e29b-41d4-a716-446655440000', 2025, '2025-07-08', '2025-07-21', 10, 'planlagt', NOW());

-- Seed shift schedule (turnus_skift) data
INSERT INTO public.turnus_skift (user_id, salon_id, dato, start_tid, slutt_tid, timer_planlagt, created_at)
VALUES 
  -- Week 1 Jan 2025
  ('550e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440000', '2025-01-06', '09:00', '17:00', 7.5, NOW()),
  ('550e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440000', '2025-01-07', '09:00', '17:00', 7.5, NOW()),
  ('550e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440000', '2025-01-08', '09:00', '16:00', 6.5, NOW()),
  ('550e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440000', '2025-01-09', '10:00', '18:00', 7.5, NOW()),
  ('550e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440000', '2025-01-10', '09:00', '15:00', 5.5, NOW()),
  ('550e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440000', '2025-01-06', '10:00', '16:00', 5.5, NOW()),
  ('550e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440000', '2025-01-08', '10:00', '16:00', 5.5, NOW()),
  ('550e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440000', '2025-01-10', '10:00', '16:00', 5.5, NOW());

-- Seed budget data (budsjett)
INSERT INTO public.budsjett (versjon_id, user_id, salon_id, dato, aar, maned, uke, dag, planlagte_timer, kundetimer, behandling_budsjett, vare_budsjett, totalt_budsjett, created_at)
VALUES 
  -- Week 1, Day 1
  ('550e8400-e29b-41d4-a716-446655440010', '550e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440000', '2025-01-06', 2025, 1, 2, 1, 7.5, 6.0, 4800, 720, 5520, NOW()),
  ('550e8400-e29b-41d4-a716-446655440010', '550e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440000', '2025-01-06', 2025, 1, 2, 1, 5.5, 4.5, 3600, 540, 4140, NOW()),
  -- Week 1, Day 2
  ('550e8400-e29b-41d4-a716-446655440010', '550e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440000', '2025-01-07', 2025, 1, 2, 2, 7.5, 6.0, 4800, 720, 5520, NOW());
