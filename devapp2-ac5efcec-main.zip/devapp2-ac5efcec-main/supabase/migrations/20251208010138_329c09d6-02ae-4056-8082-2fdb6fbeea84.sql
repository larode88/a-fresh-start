-- Create ansatt_mal table for employee goals
CREATE TABLE IF NOT EXISTS public.ansatt_mal (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  salon_id UUID NOT NULL REFERENCES public.salons(id) ON DELETE CASCADE,
  mal_type TEXT NOT NULL,
  beskrivelse TEXT,
  maalverdi NUMERIC NOT NULL DEFAULT 0,
  naavaerende_verdi NUMERIC DEFAULT 0,
  periode_start DATE NOT NULL,
  periode_slutt DATE NOT NULL,
  status TEXT DEFAULT 'aktiv',
  budsjett_id UUID REFERENCES public.budsjett_versjoner(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.ansatt_mal ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Admins can manage all ansatt_mal"
  ON public.ansatt_mal FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Salon owners can manage their ansatt_mal"
  ON public.ansatt_mal FOR ALL
  USING ((salon_id = get_user_salon_id(auth.uid())) AND is_salon_owner(auth.uid()))
  WITH CHECK ((salon_id = get_user_salon_id(auth.uid())) AND is_salon_owner(auth.uid()));

CREATE POLICY "Users can view their own ansatt_mal"
  ON public.ansatt_mal FOR SELECT
  USING (user_id = auth.uid());

-- Trigger for updated_at
CREATE TRIGGER update_ansatt_mal_updated_at
  BEFORE UPDATE ON public.ansatt_mal
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Index for performance
CREATE INDEX idx_ansatt_mal_user_id ON public.ansatt_mal(user_id);
CREATE INDEX idx_ansatt_mal_salon_id ON public.ansatt_mal(salon_id);

-- RPC Function: get_budget_summary
CREATE OR REPLACE FUNCTION public.get_budget_summary(
  p_salon_id UUID,
  p_versjon_id UUID,
  p_start_date DATE DEFAULT NULL,
  p_end_date DATE DEFAULT NULL
)
RETURNS TABLE (
  total_behandling NUMERIC,
  total_vare NUMERIC,
  total_budsjett NUMERIC,
  total_kundetimer NUMERIC,
  total_planlagte_timer NUMERIC,
  antall_dager INTEGER
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    COALESCE(SUM(behandling_budsjett), 0) AS total_behandling,
    COALESCE(SUM(vare_budsjett), 0) AS total_vare,
    COALESCE(SUM(totalt_budsjett), 0) AS total_budsjett,
    COALESCE(SUM(kundetimer), 0) AS total_kundetimer,
    COALESCE(SUM(planlagte_timer), 0) AS total_planlagte_timer,
    COUNT(*)::INTEGER AS antall_dager
  FROM budsjett
  WHERE salon_id = p_salon_id
    AND versjon_id = p_versjon_id
    AND (p_start_date IS NULL OR dato >= p_start_date)
    AND (p_end_date IS NULL OR dato <= p_end_date)
$$;

-- RPC Function: get_budget_vs_actual
CREATE OR REPLACE FUNCTION public.get_budget_vs_actual(
  p_salon_id UUID,
  p_versjon_id UUID,
  p_month INTEGER,
  p_year INTEGER
)
RETURNS TABLE (
  user_id UUID,
  user_name TEXT,
  budsjett_behandling NUMERIC,
  budsjett_vare NUMERIC,
  budsjett_total NUMERIC,
  faktisk_behandling NUMERIC,
  faktisk_vare NUMERIC,
  faktisk_total NUMERIC,
  avvik_behandling NUMERIC,
  avvik_vare NUMERIC,
  avvik_total NUMERIC,
  oppnaaelse_prosent NUMERIC
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    b.user_id,
    u.name AS user_name,
    COALESCE(SUM(b.behandling_budsjett), 0) AS budsjett_behandling,
    COALESCE(SUM(b.vare_budsjett), 0) AS budsjett_vare,
    COALESCE(SUM(b.totalt_budsjett), 0) AS budsjett_total,
    COALESCE(SUM(h.behandling_kr), 0) AS faktisk_behandling,
    COALESCE(SUM(h.vare_kr), 0) AS faktisk_vare,
    COALESCE(SUM(h.total_kr), 0) AS faktisk_total,
    COALESCE(SUM(h.behandling_kr), 0) - COALESCE(SUM(b.behandling_budsjett), 0) AS avvik_behandling,
    COALESCE(SUM(h.vare_kr), 0) - COALESCE(SUM(b.vare_budsjett), 0) AS avvik_vare,
    COALESCE(SUM(h.total_kr), 0) - COALESCE(SUM(b.totalt_budsjett), 0) AS avvik_total,
    CASE 
      WHEN COALESCE(SUM(b.totalt_budsjett), 0) > 0 
      THEN ROUND((COALESCE(SUM(h.total_kr), 0) / SUM(b.totalt_budsjett)) * 100, 1)
      ELSE 0 
    END AS oppnaaelse_prosent
  FROM budsjett b
  LEFT JOIN users u ON b.user_id = u.id
  LEFT JOIN historiske_tall h ON b.user_id = h.user_id 
    AND b.dato = h.dato
    AND h.salon_id = p_salon_id
  WHERE b.salon_id = p_salon_id
    AND b.versjon_id = p_versjon_id
    AND b.maned = p_month
    AND b.aar = p_year
  GROUP BY b.user_id, u.name
$$;

-- RPC Function: get_goal_progress
CREATE OR REPLACE FUNCTION public.get_goal_progress(
  p_user_id UUID,
  p_active_only BOOLEAN DEFAULT true
)
RETURNS TABLE (
  goal_id UUID,
  goal_type TEXT,
  goal_description TEXT,
  target_value NUMERIC,
  current_value NUMERIC,
  progress_percent NUMERIC,
  status TEXT,
  periode_start DATE,
  periode_slutt DATE
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    id AS goal_id,
    mal_type AS goal_type,
    beskrivelse AS goal_description,
    maalverdi AS target_value,
    COALESCE(naavaerende_verdi, 0) AS current_value,
    CASE 
      WHEN maalverdi > 0 THEN ROUND((COALESCE(naavaerende_verdi, 0) / maalverdi) * 100, 1)
      ELSE 0 
    END AS progress_percent,
    status,
    periode_start,
    periode_slutt
  FROM ansatt_mal
  WHERE user_id = p_user_id
    AND (NOT p_active_only OR status = 'aktiv')
  ORDER BY periode_start DESC
$$;

-- RPC Function: get_shift_hours_summary
CREATE OR REPLACE FUNCTION public.get_shift_hours_summary(
  p_user_id UUID,
  p_start_date DATE,
  p_end_date DATE
)
RETURNS TABLE (
  total_shifts INTEGER,
  total_planned_hours NUMERIC,
  avg_hours_per_shift NUMERIC,
  days_worked INTEGER
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    COUNT(*)::INTEGER AS total_shifts,
    COALESCE(SUM(timer_planlagt), 0) AS total_planned_hours,
    CASE 
      WHEN COUNT(*) > 0 THEN ROUND(COALESCE(SUM(timer_planlagt), 0) / COUNT(*), 2)
      ELSE 0 
    END AS avg_hours_per_shift,
    COUNT(DISTINCT dato)::INTEGER AS days_worked
  FROM turnus_skift
  WHERE user_id = p_user_id
    AND dato >= p_start_date
    AND dato <= p_end_date
$$;