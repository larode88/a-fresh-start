-- Create table for manual budgets (employees without schedule)
CREATE TABLE public.budsjett_manuelt (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  versjon_id UUID NOT NULL REFERENCES public.budsjett_versjoner(id) ON DELETE CASCADE,
  salon_id UUID NOT NULL REFERENCES public.salons(id) ON DELETE CASCADE,
  ansatt_id UUID NOT NULL REFERENCES public.ansatte(id) ON DELETE CASCADE,
  maned INTEGER NOT NULL CHECK (maned >= 1 AND maned <= 12),
  vare_budsjett NUMERIC DEFAULT 0,
  beskrivelse TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(versjon_id, ansatt_id, maned)
);

-- Enable RLS
ALTER TABLE public.budsjett_manuelt ENABLE ROW LEVEL SECURITY;

-- RLS policies matching existing budget tables
CREATE POLICY "Admin full access to manual budgets"
ON public.budsjett_manuelt
FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Salon leaders can manage their salon manual budgets"
ON public.budsjett_manuelt
FOR ALL
USING (is_salong_leder(auth.uid(), salon_id));

CREATE POLICY "District managers can view their district manual budgets"
ON public.budsjett_manuelt
FOR SELECT
USING (
  salon_id IN (SELECT get_district_salon_ids(auth.uid()))
);

-- Trigger for updated_at
CREATE TRIGGER update_budsjett_manuelt_updated_at
BEFORE UPDATE ON public.budsjett_manuelt
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Add index for common queries
CREATE INDEX idx_budsjett_manuelt_versjon ON public.budsjett_manuelt(versjon_id);
CREATE INDEX idx_budsjett_manuelt_salon ON public.budsjett_manuelt(salon_id);
CREATE INDEX idx_budsjett_manuelt_ansatt ON public.budsjett_manuelt(ansatt_id);