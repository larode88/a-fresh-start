-- Fase 6: HR-modul (Ferie og Fravær)

-- 6.1 Ferie-tabell
CREATE TABLE public.ferie (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  salon_id uuid NOT NULL REFERENCES public.salons(id) ON DELETE CASCADE,
  aar integer NOT NULL,
  startdato date NOT NULL,
  sluttdato date NOT NULL,
  antall_dager integer,
  timer numeric(6,2),
  status ferie_status DEFAULT 'planlagt',
  kommentar text,
  godkjent_av uuid REFERENCES public.users(id),
  godkjent_dato timestamp with time zone,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

CREATE INDEX idx_ferie_user ON public.ferie(user_id);
CREATE INDEX idx_ferie_salon ON public.ferie(salon_id);
CREATE INDEX idx_ferie_aar ON public.ferie(aar);
CREATE INDEX idx_ferie_datoer ON public.ferie(startdato, sluttdato);

-- 6.2 Ferie overføring (fra år til år)
CREATE TABLE public.ferie_overforing (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  fra_aar integer NOT NULL,
  til_aar integer NOT NULL,
  timer numeric(6,2) NOT NULL,
  godkjent_av uuid REFERENCES public.users(id),
  godkjent_dato timestamp with time zone,
  kommentar text,
  created_at timestamp with time zone DEFAULT now()
);

-- 6.3 Fravær-tabell
CREATE TABLE public.fravaer (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  salon_id uuid NOT NULL REFERENCES public.salons(id) ON DELETE CASCADE,
  fravaerstype fravaerstype NOT NULL,
  startdato date NOT NULL,
  sluttdato date NOT NULL,
  timer numeric(6,2),
  prosent numeric(5,2) DEFAULT 100, -- For gradert fravær
  status text DEFAULT 'aktiv' CHECK (status IN ('aktiv', 'avsluttet', 'kansellert')),
  dokumentasjon_url text,
  kommentar text,
  registrert_av uuid REFERENCES public.users(id),
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

CREATE INDEX idx_fravaer_user ON public.fravaer(user_id);
CREATE INDEX idx_fravaer_salon ON public.fravaer(salon_id);
CREATE INDEX idx_fravaer_type ON public.fravaer(fravaerstype);
CREATE INDEX idx_fravaer_datoer ON public.fravaer(startdato, sluttdato);

-- 6.4 Ansatt dokumenter
CREATE TABLE public.ansatt_dokumenter (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  dokument_type text NOT NULL,
  dokument_navn text NOT NULL,
  dokument_url text NOT NULL,
  utloper_dato date,
  opprettet_av uuid REFERENCES public.users(id),
  created_at timestamp with time zone DEFAULT now()
);

CREATE INDEX idx_ansatt_dokumenter_user ON public.ansatt_dokumenter(user_id);

-- 6.5 Ansatt sertifiseringer
CREATE TABLE public.ansatt_sertifiseringer (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  navn text NOT NULL,
  type text,
  utsteder text,
  utstedt_dato date,
  utloper_dato date,
  sertifikat_url text,
  created_at timestamp with time zone DEFAULT now()
);

CREATE INDEX idx_ansatt_sertifiseringer_user ON public.ansatt_sertifiseringer(user_id);

-- 6.6 Ansatt godtgjørelser (tillegg til lønn)
CREATE TABLE public.ansatt_godtgjorelser (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  type text NOT NULL,
  belop numeric(10,2) NOT NULL,
  frekvens text DEFAULT 'maaned' CHECK (frekvens IN ('time', 'dag', 'uke', 'maaned', 'aar', 'engangs')),
  gyldig_fra date NOT NULL DEFAULT CURRENT_DATE,
  gyldig_til date,
  beskrivelse text,
  created_at timestamp with time zone DEFAULT now()
);

-- 6.7 Lønn historikk
CREATE TABLE public.lonn_historikk (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  gyldig_fra date NOT NULL,
  gyldig_til date,
  fastlonn numeric(10,2),
  timesats numeric(10,2),
  arsak text,
  endret_av uuid REFERENCES public.users(id),
  created_at timestamp with time zone DEFAULT now()
);

CREATE INDEX idx_lonn_historikk_user ON public.lonn_historikk(user_id);

-- 6.8 Enable RLS
ALTER TABLE public.ferie ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ferie_overforing ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fravaer ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ansatt_dokumenter ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ansatt_sertifiseringer ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ansatt_godtgjorelser ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lonn_historikk ENABLE ROW LEVEL SECURITY;

-- 6.9 RLS Policies - ferie
CREATE POLICY "Users can view their own ferie" ON public.ferie FOR SELECT USING (user_id = auth.uid());
CREATE POLICY "Users can create their own ferie" ON public.ferie FOR INSERT WITH CHECK (user_id = auth.uid());
CREATE POLICY "Admins can manage all ferie" ON public.ferie FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Salon owners can manage their employees ferie" ON public.ferie FOR ALL
USING (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()))
WITH CHECK (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()));

-- 6.10 RLS Policies - ferie_overforing
CREATE POLICY "Users can view their own ferie_overforing" ON public.ferie_overforing FOR SELECT USING (user_id = auth.uid());
CREATE POLICY "Admins can manage all ferie_overforing" ON public.ferie_overforing FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- 6.11 RLS Policies - fravaer
CREATE POLICY "Users can view their own fravaer" ON public.fravaer FOR SELECT USING (user_id = auth.uid());
CREATE POLICY "Users can create their own fravaer" ON public.fravaer FOR INSERT WITH CHECK (user_id = auth.uid());
CREATE POLICY "Admins can manage all fravaer" ON public.fravaer FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Salon owners can manage their employees fravaer" ON public.fravaer FOR ALL
USING (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()))
WITH CHECK (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()));

-- 6.12 RLS Policies - ansatt_dokumenter
CREATE POLICY "Users can view their own dokumenter" ON public.ansatt_dokumenter FOR SELECT USING (user_id = auth.uid());
CREATE POLICY "Admins can manage all dokumenter" ON public.ansatt_dokumenter FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Salon owners can view their employees dokumenter" ON public.ansatt_dokumenter FOR SELECT
USING (user_id IN (SELECT id FROM users WHERE salon_id = get_user_salon_id(auth.uid())) AND is_salon_owner(auth.uid()));

-- 6.13 RLS Policies - ansatt_sertifiseringer
CREATE POLICY "Users can manage their own sertifiseringer" ON public.ansatt_sertifiseringer FOR ALL
USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE POLICY "Admins can manage all sertifiseringer" ON public.ansatt_sertifiseringer FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Salon owners can view their employees sertifiseringer" ON public.ansatt_sertifiseringer FOR SELECT
USING (user_id IN (SELECT id FROM users WHERE salon_id = get_user_salon_id(auth.uid())) AND is_salon_owner(auth.uid()));

-- 6.14 RLS Policies - ansatt_godtgjorelser
CREATE POLICY "Users can view their own godtgjorelser" ON public.ansatt_godtgjorelser FOR SELECT USING (user_id = auth.uid());
CREATE POLICY "Admins can manage all godtgjorelser" ON public.ansatt_godtgjorelser FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Salon owners can manage their employees godtgjorelser" ON public.ansatt_godtgjorelser FOR ALL
USING (user_id IN (SELECT id FROM users WHERE salon_id = get_user_salon_id(auth.uid())) AND is_salon_owner(auth.uid()))
WITH CHECK (user_id IN (SELECT id FROM users WHERE salon_id = get_user_salon_id(auth.uid())) AND is_salon_owner(auth.uid()));

-- 6.15 RLS Policies - lonn_historikk
CREATE POLICY "Users can view their own lonn_historikk" ON public.lonn_historikk FOR SELECT USING (user_id = auth.uid());
CREATE POLICY "Admins can manage all lonn_historikk" ON public.lonn_historikk FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- 6.16 Triggers
CREATE TRIGGER update_ferie_updated_at BEFORE UPDATE ON public.ferie FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_fravaer_updated_at BEFORE UPDATE ON public.fravaer FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 6.17 Hjelpefunksjon: Beregn ferietimer basert på stillingsprosent
CREATE OR REPLACE FUNCTION public.beregn_ferietimer(p_user_id uuid, p_startdato date, p_sluttdato date)
RETURNS numeric
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT (
    (SELECT COUNT(*) FROM kalender 
     WHERE dato BETWEEN p_startdato AND p_sluttdato AND er_arbeidsdag = true)
    * 7.5 
    * (SELECT COALESCE(stillingsprosent, 100) / 100 FROM users WHERE id = p_user_id)
  )::numeric(6,2)
$$;

-- 6.18 Hjelpefunksjon: Sjekk egenmelding-begrensninger
CREATE OR REPLACE FUNCTION public.valider_egenmelding(p_user_id uuid, p_startdato date, p_sluttdato date)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_dager integer;
  v_brukt_siste_12_mnd integer;
BEGIN
  -- Sjekk at perioden ikke overstiger 3 sammenhengende dager
  v_dager := p_sluttdato - p_startdato + 1;
  IF v_dager > 3 THEN
    RETURN false;
  END IF;
  
  -- Tell antall egenmeldingsdager siste 12 måneder
  SELECT COALESCE(SUM(sluttdato - startdato + 1), 0) INTO v_brukt_siste_12_mnd
  FROM fravaer
  WHERE user_id = p_user_id 
    AND fravaerstype = 'egenmelding'
    AND startdato >= (CURRENT_DATE - interval '12 months')
    AND status = 'aktiv';
  
  -- Maks 24 dager per 12 måneder (8 perioder à 3 dager)
  IF (v_brukt_siste_12_mnd + v_dager) > 24 THEN
    RETURN false;
  END IF;
  
  RETURN true;
END;
$$;