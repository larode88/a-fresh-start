-- Drop the view first since it depends on the status column
DROP VIEW IF EXISTS ansatte_utvidet;

-- Update any employees with status 'Prøvetid' to 'Aktiv'
UPDATE ansatte SET status = 'Aktiv' WHERE status = 'Prøvetid';

-- Create new enum without 'Prøvetid'
CREATE TYPE ansatt_status_new AS ENUM ('Aktiv', 'Permisjon', 'Arkivert');

-- Update the column to use the new enum
ALTER TABLE ansatte 
  ALTER COLUMN status DROP DEFAULT,
  ALTER COLUMN status TYPE ansatt_status_new USING status::text::ansatt_status_new,
  ALTER COLUMN status SET DEFAULT 'Aktiv'::ansatt_status_new;

-- Drop old enum and rename new one
DROP TYPE ansatt_status;
ALTER TYPE ansatt_status_new RENAME TO ansatt_status;

-- Recreate the view with the new enum type
CREATE VIEW ansatte_utvidet AS
SELECT 
  a.*,
  s.name as salong_navn,
  CASE 
    WHEN a.fodselsdato IS NOT NULL 
    THEN EXTRACT(YEAR FROM age(CURRENT_DATE, a.fodselsdato))::integer 
    ELSE NULL 
  END as alder,
  CASE 
    WHEN a.fagbrev_dato IS NOT NULL THEN 
      ROUND(EXTRACT(EPOCH FROM age(CURRENT_DATE, a.fagbrev_dato)) / 31536000, 1)
    WHEN a.ansatt_dato IS NOT NULL THEN 
      ROUND(EXTRACT(EPOCH FROM age(CURRENT_DATE, a.ansatt_dato)) / 31536000, 1)
    ELSE NULL 
  END as ansiennitet_aar,
  CASE 
    WHEN a.ansatt_dato IS NOT NULL THEN 
      EXTRACT(MONTH FROM age(CURRENT_DATE, a.ansatt_dato))::integer 
    ELSE NULL 
  END as ansiennitet_maneder,
  TO_CHAR(a.fodselsdato, 'MM-DD') as bursdag_md,
  CONCAT(a.fornavn, ' ', COALESCE(a.etternavn, '')) as navn,
  CASE 
    WHEN a.frisorfunksjon IS NOT NULL AND a.lederstilling IS NOT NULL THEN
      CONCAT(
        CASE a.frisorfunksjon
          WHEN 'frisor' THEN 'Frisør'
          WHEN 'senior_frisor' THEN 'Seniorfrisør'
          WHEN 'laerling' THEN 'Lærling'
          ELSE a.frisorfunksjon::text
        END,
        ' / ',
        CASE a.lederstilling
          WHEN 'daglig_leder' THEN 'Daglig leder'
          WHEN 'avdelingsleder' THEN 'Avdelingsleder'
          WHEN 'styreleder' THEN 'Styreleder'
          ELSE a.lederstilling::text
        END
      )
    WHEN a.frisorfunksjon IS NOT NULL THEN
      CASE a.frisorfunksjon
        WHEN 'frisor' THEN 'Frisør'
        WHEN 'senior_frisor' THEN 'Seniorfrisør'
        WHEN 'laerling' THEN 'Lærling'
        ELSE a.frisorfunksjon::text
      END
    WHEN a.lederstilling IS NOT NULL THEN
      CASE a.lederstilling
        WHEN 'daglig_leder' THEN 'Daglig leder'
        WHEN 'avdelingsleder' THEN 'Avdelingsleder'
        WHEN 'styreleder' THEN 'Styreleder'
        ELSE a.lederstilling::text
      END
    ELSE NULL
  END as rolle_display,
  CASE a.status
    WHEN 'Aktiv' THEN 'Aktiv'
    WHEN 'Permisjon' THEN 'Permisjon'
    WHEN 'Arkivert' THEN 'Arkivert'
    ELSE a.status::text
  END as status_display
FROM ansatte a
LEFT JOIN salons s ON a.salong_id = s.id;