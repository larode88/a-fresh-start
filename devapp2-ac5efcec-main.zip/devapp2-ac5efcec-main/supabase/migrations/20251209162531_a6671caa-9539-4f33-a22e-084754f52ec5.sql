-- Add financial and employee data columns to prospekter table
ALTER TABLE public.prospekter 
ADD COLUMN IF NOT EXISTS antall_ansatte integer,
ADD COLUMN IF NOT EXISTS sum_driftsinntekter numeric,
ADD COLUMN IF NOT EXISTS salgsinntekter numeric,
ADD COLUMN IF NOT EXISTS loennskostnad numeric,
ADD COLUMN IF NOT EXISTS driftsresultat numeric,
ADD COLUMN IF NOT EXISTS regnskapsaar integer;