-- Add tier_id column to insurance_product_documents for tier-specific documents
ALTER TABLE public.insurance_product_documents
ADD COLUMN tier_id uuid REFERENCES public.insurance_product_tiers(id) ON DELETE CASCADE;

-- Add index for faster queries
CREATE INDEX idx_insurance_product_documents_tier_id ON public.insurance_product_documents(tier_id);

-- Add comment for clarity
COMMENT ON COLUMN public.insurance_product_documents.tier_id IS 'Optional tier reference. If null, document applies to entire product. If set, document is tier-specific.';