-- Add health insurance company-level fields to salon_insurance
ALTER TABLE public.salon_insurance 
ADD COLUMN IF NOT EXISTS helseforsikring_status text,
ADD COLUMN IF NOT EXISTS helseforsikring_avtalenummer text,
ADD COLUMN IF NOT EXISTS helseforsikring_oppstartsdato date,
ADD COLUMN IF NOT EXISTS helseforsikring_premie numeric(10,2),
ADD COLUMN IF NOT EXISTS helseforsikring_oppsigelsesdato date;

-- Add comment for clarity
COMMENT ON COLUMN public.salon_insurance.helseforsikring_status IS 'Status: Aktiv, Avsluttet, Ventende, etc.';
COMMENT ON COLUMN public.salon_insurance.helseforsikring_avtalenummer IS 'Avtalenummer for helseforsikring';
COMMENT ON COLUMN public.salon_insurance.helseforsikring_oppstartsdato IS 'Oppstartsdato for helseforsikring';
COMMENT ON COLUMN public.salon_insurance.helseforsikring_premie IS 'Total premie for helseforsikring';
COMMENT ON COLUMN public.salon_insurance.helseforsikring_oppsigelsesdato IS 'Oppsigelsesdato for helseforsikring';