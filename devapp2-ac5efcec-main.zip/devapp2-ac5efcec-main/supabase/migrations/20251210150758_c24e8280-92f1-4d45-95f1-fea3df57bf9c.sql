-- Create SECURITY DEFINER function for inserting user_roles during onboarding
-- This bypasses RLS since the function runs with owner privileges
CREATE OR REPLACE FUNCTION public.create_user_role_for_onboarding(
  p_user_id uuid,
  p_role app_role
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Delete any existing role for this user first, then insert new one
  DELETE FROM public.user_roles WHERE user_id = p_user_id;
  INSERT INTO public.user_roles (user_id, role) VALUES (p_user_id, p_role);
END;
$$;

-- Grant execute to authenticated users
GRANT EXECUTE ON FUNCTION public.create_user_role_for_onboarding(uuid, app_role) TO authenticated;

-- Fix existing user ns@sc.no - add missing user_roles entry
DELETE FROM public.user_roles WHERE user_id = '0787f247-f559-4009-b0c1-0cbad534a7a2';
INSERT INTO public.user_roles (user_id, role)
VALUES ('0787f247-f559-4009-b0c1-0cbad534a7a2', 'salon_owner');

-- Fix whitespace in first_name for ns@sc.no
UPDATE public.users
SET first_name = TRIM(first_name),
    last_name = TRIM(last_name),
    name = TRIM(first_name) || ' ' || TRIM(last_name)
WHERE id = '0787f247-f559-4009-b0c1-0cbad534a7a2';