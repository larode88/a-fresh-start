-- Add Auth0 external user ID field for SSO linking
ALTER TABLE public.users 
ADD COLUMN IF NOT EXISTS external_auth_id TEXT UNIQUE;

-- Add index for fast lookup
CREATE INDEX IF NOT EXISTS idx_users_external_auth_id ON public.users(external_auth_id);

-- Add last login tracking
ALTER TABLE public.users
ADD COLUMN IF NOT EXISTS last_login_at TIMESTAMP WITH TIME ZONE;