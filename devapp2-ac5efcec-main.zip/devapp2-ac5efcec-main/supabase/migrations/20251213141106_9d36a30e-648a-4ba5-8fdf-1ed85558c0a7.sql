-- 1. Legg til ansatt_id kolonne (mangler helt)
ALTER TABLE public.fravaer 
ADD COLUMN ansatt_id uuid REFERENCES public.ansatte(id);

-- 2. Gjør user_id nullable (er nå NOT NULL, må endres)
ALTER TABLE public.fravaer 
ALTER COLUMN user_id DROP NOT NULL;

-- 3. Oppdater eksisterende rader med ansatt_id basert på user_id
UPDATE public.fravaer f
SET ansatt_id = a.id
FROM public.ansatte a
WHERE f.user_id = a.user_id AND f.ansatt_id IS NULL;

-- 4. Legg til indeks for bedre ytelse
CREATE INDEX IF NOT EXISTS idx_fravaer_ansatt_id ON public.fravaer(ansatt_id);