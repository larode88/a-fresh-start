
-- FASE 1.2: HJELPEFUNKSJONER FOR TURNUSBEREGNING (forenklet)

-- 1. Funksjon: Beregn uke-type basert på dato og rotasjonstype
CREATE OR REPLACE FUNCTION public.beregn_uke_type(
  p_dato DATE,
  p_gyldig_fra DATE,
  p_turnus_type TEXT
)
RETURNS TEXT
LANGUAGE plpgsql
IMMUTABLE
SET search_path TO 'public'
AS $function$
DECLARE
  v_iso_week INTEGER;
  v_uker_siden_start INTEGER;
  v_rotasjon_index INTEGER;
BEGIN
  IF p_turnus_type = 'touke' THEN
    v_iso_week := EXTRACT(WEEK FROM p_dato)::INTEGER;
    IF v_iso_week % 2 = 0 THEN RETURN 'oddetall'; ELSE RETURN 'partall'; END IF;
  ELSIF p_turnus_type = 'treuke' THEN
    v_uker_siden_start := FLOOR((p_dato - p_gyldig_fra) / 7)::INTEGER;
    v_rotasjon_index := v_uker_siden_start % 3;
    RETURN CASE v_rotasjon_index WHEN 0 THEN 'uke1' WHEN 1 THEN 'uke2' ELSE 'uke3' END;
  ELSIF p_turnus_type = 'fireuke' THEN
    v_uker_siden_start := FLOOR((p_dato - p_gyldig_fra) / 7)::INTEGER;
    v_rotasjon_index := v_uker_siden_start % 4;
    RETURN CASE v_rotasjon_index WHEN 0 THEN 'uke1' WHEN 1 THEN 'uke2' WHEN 2 THEN 'uke3' ELSE 'uke4' END;
  ELSE
    RETURN 'partall';
  END IF;
END;
$function$;

-- 2. Funksjon: Sjekk om dato er helligdag (bruker er_helligdag kolonne)
CREATE OR REPLACE FUNCTION public.er_helligdag_dato(p_dato DATE)
RETURNS BOOLEAN
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $function$
  SELECT COALESCE(
    (SELECT er_helligdag FROM kalender WHERE dato = p_dato),
    EXTRACT(ISODOW FROM p_dato) = 7
  );
$function$;

-- 3. Funksjon: Hent bemanning for time
CREATE OR REPLACE FUNCTION public.hent_bemanning_for_time(
  p_salon_id UUID,
  p_dato DATE,
  p_time INTEGER
)
RETURNS INTEGER
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  v_count INTEGER;
BEGIN
  SELECT COUNT(*) INTO v_count
  FROM ansatt_turnus at
  WHERE at.salon_id = p_salon_id
    AND at.gyldig_fra = p_dato
    AND at.fridag = false
    AND EXTRACT(HOUR FROM at.start_tid) <= p_time
    AND EXTRACT(HOUR FROM at.slutt_tid) > p_time;
  RETURN COALESCE(v_count, 0);
END;
$function$;
