-- Table for sick leave follow-up tracking
CREATE TABLE public.sykefravear_oppfolging (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  fravaer_id UUID NOT NULL REFERENCES public.fravaer(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.users(id),
  salon_id UUID NOT NULL REFERENCES public.salons(id),
  oppfolging_type TEXT NOT NULL CHECK (oppfolging_type IN ('telefonsamtale', 'samtale', 'oppfolgingsplan', 'dialogmote', 'tilrettelegging', 'annet')),
  dato DATE NOT NULL DEFAULT CURRENT_DATE,
  notater TEXT,
  neste_oppfolging DATE,
  utfort_av UUID REFERENCES public.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.sykefravear_oppfolging ENABLE ROW LEVEL SECURITY;

-- RLS policies
CREATE POLICY "Admins can manage all oppfolging"
  ON public.sykefravear_oppfolging FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Salon owners can manage their salon oppfolging"
  ON public.sykefravear_oppfolging FOR ALL
  USING ((salon_id = get_user_salon_id(auth.uid())) AND is_salon_owner(auth.uid()))
  WITH CHECK ((salon_id = get_user_salon_id(auth.uid())) AND is_salon_owner(auth.uid()));

CREATE POLICY "Users can view their own oppfolging"
  ON public.sykefravear_oppfolging FOR SELECT
  USING (user_id = auth.uid());

-- Trigger for updated_at
CREATE TRIGGER update_sykefravear_oppfolging_updated_at
  BEFORE UPDATE ON public.sykefravear_oppfolging
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Index for performance
CREATE INDEX idx_sykefravear_oppfolging_fravaer ON public.sykefravear_oppfolging(fravaer_id);
CREATE INDEX idx_sykefravear_oppfolging_user ON public.sykefravear_oppfolging(user_id);
CREATE INDEX idx_sykefravear_oppfolging_neste ON public.sykefravear_oppfolging(neste_oppfolging) WHERE neste_oppfolging IS NOT NULL;