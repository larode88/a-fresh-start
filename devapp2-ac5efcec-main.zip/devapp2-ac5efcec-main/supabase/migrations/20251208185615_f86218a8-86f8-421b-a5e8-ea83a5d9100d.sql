-- =====================================================
-- PULSUNDERSØKELSE OPTIMALISERING - FASE 1: Database
-- =====================================================

-- 1. Opprett enum for tema-kategorier
CREATE TYPE puls_tema AS ENUM (
  'trivsel',
  'arbeidsbelastning',
  'psykologisk_trygghet',
  'ledelse',
  'hms_sikkerhet',
  'utvikling'
);

-- 2. Opprett enum for spørsmålstype
CREATE TYPE puls_sporsmal_type AS ENUM (
  'skala',
  'fritekst'
);

-- 3. Opprett enum for pulstype
CREATE TYPE puls_type AS ENUM (
  'hurtigpuls',
  'dyppuls'
);

-- 4. Spørsmålsbank-tabell
CREATE TABLE puls_sporsmal_bank (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tema puls_tema NOT NULL,
  sporsmal TEXT NOT NULL,
  sporsmal_type puls_sporsmal_type NOT NULL DEFAULT 'skala',
  moduler puls_type[] NOT NULL DEFAULT ARRAY['hurtigpuls'::puls_type, 'dyppuls'::puls_type],
  aktiv BOOLEAN DEFAULT true,
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- 5. Legg til nye felt i pulsundersokelser for rotasjon
ALTER TABLE pulsundersokelser 
  ADD COLUMN IF NOT EXISTS bruk_rotasjon BOOLEAN DEFAULT false,
  ADD COLUMN IF NOT EXISTS puls_type puls_type DEFAULT 'hurtigpuls',
  ADD COLUMN IF NOT EXISTS siste_sporsmal_ids UUID[] DEFAULT '{}';

-- 6. Legg til nye felt i pulsundersokelse_svar for tema-tagging
ALTER TABLE pulsundersokelse_svar
  ADD COLUMN IF NOT EXISTS tema puls_tema,
  ADD COLUMN IF NOT EXISTS sporsmal_id UUID REFERENCES puls_sporsmal_bank(id),
  ADD COLUMN IF NOT EXISTS puls_type puls_type DEFAULT 'hurtigpuls',
  ADD COLUMN IF NOT EXISTS risiko_flagg BOOLEAN DEFAULT false;

-- 7. Opprett risikologg-tabell
CREATE TABLE puls_risikologg (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  salon_id UUID NOT NULL REFERENCES salons(id) ON DELETE CASCADE,
  svar_id UUID REFERENCES pulsundersokelse_svar(id) ON DELETE CASCADE,
  user_id UUID REFERENCES auth.users(id),
  tema puls_tema NOT NULL,
  sporsmal_id UUID REFERENCES puls_sporsmal_bank(id),
  score INTEGER NOT NULL,
  foreslatte_tiltak TEXT[],
  status TEXT DEFAULT 'ny' CHECK (status IN ('ny', 'under_behandling', 'lukket')),
  behandlet_av UUID REFERENCES auth.users(id),
  behandlet_dato TIMESTAMP WITH TIME ZONE,
  kommentar TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- 8. Spørsmålsrotasjon-logg (hvilke spørsmål ble brukt i hvilken periode)
CREATE TABLE puls_sporsmal_rotasjon (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  undersokelse_id UUID NOT NULL REFERENCES pulsundersokelser(id) ON DELETE CASCADE,
  sporsmal_id UUID NOT NULL REFERENCES puls_sporsmal_bank(id),
  periode_start DATE NOT NULL,
  periode_slutt DATE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- 9. Enable RLS
ALTER TABLE puls_sporsmal_bank ENABLE ROW LEVEL SECURITY;
ALTER TABLE puls_risikologg ENABLE ROW LEVEL SECURITY;
ALTER TABLE puls_sporsmal_rotasjon ENABLE ROW LEVEL SECURITY;

-- 10. RLS Policies for puls_sporsmal_bank
CREATE POLICY "Admins can manage sporsmal_bank"
  ON puls_sporsmal_bank FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Authenticated users can view active sporsmal"
  ON puls_sporsmal_bank FOR SELECT
  USING (aktiv = true AND auth.uid() IS NOT NULL);

-- 11. RLS Policies for puls_risikologg
CREATE POLICY "Admins can manage risikologg"
  ON puls_risikologg FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Salon leaders can view their salon risikologg"
  ON puls_risikologg FOR SELECT
  USING (
    salon_id = get_user_salon_id(auth.uid()) 
    AND is_salon_owner(auth.uid())
  );

CREATE POLICY "Salon leaders can update their salon risikologg"
  ON puls_risikologg FOR UPDATE
  USING (
    salon_id = get_user_salon_id(auth.uid()) 
    AND is_salon_owner(auth.uid())
  );

-- 12. RLS Policies for puls_sporsmal_rotasjon
CREATE POLICY "Admins can manage rotasjon"
  ON puls_sporsmal_rotasjon FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Salon leaders can view rotasjon for their surveys"
  ON puls_sporsmal_rotasjon FOR SELECT
  USING (
    undersokelse_id IN (
      SELECT id FROM pulsundersokelser 
      WHERE salon_id = get_user_salon_id(auth.uid())
    )
  );

-- 13. Trigger for updated_at
CREATE TRIGGER update_puls_sporsmal_bank_updated_at
  BEFORE UPDATE ON puls_sporsmal_bank
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_puls_risikologg_updated_at
  BEFORE UPDATE ON puls_risikologg
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- 14. Seed spørsmålsbanken med standard spørsmål
INSERT INTO puls_sporsmal_bank (tema, sporsmal, sporsmal_type, moduler, sort_order) VALUES
-- Trivsel (6 spørsmål)
('trivsel', 'Hvor godt trives du på jobb denne uken?', 'skala', ARRAY['hurtigpuls', 'dyppuls']::puls_type[], 1),
('trivsel', 'I hvilken grad føler du deg verdsatt av kolleger?', 'skala', ARRAY['hurtigpuls', 'dyppuls']::puls_type[], 2),
('trivsel', 'Hvor godt føler du deg inkludert i teamet?', 'skala', ARRAY['dyppuls']::puls_type[], 3),
('trivsel', 'Opplever du at du kan være deg selv på jobb?', 'skala', ARRAY['dyppuls']::puls_type[], 4),
('trivsel', 'Hva gjør deg mest glad på jobb akkurat nå?', 'fritekst', ARRAY['dyppuls']::puls_type[], 5),
('trivsel', 'Er det noe som hindrer deg i å trives fullt ut?', 'fritekst', ARRAY['dyppuls']::puls_type[], 6),

-- Arbeidsbelastning (6 spørsmål)
('arbeidsbelastning', 'Hvordan opplever du arbeidsmengden denne uken?', 'skala', ARRAY['hurtigpuls', 'dyppuls']::puls_type[], 1),
('arbeidsbelastning', 'I hvilken grad rekker du oppgavene dine uten stress?', 'skala', ARRAY['hurtigpuls', 'dyppuls']::puls_type[], 2),
('arbeidsbelastning', 'Får du nok pauser i løpet av arbeidsdagen?', 'skala', ARRAY['dyppuls']::puls_type[], 3),
('arbeidsbelastning', 'Opplever du at forventningene til deg er realistiske?', 'skala', ARRAY['dyppuls']::puls_type[], 4),
('arbeidsbelastning', 'Hva skaper mest press for deg akkurat nå?', 'fritekst', ARRAY['dyppuls']::puls_type[], 5),
('arbeidsbelastning', 'Hva ville hjulpet deg til å jobbe mer effektivt?', 'fritekst', ARRAY['dyppuls']::puls_type[], 6),

-- Psykologisk trygghet (6 spørsmål)
('psykologisk_trygghet', 'Føler du deg trygg på å si fra om ting som ikke fungerer?', 'skala', ARRAY['hurtigpuls', 'dyppuls']::puls_type[], 1),
('psykologisk_trygghet', 'I hvilken grad tør du å stille spørsmål uten frykt for kritikk?', 'skala', ARRAY['hurtigpuls', 'dyppuls']::puls_type[], 2),
('psykologisk_trygghet', 'Opplever du at feil blir møtt med læring fremfor kritikk?', 'skala', ARRAY['dyppuls']::puls_type[], 3),
('psykologisk_trygghet', 'Føler du deg respektert av ledelsen?', 'skala', ARRAY['dyppuls']::puls_type[], 4),
('psykologisk_trygghet', 'Hva ville gjort det tryggere å si fra om utfordringer?', 'fritekst', ARRAY['dyppuls']::puls_type[], 5),
('psykologisk_trygghet', 'Er det noe du kvier deg for å ta opp med ledelsen?', 'fritekst', ARRAY['dyppuls']::puls_type[], 6),

-- Ledelse (6 spørsmål)
('ledelse', 'Hvor fornøyd er du med støtten fra din leder?', 'skala', ARRAY['hurtigpuls', 'dyppuls']::puls_type[], 1),
('ledelse', 'I hvilken grad får du tydelige tilbakemeldinger?', 'skala', ARRAY['hurtigpuls', 'dyppuls']::puls_type[], 2),
('ledelse', 'Opplever du at lederen din er tilgjengelig ved behov?', 'skala', ARRAY['dyppuls']::puls_type[], 3),
('ledelse', 'Føler du deg sett og anerkjent for innsatsen din?', 'skala', ARRAY['dyppuls']::puls_type[], 4),
('ledelse', 'Hva kunne lederen din gjort annerledes?', 'fritekst', ARRAY['dyppuls']::puls_type[], 5),
('ledelse', 'Hva setter du mest pris på med ledelsen?', 'fritekst', ARRAY['dyppuls']::puls_type[], 6),

-- HMS/Sikkerhet (6 spørsmål)
('hms_sikkerhet', 'Føler du deg trygg på arbeidsplassen?', 'skala', ARRAY['hurtigpuls', 'dyppuls']::puls_type[], 1),
('hms_sikkerhet', 'I hvilken grad har du riktig utstyr for å gjøre jobben din?', 'skala', ARRAY['hurtigpuls', 'dyppuls']::puls_type[], 2),
('hms_sikkerhet', 'Opplever du at arbeidsplassen er ergonomisk tilrettelagt?', 'skala', ARRAY['dyppuls']::puls_type[], 3),
('hms_sikkerhet', 'Vet du hva du skal gjøre ved en nødsituasjon?', 'skala', ARRAY['dyppuls']::puls_type[], 4),
('hms_sikkerhet', 'Er det noe HMS-relatert du savner på arbeidsplassen?', 'fritekst', ARRAY['dyppuls']::puls_type[], 5),
('hms_sikkerhet', 'Har du opplevd noe som burde vært rapportert som avvik?', 'fritekst', ARRAY['dyppuls']::puls_type[], 6),

-- Utvikling (6 spørsmål)
('utvikling', 'Får du mulighet til å utvikle deg faglig?', 'skala', ARRAY['hurtigpuls', 'dyppuls']::puls_type[], 1),
('utvikling', 'I hvilken grad føler du mestring i hverdagen?', 'skala', ARRAY['hurtigpuls', 'dyppuls']::puls_type[], 2),
('utvikling', 'Opplever du at du bruker styrkene dine i jobben?', 'skala', ARRAY['dyppuls']::puls_type[], 3),
('utvikling', 'Føler du at karrieremulighetene er tydelige?', 'skala', ARRAY['dyppuls']::puls_type[], 4),
('utvikling', 'Hva ville hjulpet deg til å utvikle deg videre?', 'fritekst', ARRAY['dyppuls']::puls_type[], 5),
('utvikling', 'Er det noe du gjerne skulle lært mer om?', 'fritekst', ARRAY['dyppuls']::puls_type[], 6);

-- 15. Funksjon for å generere tiltak basert på tema og score
CREATE OR REPLACE FUNCTION get_foreslatte_tiltak(p_tema puls_tema, p_score INTEGER)
RETURNS TEXT[] AS $$
BEGIN
  IF p_score > 2 THEN
    RETURN ARRAY[]::TEXT[];
  END IF;
  
  CASE p_tema
    WHEN 'arbeidsbelastning' THEN
      RETURN ARRAY[
        'Vurder avlastning eller omfordeling av oppgaver',
        'Gjennomgå prioriteringer med leder',
        'Vurder behov for ekstra bemanning',
        'Tilby fleksitid eller hjemmekontor'
      ];
    WHEN 'psykologisk_trygghet' THEN
      RETURN ARRAY[
        'Planlegg en-til-en samtale',
        'Avklar forventninger tydelig',
        'Tilby støtte og veiledning',
        'Skap trygge rom for tilbakemelding'
      ];
    WHEN 'hms_sikkerhet' THEN
      RETURN ARRAY[
        'Gjennomfør utstyrskontroll',
        'Vurder pausefrekvens og rutiner',
        'Gjennomgå ergonomiske tilpasninger',
        'Oppdater HMS-rutiner'
      ];
    WHEN 'ledelse' THEN
      RETURN ARRAY[
        'Planlegg regelmessig oppfølging',
        'Forbedre kommunikasjonsrutiner',
        'Gi mer anerkjennelse og tilbakemelding',
        'Vær mer tilgjengelig for teamet'
      ];
    WHEN 'utvikling' THEN
      RETURN ARRAY[
        'Kartlegg opplæringsbehov',
        'Tilby kurs eller sertifisering',
        'Etabler mentor/coaching-ordning',
        'Lag utviklingsplan sammen'
      ];
    WHEN 'trivsel' THEN
      RETURN ARRAY[
        'Arranger sosiale aktiviteter',
        'Styrk inkludering i teamet',
        'Anerkjenn individuelle bidrag',
        'Skap rom for tilbakemelding'
      ];
    ELSE
      RETURN ARRAY['Gjennomfør oppfølgingssamtale'];
  END CASE;
END;
$$ LANGUAGE plpgsql IMMUTABLE;