-- Create salon_insurance table for storing HubSpot insurance data
CREATE TABLE public.salon_insurance (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  salon_id UUID REFERENCES public.salons(id) ON DELETE CASCADE NOT NULL,
  hubspot_company_id TEXT,
  hubspot_synced_at TIMESTAMPTZ,
  
  -- Datoer
  aktivering_dato DATE,
  innmelding_dato DATE,
  oppsigelse_dato DATE,
  
  -- Status
  avsluttede_forsikringer BOOLEAN DEFAULT FALSE,
  helse_status BOOLEAN DEFAULT FALSE,
  
  -- Antall
  antall_ansatte INTEGER,
  antall_arsverk NUMERIC(10,2),
  antall_fritidsulykke INTEGER,
  antall_reiseforsikring INTEGER,
  arlig_omsetning NUMERIC(15,2),
  
  -- Forsikringstyper (aktiv/ikke aktiv)
  cyber_aktiv BOOLEAN DEFAULT FALSE,
  fritidsulykke_aktiv BOOLEAN DEFAULT FALSE,
  reise_aktiv BOOLEAN DEFAULT FALSE,
  salong_aktiv BOOLEAN DEFAULT FALSE,
  yrkesskadeforsikring_aktiv BOOLEAN DEFAULT FALSE,
  
  -- Nivåer
  salong_niva TEXT,
  sum_mvil TEXT,
  
  -- Priser
  pris_cyber NUMERIC(12,2),
  pris_fritidsulykke NUMERIC(12,2),
  pris_reise NUMERIC(12,2),
  pris_salong NUMERIC(12,2),
  pris_yrkesskadeforsikring NUMERIC(12,2),
  
  -- Summer
  sum_fritidsulykke NUMERIC(12,2),
  sum_reise NUMERIC(12,2),
  sum_totalt NUMERIC(12,2),
  sum_yrkesskadeforsikring NUMERIC(12,2),
  
  -- Kontaktinfo
  kontaktperson_navn TEXT,
  kontaktperson_epost TEXT,
  
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  
  UNIQUE(salon_id)
);

-- Enable RLS
ALTER TABLE public.salon_insurance ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Admins can manage all insurance data"
ON public.salon_insurance
FOR ALL
USING (has_role(auth.uid(), 'admin'))
WITH CHECK (has_role(auth.uid(), 'admin'));

CREATE POLICY "Salon owners can view their insurance data"
ON public.salon_insurance
FOR SELECT
USING (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()));

CREATE POLICY "District managers can view district insurance data"
ON public.salon_insurance
FOR SELECT
USING (
  has_role(auth.uid(), 'district_manager') 
  AND salon_id IN (SELECT get_district_salon_ids(auth.uid()))
);

-- Trigger for updated_at
CREATE TRIGGER update_salon_insurance_updated_at
BEFORE UPDATE ON public.salon_insurance
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Index for faster lookups
CREATE INDEX idx_salon_insurance_salon_id ON public.salon_insurance(salon_id);
CREATE INDEX idx_salon_insurance_hubspot_company_id ON public.salon_insurance(hubspot_company_id);