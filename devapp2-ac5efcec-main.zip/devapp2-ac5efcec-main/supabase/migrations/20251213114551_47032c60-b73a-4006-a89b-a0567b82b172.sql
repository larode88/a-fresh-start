-- Gjør user_id nullable i ansatt_turnus for å tillate turnus for ansatte uten bruker-konto
ALTER TABLE ansatt_turnus ALTER COLUMN user_id DROP NOT NULL;

-- Legg til kommentar for dokumentasjon
COMMENT ON COLUMN ansatt_turnus.user_id IS 'Valgfri referanse til bruker-konto. Kan være NULL for ansatte som ikke har logget inn i systemet.';