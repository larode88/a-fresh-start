-- Add medlemsstatus column to salons table
ALTER TABLE salons ADD COLUMN IF NOT EXISTS medlemsstatus TEXT;