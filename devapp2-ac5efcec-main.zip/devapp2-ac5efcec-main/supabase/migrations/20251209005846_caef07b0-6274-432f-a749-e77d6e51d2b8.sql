-- Add win-back tracking columns to insurance_scheduled_cancellations
ALTER TABLE insurance_scheduled_cancellations 
ADD COLUMN IF NOT EXISTS winback_contacted BOOLEAN DEFAULT FALSE,
ADD COLUMN IF NOT EXISTS winback_contacted_by UUID REFERENCES auth.users(id),
ADD COLUMN IF NOT EXISTS winback_contacted_at TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS winback_outcome TEXT,
ADD COLUMN IF NOT EXISTS frende_notified BOOLEAN DEFAULT FALSE,
ADD COLUMN IF NOT EXISTS frende_notified_at TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS salon_notified BOOLEAN DEFAULT FALSE,
ADD COLUMN IF NOT EXISTS salon_notified_at TIMESTAMPTZ;

-- Add column for tracking change details in insurance_orders
ALTER TABLE insurance_orders
ADD COLUMN IF NOT EXISTS change_details JSONB,
ADD COLUMN IF NOT EXISTS original_values JSONB;

-- Create index for win-back queries
CREATE INDEX IF NOT EXISTS idx_scheduled_cancellations_winback 
ON insurance_scheduled_cancellations(winback_contacted, processed) 
WHERE NOT processed;

COMMENT ON COLUMN insurance_scheduled_cancellations.winback_contacted IS 'Whether admin has contacted salon for win-back';
COMMENT ON COLUMN insurance_scheduled_cancellations.winback_outcome IS 'Outcome: saved, confirmed_cancel, no_response';
COMMENT ON COLUMN insurance_orders.change_details IS 'Details about what changed (e.g., new tier, new quantity)';
COMMENT ON COLUMN insurance_orders.original_values IS 'Original values before change request';