-- Add fields to insurance_power_of_attorney for previous insurers
ALTER TABLE public.insurance_power_of_attorney
ADD COLUMN IF NOT EXISTS has_existing_insurance boolean DEFAULT false,
ADD COLUMN IF NOT EXISTS previous_insurers jsonb DEFAULT '[]'::jsonb,
ADD COLUMN IF NOT EXISTS quote_id uuid REFERENCES public.insurance_quotes(id) ON DELETE SET NULL;

-- Add comment
COMMENT ON COLUMN public.insurance_power_of_attorney.has_existing_insurance IS 'Whether the salon has existing insurance to cancel';
COMMENT ON COLUMN public.insurance_power_of_attorney.previous_insurers IS 'Array of {company, policy_number} objects for insurances to cancel';
COMMENT ON COLUMN public.insurance_power_of_attorney.quote_id IS 'Link to the insurance quote that initiated this POA';