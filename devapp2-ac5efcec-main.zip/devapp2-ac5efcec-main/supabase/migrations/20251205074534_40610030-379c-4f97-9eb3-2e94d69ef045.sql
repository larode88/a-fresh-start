-- Create insurance_scheduled_cancellations table for tracking planned insurance cancellations
CREATE TABLE public.insurance_scheduled_cancellations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  salon_id UUID NOT NULL REFERENCES public.salons(id) ON DELETE CASCADE,
  insurance_type TEXT NOT NULL CHECK (insurance_type IN ('salong', 'yrkesskade', 'cyber', 'reise', 'fritidsulykke', 'helse')),
  cancellation_date DATE NOT NULL,
  reason TEXT,
  scheduled_by UUID REFERENCES public.users(id),
  scheduled_at TIMESTAMPTZ DEFAULT now(),
  processed BOOLEAN DEFAULT false,
  processed_at TIMESTAMPTZ,
  hubspot_synced BOOLEAN DEFAULT false,
  hubspot_synced_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(salon_id, insurance_type, cancellation_date)
);

-- Add index for efficient querying of unprocessed cancellations
CREATE INDEX idx_scheduled_cancellations_pending ON public.insurance_scheduled_cancellations(cancellation_date, processed) WHERE processed = false;
CREATE INDEX idx_scheduled_cancellations_salon ON public.insurance_scheduled_cancellations(salon_id);

-- Enable RLS
ALTER TABLE public.insurance_scheduled_cancellations ENABLE ROW LEVEL SECURITY;

-- RLS policies - only admins can manage scheduled cancellations
CREATE POLICY "Admins can manage all scheduled cancellations"
ON public.insurance_scheduled_cancellations
FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- Salon owners can view their own scheduled cancellations
CREATE POLICY "Salon owners can view their scheduled cancellations"
ON public.insurance_scheduled_cancellations
FOR SELECT
USING (
  salon_id = get_user_salon_id(auth.uid()) 
  AND (is_salon_owner(auth.uid()) OR has_role(auth.uid(), 'daglig_leder'::app_role))
);

-- Add trigger for updated_at
CREATE TRIGGER update_insurance_scheduled_cancellations_updated_at
  BEFORE UPDATE ON public.insurance_scheduled_cancellations
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Add comment for documentation
COMMENT ON TABLE public.insurance_scheduled_cancellations IS 'Tracks scheduled future insurance cancellations that will be automatically processed on the cancellation date';