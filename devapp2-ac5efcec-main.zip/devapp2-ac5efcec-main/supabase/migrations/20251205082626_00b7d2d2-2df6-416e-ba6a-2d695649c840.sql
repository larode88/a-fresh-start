
-- Update function to also clear sum fields when insurance is deactivated
CREATE OR REPLACE FUNCTION public.recalculate_salon_insurance_total()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  new_total numeric := 0;
BEGIN
  -- Clear sum fields when insurance is deactivated
  IF NEW.salong_aktiv = false OR NEW.salong_aktiv IS NULL THEN
    NEW.pris_salong := NULL;
    NEW.salong_niva := NULL;
  END IF;
  
  IF NEW.yrkesskadeforsikring_aktiv = false OR NEW.yrkesskadeforsikring_aktiv IS NULL THEN
    NEW.sum_yrkesskadeforsikring := NULL;
    NEW.pris_yrkesskadeforsikring := NULL;
  END IF;
  
  IF NEW.cyber_aktiv = false OR NEW.cyber_aktiv IS NULL THEN
    NEW.pris_cyber := NULL;
  END IF;
  
  IF NEW.reise_aktiv = false OR NEW.reise_aktiv IS NULL THEN
    NEW.sum_reise := NULL;
    NEW.pris_reise := NULL;
    NEW.antall_reiseforsikring := NULL;
  END IF;
  
  IF NEW.fritidsulykke_aktiv = false OR NEW.fritidsulykke_aktiv IS NULL THEN
    NEW.sum_fritidsulykke := NULL;
    NEW.pris_fritidsulykke := NULL;
    NEW.antall_fritidsulykke := NULL;
  END IF;
  
  IF NEW.helse_status = false OR NEW.helse_status IS NULL THEN
    NEW.helse_antall_aktive := NULL;
    NEW.helseforsikring_premie := NULL;
  END IF;

  -- Calculate sum_totalt based on active insurances
  IF NEW.salong_aktiv = true AND NEW.pris_salong IS NOT NULL THEN
    new_total := new_total + NEW.pris_salong;
  END IF;
  
  IF NEW.yrkesskadeforsikring_aktiv = true AND NEW.sum_yrkesskadeforsikring IS NOT NULL THEN
    new_total := new_total + NEW.sum_yrkesskadeforsikring;
  END IF;
  
  IF NEW.cyber_aktiv = true AND NEW.pris_cyber IS NOT NULL THEN
    new_total := new_total + NEW.pris_cyber;
  END IF;
  
  IF NEW.reise_aktiv = true AND NEW.sum_reise IS NOT NULL THEN
    new_total := new_total + NEW.sum_reise;
  END IF;
  
  IF NEW.fritidsulykke_aktiv = true AND NEW.sum_fritidsulykke IS NOT NULL THEN
    new_total := new_total + NEW.sum_fritidsulykke;
  END IF;
  
  IF NEW.helse_status = true AND NEW.helse_antall_aktive IS NOT NULL THEN
    new_total := new_total + (NEW.helse_antall_aktive * 5050);
  END IF;
  
  -- Set the new total (0 if nothing active)
  NEW.sum_totalt := new_total;
  
  RETURN NEW;
END;
$$;
