-- Add source_quote_id column to insurance_orders to track which quote generated the order
ALTER TABLE public.insurance_orders 
ADD COLUMN source_quote_id uuid REFERENCES public.insurance_quotes(id);

-- Create index for faster lookups
CREATE INDEX idx_insurance_orders_source_quote_id ON public.insurance_orders(source_quote_id);

-- Add comment for documentation
COMMENT ON COLUMN public.insurance_orders.source_quote_id IS 'Reference to the insurance_quote that generated this order';