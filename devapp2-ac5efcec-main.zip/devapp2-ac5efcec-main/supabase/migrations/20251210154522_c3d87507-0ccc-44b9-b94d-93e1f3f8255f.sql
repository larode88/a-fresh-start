-- 1. Fiks is_salon_owner() til å bruke user_roles-tabellen
CREATE OR REPLACE FUNCTION public.is_salon_owner(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = 'salon_owner'
  )
$$;

-- 2. Opprett is_salon_leader() som inkluderer alle lederroller
CREATE OR REPLACE FUNCTION public.is_salon_leader(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role IN ('salon_owner', 'daglig_leder', 'avdelingsleder', 'styreleder')
  )
$$;

-- 3. Opprett get_user_chain_ids() for kjedeeier-tilgang
CREATE OR REPLACE FUNCTION public.get_user_chain_ids(_user_id uuid)
RETURNS SETOF uuid
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT DISTINCT s.chain_id
  FROM public.salons s
  INNER JOIN public.users u ON u.salon_id = s.id
  WHERE u.id = _user_id
    AND s.chain_id IS NOT NULL
$$;

-- 4. Ny RLS-policy: Salongledere kan se ansatte i sin salong
CREATE POLICY "Salon leaders can view users in their salon"
ON public.users
FOR SELECT
TO authenticated
USING (
  salon_id IS NOT NULL
  AND is_salon_leader(auth.uid())
  AND salon_id = get_user_salon_id(auth.uid())
);

-- 5. Ny RLS-policy: Kjedeeiere kan se ansatte i sin kjede
CREATE POLICY "Chain owners can view users in their chain"
ON public.users
FOR SELECT
TO authenticated
USING (
  has_role(auth.uid(), 'chain_owner')
  AND salon_id IN (
    SELECT id FROM public.salons 
    WHERE chain_id IN (SELECT get_user_chain_ids(auth.uid()))
  )
);