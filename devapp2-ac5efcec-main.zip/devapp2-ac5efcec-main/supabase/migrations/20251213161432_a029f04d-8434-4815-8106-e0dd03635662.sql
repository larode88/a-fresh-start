-- Add ansatt_id column to budsjett table
ALTER TABLE public.budsjett ADD COLUMN ansatt_id UUID REFERENCES public.ansatte(id);

-- Migrate existing data (link user_id to ansatt_id via ansatte.user_id)
UPDATE public.budsjett b
SET ansatt_id = a.id
FROM public.ansatte a
WHERE b.user_id = a.user_id;

-- Make user_id nullable (for backwards compatibility)
ALTER TABLE public.budsjett ALTER COLUMN user_id DROP NOT NULL;

-- Create index for performance
CREATE INDEX idx_budsjett_ansatt_id ON public.budsjett(ansatt_id);