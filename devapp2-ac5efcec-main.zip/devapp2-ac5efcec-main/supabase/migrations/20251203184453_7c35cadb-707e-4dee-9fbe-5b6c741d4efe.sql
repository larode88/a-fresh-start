-- Fase 4: Kalender-modul - Komplett

-- 4.1 Kalender-tabell
CREATE TABLE public.kalender (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  dato date NOT NULL UNIQUE,
  aar integer NOT NULL,
  maned integer NOT NULL,
  uke integer NOT NULL,
  ukedag integer NOT NULL,
  er_helligdag boolean DEFAULT false,
  helligdag_navn text,
  er_arbeidsdag boolean DEFAULT true,
  er_sommerferie boolean DEFAULT false,
  er_juleferie boolean DEFAULT false,
  created_at timestamp with time zone DEFAULT now()
);

CREATE INDEX idx_kalender_aar ON public.kalender(aar);
CREATE INDEX idx_kalender_uke ON public.kalender(aar, uke);
CREATE INDEX idx_kalender_maned ON public.kalender(aar, maned);

ALTER TABLE public.kalender ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Everyone can view kalender" ON public.kalender FOR SELECT USING (true);
CREATE POLICY "Admins can manage kalender" ON public.kalender FOR ALL 
USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- 4.2 Generer datoer for 2024-2030
INSERT INTO public.kalender (dato, aar, maned, uke, ukedag, er_arbeidsdag)
SELECT 
  d::date,
  EXTRACT(YEAR FROM d)::integer,
  EXTRACT(MONTH FROM d)::integer,
  EXTRACT(WEEK FROM d)::integer,
  EXTRACT(ISODOW FROM d)::integer,
  EXTRACT(ISODOW FROM d)::integer NOT IN (6, 7)
FROM generate_series('2024-01-01'::date, '2030-12-31'::date, '1 day'::interval) d;

-- 4.3 Faste norske helligdager
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = 'Nyttårsdag', er_arbeidsdag = false WHERE EXTRACT(MONTH FROM dato) = 1 AND EXTRACT(DAY FROM dato) = 1;
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = 'Arbeidernes dag', er_arbeidsdag = false WHERE EXTRACT(MONTH FROM dato) = 5 AND EXTRACT(DAY FROM dato) = 1;
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = 'Grunnlovsdag', er_arbeidsdag = false WHERE EXTRACT(MONTH FROM dato) = 5 AND EXTRACT(DAY FROM dato) = 17;
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = 'Julaften', er_arbeidsdag = false WHERE EXTRACT(MONTH FROM dato) = 12 AND EXTRACT(DAY FROM dato) = 24;
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = '1. juledag', er_arbeidsdag = false WHERE EXTRACT(MONTH FROM dato) = 12 AND EXTRACT(DAY FROM dato) = 25;
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = '2. juledag', er_arbeidsdag = false WHERE EXTRACT(MONTH FROM dato) = 12 AND EXTRACT(DAY FROM dato) = 26;
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = 'Nyttarsaften', er_arbeidsdag = false WHERE EXTRACT(MONTH FROM dato) = 12 AND EXTRACT(DAY FROM dato) = 31;

-- 4.4 Bevegelige helligdager 2024
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = 'Skjaertorsdag', er_arbeidsdag = false WHERE dato = '2024-03-28';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = 'Langfredag', er_arbeidsdag = false WHERE dato = '2024-03-29';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = '1. paskedag', er_arbeidsdag = false WHERE dato = '2024-03-31';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = '2. paskedag', er_arbeidsdag = false WHERE dato = '2024-04-01';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = 'Kristi himmelfartsdag', er_arbeidsdag = false WHERE dato = '2024-05-09';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = '1. pinsedag', er_arbeidsdag = false WHERE dato = '2024-05-19';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = '2. pinsedag', er_arbeidsdag = false WHERE dato = '2024-05-20';

-- 4.5 Bevegelige helligdager 2025
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = 'Skjaertorsdag', er_arbeidsdag = false WHERE dato = '2025-04-17';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = 'Langfredag', er_arbeidsdag = false WHERE dato = '2025-04-18';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = '1. paskedag', er_arbeidsdag = false WHERE dato = '2025-04-20';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = '2. paskedag', er_arbeidsdag = false WHERE dato = '2025-04-21';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = 'Kristi himmelfartsdag', er_arbeidsdag = false WHERE dato = '2025-05-29';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = '1. pinsedag', er_arbeidsdag = false WHERE dato = '2025-06-08';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = '2. pinsedag', er_arbeidsdag = false WHERE dato = '2025-06-09';

-- 4.6 Bevegelige helligdager 2026
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = 'Skjaertorsdag', er_arbeidsdag = false WHERE dato = '2026-04-02';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = 'Langfredag', er_arbeidsdag = false WHERE dato = '2026-04-03';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = '1. paskedag', er_arbeidsdag = false WHERE dato = '2026-04-05';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = '2. paskedag', er_arbeidsdag = false WHERE dato = '2026-04-06';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = 'Kristi himmelfartsdag', er_arbeidsdag = false WHERE dato = '2026-05-14';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = '1. pinsedag', er_arbeidsdag = false WHERE dato = '2026-05-24';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = '2. pinsedag', er_arbeidsdag = false WHERE dato = '2026-05-25';

-- 4.7 Bevegelige helligdager 2027
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = 'Skjaertorsdag', er_arbeidsdag = false WHERE dato = '2027-03-25';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = 'Langfredag', er_arbeidsdag = false WHERE dato = '2027-03-26';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = '1. paskedag', er_arbeidsdag = false WHERE dato = '2027-03-28';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = '2. paskedag', er_arbeidsdag = false WHERE dato = '2027-03-29';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = 'Kristi himmelfartsdag', er_arbeidsdag = false WHERE dato = '2027-05-06';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = '1. pinsedag', er_arbeidsdag = false WHERE dato = '2027-05-16';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = '2. pinsedag', er_arbeidsdag = false WHERE dato = '2027-05-17';

-- 4.8 Bevegelige helligdager 2028
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = 'Skjaertorsdag', er_arbeidsdag = false WHERE dato = '2028-04-13';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = 'Langfredag', er_arbeidsdag = false WHERE dato = '2028-04-14';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = '1. paskedag', er_arbeidsdag = false WHERE dato = '2028-04-16';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = '2. paskedag', er_arbeidsdag = false WHERE dato = '2028-04-17';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = 'Kristi himmelfartsdag', er_arbeidsdag = false WHERE dato = '2028-05-25';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = '1. pinsedag', er_arbeidsdag = false WHERE dato = '2028-06-04';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = '2. pinsedag', er_arbeidsdag = false WHERE dato = '2028-06-05';

-- 4.9 Bevegelige helligdager 2029
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = 'Skjaertorsdag', er_arbeidsdag = false WHERE dato = '2029-03-29';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = 'Langfredag', er_arbeidsdag = false WHERE dato = '2029-03-30';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = '1. paskedag', er_arbeidsdag = false WHERE dato = '2029-04-01';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = '2. paskedag', er_arbeidsdag = false WHERE dato = '2029-04-02';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = 'Kristi himmelfartsdag', er_arbeidsdag = false WHERE dato = '2029-05-10';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = '1. pinsedag', er_arbeidsdag = false WHERE dato = '2029-05-20';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = '2. pinsedag', er_arbeidsdag = false WHERE dato = '2029-05-21';

-- 4.10 Bevegelige helligdager 2030
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = 'Skjaertorsdag', er_arbeidsdag = false WHERE dato = '2030-04-18';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = 'Langfredag', er_arbeidsdag = false WHERE dato = '2030-04-19';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = '1. paskedag', er_arbeidsdag = false WHERE dato = '2030-04-21';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = '2. paskedag', er_arbeidsdag = false WHERE dato = '2030-04-22';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = 'Kristi himmelfartsdag', er_arbeidsdag = false WHERE dato = '2030-05-30';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = '1. pinsedag', er_arbeidsdag = false WHERE dato = '2030-06-09';
UPDATE public.kalender SET er_helligdag = true, helligdag_navn = '2. pinsedag', er_arbeidsdag = false WHERE dato = '2030-06-10';

-- 4.11 Ferieperioder
UPDATE public.kalender SET er_sommerferie = true WHERE uke BETWEEN 26 AND 32;
UPDATE public.kalender SET er_juleferie = true WHERE (maned = 12 AND EXTRACT(DAY FROM dato) >= 20) OR (maned = 1 AND EXTRACT(DAY FROM dato) <= 3);

-- 4.12 Hjelpefunksjoner
CREATE OR REPLACE FUNCTION public.get_arbeidsdager_i_periode(p_fra date, p_til date)
RETURNS integer LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT COUNT(*)::integer FROM public.kalender WHERE dato BETWEEN p_fra AND p_til AND er_arbeidsdag = true
$$;

CREATE OR REPLACE FUNCTION public.get_arbeidsdager_i_uke(p_aar integer, p_uke integer)
RETURNS integer LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT COUNT(*)::integer FROM public.kalender WHERE aar = p_aar AND uke = p_uke AND er_arbeidsdag = true
$$;