-- =====================================================
-- FASE 1: Utvikling & Samtaler - Database-utvidelser
-- =====================================================

-- 1. Kompetansedefinisjoner med rubrikk (1-5 nivåer)
CREATE TABLE public.kompetanse_definisjoner (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  navn TEXT NOT NULL,
  beskrivelse TEXT,
  kategori TEXT DEFAULT 'generell',
  rubrikk JSONB NOT NULL DEFAULT '[]'::jsonb, -- Array med {nivaa: 1-5, tittel, beskrivelse}
  aktiv BOOLEAN DEFAULT true,
  rekkefølge INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- 2. Samtale-maler (ConversationTemplate)
CREATE TABLE public.samtale_maler (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  navn TEXT NOT NULL,
  beskrivelse TEXT,
  type TEXT DEFAULT 'medarbeidersamtale', -- medarbeidersamtale, utviklingssamtale, oppfølging, etc.
  seksjoner JSONB NOT NULL DEFAULT '[]'::jsonb, -- Array med {tittel, felt[], veiledning}
  kompetanser UUID[] DEFAULT '{}', -- Referanse til kompetanse_definisjoner
  aktiv BOOLEAN DEFAULT true,
  opprettet_av UUID REFERENCES public.users(id),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- 3. Kompetanse-scorer per samtale
CREATE TABLE public.ansatt_kompetanse_score (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  samtale_id UUID NOT NULL REFERENCES public.ansatt_samtaler(id) ON DELETE CASCADE,
  kompetanse_id UUID NOT NULL REFERENCES public.kompetanse_definisjoner(id),
  score INTEGER NOT NULL CHECK (score >= 1 AND score <= 5),
  kommentar TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(samtale_id, kompetanse_id)
);

-- 4. Utvid ansatt_samtaler med nye felt
ALTER TABLE public.ansatt_samtaler 
  ADD COLUMN IF NOT EXISTS mal_id UUID REFERENCES public.samtale_maler(id),
  ADD COLUMN IF NOT EXISTS sammendrag TEXT,
  ADD COLUMN IF NOT EXISTS konfidensielle_notater TEXT, -- Kun HR/reviewer kan se
  ADD COLUMN IF NOT EXISTS sted TEXT, -- fysisk/Teams/Zoom
  ADD COLUMN IF NOT EXISTS med_deltakere UUID[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS signert_av_ansatt BOOLEAN DEFAULT false,
  ADD COLUMN IF NOT EXISTS signert_dato TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS lønnsforslag_beløp NUMERIC,
  ADD COLUMN IF NOT EXISTS lønnsforslag_kommentar TEXT,
  ADD COLUMN IF NOT EXISTS arkivert BOOLEAN DEFAULT false;

-- 5. Utvid ansatt_utviklingsplan med kostnader og type
ALTER TABLE public.ansatt_utviklingsplan
  ADD COLUMN IF NOT EXISTS type TEXT DEFAULT 'andre', -- kurs, mentor, on-the-job, sertifisering, andre
  ADD COLUMN IF NOT EXISTS estimert_kostnad NUMERIC DEFAULT 0,
  ADD COLUMN IF NOT EXISTS godkjent_kostnad BOOLEAN DEFAULT false,
  ADD COLUMN IF NOT EXISTS eier_id UUID REFERENCES public.users(id),
  ADD COLUMN IF NOT EXISTS dokumenter JSONB DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS prioritet INTEGER DEFAULT 2; -- 1=høy, 2=medium, 3=lav

-- 6. Utvid ansatt_sertifiseringer for kurshistorikk
ALTER TABLE public.ansatt_sertifiseringer
  ADD COLUMN IF NOT EXISTS kurs_leverandør TEXT,
  ADD COLUMN IF NOT EXISTS kostnad NUMERIC,
  ADD COLUMN IF NOT EXISTS varighet_timer INTEGER,
  ADD COLUMN IF NOT EXISTS tilknyttet_plan_id UUID REFERENCES public.ansatt_utviklingsplan(id),
  ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'fullført'; -- planlagt, påmeldt, fullført, ikke_bestått

-- 7. Enable RLS
ALTER TABLE public.kompetanse_definisjoner ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.samtale_maler ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ansatt_kompetanse_score ENABLE ROW LEVEL SECURITY;

-- 8. RLS Policies for kompetanse_definisjoner
CREATE POLICY "Admins can manage kompetanse_definisjoner"
  ON public.kompetanse_definisjoner FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Authenticated users can view active kompetanse_definisjoner"
  ON public.kompetanse_definisjoner FOR SELECT
  USING (auth.uid() IS NOT NULL AND aktiv = true);

-- 9. RLS Policies for samtale_maler
CREATE POLICY "Admins can manage samtale_maler"
  ON public.samtale_maler FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Authenticated users can view active samtale_maler"
  ON public.samtale_maler FOR SELECT
  USING (auth.uid() IS NOT NULL AND aktiv = true);

-- 10. RLS Policies for ansatt_kompetanse_score
CREATE POLICY "Admins can manage all kompetanse_score"
  ON public.ansatt_kompetanse_score FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Salon owners can manage their salon kompetanse_score"
  ON public.ansatt_kompetanse_score FOR ALL
  USING (
    samtale_id IN (
      SELECT id FROM public.ansatt_samtaler 
      WHERE salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid())
    )
  )
  WITH CHECK (
    samtale_id IN (
      SELECT id FROM public.ansatt_samtaler 
      WHERE salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid())
    )
  );

CREATE POLICY "Users can view their own kompetanse_score"
  ON public.ansatt_kompetanse_score FOR SELECT
  USING (
    samtale_id IN (
      SELECT id FROM public.ansatt_samtaler WHERE user_id = auth.uid()
    )
  );

-- 11. Triggers for updated_at
CREATE TRIGGER update_kompetanse_definisjoner_updated_at
  BEFORE UPDATE ON public.kompetanse_definisjoner
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_samtale_maler_updated_at
  BEFORE UPDATE ON public.samtale_maler
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- 12. Helper function for konfidensielle notater (kun HR/admin)
CREATE OR REPLACE FUNCTION public.get_konfidensielle_notater(p_samtale_id uuid)
RETURNS TEXT
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT CASE 
    WHEN has_role(auth.uid(), 'admin'::app_role) 
         OR is_admin_or_manager(auth.uid())
    THEN konfidensielle_notater
    ELSE NULL
  END
  FROM public.ansatt_samtaler
  WHERE id = p_samtale_id
$$;

-- 13. Seed default kompetanser for frisørbransjen
INSERT INTO public.kompetanse_definisjoner (navn, beskrivelse, kategori, rekkefølge, rubrikk) VALUES
('Faglig kompetanse', 'Tekniske ferdigheter innen klipp, farge og styling', 'faglig', 1, 
  '[{"nivaa":1,"tittel":"Under forventning","beskrivelse":"Trenger betydelig veiledning i grunnleggende teknikker"},
    {"nivaa":2,"tittel":"Nær forventning","beskrivelse":"Mestrer grunnleggende, men usikker på avanserte teknikker"},
    {"nivaa":3,"tittel":"Møter forventning","beskrivelse":"God mestring av standard teknikker og prosedyrer"},
    {"nivaa":4,"tittel":"Over forventning","beskrivelse":"Høy kompetanse, kan veilede andre"},
    {"nivaa":5,"tittel":"Eksepsjonell","beskrivelse":"Ekspert-nivå, innovativ og trendsettende"}]'::jsonb),
('Kundebehandling', 'Evne til å møte og ivareta kunder profesjonelt', 'service', 2,
  '[{"nivaa":1,"tittel":"Under forventning","beskrivelse":"Kommuniserer uklart, sliter med kundekontakt"},
    {"nivaa":2,"tittel":"Nær forventning","beskrivelse":"Ok kommunikasjon, men kan forbedre kundeopplevelsen"},
    {"nivaa":3,"tittel":"Møter forventning","beskrivelse":"God kundebehandling og kommunikasjon"},
    {"nivaa":4,"tittel":"Over forventning","beskrivelse":"Utmerket på å forstå og ivareta kundebehov"},
    {"nivaa":5,"tittel":"Eksepsjonell","beskrivelse":"Skaper unike kundeopplevelser, høy kundelojalitet"}]'::jsonb),
('Samarbeid', 'Evne til å jobbe i team og bidra til godt arbeidsmiljø', 'personlig', 3,
  '[{"nivaa":1,"tittel":"Under forventning","beskrivelse":"Vanskeligheter med teamarbeid"},
    {"nivaa":2,"tittel":"Nær forventning","beskrivelse":"Deltar, men tar sjelden initiativ"},
    {"nivaa":3,"tittel":"Møter forventning","beskrivelse":"God samarbeidsevne, bidrar positivt"},
    {"nivaa":4,"tittel":"Over forventning","beskrivelse":"Aktiv bidragsyter, løfter teamet"},
    {"nivaa":5,"tittel":"Eksepsjonell","beskrivelse":"Naturlig leder, inspirerer kolleger"}]'::jsonb),
('Salg og merbehandling', 'Evne til produktsalg og merbehandlinger', 'salg', 4,
  '[{"nivaa":1,"tittel":"Under forventning","beskrivelse":"Foreslår sjelden produkter eller tillegg"},
    {"nivaa":2,"tittel":"Nær forventning","beskrivelse":"Prøver, men følger ikke opp konsekvent"},
    {"nivaa":3,"tittel":"Møter forventning","beskrivelse":"Anbefaler relevante produkter naturlig"},
    {"nivaa":4,"tittel":"Over forventning","beskrivelse":"Høy salgsandel, gode rådgivning"},
    {"nivaa":5,"tittel":"Eksepsjonell","beskrivelse":"Eksepsjonelle salgsresultater, mentor for andre"}]'::jsonb),
('Effektivitet', 'Tidsstyring og produktivitet', 'produktivitet', 5,
  '[{"nivaa":1,"tittel":"Under forventning","beskrivelse":"Bruker mye tid, lav produktivitet"},
    {"nivaa":2,"tittel":"Nær forventning","beskrivelse":"Noe forbedringspotensial i tidsbruk"},
    {"nivaa":3,"tittel":"Møter forventning","beskrivelse":"God balanse mellom kvalitet og tempo"},
    {"nivaa":4,"tittel":"Over forventning","beskrivelse":"Høy effektivitet uten å gå på bekostning av kvalitet"},
    {"nivaa":5,"tittel":"Eksepsjonell","beskrivelse":"Optimaliserer tid og arbeidsflyt eksepsjonelt"}]'::jsonb);

-- 14. Seed default samtale-mal
INSERT INTO public.samtale_maler (navn, beskrivelse, type, seksjoner) VALUES
('Årlig medarbeidersamtale', 'Standard mal for årlig utviklingssamtale', 'medarbeidersamtale',
  '[{"tittel":"Agenda og intro","felt":["forventninger","agenda"],"veiledning":"Start med å gå gjennom agendaen"},
    {"tittel":"Tilbakeblikk","felt":["siste_periode","prestasjoner","utfordringer"],"veiledning":"Se tilbake på siste periode"},
    {"tittel":"Kompetansevurdering","felt":["kompetanse_scores"],"veiledning":"Vurder hver kompetanse 1-5"},
    {"tittel":"Utviklingsmål","felt":["mål_neste_periode","tiltak"],"veiledning":"Definer SMART-mål"},
    {"tittel":"Karriere og ambisjoner","felt":["karriereønsker","utviklingsbehov"],"veiledning":"Diskuter fremtidsplaner"},
    {"tittel":"Avslutning","felt":["oppsummering","neste_samtale"],"veiledning":"Oppsummer og sett neste møte"}]'::jsonb),
('Oppfølgingssamtale', 'Kort oppfølging av utviklingsplan', 'oppfølging',
  '[{"tittel":"Status tiltak","felt":["tiltak_status","hindringer"],"veiledning":"Gå gjennom pågående tiltak"},
    {"tittel":"Justeringer","felt":["nye_behov","endringer"],"veiledning":"Juster plan ved behov"},
    {"tittel":"Neste steg","felt":["aksjonspunkter"],"veiledning":"Avklar neste steg"}]'::jsonb);