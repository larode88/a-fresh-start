-- Fase 5: Turnus-modul

-- 5.1 Salong åpningstider (ukentlig standard)
CREATE TABLE public.salong_apningstider (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  salon_id uuid NOT NULL REFERENCES public.salons(id) ON DELETE CASCADE,
  ukedag integer NOT NULL CHECK (ukedag BETWEEN 1 AND 7), -- 1=mandag, 7=søndag
  apner time,
  stenger time,
  stengt boolean DEFAULT false,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now(),
  UNIQUE(salon_id, ukedag)
);

-- 5.2 Salong åpningstider unntak (helligdager, spesielle dager)
CREATE TABLE public.salong_apningstider_unntak (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  salon_id uuid NOT NULL REFERENCES public.salons(id) ON DELETE CASCADE,
  dato date NOT NULL,
  apner time,
  stenger time,
  stengt boolean DEFAULT true,
  arsak text,
  created_at timestamp with time zone DEFAULT now(),
  UNIQUE(salon_id, dato)
);

-- 5.3 Ansatt turnus (ukentlig turnusplan)
CREATE TYPE turnus_uke_type AS ENUM ('alle', 'partall', 'oddetall');

CREATE TABLE public.ansatt_turnus (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  salon_id uuid NOT NULL REFERENCES public.salons(id) ON DELETE CASCADE,
  ukedag integer NOT NULL CHECK (ukedag BETWEEN 1 AND 7),
  uke_type turnus_uke_type DEFAULT 'alle',
  start_tid time,
  slutt_tid time,
  fridag boolean DEFAULT false,
  gyldig_fra date NOT NULL DEFAULT CURRENT_DATE,
  gyldig_til date,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

CREATE INDEX idx_ansatt_turnus_user ON public.ansatt_turnus(user_id);
CREATE INDEX idx_ansatt_turnus_salon ON public.ansatt_turnus(salon_id);
CREATE INDEX idx_ansatt_turnus_gyldig ON public.ansatt_turnus(gyldig_fra, gyldig_til);

-- 5.4 Turnus skift (genererte/planlagte skift per dag)
CREATE TYPE skift_kilde AS ENUM ('turnus', 'manuell', 'bytte');

CREATE TABLE public.turnus_skift (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  salon_id uuid NOT NULL REFERENCES public.salons(id) ON DELETE CASCADE,
  dato date NOT NULL,
  start_tid time,
  slutt_tid time,
  timer_planlagt numeric(4,2),
  kilde skift_kilde DEFAULT 'turnus',
  notat text,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now(),
  UNIQUE(user_id, dato)
);

CREATE INDEX idx_turnus_skift_dato ON public.turnus_skift(dato);
CREATE INDEX idx_turnus_skift_salon_dato ON public.turnus_skift(salon_id, dato);

-- 5.5 Turnus preferanser (ansattes ønsker)
CREATE TABLE public.turnus_preferanser (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  salon_id uuid NOT NULL REFERENCES public.salons(id) ON DELETE CASCADE,
  ukedag integer CHECK (ukedag BETWEEN 1 AND 7),
  onsket_start_tid time,
  onsket_slutt_tid time,
  kan_ikke_jobbe boolean DEFAULT false,
  prioritet integer DEFAULT 1,
  kommentar text,
  gyldig_fra date DEFAULT CURRENT_DATE,
  created_at timestamp with time zone DEFAULT now()
);

-- 5.6 Enable RLS
ALTER TABLE public.salong_apningstider ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.salong_apningstider_unntak ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ansatt_turnus ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.turnus_skift ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.turnus_preferanser ENABLE ROW LEVEL SECURITY;

-- 5.7 RLS Policies - salong_apningstider
CREATE POLICY "Everyone can view salong_apningstider" ON public.salong_apningstider FOR SELECT USING (true);
CREATE POLICY "Admins can manage salong_apningstider" ON public.salong_apningstider FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Salon owners can manage their apningstider" ON public.salong_apningstider FOR ALL
USING (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()))
WITH CHECK (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()));

-- 5.8 RLS Policies - salong_apningstider_unntak
CREATE POLICY "Everyone can view apningstider_unntak" ON public.salong_apningstider_unntak FOR SELECT USING (true);
CREATE POLICY "Admins can manage apningstider_unntak" ON public.salong_apningstider_unntak FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Salon owners can manage their unntak" ON public.salong_apningstider_unntak FOR ALL
USING (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()))
WITH CHECK (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()));

-- 5.9 RLS Policies - ansatt_turnus
CREATE POLICY "Users can view their own turnus" ON public.ansatt_turnus FOR SELECT USING (user_id = auth.uid());
CREATE POLICY "Users can view turnus in their salon" ON public.ansatt_turnus FOR SELECT
USING (salon_id = get_user_salon_id(auth.uid()));
CREATE POLICY "Admins can manage all turnus" ON public.ansatt_turnus FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Salon owners can manage their turnus" ON public.ansatt_turnus FOR ALL
USING (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()))
WITH CHECK (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()));

-- 5.10 RLS Policies - turnus_skift
CREATE POLICY "Users can view their own skift" ON public.turnus_skift FOR SELECT USING (user_id = auth.uid());
CREATE POLICY "Users can view skift in their salon" ON public.turnus_skift FOR SELECT
USING (salon_id = get_user_salon_id(auth.uid()));
CREATE POLICY "Admins can manage all skift" ON public.turnus_skift FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Salon owners can manage their skift" ON public.turnus_skift FOR ALL
USING (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()))
WITH CHECK (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()));

-- 5.11 RLS Policies - turnus_preferanser
CREATE POLICY "Users can manage their own preferanser" ON public.turnus_preferanser FOR ALL
USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE POLICY "Admins can view all preferanser" ON public.turnus_preferanser FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Salon owners can view their employees preferanser" ON public.turnus_preferanser FOR SELECT
USING (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()));

-- 5.12 Triggers for updated_at
CREATE TRIGGER update_salong_apningstider_updated_at BEFORE UPDATE ON public.salong_apningstider
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_ansatt_turnus_updated_at BEFORE UPDATE ON public.ansatt_turnus
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_turnus_skift_updated_at BEFORE UPDATE ON public.turnus_skift
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 5.13 Hjelpefunksjon: Hent timer for en ansatt på en gitt dag
CREATE OR REPLACE FUNCTION public.get_turnus_timer_for_dag(p_user_id uuid, p_dato date)
RETURNS numeric
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COALESCE(
    (SELECT timer_planlagt FROM turnus_skift WHERE user_id = p_user_id AND dato = p_dato),
    (SELECT EXTRACT(EPOCH FROM (slutt_tid - start_tid)) / 3600
     FROM ansatt_turnus 
     WHERE user_id = p_user_id 
       AND ukedag = EXTRACT(ISODOW FROM p_dato)::integer
       AND gyldig_fra <= p_dato 
       AND (gyldig_til IS NULL OR gyldig_til >= p_dato)
       AND NOT fridag
       AND (uke_type = 'alle' 
            OR (uke_type = 'partall' AND EXTRACT(WEEK FROM p_dato)::integer % 2 = 0)
            OR (uke_type = 'oddetall' AND EXTRACT(WEEK FROM p_dato)::integer % 2 = 1))
     LIMIT 1),
    0
  )::numeric
$$;

-- 5.14 Hjelpefunksjon: Sjekk om salong er åpen på en gitt dag
CREATE OR REPLACE FUNCTION public.er_salong_apen(p_salon_id uuid, p_dato date)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT CASE
    -- Først sjekk unntak
    WHEN EXISTS (SELECT 1 FROM salong_apningstider_unntak WHERE salon_id = p_salon_id AND dato = p_dato AND stengt = true) THEN false
    WHEN EXISTS (SELECT 1 FROM salong_apningstider_unntak WHERE salon_id = p_salon_id AND dato = p_dato AND stengt = false) THEN true
    -- Så sjekk standard åpningstider
    WHEN EXISTS (SELECT 1 FROM salong_apningstider WHERE salon_id = p_salon_id AND ukedag = EXTRACT(ISODOW FROM p_dato)::integer AND stengt = true) THEN false
    WHEN EXISTS (SELECT 1 FROM salong_apningstider WHERE salon_id = p_salon_id AND ukedag = EXTRACT(ISODOW FROM p_dato)::integer AND stengt = false) THEN true
    -- Default: åpent på hverdager
    ELSE EXTRACT(ISODOW FROM p_dato)::integer NOT IN (6, 7)
  END
$$;