
-- Fix security definer view by recreating with SECURITY INVOKER (default)
DROP VIEW IF EXISTS public.ansatte_utvidet;

CREATE VIEW public.ansatte_utvidet WITH (security_invoker = true) AS
SELECT a.*,
  COALESCE(a.fornavn, '') || ' ' || COALESCE(a.etternavn, '') AS navn,
  CASE WHEN a.fodselsdato IS NOT NULL THEN EXTRACT(YEAR FROM age(CURRENT_DATE, a.fodselsdato))::INTEGER ELSE NULL END AS alder,
  CASE WHEN a.ansatt_dato IS NOT NULL THEN EXTRACT(YEAR FROM age(CURRENT_DATE, a.ansatt_dato))::NUMERIC ELSE NULL END AS ansiennitet_aar,
  CASE WHEN a.ansatt_dato IS NOT NULL THEN (EXTRACT(MONTH FROM age(CURRENT_DATE, a.ansatt_dato)))::INTEGER ELSE NULL END AS ansiennitet_maneder,
  CASE WHEN a.provetid_til IS NOT NULL AND a.provetid_til > CURRENT_DATE THEN 'Prøvetid' ELSE a.status::TEXT END AS status_display,
  CASE 
    WHEN a.frisorfunksjon IS NOT NULL AND a.lederstilling IS NOT NULL THEN
      CASE a.frisorfunksjon WHEN 'frisor' THEN 'Frisør' WHEN 'senior_frisor' THEN 'Senior Frisør' WHEN 'laerling' THEN 'Lærling' END || ' + ' ||
      CASE a.lederstilling WHEN 'daglig_leder' THEN 'Daglig leder' WHEN 'avdelingsleder' THEN 'Avdelingsleder' WHEN 'styreleder' THEN 'Styreleder' END
    WHEN a.frisorfunksjon IS NOT NULL THEN CASE a.frisorfunksjon WHEN 'frisor' THEN 'Frisør' WHEN 'senior_frisor' THEN 'Senior Frisør' WHEN 'laerling' THEN 'Lærling' END
    WHEN a.lederstilling IS NOT NULL THEN CASE a.lederstilling WHEN 'daglig_leder' THEN 'Daglig leder' WHEN 'avdelingsleder' THEN 'Avdelingsleder' WHEN 'styreleder' THEN 'Styreleder' END
    ELSE 'Ingen rolle'
  END AS rolle_display,
  CASE WHEN a.fodselsdato IS NOT NULL THEN TO_CHAR(a.fodselsdato, 'MM-DD') ELSE NULL END AS bursdag_md,
  s.name AS salong_navn
FROM public.ansatte a LEFT JOIN public.salons s ON a.salong_id = s.id;
