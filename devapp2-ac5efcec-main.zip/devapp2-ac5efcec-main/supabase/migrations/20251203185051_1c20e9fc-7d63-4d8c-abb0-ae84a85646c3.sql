-- Fase 7: Tariff-modul (komplett)

-- 7.1 Fagbrev status enum
CREATE TYPE fagbrev_status AS ENUM ('uten_fagbrev', 'med_fagbrev', 'mester');

-- 7.2 Tariff maler (sentrale maler fra admin)
CREATE TABLE public.tariff_maler (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  aar integer NOT NULL,
  navn text NOT NULL DEFAULT 'Standard tariff',
  fagbrev_status fagbrev_status NOT NULL,
  ansiennitet_min integer NOT NULL DEFAULT 0,
  ansiennitet_max integer,
  timesats numeric(10,2) NOT NULL,
  maanedslonn numeric(12,2),
  gyldig_fra date NOT NULL DEFAULT CURRENT_DATE,
  gyldig_til date,
  beskrivelse text,
  opprettet_av uuid REFERENCES public.users(id),
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now(),
  UNIQUE(aar, fagbrev_status, ansiennitet_min)
);

CREATE INDEX idx_tariff_maler_aar ON public.tariff_maler(aar);

-- 7.3 Tariff satser (salong-spesifikke)
CREATE TABLE public.tariff_satser (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  salon_id uuid NOT NULL REFERENCES public.salons(id) ON DELETE CASCADE,
  aar integer NOT NULL,
  fagbrev_status fagbrev_status NOT NULL,
  ansiennitet_min integer NOT NULL DEFAULT 0,
  ansiennitet_max integer,
  timesats numeric(10,2) NOT NULL,
  maanedslonn numeric(12,2),
  kilde_mal_id uuid REFERENCES public.tariff_maler(id),
  avvik_fra_mal numeric(10,2) DEFAULT 0,
  gyldig_fra date NOT NULL DEFAULT CURRENT_DATE,
  beskrivelse text,
  opprettet_av uuid REFERENCES public.users(id),
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now(),
  UNIQUE(salon_id, aar, fagbrev_status, ansiennitet_min)
);

CREATE INDEX idx_tariff_satser_salon ON public.tariff_satser(salon_id);

-- 7.4 Tariff implementeringer
CREATE TABLE public.tariff_implementeringer (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  salon_id uuid NOT NULL REFERENCES public.salons(id) ON DELETE CASCADE,
  mal_id uuid NOT NULL REFERENCES public.tariff_maler(id) ON DELETE CASCADE,
  implementert_dato date NOT NULL DEFAULT CURRENT_DATE,
  implementert_av uuid REFERENCES public.users(id),
  created_at timestamp with time zone DEFAULT now(),
  UNIQUE(salon_id, mal_id)
);

-- 7.5 Enable RLS
ALTER TABLE public.tariff_maler ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tariff_satser ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tariff_implementeringer ENABLE ROW LEVEL SECURITY;

-- 7.6 RLS Policies - tariff_maler
CREATE POLICY "Everyone can view tariff_maler" ON public.tariff_maler FOR SELECT USING (true);
CREATE POLICY "Admins can manage tariff_maler" ON public.tariff_maler FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- 7.7 RLS Policies - tariff_satser
CREATE POLICY "Users can view salon tariff_satser" ON public.tariff_satser FOR SELECT
USING (salon_id = get_user_salon_id(auth.uid()) OR has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Admins can manage all tariff_satser" ON public.tariff_satser FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Salon owners can manage tariff_satser" ON public.tariff_satser FOR ALL
USING (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()))
WITH CHECK (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()));

-- 7.8 RLS Policies - tariff_implementeringer
CREATE POLICY "Users can view salon implementeringer" ON public.tariff_implementeringer FOR SELECT
USING (salon_id = get_user_salon_id(auth.uid()) OR has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Admins can manage implementeringer" ON public.tariff_implementeringer FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Salon owners can manage implementeringer" ON public.tariff_implementeringer FOR ALL
USING (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()))
WITH CHECK (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()));

-- 7.9 Triggers
CREATE TRIGGER update_tariff_maler_updated_at BEFORE UPDATE ON public.tariff_maler
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_tariff_satser_updated_at BEFORE UPDATE ON public.tariff_satser
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 7.10 Hjelpefunksjon: Beregn månedslønn fra timesats
CREATE OR REPLACE FUNCTION public.beregn_maanedslonn(p_timesats numeric, p_stillingsprosent numeric DEFAULT 100)
RETURNS numeric
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT (p_timesats * 162.5 * (p_stillingsprosent / 100))::numeric(12,2)
$$;