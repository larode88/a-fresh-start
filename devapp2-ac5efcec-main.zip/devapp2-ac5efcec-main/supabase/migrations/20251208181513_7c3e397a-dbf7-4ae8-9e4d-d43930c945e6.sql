-- Extend turnus_uke_type enum with 3-week and 4-week support
ALTER TYPE turnus_uke_type ADD VALUE IF NOT EXISTS 'uke1';
ALTER TYPE turnus_uke_type ADD VALUE IF NOT EXISTS 'uke2';
ALTER TYPE turnus_uke_type ADD VALUE IF NOT EXISTS 'uke3';
ALTER TYPE turnus_uke_type ADD VALUE IF NOT EXISTS 'uke4';