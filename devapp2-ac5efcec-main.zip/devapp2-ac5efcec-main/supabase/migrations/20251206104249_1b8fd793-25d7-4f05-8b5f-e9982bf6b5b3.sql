-- Fix security: Remove public access to hubspot_owner_district_mapping
-- This table contains employee emails and CRM identifiers that should not be publicly accessible

-- Drop the overly permissive public policy
DROP POLICY IF EXISTS "Everyone can view hubspot owner mapping" ON public.hubspot_owner_district_mapping;

-- Create a new policy that restricts access to authenticated users only
CREATE POLICY "Authenticated users can view hubspot owner mapping"
ON public.hubspot_owner_district_mapping
FOR SELECT
TO authenticated
USING (auth.uid() IS NOT NULL);