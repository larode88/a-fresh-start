-- Add health insurance price field to users table
ALTER TABLE public.users 
ADD COLUMN IF NOT EXISTS helseforsikring_pris numeric DEFAULT NULL;

-- Add comment for documentation
COMMENT ON COLUMN public.users.helseforsikring_pris IS 'Annual health insurance price per person, synced from HubSpot';