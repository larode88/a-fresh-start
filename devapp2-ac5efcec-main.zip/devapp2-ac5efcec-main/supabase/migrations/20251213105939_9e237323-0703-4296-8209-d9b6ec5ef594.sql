-- Add columns for controlling inclusion in schedule and budget
ALTER TABLE public.ansatte 
ADD COLUMN IF NOT EXISTS inkluder_i_turnus boolean DEFAULT true,
ADD COLUMN IF NOT EXISTS inkluder_i_budsjett boolean DEFAULT true;

-- Add comment for documentation
COMMENT ON COLUMN public.ansatte.inkluder_i_turnus IS 'Whether to include employee in schedule planning. Auto-true for frisorfunksjon, configurable for leaders-only.';
COMMENT ON COLUMN public.ansatte.inkluder_i_budsjett IS 'Whether to include employee in budget calculations. Auto-true for frisorfunksjon, configurable for leaders-only.';

-- Update ansatte_utvidet view to include new columns
DROP VIEW IF EXISTS public.ansatte_utvidet;

CREATE VIEW public.ansatte_utvidet AS
SELECT 
  a.*,
  -- Calculated fields
  EXTRACT(YEAR FROM age(CURRENT_DATE, a.fodselsdato))::integer AS alder,
  EXTRACT(YEAR FROM age(CURRENT_DATE, COALESCE(a.fagbrev_dato, a.ansatt_dato)))::numeric AS ansiennitet_aar,
  CASE 
    WHEN a.provetid_til IS NOT NULL AND a.provetid_til >= CURRENT_DATE THEN true
    ELSE false
  END AS i_provetid,
  CASE 
    WHEN a.status = 'Aktiv' AND a.provetid_til IS NOT NULL AND a.provetid_til >= CURRENT_DATE 
    THEN a.provetid_til - CURRENT_DATE
    ELSE NULL
  END AS dager_til_provetid_slutt,
  -- Effective inclusion (frisorfunksjon overrides manual setting)
  CASE 
    WHEN a.frisorfunksjon IS NOT NULL THEN true
    ELSE COALESCE(a.inkluder_i_turnus, false)
  END AS effektiv_inkluder_i_turnus,
  CASE 
    WHEN a.frisorfunksjon IS NOT NULL THEN true
    ELSE COALESCE(a.inkluder_i_budsjett, false)
  END AS effektiv_inkluder_i_budsjett
FROM public.ansatte a;