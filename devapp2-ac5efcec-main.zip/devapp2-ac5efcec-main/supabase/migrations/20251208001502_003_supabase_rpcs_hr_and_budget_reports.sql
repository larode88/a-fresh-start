-- RPC Functions for HR and Budget Reporting
-- These functions provide business logic and reporting capabilities

-- Function: Get vacation days remaining for an employee
CREATE OR REPLACE FUNCTION get_vacation_days_remaining(
  p_user_id UUID,
  p_year INTEGER DEFAULT EXTRACT(YEAR FROM CURRENT_DATE)::INTEGER
)
RETURNS TABLE (
  total_days NUMERIC,
  used_days NUMERIC,
  remaining_days NUMERIC,
  pending_days NUMERIC
) AS $$
BEGIN
  RETURN QUERY
  WITH vacation_summary AS (
    SELECT 
      COALESCE(SUM(antall_dager) FILTER (WHERE status IN ('godkjent', 'avviklet')), 0) as used,
      COALESCE(SUM(antall_dager) FILTER (WHERE status = 'planlagt'), 0) as pending
    FROM ferie
    WHERE user_id = p_user_id AND aar = p_year
  ),
  employee_info AS (
    SELECT 
      COALESCE(stillingsprosent, 100) as stillingsprosent
    FROM users
    WHERE id = p_user_id
  )
  SELECT 
    (25 * (ei.stillingsprosent / 100.0))::NUMERIC as total_days,
    vs.used as used_days,
    (25 * (ei.stillingsprosent / 100.0) - vs.used)::NUMERIC as remaining_days,
    vs.pending as pending_days
  FROM vacation_summary vs, employee_info ei;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function: Get budget summary for a salon and version
CREATE OR REPLACE FUNCTION get_budget_summary(
  p_salon_id UUID,
  p_versjon_id UUID,
  p_start_date DATE DEFAULT NULL,
  p_end_date DATE DEFAULT NULL
)
RETURNS TABLE (
  total_behandling NUMERIC,
  total_vare NUMERIC,
  total_budget NUMERIC,
  total_planlagte_timer NUMERIC,
  total_kundetimer NUMERIC,
  avg_omsetning_per_time NUMERIC,
  employee_count BIGINT
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    COALESCE(SUM(b.behandling_budsjett), 0) as total_behandling,
    COALESCE(SUM(b.vare_budsjett), 0) as total_vare,
    COALESCE(SUM(b.totalt_budsjett), 0) as total_budget,
    COALESCE(SUM(b.planlagte_timer), 0) as total_planlagte_timer,
    COALESCE(SUM(b.kundetimer), 0) as total_kundetimer,
    CASE 
      WHEN SUM(b.kundetimer) > 0 
      THEN SUM(b.totalt_budsjett) / SUM(b.kundetimer)
      ELSE 0 
    END as avg_omsetning_per_time,
    COUNT(DISTINCT b.user_id) as employee_count
  FROM budsjett b
  WHERE b.salon_id = p_salon_id
    AND b.versjon_id = p_versjon_id
    AND (p_start_date IS NULL OR b.dato >= p_start_date)
    AND (p_end_date IS NULL OR b.dato <= p_end_date);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function: Get shift hours for employee in period
CREATE OR REPLACE FUNCTION get_shift_hours_summary(
  p_user_id UUID,
  p_start_date DATE,
  p_end_date DATE
)
RETURNS TABLE (
  total_shifts BIGINT,
  total_planned_hours NUMERIC,
  avg_hours_per_shift NUMERIC,
  days_worked BIGINT
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    COUNT(*)::BIGINT as total_shifts,
    COALESCE(SUM(timer_planlagt), 0) as total_planned_hours,
    CASE 
      WHEN COUNT(*) > 0 
      THEN COALESCE(SUM(timer_planlagt), 0) / COUNT(*)
      ELSE 0 
    END as avg_hours_per_shift,
    COUNT(DISTINCT dato)::BIGINT as days_worked
  FROM turnus_skift
  WHERE user_id = p_user_id
    AND dato BETWEEN p_start_date AND p_end_date;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function: Get goal progress for an employee
CREATE OR REPLACE FUNCTION get_goal_progress(
  p_user_id UUID,
  p_active_only BOOLEAN DEFAULT true
)
RETURNS TABLE (
  goal_id UUID,
  goal_type TEXT,
  goal_description TEXT,
  target_value NUMERIC,
  current_value NUMERIC,
  progress_percent NUMERIC,
  status TEXT,
  periode_start DATE,
  periode_slutt DATE
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    am.id as goal_id,
    am.mal_type as goal_type,
    am.mal_beskrivelse as goal_description,
    am.mal_verdi as target_value,
    am.oppnaadd_verdi as current_value,
    CASE 
      WHEN am.mal_verdi IS NOT NULL AND am.mal_verdi > 0 AND am.oppnaadd_verdi IS NOT NULL
      THEN (am.oppnaadd_verdi / am.mal_verdi * 100)::NUMERIC
      ELSE 0
    END as progress_percent,
    am.status,
    am.periode_start,
    am.periode_slutt
  FROM ansatt_mal am
  WHERE am.user_id = p_user_id
    AND (NOT p_active_only OR am.status = 'aktiv')
  ORDER BY am.periode_start DESC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function: Get current salary for employee
CREATE OR REPLACE FUNCTION get_current_salary(
  p_user_id UUID
)
RETURNS TABLE (
  timesats NUMERIC,
  fastlonn NUMERIC,
  stillingsprosent NUMERIC,
  gyldig_fra DATE,
  maanedslonn NUMERIC
) AS $$
BEGIN
  RETURN QUERY
  WITH current_salary AS (
    SELECT 
      lh.timesats,
      lh.fastlonn,
      lh.stillingsprosent,
      lh.gyldig_fra
    FROM lonn_historikk lh
    WHERE lh.user_id = p_user_id
      AND lh.gyldig_fra <= CURRENT_DATE
      AND (lh.gyldig_til IS NULL OR lh.gyldig_til >= CURRENT_DATE)
    ORDER BY lh.gyldig_fra DESC
    LIMIT 1
  )
  SELECT 
    cs.timesats,
    cs.fastlonn,
    cs.stillingsprosent,
    cs.gyldig_fra,
    CASE 
      WHEN cs.fastlonn IS NOT NULL THEN cs.fastlonn
      WHEN cs.timesats IS NOT NULL AND cs.stillingsprosent IS NOT NULL
      THEN (cs.timesats * 162.5 * (cs.stillingsprosent / 100))::NUMERIC
      ELSE 0
    END as maanedslonn
  FROM current_salary cs;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function: Get employee count by salon
CREATE OR REPLACE FUNCTION get_employee_count_by_salon(
  p_salon_id UUID,
  p_active_only BOOLEAN DEFAULT true
)
RETURNS TABLE (
  total_employees BIGINT,
  stylists BIGINT,
  apprentices BIGINT,
  managers BIGINT,
  avg_employment_percent NUMERIC
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    COUNT(*)::BIGINT as total_employees,
    COUNT(*) FILTER (WHERE role IN ('stylist', 'seniorfrisor'))::BIGINT as stylists,
    COUNT(*) FILTER (WHERE role = 'apprentice')::BIGINT as apprentices,
    COUNT(*) FILTER (WHERE role IN ('daglig_leder', 'avdelingsleder', 'salon_owner'))::BIGINT as managers,
    COALESCE(AVG(stillingsprosent), 0) as avg_employment_percent
  FROM users
  WHERE salon_id = p_salon_id
    AND (NOT p_active_only OR aktiv = true);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function: Get absence summary for employee
CREATE OR REPLACE FUNCTION get_absence_summary(
  p_user_id UUID,
  p_year INTEGER DEFAULT EXTRACT(YEAR FROM CURRENT_DATE)::INTEGER
)
RETURNS TABLE (
  total_days NUMERIC,
  sick_leave_days NUMERIC,
  other_leave_days NUMERIC,
  unpaid_leave_days NUMERIC,
  parental_leave_days NUMERIC
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    COALESCE(SUM(EXTRACT(DAY FROM (sluttdato - startdato + 1))), 0) as total_days,
    COALESCE(SUM(EXTRACT(DAY FROM (sluttdato - startdato + 1))) FILTER (WHERE fravaerstype IN ('egenmelding', 'sykmelding')), 0) as sick_leave_days,
    COALESCE(SUM(EXTRACT(DAY FROM (sluttdato - startdato + 1))) FILTER (WHERE fravaerstype = 'annet'), 0) as other_leave_days,
    COALESCE(SUM(EXTRACT(DAY FROM (sluttdato - startdato + 1))) FILTER (WHERE fravaerstype = 'ulonnet_permisjon'), 0) as unpaid_leave_days,
    COALESCE(SUM(EXTRACT(DAY FROM (sluttdato - startdato + 1))) FILTER (WHERE fravaerstype = 'foreldrepermisjon'), 0) as parental_leave_days
  FROM fravaer
  WHERE user_id = p_user_id
    AND EXTRACT(YEAR FROM startdato) = p_year;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function: Get budget vs actual comparison (placeholder for historical data integration)
CREATE OR REPLACE FUNCTION get_budget_vs_actual(
  p_salon_id UUID,
  p_versjon_id UUID,
  p_month INTEGER,
  p_year INTEGER
)
RETURNS TABLE (
  budgeted_treatment NUMERIC,
  budgeted_retail NUMERIC,
  budgeted_total NUMERIC,
  actual_treatment NUMERIC,
  actual_retail NUMERIC,
  actual_total NUMERIC,
  variance_percent NUMERIC
) AS $$
BEGIN
  RETURN QUERY
  WITH budget_data AS (
    SELECT 
      COALESCE(SUM(behandling_budsjett), 0) as bud_treatment,
      COALESCE(SUM(vare_budsjett), 0) as bud_retail,
      COALESCE(SUM(totalt_budsjett), 0) as bud_total
    FROM budsjett
    WHERE salon_id = p_salon_id
      AND versjon_id = p_versjon_id
      AND maned = p_month
      AND aar = p_year
  ),
  actual_data AS (
    SELECT 
      COALESCE(SUM(behandling_kr), 0) as act_treatment,
      COALESCE(SUM(vare_kr), 0) as act_retail,
      COALESCE(SUM(total_kr), 0) as act_total
    FROM historiske_tall
    WHERE salon_id = p_salon_id
      AND maned = p_month
      AND aar = p_year
  )
  SELECT 
    bd.bud_treatment,
    bd.bud_retail,
    bd.bud_total,
    ad.act_treatment,
    ad.act_retail,
    ad.act_total,
    CASE 
      WHEN bd.bud_total > 0 
      THEN ((ad.act_total - bd.bud_total) / bd.bud_total * 100)::NUMERIC
      ELSE 0 
    END as variance_percent
  FROM budget_data bd, actual_data ad;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Grant execute permissions to authenticated users
GRANT EXECUTE ON FUNCTION get_vacation_days_remaining TO authenticated;
GRANT EXECUTE ON FUNCTION get_budget_summary TO authenticated;
GRANT EXECUTE ON FUNCTION get_shift_hours_summary TO authenticated;
GRANT EXECUTE ON FUNCTION get_goal_progress TO authenticated;
GRANT EXECUTE ON FUNCTION get_current_salary TO authenticated;
GRANT EXECUTE ON FUNCTION get_employee_count_by_salon TO authenticated;
GRANT EXECUTE ON FUNCTION get_absence_summary TO authenticated;
GRANT EXECUTE ON FUNCTION get_budget_vs_actual TO authenticated;

-- Add helpful comments
COMMENT ON FUNCTION get_vacation_days_remaining IS 'Returns vacation days total, used, remaining and pending for an employee';
COMMENT ON FUNCTION get_budget_summary IS 'Returns aggregated budget summary for a salon and version';
COMMENT ON FUNCTION get_shift_hours_summary IS 'Returns shift hours statistics for an employee in a date range';
COMMENT ON FUNCTION get_goal_progress IS 'Returns goal progress for an employee with percentage completion';
COMMENT ON FUNCTION get_current_salary IS 'Returns current active salary information for an employee';
COMMENT ON FUNCTION get_employee_count_by_salon IS 'Returns employee statistics grouped by role for a salon';
COMMENT ON FUNCTION get_absence_summary IS 'Returns absence days breakdown by type for an employee';
COMMENT ON FUNCTION get_budget_vs_actual IS 'Compares budgeted vs actual performance for a period';
