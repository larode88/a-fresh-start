-- Add first_name and last_name columns to users table
ALTER TABLE public.users 
ADD COLUMN IF NOT EXISTS first_name text,
ADD COLUMN IF NOT EXISTS last_name text;

-- Migrate existing name data to first_name/last_name (split on first space)
UPDATE public.users 
SET 
  first_name = CASE 
    WHEN name IS NOT NULL AND position(' ' IN name) > 0 
    THEN split_part(name, ' ', 1)
    ELSE name
  END,
  last_name = CASE 
    WHEN name IS NOT NULL AND position(' ' IN name) > 0 
    THEN substring(name from position(' ' IN name) + 1)
    ELSE NULL
  END
WHERE first_name IS NULL;