
-- =====================================================
-- FASE 1: DATABASE-FUNDAMENT FOR MEDLEMSADMIN
-- =====================================================

-- =====================================================
-- DEL 1: ENUMS (6 stk)
-- =====================================================

-- Pipeline-status for prospekter
CREATE TYPE prospekt_pipeline_status AS ENUM (
  'identifisert',
  'kontaktet', 
  'forste_mote',
  'pagaende_dialog',
  'forhandling',
  'klar_for_innmelding',
  'vunnet',
  'tapt'
);

-- Sannsynlighet for konvertering
CREATE TYPE prospekt_sannsynlighet AS ENUM ('lav', 'medium', 'stor');

-- Signerings-status (tilpasset Docsign.se)
CREATE TYPE avtale_signerings_status AS ENUM (
  'utkast',
  'sendt',
  'apnet',
  'signert',
  'fullfort',
  'avvist',
  'utlopt'
);

-- Type Medlemskap
CREATE TYPE type_medlemskap AS ENUM (
  'salong',
  'skole',
  'stol',
  'hjemmesalong',
  'barber'
);

-- Medlemsstatus
CREATE TYPE medlemsstatus_enum AS ENUM (
  'utkast',
  'venter_signering',
  'aktiv',
  'pause',
  'oppsigelse',
  'avsluttet'
);

-- CRM aktivitetstyper
CREATE TYPE crm_aktivitet_type AS ENUM (
  'notat',
  'oppgave',
  'mote',
  'telefon',
  'epost'
);

-- =====================================================
-- DEL 2: UTVIDELSER TIL EKSISTERENDE TABELLER
-- =====================================================

-- Utvide salons med medlemsfelter (16 nye kolonner)
ALTER TABLE public.salons 
  ADD COLUMN IF NOT EXISTS type_medlemskap type_medlemskap,
  ADD COLUMN IF NOT EXISTS medlemsnummer text,
  ADD COLUMN IF NOT EXISTS medlemsavgift numeric DEFAULT 0,
  ADD COLUMN IF NOT EXISTS innmeldt_dato date,
  ADD COLUMN IF NOT EXISTS oppsigelse_dato date,
  ADD COLUMN IF NOT EXISTS avsluttet_dato date,
  ADD COLUMN IF NOT EXISTS oppsigelse_arsak text,
  ADD COLUMN IF NOT EXISTS eierskap text,
  ADD COLUMN IF NOT EXISTS arlig_omsetning numeric,
  ADD COLUMN IF NOT EXISTS siste_kontakt_dato date,
  ADD COLUMN IF NOT EXISTS neste_kontakt_dato date,
  ADD COLUMN IF NOT EXISTS trenger_oppfolging boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS onboarding_fullfort_at timestamptz,
  ADD COLUMN IF NOT EXISTS tripletex_kunde_id text,
  ADD COLUMN IF NOT EXISTS tripletex_synced_at timestamptz;

-- Utvide salon_suppliers med avtaleinformasjon (4 nye kolonner)
ALTER TABLE public.salon_suppliers
  ADD COLUMN IF NOT EXISTS avtale_startdato date,
  ADD COLUMN IF NOT EXISTS avtale_sluttdato date,
  ADD COLUMN IF NOT EXISTS bonusstruktur text,
  ADD COLUMN IF NOT EXISTS spesialavtale_detaljer text;

-- =====================================================
-- DEL 3: NYE TABELLER (7 stk)
-- =====================================================

-- 1. Prospekter - Pipeline for leads/muligheter
CREATE TABLE public.prospekter (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  salongnavn text NOT NULL,
  org_nummer text,
  kontaktperson_navn text,
  kontaktperson_epost text,
  kontaktperson_telefon text,
  adresse text,
  postnummer text,
  sted text,
  district_id uuid REFERENCES public.districts(id),
  distriktssjef_id uuid REFERENCES public.users(id),
  pipeline_status prospekt_pipeline_status NOT NULL DEFAULT 'identifisert',
  sannsynlighet prospekt_sannsynlighet DEFAULT 'medium',
  forventet_innmeldingsdato date,
  estimert_medlemsavgift numeric,
  type_medlemskap type_medlemskap,
  kilde text,
  eksisterende_tjenester text,
  notater text,
  tapt_arsak text,
  konvertert_til_salon_id uuid REFERENCES public.salons(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  archived_at timestamptz
);

-- 2. Prospekt-aktiviteter - CRM-logg for prospekter
CREATE TABLE public.prospekt_aktiviteter (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  prospekt_id uuid NOT NULL REFERENCES public.prospekter(id) ON DELETE CASCADE,
  type crm_aktivitet_type NOT NULL,
  beskrivelse text NOT NULL,
  utfort_av uuid REFERENCES public.users(id),
  forfallsdato date,
  fullfort_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- 3. Portal-moduler - Master-liste over tilgjengelige moduler
CREATE TABLE public.portal_moduler (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  navn text NOT NULL UNIQUE,
  beskrivelse text,
  ikon text,
  er_aktiv boolean DEFAULT true,
  rekkefolge integer DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 4. Salon-moduler - Hvilke moduler er aktivert per salong
CREATE TABLE public.salon_moduler (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  salon_id uuid NOT NULL REFERENCES public.salons(id) ON DELETE CASCADE,
  modul_id uuid NOT NULL REFERENCES public.portal_moduler(id) ON DELETE CASCADE,
  aktivert_av uuid REFERENCES public.users(id),
  aktivert_dato timestamptz NOT NULL DEFAULT now(),
  deaktivert_dato timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(salon_id, modul_id)
);

-- 5. Medlemsavtaler - Avtalehåndtering med Docsign.se
CREATE TABLE public.medlemsavtaler (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  salon_id uuid NOT NULL REFERENCES public.salons(id) ON DELETE CASCADE,
  avtale_type text NOT NULL DEFAULT 'medlemsavtale',
  avtale_pdf_url text,
  signert_pdf_url text,
  signerings_metode text DEFAULT 'digital',
  signerings_status avtale_signerings_status NOT NULL DEFAULT 'utkast',
  docsign_dokument_id text,
  docsign_signerings_url text,
  sendt_til_signering_at timestamptz,
  apnet_at timestamptz,
  signert_at timestamptz,
  signert_av_navn text,
  signert_av_personnummer text,
  paaminnelse_sendt_at timestamptz,
  utloper_at timestamptz,
  generert_fra_wizard_data jsonb,
  opprettet_av uuid REFERENCES public.users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 6. Medlem-kontaktpersoner - Kontaktpersoner utover users
CREATE TABLE public.medlem_kontaktpersoner (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  salon_id uuid NOT NULL REFERENCES public.salons(id) ON DELETE CASCADE,
  navn text NOT NULL,
  rolle text,
  epost text,
  telefon text,
  er_primaer_kontakt boolean DEFAULT false,
  hubspot_contact_id text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 7. Medlem-oppfølginger - CRM-aktiviteter for medlemmer
CREATE TABLE public.medlem_oppfolginger (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  salon_id uuid NOT NULL REFERENCES public.salons(id) ON DELETE CASCADE,
  type crm_aktivitet_type NOT NULL,
  beskrivelse text NOT NULL,
  utfort_av uuid REFERENCES public.users(id),
  tilordnet_til uuid REFERENCES public.users(id),
  forfallsdato date,
  fullfort_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- =====================================================
-- DEL 4: INDEKSER
-- =====================================================

CREATE INDEX idx_prospekter_district ON public.prospekter(district_id);
CREATE INDEX idx_prospekter_distriktssjef ON public.prospekter(distriktssjef_id);
CREATE INDEX idx_prospekter_pipeline_status ON public.prospekter(pipeline_status);
CREATE INDEX idx_prospekter_archived ON public.prospekter(archived_at) WHERE archived_at IS NULL;
CREATE INDEX idx_prospekt_aktiviteter_prospekt ON public.prospekt_aktiviteter(prospekt_id);
CREATE INDEX idx_salon_moduler_salon ON public.salon_moduler(salon_id);
CREATE INDEX idx_medlemsavtaler_salon ON public.medlemsavtaler(salon_id);
CREATE INDEX idx_medlemsavtaler_status ON public.medlemsavtaler(signerings_status);
CREATE INDEX idx_medlem_kontaktpersoner_salon ON public.medlem_kontaktpersoner(salon_id);
CREATE INDEX idx_medlem_oppfolginger_salon ON public.medlem_oppfolginger(salon_id);
CREATE INDEX idx_medlem_oppfolginger_forfallsdato ON public.medlem_oppfolginger(forfallsdato) WHERE fullfort_at IS NULL;
CREATE INDEX idx_salons_type_medlemskap ON public.salons(type_medlemskap);
CREATE INDEX idx_salons_trenger_oppfolging ON public.salons(trenger_oppfolging) WHERE trenger_oppfolging = true;

-- =====================================================
-- DEL 5: RLS POLICIES
-- =====================================================

-- Aktiver RLS på alle nye tabeller
ALTER TABLE public.prospekter ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.prospekt_aktiviteter ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.portal_moduler ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.salon_moduler ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.medlemsavtaler ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.medlem_kontaktpersoner ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.medlem_oppfolginger ENABLE ROW LEVEL SECURITY;

-- PROSPEKTER
CREATE POLICY "Admin full tilgang prospekter"
  ON public.prospekter FOR ALL
  USING (has_role(auth.uid(), 'admin'))
  WITH CHECK (has_role(auth.uid(), 'admin'));

CREATE POLICY "DM tilgang egne distrikter prospekter"
  ON public.prospekter FOR ALL
  USING (
    has_role(auth.uid(), 'district_manager') 
    AND district_id = get_user_district_id(auth.uid())
  )
  WITH CHECK (
    has_role(auth.uid(), 'district_manager') 
    AND district_id = get_user_district_id(auth.uid())
  );

-- PROSPEKT_AKTIVITETER
CREATE POLICY "Admin full tilgang prospekt_aktiviteter"
  ON public.prospekt_aktiviteter FOR ALL
  USING (has_role(auth.uid(), 'admin'))
  WITH CHECK (has_role(auth.uid(), 'admin'));

CREATE POLICY "DM tilgang egne prospekt_aktiviteter"
  ON public.prospekt_aktiviteter FOR ALL
  USING (
    has_role(auth.uid(), 'district_manager')
    AND prospekt_id IN (
      SELECT id FROM public.prospekter 
      WHERE district_id = get_user_district_id(auth.uid())
    )
  )
  WITH CHECK (
    has_role(auth.uid(), 'district_manager')
    AND prospekt_id IN (
      SELECT id FROM public.prospekter 
      WHERE district_id = get_user_district_id(auth.uid())
    )
  );

-- PORTAL_MODULER (les for alle autentiserte, admin kan endre)
CREATE POLICY "Alle kan lese portal_moduler"
  ON public.portal_moduler FOR SELECT
  USING (auth.uid() IS NOT NULL);

CREATE POLICY "Admin kan administrere portal_moduler"
  ON public.portal_moduler FOR ALL
  USING (has_role(auth.uid(), 'admin'))
  WITH CHECK (has_role(auth.uid(), 'admin'));

-- SALON_MODULER
CREATE POLICY "Admin full tilgang salon_moduler"
  ON public.salon_moduler FOR ALL
  USING (has_role(auth.uid(), 'admin'))
  WITH CHECK (has_role(auth.uid(), 'admin'));

CREATE POLICY "DM tilgang egne distrikter salon_moduler"
  ON public.salon_moduler FOR ALL
  USING (
    has_role(auth.uid(), 'district_manager')
    AND salon_id IN (SELECT get_district_salon_ids(auth.uid()))
  )
  WITH CHECK (
    has_role(auth.uid(), 'district_manager')
    AND salon_id IN (SELECT get_district_salon_ids(auth.uid()))
  );

CREATE POLICY "Salon owner kan lese egne moduler"
  ON public.salon_moduler FOR SELECT
  USING (salon_id = get_user_salon_id(auth.uid()));

-- MEDLEMSAVTALER
CREATE POLICY "Admin full tilgang medlemsavtaler"
  ON public.medlemsavtaler FOR ALL
  USING (has_role(auth.uid(), 'admin'))
  WITH CHECK (has_role(auth.uid(), 'admin'));

CREATE POLICY "DM tilgang egne distrikter medlemsavtaler"
  ON public.medlemsavtaler FOR ALL
  USING (
    has_role(auth.uid(), 'district_manager')
    AND salon_id IN (SELECT get_district_salon_ids(auth.uid()))
  )
  WITH CHECK (
    has_role(auth.uid(), 'district_manager')
    AND salon_id IN (SELECT get_district_salon_ids(auth.uid()))
  );

CREATE POLICY "Salon owner kan lese egne avtaler"
  ON public.medlemsavtaler FOR SELECT
  USING (salon_id = get_user_salon_id(auth.uid()));

-- MEDLEM_KONTAKTPERSONER
CREATE POLICY "Admin full tilgang medlem_kontaktpersoner"
  ON public.medlem_kontaktpersoner FOR ALL
  USING (has_role(auth.uid(), 'admin'))
  WITH CHECK (has_role(auth.uid(), 'admin'));

CREATE POLICY "DM tilgang egne distrikter medlem_kontaktpersoner"
  ON public.medlem_kontaktpersoner FOR ALL
  USING (
    has_role(auth.uid(), 'district_manager')
    AND salon_id IN (SELECT get_district_salon_ids(auth.uid()))
  )
  WITH CHECK (
    has_role(auth.uid(), 'district_manager')
    AND salon_id IN (SELECT get_district_salon_ids(auth.uid()))
  );

CREATE POLICY "Salon owner kan lese egne kontaktpersoner"
  ON public.medlem_kontaktpersoner FOR SELECT
  USING (salon_id = get_user_salon_id(auth.uid()));

-- MEDLEM_OPPFOLGINGER
CREATE POLICY "Admin full tilgang medlem_oppfolginger"
  ON public.medlem_oppfolginger FOR ALL
  USING (has_role(auth.uid(), 'admin'))
  WITH CHECK (has_role(auth.uid(), 'admin'));

CREATE POLICY "DM tilgang egne distrikter medlem_oppfolginger"
  ON public.medlem_oppfolginger FOR ALL
  USING (
    has_role(auth.uid(), 'district_manager')
    AND salon_id IN (SELECT get_district_salon_ids(auth.uid()))
  )
  WITH CHECK (
    has_role(auth.uid(), 'district_manager')
    AND salon_id IN (SELECT get_district_salon_ids(auth.uid()))
  );

CREATE POLICY "Salon owner kan lese egne oppfølginger"
  ON public.medlem_oppfolginger FOR SELECT
  USING (salon_id = get_user_salon_id(auth.uid()));

-- =====================================================
-- DEL 6: TRIGGERS
-- =====================================================

-- Updated_at triggers for alle nye tabeller
CREATE TRIGGER update_prospekter_updated_at
  BEFORE UPDATE ON public.prospekter
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_portal_moduler_updated_at
  BEFORE UPDATE ON public.portal_moduler
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_medlemsavtaler_updated_at
  BEFORE UPDATE ON public.medlemsavtaler
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_medlem_kontaktpersoner_updated_at
  BEFORE UPDATE ON public.medlem_kontaktpersoner
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Trigger-funksjon for automatisk trenger_oppfolging
CREATE OR REPLACE FUNCTION public.check_trenger_oppfolging()
RETURNS TRIGGER AS $$
BEGIN
  -- Sett trenger_oppfolging = true hvis siste_kontakt_dato er > 45 dager gammel
  IF NEW.siste_kontakt_dato IS NOT NULL THEN
    NEW.trenger_oppfolging := (NEW.siste_kontakt_dato < CURRENT_DATE - INTERVAL '45 days');
  ELSE
    -- Hvis aldri kontaktet og innmeldt, trenger oppfølging
    NEW.trenger_oppfolging := (NEW.innmeldt_dato IS NOT NULL);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

CREATE TRIGGER check_salon_oppfolging
  BEFORE INSERT OR UPDATE OF siste_kontakt_dato, innmeldt_dato ON public.salons
  FOR EACH ROW EXECUTE FUNCTION public.check_trenger_oppfolging();

-- =====================================================
-- DEL 7: SEED-DATA FOR PORTAL_MODULER
-- =====================================================

INSERT INTO public.portal_moduler (navn, beskrivelse, ikon, er_aktiv, rekkefolge) VALUES
  ('HR & Personal', 'Ansattadministrasjon, dokumenter og sertifiseringer', 'Users', true, 1),
  ('Budsjett', 'Budsjettering og målstyring', 'Calculator', true, 2),
  ('KPI & Rapporter', 'Daglige og ukentlige rapporter', 'BarChart3', true, 3),
  ('Forsikring', 'Forsikringsportal og bestillinger', 'Shield', true, 4),
  ('Kurs & Kompetanse', 'Sertifiseringer og opplæring', 'GraduationCap', true, 5),
  ('Pulsundersøkelser', 'Medarbeiderundersøkelser', 'Heart', true, 6),
  ('Sykefravær', 'NAV-oppfølging og sykmelding', 'Activity', true, 7),
  ('Onboarding', 'Ansatt onboarding og offboarding', 'UserPlus', true, 8),
  ('Bonus', 'Leverandørbonus-oversikt', 'Gift', true, 9)
ON CONFLICT (navn) DO NOTHING;
