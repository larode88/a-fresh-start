-- Insert existing email templates from edge functions into the database
-- These are converted from the hardcoded templates in the edge functions

-- 1. Forsikringstilbud til medlem (send-quote-email: send_quote)
INSERT INTO email_templates (name, slug, description, category, status, is_system_template, subject_template, tags, structure)
VALUES (
  'Forsikringstilbud til medlem',
  'insurance-quote-offer',
  'Sendes til salonger med forsikringstilbud fra distriktsleder',
  'forsikring',
  'published',
  true,
  'Forsikringstilbud fra Hår1 – {salongnavn}',
  ARRAY['forsikring', 'tilbud', 'salg'],
  '{
    "modules": [
      {
        "id": "header-1",
        "type": "header-logo",
        "content": {"logoUrl": "/haar1-forsikring-email-logo.png", "alt": "Hår1 Forsikring"},
        "styles": {"backgroundColor": "#FAF8F5", "padding": "32px", "textAlign": "center"}
      },
      {
        "id": "text-1",
        "type": "text",
        "content": {"text": "<p style=\"font-size: 18px;\">Hei {fornavn}! 👋</p><p>Vi setter stor pris på tilliten du viser oss. Basert på samtalen med {distriktsleder} har vi skreddersydd et forsikringsforslag som gir deg og dine ansatte den tryggheten dere fortjener.</p>"},
        "styles": {"padding": "0 0 20px 0"}
      },
      {
        "id": "benefits-1",
        "type": "benefits-list",
        "content": {
          "title": "Som en del av Hår1-fellesskapet får dere:",
          "items": [
            "Skreddersydde forsikringer for frisørbransjen",
            "Konkurransedyktige priser gjennom vårt fellesinnkjøp",
            "Enkel administrasjon – vi tar oss av det praktiske",
            "Personlig oppfølging fra vårt dedikerte forsikringsteam"
          ]
        },
        "styles": {"backgroundColor": "#FAF7F2", "borderRadius": "12px", "padding": "24px", "margin": "24px 0"}
      },
      {
        "id": "table-1",
        "type": "product-table",
        "content": {"title": "Ditt forsikringsforslag", "products": "{produkter}", "totalPrice": "{totalpris}"},
        "styles": {"margin": "32px 0 24px 0"}
      },
      {
        "id": "cta-1",
        "type": "cta-button",
        "content": {"text": "Aksepter tilbudet →", "url": "{aksepter_link}"},
        "styles": {"textAlign": "center", "margin": "32px 0"}
      },
      {
        "id": "text-2",
        "type": "text",
        "content": {"text": "<p style=\"font-size: 13px; color: #888; text-align: center;\">Ved godkjenning blir du ført til signering av fullmakt.</p>"},
        "styles": {}
      },
      {
        "id": "footer-1",
        "type": "footer-signature",
        "content": {"title": "Har du spørsmål? Vi er her for deg!", "signature": "Hår1 Forsikringsteamet", "email": "forsikring@har1.no", "phone": "+47 4000 3345"},
        "styles": {"textAlign": "center", "marginTop": "32px", "padding": "24px"}
      }
    ]
  }'::jsonb
);

-- 2. Tilbud akseptert (admin-varsling)
INSERT INTO email_templates (name, slug, description, category, status, is_system_template, subject_template, tags, structure)
VALUES (
  'Tilbud akseptert - Admin varsling',
  'insurance-quote-accepted-admin',
  'Varsler admin når et tilbud er akseptert (venter på signering)',
  'forsikring',
  'published',
  true,
  'Tilbud akseptert – {salongnavn} (venter på signering)',
  ARRAY['forsikring', 'admin', 'varsling'],
  '{
    "modules": [
      {
        "id": "header-1",
        "type": "header-logo",
        "content": {"logoUrl": "/haar1-forsikring-email-logo.png", "alt": "Hår1 Forsikring"},
        "styles": {"backgroundColor": "#FAF8F5", "padding": "24px", "textAlign": "center"}
      },
      {
        "id": "text-1",
        "type": "text",
        "content": {"text": "<h2 style=\"margin: 0 0 20px 0; color: #8B7355;\">📋 Forsikringstilbud akseptert</h2>"},
        "styles": {}
      },
      {
        "id": "warning-1",
        "type": "warning-banner",
        "content": {"text": "Merk: Medlemmet har akseptert tilbudet, men fullmakten er ennå ikke signert."},
        "styles": {"backgroundColor": "#FFF8E7", "border": "1px solid #F0C36D", "borderRadius": "8px", "padding": "16px", "margin": "20px 0"}
      },
      {
        "id": "info-1",
        "type": "info-box",
        "content": {"items": ["Salongnavn: {salongnavn}", "Org.nummer: {org_nummer}", "Kontaktperson: {kontaktperson}", "E-post: {epost}", "Telefon: {telefon}"]},
        "styles": {"backgroundColor": "#FAF7F2", "borderRadius": "8px", "padding": "20px", "margin": "20px 0"}
      },
      {
        "id": "cta-1",
        "type": "cta-button",
        "content": {"text": "Se tilbud i admin →", "url": "{admin_link}"},
        "styles": {"margin": "24px 0"}
      }
    ]
  }'::jsonb
);

-- 3. Fullmakt signert - bekreftelse til medlem
INSERT INTO email_templates (name, slug, description, category, status, is_system_template, subject_template, tags, structure)
VALUES (
  'Fullmakt signert - Bekreftelse',
  'insurance-poa-signed',
  'Bekreftelse til medlem når fullmakt er signert',
  'forsikring',
  'published',
  true,
  'Velkommen som forsikringskunde! – {salongnavn}',
  ARRAY['forsikring', 'fullmakt', 'bekreftelse'],
  '{
    "modules": [
      {
        "id": "header-1",
        "type": "header-logo",
        "content": {"logoUrl": "/haar1-forsikring-email-logo.png", "alt": "Hår1 Forsikring"},
        "styles": {"backgroundColor": "#FAF8F5", "padding": "32px", "textAlign": "center"}
      },
      {
        "id": "success-1",
        "type": "success-banner",
        "content": {"emoji": "🎉", "title": "Fullmakten er signert!"},
        "styles": {"backgroundColor": "#E8F5E9", "borderRadius": "12px", "padding": "24px 28px", "marginBottom": "28px", "textAlign": "center"}
      },
      {
        "id": "text-1",
        "type": "text",
        "content": {"text": "<p style=\"font-size: 18px;\">Hei {fornavn}!</p><p>Tusen takk for tilliten! Vi har nå mottatt din signerte fullmakt for <strong>{salongnavn}</strong>, og du er nå en del av Hår1 Forsikring.</p>"},
        "styles": {"padding": "0 0 20px 0"}
      },
      {
        "id": "info-1",
        "type": "info-box",
        "content": {"title": "Hva skjer nå?", "items": ["Vi tar oss av all nødvendig administrasjon", "Du får beskjed når forsikringene er aktive", "Dokumenter blir tilgjengelige i portalen din"]},
        "styles": {"backgroundColor": "#FAF7F2", "borderRadius": "12px", "padding": "24px", "margin": "24px 0"}
      },
      {
        "id": "footer-1",
        "type": "footer-signature",
        "content": {"signature": "Hår1 Forsikringsteamet", "email": "forsikring@har1.no", "phone": "+47 4000 3345"},
        "styles": {"textAlign": "center", "marginTop": "32px", "padding": "24px"}
      }
    ]
  }'::jsonb
);

-- 4. Helseforsikring velkomst-e-post
INSERT INTO email_templates (name, slug, description, category, status, is_system_template, subject_template, tags, structure)
VALUES (
  'Helseforsikring Velkomst',
  'health-insurance-welcome',
  'Velkomst-e-post til ansatte med ny helseforsikring',
  'forsikring',
  'published',
  true,
  'Velkommen til Hår1 Helseforsikring 🎉',
  ARRAY['forsikring', 'helse', 'velkomst'],
  '{
    "modules": [
      {
        "id": "header-1",
        "type": "header-logo",
        "content": {"logoUrl": "/haar1-forsikring-email-logo.png", "alt": "Hår1 Forsikring"},
        "styles": {"backgroundColor": "#FAF8F5", "padding": "32px", "textAlign": "center"}
      },
      {
        "id": "success-1",
        "type": "success-banner",
        "content": {"emoji": "🎉", "title": "Velkommen til Hår1 Helseforsikring!"},
        "styles": {"backgroundColor": "#E8F5E9", "borderRadius": "12px", "padding": "28px", "marginBottom": "28px", "textAlign": "center"}
      },
      {
        "id": "text-1",
        "type": "text",
        "content": {"text": "<p style=\"font-size: 18px;\">Kjære {fornavn} 👋</p><p>Vi er glade for at du har valgt Hår1 Helseforsikring hos ERGO! Du har nå tilgang til en forsikring som gir deg trygghet og rask tilgang til medisinsk behandling når du trenger det.</p>"},
        "styles": {}
      },
      {
        "id": "highlight-1",
        "type": "info-box",
        "content": {"title": "Oppstart for forsikringen", "text": "{oppstartsdato}"},
        "styles": {"backgroundColor": "#FEF3C7", "borderRadius": "12px", "padding": "20px", "margin": "24px 0", "textAlign": "center"}
      },
      {
        "id": "benefits-1",
        "type": "benefits-list",
        "content": {
          "title": "Forsikringen din dekker blant annet:",
          "items": [
            "Operasjoner og dagkirurgi",
            "Sykehusinnleggelse",
            "Behandling hos legespesialist",
            "Kreftbehandling",
            "Psykologisk førstehjelp (12 behandlingstimer)",
            "Fysikalsk behandling (12 timer, egenandel 250 kr)"
          ]
        },
        "styles": {"backgroundColor": "#FAF7F2", "borderRadius": "12px", "padding": "24px", "margin": "24px 0"}
      },
      {
        "id": "text-2",
        "type": "text",
        "content": {"text": "<h3 style=\"color: #8B7355;\">Slik bruker du forsikringen</h3><p>📲 <strong>Last ned BliFrisk-appen</strong> på <a href=\"https://blifrisk.no/last-ned\" style=\"color: #8B7355;\">blifrisk.no/last-ned</a> for å få rask tilgang til helsetjenester.</p>"},
        "styles": {"margin": "32px 0 16px 0"}
      },
      {
        "id": "code-1",
        "type": "info-box",
        "content": {"title": "Ditt avtalenummer (bruk ved registrering)", "text": "{avtalenummer}"},
        "styles": {"backgroundColor": "#F8F9FA", "border": "2px dashed #E5E7EB", "borderRadius": "12px", "padding": "24px", "margin": "24px 0", "textAlign": "center", "fontSize": "32px", "fontFamily": "monospace"}
      },
      {
        "id": "contact-1",
        "type": "info-box",
        "content": {"title": "💬 Spørsmål om helseforsikringen?", "text": "Kontakt ERGO på <strong>800 83 313</strong> eller <a href=\"mailto:infohelse@ergo.no\">infohelse@ergo.no</a>"},
        "styles": {"backgroundColor": "#F8F9FA", "borderLeft": "4px solid #8B7355", "padding": "16px 20px", "margin": "24px 0"}
      },
      {
        "id": "footer-1",
        "type": "footer-signature",
        "content": {"closing": "Varme hilsener,", "signature": "Hår1-teamet", "email": "forsikring@har1.no", "phone": "+47 4000 3345"},
        "styles": {"textAlign": "center", "marginTop": "32px", "padding": "24px"}
      }
    ]
  }'::jsonb
);

-- 5. POA OTP-kode e-post
INSERT INTO email_templates (name, slug, description, category, status, is_system_template, subject_template, tags, structure)
VALUES (
  'Fullmakt OTP-kode',
  'poa-otp-code',
  'E-post med engangskode for signering av fullmakt',
  'forsikring',
  'published',
  true,
  'Din signeringskode for fullmakt til Hår1',
  ARRAY['forsikring', 'fullmakt', 'otp', 'sikkerhet'],
  '{
    "modules": [
      {
        "id": "header-1",
        "type": "header-logo",
        "content": {"logoUrl": "/haar1-forsikring-email-logo.png", "alt": "Hår1 Forsikring"},
        "styles": {"backgroundColor": "#FAF8F5", "padding": "32px", "textAlign": "center"}
      },
      {
        "id": "text-1",
        "type": "text",
        "content": {"text": "<p style=\"font-size: 18px;\">Hei! 👋</p><p>For å fullføre signeringen av fullmakten, bruk koden under:</p>"},
        "styles": {}
      },
      {
        "id": "otp-1",
        "type": "info-box",
        "content": {"title": "Din signeringskode", "text": "{otp_kode}", "subtitle": "Koden er gyldig i 10 minutter"},
        "styles": {"backgroundColor": "#FAF7F2", "borderRadius": "16px", "padding": "32px", "textAlign": "center", "margin": "24px 0", "fontSize": "42px", "fontFamily": "monospace", "letterSpacing": "12px"}
      },
      {
        "id": "text-2",
        "type": "text",
        "content": {"text": "<p>Gå tilbake til siden du ble sendt til og legg inn koden for å fullføre signeringen.</p>"},
        "styles": {"margin": "24px 0"}
      },
      {
        "id": "info-1",
        "type": "info-box",
        "content": {"text": "💡 Hvis du ikke har bedt om denne koden, kan du trygt ignorere denne e-posten."},
        "styles": {"backgroundColor": "#F8F9FA", "borderLeft": "4px solid #8B7355", "padding": "16px 20px", "margin": "24px 0"}
      },
      {
        "id": "footer-1",
        "type": "footer-signature",
        "content": {"closing": "Varm hilsen,", "signature": "Hår1 Forsikringsteamet", "email": "forsikring@har1.no", "phone": "+47 4000 3345"},
        "styles": {"textAlign": "center", "marginTop": "32px", "padding": "24px"}
      }
    ]
  }'::jsonb
);

-- 6. Bestilling mottatt - admin varsling
INSERT INTO email_templates (name, slug, description, category, status, is_system_template, subject_template, tags, structure)
VALUES (
  'Bestilling mottatt - Admin varsling',
  'order-submitted-admin',
  'Varsler admin om ny forsikringsbestilling',
  'forsikring',
  'published',
  true,
  'Ny forsikringsbestilling fra {salongnavn}',
  ARRAY['forsikring', 'bestilling', 'admin'],
  '{
    "modules": [
      {
        "id": "header-1",
        "type": "header-logo",
        "content": {"logoUrl": "/haar1-forsikring-email-logo.png", "alt": "Hår1 Forsikring"},
        "styles": {"backgroundColor": "#FAF8F5", "padding": "32px", "textAlign": "center"}
      },
      {
        "id": "text-1",
        "type": "text",
        "content": {"text": "<h2 style=\"color: #8B7355;\">📋 Ny forsikringsbestilling</h2><p>En ny forsikringsbestilling er mottatt og venter på godkjenning.</p>"},
        "styles": {}
      },
      {
        "id": "info-1",
        "type": "info-box",
        "content": {"items": ["Salong: {salongnavn}", "Kontaktperson: {kontaktperson}", "Estimert årlig premie: {totalpris}"]},
        "styles": {"backgroundColor": "#FAF7F2", "borderRadius": "12px", "padding": "20px", "margin": "24px 0"}
      },
      {
        "id": "cta-1",
        "type": "cta-button",
        "content": {"text": "Se bestilling i admin →", "url": "{admin_link}"},
        "styles": {"textAlign": "center", "margin": "28px 0"}
      }
    ]
  }'::jsonb
);

-- 7. Bestilling godkjent - til medlem
INSERT INTO email_templates (name, slug, description, category, status, is_system_template, subject_template, tags, structure)
VALUES (
  'Bestilling godkjent',
  'order-approved',
  'Bekrefter til medlem at bestillingen er godkjent',
  'forsikring',
  'published',
  true,
  'Din forsikringsbestilling er godkjent ✓ – {salongnavn}',
  ARRAY['forsikring', 'bestilling', 'godkjent'],
  '{
    "modules": [
      {
        "id": "header-1",
        "type": "header-logo",
        "content": {"logoUrl": "/haar1-forsikring-email-logo.png", "alt": "Hår1 Forsikring"},
        "styles": {"backgroundColor": "#FAF8F5", "padding": "32px", "textAlign": "center"}
      },
      {
        "id": "success-1",
        "type": "success-banner",
        "content": {"emoji": "✅", "title": "Bestilling godkjent!"},
        "styles": {"backgroundColor": "#E8F5E9", "borderRadius": "12px", "padding": "28px", "marginBottom": "28px", "textAlign": "center"}
      },
      {
        "id": "text-1",
        "type": "text",
        "content": {"text": "<p style=\"font-size: 18px;\">Hei {fornavn}! 👋</p><p>Vi har godkjent forsikringsbestillingen for <strong>{salongnavn}</strong>.</p>"},
        "styles": {}
      },
      {
        "id": "info-1",
        "type": "info-box",
        "content": {"title": "Hva skjer nå?", "items": ["Bestillingen sendes til Frende for aktivering", "Du mottar bekreftelse når forsikringen er aktiv", "Dokumenter blir tilgjengelige i portalen"]},
        "styles": {"backgroundColor": "#FAF7F2", "borderRadius": "12px", "padding": "24px", "margin": "24px 0"}
      },
      {
        "id": "price-1",
        "type": "info-box",
        "content": {"title": "Årlig premie", "text": "{totalpris}"},
        "styles": {"backgroundColor": "#F8F9FA", "borderRadius": "8px", "padding": "16px", "margin": "20px 0", "textAlign": "center", "fontSize": "24px"}
      },
      {
        "id": "footer-1",
        "type": "footer-signature",
        "content": {"closing": "Varm hilsen,", "signature": "Hår1 Forsikringsteamet", "email": "forsikring@har1.no", "phone": "+47 4000 3345"},
        "styles": {"textAlign": "center", "marginTop": "32px", "padding": "24px"}
      }
    ]
  }'::jsonb
);

-- 8. Bestilling avvist - til medlem
INSERT INTO email_templates (name, slug, description, category, status, is_system_template, subject_template, tags, structure)
VALUES (
  'Bestilling avvist',
  'order-rejected',
  'Varsler medlem om at bestillingen er avvist',
  'forsikring',
  'published',
  true,
  'Forsikringsbestilling kunne ikke godkjennes – {salongnavn}',
  ARRAY['forsikring', 'bestilling', 'avvist'],
  '{
    "modules": [
      {
        "id": "header-1",
        "type": "header-logo",
        "content": {"logoUrl": "/haar1-forsikring-email-logo.png", "alt": "Hår1 Forsikring"},
        "styles": {"backgroundColor": "#FAF8F5", "padding": "32px", "textAlign": "center"}
      },
      {
        "id": "text-1",
        "type": "text",
        "content": {"text": "<h2 style=\"color: #8B7355;\">Bestilling avvist</h2><p style=\"font-size: 18px;\">Hei {fornavn},</p><p>Dessverre kunne vi ikke godkjenne forsikringsbestillingen for <strong>{salongnavn}</strong>.</p>"},
        "styles": {}
      },
      {
        "id": "error-1",
        "type": "info-box",
        "content": {"title": "Begrunnelse:", "text": "{avvisningsgrunn}"},
        "styles": {"backgroundColor": "#FEF2F2", "borderLeft": "4px solid #EF4444", "padding": "16px 20px", "margin": "24px 0"}
      },
      {
        "id": "text-2",
        "type": "text",
        "content": {"text": "<p>Du er velkommen til å sende inn en ny bestilling eller kontakte oss for mer informasjon.</p>"},
        "styles": {"margin": "24px 0"}
      },
      {
        "id": "footer-1",
        "type": "footer-signature",
        "content": {"signature": "Hår1 Forsikringsteamet", "email": "forsikring@har1.no", "phone": "+47 4000 3345"},
        "styles": {"textAlign": "center", "marginTop": "32px", "padding": "24px"}
      }
    ]
  }'::jsonb
);

-- 9. Forsikring aktivert
INSERT INTO email_templates (name, slug, description, category, status, is_system_template, subject_template, tags, structure)
VALUES (
  'Forsikring aktivert',
  'order-completed',
  'Bekrefter til medlem at forsikringen nå er aktiv',
  'forsikring',
  'published',
  true,
  'Forsikring aktivert ✓ – {salongnavn}',
  ARRAY['forsikring', 'aktivert', 'bekreftelse'],
  '{
    "modules": [
      {
        "id": "header-1",
        "type": "header-logo",
        "content": {"logoUrl": "/haar1-forsikring-email-logo.png", "alt": "Hår1 Forsikring"},
        "styles": {"backgroundColor": "#FAF8F5", "padding": "32px", "textAlign": "center"}
      },
      {
        "id": "success-1",
        "type": "success-banner",
        "content": {"emoji": "🎉", "title": "Forsikring aktivert!"},
        "styles": {"backgroundColor": "#E8F5E9", "borderRadius": "12px", "padding": "28px", "marginBottom": "28px", "textAlign": "center"}
      },
      {
        "id": "text-1",
        "type": "text",
        "content": {"text": "<p style=\"font-size: 18px;\">Hei {fornavn}! 👋</p><p>Gode nyheter! Forsikringen for <strong>{salongnavn}</strong> er nå aktiv.</p>"},
        "styles": {}
      },
      {
        "id": "price-1",
        "type": "info-box",
        "content": {"title": "Årlig premie", "text": "{totalpris}"},
        "styles": {"backgroundColor": "#FAF7F2", "borderRadius": "12px", "padding": "20px", "margin": "24px 0", "textAlign": "center", "fontSize": "28px"}
      },
      {
        "id": "info-1",
        "type": "info-box",
        "content": {"text": "💡 Du kan nå se dine forsikringer og dokumenter i Hår1-portalen under \"Forsikring\"."},
        "styles": {"backgroundColor": "#F8F9FA", "borderLeft": "4px solid #8B7355", "padding": "16px 20px", "margin": "24px 0"}
      },
      {
        "id": "text-2",
        "type": "text",
        "content": {"text": "<p>Ved skade eller spørsmål er vi alltid tilgjengelige for deg!</p>"},
        "styles": {"margin": "24px 0"}
      },
      {
        "id": "footer-1",
        "type": "footer-signature",
        "content": {"closing": "Varm hilsen,", "signature": "Hår1 Forsikringsteamet", "email": "forsikring@har1.no", "phone": "+47 4000 3345"},
        "styles": {"textAlign": "center", "marginTop": "32px", "padding": "24px"}
      }
    ]
  }'::jsonb
);

-- 10. Invitasjons-e-post
INSERT INTO email_templates (name, slug, description, category, status, is_system_template, subject_template, tags, structure)
VALUES (
  'Invitasjon til Hår1 Portalen',
  'user-invitation',
  'E-post som sendes når brukere inviteres til portalen',
  'system',
  'published',
  true,
  'Du er invitert til Merbehandling Challenge 2026!',
  ARRAY['system', 'invitasjon', 'onboarding'],
  '{
    "modules": [
      {
        "id": "text-1",
        "type": "text",
        "content": {"text": "<h1 style=\"color: #1a1a1a; margin-bottom: 24px;\">Velkommen til Merbehandling Challenge 2026!</h1><p>Du har blitt invitert til å bli med i Merbehandling Challenge 2026 - Hår1s offisielle plattform for salongvekst og lønnsomhet.</p>"},
        "styles": {}
      },
      {
        "id": "info-1",
        "type": "info-box",
        "content": {"title": "Din rolle:", "text": "{rolle}"},
        "styles": {"backgroundColor": "#f4f4f5", "borderRadius": "8px", "padding": "16px", "margin": "24px 0"}
      },
      {
        "id": "text-2",
        "type": "text",
        "content": {"text": "<p>Klikk på knappen under for å opprette din konto og komme i gang:</p>"},
        "styles": {}
      },
      {
        "id": "cta-1",
        "type": "cta-button",
        "content": {"text": "Opprett konto", "url": "{invitasjons_link}"},
        "styles": {"textAlign": "center", "margin": "32px 0"}
      },
      {
        "id": "text-3",
        "type": "text",
        "content": {"text": "<p style=\"color: #71717a; font-size: 14px;\">Denne invitasjonen utløper om 7 dager. Hvis du ikke forventet denne e-posten, kan du trygt ignorere den.</p>"},
        "styles": {}
      },
      {
        "id": "footer-1",
        "type": "footer-signature",
        "content": {"signature": "Hår1 / Merbehandling Challenge Team"},
        "styles": {"marginTop": "32px"}
      }
    ]
  }'::jsonb
);