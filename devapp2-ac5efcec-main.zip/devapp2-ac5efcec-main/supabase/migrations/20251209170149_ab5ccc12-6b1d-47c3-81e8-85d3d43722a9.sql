-- Add sum_driftskostnad column to prospekter table
ALTER TABLE public.prospekter 
ADD COLUMN IF NOT EXISTS sum_driftskostnad numeric;