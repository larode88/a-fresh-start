-- Opprett unik index for aktive turnus-maler for å forhindre fremtidige duplikater
CREATE UNIQUE INDEX IF NOT EXISTS idx_ansatt_turnus_unique_active 
ON ansatt_turnus (ansatt_id, ukedag, uke_type) 
WHERE gyldig_til IS NULL;