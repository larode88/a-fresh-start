
-- Extend ansatt_samtaler with wizard data
ALTER TABLE public.ansatt_samtaler 
ADD COLUMN IF NOT EXISTS steg_notater jsonb DEFAULT '{}'::jsonb,
ADD COLUMN IF NOT EXISTS forberedelses_frist date;

-- Create medarbeidersamtale_forberedelse table
CREATE TABLE public.medarbeidersamtale_forberedelse (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  samtale_id uuid NOT NULL REFERENCES public.ansatt_samtaler(id) ON DELETE CASCADE,
  utfylt_av_type text NOT NULL CHECK (utfylt_av_type IN ('medarbeider', 'leder')),
  -- Medarbeider spørsmål (9 stk)
  egen_innsats_score integer CHECK (egen_innsats_score BETWEEN 1 AND 5),
  egen_innsats_kommentar text,
  arbeid_salong_score integer CHECK (arbeid_salong_score BETWEEN 1 AND 5),
  arbeid_salong_kommentar text,
  hjelp_leder_score integer CHECK (hjelp_leder_score BETWEEN 1 AND 5),
  hjelp_leder_kommentar text,
  kompetanse_score integer CHECK (kompetanse_score BETWEEN 1 AND 5),
  kompetanse_kommentar text,
  stotte_leder_score integer CHECK (stotte_leder_score BETWEEN 1 AND 5),
  stotte_leder_kommentar text,
  ferdigheter_utvikle text,
  leder_hjelp_mal text,
  framtidige_mal text,
  andre_tema text,
  -- Leder spørsmål (4 stk)
  prestasjoner_score integer CHECK (prestasjoner_score BETWEEN 1 AND 5),
  prestasjoner_kommentar text,
  styrker text,
  forbedringsomrader text,
  andre_tema_leder text,
  -- Meta
  ferdig_utfylt boolean DEFAULT false,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now(),
  UNIQUE(samtale_id, utfylt_av_type)
);

-- Create samtale_smart_mal table
CREATE TABLE public.samtale_smart_mal (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  samtale_id uuid NOT NULL REFERENCES public.ansatt_samtaler(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  tittel text NOT NULL,
  spesifikt text NOT NULL,
  maalbart text NOT NULL,
  oppnaaelig text NOT NULL,
  relevant text NOT NULL,
  tidsbestemt text NOT NULL,
  frist date,
  status text DEFAULT 'ikke_startet' CHECK (status IN ('ikke_startet', 'pagaende', 'fullfort', 'avbrutt')),
  fremgang integer DEFAULT 0 CHECK (fremgang BETWEEN 0 AND 100),
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Create mote_oppgaver table
CREATE TABLE public.mote_oppgaver (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  samtale_id uuid NOT NULL REFERENCES public.ansatt_samtaler(id) ON DELETE CASCADE,
  tittel text NOT NULL,
  beskrivelse text,
  ansvarlig_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  ansvarlig_type text NOT NULL CHECK (ansvarlig_type IN ('medarbeider', 'leder')),
  frist date,
  prioritet text DEFAULT 'normal' CHECK (prioritet IN ('lav', 'normal', 'hoy', 'kritisk')),
  status text DEFAULT 'aapen' CHECK (status IN ('aapen', 'pagaende', 'fullfort', 'avbrutt')),
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Create medarbeidersamtale_paminnelser table
CREATE TABLE public.medarbeidersamtale_paminnelser (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  salon_id uuid NOT NULL REFERENCES public.salons(id) ON DELETE CASCADE,
  samtale_id uuid REFERENCES public.ansatt_samtaler(id) ON DELETE CASCADE,
  ansatt_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  leder_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('ny_samtale_planlagt', 'forberedelse_frist', 'samtale_i_dag', 'oppgave_frist', 'puls_utsendt')),
  melding text NOT NULL,
  lest boolean DEFAULT false,
  lest_dato timestamp with time zone,
  created_at timestamp with time zone DEFAULT now()
);

-- Create pulsundersokelser table
CREATE TABLE public.pulsundersokelser (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  salon_id uuid NOT NULL REFERENCES public.salons(id) ON DELETE CASCADE,
  navn text NOT NULL,
  beskrivelse text,
  frekvens text NOT NULL CHECK (frekvens IN ('ukentlig', 'annenhver_uke', 'maanedlig')),
  start_dato date NOT NULL,
  slutt_dato date,
  aktiv boolean DEFAULT true,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- Create pulsundersokelse_svar table
CREATE TABLE public.pulsundersokelse_svar (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  undersokelse_id uuid NOT NULL REFERENCES public.pulsundersokelser(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  stemning integer NOT NULL CHECK (stemning BETWEEN 1 AND 5),
  energi integer NOT NULL CHECK (energi BETWEEN 1 AND 5),
  mestring integer NOT NULL CHECK (mestring BETWEEN 1 AND 5),
  kommentar text,
  dato date NOT NULL DEFAULT CURRENT_DATE,
  created_at timestamp with time zone DEFAULT now(),
  UNIQUE(undersokelse_id, user_id, dato)
);

-- Enable RLS
ALTER TABLE public.medarbeidersamtale_forberedelse ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.samtale_smart_mal ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mote_oppgaver ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.medarbeidersamtale_paminnelser ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pulsundersokelser ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pulsundersokelse_svar ENABLE ROW LEVEL SECURITY;

-- RLS for medarbeidersamtale_forberedelse
-- Medarbeider kan kun se/redigere egen forberedelse (IKKE lederens!)
CREATE POLICY "Medarbeider kan se egen forberedelse" ON public.medarbeidersamtale_forberedelse
FOR SELECT USING (
  utfylt_av_type = 'medarbeider' AND 
  samtale_id IN (SELECT id FROM ansatt_samtaler WHERE user_id = auth.uid())
);

CREATE POLICY "Medarbeider kan redigere egen forberedelse" ON public.medarbeidersamtale_forberedelse
FOR ALL USING (
  utfylt_av_type = 'medarbeider' AND 
  samtale_id IN (SELECT id FROM ansatt_samtaler WHERE user_id = auth.uid())
) WITH CHECK (
  utfylt_av_type = 'medarbeider' AND 
  samtale_id IN (SELECT id FROM ansatt_samtaler WHERE user_id = auth.uid())
);

-- Leder kan se begge parters forberedelse og redigere sin egen
CREATE POLICY "Leder kan se alle forberedelser for sine samtaler" ON public.medarbeidersamtale_forberedelse
FOR SELECT USING (
  samtale_id IN (SELECT id FROM ansatt_samtaler WHERE utfort_av = auth.uid())
  OR has_role(auth.uid(), 'admin'::app_role)
);

CREATE POLICY "Leder kan redigere sin forberedelse" ON public.medarbeidersamtale_forberedelse
FOR ALL USING (
  utfylt_av_type = 'leder' AND 
  samtale_id IN (SELECT id FROM ansatt_samtaler WHERE utfort_av = auth.uid())
) WITH CHECK (
  utfylt_av_type = 'leder' AND 
  samtale_id IN (SELECT id FROM ansatt_samtaler WHERE utfort_av = auth.uid())
);

CREATE POLICY "Admin kan administrere alle forberedelser" ON public.medarbeidersamtale_forberedelse
FOR ALL USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- RLS for samtale_smart_mal
CREATE POLICY "Brukere kan se egne SMART-mål" ON public.samtale_smart_mal
FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Ledere kan se SMART-mål for sine samtaler" ON public.samtale_smart_mal
FOR SELECT USING (
  samtale_id IN (SELECT id FROM ansatt_samtaler WHERE utfort_av = auth.uid())
  OR has_role(auth.uid(), 'admin'::app_role)
);

CREATE POLICY "Ledere kan administrere SMART-mål" ON public.samtale_smart_mal
FOR ALL USING (
  samtale_id IN (SELECT id FROM ansatt_samtaler WHERE utfort_av = auth.uid())
  OR has_role(auth.uid(), 'admin'::app_role)
) WITH CHECK (
  samtale_id IN (SELECT id FROM ansatt_samtaler WHERE utfort_av = auth.uid())
  OR has_role(auth.uid(), 'admin'::app_role)
);

-- RLS for mote_oppgaver
CREATE POLICY "Brukere kan se egne oppgaver" ON public.mote_oppgaver
FOR SELECT USING (ansvarlig_id = auth.uid());

CREATE POLICY "Ledere kan administrere oppgaver for sine samtaler" ON public.mote_oppgaver
FOR ALL USING (
  samtale_id IN (SELECT id FROM ansatt_samtaler WHERE utfort_av = auth.uid())
  OR has_role(auth.uid(), 'admin'::app_role)
) WITH CHECK (
  samtale_id IN (SELECT id FROM ansatt_samtaler WHERE utfort_av = auth.uid())
  OR has_role(auth.uid(), 'admin'::app_role)
);

-- RLS for medarbeidersamtale_paminnelser
CREATE POLICY "Brukere kan se egne påminnelser" ON public.medarbeidersamtale_paminnelser
FOR SELECT USING (ansatt_id = auth.uid() OR leder_id = auth.uid());

CREATE POLICY "Brukere kan oppdatere egne påminnelser" ON public.medarbeidersamtale_paminnelser
FOR UPDATE USING (ansatt_id = auth.uid() OR leder_id = auth.uid());

CREATE POLICY "Ledere kan opprette påminnelser" ON public.medarbeidersamtale_paminnelser
FOR INSERT WITH CHECK (
  leder_id = auth.uid() OR has_role(auth.uid(), 'admin'::app_role)
);

CREATE POLICY "Admin kan administrere alle påminnelser" ON public.medarbeidersamtale_paminnelser
FOR ALL USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- RLS for pulsundersokelser
CREATE POLICY "Ledere kan administrere pulsundersøkelser" ON public.pulsundersokelser
FOR ALL USING (
  (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()))
  OR has_role(auth.uid(), 'admin'::app_role)
) WITH CHECK (
  (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()))
  OR has_role(auth.uid(), 'admin'::app_role)
);

CREATE POLICY "Ansatte kan se aktive pulsundersøkelser" ON public.pulsundersokelser
FOR SELECT USING (
  salon_id = get_user_salon_id(auth.uid()) AND aktiv = true
);

-- RLS for pulsundersokelse_svar
CREATE POLICY "Ansatte kan svare på puls" ON public.pulsundersokelse_svar
FOR INSERT WITH CHECK (user_id = auth.uid());

CREATE POLICY "Ansatte kan se egne svar" ON public.pulsundersokelse_svar
FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Ledere kan se alle svar for sin salong" ON public.pulsundersokelse_svar
FOR SELECT USING (
  undersokelse_id IN (
    SELECT id FROM pulsundersokelser WHERE salon_id = get_user_salon_id(auth.uid())
  ) AND is_salon_owner(auth.uid())
);

CREATE POLICY "Admin kan administrere alle svar" ON public.pulsundersokelse_svar
FOR ALL USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- Triggers for updated_at
CREATE TRIGGER update_medarbeidersamtale_forberedelse_updated_at
  BEFORE UPDATE ON public.medarbeidersamtale_forberedelse
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_samtale_smart_mal_updated_at
  BEFORE UPDATE ON public.samtale_smart_mal
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_mote_oppgaver_updated_at
  BEFORE UPDATE ON public.mote_oppgaver
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_pulsundersokelser_updated_at
  BEFORE UPDATE ON public.pulsundersokelser
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
