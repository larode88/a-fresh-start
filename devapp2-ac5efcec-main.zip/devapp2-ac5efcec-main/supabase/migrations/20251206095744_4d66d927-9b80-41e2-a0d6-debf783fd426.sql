-- =====================================================
-- Insurance Quotes Module - Database Schema
-- For District Managers to create and send insurance quotes to members
-- =====================================================

-- Create enum for quote status
CREATE TYPE public.insurance_quote_status AS ENUM (
  'draft',
  'sent',
  'accepted',
  'expired',
  'completed'
);

-- Create the insurance_quotes table
CREATE TABLE public.insurance_quotes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  
  -- Member/Salon information (can be linked or manual entry)
  member_salon_id UUID REFERENCES public.salons(id) ON DELETE SET NULL,
  salon_name TEXT NOT NULL,
  org_number TEXT NOT NULL,
  contact_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  
  -- District Manager who created the quote
  district_manager_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  
  -- Products selected (JSON array of product selections)
  -- Format: [{ "product_id": "uuid", "product_name": "...", "price": 1499, "quantity": 1, "tier_name": "Nivå 1" }]
  products JSONB NOT NULL DEFAULT '[]'::jsonb,
  
  -- Pricing
  total_price NUMERIC(12,2) NOT NULL DEFAULT 0,
  
  -- Notes from DM
  notes TEXT,
  
  -- Quote status and workflow
  status insurance_quote_status NOT NULL DEFAULT 'draft',
  sent_at TIMESTAMP WITH TIME ZONE,
  accepted_at TIMESTAMP WITH TIME ZONE,
  completed_at TIMESTAMP WITH TIME ZONE,
  expires_at TIMESTAMP WITH TIME ZONE,
  
  -- Acceptance tracking
  acceptance_token TEXT UNIQUE,
  acceptance_ip TEXT,
  acceptance_user_agent TEXT,
  
  -- Link to fullmakt (Power of Attorney) when created
  link_to_fullmakt UUID REFERENCES public.insurance_power_of_attorney(id) ON DELETE SET NULL,
  
  -- Timestamps
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.insurance_quotes ENABLE ROW LEVEL SECURITY;

-- Create index for faster lookups
CREATE INDEX idx_insurance_quotes_status ON public.insurance_quotes(status);
CREATE INDEX idx_insurance_quotes_dm ON public.insurance_quotes(district_manager_id);
CREATE INDEX idx_insurance_quotes_salon ON public.insurance_quotes(member_salon_id);
CREATE INDEX idx_insurance_quotes_acceptance_token ON public.insurance_quotes(acceptance_token);
CREATE INDEX idx_insurance_quotes_expires ON public.insurance_quotes(expires_at);

-- RLS Policies

-- District Managers can manage quotes for salons in their district
CREATE POLICY "District managers can manage their quotes"
ON public.insurance_quotes
FOR ALL
USING (
  district_manager_id = auth.uid() OR
  has_role(auth.uid(), 'admin'::app_role)
)
WITH CHECK (
  district_manager_id = auth.uid() OR
  has_role(auth.uid(), 'admin'::app_role)
);

-- District Managers can view quotes for their district salons (even created by others)
CREATE POLICY "District managers can view district quotes"
ON public.insurance_quotes
FOR SELECT
USING (
  has_role(auth.uid(), 'district_manager'::app_role) AND
  member_salon_id IN (SELECT get_district_salon_ids(auth.uid()))
);

-- Public can read quotes via acceptance token (for quote acceptance page)
CREATE POLICY "Public can read quotes by token"
ON public.insurance_quotes
FOR SELECT
USING (
  acceptance_token IS NOT NULL AND 
  acceptance_token = current_setting('app.current_acceptance_token', true)
);

-- Admins have full access
CREATE POLICY "Admins can manage all quotes"
ON public.insurance_quotes
FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- Trigger for updating updated_at
CREATE TRIGGER update_insurance_quotes_updated_at
  BEFORE UPDATE ON public.insurance_quotes
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Add quote_id to insurance_power_of_attorney to link them
ALTER TABLE public.insurance_power_of_attorney 
ADD COLUMN IF NOT EXISTS quote_id UUID REFERENCES public.insurance_quotes(id) ON DELETE SET NULL;

-- Create index on the new column
CREATE INDEX IF NOT EXISTS idx_poa_quote_id ON public.insurance_power_of_attorney(quote_id);