-- Fase 2: Budsjett-modul

-- 2.1 Budsjett årsak for null timer
CREATE TYPE budsjett_arsak_null AS ENUM ('helg', 'helligdag', 'ferie', 'salong_stengt', 'turnus_fridag', 'permisjon', 'annet');

-- 2.2 Budsjett versjoner (for å håndtere ulike budsjettscenarier)
CREATE TABLE public.budsjett_versjoner (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  salon_id uuid NOT NULL REFERENCES public.salons(id) ON DELETE CASCADE,
  aar integer NOT NULL,
  versjon_nummer integer NOT NULL DEFAULT 1,
  versjon_navn text NOT NULL DEFAULT 'Hovedbudsjett',
  er_aktiv boolean DEFAULT false,
  beskrivelse text,
  opprettet_av uuid REFERENCES public.users(id),
  godkjent_av uuid REFERENCES public.users(id),
  godkjent_dato timestamp with time zone,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now(),
  UNIQUE(salon_id, aar, versjon_nummer)
);

CREATE INDEX idx_budsjett_versjoner_salon_aar ON public.budsjett_versjoner(salon_id, aar);

-- 2.3 Budsjett (daglig budsjett per frisør)
CREATE TABLE public.budsjett (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  versjon_id uuid NOT NULL REFERENCES public.budsjett_versjoner(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  salon_id uuid NOT NULL REFERENCES public.salons(id) ON DELETE CASCADE,
  aar integer NOT NULL,
  maned integer NOT NULL CHECK (maned BETWEEN 1 AND 12),
  uke integer NOT NULL,
  dag integer NOT NULL CHECK (dag BETWEEN 1 AND 31),
  dato date NOT NULL,
  planlagte_timer numeric(4,2) DEFAULT 0,
  kundetimer numeric(4,2) DEFAULT 0,
  behandling_budsjett numeric(10,2) DEFAULT 0,
  vare_budsjett numeric(10,2) DEFAULT 0,
  totalt_budsjett numeric(10,2) DEFAULT 0,
  arsak_null_timer budsjett_arsak_null,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now(),
  UNIQUE(versjon_id, user_id, dato)
);

CREATE INDEX idx_budsjett_versjon ON public.budsjett(versjon_id);
CREATE INDEX idx_budsjett_user ON public.budsjett(user_id);
CREATE INDEX idx_budsjett_dato ON public.budsjett(dato);
CREATE INDEX idx_budsjett_uke ON public.budsjett(aar, uke);
CREATE INDEX idx_budsjett_maned ON public.budsjett(aar, maned);

-- 2.4 Budsjett fastsatt (låst årsbudsjett per frisør)
CREATE TABLE public.budsjett_fastsatt (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  versjon_id uuid NOT NULL REFERENCES public.budsjett_versjoner(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  salon_id uuid NOT NULL REFERENCES public.salons(id) ON DELETE CASCADE,
  fastsatt_arsbudsjett numeric(12,2) NOT NULL DEFAULT 0,
  fastsatt_behandling numeric(12,2) NOT NULL DEFAULT 0,
  fastsatt_vare numeric(12,2) NOT NULL DEFAULT 0,
  fastsatt_timer numeric(8,2) DEFAULT 0,
  godkjent_av uuid REFERENCES public.users(id),
  godkjent_dato timestamp with time zone,
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now(),
  UNIQUE(versjon_id, user_id)
);

-- 2.5 Historiske tall (for import og sammenligning)
CREATE TABLE public.historiske_tall (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  salon_id uuid NOT NULL REFERENCES public.salons(id) ON DELETE CASCADE,
  user_id uuid REFERENCES public.users(id) ON DELETE SET NULL,
  aar integer NOT NULL,
  maned integer CHECK (maned BETWEEN 1 AND 12),
  uke integer,
  dag integer CHECK (dag BETWEEN 1 AND 31),
  dato date,
  behandling_kr numeric(10,2) DEFAULT 0,
  vare_kr numeric(10,2) DEFAULT 0,
  total_kr numeric(10,2) DEFAULT 0,
  kunder integer DEFAULT 0,
  timer_jobbet numeric(6,2) DEFAULT 0,
  kilde text DEFAULT 'import',
  created_at timestamp with time zone DEFAULT now()
);

CREATE INDEX idx_historiske_tall_salon ON public.historiske_tall(salon_id);
CREATE INDEX idx_historiske_tall_dato ON public.historiske_tall(dato);
CREATE INDEX idx_historiske_tall_uke ON public.historiske_tall(aar, uke);

-- 2.6 Rapport kommentarer (KPI-kommentarer per periode)
CREATE TABLE public.rapport_kommentarer (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  salon_id uuid NOT NULL REFERENCES public.salons(id) ON DELETE CASCADE,
  aar integer NOT NULL,
  uke integer,
  maned integer,
  periode_type text NOT NULL DEFAULT 'uke' CHECK (periode_type IN ('dag', 'uke', 'maned', 'aar')),
  kpi_type text,
  kommentar text,
  svar text,
  opprettet_av uuid REFERENCES public.users(id),
  created_at timestamp with time zone DEFAULT now(),
  updated_at timestamp with time zone DEFAULT now()
);

-- 2.7 Enable RLS
ALTER TABLE public.budsjett_versjoner ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.budsjett ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.budsjett_fastsatt ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.historiske_tall ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rapport_kommentarer ENABLE ROW LEVEL SECURITY;

-- 2.8 RLS Policies - budsjett_versjoner
CREATE POLICY "Admins can manage all budsjett_versjoner" ON public.budsjett_versjoner FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Salon owners can manage their budsjett_versjoner" ON public.budsjett_versjoner FOR ALL
USING (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()))
WITH CHECK (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()));
CREATE POLICY "District managers can view budsjett_versjoner" ON public.budsjett_versjoner FOR SELECT
USING (has_role(auth.uid(), 'district_manager'::app_role) AND salon_id IN (SELECT get_district_salon_ids(auth.uid())));
CREATE POLICY "Users can view their salon budsjett_versjoner" ON public.budsjett_versjoner FOR SELECT
USING (salon_id = get_user_salon_id(auth.uid()));

-- 2.9 RLS Policies - budsjett
CREATE POLICY "Admins can manage all budsjett" ON public.budsjett FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Salon owners can manage their budsjett" ON public.budsjett FOR ALL
USING (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()))
WITH CHECK (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()));
CREATE POLICY "District managers can view budsjett" ON public.budsjett FOR SELECT
USING (has_role(auth.uid(), 'district_manager'::app_role) AND salon_id IN (SELECT get_district_salon_ids(auth.uid())));
CREATE POLICY "Users can view their own budsjett" ON public.budsjett FOR SELECT
USING (user_id = auth.uid() OR salon_id = get_user_salon_id(auth.uid()));

-- 2.10 RLS Policies - budsjett_fastsatt
CREATE POLICY "Admins can manage all budsjett_fastsatt" ON public.budsjett_fastsatt FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Salon owners can manage their budsjett_fastsatt" ON public.budsjett_fastsatt FOR ALL
USING (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()))
WITH CHECK (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()));
CREATE POLICY "Users can view their own budsjett_fastsatt" ON public.budsjett_fastsatt FOR SELECT
USING (user_id = auth.uid() OR salon_id = get_user_salon_id(auth.uid()));

-- 2.11 RLS Policies - historiske_tall
CREATE POLICY "Admins can manage all historiske_tall" ON public.historiske_tall FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Salon owners can manage their historiske_tall" ON public.historiske_tall FOR ALL
USING (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()))
WITH CHECK (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()));
CREATE POLICY "Users can view their salon historiske_tall" ON public.historiske_tall FOR SELECT
USING (salon_id = get_user_salon_id(auth.uid()));

-- 2.12 RLS Policies - rapport_kommentarer
CREATE POLICY "Admins can manage all rapport_kommentarer" ON public.rapport_kommentarer FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role)) WITH CHECK (has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Salon owners can manage their rapport_kommentarer" ON public.rapport_kommentarer FOR ALL
USING (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()))
WITH CHECK (salon_id = get_user_salon_id(auth.uid()) AND is_salon_owner(auth.uid()));
CREATE POLICY "Users can view their salon rapport_kommentarer" ON public.rapport_kommentarer FOR SELECT
USING (salon_id = get_user_salon_id(auth.uid()));

-- 2.13 Triggers for updated_at
CREATE TRIGGER update_budsjett_versjoner_updated_at BEFORE UPDATE ON public.budsjett_versjoner
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_budsjett_updated_at BEFORE UPDATE ON public.budsjett
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_budsjett_fastsatt_updated_at BEFORE UPDATE ON public.budsjett_fastsatt
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_rapport_kommentarer_updated_at BEFORE UPDATE ON public.rapport_kommentarer
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 2.14 Hjelpefunksjon: Beregn budsjett for en frisør på en dag
CREATE OR REPLACE FUNCTION public.beregn_daglig_budsjett(
  p_user_id uuid,
  p_dato date,
  p_effektivitet numeric,
  p_omsetning_per_time numeric,
  p_varesalg_prosent numeric
)
RETURNS TABLE(kundetimer numeric, behandling numeric, vare numeric, total numeric)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  WITH planlagt AS (
    SELECT get_turnus_timer_for_dag(p_user_id, p_dato) AS timer
  )
  SELECT 
    (p.timer * (p_effektivitet / 100))::numeric(10,2) AS kundetimer,
    ((p.timer * (p_effektivitet / 100) * p_omsetning_per_time) * (1 - p_varesalg_prosent / 100))::numeric(10,2) AS behandling,
    ((p.timer * (p_effektivitet / 100) * p_omsetning_per_time) * (p_varesalg_prosent / 100))::numeric(10,2) AS vare,
    (p.timer * (p_effektivitet / 100) * p_omsetning_per_time)::numeric(10,2) AS total
  FROM planlagt p
$$;

-- 2.15 Hjelpefunksjon: Hent aktiv budsjettversjon
CREATE OR REPLACE FUNCTION public.get_aktiv_budsjett_versjon(p_salon_id uuid, p_aar integer)
RETURNS uuid
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT id FROM budsjett_versjoner 
  WHERE salon_id = p_salon_id AND aar = p_aar AND er_aktiv = true
  LIMIT 1
$$;