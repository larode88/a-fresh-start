-- Table for employee performance reviews (medarbeidersamtaler)
CREATE TABLE public.ansatt_samtaler (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES public.users(id),
  salon_id UUID NOT NULL REFERENCES public.salons(id),
  samtale_type TEXT NOT NULL CHECK (samtale_type IN ('medarbeidersamtale', 'oppfolging', 'utviklingssamtale', 'lonnssamtale', 'annet')),
  dato DATE NOT NULL,
  utfort_av UUID NOT NULL REFERENCES public.users(id),
  notater TEXT,
  styrker TEXT,
  utviklingsomrader TEXT,
  mal_neste_periode TEXT,
  neste_samtale DATE,
  status TEXT DEFAULT 'planlagt' CHECK (status IN ('planlagt', 'gjennomfort', 'avlyst')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Table for development plans (utviklingsplaner)
CREATE TABLE public.ansatt_utviklingsplan (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES public.users(id),
  salon_id UUID NOT NULL REFERENCES public.salons(id),
  samtale_id UUID REFERENCES public.ansatt_samtaler(id) ON DELETE SET NULL,
  tittel TEXT NOT NULL,
  beskrivelse TEXT,
  kategori TEXT CHECK (kategori IN ('faglig', 'lederskap', 'salg', 'kundeservice', 'personlig', 'annet')),
  maal TEXT,
  tiltak TEXT,
  frist DATE,
  status TEXT DEFAULT 'ikke_startet' CHECK (status IN ('ikke_startet', 'pagar', 'fullfort', 'avbrutt')),
  fremgang INTEGER DEFAULT 0 CHECK (fremgang >= 0 AND fremgang <= 100),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.ansatt_samtaler ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ansatt_utviklingsplan ENABLE ROW LEVEL SECURITY;

-- RLS policies for ansatt_samtaler
CREATE POLICY "Admins can manage all samtaler"
  ON public.ansatt_samtaler FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Salon owners can manage their salon samtaler"
  ON public.ansatt_samtaler FOR ALL
  USING ((salon_id = get_user_salon_id(auth.uid())) AND is_salon_owner(auth.uid()))
  WITH CHECK ((salon_id = get_user_salon_id(auth.uid())) AND is_salon_owner(auth.uid()));

CREATE POLICY "Users can view their own samtaler"
  ON public.ansatt_samtaler FOR SELECT
  USING (user_id = auth.uid());

-- RLS policies for ansatt_utviklingsplan
CREATE POLICY "Admins can manage all utviklingsplaner"
  ON public.ansatt_utviklingsplan FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Salon owners can manage their salon utviklingsplaner"
  ON public.ansatt_utviklingsplan FOR ALL
  USING ((salon_id = get_user_salon_id(auth.uid())) AND is_salon_owner(auth.uid()))
  WITH CHECK ((salon_id = get_user_salon_id(auth.uid())) AND is_salon_owner(auth.uid()));

CREATE POLICY "Users can view their own utviklingsplaner"
  ON public.ansatt_utviklingsplan FOR SELECT
  USING (user_id = auth.uid());

CREATE POLICY "Users can update their own utviklingsplaner progress"
  ON public.ansatt_utviklingsplan FOR UPDATE
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

-- Triggers for updated_at
CREATE TRIGGER update_ansatt_samtaler_updated_at
  BEFORE UPDATE ON public.ansatt_samtaler
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_ansatt_utviklingsplan_updated_at
  BEFORE UPDATE ON public.ansatt_utviklingsplan
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Indexes
CREATE INDEX idx_ansatt_samtaler_user ON public.ansatt_samtaler(user_id);
CREATE INDEX idx_ansatt_samtaler_salon ON public.ansatt_samtaler(salon_id);
CREATE INDEX idx_ansatt_utviklingsplan_user ON public.ansatt_utviklingsplan(user_id);