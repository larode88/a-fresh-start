-- Add type column to ferie table for vacation type (e.g., Påskeferie, Sommerferie, etc.)
ALTER TABLE public.ferie
ADD COLUMN type TEXT DEFAULT 'Ferie';