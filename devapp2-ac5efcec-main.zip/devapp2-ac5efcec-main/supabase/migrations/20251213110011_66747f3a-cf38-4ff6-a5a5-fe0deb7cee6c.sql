-- Fix ansatte_utvidet view with all calculated fields
DROP VIEW IF EXISTS public.ansatte_utvidet;

CREATE VIEW public.ansatte_utvidet AS
SELECT 
  a.*,
  -- Combined name
  CONCAT(a.fornavn, ' ', COALESCE(a.etternavn, '')) AS navn,
  -- Age calculation
  EXTRACT(YEAR FROM age(CURRENT_DATE, a.fodselsdato))::integer AS alder,
  -- Seniority in years
  EXTRACT(YEAR FROM age(CURRENT_DATE, COALESCE(a.fagbrev_dato, a.ansatt_dato)))::numeric AS ansiennitet_aar,
  -- Seniority in months
  EXTRACT(YEAR FROM age(CURRENT_DATE, COALESCE(a.fagbrev_dato, a.ansatt_dato)))::integer * 12 + 
  EXTRACT(MONTH FROM age(CURRENT_DATE, COALESCE(a.fagbrev_dato, a.ansatt_dato)))::integer AS ansiennitet_maneder,
  -- Probation status
  CASE 
    WHEN a.provetid_til IS NOT NULL AND a.provetid_til >= CURRENT_DATE THEN true
    ELSE false
  END AS i_provetid,
  -- Days until probation ends
  CASE 
    WHEN a.status = 'Aktiv' AND a.provetid_til IS NOT NULL AND a.provetid_til >= CURRENT_DATE 
    THEN a.provetid_til - CURRENT_DATE
    ELSE NULL
  END AS dager_til_provetid_slutt,
  -- Status display text
  CASE a.status
    WHEN 'Aktiv' THEN 'Aktiv'
    WHEN 'Permisjon' THEN 'Permisjon'
    WHEN 'Arkivert' THEN 'Arkivert'
    ELSE a.status::text
  END AS status_display,
  -- Role display text
  CASE 
    WHEN a.lederstilling IS NOT NULL AND a.frisorfunksjon IS NOT NULL 
    THEN CONCAT(
      CASE a.frisorfunksjon 
        WHEN 'frisor' THEN 'Frisør'
        WHEN 'senior_frisor' THEN 'Senior Frisør'
        WHEN 'laerling' THEN 'Lærling'
      END,
      ' / ',
      CASE a.lederstilling
        WHEN 'daglig_leder' THEN 'Daglig leder'
        WHEN 'avdelingsleder' THEN 'Avdelingsleder'
        WHEN 'styreleder' THEN 'Styreleder'
      END
    )
    WHEN a.lederstilling IS NOT NULL THEN
      CASE a.lederstilling
        WHEN 'daglig_leder' THEN 'Daglig leder'
        WHEN 'avdelingsleder' THEN 'Avdelingsleder'
        WHEN 'styreleder' THEN 'Styreleder'
      END
    WHEN a.frisorfunksjon IS NOT NULL THEN
      CASE a.frisorfunksjon 
        WHEN 'frisor' THEN 'Frisør'
        WHEN 'senior_frisor' THEN 'Senior Frisør'
        WHEN 'laerling' THEN 'Lærling'
      END
    ELSE 'Ikke definert'
  END AS rolle_display,
  -- Frisorfunksjon display text
  CASE a.frisorfunksjon 
    WHEN 'frisor' THEN 'Frisør'
    WHEN 'senior_frisor' THEN 'Senior Frisør'
    WHEN 'laerling' THEN 'Lærling'
    ELSE NULL
  END AS frisorfunksjon_display,
  -- Lederstilling display text
  CASE a.lederstilling
    WHEN 'daglig_leder' THEN 'Daglig leder'
    WHEN 'avdelingsleder' THEN 'Avdelingsleder'
    WHEN 'styreleder' THEN 'Styreleder'
    ELSE NULL
  END AS lederstilling_display,
  -- Effective inclusion flags (frisorfunksjon overrides manual setting)
  CASE 
    WHEN a.frisorfunksjon IS NOT NULL THEN true
    ELSE COALESCE(a.inkluder_i_turnus, false)
  END AS effektiv_inkluder_i_turnus,
  CASE 
    WHEN a.frisorfunksjon IS NOT NULL THEN true
    ELSE COALESCE(a.inkluder_i_budsjett, false)
  END AS effektiv_inkluder_i_budsjett
FROM public.ansatte a;