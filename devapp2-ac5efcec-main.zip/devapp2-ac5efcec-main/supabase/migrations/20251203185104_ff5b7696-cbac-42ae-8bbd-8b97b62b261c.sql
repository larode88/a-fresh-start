-- Fiks search_path for beregn_maanedslonn
CREATE OR REPLACE FUNCTION public.beregn_maanedslonn(p_timesats numeric, p_stillingsprosent numeric DEFAULT 100)
RETURNS numeric
LANGUAGE sql
IMMUTABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT (p_timesats * 162.5 * (p_stillingsprosent / 100))::numeric(12,2)
$$;