-- Add withdrawn status to insurance_quote_status enum
ALTER TYPE insurance_quote_status ADD VALUE IF NOT EXISTS 'withdrawn';

-- Add withdrawn_at column to insurance_quotes table
ALTER TABLE insurance_quotes ADD COLUMN IF NOT EXISTS withdrawn_at timestamp with time zone;