-- Tabell for fullmakter med OTP-verifisering
CREATE TABLE public.insurance_power_of_attorney (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  
  -- Salonginformasjon
  salon_name TEXT NOT NULL,
  org_number TEXT NOT NULL,
  contact_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  
  -- Kobling til eksisterende salon (hvis funnet)
  salon_id UUID REFERENCES public.salons(id),
  
  -- OTP
  otp_code_hash TEXT NOT NULL,
  otp_expires_at TIMESTAMPTZ NOT NULL,
  otp_attempts INTEGER DEFAULT 0,
  
  -- Signering
  signed BOOLEAN DEFAULT false,
  signed_at TIMESTAMPTZ,
  ip_address TEXT,
  user_agent TEXT,
  
  -- Samtykker
  consent_transfer BOOLEAN DEFAULT false,
  consent_privacy BOOLEAN DEFAULT false,
  
  -- PDF (for senere)
  pdf_url TEXT,
  
  -- Metadata
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  
  -- Varsling
  admin_notified_at TIMESTAMPTZ
);

-- Indekser
CREATE INDEX idx_poa_email ON public.insurance_power_of_attorney(email);
CREATE INDEX idx_poa_org_number ON public.insurance_power_of_attorney(org_number);
CREATE INDEX idx_poa_signed ON public.insurance_power_of_attorney(signed);
CREATE INDEX idx_poa_created_at ON public.insurance_power_of_attorney(created_at DESC);

-- RLS Policies
ALTER TABLE public.insurance_power_of_attorney ENABLE ROW LEVEL SECURITY;

-- Admin kan gjøre alt
CREATE POLICY "Admins can manage all POA" ON public.insurance_power_of_attorney
  FOR ALL USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- Offentlig kan opprette (for skjema - ingen auth)
CREATE POLICY "Public can insert POA" ON public.insurance_power_of_attorney
  FOR INSERT WITH CHECK (true);

-- Offentlig kan lese (for verifisering)
CREATE POLICY "Public can read POA for verification" ON public.insurance_power_of_attorney
  FOR SELECT USING (true);

-- Offentlig kan oppdatere (for verifisering)
CREATE POLICY "Public can update POA for verification" ON public.insurance_power_of_attorney
  FOR UPDATE USING (true);

-- Trigger for updated_at
CREATE TRIGGER update_poa_updated_at
  BEFORE UPDATE ON public.insurance_power_of_attorney
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Funksjon for å koble POA til eksisterende salong basert på org_number
CREATE OR REPLACE FUNCTION public.link_poa_to_salon()
RETURNS TRIGGER AS $$
BEGIN
  -- Prøv å finne salong med matchende org_number
  SELECT id INTO NEW.salon_id
  FROM public.salons
  WHERE org_number = NEW.org_number
  LIMIT 1;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Trigger for å automatisk koble POA til salong
CREATE TRIGGER link_poa_to_salon_trigger
  BEFORE INSERT ON public.insurance_power_of_attorney
  FOR EACH ROW
  EXECUTE FUNCTION public.link_poa_to_salon();