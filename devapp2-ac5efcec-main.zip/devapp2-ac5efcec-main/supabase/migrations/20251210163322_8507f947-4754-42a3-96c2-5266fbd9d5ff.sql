-- Drop existing policy
DROP POLICY IF EXISTS "Salon owners can manage their salon samtaler" ON ansatt_samtaler;

-- Create updated policy including daglig_leder and avdelingsleder
CREATE POLICY "Salon managers can manage their salon samtaler" 
ON ansatt_samtaler 
FOR ALL 
USING (
  salon_id = get_user_salon_id(auth.uid()) 
  AND (
    is_salon_owner(auth.uid()) 
    OR has_role(auth.uid(), 'daglig_leder'::app_role)
    OR has_role(auth.uid(), 'avdelingsleder'::app_role)
  )
)
WITH CHECK (
  salon_id = get_user_salon_id(auth.uid()) 
  AND (
    is_salon_owner(auth.uid()) 
    OR has_role(auth.uid(), 'daglig_leder'::app_role)
    OR has_role(auth.uid(), 'avdelingsleder'::app_role)
  )
);