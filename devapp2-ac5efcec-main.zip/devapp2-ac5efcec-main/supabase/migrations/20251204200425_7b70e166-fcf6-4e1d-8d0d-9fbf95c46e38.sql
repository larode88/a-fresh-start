-- Add new columns to insurance_orders for Frende info, switching, and POA
ALTER TABLE insurance_orders ADD COLUMN IF NOT EXISTS antall_ansatte integer;
ALTER TABLE insurance_orders ADD COLUMN IF NOT EXISTS antall_arsverk numeric;
ALTER TABLE insurance_orders ADD COLUMN IF NOT EXISTS aarlig_omsetning numeric;
ALTER TABLE insurance_orders ADD COLUMN IF NOT EXISTS switching_provider boolean DEFAULT false;
ALTER TABLE insurance_orders ADD COLUMN IF NOT EXISTS previous_insurances jsonb;
ALTER TABLE insurance_orders ADD COLUMN IF NOT EXISTS poa_signature_name text;
ALTER TABLE insurance_orders ADD COLUMN IF NOT EXISTS poa_signature_at timestamptz;
ALTER TABLE insurance_orders ADD COLUMN IF NOT EXISTS desired_start_date date;

-- Add new columns to salon_insurance for HubSpot sync
ALTER TABLE salon_insurance ADD COLUMN IF NOT EXISTS bytter_selskap boolean DEFAULT false;
ALTER TABLE salon_insurance ADD COLUMN IF NOT EXISTS tidligere_forsikringer text;
ALTER TABLE salon_insurance ADD COLUMN IF NOT EXISTS bestillingsdato date;
ALTER TABLE salon_insurance ADD COLUMN IF NOT EXISTS oppstartsdato date;