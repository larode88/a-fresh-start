-- Oppdater valid_uke_type constraint i turnus_preferanser for å fjerne fireuke/uke4
-- Dropp eksisterende constraint og opprett ny uten uke4

-- Først oppdater beregn_uke_type funksjonen for å fjerne fireuke-støtte
CREATE OR REPLACE FUNCTION public.beregn_uke_type(p_dato date, p_gyldig_fra date, p_turnus_type text)
 RETURNS text
 LANGUAGE plpgsql
 IMMUTABLE
 SET search_path TO 'public'
AS $function$
DECLARE
  v_iso_week INTEGER;
  v_uker_siden_start INTEGER;
  v_rotasjon_index INTEGER;
BEGIN
  IF p_turnus_type = 'touke' THEN
    v_iso_week := EXTRACT(WEEK FROM p_dato)::INTEGER;
    IF v_iso_week % 2 = 0 THEN RETURN 'oddetall'; ELSE RETURN 'partall'; END IF;
  ELSIF p_turnus_type = 'treuke' THEN
    v_uker_siden_start := FLOOR((p_dato - p_gyldig_fra) / 7)::INTEGER;
    v_rotasjon_index := v_uker_siden_start % 3;
    RETURN CASE v_rotasjon_index WHEN 0 THEN 'uke1' WHEN 1 THEN 'uke2' ELSE 'uke3' END;
  ELSE
    -- enkel turnus - returnerer partall som standard
    RETURN 'partall';
  END IF;
END;
$function$;

-- Opprett get_turnus_stillingsprosent funksjon for server-side beregning
CREATE OR REPLACE FUNCTION public.get_turnus_stillingsprosent(
  p_user_id UUID,
  p_salon_id UUID
)
RETURNS TABLE (
  turnus_type TEXT,
  gjennomsnittlig_timer NUMERIC,
  stillingsprosent NUMERIC,
  uker_detaljer JSONB
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_turnus_type TEXT;
  v_total_timer NUMERIC := 0;
  v_antall_uker INTEGER;
  v_uker_data JSONB := '[]'::JSONB;
BEGIN
  -- Finn turnustype fra aktive maler (ansatt_turnus uten gyldig_til)
  SELECT CASE
    WHEN EXISTS (SELECT 1 FROM ansatt_turnus WHERE user_id = p_user_id AND salon_id = p_salon_id AND gyldig_til IS NULL AND uke_type IN ('uke1', 'uke2', 'uke3')) THEN 'treuke'
    WHEN EXISTS (SELECT 1 FROM ansatt_turnus WHERE user_id = p_user_id AND salon_id = p_salon_id AND gyldig_til IS NULL AND uke_type IN ('partall', 'oddetall')) THEN 'touke'
    ELSE 'enkel'
  END INTO v_turnus_type;
  
  -- Sett antall uker basert på turnustype
  v_antall_uker := CASE v_turnus_type
    WHEN 'touke' THEN 2
    WHEN 'treuke' THEN 3
    ELSE 1
  END;
  
  -- Beregn timer per uketype
  WITH uke_timer AS (
    SELECT 
      at.uke_type,
      SUM(
        CASE 
          WHEN NOT at.fridag AND at.start_tid IS NOT NULL AND at.slutt_tid IS NOT NULL THEN
            GREATEST(0,
              EXTRACT(EPOCH FROM (at.slutt_tid - at.start_tid)) / 3600
              - CASE WHEN EXTRACT(EPOCH FROM (at.slutt_tid - at.start_tid)) / 3600 > 5.5 THEN 0.5 ELSE 0 END  -- 30 min pause for skift over 5.5t
            )
          ELSE 0
        END
      ) as timer
    FROM ansatt_turnus at
    WHERE at.user_id = p_user_id
      AND at.salon_id = p_salon_id
      AND at.gyldig_til IS NULL
    GROUP BY at.uke_type
  )
  SELECT 
    COALESCE(SUM(timer), 0),
    COALESCE(jsonb_agg(jsonb_build_object(
      'uke_type', uke_type,
      'timer', ROUND(timer, 1),
      'prosent', ROUND((timer / 37.5) * 100, 1)
    )), '[]'::JSONB)
  INTO v_total_timer, v_uker_data
  FROM uke_timer;
  
  -- Returner resultater
  RETURN QUERY SELECT
    v_turnus_type,
    ROUND(v_total_timer / GREATEST(v_antall_uker, 1), 1),
    ROUND((v_total_timer / GREATEST(v_antall_uker, 1) / 37.5) * 100, 1),
    v_uker_data;
END;
$$;

-- Kommenter: uke_type enum i databasen inneholder fortsatt 'uke4', men dette er nå deprecated
-- Frontend og backend ignorerer 'uke4'-verdier og støtter kun touke og treuke turnustyper