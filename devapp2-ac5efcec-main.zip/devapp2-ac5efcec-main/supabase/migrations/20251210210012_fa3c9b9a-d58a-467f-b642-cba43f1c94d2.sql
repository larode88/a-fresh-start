-- Add Adobe Sign related columns to innmelding_utkast
ALTER TABLE public.innmelding_utkast 
ADD COLUMN IF NOT EXISTS adobe_agreement_id TEXT,
ADD COLUMN IF NOT EXISTS adobe_signing_status TEXT DEFAULT 'not_started',
ADD COLUMN IF NOT EXISTS pdf_draft_url TEXT,
ADD COLUMN IF NOT EXISTS signed_pdf_url TEXT,
ADD COLUMN IF NOT EXISTS agreement_sent_at TIMESTAMP WITH TIME ZONE,
ADD COLUMN IF NOT EXISTS agreement_signed_at TIMESTAMP WITH TIME ZONE,
ADD COLUMN IF NOT EXISTS member_activated_at TIMESTAMP WITH TIME ZONE;

-- Create avtaler table for all agreements (both new and re-signing)
CREATE TABLE IF NOT EXISTS public.avtaler (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  salon_id UUID REFERENCES public.salons(id) ON DELETE SET NULL,
  innmelding_utkast_id UUID REFERENCES public.innmelding_utkast(id) ON DELETE SET NULL,
  
  -- Agreement details
  avtale_type TEXT NOT NULL DEFAULT 'medlemsavtale',
  org_nummer TEXT NOT NULL,
  salongnavn TEXT NOT NULL,
  kontaktperson_navn TEXT,
  kontaktperson_epost TEXT,
  medlemsniva TEXT,
  startdato DATE,
  
  -- Adobe Sign
  adobe_agreement_id TEXT,
  signing_status TEXT DEFAULT 'not_started',
  pdf_draft_url TEXT,
  signed_pdf_url TEXT,
  
  -- Timestamps
  sent_at TIMESTAMP WITH TIME ZONE,
  viewed_at TIMESTAMP WITH TIME ZONE,
  signed_at TIMESTAMP WITH TIME ZONE,
  completed_at TIMESTAMP WITH TIME ZONE,
  
  -- Metadata
  created_by UUID REFERENCES public.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  
  -- District filtering
  district_id UUID REFERENCES public.districts(id),
  hubspot_owner_id TEXT
);

-- Create avtale_logg for audit trail
CREATE TABLE IF NOT EXISTS public.avtale_logg (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  avtale_id UUID NOT NULL REFERENCES public.avtaler(id) ON DELETE CASCADE,
  hendelse TEXT NOT NULL,
  detaljer TEXT,
  adobe_melding TEXT,
  utfort_av UUID REFERENCES public.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.avtaler ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.avtale_logg ENABLE ROW LEVEL SECURITY;

-- RLS policies for avtaler
CREATE POLICY "Admins can manage all avtaler" ON public.avtaler
  FOR ALL USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "District managers can view their district avtaler" ON public.avtaler
  FOR SELECT USING (
    has_role(auth.uid(), 'district_manager') 
    AND district_id = get_user_district_id(auth.uid())
  );

CREATE POLICY "District managers can create avtaler in their district" ON public.avtaler
  FOR INSERT WITH CHECK (
    has_role(auth.uid(), 'district_manager') 
    AND district_id = get_user_district_id(auth.uid())
  );

CREATE POLICY "District managers can update their district avtaler" ON public.avtaler
  FOR UPDATE USING (
    has_role(auth.uid(), 'district_manager') 
    AND district_id = get_user_district_id(auth.uid())
  );

-- RLS policies for avtale_logg
CREATE POLICY "Admins can view all avtale_logg" ON public.avtale_logg
  FOR ALL USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "District managers can view their avtale logg" ON public.avtale_logg
  FOR SELECT USING (
    has_role(auth.uid(), 'district_manager') 
    AND EXISTS (
      SELECT 1 FROM public.avtaler a 
      WHERE a.id = avtale_logg.avtale_id 
      AND a.district_id = get_user_district_id(auth.uid())
    )
  );

CREATE POLICY "District managers can create avtale logg entries" ON public.avtale_logg
  FOR INSERT WITH CHECK (
    has_role(auth.uid(), 'district_manager') 
    AND EXISTS (
      SELECT 1 FROM public.avtaler a 
      WHERE a.id = avtale_logg.avtale_id 
      AND a.district_id = get_user_district_id(auth.uid())
    )
  );

-- Index for performance
CREATE INDEX IF NOT EXISTS idx_avtaler_salon_id ON public.avtaler(salon_id);
CREATE INDEX IF NOT EXISTS idx_avtaler_district_id ON public.avtaler(district_id);
CREATE INDEX IF NOT EXISTS idx_avtaler_signing_status ON public.avtaler(signing_status);
CREATE INDEX IF NOT EXISTS idx_avtale_logg_avtale_id ON public.avtale_logg(avtale_id);

-- Trigger for updated_at
CREATE TRIGGER update_avtaler_updated_at
  BEFORE UPDATE ON public.avtaler
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();