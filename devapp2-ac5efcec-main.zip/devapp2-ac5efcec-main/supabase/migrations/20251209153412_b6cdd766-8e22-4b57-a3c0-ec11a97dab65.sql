-- Add missing columns for membership management (Hår1 as master)
ALTER TABLE public.salons ADD COLUMN IF NOT EXISTS bankkontonummer text;
ALTER TABLE public.salons ADD COLUMN IF NOT EXISTS lifecyclestage text;

-- Add comment for documentation
COMMENT ON COLUMN public.salons.bankkontonummer IS 'Salongens bankkontonummer - synkes til HubSpot';
COMMENT ON COLUMN public.salons.lifecyclestage IS 'HubSpot lifecycle stage - managed locally, synced to HubSpot';
COMMENT ON COLUMN public.salons.medlemsnummer IS 'Tripletex kunde-ID - synkes til HubSpot som kundenummer';
COMMENT ON COLUMN public.salons.medlemsavgift IS 'Årlig medlemsavgift - synkes til HubSpot';
COMMENT ON COLUMN public.salons.type_medlemskap IS 'Type medlemskap (enum) - synkes til HubSpot som medlmestype/type_medlemskap';