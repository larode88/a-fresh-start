
-- Phase 1: Insurance Ordering System Database Structure

-- 1.1 Create enums
CREATE TYPE insurance_product_type AS ENUM (
  'salong', 'yrkesskade', 'cyber', 'reise', 'fritidsulykke', 'helse'
);

CREATE TYPE insurance_price_model AS ENUM (
  'fast', 'per_arsverk', 'per_person'
);

CREATE TYPE insurance_order_status AS ENUM (
  'draft', 'pending_approval', 'approved', 'rejected', 
  'sent_to_frende', 'completed', 'cancelled'
);

CREATE TYPE insurance_order_type AS ENUM (
  'new', 'change', 'cancellation'
);

-- 1.2 Create insurance_products table
CREATE TABLE public.insurance_products (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  product_type insurance_product_type NOT NULL,
  price_model insurance_price_model NOT NULL,
  base_price NUMERIC(10,2) NOT NULL,
  requires_employee_selection BOOLEAN DEFAULT false,
  active BOOLEAN DEFAULT true,
  sort_order INTEGER DEFAULT 0,
  icon_name TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- 1.3 Create insurance_product_tiers table (for Salongforsikring levels)
CREATE TABLE public.insurance_product_tiers (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  product_id UUID NOT NULL REFERENCES public.insurance_products(id) ON DELETE CASCADE,
  tier_name TEXT NOT NULL,
  tier_description TEXT,
  price NUMERIC(10,2) NOT NULL,
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- 1.4 Create insurance_coverage_details table (coverage table for each tier)
CREATE TABLE public.insurance_coverage_details (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tier_id UUID NOT NULL REFERENCES public.insurance_product_tiers(id) ON DELETE CASCADE,
  coverage_type TEXT NOT NULL,
  coverage_value TEXT NOT NULL,
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- 1.5 Create insurance_product_documents table
CREATE TABLE public.insurance_product_documents (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  product_id UUID NOT NULL REFERENCES public.insurance_products(id) ON DELETE CASCADE,
  document_type TEXT NOT NULL DEFAULT 'vilkar',
  title TEXT NOT NULL,
  file_url TEXT NOT NULL,
  version TEXT,
  uploaded_by UUID REFERENCES public.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- 1.6 Create insurance_orders table
CREATE TABLE public.insurance_orders (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  salon_id UUID NOT NULL REFERENCES public.salons(id) ON DELETE CASCADE,
  ordered_by_user_id UUID NOT NULL REFERENCES public.users(id),
  status insurance_order_status NOT NULL DEFAULT 'draft',
  order_type insurance_order_type NOT NULL DEFAULT 'new',
  total_price NUMERIC(10,2) DEFAULT 0,
  contact_name TEXT,
  contact_email TEXT,
  contact_phone TEXT,
  admin_notes TEXT,
  rejection_reason TEXT,
  approved_by_user_id UUID REFERENCES public.users(id),
  approved_at TIMESTAMP WITH TIME ZONE,
  sent_to_frende_at TIMESTAMP WITH TIME ZONE,
  frende_reference TEXT,
  completed_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- 1.7 Create insurance_order_items table
CREATE TABLE public.insurance_order_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  order_id UUID NOT NULL REFERENCES public.insurance_orders(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES public.insurance_products(id),
  tier_id UUID REFERENCES public.insurance_product_tiers(id),
  quantity INTEGER DEFAULT 1,
  unit_price NUMERIC(10,2) NOT NULL,
  total_price NUMERIC(10,2) NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- 1.8 Create insurance_order_employees table (for per-person products)
CREATE TABLE public.insurance_order_employees (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  order_item_id UUID NOT NULL REFERENCES public.insurance_order_items(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE(order_item_id, user_id)
);

-- 1.9 Create indexes for performance
CREATE INDEX idx_insurance_orders_salon_id ON public.insurance_orders(salon_id);
CREATE INDEX idx_insurance_orders_status ON public.insurance_orders(status);
CREATE INDEX idx_insurance_order_items_order_id ON public.insurance_order_items(order_id);
CREATE INDEX idx_insurance_product_tiers_product_id ON public.insurance_product_tiers(product_id);

-- 1.10 Create updated_at triggers
CREATE TRIGGER update_insurance_products_updated_at
  BEFORE UPDATE ON public.insurance_products
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_insurance_product_tiers_updated_at
  BEFORE UPDATE ON public.insurance_product_tiers
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_insurance_orders_updated_at
  BEFORE UPDATE ON public.insurance_orders
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- 1.11 Enable RLS on all tables
ALTER TABLE public.insurance_products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.insurance_product_tiers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.insurance_coverage_details ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.insurance_product_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.insurance_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.insurance_order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.insurance_order_employees ENABLE ROW LEVEL SECURITY;

-- 1.12 RLS Policies for insurance_products (read for all authenticated, manage for admin)
CREATE POLICY "Authenticated users can view active products"
  ON public.insurance_products FOR SELECT
  USING (auth.uid() IS NOT NULL AND active = true);

CREATE POLICY "Admins can view all products"
  ON public.insurance_products FOR SELECT
  USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can manage products"
  ON public.insurance_products FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- 1.13 RLS Policies for insurance_product_tiers
CREATE POLICY "Authenticated users can view tiers"
  ON public.insurance_product_tiers FOR SELECT
  USING (auth.uid() IS NOT NULL);

CREATE POLICY "Admins can manage tiers"
  ON public.insurance_product_tiers FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- 1.14 RLS Policies for insurance_coverage_details
CREATE POLICY "Authenticated users can view coverage details"
  ON public.insurance_coverage_details FOR SELECT
  USING (auth.uid() IS NOT NULL);

CREATE POLICY "Admins can manage coverage details"
  ON public.insurance_coverage_details FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- 1.15 RLS Policies for insurance_product_documents
CREATE POLICY "Authenticated users can view documents"
  ON public.insurance_product_documents FOR SELECT
  USING (auth.uid() IS NOT NULL);

CREATE POLICY "Admins can manage documents"
  ON public.insurance_product_documents FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- 1.16 RLS Policies for insurance_orders
CREATE POLICY "Admins can manage all orders"
  ON public.insurance_orders FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "District managers can view orders in their district"
  ON public.insurance_orders FOR SELECT
  USING (
    has_role(auth.uid(), 'district_manager'::app_role) 
    AND salon_id IN (SELECT get_district_salon_ids(auth.uid()))
  );

CREATE POLICY "Salon owners can manage their orders"
  ON public.insurance_orders FOR ALL
  USING (
    salon_id = get_user_salon_id(auth.uid()) 
    AND (is_salon_owner(auth.uid()) OR has_role(auth.uid(), 'daglig_leder'::app_role))
  )
  WITH CHECK (
    salon_id = get_user_salon_id(auth.uid()) 
    AND (is_salon_owner(auth.uid()) OR has_role(auth.uid(), 'daglig_leder'::app_role))
  );

-- 1.17 RLS Policies for insurance_order_items
CREATE POLICY "Admins can manage all order items"
  ON public.insurance_order_items FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Users can view order items for accessible orders"
  ON public.insurance_order_items FOR SELECT
  USING (
    order_id IN (
      SELECT id FROM public.insurance_orders 
      WHERE salon_id = get_user_salon_id(auth.uid())
         OR has_role(auth.uid(), 'admin'::app_role)
         OR (has_role(auth.uid(), 'district_manager'::app_role) AND salon_id IN (SELECT get_district_salon_ids(auth.uid())))
    )
  );

CREATE POLICY "Salon owners can manage their order items"
  ON public.insurance_order_items FOR ALL
  USING (
    order_id IN (
      SELECT id FROM public.insurance_orders 
      WHERE salon_id = get_user_salon_id(auth.uid())
        AND (is_salon_owner(auth.uid()) OR has_role(auth.uid(), 'daglig_leder'::app_role))
    )
  )
  WITH CHECK (
    order_id IN (
      SELECT id FROM public.insurance_orders 
      WHERE salon_id = get_user_salon_id(auth.uid())
        AND (is_salon_owner(auth.uid()) OR has_role(auth.uid(), 'daglig_leder'::app_role))
    )
  );

-- 1.18 RLS Policies for insurance_order_employees
CREATE POLICY "Admins can manage all order employees"
  ON public.insurance_order_employees FOR ALL
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Users can view order employees for accessible orders"
  ON public.insurance_order_employees FOR SELECT
  USING (
    order_item_id IN (
      SELECT oi.id FROM public.insurance_order_items oi
      JOIN public.insurance_orders o ON oi.order_id = o.id
      WHERE o.salon_id = get_user_salon_id(auth.uid())
         OR has_role(auth.uid(), 'admin'::app_role)
    )
  );

CREATE POLICY "Salon owners can manage their order employees"
  ON public.insurance_order_employees FOR ALL
  USING (
    order_item_id IN (
      SELECT oi.id FROM public.insurance_order_items oi
      JOIN public.insurance_orders o ON oi.order_id = o.id
      WHERE o.salon_id = get_user_salon_id(auth.uid())
        AND (is_salon_owner(auth.uid()) OR has_role(auth.uid(), 'daglig_leder'::app_role))
    )
  )
  WITH CHECK (
    order_item_id IN (
      SELECT oi.id FROM public.insurance_order_items oi
      JOIN public.insurance_orders o ON oi.order_id = o.id
      WHERE o.salon_id = get_user_salon_id(auth.uid())
        AND (is_salon_owner(auth.uid()) OR has_role(auth.uid(), 'daglig_leder'::app_role))
    )
  );

-- 1.19 Create storage bucket for insurance documents
INSERT INTO storage.buckets (id, name, public) 
VALUES ('insurance-documents', 'insurance-documents', true)
ON CONFLICT (id) DO NOTHING;

-- 1.20 Storage policies for insurance-documents bucket
CREATE POLICY "Anyone can view insurance documents"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'insurance-documents');

CREATE POLICY "Admins can upload insurance documents"
  ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'insurance-documents' AND has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can update insurance documents"
  ON storage.objects FOR UPDATE
  USING (bucket_id = 'insurance-documents' AND has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can delete insurance documents"
  ON storage.objects FOR DELETE
  USING (bucket_id = 'insurance-documents' AND has_role(auth.uid(), 'admin'::app_role));

-- 1.21 Insert initial product data
INSERT INTO public.insurance_products (name, description, product_type, price_model, base_price, requires_employee_selection, sort_order, icon_name) VALUES
('Helseforsikring', 'Privat helseforsikring for ansatte med rask tilgang til spesialist og behandling.', 'helse', 'per_person', 5050.00, true, 1, 'Heart'),
('Salongforsikring', 'Dekker skader på maskiner, inventar, løsøre og varer i salongen. Inkluderer brann, vann, innbrudd, tyveri, hærverk og naturskade.', 'salong', 'fast', 0, false, 2, 'Building2'),
('Utvidet Yrkesskade', 'Utvidet yrkesskadeforsikring som gir bedre dekning enn lovpålagt minimum.', 'yrkesskade', 'per_arsverk', 1499.00, false, 3, 'Shield'),
('Fritidsulykke', 'Ulykkesforsikring som dekker ansatte på fritiden.', 'fritidsulykke', 'per_person', 949.00, true, 4, 'Activity'),
('Reiseforsikring', 'Komplett reiseforsikring for ansatte med dekning verden over.', 'reise', 'per_person', 1499.00, true, 5, 'Plane'),
('Cyberforsikring', 'Beskytter mot datatap, hacking og cyberangrep.', 'cyber', 'fast', 949.00, false, 6, 'ShieldCheck');

-- 1.22 Get the Salongforsikring product ID and insert tiers
DO $$
DECLARE
  salong_product_id UUID;
  tier1_id UUID;
  tier2_id UUID;
  tier3_id UUID;
BEGIN
  SELECT id INTO salong_product_id FROM public.insurance_products WHERE product_type = 'salong' LIMIT 1;
  
  -- Insert tiers
  INSERT INTO public.insurance_product_tiers (product_id, tier_name, tier_description, price, sort_order)
  VALUES (salong_product_id, 'Nivå 1', 'Grunnleggende dekning for mindre salonger', 2799.00, 1)
  RETURNING id INTO tier1_id;
  
  INSERT INTO public.insurance_product_tiers (product_id, tier_name, tier_description, price, sort_order)
  VALUES (salong_product_id, 'Nivå 2', 'Utvidet dekning for mellomstore salonger', 3299.00, 2)
  RETURNING id INTO tier2_id;
  
  INSERT INTO public.insurance_product_tiers (product_id, tier_name, tier_description, price, sort_order)
  VALUES (salong_product_id, 'Nivå 3', 'Fullverdig dekning for større salonger', 4109.00, 3)
  RETURNING id INTO tier3_id;
  
  -- Insert coverage details for Tier 1
  INSERT INTO public.insurance_coverage_details (tier_id, coverage_type, coverage_value, sort_order) VALUES
  (tier1_id, 'Tingdekning', '500 000 kr', 1),
  (tier1_id, 'Naturskade', '500 000 kr', 2),
  (tier1_id, 'Glass', '50 000 kr', 3),
  (tier1_id, 'Kasko', '500 000 kr', 4),
  (tier1_id, 'Maskinskade', '500 000 kr', 5),
  (tier1_id, 'Avbruddstap', '2 000 000 kr', 6),
  (tier1_id, 'Ansvarstid', '12 mnd', 7),
  (tier1_id, 'Egenandel', '15 000 kr', 8),
  (tier1_id, 'Egenandel glass', '5 000 kr', 9);
  
  -- Insert coverage details for Tier 2
  INSERT INTO public.insurance_coverage_details (tier_id, coverage_type, coverage_value, sort_order) VALUES
  (tier2_id, 'Tingdekning', '1 000 000 kr', 1),
  (tier2_id, 'Naturskade', '1 000 000 kr', 2),
  (tier2_id, 'Glass', '50 000 kr', 3),
  (tier2_id, 'Kasko', '1 000 000 kr', 4),
  (tier2_id, 'Maskinskade', '1 000 000 kr', 5),
  (tier2_id, 'Avbruddstap', '3 000 000 kr', 6),
  (tier2_id, 'Ansvarstid', '12 mnd', 7),
  (tier2_id, 'Egenandel', '15 000 kr', 8),
  (tier2_id, 'Egenandel glass', '5 000 kr', 9);
  
  -- Insert coverage details for Tier 3
  INSERT INTO public.insurance_coverage_details (tier_id, coverage_type, coverage_value, sort_order) VALUES
  (tier3_id, 'Tingdekning', '2 000 000 kr', 1),
  (tier3_id, 'Naturskade', '2 000 000 kr', 2),
  (tier3_id, 'Glass', '50 000 kr', 3),
  (tier3_id, 'Kasko', '2 000 000 kr', 4),
  (tier3_id, 'Maskinskade', '2 000 000 kr', 5),
  (tier3_id, 'Avbruddstap', '5 000 000 kr', 6),
  (tier3_id, 'Ansvarstid', '12 mnd', 7),
  (tier3_id, 'Egenandel', '15 000 kr', 8),
  (tier3_id, 'Egenandel glass', '5 000 kr', 9);
END $$;
