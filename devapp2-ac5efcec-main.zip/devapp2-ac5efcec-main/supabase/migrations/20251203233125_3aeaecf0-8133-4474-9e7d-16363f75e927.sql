-- Create salon-logos storage bucket
INSERT INTO storage.buckets (id, name, public)
VALUES ('salon-logos', 'salon-logos', true)
ON CONFLICT (id) DO NOTHING;

-- Allow authenticated users to upload salon logos (admins only via RLS on salons table)
CREATE POLICY "Authenticated users can upload salon logos"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'salon-logos');

-- Allow authenticated users to update salon logos
CREATE POLICY "Authenticated users can update salon logos"
ON storage.objects
FOR UPDATE
TO authenticated
USING (bucket_id = 'salon-logos');

-- Allow public read access to salon logos
CREATE POLICY "Public can view salon logos"
ON storage.objects
FOR SELECT
USING (bucket_id = 'salon-logos');