-- =============================================================================
-- Migration: Add salon leader UPDATE access and fix inconsistent admin policies
-- =============================================================================

-- 1. Add new policy: Salon leaders can update their own salon
CREATE POLICY "Salon leaders can update their salon"
ON public.salons
FOR UPDATE
TO authenticated
USING (
  is_salon_leader(auth.uid())
  AND id = get_user_salon_id(auth.uid())
)
WITH CHECK (
  is_salon_leader(auth.uid())
  AND id = get_user_salon_id(auth.uid())
);

-- 2. Fix inconsistent INSERT policy (was using get_user_role instead of has_role)
DROP POLICY IF EXISTS "Admins can insert salons" ON public.salons;
CREATE POLICY "Admins can insert salons"
ON public.salons
FOR INSERT
TO authenticated
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

-- 3. Fix inconsistent UPDATE policy for admins (was using get_user_role instead of has_role)
DROP POLICY IF EXISTS "Admins can update salons" ON public.salons;
CREATE POLICY "Admins can update salons"
ON public.salons
FOR UPDATE
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));