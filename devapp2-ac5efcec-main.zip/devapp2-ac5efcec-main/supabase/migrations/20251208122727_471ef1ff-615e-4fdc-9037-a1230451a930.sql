
-- =====================================================
-- FASE 1: ANSATTE-MODUL KOMPLETT DATABASESTRUKTUR
-- =====================================================

-- 1. NYE ENUMS
DO $$ BEGIN CREATE TYPE frisorfunksjon AS ENUM ('frisor', 'senior_frisor', 'laerling'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE lederstilling AS ENUM ('daglig_leder', 'avdelingsleder', 'styreleder'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE ansatt_status AS ENUM ('Aktiv', 'Prøvetid', 'Permisjon', 'Arkivert'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE signatur_status AS ENUM ('ikke_pakrevd', 'venter_signatur', 'signert', 'avvist'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE sertifisering_type_v2 AS ENUM ('fagbrev', 'kurs', 'sertifisering', 'godkjenning'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE lonnstype AS ENUM ('timelonn', 'fastlonn', 'provisjon', 'timelonn_provisjon'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN CREATE TYPE feriekrav_type AS ENUM ('lovfestet', 'tariffavtale', 'utvidet'); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- 2. HOVEDTABELL: ANSATTE (70+ KOLONNER)
CREATE TABLE IF NOT EXISTS public.ansatte (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  fornavn TEXT NOT NULL,
  etternavn TEXT,
  salong_id UUID REFERENCES public.salons(id) ON DELETE SET NULL,
  user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  status ansatt_status NOT NULL DEFAULT 'Aktiv',
  frisorfunksjon frisorfunksjon,
  lederstilling lederstilling,
  ansatt_dato DATE,
  stillingsprosent INTEGER NOT NULL DEFAULT 100 CHECK (stillingsprosent >= 0 AND stillingsprosent <= 100),
  arbeidstid_per_uke NUMERIC(4,1) DEFAULT 37.5,
  arbeidsdager_pr_uke INTEGER DEFAULT 5 CHECK (arbeidsdager_pr_uke >= 1 AND arbeidsdager_pr_uke <= 7),
  provetid_til DATE,
  oppsigelsesdato DATE,
  siste_arbeidsdag DATE,
  lonnstype_enum lonnstype,
  timesats NUMERIC(10,2),
  fastlonn NUMERIC(12,2),
  provisjon_behandling_prosent NUMERIC(5,2) DEFAULT 33,
  provisjon_vare_prosent NUMERIC(5,2) DEFAULT 10,
  provisjon_behandling_hoy_prosent NUMERIC(5,2) DEFAULT 35,
  provisjon_terskel NUMERIC(12,2) DEFAULT 0,
  feriekrav_type_enum feriekrav_type DEFAULT 'lovfestet',
  feriekrav_timer_per_aar NUMERIC(6,2) NOT NULL DEFAULT 157.5,
  feriekrav_kommentar TEXT,
  fodselsdato DATE,
  telefon TEXT,
  epost TEXT,
  adresse TEXT,
  postnummer TEXT,
  poststed TEXT,
  kjonn TEXT,
  nasjonalitet TEXT,
  personnummer TEXT,
  bankkontonummer TEXT,
  fagbrev_dato DATE,
  utdanning_fagbrev TEXT,
  kurs_sertifiseringer TEXT,
  mentor_id UUID,
  verdier TEXT,
  motivasjon_i_jobben TEXT,
  beste_del_av_arbeidsdagen TEXT,
  foretrukket_feiring TEXT,
  effektivitet_prosent NUMERIC(5,2) DEFAULT 65,
  omsetning_per_time NUMERIC(10,2) DEFAULT 850,
  varesalg_prosent NUMERIC(5,2) DEFAULT 15,
  rebooking_prosent NUMERIC(5,2) DEFAULT 80,
  budsjett_kilde TEXT DEFAULT 'turnus',
  profilbilde_url TEXT,
  arkivert_dato DATE,
  arkivert_av UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  arkivert_arsak TEXT,
  hubspot_contact_id TEXT,
  hubspot_synced_at TIMESTAMP WITH TIME ZONE,
  helseforsikring_status TEXT,
  helseforsikring_avtalenummer TEXT,
  helseforsikring_oppstartsdato DATE,
  helseforsikring_oppsigelsesdato DATE,
  helseforsikring_pris NUMERIC(10,2) DEFAULT 5050,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

DO $$ BEGIN ALTER TABLE public.ansatte ADD CONSTRAINT fk_ansatte_mentor FOREIGN KEY (mentor_id) REFERENCES public.ansatte(id) ON DELETE SET NULL; EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE INDEX IF NOT EXISTS idx_ansatte_salong_id ON public.ansatte(salong_id);
CREATE INDEX IF NOT EXISTS idx_ansatte_user_id ON public.ansatte(user_id);
CREATE INDEX IF NOT EXISTS idx_ansatte_status ON public.ansatte(status);
CREATE INDEX IF NOT EXISTS idx_ansatte_frisorfunksjon ON public.ansatte(frisorfunksjon);
CREATE INDEX IF NOT EXISTS idx_ansatte_hubspot_contact_id ON public.ansatte(hubspot_contact_id);

CREATE OR REPLACE FUNCTION update_ansatte_updated_at() RETURNS TRIGGER AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END; $$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS trigger_ansatte_updated_at ON public.ansatte;
CREATE TRIGGER trigger_ansatte_updated_at BEFORE UPDATE ON public.ansatte FOR EACH ROW EXECUTE FUNCTION update_ansatte_updated_at();

-- 3. VIEW: ANSATTE_UTVIDET
CREATE OR REPLACE VIEW public.ansatte_utvidet AS
SELECT a.*,
  COALESCE(a.fornavn, '') || ' ' || COALESCE(a.etternavn, '') AS navn,
  CASE WHEN a.fodselsdato IS NOT NULL THEN EXTRACT(YEAR FROM age(CURRENT_DATE, a.fodselsdato))::INTEGER ELSE NULL END AS alder,
  CASE WHEN a.ansatt_dato IS NOT NULL THEN EXTRACT(YEAR FROM age(CURRENT_DATE, a.ansatt_dato))::NUMERIC ELSE NULL END AS ansiennitet_aar,
  CASE WHEN a.ansatt_dato IS NOT NULL THEN (EXTRACT(MONTH FROM age(CURRENT_DATE, a.ansatt_dato)))::INTEGER ELSE NULL END AS ansiennitet_maneder,
  CASE WHEN a.provetid_til IS NOT NULL AND a.provetid_til > CURRENT_DATE THEN 'Prøvetid' ELSE a.status::TEXT END AS status_display,
  CASE 
    WHEN a.frisorfunksjon IS NOT NULL AND a.lederstilling IS NOT NULL THEN
      CASE a.frisorfunksjon WHEN 'frisor' THEN 'Frisør' WHEN 'senior_frisor' THEN 'Senior Frisør' WHEN 'laerling' THEN 'Lærling' END || ' + ' ||
      CASE a.lederstilling WHEN 'daglig_leder' THEN 'Daglig leder' WHEN 'avdelingsleder' THEN 'Avdelingsleder' WHEN 'styreleder' THEN 'Styreleder' END
    WHEN a.frisorfunksjon IS NOT NULL THEN CASE a.frisorfunksjon WHEN 'frisor' THEN 'Frisør' WHEN 'senior_frisor' THEN 'Senior Frisør' WHEN 'laerling' THEN 'Lærling' END
    WHEN a.lederstilling IS NOT NULL THEN CASE a.lederstilling WHEN 'daglig_leder' THEN 'Daglig leder' WHEN 'avdelingsleder' THEN 'Avdelingsleder' WHEN 'styreleder' THEN 'Styreleder' END
    ELSE 'Ingen rolle'
  END AS rolle_display,
  CASE WHEN a.fodselsdato IS NOT NULL THEN TO_CHAR(a.fodselsdato, 'MM-DD') ELSE NULL END AS bursdag_md,
  s.name AS salong_navn
FROM public.ansatte a LEFT JOIN public.salons s ON a.salong_id = s.id;

-- 4. STØTTETABELLER
CREATE TABLE IF NOT EXISTS public.ansatt_endringslogg (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ansatt_id UUID NOT NULL REFERENCES public.ansatte(id) ON DELETE CASCADE,
  tabell_navn TEXT NOT NULL DEFAULT 'ansatte',
  felt_navn TEXT NOT NULL,
  tidligere_verdi TEXT,
  ny_verdi TEXT,
  hendelse_type TEXT NOT NULL DEFAULT 'UPDATE',
  endret_av UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  endret_dato TIMESTAMP WITH TIME ZONE DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_endringslogg_ansatt_id ON public.ansatt_endringslogg(ansatt_id);

CREATE TABLE IF NOT EXISTS public.ansatt_dokumenter_v2 (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ansatt_id UUID NOT NULL REFERENCES public.ansatte(id) ON DELETE CASCADE,
  filnavn TEXT NOT NULL,
  dokument_url TEXT NOT NULL,
  dokument_type TEXT NOT NULL,
  signatur_status signatur_status DEFAULT 'ikke_pakrevd',
  signert_dato TIMESTAMP WITH TIME ZONE,
  versjon INTEGER DEFAULT 1,
  opprettet_av UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.ansatt_sertifiseringer_v2 (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ansatt_id UUID NOT NULL REFERENCES public.ansatte(id) ON DELETE CASCADE,
  navn TEXT NOT NULL,
  type sertifisering_type_v2 DEFAULT 'kurs',
  leverandor TEXT,
  utstedt_dato DATE,
  utloper_dato DATE,
  status TEXT DEFAULT 'aktiv',
  obligatorisk BOOLEAN DEFAULT false,
  sertifikat_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.ansatt_godtgjorelser_v2 (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  ansatt_id UUID NOT NULL REFERENCES public.ansatte(id) ON DELETE CASCADE,
  type TEXT NOT NULL,
  belop NUMERIC(12,2) NOT NULL,
  frekvens TEXT DEFAULT 'maaned',
  beskrivelse TEXT,
  gyldig_fra DATE NOT NULL DEFAULT CURRENT_DATE,
  gyldig_til DATE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- 5. SECURITY DEFINER FUNCTIONS
CREATE OR REPLACE FUNCTION public.has_salong_access(_user_id uuid, _salong_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.ansatte WHERE user_id = _user_id AND salong_id = _salong_id)
  OR EXISTS (SELECT 1 FROM public.user_salon_roles WHERE user_id = _user_id AND salon_id = _salong_id)
  OR EXISTS (SELECT 1 FROM public.salons s JOIN public.user_chain_roles ucr ON s.chain_id = ucr.chain_id WHERE ucr.user_id = _user_id AND s.id = _salong_id)
  OR EXISTS (SELECT 1 FROM public.salons s JOIN public.users u ON u.district_id = s.district_id WHERE u.id = _user_id AND s.id = _salong_id AND has_role(_user_id, 'district_manager'))
$$;

CREATE OR REPLACE FUNCTION public.get_ansatt_id_for_user(_user_id uuid)
RETURNS uuid LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$ SELECT id FROM public.ansatte WHERE user_id = _user_id LIMIT 1 $$;

CREATE OR REPLACE FUNCTION public.is_salong_leder(_user_id uuid, _salong_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.ansatte WHERE user_id = _user_id AND salong_id = _salong_id AND lederstilling IS NOT NULL) OR has_role(_user_id, 'admin')
$$;

-- 6. RLS POLICIES
ALTER TABLE public.ansatte ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ansatt_endringslogg ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ansatt_dokumenter_v2 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ansatt_sertifiseringer_v2 ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ansatt_godtgjorelser_v2 ENABLE ROW LEVEL SECURITY;

CREATE POLICY "ansatte_select_own" ON public.ansatte FOR SELECT USING (user_id = auth.uid());
CREATE POLICY "ansatte_admin_all" ON public.ansatte FOR ALL USING (has_role(auth.uid(), 'admin')) WITH CHECK (has_role(auth.uid(), 'admin'));
CREATE POLICY "ansatte_leder_all" ON public.ansatte FOR ALL USING (is_salong_leder(auth.uid(), salong_id)) WITH CHECK (is_salong_leder(auth.uid(), salong_id));
CREATE POLICY "ansatte_salong_select" ON public.ansatte FOR SELECT USING (has_salong_access(auth.uid(), salong_id));

CREATE POLICY "endringslogg_admin_select" ON public.ansatt_endringslogg FOR SELECT USING (has_role(auth.uid(), 'admin') OR is_admin_or_manager(auth.uid()));
CREATE POLICY "endringslogg_insert" ON public.ansatt_endringslogg FOR INSERT WITH CHECK (true);

CREATE POLICY "dok_v2_admin" ON public.ansatt_dokumenter_v2 FOR ALL USING (has_role(auth.uid(), 'admin')) WITH CHECK (has_role(auth.uid(), 'admin'));
CREATE POLICY "dok_v2_own_select" ON public.ansatt_dokumenter_v2 FOR SELECT USING (ansatt_id = get_ansatt_id_for_user(auth.uid()));
CREATE POLICY "dok_v2_leder" ON public.ansatt_dokumenter_v2 FOR ALL USING (ansatt_id IN (SELECT id FROM public.ansatte WHERE is_salong_leder(auth.uid(), salong_id))) WITH CHECK (ansatt_id IN (SELECT id FROM public.ansatte WHERE is_salong_leder(auth.uid(), salong_id)));

CREATE POLICY "sert_v2_admin" ON public.ansatt_sertifiseringer_v2 FOR ALL USING (has_role(auth.uid(), 'admin')) WITH CHECK (has_role(auth.uid(), 'admin'));
CREATE POLICY "sert_v2_own" ON public.ansatt_sertifiseringer_v2 FOR ALL USING (ansatt_id = get_ansatt_id_for_user(auth.uid())) WITH CHECK (ansatt_id = get_ansatt_id_for_user(auth.uid()));
CREATE POLICY "sert_v2_leder_select" ON public.ansatt_sertifiseringer_v2 FOR SELECT USING (ansatt_id IN (SELECT id FROM public.ansatte WHERE is_salong_leder(auth.uid(), salong_id)));

CREATE POLICY "godt_v2_admin" ON public.ansatt_godtgjorelser_v2 FOR ALL USING (has_role(auth.uid(), 'admin')) WITH CHECK (has_role(auth.uid(), 'admin'));
CREATE POLICY "godt_v2_own_select" ON public.ansatt_godtgjorelser_v2 FOR SELECT USING (ansatt_id = get_ansatt_id_for_user(auth.uid()));
CREATE POLICY "godt_v2_leder" ON public.ansatt_godtgjorelser_v2 FOR ALL USING (ansatt_id IN (SELECT id FROM public.ansatte WHERE is_salong_leder(auth.uid(), salong_id))) WITH CHECK (ansatt_id IN (SELECT id FROM public.ansatte WHERE is_salong_leder(auth.uid(), salong_id)));

-- 7. DATAMIGRERING FRA USERS (kun eksisterende kolonner)
INSERT INTO public.ansatte (
  fornavn, etternavn, salong_id, user_id, status, frisorfunksjon, lederstilling,
  ansatt_dato, stillingsprosent, fodselsdato, telefon, epost, fagbrev_dato,
  timesats, fastlonn, hubspot_contact_id, hubspot_synced_at,
  helseforsikring_status, helseforsikring_avtalenummer, helseforsikring_oppstartsdato,
  helseforsikring_oppsigelsesdato, helseforsikring_pris, profilbilde_url, created_at
)
SELECT 
  COALESCE(u.first_name, SPLIT_PART(COALESCE(u.name, u.email), ' ', 1)),
  COALESCE(u.last_name, CASE WHEN POSITION(' ' IN COALESCE(u.name, '')) > 0 THEN SUBSTRING(u.name FROM POSITION(' ' IN u.name) + 1) ELSE NULL END),
  u.salon_id, u.id,
  CASE WHEN u.aktiv = false THEN 'Arkivert'::ansatt_status ELSE 'Aktiv'::ansatt_status END,
  CASE u.role WHEN 'stylist' THEN 'frisor'::frisorfunksjon WHEN 'seniorfrisor' THEN 'senior_frisor'::frisorfunksjon WHEN 'apprentice' THEN 'laerling'::frisorfunksjon ELSE NULL END,
  CASE u.role WHEN 'daglig_leder' THEN 'daglig_leder'::lederstilling WHEN 'avdelingsleder' THEN 'avdelingsleder'::lederstilling WHEN 'salon_owner' THEN 'daglig_leder'::lederstilling WHEN 'styreleder' THEN 'styreleder'::lederstilling ELSE NULL END,
  u.ansettelsesdato, COALESCE(u.stillingsprosent, 100), u.fodselsdato, u.phone, u.email, u.fagbrevdato,
  u.timesats, u.fastlonn, u.hubspot_contact_id, u.hubspot_synced_at,
  u.helseforsikring_status, u.helseforsikring_avtalenummer, u.helseforsikring_oppstartsdato,
  u.helseforsikring_oppsigelsesdato, COALESCE(u.helseforsikring_pris, 5050), u.avatar_url, u.created_at
FROM public.users u WHERE u.salon_id IS NOT NULL
ON CONFLICT DO NOTHING;

-- 8. STORAGE BUCKET
INSERT INTO storage.buckets (id, name, public) VALUES ('ansatte-profilbilder', 'ansatte-profilbilder', true) ON CONFLICT (id) DO NOTHING;
