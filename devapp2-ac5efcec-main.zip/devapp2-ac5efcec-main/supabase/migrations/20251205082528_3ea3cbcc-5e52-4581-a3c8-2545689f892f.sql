
-- Create function to recalculate sum_totalt
CREATE OR REPLACE FUNCTION public.recalculate_salon_insurance_total()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  new_total numeric := 0;
BEGIN
  -- Calculate sum based on active insurances
  IF NEW.salong_aktiv = true AND NEW.pris_salong IS NOT NULL THEN
    new_total := new_total + NEW.pris_salong;
  END IF;
  
  IF NEW.yrkesskadeforsikring_aktiv = true AND NEW.sum_yrkesskadeforsikring IS NOT NULL THEN
    new_total := new_total + NEW.sum_yrkesskadeforsikring;
  END IF;
  
  IF NEW.cyber_aktiv = true AND NEW.pris_cyber IS NOT NULL THEN
    new_total := new_total + NEW.pris_cyber;
  END IF;
  
  IF NEW.reise_aktiv = true AND NEW.sum_reise IS NOT NULL THEN
    new_total := new_total + NEW.sum_reise;
  END IF;
  
  IF NEW.fritidsulykke_aktiv = true AND NEW.sum_fritidsulykke IS NOT NULL THEN
    new_total := new_total + NEW.sum_fritidsulykke;
  END IF;
  
  IF NEW.helse_status = true AND NEW.helse_antall_aktive IS NOT NULL THEN
    new_total := new_total + (NEW.helse_antall_aktive * 5050);
  END IF;
  
  -- Set the new total
  NEW.sum_totalt := new_total;
  
  RETURN NEW;
END;
$$;

-- Create trigger to run before insert or update
DROP TRIGGER IF EXISTS trigger_recalculate_insurance_total ON salon_insurance;
CREATE TRIGGER trigger_recalculate_insurance_total
  BEFORE INSERT OR UPDATE ON salon_insurance
  FOR EACH ROW
  EXECUTE FUNCTION recalculate_salon_insurance_total();
