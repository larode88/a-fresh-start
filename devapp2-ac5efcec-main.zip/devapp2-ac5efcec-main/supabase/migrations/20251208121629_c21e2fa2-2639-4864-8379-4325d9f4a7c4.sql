-- Oppdatert trigger som ALLTID beregner sum-felter basert på faste enhetspriser
CREATE OR REPLACE FUNCTION public.recalculate_salon_insurance_total()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  new_total numeric := 0;
  yrkesskade_unit_price numeric := 1499;
  reise_unit_price numeric := 1499;
  fritidsulykke_unit_price numeric := 949;
  cyber_unit_price numeric := 949;
BEGIN
  -- Clear sum fields when insurance is deactivated
  IF NEW.salong_aktiv = false OR NEW.salong_aktiv IS NULL THEN
    NEW.pris_salong := NULL;
    NEW.salong_niva := NULL;
  END IF;
  
  IF NEW.yrkesskadeforsikring_aktiv = false OR NEW.yrkesskadeforsikring_aktiv IS NULL THEN
    NEW.sum_yrkesskadeforsikring := NULL;
    NEW.pris_yrkesskadeforsikring := NULL;
  ELSE
    -- ALLTID sett korrekt enhetspris og beregn sum på nytt når aktiv
    NEW.pris_yrkesskadeforsikring := yrkesskade_unit_price;
    IF NEW.antall_arsverk IS NOT NULL AND NEW.antall_arsverk > 0 THEN
      NEW.sum_yrkesskadeforsikring := yrkesskade_unit_price * NEW.antall_arsverk;
    ELSE
      NEW.sum_yrkesskadeforsikring := NULL;
    END IF;
  END IF;
  
  IF NEW.cyber_aktiv = false OR NEW.cyber_aktiv IS NULL THEN
    NEW.pris_cyber := NULL;
  ELSE
    -- ALLTID sett korrekt enhetspris når aktiv
    NEW.pris_cyber := cyber_unit_price;
  END IF;
  
  IF NEW.reise_aktiv = false OR NEW.reise_aktiv IS NULL THEN
    NEW.sum_reise := NULL;
    NEW.pris_reise := NULL;
    NEW.antall_reiseforsikring := NULL;
  ELSE
    -- ALLTID sett korrekt enhetspris og beregn sum på nytt når aktiv
    NEW.pris_reise := reise_unit_price;
    IF NEW.antall_reiseforsikring IS NOT NULL AND NEW.antall_reiseforsikring > 0 THEN
      NEW.sum_reise := reise_unit_price * NEW.antall_reiseforsikring;
    ELSE
      NEW.sum_reise := NULL;
    END IF;
  END IF;
  
  IF NEW.fritidsulykke_aktiv = false OR NEW.fritidsulykke_aktiv IS NULL THEN
    NEW.sum_fritidsulykke := NULL;
    NEW.pris_fritidsulykke := NULL;
    NEW.antall_fritidsulykke := NULL;
  ELSE
    -- ALLTID sett korrekt enhetspris og beregn sum på nytt når aktiv
    NEW.pris_fritidsulykke := fritidsulykke_unit_price;
    IF NEW.antall_fritidsulykke IS NOT NULL AND NEW.antall_fritidsulykke > 0 THEN
      NEW.sum_fritidsulykke := fritidsulykke_unit_price * NEW.antall_fritidsulykke;
    ELSE
      NEW.sum_fritidsulykke := NULL;
    END IF;
  END IF;
  
  IF NEW.helse_status = false OR NEW.helse_status IS NULL THEN
    NEW.helse_antall_aktive := NULL;
    NEW.helseforsikring_premie := NULL;
  END IF;

  -- Calculate sum_totalt based on active insurances (ALLTID beregnet på nytt)
  IF NEW.salong_aktiv = true AND NEW.pris_salong IS NOT NULL THEN
    new_total := new_total + NEW.pris_salong;
  END IF;
  
  IF NEW.yrkesskadeforsikring_aktiv = true AND NEW.sum_yrkesskadeforsikring IS NOT NULL THEN
    new_total := new_total + NEW.sum_yrkesskadeforsikring;
  END IF;
  
  IF NEW.cyber_aktiv = true AND NEW.pris_cyber IS NOT NULL THEN
    new_total := new_total + NEW.pris_cyber;
  END IF;
  
  IF NEW.reise_aktiv = true AND NEW.sum_reise IS NOT NULL THEN
    new_total := new_total + NEW.sum_reise;
  END IF;
  
  IF NEW.fritidsulykke_aktiv = true AND NEW.sum_fritidsulykke IS NOT NULL THEN
    new_total := new_total + NEW.sum_fritidsulykke;
  END IF;
  
  IF NEW.helse_status = true AND NEW.helse_antall_aktive IS NOT NULL THEN
    new_total := new_total + (NEW.helse_antall_aktive * 5050);
  END IF;
  
  -- Set the new total (0 if nothing active)
  NEW.sum_totalt := new_total;
  
  RETURN NEW;
END;
$function$;

-- Engangsfiks: Oppdater alle eksisterende salon_insurance med korrekte priser og summer
UPDATE salon_insurance
SET 
  -- Yrkesskade: alltid enhetspris 1499, beregn sum
  pris_yrkesskadeforsikring = CASE 
    WHEN yrkesskadeforsikring_aktiv = true THEN 1499 
    ELSE NULL 
  END,
  sum_yrkesskadeforsikring = CASE 
    WHEN yrkesskadeforsikring_aktiv = true AND antall_arsverk IS NOT NULL AND antall_arsverk > 0 
    THEN 1499 * antall_arsverk 
    ELSE NULL 
  END,
  -- Reise: alltid enhetspris 1499, beregn sum
  pris_reise = CASE 
    WHEN reise_aktiv = true THEN 1499 
    ELSE NULL 
  END,
  sum_reise = CASE 
    WHEN reise_aktiv = true AND antall_reiseforsikring IS NOT NULL AND antall_reiseforsikring > 0 
    THEN 1499 * antall_reiseforsikring 
    ELSE NULL 
  END,
  -- Fritidsulykke: alltid enhetspris 949, beregn sum
  pris_fritidsulykke = CASE 
    WHEN fritidsulykke_aktiv = true THEN 949 
    ELSE NULL 
  END,
  sum_fritidsulykke = CASE 
    WHEN fritidsulykke_aktiv = true AND antall_fritidsulykke IS NOT NULL AND antall_fritidsulykke > 0 
    THEN 949 * antall_fritidsulykke 
    ELSE NULL 
  END,
  -- Cyber: alltid enhetspris 949
  pris_cyber = CASE 
    WHEN cyber_aktiv = true THEN 949 
    ELSE NULL 
  END,
  -- sum_totalt vil beregnes av triggeren, men vi setter den her også for sikkerhets skyld
  sum_totalt = COALESCE(
    CASE WHEN salong_aktiv = true THEN pris_salong ELSE 0 END, 0
  ) + COALESCE(
    CASE WHEN yrkesskadeforsikring_aktiv = true AND antall_arsverk IS NOT NULL THEN 1499 * antall_arsverk ELSE 0 END, 0
  ) + COALESCE(
    CASE WHEN cyber_aktiv = true THEN 949 ELSE 0 END, 0
  ) + COALESCE(
    CASE WHEN reise_aktiv = true AND antall_reiseforsikring IS NOT NULL THEN 1499 * antall_reiseforsikring ELSE 0 END, 0
  ) + COALESCE(
    CASE WHEN fritidsulykke_aktiv = true AND antall_fritidsulykke IS NOT NULL THEN 949 * antall_fritidsulykke ELSE 0 END, 0
  ) + COALESCE(
    CASE WHEN helse_status = true AND helse_antall_aktive IS NOT NULL THEN 5050 * helse_antall_aktive ELSE 0 END, 0
  ),
  updated_at = now();