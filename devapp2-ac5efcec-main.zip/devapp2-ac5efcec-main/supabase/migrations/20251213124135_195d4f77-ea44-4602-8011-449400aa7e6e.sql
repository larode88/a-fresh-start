-- Legg til ansatt_id kolonne med foreign key til ansatte
ALTER TABLE ferie ADD COLUMN ansatt_id uuid REFERENCES ansatte(id);

-- Gjør user_id nullable
ALTER TABLE ferie ALTER COLUMN user_id DROP NOT NULL;

-- Legg til kommentarer
COMMENT ON COLUMN ferie.ansatt_id IS 'Referanse til ansatt. Primær identifikator for ferie.';
COMMENT ON COLUMN ferie.user_id IS 'Valgfri referanse til bruker-konto. Kan være NULL for ansatte uten brukerkonto.';

-- Oppdater eksisterende ferie-poster med ansatt_id basert på user_id
UPDATE ferie f
SET ansatt_id = a.id
FROM ansatte a
WHERE f.user_id = a.user_id
AND f.ansatt_id IS NULL;