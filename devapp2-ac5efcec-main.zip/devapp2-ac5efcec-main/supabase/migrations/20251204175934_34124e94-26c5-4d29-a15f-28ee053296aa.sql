-- Add new status "invoiced" to the insurance_order_status enum
ALTER TYPE insurance_order_status ADD VALUE 'invoiced';

-- Add new columns for transfer date from Frende and invoice date
ALTER TABLE insurance_orders 
ADD COLUMN IF NOT EXISTS frende_transfer_date DATE,
ADD COLUMN IF NOT EXISTS invoiced_at TIMESTAMPTZ;