
-- Fiks search_path for check_trenger_oppfolging funksjonen
CREATE OR REPLACE FUNCTION public.check_trenger_oppfolging()
RETURNS TRIGGER AS $$
BEGIN
  -- Sett trenger_oppfolging = true hvis siste_kontakt_dato er > 45 dager gammel
  IF NEW.siste_kontakt_dato IS NOT NULL THEN
    NEW.trenger_oppfolging := (NEW.siste_kontakt_dato < CURRENT_DATE - INTERVAL '45 days');
  ELSE
    -- Hvis aldri kontaktet og innmeldt, trenger oppfølging
    NEW.trenger_oppfolging := (NEW.innmeldt_dato IS NOT NULL);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = 'public';
