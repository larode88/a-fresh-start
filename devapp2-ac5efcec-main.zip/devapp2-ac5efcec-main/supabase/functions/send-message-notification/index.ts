import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface NotificationRequest {
  threadId: string;
  messageText: string;
  senderName: string;
  senderId: string;
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Check if email sending is enabled
    const { data: emailSetting } = await supabase
      .from("system_settings")
      .select("value")
      .eq("key", "email_enabled")
      .single();

    const isEmailEnabled = emailSetting?.value === true;

    if (!isEmailEnabled) {
      console.log("Email sending is disabled - skipping message notification");
      return new Response(
        JSON.stringify({ success: true, skipped: true, reason: "Email sending disabled" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Validate authentication
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      console.error("No authorization header provided");
      return new Response(JSON.stringify({ error: 'Unauthorized' }), { 
        status: 401, 
        headers: { ...corsHeaders, "Content-Type": "application/json" } 
      });
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !user) {
      console.error("Invalid token:", authError?.message);
      return new Response(JSON.stringify({ error: 'Invalid token' }), { 
        status: 401, 
        headers: { ...corsHeaders, "Content-Type": "application/json" } 
      });
    }

    const { threadId, messageText, senderName, senderId }: NotificationRequest = await req.json();

    // Verify the authenticated user is the sender
    if (user.id !== senderId) {
      console.error("User mismatch: authenticated user is not the sender");
      return new Response(JSON.stringify({ error: 'Forbidden: Cannot send notifications as another user' }), { 
        status: 403, 
        headers: { ...corsHeaders, "Content-Type": "application/json" } 
      });
    }

    // Verify user is a participant in the thread
    const { data: participation, error: partError } = await supabase
      .from('thread_participants')
      .select('id')
      .eq('thread_id', threadId)
      .eq('user_id', user.id)
      .maybeSingle();

    if (partError || !participation) {
      console.error("User is not a participant in thread:", threadId);
      return new Response(JSON.stringify({ error: 'Forbidden: Not a participant in this thread' }), { 
        status: 403, 
        headers: { ...corsHeaders, "Content-Type": "application/json" } 
      });
    }

    console.log("Sending notification for thread:", threadId, "from:", senderName, "user:", user.id);

    // Get thread subject
    const { data: thread, error: threadError } = await supabase
      .from("message_threads")
      .select("subject")
      .eq("id", threadId)
      .single();

    if (threadError) {
      console.error("Error fetching thread:", threadError);
      throw threadError;
    }

    // Get all participants except the sender
    const { data: participants, error: participantsError } = await supabase
      .from("thread_participants")
      .select("user_id")
      .eq("thread_id", threadId)
      .neq("user_id", senderId);

    if (participantsError) {
      console.error("Error fetching participants:", participantsError);
      throw participantsError;
    }

    if (!participants || participants.length === 0) {
      console.log("No participants to notify");
      return new Response(JSON.stringify({ success: true, notified: 0 }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Get user emails and notification preferences
    const userIds = participants.map(p => p.user_id);
    const { data: users, error: usersError } = await supabase
      .from("users")
      .select("id, email, name")
      .in("id", userIds);

    if (usersError) {
      console.error("Error fetching users:", usersError);
      throw usersError;
    }

    // Get notification preferences for all users
    const { data: preferences, error: prefsError } = await supabase
      .from("user_notification_preferences")
      .select("user_id, email_on_new_message")
      .in("user_id", userIds);

    if (prefsError) {
      console.error("Error fetching preferences:", prefsError);
      // Continue anyway - default to sending emails
    }

    // Create a map of user preferences (default to true if no preference set)
    const prefsMap = new Map<string, boolean>();
    preferences?.forEach((pref: any) => {
      prefsMap.set(pref.user_id, pref.email_on_new_message);
    });

    // Filter users who want email notifications
    const usersToNotify = users?.filter((user) => {
      const wantsEmail = prefsMap.get(user.id);
      // Default to true if no preference is set
      return wantsEmail === undefined || wantsEmail === true;
    }) || [];

    if (usersToNotify.length === 0) {
      console.log("No users want email notifications");
      return new Response(JSON.stringify({ success: true, notified: 0, skipped: users?.length || 0 }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Send emails to users who want notifications
    const emailPromises = usersToNotify.map(async (user) => {
      try {
        const truncatedMessage = messageText.length > 200 
          ? messageText.substring(0, 200) + "..." 
          : messageText;

        const response = await fetch("https://api.resend.com/emails", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${RESEND_API_KEY}`,
          },
          body: JSON.stringify({
            from: "Hår1 Portalen <noreply@har1.no>",
            to: [user.email],
            subject: `Ny melding: ${thread.subject}`,
            html: `
              <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
                <h2 style="color: #333;">Hei ${user.name}!</h2>
                <p style="color: #666;">Du har mottatt en ny melding fra <strong>${senderName}</strong>.</p>
                
                <div style="background: #f5f5f5; padding: 16px; border-radius: 8px; margin: 20px 0;">
                  <p style="color: #333; margin: 0 0 8px 0;"><strong>Emne:</strong> ${thread.subject}</p>
                  <p style="color: #666; margin: 0;">${truncatedMessage}</p>
                </div>
                
                <a href="https://portal.har1.no/messages" 
                   style="display: inline-block; background: #6366f1; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px;">
                  Se melding
                </a>
                
                <p style="color: #999; margin-top: 30px; font-size: 12px;">
                  Denne e-posten ble sendt fra Hår1 Portalen. 
                  Du kan endre varslingsinnstillinger i din profil.
                </p>
              </div>
            `,
          }),
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.message || "Failed to send email");
        }

        console.log("Email sent to:", user.email);
        return { email: user.email, success: true };
      } catch (error) {
        console.error("Error sending email to", user.email, error);
        return { email: user.email, success: false, error };
      }
    });

    const results = await Promise.all(emailPromises);
    const successCount = results.filter(r => r.success).length;
    const skippedCount = (users?.length || 0) - usersToNotify.length;

    console.log(`Sent ${successCount}/${results.length} emails, skipped ${skippedCount} (opted out)`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        notified: successCount, 
        total: results.length,
        skipped: skippedCount
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error: any) {
    console.error("Error in send-message-notification:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
};

serve(handler);
