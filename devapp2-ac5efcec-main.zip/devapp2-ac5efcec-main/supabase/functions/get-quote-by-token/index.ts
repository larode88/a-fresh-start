import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const handler = async (req: Request): Promise<Response> => {
  console.log("get-quote-by-token function called");

  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { token }: { token: string } = await req.json();
    console.log(`Fetching quote with token: ${token}`);

    // Fetch quote by token
    const { data: quote, error: quoteError } = await supabase
      .from("insurance_quotes")
      .select(`
        id,
        salon_name,
        org_number,
        contact_name,
        email,
        phone,
        products,
        total_price,
        notes,
        status,
        sent_at,
        accepted_at,
        expires_at,
        withdrawn_at,
        link_to_fullmakt,
        district_manager:district_manager_id (
          name
        )
      `)
      .eq("acceptance_token", token)
      .single();

    if (quoteError || !quote) {
      console.error("Quote not found:", quoteError);
      return new Response(
        JSON.stringify({ error: "Tilbudet ble ikke funnet", code: "NOT_FOUND" }),
        { status: 404, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Check if withdrawn
    if (quote.status === "withdrawn") {
      return new Response(
        JSON.stringify({ 
          error: "Tilbudet er trukket tilbake. Kontakt din distriktsleder for et nytt tilbud.", 
          code: "WITHDRAWN",
          quote: { salon_name: quote.salon_name, status: "withdrawn" }
        }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Check expiry for sent quotes
    if (quote.status === "sent" && quote.expires_at && new Date(quote.expires_at) < new Date()) {
      return new Response(
        JSON.stringify({ 
          error: "Tilbudet har utløpt. Kontakt din distriktsleder.", 
          code: "EXPIRED",
          quote: { salon_name: quote.salon_name, status: "expired" }
        }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    return new Response(
      JSON.stringify({ success: true, quote }),
      { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );

  } catch (error: any) {
    console.error("Error in get-quote-by-token:", error);
    return new Response(
      JSON.stringify({ error: error.message || "An error occurred" }),
      { status: 500, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );
  }
};

serve(handler);
