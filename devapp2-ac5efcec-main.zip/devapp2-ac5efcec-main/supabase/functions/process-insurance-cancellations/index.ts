import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Map insurance type to columns and HubSpot fields to clear on cancellation
const insuranceTypeConfig: Record<string, {
  aktivColumn: string;
  dbFieldsToClear: Record<string, any>;
  hubspotFieldsToClear: Record<string, any>;
}> = {
  salong: {
    aktivColumn: "salong_aktiv",
    dbFieldsToClear: {
      salong_aktiv: false,
      salong_niva: null,
      pris_salong: null,
    },
    hubspotFieldsToClear: {
      forsikring_salongforsikring: "Nei",
      forsikring_salongforsikring_niva: "",
      forsikring_pris_salongforsikring_niva1: "",
    },
  },
  yrkesskade: {
    aktivColumn: "yrkesskadeforsikring_aktiv",
    dbFieldsToClear: {
      yrkesskadeforsikring_aktiv: false,
      pris_yrkesskadeforsikring: null,
      sum_yrkesskadeforsikring: null,
    },
    hubspotFieldsToClear: {
      forsikring_yrkesskadeforsikring: "Nei",
      forsikring_pris_yrkesskadeforsikring: "",
      forsikring_sum_yrkesskadeforsikring: "",
    },
  },
  cyber: {
    aktivColumn: "cyber_aktiv",
    dbFieldsToClear: {
      cyber_aktiv: false,
      pris_cyber: null,
    },
    hubspotFieldsToClear: {
      forsikring_cyberforsikring: "Nei",
      forsikring_pris_cyber: "",
    },
  },
  reise: {
    aktivColumn: "reise_aktiv",
    dbFieldsToClear: {
      reise_aktiv: false,
      pris_reise: null,
      sum_reise: null,
      antall_reiseforsikring: null,
    },
    hubspotFieldsToClear: {
      forsikring_reiseforsikring: "Nei",
      forsikring_pris_reise: "",
      forsikring_sum_reise: "",
      forsikring_antall_reiseforsikring: "",
    },
  },
  fritidsulykke: {
    aktivColumn: "fritidsulykke_aktiv",
    dbFieldsToClear: {
      fritidsulykke_aktiv: false,
      pris_fritidsulykke: null,
      sum_fritidsulykke: null,
      antall_fritidsulykke: null,
    },
    hubspotFieldsToClear: {
      forsikring_fritidsulykkeforsikring: "Nei",
      forsikring_pris_fritidsulykke: "",
      forsikring_sum_fritidsulykke: "",
      forsikring_antall_fritidsulykke: "",
    },
  },
  helse: {
    aktivColumn: "helse_status",
    dbFieldsToClear: {
      helse_status: false,
      helse_antall_aktive: 0,
      helseforsikring_premie: null,
      helseforsikring_avtalenummer: null,
      helseforsikring_oppstartsdato: null,
      helseforsikring_oppsigelsesdato: null,
    },
    hubspotFieldsToClear: {
      forsikring_status_helse: "Nei",
      forsikring_helse_antall_aktive: "",
      forsikring_helseforsikring_premie: "",
    },
  },
};

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  // Verify cron secret for authentication
  const cronSecret = Deno.env.get("CRON_SECRET");
  const providedSecret = req.headers.get("x-cron-secret");
  if (!cronSecret || providedSecret !== cronSecret) {
    console.error("Unauthorized: Invalid or missing cron secret");
    return new Response(
      JSON.stringify({ error: "Unauthorized" }),
      { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  try {
    console.log("Starting process-insurance-cancellations job...");

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Get today's date in YYYY-MM-DD format
    const today = new Date().toISOString().split("T")[0];
    console.log(`Processing cancellations for date <= ${today}`);

    // Fetch all unprocessed cancellations that should be processed today or earlier
    const { data: pendingCancellations, error: fetchError } = await supabase
      .from("insurance_scheduled_cancellations")
      .select(`
        *,
        salon:salons(id, name, hubspot_company_id),
        scheduled_by_user:users!scheduled_by(name, email)
      `)
      .eq("processed", false)
      .lte("cancellation_date", today)
      .order("cancellation_date", { ascending: true });

    if (fetchError) {
      console.error("Error fetching pending cancellations:", fetchError);
      throw fetchError;
    }

    if (!pendingCancellations || pendingCancellations.length === 0) {
      console.log("No pending cancellations to process");
      return new Response(
        JSON.stringify({ success: true, message: "No pending cancellations", processed: 0 }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`Found ${pendingCancellations.length} cancellations to process`);

    const results = {
      processed: 0,
      failed: 0,
      hubspotSynced: 0,
      errors: [] as string[],
    };

    // Process each cancellation
    for (const cancellation of pendingCancellations) {
      try {
        console.log(`Processing cancellation ${cancellation.id} for salon ${cancellation.salon?.name} - ${cancellation.insurance_type}`);

        const config = insuranceTypeConfig[cancellation.insurance_type];
        if (!config) {
          console.error(`Unknown insurance type: ${cancellation.insurance_type}`);
          results.errors.push(`Unknown insurance type: ${cancellation.insurance_type}`);
          results.failed++;
          continue;
        }

        // Update salon_insurance - clear all related fields
        const updateData: Record<string, any> = {
          ...config.dbFieldsToClear,
          oppsigelse_dato: cancellation.cancellation_date,
          updated_at: new Date().toISOString(),
        };

        const { error: updateError } = await supabase
          .from("salon_insurance")
          .update(updateData)
          .eq("salon_id", cancellation.salon_id);

        if (updateError) {
          console.error(`Error updating salon_insurance for ${cancellation.salon_id}:`, updateError);
          results.errors.push(`Failed to update salon_insurance: ${updateError.message}`);
          results.failed++;
          continue;
        }

        console.log(`Successfully deactivated ${cancellation.insurance_type} for salon ${cancellation.salon_id}`);

        // Recalculate sum_totalt based on remaining active insurances
        const { data: currentInsurance } = await supabase
          .from("salon_insurance")
          .select("*")
          .eq("salon_id", cancellation.salon_id)
          .single();

        if (currentInsurance) {
          let newTotal = 0;
          if (currentInsurance.salong_aktiv && currentInsurance.pris_salong) {
            newTotal += Number(currentInsurance.pris_salong);
          }
          if (currentInsurance.yrkesskadeforsikring_aktiv && currentInsurance.sum_yrkesskadeforsikring) {
            newTotal += Number(currentInsurance.sum_yrkesskadeforsikring);
          }
          if (currentInsurance.cyber_aktiv && currentInsurance.pris_cyber) {
            newTotal += Number(currentInsurance.pris_cyber);
          }
          if (currentInsurance.reise_aktiv && currentInsurance.sum_reise) {
            newTotal += Number(currentInsurance.sum_reise);
          }
          if (currentInsurance.fritidsulykke_aktiv && currentInsurance.sum_fritidsulykke) {
            newTotal += Number(currentInsurance.sum_fritidsulykke);
          }
          if (currentInsurance.helse_status && currentInsurance.helse_antall_aktive) {
            newTotal += Number(currentInsurance.helse_antall_aktive) * 5050; // Health insurance price per person
          }

          await supabase
            .from("salon_insurance")
            .update({ sum_totalt: newTotal })
            .eq("salon_id", cancellation.salon_id);

          console.log(`Recalculated sum_totalt to ${newTotal} for salon ${cancellation.salon_id}`);
        }

        // Sync to HubSpot if company ID exists
        let hubspotSynced = false;
        if (cancellation.salon?.hubspot_company_id) {
          try {
            hubspotSynced = await syncCancellationToHubSpot(
              supabase,
              cancellation.salon.hubspot_company_id,
              cancellation.insurance_type,
              cancellation.cancellation_date
            );
            if (hubspotSynced) {
              results.hubspotSynced++;
              console.log(`HubSpot sync successful for salon ${cancellation.salon_id}`);
            }
          } catch (hubspotError) {
            console.error(`HubSpot sync failed for salon ${cancellation.salon_id}:`, hubspotError);
            // Continue processing even if HubSpot sync fails
          }
        }

        // Mark cancellation as processed
        const { error: markError } = await supabase
          .from("insurance_scheduled_cancellations")
          .update({
            processed: true,
            processed_at: new Date().toISOString(),
            hubspot_synced: hubspotSynced,
            hubspot_synced_at: hubspotSynced ? new Date().toISOString() : null,
          })
          .eq("id", cancellation.id);

        if (markError) {
          console.error(`Error marking cancellation ${cancellation.id} as processed:`, markError);
          results.errors.push(`Failed to mark as processed: ${markError.message}`);
        }

        results.processed++;
      } catch (err: unknown) {
        const errorMessage = err instanceof Error ? err.message : String(err);
        console.error(`Error processing cancellation ${cancellation.id}:`, err);
        results.errors.push(`Error processing ${cancellation.id}: ${errorMessage}`);
        results.failed++;
      }
    }

    console.log(`Processing complete. Processed: ${results.processed}, Failed: ${results.failed}, HubSpot synced: ${results.hubspotSynced}`);

    return new Response(
      JSON.stringify({
        success: true,
        message: `Processed ${results.processed} cancellations`,
        ...results,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error("Error in process-insurance-cancellations:", error);
    return new Response(
      JSON.stringify({ success: false, error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

async function syncCancellationToHubSpot(
  supabase: any,
  hubspotCompanyId: string,
  insuranceType: string,
  cancellationDate: string
): Promise<boolean> {
  try {
    // Get HubSpot access token
    const { data: tokenData, error: tokenError } = await supabase
      .from("hubspot_oauth_tokens")
      .select("access_token, expires_at, refresh_token")
      .order("created_at", { ascending: false })
      .limit(1)
      .single();

    if (tokenError || !tokenData) {
      console.log("No HubSpot token available, skipping sync");
      return false;
    }

    let accessToken = tokenData.access_token;

    // Check if token is expired and refresh if needed
    if (new Date(tokenData.expires_at) <= new Date()) {
      console.log("HubSpot token expired, refreshing...");
      const refreshedToken = await refreshHubSpotToken(supabase, tokenData.refresh_token);
      if (!refreshedToken) {
        return false;
      }
      accessToken = refreshedToken;
    }

    // Build HubSpot update payload - clear all related fields
    const config = insuranceTypeConfig[insuranceType];
    const updatePayload: Record<string, any> = {
      ...config.hubspotFieldsToClear,
      dato_for_oppsigelse_av_forsikring: cancellationDate,
    };

    // Update HubSpot company
    const response = await fetch(
      `https://api.hubapi.com/crm/v3/objects/companies/${hubspotCompanyId}`,
      {
        method: "PATCH",
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ properties: updatePayload }),
      }
    );

    if (!response.ok) {
      const errorText = await response.text();
      console.error(`HubSpot API error: ${response.status} - ${errorText}`);
      return false;
    }

    console.log(`Successfully synced cancellation to HubSpot for company ${hubspotCompanyId}`);
    return true;
  } catch (error) {
    console.error("Error syncing to HubSpot:", error);
    return false;
  }
}

async function refreshHubSpotToken(supabase: any, refreshToken: string): Promise<string | null> {
  try {
    const clientId = Deno.env.get("HUBSPOT_CLIENT_ID");
    const clientSecret = Deno.env.get("HUBSPOT_CLIENT_SECRET");

    if (!clientId || !clientSecret) {
      console.error("HubSpot credentials not configured");
      return null;
    }

    const response = await fetch("https://api.hubapi.com/oauth/v1/token", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        grant_type: "refresh_token",
        client_id: clientId,
        client_secret: clientSecret,
        refresh_token: refreshToken,
      }),
    });

    if (!response.ok) {
      console.error("Failed to refresh HubSpot token");
      return null;
    }

    const tokenData = await response.json();
    const expiresAt = new Date(Date.now() + tokenData.expires_in * 1000).toISOString();

    // Update token in database
    await supabase.from("hubspot_oauth_tokens").insert({
      access_token: tokenData.access_token,
      refresh_token: tokenData.refresh_token,
      expires_at: expiresAt,
    });

    return tokenData.access_token;
  } catch (error) {
    console.error("Error refreshing HubSpot token:", error);
    return null;
  }
}
