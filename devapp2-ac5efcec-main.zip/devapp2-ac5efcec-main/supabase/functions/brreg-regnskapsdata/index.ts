import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface RegnskapsregisteretResponse {
  regnskapsperiode?: {
    fraDato?: string;
    tilDato?: string;
  };
  resultatregnskapResultat?: {
    driftsresultat?: {
      driftsresultat?: number;
      driftsinntekter?: {
        sumDriftsinntekter?: number;
      };
      driftskostnad?: {
        sumDriftskostnad?: number;
      };
    };
  };
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { orgNumber } = await req.json();
    
    if (!orgNumber) {
      return new Response(
        JSON.stringify({ error: 'orgNumber is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const cleanedOrgNumber = orgNumber.replace(/\s/g, '');
    if (!/^\d{9}$/.test(cleanedOrgNumber)) {
      return new Response(
        JSON.stringify({ error: 'Invalid org number format' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Fetching financial data for org: ${cleanedOrgNumber}`);

    // Fetch list of available years
    const listResponse = await fetch(
      `https://data.brreg.no/regnskapsregisteret/regnskap/${cleanedOrgNumber}`
    );

    if (!listResponse.ok) {
      console.log(`No financial data found for ${cleanedOrgNumber}, status: ${listResponse.status}`);
      return new Response(
        JSON.stringify({ data: null }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const listData = await listResponse.json();
    console.log(`Found ${Array.isArray(listData) ? listData.length : 0} financial records`);
    
    if (!listData || !Array.isArray(listData) || listData.length === 0) {
      return new Response(
        JSON.stringify({ data: null }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Sort by year descending and get the latest
    const sortedYears = listData.sort((a: any, b: any) => {
      const yearA = a.regnskapsperiode?.tilDato ? new Date(a.regnskapsperiode.tilDato).getFullYear() : 0;
      const yearB = b.regnskapsperiode?.tilDato ? new Date(b.regnskapsperiode.tilDato).getFullYear() : 0;
      return yearB - yearA;
    });

    const latest = sortedYears[0];
    let detailData: RegnskapsregisteretResponse = latest;
    
    // Try to get detailed data if there's an id
    if (latest.id) {
      try {
        const detailResponse = await fetch(
          `https://data.brreg.no/regnskapsregisteret/regnskap/${cleanedOrgNumber}/${latest.id}`
        );
        if (detailResponse.ok) {
          detailData = await detailResponse.json();
          console.log('Fetched detailed financial data');
        }
      } catch (e) {
        console.log('Could not fetch detailed data, using list data');
      }
    }

    const regnskapsaar = detailData.regnskapsperiode?.tilDato 
      ? new Date(detailData.regnskapsperiode.tilDato).getFullYear()
      : undefined;

    // Extract from the correct nested path: resultatregnskapResultat.driftsresultat
    const driftsresultatObj = detailData.resultatregnskapResultat?.driftsresultat;
    
    const sumDriftsinntekter = driftsresultatObj?.driftsinntekter?.sumDriftsinntekter;
    const sumDriftskostnad = driftsresultatObj?.driftskostnad?.sumDriftskostnad;
    const driftsresultat = driftsresultatObj?.driftsresultat;

    console.log('Parsed financial data:', { sumDriftsinntekter, sumDriftskostnad, driftsresultat, regnskapsaar });

    const result = {
      sumDriftsinntekter,
      sumDriftskostnad,
      driftsresultat,
      regnskapsaar,
    };

    console.log('Returning financial data:', result);

    return new Response(
      JSON.stringify({ data: result }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('Error fetching financial data:', errorMessage);
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
