import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// GHD customer number to org number mapping (from provided list)
// Format: { kundenr: orgNr }
const GHD_CUSTOMER_MAPPINGS: Record<string, string> = {
  "10298038": "989348809",
  "10202912": "984913710",
  "10496874": "926924583",
  "10264811": "885094732",
  "10258427": "998403189",
  "10382446": "920293565",
  "10371039": "911925206",
  "10370709": "994266799",
  "10371122": "917317690",
  "10601855": "915218326",
  "10371106": "918817182",
  "10370806": "899002962",
  "10370617": "997031830",
  "10267660": "970348115",
  "10266565": "998037980",
  "10370262": "915066704",
  "10206243": "992927887",
  "10546264": "929973321",
  "10370613": "987488557",
  "10229346": "990841977",
  "10362650": "936120121",
  "10207586": "989397516",
  "10228461": "917825300",
  "10277034": "996661652",
  "10512819": "827600482",
  "10226323": "912827313",
  "10370577": "976792246",
  "10370594": "992691336",
  "10537629": "971193573",
  "10370856": "981873858",
  "10567615": "991246983",
  "10298772": "984940440",
  "10258914": "990163340",
  "10536911": "997603540",
  "10262516": "992101725",
  "10242866": "977674093",
  "10273973": "993294756",
  "10354726": "887944482",
  "10474094": "825627162",
  "10532668": "927452820",
  "10226590": "812450352",
  "10387647": "920051103",
  "10370889": "914000548",
  "10259860": "947091336",
  "10236629": "999615112",
  "10519132": "928764125",
  "10295442": "914072166",
  "10258475": "894538902",
  "10427540": "817409822",
  "10524123": "929091957",
  "10520114": "928620301",
  "10371076": "914836123",
  "10301598": "970113053",
  "10256128": "998936845",
  "10204817": "891174292",
  "10425449": "918515585",
  "10299440": "893042652",
  "10428343": "988419141",
  "10536678": "924358890",
  "10200649": "970312285",
  "10475237": "926087053",
  "10480911": "925891576",
  "10547945": "829776782",
  "10371080": "818423012",
  "10350262": "988613398",
  "10304316": "989594915",
  "10511453": "920973140",
  "10301559": "989084321",
  "10611091": "920233260",
  "10522336": "994480936",
  "10203199": "988946737",
  "10202206": "984234724",
  "10253630": "813221322",
  "10370920": "919062894",
  "10431102": "999145736",
  "10370649": "976483839",
  "10370746": "981466586",
  "10370632": "988764248",
  "10370509": "983431631",
  "10244181": "915004067",
  "10273824": "979798482",
  "10383475": "920342205",
  "10592437": "933937259",
  "10370610": "988357677",
  "10370932": "981710673",
  "10370264": "920240690",
  "10468404": "920736815",
  "10455910": "911855275",
  "10417157": "921441959",
  "10371074": "912256308",
  "10485045": "926086111",
  "10383545": "821422442",
  "10266781": "980123499",
  "10370523": "995745704",
  "10370630": "815614372",
  "10498738": "927332809",
  "10242593": "914488915",
  "10563474": "931851411",
  "10407706": "920779700",
  "10255286": "977067022",
  "10430282": "999195059",
  "10456915": "922609624",
  "10572510": "930120847",
  "10293042": "961472229",
  "10207958": "985872317",
  "10439173": "998597943",
  "10547895": "956604621",
  "10370601": "968602241",
  "10542258": "992849673",
  "10370580": "998911664",
  "10370663": "984475144",
  "10266410": "988016853",
  "10370884": "913757351",
  "10229777": "998545145",
  "10370655": "998508576",
  "10593893": "922321620",
  "10304183": "888802932",
  "10261281": "986709983",
  "10370616": "895460362",
  "10361180": "993155934",
  "10245639": "897109832",
  "10347972": "919294256",
  "10203196": "940033500",
  "10370699": "980441687",
  "10371038": "980395898",
  "10206724": "976188284",
  "10386618": "950510463",
  "10293090": "967300810",
  "10371096": "913079264",
  "10231623": "999166628",
  "10370799": "984238355",
  "10200127": "970091793",
  "10272688": "877100472",
  "10297860": "970587020",
  "10301582": "989620231",
  "10370730": "964839123",
  "10370284": "999503799",
  "10390256": "921416849",
  "10271901": "981711939",
  "10475459": "923060235",
  "10375561": "913441826",
  "10274010": "993294713",
  "10403208": "970117245",
  "10285759": "889040432",
  "10371075": "915519970",
  "10370939": "912341127",
  "10370949": "912341100",
  "10370606": "917063591",
  "10370705": "955151682",
  "10237568": "979783604",
  "10371064": "918588493",
  "10584610": "931683462",
  "10371086": "918771824",
  "10370835": "998550955",
  "10298490": "980363376",
  "10542374": "930683701",
  "10371006": "813413892",
  "10501990": "927440911",
  "10371028": "911879492",
  "10398943": "921777485",
  "10378567": "921133464",
  "10615551": "935868475",
  "10546453": "999326706",
  "10273482": "873191732",
  "10582601": "927281600",
  "10384767": "921277385",
  "10277553": "998006791",
  "10402861": "971190140",
  "10345261": "918984313",
  "10370811": "998900522",
  "10370816": "894205202",
  "10440839": "921219172",
  "10383474": "996562794",
  "10247013": "999629962",
  "10302409": "985506140",
  "10259027": "911559676",
  "10304020": "998437458",
  "10555616": "922103887",
  "10347099": "917865892",
  "10522064": "926544594",
  "10370673": "915597920",
  "10236084": "917095795",
  "10268027": "977024137",
  "10222012": "998536782",
  "10214257": "889537582",
  "10244505": "995145472",
  "10207772": "992074450",
  "10428889": "917155410",
  "10520198": "926561510",
  // Entries without kundenummer but with org numbers (SDA = Nei)
  // These won't have a kundenummer but we still track them if needed
};

// Additional mappings from the list that don't have kundenummer (SDA = Nei entries with org numbers)
const ADDITIONAL_ORG_MAPPINGS: string[] = [
  "928703878", // AM Frisør 2 AS
  "929351789", // Anastasia Holstad
  "994454730", // Basic Hair AS
  "934181115", // Beauty By Mohd Ali
  "923959335", // Bergljots Frisør og Negledesign AS
  "927432234", // Blend Or Cut AS
  "932873036", // Blomsterøya Frisør AS
  "933183483", // Blossome AS
  "970133194", // Blåkors Opplæringssenter AGLO
  "921006195", // Box Brud AS
  "916266928", // Box Frisør AS
  "916358865", // Buddas Hage
  "996772772", // Charlottenlund vgs
  "991418415", // Christine Stene Winther Avseth
  "882022552", // Clinique EmilieAnne AS
  "918004289", // Clipp Frisør AS
  "931045814", // Color Bar Fana AS
  "923808388", // Color Bar Norge AS
  "923029737", // Cutshim Frisør og Spa AS
  "970320857", // Dal Frisør
  "996274624", // Din Lille salong
  "930495239", // Dixon Hårstudio AS
  "925178934", // Dr. Keratin-BMPL AS
  "917795584", // Edge Barbershop Trondheim AS
  "935423295", // Ela Frisør Brattørgata AS
  "890827292", // Elin E. Men & Women AS
  "925573388", // Ellingsrud Frisør AS
  "917973075", // Essens Frisør
  "935619874", // Eventyrlig S. Andreassen
  "935219078", // Fanny Lykke AS
  "931011804", // Fjell Studio AS
  "825243542", // FMG AS
  "817418252", // Fr Clinique AS
  "818405952", // Frisør Anne-Lise Unsgård (Salong FUS)
  "926419498", // Frisør Cathrine Stang
  "979877463", // Frisør Dårelokken AS
  "921887981", // Frisør Hege Johansen AS
  "915491987", // Frisør Linn Eggen -Finess Hårstudio
  "883640012", // Frisørbørsen Siv Olsen
  "832918962", // Frisørhjørnet Vågen AS
  "965075097", // Frisørstuggu Rutt-Karin Sødahl Engezelius
  "999134297", // Frisørstuå AS
  "825059822", // Frisørtunet AS // Linn Kristin Bore
  "996294579", // Fryd v/ Evy S. Vigdal
  "928899829", // Gents Club AS
  "927163047", // Glimmer Frisør AS
  "934513045", // GM Studio Sørløkk
  "813826712", // Gro's Frisør AS
  "981514319", // Grønnestad Hårklinikk & Frisør AS
  "933333426", // Hair By Elisabeth Arntsen
  "930360147", // Hair Rituals AS
  "934105761", // Hairline AS
  "953333651", // Hair-Line Dame og Herresalong
  "915048412", // Hairdesign AS
  "920163874", // Hairdesign Ida Engebretsen
  "820163842", // Hairdesign Sandra Kristoffersen
  "976053605", // Hans og Hennes Frisør Torsvik
  "920197167", // Harmoni Frisør Kurt Engen AS
  "920416594", // Hashtaghair&wellness AS
  "997198409", // Head Beauty AS-Fornebu
  "925611050", // Head Frisør Grimstad AS
  "927196689", // Head Frisør / Amfi Larvik
  "930353205", // Head Frisør Sandefjord AS
  "995354020", // Head Hair & Beauty AS // Oslo
  "911891557", // Head Skills AS
  "916562047", // Hellens Klippotek AS
  "913307887", // Henriette&Kristoffer AS Salong Fjordveien
  "926317059", // Herligheden Hudpleie & Makeup AS
  "994494368", // Hodet Først - Hår og Make Up
  "995519348", // Høyanger Dame og Herrefrisør AS
  "994941224", // Hårek & Gyda Frisør AS
  "916331614", // Hårek Frisørstudio AS
  "998288819", // Hårfeen v/ Silvia C Rosseland
  "916068972", // Hårfeen v/ Maren V Hole
  "998503647", // Hårfin Kopervik AS
  "930980552", // Hårgalleriet Sandefjord AS
  "933221377", // Hårgården By Camilla Jentoftsen
  "993812102", // Hårstua Kongsberg AS
  "995390051", // Ida Helen Norum-Brest Maison
  "997943392", // Ide Salongen AS
  "917396280", // Kasia Salong AS
  "920629814", // Katrine Røttingen
  "912440117", // Kims Frisør Herreavdelingen
  "912155625", // Kløppern AS
  "914183731", // Kobber Frisør AS
  "933277070", // Konkav Atelier AS
  "982575400", // Kort & Godt AS
  "914738857", // Kruger Frisør AS
  "993338648", // Krystall Hud og Velvære Fuglestad
  "958075979", // Kvinnherad Vekstbedrift AS (avd. Frisør)
  "920459854", // Lailas Frisør AS
  "993069450", // Lille My Frisør Marit Iren Tjelta
  "997073134", // Lille Paris Frisørsalong AS
  "830877622", // Lines Hårpleie AS
  "989886800", // LK Frisører AS
  "933472469", // Løvland Frisør
  "953138557", // M-Frisør Mette Iren Jensen
  "824347352", // MaGi Hårdesign AS
  "913168771", // Malavita AS
  "994418303", // Manon Frisør - Halonen
  "924383593", // Maria Johansen/ SalongZ
  "892557942", // Mode Frisør
  "996760618", // Motehår AS
  "927077744", // Naomi Studio AS
  "946473766", // Noir Hairdresser Drøbak AS
  "929385195", // Nordhaar Marianne Sneås
  "933085570", // Nye Frisøren AS
  "933498409", // Nye Volum Frisør AS
  "824646872", // Næss Dame & Herrefrisør AS
  "911662396", // Næss Frisør AS
  "932593610", // Oh la la Tangentoppen AS
  "926732749", // Oh la la AS
  "922339988", // Oro AS
  "918741003", // ORO v/ Edith H.Heskje
  "924764600", // Peak salong AS
  "932841363", // Perle Frisør
  "932686953", // Pikant Klippotek AS
  "992206888", // Pollen Hud og Spa AS
  "931313274", // Prep Haar AS
  "820351622", // Pryd Frisør Bergen AS
  "918973869", // Ravnevand Beauty
  "833647512", // Rebecca Hansen Frisør AS
  "911828189", // Rebell Hårstudio AS
  "824190992", // Ronny Larsson Frisør -Spotlight Frisør
  "913332156", // Rune & Mari AS Salong Fjordveien
  "913222512", // Salong 83 AS
  "987299207", // Salong 9 Barbro Torp
  "927968169", // Salong Carpe Diem Bakke
  "891478372", // Salong Hovenga AS
  "927402890", // Salong Indiana AS
  "918713999", // Salong Karisma Førde AS
  "928793001", // Sans for Hår AS
  "992674016", // Saxen Frisør Stord AS
  "922703493", // Sence AS
  "922648808", // Sence Nina Larsen
  "922620598", // Silje Liholt-Nilssen
  "926942247", // Sirkel Frisør AS
  "822395252", // Skogen Frisør AS
  "889884762", // Snæbbus Hair v/Mari
  "934859367", // Snål Frisør AS
  "835261832", // Solfrid K Høyer
  "925840440", // Sol Frisør AS
  "833701932", // Spire Salong AS
  "933410889", // Strå AS
  "914637767", // Studio 1 Frisør AS
  "927568780", // Studio Asdal Frisør AS
  "986623175", // Studio B AS
  "934438248", // Studio H & M Frisør AS(The Leader AS)
  "925719315", // Suave Salong AS
  "819165742", // Svai Frisør AS
  "923208801", // TEHE AS
  "982785944", // The Leader AS
  "999558801", // Tina.S Salong AS
  "917338213", // Tiur Frisør AS
  "990542414", // Tone Kari Hellum Pedersen
  "919905751", // Toppen Frisør Os AS
  "881711192", // Toppen Frisører
  "918067833", // Topsy Frisør. Heidi B Syversen
  "976268539", // Toves Frisør
  "928333574", // Vibe Frisør AS
  "915258336", // WB Frisører AS
  "923390774", // Wenches Hårpleie AS
  "923768467", // Your Time Frisør og Velvære
  "976060407", // Zanzuel & Klinikk Nova AS
  "915922880", // Zen Vibes Hair AS
  "929271009", // Årnes Frisør Andersen
  "921785518", // Åsgården Frisør AS
];

// Wella supplier ID
const WELLA_SUPPLIER_ID = 'b157a720-4b7c-48c9-8bdc-61b7ed20e288';

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Starting GHD customer import...');

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    let imported = 0;
    let notFound = 0;
    let errors = 0;
    const notFoundList: string[] = [];
    const errorList: string[] = [];

    // Process all GHD customer mappings
    for (const [kundenr, orgNr] of Object.entries(GHD_CUSTOMER_MAPPINGS)) {
      // Clean org number (remove spaces)
      const cleanOrgNr = orgNr.replace(/\s/g, '');
      
      // Find salon by org_number
      const { data: salon, error: salonError } = await supabase
        .from('salons')
        .select('id, name')
        .eq('org_number', cleanOrgNr)
        .maybeSingle();

      if (salonError) {
        console.error(`Error looking up salon for org ${cleanOrgNr}:`, salonError);
        errors++;
        errorList.push(`${kundenr} (${cleanOrgNr}): ${salonError.message}`);
        continue;
      }

      if (!salon) {
        console.log(`No salon found for org_number ${cleanOrgNr} (kundenr: ${kundenr})`);
        notFound++;
        notFoundList.push(`${kundenr} -> ${cleanOrgNr}`);
        continue;
      }

      // Upsert supplier identifier
      const { error: upsertError } = await supabase
        .from('supplier_identifiers')
        .upsert({
          supplier_id: WELLA_SUPPLIER_ID,
          salon_id: salon.id,
          supplier_customer_number: kundenr,
          identifier_type: 'customer_number'
        }, {
          onConflict: 'supplier_id,supplier_customer_number'
        });

      if (upsertError) {
        console.error(`Error upserting identifier for ${kundenr}:`, upsertError);
        errors++;
        errorList.push(`${kundenr}: ${upsertError.message}`);
        continue;
      }

      console.log(`Imported: ${kundenr} -> ${salon.name} (${salon.id})`);
      imported++;
    }

    const result = {
      success: true,
      imported,
      notFound,
      errors,
      total: Object.keys(GHD_CUSTOMER_MAPPINGS).length,
      notFoundList: notFoundList.slice(0, 20), // First 20 for debugging
      errorList: errorList.slice(0, 10)
    };

    console.log('Import complete:', result);

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('Error in import-ghd-customers:', error);
    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
