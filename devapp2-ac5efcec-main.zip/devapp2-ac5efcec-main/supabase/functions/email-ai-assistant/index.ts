import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');

interface AIRequest {
  action: 'rewrite' | 'shorten' | 'expand' | 'alt-text' | 'subject-lines' | 'generate-email';
  content?: string;
  imageUrl?: string;
  context?: {
    purpose?: string;
    tone?: string;
    type?: string;
  };
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY is not configured');
    }

    const { action, content, imageUrl, context } = await req.json() as AIRequest;
    console.log(`AI email assistant action: ${action}`);

    let systemPrompt = '';
    let userPrompt = '';

    switch (action) {
      case 'rewrite':
        systemPrompt = `Du er en profesjonell tekstforfatter for Hår1, Norges største frisørkjede. 
Din tone of voice er:
- Varm og profesjonell
- Nordisk og moderne
- Inspirerende og motiverende
- Inkluderende og støttende

Skriv om teksten i Hår1s tone of voice. Behold hovedbudskapet men gjør teksten mer engasjerende og profesjonell.
Returner KUN den omskrevne teksten, ingen forklaringer.`;
        userPrompt = content || '';
        break;

      case 'shorten':
        systemPrompt = `Du er en profesjonell tekstforfatter. Din oppgave er å forkorte teksten og gjøre den mer punchy og direkte.
- Behold hovedbudskapet
- Fjern unødvendige ord
- Gjør setningene kortere og mer slagkraftige
- Bruk aktive verb

Returner KUN den forkortede teksten, ingen forklaringer.`;
        userPrompt = content || '';
        break;

      case 'expand':
        systemPrompt = `Du er en profesjonell tekstforfatter for Hår1. Din oppgave er å utvide teksten med mer detaljer og kontekst.
- Legg til relevante detaljer
- Gjør teksten mer beskrivende
- Behold den originale tonen
- Ikke gjør teksten for lang (maks 2x original lengde)

Returner KUN den utvidede teksten, ingen forklaringer.`;
        userPrompt = content || '';
        break;

      case 'alt-text':
        systemPrompt = `Du er en ekspert på tilgjengelighet og SEO. Generer en kort, beskrivende alt-tekst for bildet.
- Beskriv hva som vises i bildet
- Vær konkret og informativ
- Hold det under 125 tegn
- Unngå "bilde av" eller "foto av"

Returner KUN alt-teksten, ingen forklaringer.`;
        userPrompt = imageUrl ? `Beskriv dette bildet for alt-tekst: ${imageUrl}` : 'Generer en generisk alt-tekst for et frisørbilde';
        break;

      case 'subject-lines':
        systemPrompt = `Du er en e-postmarkedsføringsekspert for Hår1. Generer 5 forslag til emnelinjer basert på e-postinnholdet.
Emnelinjer skal:
- Være under 50 tegn
- Vekke nysgjerrighet
- Være relevante for innholdet
- Bruke Hår1s tone of voice (varm, profesjonell, inspirerende)

Returner en JSON-array med 5 objekter, hvert med "subject" og "previewText" felt.
Eksempel: [{"subject": "Din personlige invitasjon", "previewText": "Vi har noe spesielt til deg..."}]`;
        userPrompt = `Generer emnelinjer for denne e-posten:\n\n${content}`;
        break;

      case 'generate-email':
        const emailType = context?.type || 'nyhetsbrev';
        const tone = context?.tone || 'profesjonell';
        const purpose = context?.purpose || 'informere';
        
        systemPrompt = `Du er en profesjonell e-postforfatter for Hår1, Norges største frisørkjede.
Din tone of voice er:
- Varm og profesjonell
- Nordisk og moderne
- Inspirerende og motiverende
- Inkluderende og støttende

Generer en komplett e-poststruktur i JSON-format med følgende moduler:
- header-logo (med Hår1 logo)
- heading (hovedoverskrift)
- text (innledende tekst)
- cta-button (call to action)
- footer-signature (standard footer)

Returner KUN gyldig JSON med denne strukturen:
{
  "subject": "Emnelinje her",
  "modules": [
    { "type": "header-logo", "content": { "logoUrl": "", "altText": "Hår1" } },
    { "type": "heading", "content": { "text": "Overskrift", "level": "h1" } },
    { "type": "text", "content": { "text": "Innhold her..." } },
    { "type": "cta-button", "content": { "text": "Knapptekst", "url": "#", "variant": "primary" } },
    { "type": "footer-signature", "content": { "companyName": "Hår1", "address": "", "phone": "", "email": "" } }
  ]
}`;
        userPrompt = `Lag en ${emailType} e-post med ${tone} tone. Formål: ${purpose}\n\nBeskrivelse: ${content}`;
        break;

      default:
        throw new Error(`Unknown action: ${action}`);
    }

    console.log('Calling Lovable AI gateway...');
    
    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ],
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: 'For mange forespørsler. Prøv igjen om litt.' }), {
          status: 429,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: 'AI-kreditter brukt opp. Kontakt admin.' }), {
          status: 402,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
      const errorText = await response.text();
      console.error('AI gateway error:', response.status, errorText);
      throw new Error(`AI gateway error: ${response.status}`);
    }

    const data = await response.json();
    const result = data.choices?.[0]?.message?.content;

    if (!result) {
      throw new Error('No response from AI');
    }

    console.log('AI response received successfully');

    // Parse JSON responses for specific actions
    let parsedResult = result;
    if (action === 'subject-lines' || action === 'generate-email') {
      try {
        // Extract JSON from response (in case it's wrapped in markdown)
        const jsonMatch = result.match(/\[[\s\S]*\]|\{[\s\S]*\}/);
        if (jsonMatch) {
          parsedResult = JSON.parse(jsonMatch[0]);
        }
      } catch (e) {
        console.error('Failed to parse JSON response:', e);
        parsedResult = result;
      }
    }

    return new Response(JSON.stringify({ result: parsedResult }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error in email-ai-assistant:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Unknown error' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
