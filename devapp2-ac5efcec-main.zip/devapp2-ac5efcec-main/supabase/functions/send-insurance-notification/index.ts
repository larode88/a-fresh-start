import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface NotificationRequest {
  type: "order_submitted" | "order_approved" | "order_rejected" | "order_sent_to_frende" | "order_completed" | "order_to_frende";
  recipientEmail: string;
  recipientName: string;
  salonName: string;
  orderTotal?: number;
  rejectionReason?: string;
  orderId: string;
  orderDetails?: {
    salonAddress?: string;
    salonPostalCode?: string;
    salonCity?: string;
    orgNumber?: string;
    contactName?: string;
    contactEmail?: string;
    contactPhone?: string;
    antallAnsatte?: number;
    antallArsverk?: number;
    aarligOmsetning?: number;
    switchingProvider?: boolean;
    previousInsurances?: string;
    products?: Array<{
      name: string;
      tierName?: string;
      quantity: number;
      unitPrice: number;
      totalPrice: number;
    }>;
  };
}

const formatPrice = (price: number) => {
  return new Intl.NumberFormat("nb-NO", {
    style: "currency",
    currency: "NOK",
    maximumFractionDigits: 0,
  }).format(price);
};

// Format previous insurances from JSON to readable text
const formatPreviousInsurances = (json: string | null): string => {
  if (!json) return '';
  try {
    const insurances = JSON.parse(json);
    if (Array.isArray(insurances)) {
      return insurances.map((ins: { company: string; policy_number: string }) => 
        `${ins.company} (Polisenr: ${ins.policy_number})`
      ).join('<br>');
    }
    return json;
  } catch {
    return json;
  }
};

const getSubjectAndBody = (data: NotificationRequest, logoUrl: string, siteUrl: string): { subject: string; html: string } => {
  
  const wrapInTemplate = (content: string) => `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body style="font-family: 'Segoe UI', 'DM Sans', Arial, sans-serif; line-height: 1.7; color: #3D3D3D; margin: 0; padding: 0; background-color: #FAF8F5;">
      <div style="max-width: 600px; margin: 0 auto; padding: 40px 20px;">
        
        <!-- Logo Header -->
        <div style="text-align: center; margin-bottom: 32px;">
          <img src="${logoUrl}" alt="Hår1 Forsikring" style="max-height: 70px; width: auto;" />
        </div>
        
        <!-- Main Content Card -->
        <div style="background: #FFFFFF; border-radius: 16px; padding: 40px 32px; box-shadow: 0 4px 24px rgba(139, 115, 85, 0.08);">
          ${content}
        </div>
        
        <!-- Footer -->
        <div style="text-align: center; margin-top: 32px; padding: 24px; color: #6B5440;">
          <p style="margin: 0 0 4px 0; font-size: 15px;">Varm hilsen,</p>
          <p style="margin: 0; font-weight: 600; color: #8B7355; font-size: 16px;">Hår1 Forsikringsteamet</p>
          <p style="margin: 16px 0 0 0; font-size: 14px; color: #888;">
            📧 <a href="mailto:forsikring@har1.no" style="color: #8B7355; text-decoration: none;">forsikring@har1.no</a><br/>
            📞 +47 4000 3345
          </p>
        </div>
        
      </div>
    </body>
    </html>
  `;

  switch (data.type) {
    case "order_submitted":
      return {
        subject: `Ny forsikringsbestilling fra ${data.salonName}`,
        html: wrapInTemplate(`
          <h2 style="margin: 0 0 24px 0; color: #8B7355;">📋 Ny forsikringsbestilling</h2>
          
          <p style="margin: 0 0 20px 0; color: #5A5A5A;">
            En ny forsikringsbestilling er mottatt og venter på godkjenning.
          </p>
          
          <div style="background: linear-gradient(135deg, #FAF7F2 0%, #F5EEE6 100%); border-radius: 12px; padding: 20px; margin: 24px 0;">
            <p style="margin: 0 0 8px 0;"><strong>Salong:</strong> ${data.salonName}</p>
            <p style="margin: 0 0 8px 0;"><strong>Kontaktperson:</strong> ${data.recipientName}</p>
            <p style="margin: 0;"><strong>Estimert årlig premie:</strong> ${data.orderTotal ? formatPrice(data.orderTotal) : "Se detaljer"}</p>
          </div>
          
          <div style="text-align: center; margin: 28px 0;">
            <a href="${siteUrl}/admin/insurance" style="display: inline-block; background: linear-gradient(135deg, #8B7355 0%, #6B5440 100%); color: #FFFFFF; padding: 14px 32px; text-decoration: none; border-radius: 50px; font-weight: 600; font-size: 15px; box-shadow: 0 4px 16px rgba(139, 115, 85, 0.3);">
              Se bestilling i admin →
            </a>
          </div>
        `),
      };

    case "order_approved":
      return {
        subject: `Din forsikringsbestilling er godkjent ✓ – ${data.salonName}`,
        html: wrapInTemplate(`
          <!-- Success Banner -->
          <div style="background: linear-gradient(135deg, #E8F5E9 0%, #C8E6C9 100%); border-radius: 12px; padding: 28px; margin-bottom: 28px; text-align: center;">
            <div style="font-size: 48px; margin-bottom: 12px;">✅</div>
            <h2 style="color: #2E7D32; margin: 0; font-size: 22px; font-weight: 600;">Bestilling godkjent!</h2>
          </div>
          
          <p style="font-size: 18px; margin: 0 0 16px 0;">Hei ${data.recipientName}! 👋</p>
          
          <p style="margin: 0 0 20px 0; color: #5A5A5A;">
            Vi har godkjent forsikringsbestillingen for <strong>${data.salonName}</strong>.
          </p>
          
          <div style="background: linear-gradient(135deg, #FAF7F2 0%, #F5EEE6 100%); border-radius: 12px; padding: 24px; margin: 24px 0;">
            <p style="margin: 0 0 12px 0; font-weight: 600; color: #8B7355;">Hva skjer nå?</p>
            <p style="margin: 0; color: #5A5A5A; line-height: 1.9;">
              ✓ Bestillingen sendes til Frende for aktivering<br/>
              ✓ Du mottar bekreftelse når forsikringen er aktiv<br/>
              ✓ Dokumenter blir tilgjengelige i portalen
            </p>
          </div>
          
          ${data.orderTotal ? `
            <div style="text-align: center; background: #F8F9FA; border-radius: 8px; padding: 16px; margin: 20px 0;">
              <p style="margin: 0; font-size: 14px; color: #888;">Årlig premie</p>
              <p style="margin: 4px 0 0 0; font-size: 24px; font-weight: 700; color: #8B7355;">${formatPrice(data.orderTotal)}</p>
            </div>
          ` : ''}
        `),
      };

    case "order_rejected":
      return {
        subject: `Forsikringsbestilling kunne ikke godkjennes – ${data.salonName}`,
        html: wrapInTemplate(`
          <h2 style="margin: 0 0 24px 0; color: #8B7355;">Bestilling avvist</h2>
          
          <p style="font-size: 18px; margin: 0 0 16px 0;">Hei ${data.recipientName},</p>
          
          <p style="margin: 0 0 20px 0; color: #5A5A5A;">
            Dessverre kunne vi ikke godkjenne forsikringsbestillingen for <strong>${data.salonName}</strong>.
          </p>
          
          ${data.rejectionReason ? `
            <div style="background: #FEF2F2; border-left: 4px solid #EF4444; border-radius: 0 8px 8px 0; padding: 16px 20px; margin: 24px 0;">
              <p style="margin: 0 0 8px 0; font-weight: 600; color: #DC2626; font-size: 14px;">Begrunnelse:</p>
              <p style="margin: 0; color: #5A5A5A;">${data.rejectionReason}</p>
            </div>
          ` : ''}
          
          <p style="margin: 24px 0; color: #5A5A5A;">
            Du er velkommen til å sende inn en ny bestilling eller kontakte oss for mer informasjon.
          </p>
        `),
      };

    case "order_sent_to_frende":
      return {
        subject: `Forsikringsbestilling sendt til Frende – ${data.salonName}`,
        html: wrapInTemplate(`
          <h2 style="margin: 0 0 24px 0; color: #8B7355;">📤 Bestilling sendt til forsikringsselskap</h2>
          
          <p style="font-size: 18px; margin: 0 0 16px 0;">Hei ${data.recipientName}! 👋</p>
          
          <p style="margin: 0 0 20px 0; color: #5A5A5A;">
            Forsikringsbestillingen for <strong>${data.salonName}</strong> er nå sendt til Frende for behandling.
          </p>
          
          <div style="background: linear-gradient(135deg, #FAF7F2 0%, #F5EEE6 100%); border-radius: 12px; padding: 24px; margin: 24px 0;">
            <p style="margin: 0; color: #5A5A5A; line-height: 1.9;">
              ✓ Du vil motta forsikringsbevis og dokumentasjon direkte fra Frende<br/>
              ✓ Vi gir deg beskjed når forsikringen er aktivert
            </p>
          </div>
          
          <p style="margin: 24px 0; color: #5A5A5A;">
            Har du spørsmål i mellomtiden? Vi er alltid tilgjengelige!
          </p>
        `),
      };

    case "order_to_frende":
      // Detailed order email sent TO Frende for processing
      const details = data.orderDetails || {};
      const productsHtml = details.products?.map(p => `
        <tr>
          <td style="padding: 14px 16px; border-bottom: 1px solid #E8E0D8; color: #4A4A4A;">${p.name}${p.tierName ? ` (${p.tierName})` : ''}</td>
          <td style="padding: 14px 16px; border-bottom: 1px solid #E8E0D8; text-align: center; color: #4A4A4A;">${p.quantity}</td>
          <td style="padding: 14px 16px; border-bottom: 1px solid #E8E0D8; text-align: right; color: #4A4A4A; font-weight: 500;">${formatPrice(p.totalPrice)}</td>
        </tr>
      `).join('') || '';

      return {
        subject: `Ny forsikringsbestilling – ${data.salonName} (Ordre: ${data.orderId.slice(0, 8)})`,
        html: wrapInTemplate(`
          <h2 style="margin: 0 0 24px 0; color: #8B7355;">📦 Ny forsikringsbestilling fra Hår1</h2>
          
          <h3 style="color: #8B7355; font-weight: 600; margin: 24px 0 12px 0; font-size: 14px; text-transform: uppercase; letter-spacing: 0.5px;">Salonginfo</h3>
          <div style="background: linear-gradient(135deg, #FAF7F2 0%, #F5EEE6 100%); border-radius: 12px; padding: 20px; margin: 0 0 24px 0;">
            <p style="margin: 0 0 8px 0;"><strong>Salongnavn:</strong> ${data.salonName}</p>
            <p style="margin: 0 0 8px 0;"><strong>Org.nummer:</strong> ${details.orgNumber || 'Ikke oppgitt'}</p>
            <p style="margin: 0;"><strong>Adresse:</strong> ${details.salonAddress || ''}, ${details.salonPostalCode || ''} ${details.salonCity || ''}</p>
          </div>

          <h3 style="color: #8B7355; font-weight: 600; margin: 24px 0 12px 0; font-size: 14px; text-transform: uppercase; letter-spacing: 0.5px;">Kontaktperson</h3>
          <div style="background: linear-gradient(135deg, #FAF7F2 0%, #F5EEE6 100%); border-radius: 12px; padding: 20px; margin: 0 0 24px 0;">
            <p style="margin: 0 0 8px 0;"><strong>Navn:</strong> ${details.contactName || data.recipientName}</p>
            <p style="margin: 0 0 8px 0;"><strong>E-post:</strong> ${details.contactEmail || data.recipientEmail}</p>
            <p style="margin: 0;"><strong>Telefon:</strong> ${details.contactPhone || 'Ikke oppgitt'}</p>
          </div>

          <h3 style="color: #8B7355; font-weight: 600; margin: 24px 0 12px 0; font-size: 14px; text-transform: uppercase; letter-spacing: 0.5px;">Bedriftsinfo</h3>
          <div style="background: linear-gradient(135deg, #FAF7F2 0%, #F5EEE6 100%); border-radius: 12px; padding: 20px; margin: 0 0 24px 0;">
            <p style="margin: 0 0 8px 0;"><strong>Antall ansatte:</strong> ${details.antallAnsatte || 'Ikke oppgitt'}</p>
            <p style="margin: 0 0 8px 0;"><strong>Antall årsverk:</strong> ${details.antallArsverk || 'Ikke oppgitt'}</p>
            <p style="margin: 0;"><strong>Årlig omsetning:</strong> ${details.aarligOmsetning ? formatPrice(details.aarligOmsetning) : 'Ikke oppgitt'}</p>
          </div>

          ${details.switchingProvider ? `
            <h3 style="color: #8B7355; font-weight: 600; margin: 24px 0 12px 0; font-size: 14px; text-transform: uppercase; letter-spacing: 0.5px;">Eksisterende forsikring</h3>
            <div style="background: #FEF3C7; border-radius: 12px; padding: 20px; margin: 0 0 24px 0;">
              <p style="margin: 0 0 8px 0;"><strong>Bytter fra eksisterende forsikring:</strong> Ja</p>
              ${details.previousInsurances ? `<p style="margin: 0;"><strong>Tidligere forsikringer:</strong><br>${formatPreviousInsurances(details.previousInsurances)}</p>` : ''}
            </div>
          ` : ''}

          <h3 style="color: #8B7355; font-weight: 600; margin: 24px 0 12px 0; font-size: 14px; text-transform: uppercase; letter-spacing: 0.5px;">Bestilte produkter</h3>
          <table style="width: 100%; border-collapse: collapse; margin: 0 0 24px 0;">
            <thead>
              <tr style="background: #8B7355;">
                <th style="padding: 14px 16px; text-align: left; font-weight: 600; color: #FFFFFF; border-radius: 8px 0 0 0;">Produkt</th>
                <th style="padding: 14px 16px; text-align: center; font-weight: 600; color: #FFFFFF;">Antall</th>
                <th style="padding: 14px 16px; text-align: right; font-weight: 600; color: #FFFFFF; border-radius: 0 8px 0 0;">Pris/år</th>
              </tr>
            </thead>
            <tbody>
              ${productsHtml}
              <tr style="background: linear-gradient(135deg, #8B7355 0%, #6B5440 100%);">
                <td colspan="2" style="padding: 16px; color: #FFFFFF; font-weight: 600; border-radius: 0 0 0 8px;">Totalpris per år</td>
                <td style="padding: 16px; text-align: right; color: #FFFFFF; font-weight: 700; font-size: 18px; border-radius: 0 0 8px 0;">${data.orderTotal ? formatPrice(data.orderTotal) : 'Se detaljer'}</td>
              </tr>
            </tbody>
          </table>

          <p style="margin-top: 24px; font-size: 12px; color: #888; text-align: center;">
            Ordre-ID: ${data.orderId}<br>
            Sendt fra Hår1-portalen
          </p>
        `),
      };

    case "order_completed":
      return {
        subject: `Forsikring aktivert ✓ – ${data.salonName}`,
        html: wrapInTemplate(`
          <!-- Success Banner -->
          <div style="background: linear-gradient(135deg, #E8F5E9 0%, #C8E6C9 100%); border-radius: 12px; padding: 28px; margin-bottom: 28px; text-align: center;">
            <div style="font-size: 48px; margin-bottom: 12px;">🎉</div>
            <h2 style="color: #2E7D32; margin: 0; font-size: 22px; font-weight: 600;">Forsikring aktivert!</h2>
          </div>
          
          <p style="font-size: 18px; margin: 0 0 16px 0;">Hei ${data.recipientName}! 👋</p>
          
          <p style="margin: 0 0 20px 0; color: #5A5A5A;">
            Gode nyheter! Forsikringen for <strong>${data.salonName}</strong> er nå aktiv.
          </p>
          
          ${data.orderTotal ? `
            <div style="text-align: center; background: linear-gradient(135deg, #FAF7F2 0%, #F5EEE6 100%); border-radius: 12px; padding: 20px; margin: 24px 0;">
              <p style="margin: 0; font-size: 14px; color: #8B7355; font-weight: 500;">Årlig premie</p>
              <p style="margin: 8px 0 0 0; font-size: 28px; font-weight: 700; color: #3D3D3D;">${formatPrice(data.orderTotal)}</p>
            </div>
          ` : ''}
          
          <div style="background: #F8F9FA; border-left: 4px solid #8B7355; border-radius: 0 8px 8px 0; padding: 16px 20px; margin: 24px 0;">
            <p style="margin: 0; font-size: 14px; color: #5A5A5A;">
              💡 Du kan nå se dine forsikringer og dokumenter i Hår1-portalen under "Forsikring".
            </p>
          </div>
          
          <p style="margin: 24px 0; color: #5A5A5A;">
            Ved skade eller spørsmål er vi alltid tilgjengelige for deg!
          </p>
        `),
      };

    default:
      return {
        subject: `Forsikringsoppdatering – ${data.salonName}`,
        html: wrapInTemplate(`
          <p style="margin: 0; color: #5A5A5A;">Det har skjedd en oppdatering på din forsikringsbestilling.</p>
        `),
      };
  }
};

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const siteUrl = Deno.env.get("SITE_URL") || "https://devapp2.lovable.app";
    const logoUrl = `${siteUrl}/haar1-forsikring-email-logo.png`;
    
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Authenticate the user
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      console.error("No authorization header provided");
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);

    if (authError || !user) {
      console.error("Invalid token or user not found:", authError?.message);
      return new Response(
        JSON.stringify({ error: "Invalid token" }),
        { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Verify user has admin role or is associated with the salon
    const { data: userRole } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .single();

    const { data: userData } = await supabase
      .from("users")
      .select("salon_id")
      .eq("id", user.id)
      .single();

    const isAdmin = userRole?.role === "admin";
    const isDagligLeder = userRole?.role === "daglig_leder";
    const isSalonOwner = userRole?.role === "salon_owner";

    // Parse the request body to check order access
    const data: NotificationRequest = await req.json();

    // Verify user has access to the order
    if (!isAdmin) {
      const { data: order } = await supabase
        .from("insurance_orders")
        .select("salon_id, ordered_by_user_id")
        .eq("id", data.orderId)
        .single();

      if (!order) {
        console.error("Order not found:", data.orderId);
        return new Response(
          JSON.stringify({ error: "Order not found" }),
          { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      // Check if user is the order creator or belongs to the same salon
      const hasAccess = 
        order.ordered_by_user_id === user.id || 
        (userData?.salon_id && order.salon_id === userData.salon_id && (isSalonOwner || isDagligLeder));

      if (!hasAccess) {
        console.error("User does not have access to this order");
        return new Response(
          JSON.stringify({ error: "Forbidden" }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    }

    console.log(`Authenticated user ${user.id} (role: ${userRole?.role}) sending notification for order ${data.orderId}`);

    // Check if email sending is enabled
    const { data: emailSetting } = await supabase
      .from("system_settings")
      .select("value")
      .eq("key", "email_enabled")
      .single();

    const isEmailEnabled = emailSetting?.value === true;

    if (!isEmailEnabled) {
      console.log("Email sending is disabled - skipping insurance notification");
      return new Response(
        JSON.stringify({ success: true, skipped: true, reason: "Email sending disabled" }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (!RESEND_API_KEY) {
      console.error("RESEND_API_KEY is not configured");
      return new Response(
        JSON.stringify({ error: "Email service not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { subject, html } = getSubjectAndBody(data, logoUrl, siteUrl);

    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: "Hår1 Forsikring <forsikring@har1.no>",
        to: [data.recipientEmail],
        subject,
        html,
      }),
    });

    if (!res.ok) {
      const errorText = await res.text();
      console.error("Resend API error:", errorText);
      throw new Error(`Failed to send email: ${errorText}`);
    }

    const result = await res.json();
    console.log("Email sent successfully:", result);

    return new Response(
      JSON.stringify({ success: true, messageId: result.id }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error sending notification:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
};

serve(handler);
