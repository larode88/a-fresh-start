import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "https://esm.sh/resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface GrowthBonusReportRequest {
  salonName: string;
  recipientEmail: string;
  recipientName: string;
  senderEmail: string;
  senderName: string;
  year: number;
  currentYearToDate: number;
  previousYearSamePeriod: number;
  previousYearTotal: number;
  growthPercent: number;
  progressPercent: number;
  bonusAmount: number;
  latestPeriod: string;
  isNewCustomer: boolean;
  // New fields for combined bonus tiers
  hasExtraTier: boolean;
  baseBonus: number;
  extraBonus: number;
  fivePercentThreshold: number;
  excessAmount: number;
}

const formatCurrency = (value: number): string => {
  return new Intl.NumberFormat("nb-NO", {
    style: "currency",
    currency: "NOK",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(value);
};

const formatPercent = (value: number): string => {
  const sign = value >= 0 ? "+" : "";
  return `${sign}${value.toFixed(1)}%`;
};

const generateEmailHtml = (data: GrowthBonusReportRequest): string => {
  const growthColor = data.growthPercent >= 0 ? "#16a34a" : "#dc2626";
  const growthArrow = data.growthPercent >= 0 ? "↑" : "↓";
  
  // Determine tier display based on new rules
  const tierLabel = data.hasExtraTier ? "5% + 10%" : "2,5%";
  const tierColor = data.hasExtraTier ? "#16a34a" : "#f59e0b";

  // Build bonus calculation HTML based on tier
  let bonusCalculationHtml = "";
  if (data.hasExtraTier) {
    bonusCalculationHtml = `
      <table width="100%" cellpadding="0" cellspacing="0" style="margin-top: 12px; font-size: 13px;">
        <tr>
          <td style="padding: 4px 0; color: #a3a3a3;">5% av årets omsetning:</td>
          <td style="padding: 4px 0; text-align: right; color: #ffffff;">${formatCurrency(data.baseBonus)}</td>
        </tr>
        <tr>
          <td style="padding: 4px 0; color: #a3a3a3;">+10% av overskudd${data.excessAmount > 0 ? ` (${formatCurrency(data.excessAmount)})` : ''}:</td>
          <td style="padding: 4px 0; text-align: right; color: #ffffff;">${formatCurrency(data.extraBonus)}</td>
        </tr>
        <tr>
          <td colspan="2" style="padding: 8px 0 0 0; border-top: 1px solid #404040;"></td>
        </tr>
        <tr>
          <td style="padding: 4px 0; color: #ffffff; font-weight: 600;">Total bonus:</td>
          <td style="padding: 4px 0; text-align: right; color: #ffffff; font-weight: 600;">${formatCurrency(data.bonusAmount)}</td>
        </tr>
      </table>
    `;
  } else {
    bonusCalculationHtml = `
      <div style="margin-top: 8px; font-size: 13px; color: #a3a3a3;">
        2,5% × ${formatCurrency(data.currentYearToDate)} = ${formatCurrency(data.bonusAmount)}
      </div>
    `;
  }

  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f5f5f0;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f5f5f0; padding: 40px 20px;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 12px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);">
          <!-- Header -->
          <tr>
            <td style="padding: 32px 40px; text-align: center; border-bottom: 1px solid #e5e5e5;">
              <img src="https://portal.har1.no/haar1-logo-black.png" alt="Hår1" style="height: 40px; width: auto;">
            </td>
          </tr>
          
          <!-- Content -->
          <tr>
            <td style="padding: 40px;">
              <h2 style="margin: 0 0 8px 0; color: #1a1a1a; font-size: 20px; font-weight: 600;">
                Hei ${data.recipientName},
              </h2>
              <p style="margin: 0 0 24px 0; color: #525252; font-size: 15px; line-height: 1.6;">
                Her er en oppdatering på vekstbonus for <strong>${data.salonName}</strong> så langt i ${data.year}.
              </p>
              
              ${data.isNewCustomer ? `
              <div style="background-color: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; padding: 12px 16px; margin-bottom: 24px;">
                <span style="color: #166534; font-size: 14px;">🎉 Ny kunde i ${data.year} – automatisk kvalifisert for 5% + 10% vekstbonus!</span>
              </div>
              ` : ''}
              
              <!-- Stats Table -->
              <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #fafaf9; border-radius: 8px; margin-bottom: 24px;">
                <tr>
                  <td style="padding: 20px;">
                    <table width="100%" cellpadding="0" cellspacing="0">
                      <tr>
                        <td style="padding: 8px 0; color: #737373; font-size: 14px;">L'Oréal innkjøp hittil i ${data.year}</td>
                        <td style="padding: 8px 0; text-align: right; color: #1a1a1a; font-weight: 600; font-size: 14px;">${formatCurrency(data.currentYearToDate)}</td>
                      </tr>
                      <tr>
                        <td style="padding: 8px 0; color: #737373; font-size: 14px;">Samme periode ${data.year - 1}</td>
                        <td style="padding: 8px 0; text-align: right; color: #1a1a1a; font-weight: 600; font-size: 14px;">${formatCurrency(data.previousYearSamePeriod)}</td>
                      </tr>
                      <tr>
                        <td style="padding: 8px 0; color: #737373; font-size: 14px;">Vekst vs. fjor</td>
                        <td style="padding: 8px 0; text-align: right; color: ${growthColor}; font-weight: 600; font-size: 14px;">
                          ${growthArrow} ${formatPercent(data.growthPercent)}
                        </td>
                      </tr>
                      <tr>
                        <td colspan="2" style="padding: 12px 0 8px 0; border-top: 1px solid #e5e5e5;"></td>
                      </tr>
                      <tr>
                        <td style="padding: 8px 0; color: #737373; font-size: 14px;">Totalt ${data.year - 1}</td>
                        <td style="padding: 8px 0; text-align: right; color: #1a1a1a; font-weight: 600; font-size: 14px;">${formatCurrency(data.previousYearTotal)}</td>
                      </tr>
                      <tr>
                        <td style="padding: 8px 0; color: #737373; font-size: 14px;">Oppnådd av fjorår</td>
                        <td style="padding: 8px 0; text-align: right; color: #1a1a1a; font-weight: 600; font-size: 14px;">${data.progressPercent.toFixed(1)}%</td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
              
              <!-- Bonus Section -->
              <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #1a1a1a; border-radius: 8px; margin-bottom: 24px;">
                <tr>
                  <td style="padding: 24px;">
                    <div style="text-align: center;">
                      <div style="font-size: 14px; color: #a3a3a3; margin-bottom: 8px;">🏆 Vekstbonus-tier</div>
                      <div style="display: inline-block; background-color: ${tierColor}; color: white; padding: 6px 16px; border-radius: 20px; font-weight: 600; font-size: 16px; margin-bottom: 16px;">
                        ${tierLabel}
                      </div>
                    </div>
                    ${bonusCalculationHtml}
                    <div style="text-align: center; margin-top: 16px;">
                      <div style="font-size: 14px; color: #a3a3a3; margin-bottom: 4px;">Estimert bonus</div>
                      <div style="font-size: 28px; color: #ffffff; font-weight: 700;">${formatCurrency(data.bonusAmount)}</div>
                    </div>
                  </td>
                </tr>
              </table>
              
              <p style="margin: 0 0 8px 0; color: #737373; font-size: 13px; line-height: 1.5;">
                <em>Tall oppdatert t.o.m. ${data.latestPeriod}. Endelig bonus beregnes ved årsslutt.</em>
              </p>
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td style="padding: 24px 40px; border-top: 1px solid #e5e5e5; background-color: #fafaf9; border-radius: 0 0 12px 12px;">
              <p style="margin: 0 0 4px 0; color: #1a1a1a; font-size: 14px;">Vennlig hilsen,</p>
              <p style="margin: 0 0 4px 0; color: #1a1a1a; font-size: 14px; font-weight: 600;">${data.senderName}</p>
              <p style="margin: 0; color: #737373; font-size: 13px;">Hår1</p>
              <p style="margin: 4px 0 0 0; color: #737373; font-size: 13px;">${data.senderEmail}</p>
            </td>
          </tr>
        </table>
        
        <p style="margin: 24px 0 0 0; color: #a3a3a3; font-size: 12px; text-align: center;">
          Hår1. Kjeden AS • Apotekergata 10 B, 0180 Oslo
        </p>
      </td>
    </tr>
  </table>
</body>
</html>
  `;
};

const handler = async (req: Request): Promise<Response> => {
  console.log("send-growth-bonus-report function called");

  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const data: GrowthBonusReportRequest = await req.json();
    console.log("Sending growth bonus report to:", data.recipientEmail);

    const html = generateEmailHtml(data);

    const emailResponse = await resend.emails.send({
      from: `${data.senderName} <${data.senderEmail}>`,
      to: [data.recipientEmail],
      subject: `Vekstbonus-rapport for ${data.salonName} – ${data.year}`,
      html,
    });

    console.log("Email sent successfully:", emailResponse);

    return new Response(JSON.stringify({ success: true, data: emailResponse }), {
      status: 200,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  } catch (error: any) {
    console.error("Error sending growth bonus report:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
