import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface SendQuoteEmailRequest {
  quoteId: string;
  action: "send_quote" | "notify_acceptance" | "notify_completion";
}

interface QuoteProduct {
  product_id: string;
  product_name: string;
  price: number;
  quantity: number;
  tier_name?: string;
  arsverk?: number;
  antall_ansatte?: number;
  aarlig_omsetning?: number;
  selected_employees?: { user_id: string; name: string }[];
}

// Helper to format price
const formatPrice = (price: number): string => {
  return new Intl.NumberFormat('nb-NO').format(price);
};

// Helper to get display quantity and calculated price for a product
const getProductDisplayInfo = (p: QuoteProduct): { displayQuantity: string; calculatedPrice: number } => {
  // Yrkesskade - use årsverk
  if (p.arsverk !== undefined && p.arsverk > 0) {
    return {
      displayQuantity: `${p.arsverk} årsverk`,
      calculatedPrice: p.price * p.arsverk
    };
  }
  
  // Helseforsikring - use selected employees count
  if (p.selected_employees && p.selected_employees.length > 0) {
    return {
      displayQuantity: `${p.selected_employees.length} pers.`,
      calculatedPrice: p.price * p.selected_employees.length
    };
  }
  
  // Default - use quantity
  return {
    displayQuantity: String(p.quantity),
    calculatedPrice: p.price * p.quantity
  };
};

// Try to render email from database template via render-email-template function
async function tryRenderFromTemplate(
  supabaseUrl: string,
  supabaseServiceKey: string,
  templateSlug: string,
  variables: Record<string, string>
): Promise<{ html: string; subject: string } | null> {
  try {
    const response = await fetch(`${supabaseUrl}/functions/v1/render-email-template`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${supabaseServiceKey}`,
      },
      body: JSON.stringify({
        template_slug: templateSlug,
        variables
      }),
    });

    if (response.ok) {
      const data = await response.json();
      if (data.html && data.subject) {
        console.log(`Successfully rendered template: ${templateSlug}`);
        return { html: data.html, subject: data.subject };
      }
    }
    console.log(`Template ${templateSlug} not found or rendering failed, using fallback`);
    return null;
  } catch (error) {
    console.error(`Error rendering template ${templateSlug}:`, error);
    return null;
  }
}

const handler = async (req: Request): Promise<Response> => {
  console.log("send-quote-email function called");

  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const resendApiKey = Deno.env.get("RESEND_API_KEY");

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Check if email is enabled
    const { data: settings } = await supabase
      .from("system_settings")
      .select("value")
      .eq("key", "email_enabled")
      .single();

    const emailEnabled = settings?.value === true || settings?.value === "true";

    const { quoteId, action }: SendQuoteEmailRequest = await req.json();
    console.log(`Processing action: ${action} for quote: ${quoteId}`);

    // Fetch quote data
    const { data: quote, error: quoteError } = await supabase
      .from("insurance_quotes")
      .select(`
        *,
        district_manager:district_manager_id (
          name,
          email
        )
      `)
      .eq("id", quoteId)
      .single();

    if (quoteError || !quote) {
      console.error("Error fetching quote:", quoteError);
      throw new Error("Quote not found");
    }

    const products = (quote.products as QuoteProduct[]) || [];
    const acceptanceUrl = `${Deno.env.get("SITE_URL") || "https://devapp2.lovable.app"}/quote/accept/${quote.acceptance_token}`;
    const siteUrl = Deno.env.get("SITE_URL") || "https://devapp2.lovable.app";
    const logoUrl = `${siteUrl}/haar1-forsikring-email-logo.png`;
    const districtManagerName = (quote.district_manager as any)?.name || 'din distriktsleder';

    let emailHtml = "";
    let subject = "";
    let toEmail = "";

    if (action === "send_quote") {
      // Email to member with quote offer
      toEmail = quote.email;
      
      // Try database template first
      const productRows = products.map(p => {
        const { displayQuantity, calculatedPrice } = getProductDisplayInfo(p);
        return [
          `${p.product_name}${p.tier_name ? ` (${p.tier_name})` : ''}`,
          displayQuantity,
          `${formatPrice(calculatedPrice)} kr`
        ];
      });

      const templateResult = await tryRenderFromTemplate(
        supabaseUrl,
        supabaseServiceKey,
        'insurance-quote-offer',
        {
          fornavn: quote.contact_name?.split(' ')[0] || quote.contact_name || 'Hei',
          kontaktperson: quote.contact_name || '',
          salongnavn: quote.salon_name || '',
          distriktsleder: districtManagerName,
          totalpris: `${formatPrice(quote.total_price)} kr`,
          link: acceptanceUrl,
          notat: quote.notes || '',
          logoUrl: logoUrl,
          // Product table will be built from template
        }
      );

      if (templateResult) {
        emailHtml = templateResult.html;
        subject = templateResult.subject;
      } else {
        // Fallback to hardcoded HTML
        subject = `Forsikringstilbud fra Hår1 – ${quote.salon_name}`;
        
        const productListHtml = products.map(p => {
          const { displayQuantity, calculatedPrice } = getProductDisplayInfo(p);
          return `
            <tr>
              <td style="padding: 14px 16px; border-bottom: 1px solid #E8E0D8; color: #4A4A4A;">${p.product_name}${p.tier_name ? ` (${p.tier_name})` : ''}</td>
              <td style="padding: 14px 16px; border-bottom: 1px solid #E8E0D8; text-align: center; color: #4A4A4A;">${displayQuantity}</td>
              <td style="padding: 14px 16px; border-bottom: 1px solid #E8E0D8; text-align: right; color: #4A4A4A; font-weight: 500;">${formatPrice(calculatedPrice)} kr</td>
            </tr>
          `;
        }).join('');

        emailHtml = `
          <!DOCTYPE html>
          <html>
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
          </head>
          <body style="font-family: 'Segoe UI', 'DM Sans', Arial, sans-serif; line-height: 1.7; color: #3D3D3D; margin: 0; padding: 0; background-color: #FAF8F5;">
            <div style="max-width: 600px; margin: 0 auto; padding: 40px 20px;">
              
              <!-- Logo Header -->
              <div style="text-align: center; margin-bottom: 32px;">
                <img src="${logoUrl}" alt="Hår1 Forsikring" style="max-height: 70px; width: auto;" />
              </div>
              
              <!-- Main Content Card -->
              <div style="background: #FFFFFF; border-radius: 16px; padding: 40px 32px; box-shadow: 0 4px 24px rgba(139, 115, 85, 0.08);">
                
                <p style="font-size: 18px; margin: 0 0 16px 0;">Hei ${quote.contact_name}! 👋</p>
                
                <p style="margin: 0 0 20px 0; color: #5A5A5A;">
                  Vi setter stor pris på tilliten du viser oss. Basert på samtalen med ${districtManagerName} har vi skreddersydd et forsikringsforslag som gir deg og dine ansatte den tryggheten dere fortjener.
                </p>
                
                <!-- Benefits Box -->
                <div style="background: linear-gradient(135deg, #FAF7F2 0%, #F5EEE6 100%); border-radius: 12px; padding: 24px; margin: 24px 0;">
                  <p style="margin: 0 0 12px 0; font-weight: 600; color: #8B7355;">Som en del av Hår1-fellesskapet får dere:</p>
                  <p style="margin: 0; color: #5A5A5A; line-height: 1.9;">
                    ✓ Skreddersydde forsikringer for frisørbransjen<br/>
                    ✓ Konkurransedyktige priser gjennom vårt fellesinnkjøp<br/>
                    ✓ Enkel administrasjon – vi tar oss av det praktiske<br/>
                    ✓ Personlig oppfølging fra vårt dedikerte forsikringsteam
                  </p>
                </div>
                
                <h3 style="color: #8B7355; font-weight: 600; margin: 32px 0 16px 0; font-size: 16px; text-transform: uppercase; letter-spacing: 0.5px;">Ditt forsikringsforslag</h3>
                
                <table style="width: 100%; border-collapse: collapse; margin: 0 0 24px 0;">
                  <thead>
                    <tr style="background: #8B7355;">
                      <th style="padding: 14px 16px; text-align: left; font-weight: 600; color: #FFFFFF; border-radius: 8px 0 0 0;">Produkt</th>
                      <th style="padding: 14px 16px; text-align: center; font-weight: 600; color: #FFFFFF;">Antall</th>
                      <th style="padding: 14px 16px; text-align: right; font-weight: 600; color: #FFFFFF; border-radius: 0 8px 0 0;">Pris/år</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${productListHtml}
                    <tr style="background: linear-gradient(135deg, #8B7355 0%, #6B5440 100%);">
                      <td colspan="2" style="padding: 16px; color: #FFFFFF; font-weight: 600; border-radius: 0 0 0 8px;">Totalpris per år</td>
                      <td style="padding: 16px; text-align: right; color: #FFFFFF; font-weight: 700; font-size: 18px; border-radius: 0 0 8px 0;">${formatPrice(quote.total_price)} kr</td>
                    </tr>
                  </tbody>
                </table>
                
                ${quote.notes ? `
                  <div style="background: #F8F9FA; border-left: 4px solid #8B7355; border-radius: 0 8px 8px 0; padding: 16px 20px; margin: 24px 0;">
                    <p style="margin: 0 0 8px 0; font-weight: 600; color: #8B7355; font-size: 14px;">💬 Notater fra ${districtManagerName}:</p>
                    <p style="margin: 0; color: #5A5A5A; font-style: italic;">${quote.notes}</p>
                  </div>
                ` : ''}
                
                <p style="margin: 28px 0 20px 0; color: #5A5A5A;">
                  Klar til å sikre salongen din? Klikk på knappen under, så hjelper vi deg resten av veien.
                </p>
                
                <!-- CTA Button -->
                <div style="text-align: center; margin: 32px 0;">
                  <a href="${acceptanceUrl}" style="display: inline-block; background: linear-gradient(135deg, #8B7355 0%, #6B5440 100%); color: #FFFFFF; padding: 18px 48px; text-decoration: none; border-radius: 50px; font-weight: 600; font-size: 16px; box-shadow: 0 4px 16px rgba(139, 115, 85, 0.3);">
                    Aksepter tilbudet →
                  </a>
                </div>
                
                <p style="font-size: 13px; color: #888; text-align: center; margin: 0;">
                  Ved godkjenning blir du ført til signering av fullmakt.
                </p>
                
              </div>
              
              <!-- Footer -->
              <div style="text-align: center; margin-top: 32px; padding: 24px; color: #6B5440;">
                <p style="margin: 0 0 8px 0; font-weight: 500;">Har du spørsmål? Vi er her for deg!</p>
                <p style="margin: 0; font-weight: 600; color: #8B7355;">Hår1 Forsikringsteamet</p>
                <p style="margin: 12px 0 0 0; font-size: 14px; color: #888;">
                  📧 <a href="mailto:forsikring@har1.no" style="color: #8B7355; text-decoration: none;">forsikring@har1.no</a><br/>
                  📞 +47 4000 3345
                </p>
              </div>
              
            </div>
          </body>
          </html>
        `;
      }
    } else if (action === "notify_acceptance") {
      // Email to admin when quote is accepted (but not yet signed)
      toEmail = "lars-ivar@har1.no";
      
      const templateResult = await tryRenderFromTemplate(
        supabaseUrl,
        supabaseServiceKey,
        'insurance-quote-accepted-admin',
        {
          salongnavn: quote.salon_name || '',
          org_nummer: quote.org_number || '',
          kontaktperson: quote.contact_name || '',
          email: quote.email || '',
          telefon: quote.phone || 'Ikke oppgitt',
          distriktsleder: districtManagerName,
          totalpris: `${formatPrice(quote.total_price)} kr`,
          logoUrl: logoUrl,
          adminLink: `${siteUrl}/admin/insurance`,
        }
      );

      if (templateResult) {
        emailHtml = templateResult.html;
        subject = templateResult.subject;
      } else {
        // Fallback to hardcoded HTML
        subject = `Tilbud akseptert – ${quote.salon_name} (venter på signering)`;
        
        const productListHtml = products.map(p => {
          const { displayQuantity, calculatedPrice } = getProductDisplayInfo(p);
          return `<li style="margin: 8px 0; color: #4A4A4A;">${p.product_name}${p.tier_name ? ` (${p.tier_name})` : ''} – ${displayQuantity} – ${formatPrice(calculatedPrice)} kr</li>`;
        }).join('');

        emailHtml = `
          <!DOCTYPE html>
          <html>
          <head>
            <meta charset="utf-8">
          </head>
          <body style="font-family: 'Segoe UI', 'DM Sans', Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; background-color: #FAF8F5;">
            <div style="max-width: 600px; margin: 0 auto; padding: 40px 20px;">
              
              <div style="text-align: center; margin-bottom: 24px;">
                <img src="${logoUrl}" alt="Hår1 Forsikring" style="max-height: 60px; width: auto;" />
              </div>
              
              <div style="background: #FFFFFF; border-radius: 12px; padding: 32px; box-shadow: 0 2px 12px rgba(0,0,0,0.05);">
                
                <h2 style="margin: 0 0 20px 0; color: #8B7355;">📋 Forsikringstilbud akseptert</h2>
                
                <div style="background: #FFF8E7; border: 1px solid #F0C36D; border-radius: 8px; padding: 16px; margin: 20px 0;">
                  <strong style="color: #8B6914;">⚠️ Merk:</strong> Medlemmet har akseptert tilbudet, men fullmakten er ennå ikke signert.
                </div>
                
                <div style="background: #FAF7F2; border-radius: 8px; padding: 20px; margin: 20px 0;">
                  <p style="margin: 0 0 8px 0;"><strong>Salongnavn:</strong> ${quote.salon_name}</p>
                  <p style="margin: 0 0 8px 0;"><strong>Org.nummer:</strong> ${quote.org_number}</p>
                  <p style="margin: 0 0 8px 0;"><strong>Kontaktperson:</strong> ${quote.contact_name}</p>
                  <p style="margin: 0 0 8px 0;"><strong>E-post:</strong> ${quote.email}</p>
                  <p style="margin: 0;"><strong>Telefon:</strong> ${quote.phone || 'Ikke oppgitt'}</p>
                </div>
                
                <h3 style="color: #8B7355; margin: 24px 0 12px 0;">Valgte produkter:</h3>
                <ul style="padding-left: 20px; margin: 0;">
                  ${productListHtml}
                </ul>
                <p style="margin: 16px 0 0 0;"><strong>Totalpris:</strong> ${formatPrice(quote.total_price)} kr/år</p>
                
                <p style="margin: 20px 0 0 0;"><strong>Distriktsleder:</strong> ${districtManagerName}</p>
                
                <div style="margin-top: 24px;">
                  <a href="${siteUrl}/admin/insurance" 
                     style="display: inline-block; background: #8B7355; color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px; font-weight: 500;">
                    Se tilbud i admin →
                  </a>
                </div>
                
              </div>
            </div>
          </body>
          </html>
        `;
      }
    } else if (action === "notify_completion") {
      // Email to member confirming completion
      toEmail = quote.email;
      
      const templateResult = await tryRenderFromTemplate(
        supabaseUrl,
        supabaseServiceKey,
        'insurance-poa-signed',
        {
          fornavn: quote.contact_name?.split(' ')[0] || quote.contact_name || 'Hei',
          kontaktperson: quote.contact_name || '',
          salongnavn: quote.salon_name || '',
          logoUrl: logoUrl,
        }
      );

      if (templateResult) {
        emailHtml = templateResult.html;
        subject = templateResult.subject;
      } else {
        // Fallback to hardcoded HTML
        subject = `Velkommen som forsikringskunde! – ${quote.salon_name}`;
        
        emailHtml = `
          <!DOCTYPE html>
          <html>
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
          </head>
          <body style="font-family: 'Segoe UI', 'DM Sans', Arial, sans-serif; line-height: 1.7; color: #3D3D3D; margin: 0; padding: 0; background-color: #FAF8F5;">
            <div style="max-width: 600px; margin: 0 auto; padding: 40px 20px;">
              
              <div style="text-align: center; margin-bottom: 32px;">
                <img src="${logoUrl}" alt="Hår1 Forsikring" style="max-height: 70px; width: auto;" />
              </div>
              
              <div style="background: #FFFFFF; border-radius: 16px; padding: 40px 32px; box-shadow: 0 4px 24px rgba(139, 115, 85, 0.08);">
                
                <!-- Success Banner -->
                <div style="background: linear-gradient(135deg, #E8F5E9 0%, #C8E6C9 100%); border-radius: 12px; padding: 24px; margin-bottom: 28px; text-align: center;">
                  <div style="font-size: 48px; margin-bottom: 12px;">🎉</div>
                  <h2 style="color: #2E7D32; margin: 0; font-size: 22px;">Fullmakten er signert!</h2>
                </div>
                
                <p style="font-size: 18px; margin: 0 0 16px 0;">Hei ${quote.contact_name}!</p>
                
                <p style="margin: 0 0 20px 0; color: #5A5A5A;">
                  Tusen takk for tilliten! Vi har nå mottatt din signerte fullmakt for <strong>${quote.salon_name}</strong>, og du er nå en del av Hår1 Forsikring.
                </p>
                
                <div style="background: #FAF7F2; border-radius: 12px; padding: 24px; margin: 24px 0;">
                  <p style="margin: 0 0 12px 0; font-weight: 600; color: #8B7355;">Hva skjer nå?</p>
                  <p style="margin: 0; color: #5A5A5A; line-height: 1.9;">
                    ✓ Vi tar oss av all nødvendig administrasjon<br/>
                    ✓ Du får beskjed når forsikringene er aktive<br/>
                    ✓ Dokumenter blir tilgjengelige i portalen din
                  </p>
                </div>
                
                <p style="margin: 24px 0; color: #5A5A5A;">
                  Har du spørsmål i mellomtiden? Vi er alltid tilgjengelige og hjelper deg gjerne!
                </p>
                
              </div>
              
              <!-- Footer -->
              <div style="text-align: center; margin-top: 32px; padding: 24px; color: #6B5440;">
                <p style="margin: 0 0 4px 0; font-size: 15px;">Varm hilsen,</p>
                <p style="margin: 0; font-weight: 600; color: #8B7355; font-size: 16px;">Hår1 Forsikringsteamet</p>
                <p style="margin: 16px 0 0 0; font-size: 14px; color: #888;">
                  📧 <a href="mailto:forsikring@har1.no" style="color: #8B7355; text-decoration: none;">forsikring@har1.no</a><br/>
                  📞 +47 4000 3345
                </p>
              </div>
              
            </div>
          </body>
          </html>
        `;
      }
    }

    // Send email if enabled
    if (emailEnabled && resendApiKey && toEmail) {
      const emailResponse = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${resendApiKey}`,
        },
        body: JSON.stringify({
          from: "Hår1 Forsikring <forsikring@har1.no>",
          to: [toEmail],
          subject: subject,
          html: emailHtml,
        }),
      });

      if (!emailResponse.ok) {
        const errorData = await emailResponse.text();
        console.error("Error sending email:", errorData);
      } else {
        console.log(`Email sent successfully to: ${toEmail}`);
      }
    } else {
      console.log("Email disabled or no API key - email not sent");
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: "Email processed",
        emailSent: emailEnabled && !!resendApiKey
      }),
      { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );

  } catch (error: any) {
    console.error("Error in send-quote-email:", error);
    return new Response(
      JSON.stringify({ error: error.message || "An error occurred" }),
      { status: 500, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );
  }
};

serve(handler);
