import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "https://esm.sh/resend@2.0.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface InvitationEmailRequest {
  email: string;
  role: string;
  salonName?: string;
  districtName?: string;
  supplierName?: string;
  invitationUrl?: string;
  token?: string;
}

const getRoleLabel = (role: string): string => {
  const labels: Record<string, string> = {
    admin: "Admin",
    district_manager: "Distriktsleder",
    salon_owner: "Salongeier",
    stylist: "Frisør",
    apprentice: "Lærling",
    supplier_admin: "Leverandør Admin",
    supplier_sales: "Leverandør Salg",
    supplier_business_dev: "Leverandør Business Dev",
  };
  return labels[role] || role;
};

// Try to render email from database template via render-email-template function
async function tryRenderFromTemplate(
  supabaseUrl: string,
  supabaseServiceKey: string,
  templateSlug: string,
  variables: Record<string, string>
): Promise<{ html: string; subject: string } | null> {
  try {
    const response = await fetch(`${supabaseUrl}/functions/v1/render-email-template`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${supabaseServiceKey}`,
      },
      body: JSON.stringify({
        template_slug: templateSlug,
        variables
      }),
    });

    if (response.ok) {
      const data = await response.json();
      if (data.html && data.subject) {
        console.log(`Successfully rendered template: ${templateSlug}`);
        return { html: data.html, subject: data.subject };
      }
    }
    console.log(`Template ${templateSlug} not found or rendering failed, using fallback`);
    return null;
  } catch (error) {
    console.error(`Error rendering template ${templateSlug}:`, error);
    return null;
  }
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Verify user is authenticated and has admin or salon_owner role
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      console.error("No authorization header provided");
      return new Response(
        JSON.stringify({ error: "Unauthorized - no authorization header" }),
        { status: 401, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Check if email sending is enabled
    const { data: emailSetting } = await supabase
      .from("system_settings")
      .select("value")
      .eq("key", "email_enabled")
      .single();

    const isEmailEnabled = emailSetting?.value === true;

    if (!isEmailEnabled) {
      console.log("Email sending is disabled - skipping invitation email");
      return new Response(
        JSON.stringify({ success: true, skipped: true, reason: "Email sending disabled" }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Get user from JWT token
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    
    if (authError || !user) {
      console.error("Auth error:", authError);
      return new Response(
        JSON.stringify({ error: "Unauthorized - invalid token" }),
        { status: 401, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Check if user has admin or salon_owner role
    const { data: userRole, error: roleError } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .single();

    if (roleError || !userRole) {
      console.error("Role lookup error:", roleError);
      return new Response(
        JSON.stringify({ error: "Unauthorized - could not verify role" }),
        { status: 401, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const allowedRoles = ["admin", "salon_owner"];
    if (!allowedRoles.includes(userRole.role)) {
      console.error("User does not have required role:", userRole.role);
      return new Response(
        JSON.stringify({ error: "Forbidden - insufficient permissions" }),
        { status: 403, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    console.log(`Authorized user ${user.email} with role ${userRole.role} sending invitation`);

    const body = await req.json();
    console.log("Received body:", JSON.stringify(body));
    
    const { email, role, salonName, districtName, supplierName, invitationUrl: providedUrl, token: invitationToken } = body as InvitationEmailRequest;
    
    // Construct invitationUrl from token if not provided directly
    let invitationUrl = providedUrl;
    if (!invitationUrl && invitationToken) {
      // Get origin from request headers or use default
      const origin = req.headers.get("origin") || "https://portal.har1.no";
      invitationUrl = `${origin}/onboarding?token=${invitationToken}`;
      console.log("Constructed invitationUrl from token:", invitationUrl);
    }
    
    console.log("Parsed fields - email:", email, "role:", role, "invitationUrl:", invitationUrl);

    // Validate required fields
    if (!email || !role || !invitationUrl) {
      console.error("Validation failed - email:", email, "role:", role, "invitationUrl:", invitationUrl);
      return new Response(
        JSON.stringify({ error: "Missing required fields: email, role, invitationUrl or token", received: { email, role, invitationUrl, invitationToken } }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    console.log(`Sending invitation email to ${email} with role ${role}`);

    // Build entity info
    let entityInfo = '';
    if (salonName) {
      entityInfo = salonName;
    } else if (districtName) {
      entityInfo = districtName;
    } else if (supplierName) {
      entityInfo = supplierName;
    }

    // Try database template first
    const templateResult = await tryRenderFromTemplate(
      supabaseUrl,
      supabaseServiceKey,
      'user-invitation',
      {
        email: email,
        rolle: getRoleLabel(role),
        salongnavn: salonName || '',
        distriktsnavn: districtName || '',
        leverandornavn: supplierName || '',
        tilknytning: entityInfo,
        link: invitationUrl,
      }
    );

    let emailHtml: string;
    let subject: string;

    if (templateResult) {
      emailHtml = templateResult.html;
      subject = templateResult.subject;
    } else {
      // Fallback to hardcoded HTML with OTP instructions
      subject = "Du er invitert til Hår1 Portalen";
      
      // Build entity info section
      let entityInfoHtml = '';
      if (salonName) {
        entityInfoHtml = `<p style="color: #4a4a4a; font-size: 16px; line-height: 1.6;">Du er invitert til salongen: <strong>${salonName}</strong></p>`;
      } else if (districtName) {
        entityInfoHtml = `<p style="color: #4a4a4a; font-size: 16px; line-height: 1.6;">Du er tilknyttet distriktet: <strong>${districtName}</strong></p>`;
      } else if (supplierName) {
        entityInfoHtml = `<p style="color: #4a4a4a; font-size: 16px; line-height: 1.6;">Du er tilknyttet leverandøren: <strong>${supplierName}</strong></p>`;
      }

      emailHtml = `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
        </head>
        <body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; background-color: #f9fafb;">
          <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f9fafb; padding: 40px 20px;">
            <tr>
              <td align="center">
                <table width="100%" cellpadding="0" cellspacing="0" style="max-width: 600px; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);">
                  <!-- Header -->
                  <tr>
                    <td style="background: linear-gradient(135deg, #7c3aed 0%, #9333ea 100%); padding: 40px 40px; text-align: center;">
                      <img src="https://portal.har1.no/haar1-logo-white.png" alt="Hår1" style="height: 48px; width: auto;">
                    </td>
                  </tr>
                  
                  <!-- Content -->
                  <tr>
                    <td style="padding: 40px;">
                      <h1 style="margin: 0 0 24px; font-size: 24px; font-weight: 600; color: #111827;">
                        Velkommen til Hår1 Portalen! 👋
                      </h1>
                      
                      <p style="margin: 0 0 16px; font-size: 16px; line-height: 1.6; color: #4b5563;">
                        Du har blitt invitert til å bli med i Hår1 Portalen.
                      </p>
                      
                      ${entityInfoHtml}
                      
                      <div style="background: #f4f4f5; border-radius: 8px; padding: 16px; margin: 24px 0;">
                        <p style="margin: 0 0 8px 0; color: #71717a; font-size: 14px;">Din rolle:</p>
                        <p style="margin: 0; color: #1a1a1a; font-size: 18px; font-weight: 600;">${getRoleLabel(role)}</p>
                      </div>
                      
                      <p style="margin: 0 0 16px; font-size: 16px; line-height: 1.6; color: #4b5563;">
                        Klikk på knappen under for å fullføre registreringen og fylle ut din profil:
                      </p>
                      
                      <div style="text-align: center; margin: 24px 0;">
                        <a href="${invitationUrl}" style="display: inline-block; background: linear-gradient(135deg, #7c3aed 0%, #9333ea 100%); color: #ffffff; text-decoration: none; padding: 14px 32px; border-radius: 8px; font-weight: 600; font-size: 16px;">
                          Fullfør registrering
                        </a>
                      </div>
                      
                      <div style="background-color: #f3e8ff; border-radius: 8px; padding: 20px; margin: 24px 0;">
                        <h3 style="margin: 0 0 12px; font-size: 14px; font-weight: 600; color: #7c3aed;">Etter registrering – slik logger du inn:</h3>
                        <ol style="margin: 0; padding-left: 20px; color: #4b5563; font-size: 14px; line-height: 1.8;">
                          <li>Gå til <a href="https://portal.har1.no" style="color: #7c3aed;">portal.har1.no</a></li>
                          <li>Skriv inn e-postadressen din: <strong>${email}</strong></li>
                          <li>Klikk "Send engangskode"</li>
                          <li>Du mottar en 6-sifret kode på e-post</li>
                          <li>Skriv inn koden og du er logget inn!</li>
                        </ol>
                        <p style="margin: 12px 0 0 0; font-size: 13px; color: #6b7280;">
                          Vi bruker engangskode (OTP) for sikker innlogging – ingen passord å huske!
                        </p>
                      </div>
                      
                      <p style="color: #71717a; font-size: 14px; line-height: 1.6;">
                        Denne invitasjonen utløper om 7 dager. Hvis du ikke forventet denne e-posten, kan du trygt ignorere den.
                      </p>
                    </td>
                  </tr>
                  
                  <!-- Footer -->
                  <tr>
                    <td style="padding: 24px 40px; background-color: #f9fafb; text-align: center;">
                      <p style="margin: 0; font-size: 12px; color: #9ca3af;">
                        Med vennlig hilsen,<br>
                        Hår1-teamet
                      </p>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
        </body>
        </html>
      `;
    }

    const { data, error } = await resend.emails.send({
      from: "Hår1 Portalen <noreply@har1.no>",
      to: [email],
      subject: subject,
      html: emailHtml,
    });

    if (error) {
      console.error("Resend API error:", error);
      return new Response(
        JSON.stringify({ error: error.message || "Failed to send email" }),
        {
          status: 500,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }

    console.log("Invitation email sent successfully:", data);

    return new Response(JSON.stringify({ success: true, data }), {
      status: 200,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  } catch (error: any) {
    console.error("Error sending invitation email:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
