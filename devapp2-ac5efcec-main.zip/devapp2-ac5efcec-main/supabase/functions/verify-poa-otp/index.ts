import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface VerifyOtpRequest {
  email: string;
  otp: string;
  ipAddress?: string;
  userAgent?: string;
}

interface QuoteProduct {
  product_id: string;
  product_name: string;
  price: number;
  quantity: number;
  tier_id?: string;
  tier_name?: string;
  arsverk?: number;
  selected_employees?: { user_id: string; name: string; personnummer?: string }[];
}

// Hash OTP using same method as send function
async function hashOtp(otp: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(otp + Deno.env.get("SUPABASE_SERVICE_ROLE_KEY"));
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, "0")).join("");
}

// Create insurance orders from quote - split into bedrift and helse
async function createOrdersFromQuote(
  supabase: any, 
  quote: any, 
  poa: any
): Promise<{ bedriftOrderId: string | null; helseOrderId: string | null; error: string | null }> {
  console.log("Creating insurance orders from quote:", quote.id);

  try {
    const products: QuoteProduct[] = quote.products || [];
    if (products.length === 0) {
      console.log("No products in quote, skipping order creation");
      return { bedriftOrderId: null, helseOrderId: null, error: "No products in quote" };
    }

    // Split products into bedrift and helse
    const helseProducts = products.filter((p) => 
      p.product_name === "Helseforsikring" || (p.selected_employees && p.selected_employees.length > 0)
    );
    const bedriftProducts = products.filter((p) => 
      p.product_name !== "Helseforsikring" && (!p.selected_employees || p.selected_employees.length === 0)
    );

    console.log(`Splitting: ${bedriftProducts.length} bedrift products, ${helseProducts.length} helse products`);

    // Fetch product details
    const productNames = products.map((p) => p.product_name);
    const { data: dbProducts } = await supabase
      .from("insurance_products")
      .select("id, name")
      .in("name", productNames);

    const productNameToId: Record<string, string> = {};
    if (dbProducts) {
      for (const p of dbProducts) {
        productNameToId[p.name] = p.id;
      }
    }

    const tierNames = products.filter((p) => p.tier_name).map((p) => p.tier_name);
    const { data: dbTiers } = await supabase
      .from("insurance_product_tiers")
      .select("id, tier_name, product_id")
      .in("tier_name", tierNames);

    const tierNameToId: Record<string, string> = {};
    if (dbTiers) {
      for (const t of dbTiers) {
        tierNameToId[`${t.product_id}:${t.tier_name}`] = t.id;
      }
    }

    let bedriftOrderId: string | null = null;
    let helseOrderId: string | null = null;

    // Create Bedrift order
    if (bedriftProducts.length > 0) {
      let bedriftTotal = 0;
      for (const p of bedriftProducts) {
        const qty = p.quantity || p.arsverk || 1;
        bedriftTotal += p.price * qty;
      }

      const { data: bedriftOrder, error: bedriftError } = await supabase
        .from("insurance_orders")
        .insert({
          salon_id: quote.member_salon_id,
          ordered_by_user_id: quote.district_manager_id,
          status: "pending_approval",
          order_type: "new",
          order_category: "bedrift",
          total_price: bedriftTotal,
          contact_name: quote.contact_name,
          contact_email: quote.email,
          contact_phone: quote.phone,
          switching_provider: poa?.has_existing_insurance || false,
          previous_insurances: poa?.previous_insurers || null,
          poa_signature_name: poa?.contact_name || null,
          poa_signature_at: poa?.signed_at || null,
          source_quote_id: quote.id,
          salon_address: quote.salon_address,
          salon_postal_code: quote.salon_postal_code,
          salon_city: quote.salon_city,
        })
        .select()
        .single();

      if (bedriftError) {
        console.error("Error creating bedrift order:", bedriftError);
      } else {
        bedriftOrderId = bedriftOrder.id;
        console.log("Bedrift order created:", bedriftOrderId);

        for (const product of bedriftProducts) {
          const productId = product.product_id || productNameToId[product.product_name];
          if (!productId) continue;

          const quantity = product.quantity || product.arsverk || 1;
          const tierId = product.tier_id || (product.tier_name ? tierNameToId[`${productId}:${product.tier_name}`] : null);

          await supabase.from("insurance_order_items").insert({
            order_id: bedriftOrderId,
            product_id: productId,
            tier_id: tierId || null,
            quantity,
            unit_price: product.price,
            total_price: product.price * quantity,
          });
        }
      }
    }

    // Create Helse order
    if (helseProducts.length > 0) {
      let helseTotal = 0;
      for (const p of helseProducts) {
        const qty = p.selected_employees?.length || p.quantity || 1;
        helseTotal += p.price * qty;
      }

      const { data: helseOrder, error: helseError } = await supabase
        .from("insurance_orders")
        .insert({
          salon_id: quote.member_salon_id,
          ordered_by_user_id: quote.district_manager_id,
          status: "pending_approval",
          order_type: "new",
          order_category: "helse",
          total_price: helseTotal,
          contact_name: quote.contact_name,
          contact_email: quote.email,
          contact_phone: quote.phone,
          switching_provider: false,
          previous_insurances: null,
          poa_signature_name: poa?.contact_name || null,
          poa_signature_at: poa?.signed_at || null,
          source_quote_id: quote.id,
          salon_address: quote.salon_address,
          salon_postal_code: quote.salon_postal_code,
          salon_city: quote.salon_city,
        })
        .select()
        .single();

      if (helseError) {
        console.error("Error creating helse order:", helseError);
      } else {
        helseOrderId = helseOrder.id;
        console.log("Helse order created:", helseOrderId);

        for (const product of helseProducts) {
          const productId = product.product_id || productNameToId[product.product_name];
          if (!productId) continue;

          const quantity = product.selected_employees?.length || product.quantity || 1;

          const { data: orderItem, error: itemError } = await supabase
            .from("insurance_order_items")
            .insert({
              order_id: helseOrderId,
              product_id: productId,
              tier_id: null,
              quantity,
              unit_price: product.price,
              total_price: product.price * quantity,
            })
            .select()
            .single();

          if (itemError) continue;

          if (product.selected_employees && product.selected_employees.length > 0) {
            for (const emp of product.selected_employees) {
              if (emp.user_id) {
                await supabase.from("insurance_order_employees").insert({
                  order_item_id: orderItem.id,
                  user_id: emp.user_id,
                });
              }
            }
          }
        }
      }
    }

    return { bedriftOrderId, helseOrderId, error: null };
  } catch (err: any) {
    console.error("Error in createOrdersFromQuote:", err);
    return { bedriftOrderId: null, helseOrderId: null, error: err.message };
  }
}

const handler = async (req: Request): Promise<Response> => {
  console.log("verify-poa-otp function called");

  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const resendApiKey = Deno.env.get("RESEND_API_KEY");
    const siteUrl = Deno.env.get("SITE_URL") || "https://devapp2.lovable.app";
    const logoUrl = `${siteUrl}/haar1-forsikring-email-logo.png`;

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { data: settings } = await supabase
      .from("system_settings")
      .select("value")
      .eq("key", "email_enabled")
      .single();

    const emailEnabled = settings?.value === true || settings?.value === "true";

    const { email, otp, ipAddress, userAgent }: VerifyOtpRequest = await req.json();
    console.log("Verifying OTP for email:", email);

    const { data: poa, error: fetchError } = await supabase
      .from("insurance_power_of_attorney")
      .select("*")
      .eq("email", email)
      .eq("signed", false)
      .order("created_at", { ascending: false })
      .limit(1)
      .single();

    if (fetchError || !poa) {
      console.error("POA not found:", fetchError);
      return new Response(
        JSON.stringify({ error: "Fullmakt ikke funnet", code: "NOT_FOUND" }),
        { status: 404, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    if (new Date(poa.otp_expires_at) < new Date()) {
      return new Response(
        JSON.stringify({ error: "Koden har utløpt. Vennligst be om en ny kode.", code: "EXPIRED" }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    if (poa.otp_attempts >= 5) {
      return new Response(
        JSON.stringify({ error: "For mange forsøk. Vennligst be om en ny kode.", code: "TOO_MANY_ATTEMPTS" }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const otpHash = await hashOtp(otp);
    if (otpHash !== poa.otp_code_hash) {
      await supabase
        .from("insurance_power_of_attorney")
        .update({ otp_attempts: poa.otp_attempts + 1 })
        .eq("id", poa.id);

      return new Response(
        JSON.stringify({ error: "Feil kode. Vennligst prøv igjen.", code: "INVALID_OTP" }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const signedAt = new Date().toISOString();
    const { error: updateError } = await supabase
      .from("insurance_power_of_attorney")
      .update({
        signed: true,
        signed_at: signedAt,
        ip_address: ipAddress || null,
        user_agent: userAgent || null,
      })
      .eq("id", poa.id);

    if (updateError) {
      console.error("Error updating POA as signed:", updateError);
      throw new Error("Kunne ikke oppdatere fullmakt");
    }

    console.log("POA signed successfully:", poa.id);

    let linkedQuote = null;
    let bedriftOrderId: string | null = null;
    let helseOrderId: string | null = null;
    
    if (poa.quote_id) {
      console.log("POA is linked to quote:", poa.quote_id);
      
      const { data: quote, error: quoteError } = await supabase
        .from("insurance_quotes")
        .update({
          status: "completed",
          completed_at: signedAt,
          link_to_fullmakt: poa.id,
        })
        .eq("id", poa.quote_id)
        .select("*, district_manager:users!insurance_quotes_district_manager_id_fkey(name, email)")
        .single();

      if (quoteError) {
        console.error("Error updating linked quote:", quoteError);
      } else {
        console.log("Quote marked as completed:", quote.id);
        linkedQuote = quote;

        // Create split orders
        const result = await createOrdersFromQuote(supabase, quote, poa);
        if (result.error) {
          console.error("Failed to create orders from quote:", result.error);
        } else {
          bedriftOrderId = result.bedriftOrderId;
          helseOrderId = result.helseOrderId;
          console.log("Insurance orders created - Bedrift:", bedriftOrderId, "Helse:", helseOrderId);
        }
      }
    }

    // Send confirmation emails
    if (emailEnabled && resendApiKey) {
      const userEmailHtml = `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
        </head>
        <body style="font-family: 'Segoe UI', 'DM Sans', Arial, sans-serif; line-height: 1.7; color: #3D3D3D; margin: 0; padding: 0; background-color: #FAF8F5;">
          <div style="max-width: 600px; margin: 0 auto; padding: 40px 20px;">
            
            <!-- Logo Header -->
            <div style="text-align: center; margin-bottom: 32px;">
              <img src="${logoUrl}" alt="Hår1 Forsikring" style="max-height: 70px; width: auto;" />
            </div>
            
            <!-- Main Content Card -->
            <div style="background: #FFFFFF; border-radius: 16px; padding: 40px 32px; box-shadow: 0 4px 24px rgba(139, 115, 85, 0.08);">
              
              <!-- Success Banner -->
              <div style="background: linear-gradient(135deg, #E8F5E9 0%, #C8E6C9 100%); border-radius: 12px; padding: 28px; margin-bottom: 28px; text-align: center;">
                <div style="font-size: 48px; margin-bottom: 12px;">🎉</div>
                <h2 style="color: #2E7D32; margin: 0; font-size: 22px; font-weight: 600;">Fullmakten er signert!</h2>
              </div>
              
              <p style="font-size: 18px; margin: 0 0 16px 0;">Hei! 👋</p>
              
              <p style="margin: 0 0 20px 0; color: #5A5A5A;">
                Tusen takk – fullmakten er nå signert, og Hår1 Forsikringsteamet starter arbeidet med forsikringene dine.
              </p>
              
              <!-- Next Steps Box -->
              <div style="background: linear-gradient(135deg, #FAF7F2 0%, #F5EEE6 100%); border-radius: 12px; padding: 24px; margin: 24px 0;">
                <p style="margin: 0 0 12px 0; font-weight: 600; color: #8B7355;">Hva skjer nå?</p>
                <p style="margin: 0; color: #5A5A5A; line-height: 1.9;">
                  ✓ Vi tar oss av all nødvendig administrasjon<br/>
                  ✓ Du får beskjed når forsikringene er aktive<br/>
                  ✓ Dokumenter blir tilgjengelige i portalen din
                </p>
              </div>
              
              <p style="margin: 24px 0; color: #5A5A5A;">
                Du hører fra oss ved behov – vi er her for deg! 💛
              </p>
              
            </div>
            
            <!-- Footer -->
            <div style="text-align: center; margin-top: 32px; padding: 24px; color: #6B5440;">
              <p style="margin: 0 0 4px 0; font-size: 15px;">Varm hilsen,</p>
              <p style="margin: 0; font-weight: 600; color: #8B7355; font-size: 16px;">Hår1 Forsikringsteamet</p>
              <p style="margin: 16px 0 0 0; font-size: 14px; color: #888;">
                📧 <a href="mailto:forsikring@har1.no" style="color: #8B7355; text-decoration: none;">forsikring@har1.no</a><br/>
                📞 +47 4000 3345
              </p>
            </div>
            
          </div>
        </body>
        </html>
      `;

      try {
        await fetch("https://api.resend.com/emails", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${resendApiKey}`,
          },
          body: JSON.stringify({
            from: "Hår1 Forsikring <forsikring@har1.no>",
            to: [email],
            subject: "Fullmakten din er nå signert ✓",
            html: userEmailHtml,
          }),
        });
        console.log("Confirmation email sent to user:", email);
      } catch (e) {
        console.error("Error sending user confirmation email:", e);
      }

      // Admin email with order info
      const ordersCreatedHtml = bedriftOrderId || helseOrderId ? `
        <div style="background: linear-gradient(135deg, #E8F5E9 0%, #C8E6C9 100%); border-radius: 12px; padding: 20px; margin: 20px 0;">
          <p style="margin: 0 0 8px 0; font-weight: 600; color: #2E7D32;">📦 Bestillinger opprettet automatisk</p>
          ${bedriftOrderId ? `<p style="margin: 4px 0; color: #4A4A4A;">• Bedriftsforsikring: <code style="background: #fff; padding: 2px 6px; border-radius: 4px; font-size: 12px;">${bedriftOrderId.slice(0, 8)}...</code></p>` : ''}
          ${helseOrderId ? `<p style="margin: 4px 0; color: #4A4A4A;">• Helseforsikring: <code style="background: #fff; padding: 2px 6px; border-radius: 4px; font-size: 12px;">${helseOrderId.slice(0, 8)}...</code></p>` : ''}
        </div>
      ` : '';

      const adminEmailHtml = `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
        </head>
        <body style="font-family: 'Segoe UI', 'DM Sans', Arial, sans-serif; line-height: 1.7; color: #3D3D3D; margin: 0; padding: 0; background-color: #FAF8F5;">
          <div style="max-width: 600px; margin: 0 auto; padding: 40px 20px;">
            
            <!-- Logo Header -->
            <div style="text-align: center; margin-bottom: 32px;">
              <img src="${logoUrl}" alt="Hår1 Forsikring" style="max-height: 70px; width: auto;" />
            </div>
            
            <!-- Main Content Card -->
            <div style="background: #FFFFFF; border-radius: 16px; padding: 40px 32px; box-shadow: 0 4px 24px rgba(139, 115, 85, 0.08);">
              
              <h2 style="margin: 0 0 24px 0; color: #8B7355;">✅ Ny fullmakt signert${linkedQuote ? ' – Tilbud fullført' : ''}</h2>
              
              <!-- Salon Info Box -->
              <div style="background: linear-gradient(135deg, #FAF7F2 0%, #F5EEE6 100%); border-radius: 12px; padding: 20px; margin: 20px 0;">
                <p style="margin: 0 0 8px 0;"><strong>Salongnavn:</strong> ${poa.salon_name}</p>
                <p style="margin: 0 0 8px 0;"><strong>Org.nummer:</strong> ${poa.org_number}</p>
                <p style="margin: 0 0 8px 0;"><strong>Kontaktperson:</strong> ${poa.contact_name}</p>
                <p style="margin: 0;"><strong>E-post:</strong> ${poa.email}</p>
              </div>
              
              ${ordersCreatedHtml}
              
              <!-- CTA Button -->
              <div style="text-align: center; margin: 28px 0;">
                <a href="${siteUrl}/admin/insurance" style="display: inline-block; background: linear-gradient(135deg, #8B7355 0%, #6B5440 100%); color: #FFFFFF; padding: 14px 32px; text-decoration: none; border-radius: 50px; font-weight: 600; font-size: 15px; box-shadow: 0 4px 16px rgba(139, 115, 85, 0.3);">
                  Se i admin →
                </a>
              </div>
              
            </div>
            
            <!-- Footer -->
            <div style="text-align: center; margin-top: 32px; padding: 24px; color: #888; font-size: 13px;">
              <p style="margin: 0;">Denne e-posten er sendt automatisk fra Hår1-portalen.</p>
            </div>
            
          </div>
        </body>
        </html>
      `;

      try {
        await fetch("https://api.resend.com/emails", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${resendApiKey}`,
          },
          body: JSON.stringify({
            from: "Hår1 Forsikring <forsikring@har1.no>",
            to: ["lars-ivar@har1.no"],
            subject: `Fullmakt signert: ${poa.salon_name}${bedriftOrderId || helseOrderId ? ' – Bestillinger opprettet' : ''}`,
            html: adminEmailHtml,
          }),
        });
        console.log("Admin notification email sent");
      } catch (e) {
        console.error("Error sending admin email:", e);
      }
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        poaId: poa.id,
        quoteCompleted: !!linkedQuote,
        bedriftOrderId,
        helseOrderId
      }),
      { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );

  } catch (error: any) {
    console.error("Error in verify-poa-otp:", error);
    return new Response(
      JSON.stringify({ error: error.message || "An error occurred" }),
      { status: 500, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );
  }
};

serve(handler);
