import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// ICON Hairspa customer data with org numbers and customer numbers
const customerData = [
  { org: "989348809", kundenummer: "39264" },
  { org: "998403189", kundenummer: "36997" },
  { org: "994266799", kundenummer: "35326" },
  { org: "918817182", kundenummer: "38994" },
  { org: "899002962", kundenummer: "39266" },
  { org: "997031830", kundenummer: "36543" },
  { org: "970348115", kundenummer: "31816" },
  { org: "998037980", kundenummer: "36929" },
  { org: "987488557", kundenummer: "30933" },
  { org: "994454730", kundenummer: "35349" },
  { org: "923959335", kundenummer: "42563" },
  { org: "989397516", kundenummer: "32310" },
  { org: "912827313", kundenummer: "40013" },
  { org: "992691336", kundenummer: "35657" },
  { org: "981873858", kundenummer: "32500" },
  { org: "991246983", kundenummer: "31512" },
  { org: "990163340", kundenummer: "34134" },
  { org: "992101725", kundenummer: "34137" },
  { org: "977674093", kundenummer: "30308" },
  { org: "993294756", kundenummer: "40155" },
  { org: "825627162", kundenummer: "41075" },
  { org: "812450352", kundenummer: "37124" },
  { org: "914000548", kundenummer: "42163" },
  { org: "991418415", kundenummer: "33407" },
  { org: "918004289", kundenummer: "39204" },
  { org: "914072166", kundenummer: "39106" },
  { org: "894538902", kundenummer: "36116" },
  { org: "817409822", kundenummer: "38922" },
  { org: "923029737", kundenummer: "40653" },
  { org: "970320857", kundenummer: "33421" },
  { org: "930495239", kundenummer: "42661" },
  { org: "928620301", kundenummer: "42586" },
  { org: "914836123", kundenummer: "39932" },
  { org: "998239052", kundenummer: "39273" },
  { org: "891174292", kundenummer: "32953" },
  { org: "918515585", kundenummer: "39299" },
  { org: "988419141", kundenummer: "32023" },
  { org: "926087053", kundenummer: "41789" },
  { org: "818405952", kundenummer: "40430" },
  { org: "925891576", kundenummer: "42594" },
  { org: "926419498", kundenummer: "41379" },
  { org: "829776782", kundenummer: "42996" },
  { org: "818423012", kundenummer: "39242" },
  { org: "883640012", kundenummer: "39182" },
  { org: "988613398", kundenummer: "42454" },
  { org: "989594915", kundenummer: "36839" },
  { org: "920973140", kundenummer: "40218" },
  { org: "989084321", kundenummer: "31370" },
  { org: "999134297", kundenummer: "31001" },
  { org: "996294579", kundenummer: "39103" },
  { org: "994480936", kundenummer: "39951" },
  { org: "927163047", kundenummer: "41883" },
  { org: "988946737", kundenummer: "31586" },
  { org: "813826712", kundenummer: "39902" },
  { org: "984234724", kundenummer: "38157" },
  { org: "919062894", kundenummer: "40124" },
  { org: "999145736", kundenummer: "37395" },
  { org: "976483839", kundenummer: "32862" },
  { org: "981466586", kundenummer: "41253" },
  { org: "983431631", kundenummer: "32948" },
  { org: "981514319", kundenummer: "39815" },
  { org: "920342205", kundenummer: "40351" },
  { org: "930360147", kundenummer: "43147" },
  { org: "976053605", kundenummer: "42606" },
  { org: "997198409", kundenummer: "39559" },
  { org: "925611050", kundenummer: "41658" },
  { org: "927196689", kundenummer: "41978" },
  { org: "930353205", kundenummer: "43153" },
  { org: "911891557", kundenummer: "39559" },
  { org: "996069257", kundenummer: "36037" },
  { org: "928715027", kundenummer: "42608" },
  { org: "916562047", kundenummer: "39175" },
  { org: "913307887", kundenummer: "38179" },
  { org: "989572679", kundenummer: "39807" },
  { org: "994494368", kundenummer: "35379" },
  { org: "987658738", kundenummer: "40608" },
  { org: "994941224", kundenummer: "39197" },
  { org: "916331614", kundenummer: "38783" },
  { org: "984840136", kundenummer: "39173" },
  { org: "996655229", kundenummer: "36234" },
  { org: "930980552", kundenummer: "43279" },
  { org: "993812102", kundenummer: "41208" },
  { org: "929721225", kundenummer: "43020" },
  { org: "997943392", kundenummer: "35705" },
  { org: "998610923", kundenummer: "37267" },
  { org: "913865545", kundenummer: "40766" },
  { org: "977558344", kundenummer: "32159" },
  { org: "897076322", kundenummer: "36504" },
  { org: "986979778", kundenummer: "30298" },
  { org: "994276859", kundenummer: "39940" },
  { org: "885923992", kundenummer: "31211" },
  { org: "973192302", kundenummer: "32486" },
  { org: "933277070", kundenummer: "43741" },
  { org: "914738857", kundenummer: "39223" },
  { org: "958075979", kundenummer: "42628" },
  { org: "974430355", kundenummer: "33621" },
  { org: "988421804", kundenummer: "40623" },
  { org: "988925594", kundenummer: "38883" },
  { org: "925288241", kundenummer: "38895" },
  { org: "997073134", kundenummer: "42463" },
  { org: "830877622", kundenummer: "37200" },
  { org: "916602367", kundenummer: "39973" },
  { org: "920240690", kundenummer: "40652" },
  { org: "911855275", kundenummer: "39185" },
  { org: "921441959", kundenummer: "40736" },
  { org: "926086111", kundenummer: "41338" },
  { org: "980123499", kundenummer: "31086" },
  { org: "995745704", kundenummer: "39262" },
  { org: "940033500", kundenummer: "32405" },
  { org: "977067022", kundenummer: "36994" },
  { org: "999195059", kundenummer: "37354" },
  { org: "996760618", kundenummer: "42462" },
  { org: "922609624", kundenummer: "40487" },
  { org: "930120847", kundenummer: "40543" },
  { org: "961472229", kundenummer: "37085" },
  { org: "985872317", kundenummer: "39171" },
  { org: "911662396", kundenummer: "32467" },
  { org: "932593610", kundenummer: "43672" },
  { org: "926732749", kundenummer: "42112" },
  { org: "922339988", kundenummer: "40404" },
  { org: "992849673", kundenummer: "37127" },
  { org: "924764600", kundenummer: "40875" },
  { org: "998911664", kundenummer: "42253" },
  { org: "984475144", kundenummer: "32166" },
  { org: "932841363", kundenummer: "43645" },
  { org: "932686953", kundenummer: "43675" },
  { org: "931313274", kundenummer: "43425" },
  { org: "820351622", kundenummer: "42432" },
  { org: "922321620", kundenummer: "42849" },
  { org: "998508576", kundenummer: "30121" },
  { org: "824190992", kundenummer: "40753" },
  { org: "913332156", kundenummer: "38919" },
  { org: "895460362", kundenummer: "35817" },
  { org: "927968169", kundenummer: "42224" },
  { org: "993155934", kundenummer: "40498" },
  { org: "897109832", kundenummer: "36818" },
  { org: "919294256", kundenummer: "40301" },
  { org: "891478372", kundenummer: "31352" },
  { org: "927402890", kundenummer: "42982" },
  { org: "976188284", kundenummer: "38961" },
  { org: "913183762", kundenummer: "39304" },
  { org: "999166628", kundenummer: "37252" },
  { org: "984238355", kundenummer: "31118" },
  { org: "989620231", kundenummer: "32855" },
  { org: "999503799", kundenummer: "40571" },
  { org: "930495239", kundenummer: "42661" },
  { org: "922648808", kundenummer: "40566" },
  { org: "993294713", kundenummer: "40154" },
  { org: "889040432", kundenummer: "33541" },
  { org: "915519970", kundenummer: "43035" },
  { org: "889884762", kundenummer: "31987" },
  { org: "917063591", kundenummer: "43729" },
  { org: "979783604", kundenummer: "31264" },
  { org: "918588493", kundenummer: "39285" },
  { org: "918771824", kundenummer: "39338" },
  { org: "980363376", kundenummer: "30610" },
  { org: "914637767", kundenummer: "38630" },
  { org: "986623175", kundenummer: "43367" },
  { org: "927440911", kundenummer: "42000" },
  { org: "911879492", kundenummer: "40418" },
  { org: "921777485", kundenummer: "40648" },
  { org: "921133464", kundenummer: "40650" },
  { org: "921277385", kundenummer: "40650" },
  { org: "819165742", kundenummer: "39351" },
  { org: "971190140", kundenummer: "40007" },
  { org: "894205202", kundenummer: "39193" },
  { org: "923208801", kundenummer: "42672" },
  { org: "999629962", kundenummer: "37338" },
  { org: "985506140", kundenummer: "31955" },
  { org: "911559676", kundenummer: "37380" },
  { org: "917338213", kundenummer: "42446" },
  { org: "990542414", kundenummer: "39181" },
  { org: "922103887", kundenummer: "40504" },
  { org: "919905751", kundenummer: "42440" },
  { org: "895833622", kundenummer: "36780" },
  { org: "926544594", kundenummer: "41578" },
  { org: "915597920", kundenummer: "38660" },
  { org: "917095795", kundenummer: "40345" },
  { org: "977024137", kundenummer: "39178" },
  { org: "998536782", kundenummer: "37187" },
  { org: "915258336", kundenummer: "38543" },
  { org: "917155410", kundenummer: "42548" },
  { org: "923768467", kundenummer: "40655" },
  { org: "915922880", kundenummer: "39061" },
];

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // First, find ICON Hairspa supplier ID
    const { data: supplier, error: supplierError } = await supabase
      .from("leverandorer")
      .select("id, navn")
      .ilike("navn", "%icon%")
      .single();

    if (supplierError || !supplier) {
      console.error("Could not find ICON Hairspa supplier:", supplierError);
      return new Response(
        JSON.stringify({ error: "Could not find ICON Hairspa supplier" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 400 }
      );
    }

    console.log(`Found supplier: ${supplier.navn} (${supplier.id})`);

    // Fetch all salons
    const { data: salons, error: salonsError } = await supabase
      .from("salons")
      .select("id, name, org_number");

    if (salonsError) {
      console.error("Error fetching salons:", salonsError);
      return new Response(
        JSON.stringify({ error: "Error fetching salons" }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 500 }
      );
    }

    // Create a map of org_number to salon
    const salonMap = new Map<string, { id: string; name: string }>();
    for (const salon of salons || []) {
      if (salon.org_number) {
        const normalizedOrg = salon.org_number.replace(/\s/g, "");
        salonMap.set(normalizedOrg, { id: salon.id, name: salon.name });
      }
    }

    let matchedCount = 0;
    let notFoundCount = 0;
    let insertedCount = 0;
    const notFoundOrgs: string[] = [];
    const errors: string[] = [];

    for (const customer of customerData) {
      const normalizedOrg = customer.org.replace(/\s/g, "");
      const salon = salonMap.get(normalizedOrg);

      if (salon) {
        matchedCount++;
        
        const { error: upsertError } = await supabase
          .from("supplier_identifiers")
          .upsert({
            supplier_id: supplier.id,
            salon_id: salon.id,
            supplier_customer_number: customer.kundenummer,
            identifier_type: "kundenummer",
          }, {
            onConflict: "supplier_id,salon_id,identifier_type",
          });

        if (upsertError) {
          console.error(`Error upserting for salon ${salon.name}:`, upsertError);
          errors.push(`${salon.name}: ${upsertError.message}`);
        } else {
          insertedCount++;
          console.log(`Upserted: ${salon.name} -> ${customer.kundenummer}`);
        }
      } else {
        notFoundCount++;
        notFoundOrgs.push(normalizedOrg);
      }
    }

    console.log(`Import complete: ${matchedCount} matched, ${notFoundCount} not found, ${insertedCount} inserted`);

    return new Response(
      JSON.stringify({
        success: true,
        supplier: supplier.navn,
        total: customerData.length,
        matched: matchedCount,
        notFound: notFoundCount,
        inserted: insertedCount,
        notFoundOrgs: notFoundOrgs.slice(0, 20),
        errors: errors.slice(0, 10),
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: unknown) {
    console.error("Error in import:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 500 }
    );
  }
});
