import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const INGOODHANDS_SUPPLIER_ID = '94c74a35-9986-42a0-bbb6-e900650fdf6a';

interface CustomerMapping {
  org_number: string;
  customer_number: string;
  salon_name?: string;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { mappings } = await req.json() as { mappings: CustomerMapping[] };

    if (!mappings || !Array.isArray(mappings)) {
      return new Response(
        JSON.stringify({ error: 'Missing or invalid mappings array' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Processing ${mappings.length} InGoodHands customer mappings`);

    // Fetch all salons to create lookup map
    const { data: salons, error: salonsError } = await supabase
      .from('salons')
      .select('id, org_number, name');

    if (salonsError) {
      console.error('Error fetching salons:', salonsError);
      throw salonsError;
    }

    // Create lookup map by org_number
    const salonByOrgNumber = new Map<string, { id: string; name: string }>();
    for (const salon of salons || []) {
      if (salon.org_number) {
        salonByOrgNumber.set(salon.org_number, { id: salon.id, name: salon.name });
      }
    }

    // Fetch existing supplier_identifiers for InGoodHands to check duplicates
    const { data: existingIdentifiers, error: existingError } = await supabase
      .from('supplier_identifiers')
      .select('salon_id, supplier_customer_number')
      .eq('supplier_id', INGOODHANDS_SUPPLIER_ID);

    if (existingError) {
      console.error('Error fetching existing identifiers:', existingError);
      throw existingError;
    }

    const existingSet = new Set(
      (existingIdentifiers || []).map(ei => `${ei.salon_id}-${ei.supplier_customer_number}`)
    );

    const results = {
      inserted: [] as { salon_name: string; customer_number: string }[],
      not_found: [] as { org_number: string; customer_number: string; salon_name?: string }[],
      already_exists: [] as { salon_name: string; customer_number: string }[],
      errors: [] as { org_number: string; error: string }[]
    };

    for (const mapping of mappings) {
      const { org_number, customer_number, salon_name } = mapping;

      // Find salon by org_number
      const salon = salonByOrgNumber.get(org_number);

      if (!salon) {
        console.log(`Salon not found for org_number: ${org_number} (${salon_name || 'unknown'})`);
        results.not_found.push({ org_number, customer_number, salon_name });
        continue;
      }

      // Check if already exists
      const key = `${salon.id}-${customer_number}`;
      if (existingSet.has(key)) {
        console.log(`Identifier already exists for salon: ${salon.name}`);
        results.already_exists.push({ salon_name: salon.name, customer_number });
        continue;
      }

      // Insert new identifier
      const { error: insertError } = await supabase
        .from('supplier_identifiers')
        .insert({
          supplier_id: INGOODHANDS_SUPPLIER_ID,
          salon_id: salon.id,
          supplier_customer_number: customer_number,
          identifier_type: 'customer_number'
        });

      if (insertError) {
        console.error(`Error inserting identifier for ${salon.name}:`, insertError);
        results.errors.push({ org_number, error: insertError.message });
      } else {
        console.log(`Inserted identifier ${customer_number} for salon: ${salon.name}`);
        results.inserted.push({ salon_name: salon.name, customer_number });
        existingSet.add(key); // Prevent duplicates within same batch
      }
    }

    console.log(`Import complete: ${results.inserted.length} inserted, ${results.not_found.length} not found, ${results.already_exists.length} already exists, ${results.errors.length} errors`);

    return new Response(
      JSON.stringify({
        success: true,
        summary: {
          total: mappings.length,
          inserted: results.inserted.length,
          not_found: results.not_found.length,
          already_exists: results.already_exists.length,
          errors: results.errors.length
        },
        details: results
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in import-ingoodhands-customers:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
