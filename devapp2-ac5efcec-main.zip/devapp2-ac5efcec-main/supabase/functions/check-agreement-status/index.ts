import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const FIRMA_API_KEY = Deno.env.get('FIRMA_API_KEY');
const SUPABASE_URL = Deno.env.get('SUPABASE_URL');
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

interface SigningStatus {
  finished: boolean;
  cancelled: boolean;
  expired: boolean;
  signers: Array<{
    email: string;
    name: string;
    signed: boolean;
    signedAt?: string;
  }>;
}

async function getSigningStatus(requestId: string): Promise<SigningStatus | null> {
  try {
    const response = await fetch(`https://api.firma.dev/v1/signing-requests/${requestId}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${FIRMA_API_KEY}`,
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      console.error(`Failed to get signing status for ${requestId}: ${response.status}`);
      return null;
    }

    const data = await response.json();
    return {
      finished: data.status === 'COMPLETED' || data.status === 'completed',
      cancelled: data.status === 'CANCELLED' || data.status === 'cancelled',
      expired: data.status === 'EXPIRED' || data.status === 'expired',
      signers: data.signers || [],
    };
  } catch (error) {
    console.error(`Error getting signing status for ${requestId}:`, error);
    return null;
  }
}

async function downloadSignedDocument(requestId: string): Promise<Uint8Array | null> {
  try {
    const response = await fetch(`https://api.firma.dev/v1/signing-requests/${requestId}/signed-document`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${FIRMA_API_KEY}`,
      },
    });

    if (!response.ok) {
      console.error(`Failed to download signed document for ${requestId}: ${response.status}`);
      return null;
    }

    const arrayBuffer = await response.arrayBuffer();
    return new Uint8Array(arrayBuffer);
  } catch (error) {
    console.error(`Error downloading signed document for ${requestId}:`, error);
    return null;
  }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Starting agreement status check...');

    const supabase = createClient(SUPABASE_URL!, SUPABASE_SERVICE_ROLE_KEY!);

    // Fetch all drafts waiting for signature
    const { data: pendingDrafts, error: fetchError } = await supabase
      .from('innmelding_utkast')
      .select('*')
      .eq('status', 'venter_signering');

    if (fetchError) {
      console.error('Error fetching pending drafts:', fetchError);
      return new Response(JSON.stringify({ error: fetchError.message }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (!pendingDrafts || pendingDrafts.length === 0) {
      console.log('No pending agreements to check');
      return new Response(JSON.stringify({ message: 'No pending agreements', checked: 0 }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log(`Found ${pendingDrafts.length} pending agreements to check`);

    const results = [];

    for (const draft of pendingDrafts) {
      const wizardData = draft.wizard_data || {};
      const avtaleUrl = wizardData.avtale_url;

      if (!avtaleUrl) {
        console.log(`Draft ${draft.id} has no avtale_url, skipping`);
        continue;
      }

      // Extract signing request ID from URL
      // URL format: https://app.firma.dev/signing-requests/{id}
      const urlParts = avtaleUrl.split('/');
      const requestId = urlParts[urlParts.length - 1];

      if (!requestId) {
        console.log(`Could not extract request ID from ${avtaleUrl}`);
        continue;
      }

      console.log(`Checking status for draft ${draft.id}, request ${requestId}`);

      const status = await getSigningStatus(requestId);

      if (!status) {
        console.log(`Could not get status for request ${requestId}`);
        continue;
      }

      console.log(`Status for ${requestId}:`, status);

      if (status.finished) {
        console.log(`Agreement ${requestId} is finished/signed!`);

        // Download the signed PDF
        const signedPdf = await downloadSignedDocument(requestId);
        let signedPdfUrl = null;

        if (signedPdf) {
          // Upload to storage
          const fileName = `samarbeidsavtaler/${draft.org_nummer}_${Date.now()}.pdf`;
          
          const { data: uploadData, error: uploadError } = await supabase.storage
            .from('insurance-documents')
            .upload(fileName, signedPdf, {
              contentType: 'application/pdf',
              upsert: true,
            });

          if (uploadError) {
            console.error('Error uploading signed PDF:', uploadError);
          } else {
            const { data: urlData } = supabase.storage
              .from('insurance-documents')
              .getPublicUrl(fileName);
            
            signedPdfUrl = urlData?.publicUrl;
            console.log(`Signed PDF uploaded to: ${signedPdfUrl}`);
          }
        }

        // Update the draft
        const updatedWizardData = {
          ...wizardData,
          avtale_status: 'signert',
          signed_pdf_url: signedPdfUrl,
        };

        const { error: updateError } = await supabase
          .from('innmelding_utkast')
          .update({
            status: 'ferdig',
            avtale_status: 'signert',
            current_step: 7,
            agreement_signed_at: new Date().toISOString(),
            signed_pdf_url: signedPdfUrl,
            wizard_data: updatedWizardData,
          })
          .eq('id', draft.id);

        if (updateError) {
          console.error(`Error updating draft ${draft.id}:`, updateError);
        } else {
          console.log(`Draft ${draft.id} updated to ferdig/signert`);
          results.push({ id: draft.id, status: 'signert', signedPdfUrl });
        }

        // Also update the avtaler table if there's a linked agreement
        if (wizardData.avtale_id) {
          await supabase
            .from('avtaler')
            .update({
              signing_status: 'signert',
              signed_at: new Date().toISOString(),
              signed_pdf_url: signedPdfUrl,
            })
            .eq('id', wizardData.avtale_id);
        }

      } else if (status.cancelled) {
        console.log(`Agreement ${requestId} was cancelled`);

        const { error: updateError } = await supabase
          .from('innmelding_utkast')
          .update({
            status: 'utkast',
            avtale_status: 'avvist',
            wizard_data: { ...wizardData, avtale_status: 'avvist' },
          })
          .eq('id', draft.id);

        if (!updateError) {
          results.push({ id: draft.id, status: 'avvist' });
        }

      } else if (status.expired) {
        console.log(`Agreement ${requestId} has expired`);

        const { error: updateError } = await supabase
          .from('innmelding_utkast')
          .update({
            status: 'utkast',
            avtale_status: 'utlopt',
            wizard_data: { ...wizardData, avtale_status: 'utlopt' },
          })
          .eq('id', draft.id);

        if (!updateError) {
          results.push({ id: draft.id, status: 'utlopt' });
        }
      } else {
        console.log(`Agreement ${requestId} still pending`);
        results.push({ id: draft.id, status: 'venter' });
      }
    }

    console.log('Agreement status check completed', results);

    return new Response(JSON.stringify({ 
      message: 'Status check completed',
      checked: pendingDrafts.length,
      results 
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error: unknown) {
    console.error('Error in check-agreement-status:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
