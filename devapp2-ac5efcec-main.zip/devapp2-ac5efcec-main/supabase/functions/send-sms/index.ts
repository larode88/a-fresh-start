import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface SendSmsRequest {
  phone: string;
  message: string;
  messageType: string;
  userId?: string;
}

// Format phone number to E.164 format
function formatPhoneNumber(phone: string): string {
  // Remove all non-digit characters except leading +
  let cleaned = phone.replace(/[^\d+]/g, "");
  
  // If it starts with 00, replace with +
  if (cleaned.startsWith("00")) {
    cleaned = "+" + cleaned.substring(2);
  }
  
  // If no country code, assume Norwegian (+47)
  if (!cleaned.startsWith("+")) {
    // Remove leading 0 if present
    if (cleaned.startsWith("0")) {
      cleaned = cleaned.substring(1);
    }
    cleaned = "+47" + cleaned;
  }
  
  return cleaned;
}

// Get Sakari access token
async function getSakariAccessToken(): Promise<string> {
  const clientId = Deno.env.get("SAKARI_CLIENT_ID");
  const clientSecret = Deno.env.get("SAKARI_CLIENT_SECRET");
  
  if (!clientId || !clientSecret) {
    throw new Error("Sakari credentials not configured");
  }
  
  const response = await fetch("https://api.sakari.io/oauth2/token", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: new URLSearchParams({
      grant_type: "client_credentials",
      client_id: clientId,
      client_secret: clientSecret,
    }),
  });
  
  if (!response.ok) {
    const error = await response.text();
    console.error("Sakari auth error:", error);
    throw new Error("Failed to authenticate with Sakari");
  }
  
  const data = await response.json();
  return data.access_token;
}

// Send SMS via Sakari
async function sendSmsViaSakari(phone: string, message: string): Promise<{ messageId: string; status: string }> {
  const accountId = Deno.env.get("SAKARI_ACCOUNT_ID");
  
  if (!accountId) {
    throw new Error("SAKARI_ACCOUNT_ID not configured");
  }
  
  const accessToken = await getSakariAccessToken();
  const formattedPhone = formatPhoneNumber(phone);
  
  console.log(`Sending SMS to ${formattedPhone}`);
  
  const response = await fetch(`https://api.sakari.io/v1/accounts/${accountId}/messages`, {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      contacts: [{ mobile: { number: formattedPhone } }],
      template: message,
    }),
  });
  
  const responseData = await response.json();
  
  if (!response.ok) {
    console.error("Sakari send error:", responseData);
    throw new Error(responseData.error?.message || "Failed to send SMS via Sakari");
  }
  
  console.log("Sakari response:", responseData);
  
  // Extract message ID from response
  const messageId = responseData.data?.[0]?.id || responseData.id || "unknown";
  const status = responseData.data?.[0]?.status || "sent";
  
  return { messageId, status };
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }
  
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    
    const { phone, message, messageType, userId }: SendSmsRequest = await req.json();
    
    if (!phone || !message || !messageType) {
      return new Response(
        JSON.stringify({ error: "Missing required fields: phone, message, messageType" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    
    // Check if SMS is enabled in system settings
    const { data: settings } = await supabase
      .from("system_settings")
      .select("sms_enabled")
      .single();
    
    // Default to enabled if setting doesn't exist
    const smsEnabled = settings?.sms_enabled !== false;
    
    if (!smsEnabled) {
      console.log("SMS sending disabled in system settings");
      // Log but don't send
      await supabase.from("sms_log").insert({
        user_id: userId || null,
        phone_number: phone,
        message_type: messageType,
        message_preview: message.substring(0, 100),
        status: "disabled",
      });
      
      return new Response(
        JSON.stringify({ success: true, message: "SMS sending disabled", messageId: null }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    
    // Send SMS via Sakari
    const { messageId, status } = await sendSmsViaSakari(phone, message);
    
    // Log the SMS
    await supabase.from("sms_log").insert({
      user_id: userId || null,
      phone_number: phone,
      message_type: messageType,
      message_preview: message.substring(0, 100),
      sakari_message_id: messageId,
      status: status,
    });
    
    console.log(`SMS sent successfully to ${phone}, messageId: ${messageId}`);
    
    return new Response(
      JSON.stringify({ success: true, messageId, status }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
    
  } catch (error: unknown) {
    console.error("Error sending SMS:", error);
    const errorMessage = error instanceof Error ? error.message : "Failed to send SMS";
    
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
