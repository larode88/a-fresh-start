import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface RenderRequest {
  template_slug: string;
  variables?: Record<string, string>;
}

interface EmailModule {
  id: string;
  type: string;
  content: Record<string, unknown>;
  styles?: Record<string, unknown>;
}

interface EmailStructure {
  modules: EmailModule[];
}

const BASE_FONT = "'DM Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif";

// Replace tokens in text with variable values
function replaceTokens(text: string, variables: Record<string, string>): string {
  let result = text;
  for (const [key, value] of Object.entries(variables)) {
    const token = `{${key}}`;
    result = result.replace(new RegExp(token.replace(/[{}]/g, '\\$&'), 'g'), value || '');
  }
  return result;
}

// Helper to get background color with priority: content.backgroundColor > styles.backgroundColor > default
const getBgColor = (
  c: Record<string, unknown>,
  styles: Record<string, unknown>,
  defaultColor: string
): string => {
  if (c.backgroundColor && typeof c.backgroundColor === 'string' && c.backgroundColor !== '') {
    return c.backgroundColor;
  }
  if (styles.backgroundColor && typeof styles.backgroundColor === 'string' && styles.backgroundColor !== '') {
    return styles.backgroundColor as string;
  }
  return defaultColor;
};

// Generate HTML for a single module - MUST MATCH emailHtmlGenerator.ts exactly
function generateModuleHtml(module: EmailModule, variables: Record<string, string>): string {
  const { type, content, styles = {} } = module;

  // Replace tokens in content
  const processContent = (c: Record<string, unknown>): Record<string, unknown> => {
    const processed: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(c)) {
      if (typeof value === 'string') {
        processed[key] = replaceTokens(value, variables);
      } else if (Array.isArray(value)) {
        processed[key] = value.map(item => 
          typeof item === 'string' ? replaceTokens(item, variables) : item
        );
      } else if (typeof value === 'object' && value !== null) {
        processed[key] = processContent(value as Record<string, unknown>);
      } else {
        processed[key] = value;
      }
    }
    return processed;
  };

  const c = processContent(content);

  switch (type) {
    case "header-logo":
    case "header-portalen":
      return `
        <tr>
          <td style="background-color: ${getBgColor(c, styles, '#FAF8F5')}; padding: ${styles.padding || '32px'}; text-align: center;">
            <img src="${c.logoUrl}" alt="${c.logoAlt || 'Logo'}" style="max-height: 60px;" />
          </td>
        </tr>
      `;

    case "text":
      // Support both content.content and content.text for backward compatibility
      const textContent = (c.content || c.text || '') as string;
      const textColor = styles.color || '#3D3D3D';
      const textBgColor = getBgColor(c, styles, 'transparent');
      return `
        <tr>
          <td style="padding: ${styles.padding || '24px 32px'}; font-family: ${BASE_FONT}; font-size: 16px; line-height: 1.6; color: ${textColor}; text-align: ${styles.textAlign || 'left'}; background-color: ${textBgColor};">
            ${textContent}
          </td>
        </tr>
      `;

    case "heading":
      const headingSize = c.level === 'h1' ? '28px' : c.level === 'h3' ? '18px' : c.size === 'large' ? '24px' : c.size === 'small' ? '16px' : '22px';
      const headingColor = styles.color || c.color || '#8B7355';
      const headingBgColor = getBgColor(c, styles, 'transparent');
      return `
        <tr>
          <td style="padding: ${styles.padding || '24px 32px 8px 32px'}; font-family: ${BASE_FONT}; font-size: ${headingSize}; font-weight: 600; line-height: 1.4; color: ${headingColor}; text-align: ${styles.textAlign || 'left'}; background-color: ${headingBgColor};">
            ${c.text || ''}
          </td>
        </tr>
      `;

    case "cta-button":
      const ctaBgColor = getBgColor(c, styles, 'transparent');
      return `
        <tr>
          <td style="padding: ${styles.padding || '16px 32px'}; text-align: center; background-color: ${ctaBgColor};">
            <a href="${c.url || '#'}" style="display: inline-block; padding: 14px 32px; background: linear-gradient(135deg, #8B7355 0%, #6B5440 100%); color: #FFFFFF; text-decoration: none; border-radius: 8px; font-weight: 600; font-size: 16px; font-family: ${BASE_FONT};">
              ${c.text || 'Klikk her'}
            </a>
          </td>
        </tr>
      `;

    case "info-box":
      // Support both content.content and content.text for backward compatibility
      const infoBoxContent = (c.content || c.text || '') as string;
      return `
        <tr>
          <td style="padding: ${styles.margin || '16px 32px'};">
            <table width="100%" cellpadding="0" cellspacing="0" style="background: linear-gradient(135deg, #FAF7F2 0%, #F5EEE6 100%); border-radius: 12px;">
              <tr>
                <td style="padding: ${styles.padding || '24px'};">
                  ${c.title ? `<h3 style="margin: 0 0 12px 0; font-weight: 600; font-size: 18px; color: #3D3D3D; font-family: ${BASE_FONT};">${c.title}</h3>` : ''}
                  <div style="font-family: ${BASE_FONT}; font-size: 15px; line-height: 1.6; color: #3D3D3D;">
                    ${infoBoxContent}
                  </div>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      `;

    case "success-banner":
      return `
        <tr>
          <td style="padding: ${styles.margin || '16px 32px'};">
            <table width="100%" cellpadding="0" cellspacing="0" style="background: linear-gradient(135deg, #E8F5E9 0%, #C8E6C9 100%); border-radius: 12px;">
              <tr>
                <td style="padding: 24px; text-align: center;">
                  <div style="font-size: 48px; margin-bottom: 12px;">${c.emoji || '🎉'}</div>
                  <div style="font-family: ${BASE_FONT}; font-size: 20px; font-weight: 600; color: #2E7D32;">
                    ${c.text || 'Vellykket!'}
                  </div>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      `;

    case "warning-banner":
      return `
        <tr>
          <td style="padding: ${styles.margin || '16px 32px'};">
            <table width="100%" cellpadding="0" cellspacing="0" style="background: #FFF8E7; border: 1px solid #F0C36D; border-radius: 8px;">
              <tr>
                <td style="padding: 16px;">
                  <div style="font-family: ${BASE_FONT}; font-weight: 600; color: #8B6914;">
                    ⚠️ ${c.text || 'Obs!'}
                  </div>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      `;

    case "benefits-list":
      const items = (c.items as string[]) || [];
      const listItems = items.map((item: string) => `
        <tr>
          <td style="padding: 6px 0; font-family: ${BASE_FONT}; font-size: 16px; color: #5A5A5A;">
            <span style="color: #4CAF50; font-weight: bold; margin-right: 12px;">✓</span>
            ${item}
          </td>
        </tr>
      `).join('');
      return `
        <tr>
          <td style="padding: ${styles.margin || '16px 32px'};">
            <table width="100%" cellpadding="0" cellspacing="0" style="background: linear-gradient(135deg, #FAF7F2 0%, #F5EEE6 100%); border-radius: 12px;">
              <tr>
                <td style="padding: ${styles.padding || '24px'};">
                  ${c.title ? `<h3 style="margin: 0 0 16px 0; font-weight: 600; font-size: 18px; color: #8B7355; font-family: ${BASE_FONT};">${c.title}</h3>` : ''}
                  <table width="100%" cellpadding="0" cellspacing="0">
                    ${listItems}
                  </table>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      `;

    case "product-table":
      const headers = (c.headers as string[]) || ["Produkt", "Antall", "Pris"];
      const rows = (c.rows as string[][]) || [];
      const showTotal = c.showTotal !== false;
      const totalLabel = (c.totalLabel as string) || "Total";
      const totalValue = (c.totalValue as string) || "";

      const headerCells = headers.map((h: string, i: number) => `
        <th style="padding: 14px 16px; text-align: ${i === 0 ? 'left' : 'right'}; font-weight: 600; font-size: 14px; color: #FFFFFF; font-family: ${BASE_FONT}; ${i === 0 ? 'border-radius: 8px 0 0 0;' : ''} ${i === headers.length - 1 ? 'border-radius: 0 8px 0 0;' : ''}">
          ${h}
        </th>
      `).join('');
      
      const rowsHtml = rows.length === 0 
        ? `<tr><td colspan="${headers.length}" style="padding: 24px; text-align: center; color: #8B8B8B;">Ingen produkter</td></tr>`
        : rows.map((row: string[]) => `
            <tr>
              ${row.map((cell, i) => `
                <td style="padding: 14px 16px; text-align: ${i === 0 ? 'left' : 'right'}; border-bottom: 1px solid #E8E0D8; color: #4A4A4A; font-family: ${BASE_FONT};">
                  ${cell}
                </td>
              `).join('')}
            </tr>
          `).join('');

      const totalRow = showTotal && totalValue ? `
        <tr style="background: linear-gradient(135deg, #8B7355 0%, #6B5440 100%);">
          <td colspan="${headers.length - 1}" style="padding: 16px; color: #FFFFFF; font-weight: 600; border-radius: 0 0 0 8px; font-family: ${BASE_FONT};">${totalLabel}</td>
          <td style="padding: 16px; text-align: right; color: #FFFFFF; font-weight: 700; font-size: 18px; border-radius: 0 0 8px 0; font-family: ${BASE_FONT};">${totalValue}</td>
        </tr>
      ` : '';

      return `
        <tr>
          <td style="padding: ${styles.margin || '16px 32px'};">
            <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse: collapse;">
              <tr style="background: #8B7355;">${headerCells}</tr>
              ${rowsHtml}
              ${totalRow}
            </table>
          </td>
        </tr>
      `;

    case "note-box":
      return `
        <tr>
          <td style="padding: ${styles.margin || '16px 32px'};">
            <table width="100%" cellpadding="0" cellspacing="0" style="background: #F8F9FA; border-left: 4px solid #8B7355; border-radius: 0 8px 8px 0;">
              <tr>
                <td style="padding: 16px 20px;">
                  ${c.title ? `<p style="margin: 0 0 8px 0; font-weight: 600; color: #8B7355; font-size: 14px; font-family: ${BASE_FONT};">${c.icon || '💬'} ${c.title}</p>` : ''}
                  <p style="margin: 0; color: #5A5A5A; font-style: italic; font-family: ${BASE_FONT};">${c.content || ''}</p>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      `;

    case "footer-signature":
      const contact = c.contact as Record<string, string> | undefined;
      const footerBgColor = getBgColor(c, styles, '#FAF8F5');
      return `
        <tr>
          <td style="background-color: ${footerBgColor}; padding: ${styles.padding || '32px'}; text-align: center; border-top: 1px solid #E8E0D5;">
            <div style="font-family: ${BASE_FONT}; font-size: 16px; line-height: 1.6; color: #3D3D3D; margin-bottom: 16px;">
              ${c.signature || 'Med vennlig hilsen,<br><strong>Hår1-teamet</strong>'}
            </div>
            ${contact ? `
              <div style="font-size: 14px; color: #6B6B6B; font-family: ${BASE_FONT};">
                ${contact.phone ? `<p style="margin: 4px 0;">📞 ${contact.phone}</p>` : ''}
                ${contact.email ? `<p style="margin: 4px 0;">✉️ <a href="mailto:${contact.email}" style="color: #8B7355; text-decoration: none;">${contact.email}</a></p>` : ''}
                ${contact.website ? `<p style="margin: 4px 0;">🌐 ${contact.website}</p>` : ''}
              </div>
            ` : ''}
          </td>
        </tr>
      `;

    case "footer-disclaimer":
      return `
        <tr>
          <td style="font-size: 12px; color: #8B8B8B; padding: ${styles.padding || '16px 32px'}; text-align: center; font-family: ${BASE_FONT};">
            ${c.text || 'Denne e-posten er sendt fra Hår1.'}
          </td>
        </tr>
      `;

    case "separator":
      return `
        <tr>
          <td style="padding: ${styles.margin || '16px 32px'};">
            <hr style="border: none; border-top: 1px ${c.style || 'solid'} ${c.color || '#E8E0D5'}; margin: 0;" />
          </td>
        </tr>
      `;

    case "spacer":
      return `
        <tr>
          <td style="height: ${c.height || '24px'};"></td>
        </tr>
      `;

    case "image":
      const imageBgColor = getBgColor(c, styles, 'transparent');
      return `
        <tr>
          <td style="padding: ${styles.padding || '16px 32px'}; text-align: center; background-color: ${imageBgColor};">
            ${c.src 
              ? `<img src="${c.src}" alt="${c.alt || ''}" style="max-width: ${c.width || '100%'}; height: auto;" />`
              : ''
            }
          </td>
        </tr>
      `;

    case "two-columns":
      const left = c.left as Record<string, string> | undefined;
      const right = c.right as Record<string, string> | undefined;
      return `
        <tr>
          <td style="padding: ${styles.padding || '16px 32px'};">
            <table width="100%" cellpadding="0" cellspacing="0">
              <tr>
                <td width="50%" valign="top" style="padding-right: 8px; font-family: ${BASE_FONT};">
                  ${left?.content || ''}
                </td>
                <td width="50%" valign="top" style="padding-left: 8px; font-family: ${BASE_FONT};">
                  ${right?.content || ''}
                </td>
              </tr>
            </table>
          </td>
        </tr>
      `;

    case "otp-box":
      return `
        <tr>
          <td style="padding: ${styles.padding || '24px 32px'}; text-align: center;">
            <table cellpadding="0" cellspacing="0" style="margin: 0 auto; background: linear-gradient(135deg, #FAF7F2 0%, #F5EEE6 100%); border-radius: 16px;">
              <tr>
                <td style="padding: 32px;">
                  <p style="margin: 0 0 12px 0; font-size: 14px; color: #8B7355; font-weight: 500; text-transform: uppercase; letter-spacing: 1px; font-family: ${BASE_FONT};">
                    ${c.label || 'Din engangskode'}
                  </p>
                  <p style="margin: 16px 0; font-size: 42px; font-weight: 700; letter-spacing: 12px; color: #3D3D3D; font-family: monospace;">
                    ${c.code || '------'}
                  </p>
                  <p style="margin: 16px 0 0 0; font-size: 14px; color: #888; font-family: ${BASE_FONT};">
                    Koden er gyldig i ${c.expiryMinutes || 10} minutter
                  </p>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      `;

    case "agreement-box":
      return `
        <tr>
          <td style="padding: ${styles.padding || '16px 32px'};">
            <table width="100%" cellpadding="0" cellspacing="0" style="background: #F8F9FA; border: 2px dashed #E5E7EB; border-radius: 12px;">
              <tr>
                <td style="padding: 24px; text-align: center;">
                  <p style="margin: 0 0 8px 0; font-size: 13px; color: #6B7280; text-transform: uppercase; letter-spacing: 1px; font-family: ${BASE_FONT};">${c.label || 'Avtalenummer'}</p>
                  <p style="margin: 0; font-size: 32px; font-weight: 700; color: #3D3D3D; font-family: monospace; letter-spacing: 2px;">${c.value || ''}</p>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      `;

    case "date-highlight":
      return `
        <tr>
          <td style="padding: ${styles.margin || '16px 32px'};">
            <table width="100%" cellpadding="0" cellspacing="0" style="background: linear-gradient(135deg, #FEF3C7 0%, #FDE68A 100%); border-radius: 12px;">
              <tr>
                <td style="padding: 20px; text-align: center;">
                  <p style="margin: 0 0 4px 0; font-size: 14px; color: #92400E; font-weight: 500; font-family: ${BASE_FONT};">${c.label || ''}</p>
                  <p style="margin: 0; font-size: 24px; font-weight: 700; color: #78350F; font-family: ${BASE_FONT};">${c.date || ''}</p>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      `;

    case "salon-info":
      return `
        <tr>
          <td style="padding: ${styles.margin || '16px 32px'};">
            <table width="100%" cellpadding="0" cellspacing="0" style="background: #FAF7F2; border-radius: 8px;">
              <tr>
                <td style="padding: 20px;">
                  ${c.salonName ? `<p style="margin: 0 0 8px 0; font-family: ${BASE_FONT};"><strong>Salongnavn:</strong> ${c.salonName}</p>` : ''}
                  ${c.orgNumber ? `<p style="margin: 0 0 8px 0; font-family: ${BASE_FONT};"><strong>Org.nummer:</strong> ${c.orgNumber}</p>` : ''}
                  ${c.contactName ? `<p style="margin: 0 0 8px 0; font-family: ${BASE_FONT};"><strong>Kontaktperson:</strong> ${c.contactName}</p>` : ''}
                  ${c.email ? `<p style="margin: 0 0 8px 0; font-family: ${BASE_FONT};"><strong>E-post:</strong> ${c.email}</p>` : ''}
                  ${c.phone ? `<p style="margin: 0; font-family: ${BASE_FONT};"><strong>Telefon:</strong> ${c.phone}</p>` : ''}
                </td>
              </tr>
            </table>
          </td>
        </tr>
      `;

    default:
      return '';
  }
}

// Generate full email HTML
function generateEmailHtml(structure: EmailStructure, variables: Record<string, string>): string {
  const modulesHtml = structure.modules.map(m => generateModuleHtml(m, variables)).join('');
  
  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>E-post</title>
</head>
<body style="margin: 0; padding: 0; background-color: #FAF8F5; font-family: 'DM Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #FAF8F5;">
    <tr>
      <td align="center" style="padding: 20px;">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #FFFFFF; max-width: 600px; border-radius: 16px; box-shadow: 0 4px 24px rgba(139, 115, 85, 0.08);">
          ${modulesHtml || '<tr><td style="padding: 48px; text-align: center; color: #8B8B8B;">Ingen innhold</td></tr>'}
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
  `;
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { template_slug, variables = {} }: RenderRequest = await req.json();

    if (!template_slug) {
      return new Response(
        JSON.stringify({ error: "template_slug is required" }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    console.log(`Rendering email template: ${template_slug}`);

    // Fetch template by slug
    const { data: template, error: templateError } = await supabase
      .from("email_templates")
      .select("*")
      .eq("slug", template_slug)
      .eq("status", "published")
      .single();

    if (templateError || !template) {
      console.error("Template not found:", templateError);
      return new Response(
        JSON.stringify({ error: "Template not found or not published", slug: template_slug }),
        { status: 404, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const structure = template.structure as EmailStructure;
    const subjectTemplate = template.subject_template || "";

    // Generate HTML
    const html = generateEmailHtml(structure, variables);
    const subject = replaceTokens(subjectTemplate, variables);

    console.log(`Template rendered successfully: ${template_slug}`);

    return new Response(
      JSON.stringify({ 
        html, 
        subject,
        template_id: template.id,
        template_name: template.name
      }),
      { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    console.error("Error rendering template:", errorMessage);
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );
  }
};

serve(handler);
