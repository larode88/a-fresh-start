import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const VERDANT_SUPPLIER_ID = 'ae4c8e52-35ea-4dbb-910e-26289cf9c482';

interface CustomerMapping {
  org_number: string;
  customer_number: string;
  company_name?: string;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { mappings } = await req.json() as { mappings: CustomerMapping[] };

    if (!mappings || !Array.isArray(mappings)) {
      return new Response(
        JSON.stringify({ error: 'Missing or invalid mappings array' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Processing ${mappings.length} customer mappings for Verdant`);

    // Fetch all salons with org_number
    const { data: salons, error: salonsError } = await supabase
      .from('salons')
      .select('id, org_number, name');

    if (salonsError) {
      console.error('Error fetching salons:', salonsError);
      throw salonsError;
    }

    // Create lookup map by org_number
    const salonsByOrgNumber = new Map<string, { id: string; name: string }>();
    salons?.forEach(salon => {
      if (salon.org_number) {
        // Normalize org number (remove spaces)
        const normalizedOrg = salon.org_number.replace(/\s/g, '');
        salonsByOrgNumber.set(normalizedOrg, { id: salon.id, name: salon.name });
      }
    });

    console.log(`Found ${salonsByOrgNumber.size} salons with org numbers`);

    // Check existing supplier_identifiers for Verdant to avoid duplicates
    const { data: existingIdentifiers } = await supabase
      .from('supplier_identifiers')
      .select('salon_id, supplier_customer_number')
      .eq('supplier_id', VERDANT_SUPPLIER_ID);

    const existingSalonIds = new Set(existingIdentifiers?.map(i => i.salon_id) || []);
    const existingCustomerNumbers = new Set(existingIdentifiers?.map(i => i.supplier_customer_number) || []);

    console.log(`Found ${existingSalonIds.size} existing Verdant identifiers`);

    const results = {
      inserted: [] as { org_number: string; customer_number: string; salon_name: string }[],
      not_found: [] as { org_number: string; customer_number: string; company_name?: string }[],
      already_exists: [] as { org_number: string; customer_number: string; salon_name: string }[],
      errors: [] as { org_number: string; customer_number: string; error: string }[]
    };

    // Process each mapping
    for (const mapping of mappings) {
      const normalizedOrg = mapping.org_number.replace(/\s/g, '');
      const salon = salonsByOrgNumber.get(normalizedOrg);

      if (!salon) {
        results.not_found.push({
          org_number: mapping.org_number,
          customer_number: mapping.customer_number,
          company_name: mapping.company_name
        });
        continue;
      }

      // Check if already exists
      if (existingSalonIds.has(salon.id) || existingCustomerNumbers.has(mapping.customer_number)) {
        results.already_exists.push({
          org_number: mapping.org_number,
          customer_number: mapping.customer_number,
          salon_name: salon.name
        });
        continue;
      }

      // Insert new identifier
      const { error: insertError } = await supabase
        .from('supplier_identifiers')
        .insert({
          supplier_id: VERDANT_SUPPLIER_ID,
          salon_id: salon.id,
          supplier_customer_number: mapping.customer_number,
          identifier_type: 'customer_number'
        });

      if (insertError) {
        console.error(`Error inserting identifier for ${mapping.org_number}:`, insertError);
        results.errors.push({
          org_number: mapping.org_number,
          customer_number: mapping.customer_number,
          error: insertError.message
        });
      } else {
        results.inserted.push({
          org_number: mapping.org_number,
          customer_number: mapping.customer_number,
          salon_name: salon.name
        });
        // Add to sets to prevent duplicate insertions in same batch
        existingSalonIds.add(salon.id);
        existingCustomerNumbers.add(mapping.customer_number);
      }
    }

    console.log(`Import complete: ${results.inserted.length} inserted, ${results.not_found.length} not found, ${results.already_exists.length} already exists, ${results.errors.length} errors`);

    return new Response(
      JSON.stringify({
        success: true,
        summary: {
          total_processed: mappings.length,
          inserted: results.inserted.length,
          not_found: results.not_found.length,
          already_exists: results.already_exists.length,
          errors: results.errors.length
        },
        details: results
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in import-verdant-customers:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
