import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "https://esm.sh/resend@2.0.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface ReviewNotificationRequest {
  action: "invitation" | "reminder" | "summary";
  review_id: string;
}

const REVIEW_TYPE_LABELS: Record<string, string> = {
  medarbeidersamtale: "Medarbeidersamtale",
  oppfolging: "Oppfølgingssamtale",
  utviklingssamtale: "Utviklingssamtale",
  lonnssamtale: "Lønnssamtale",
  annet: "Samtale",
};

const LOCATION_LABELS: Record<string, string> = {
  fysisk: "Fysisk møte",
  teams: "Microsoft Teams",
  zoom: "Zoom",
  telefon: "Telefon",
};

const formatDate = (dateStr: string): string => {
  const date = new Date(dateStr);
  return date.toLocaleDateString("nb-NO", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
};

const generateInvitationEmail = (
  employeeName: string,
  reviewerName: string,
  reviewType: string,
  date: string,
  location: string
): string => {
  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; background-color: #faf8f5; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #faf8f5; padding: 40px 20px;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 16px; box-shadow: 0 4px 24px rgba(0,0,0,0.08);">
          <tr>
            <td style="background: linear-gradient(135deg, #8B7355 0%, #6B5440 100%); padding: 32px; border-radius: 16px 16px 0 0; text-align: center;">
              <img src="https://asaiahiimtsazwbekako.supabase.co/storage/v1/object/public/email-assets/haar1-logo-white.png" alt="Hår1" height="40" style="height: 40px;">
              <h1 style="color: #ffffff; font-size: 22px; margin: 16px 0 0 0; font-weight: 500;">Invitasjon til samtale</h1>
            </td>
          </tr>
          <tr>
            <td style="padding: 40px;">
              <p style="color: #2d2d2d; font-size: 16px; line-height: 1.6; margin: 0 0 24px 0;">
                Hei ${employeeName},
              </p>
              <p style="color: #2d2d2d; font-size: 16px; line-height: 1.6; margin: 0 0 24px 0;">
                Du er invitert til en <strong>${REVIEW_TYPE_LABELS[reviewType] || reviewType}</strong> med ${reviewerName}.
              </p>
              
              <table width="100%" cellpadding="0" cellspacing="0" style="background: linear-gradient(180deg, #FAF7F2 0%, #F5EEE6 100%); border-radius: 12px; padding: 24px; margin-bottom: 24px;">
                <tr>
                  <td>
                    <table width="100%" cellpadding="0" cellspacing="0">
                      <tr>
                        <td style="padding: 8px 0;">
                          <strong style="color: #6B5440;">Dato:</strong>
                          <span style="color: #2d2d2d; margin-left: 12px;">${formatDate(date)}</span>
                        </td>
                      </tr>
                      <tr>
                        <td style="padding: 8px 0;">
                          <strong style="color: #6B5440;">Sted:</strong>
                          <span style="color: #2d2d2d; margin-left: 12px;">${LOCATION_LABELS[location] || location}</span>
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
              
              <p style="color: #666666; font-size: 14px; line-height: 1.6; margin: 0 0 24px 0;">
                Vennligst bekreft oppmøte eller ta kontakt dersom tidspunktet ikke passer.
              </p>
              
              <p style="color: #2d2d2d; font-size: 16px; line-height: 1.6; margin: 32px 0 0 0;">
                Med vennlig hilsen,<br>
                <strong>${reviewerName}</strong>
              </p>
            </td>
          </tr>
          <tr>
            <td style="background-color: #f8f5f1; padding: 24px; border-radius: 0 0 16px 16px; text-align: center;">
              <p style="color: #888888; font-size: 12px; margin: 0;">
                © ${new Date().getFullYear()} Hår1 Portalen
              </p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
};

const generateReminderEmail = (
  employeeName: string,
  reviewerName: string,
  reviewType: string,
  date: string,
  location: string,
  daysUntil: number
): string => {
  const urgency = daysUntil === 1 ? "i morgen" : `om ${daysUntil} dager`;
  
  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; background-color: #faf8f5; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #faf8f5; padding: 40px 20px;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 16px; box-shadow: 0 4px 24px rgba(0,0,0,0.08);">
          <tr>
            <td style="background: linear-gradient(135deg, #d4a574 0%, #c49660 100%); padding: 32px; border-radius: 16px 16px 0 0; text-align: center;">
              <img src="https://asaiahiimtsazwbekako.supabase.co/storage/v1/object/public/email-assets/haar1-logo-white.png" alt="Hår1" height="40" style="height: 40px;">
              <h1 style="color: #ffffff; font-size: 22px; margin: 16px 0 0 0; font-weight: 500;">Påminnelse: Samtale ${urgency}</h1>
            </td>
          </tr>
          <tr>
            <td style="padding: 40px;">
              <p style="color: #2d2d2d; font-size: 16px; line-height: 1.6; margin: 0 0 24px 0;">
                Hei ${employeeName},
              </p>
              <p style="color: #2d2d2d; font-size: 16px; line-height: 1.6; margin: 0 0 24px 0;">
                Dette er en påminnelse om din kommende <strong>${REVIEW_TYPE_LABELS[reviewType] || reviewType}</strong>.
              </p>
              
              <table width="100%" cellpadding="0" cellspacing="0" style="background: linear-gradient(180deg, #FFF9E6 0%, #FFF3CC 100%); border-radius: 12px; padding: 24px; margin-bottom: 24px; border-left: 4px solid #d4a574;">
                <tr>
                  <td>
                    <table width="100%" cellpadding="0" cellspacing="0">
                      <tr>
                        <td style="padding: 8px 0;">
                          <strong style="color: #8B6914;">📅 Dato:</strong>
                          <span style="color: #2d2d2d; margin-left: 12px;">${formatDate(date)}</span>
                        </td>
                      </tr>
                      <tr>
                        <td style="padding: 8px 0;">
                          <strong style="color: #8B6914;">📍 Sted:</strong>
                          <span style="color: #2d2d2d; margin-left: 12px;">${LOCATION_LABELS[location] || location}</span>
                        </td>
                      </tr>
                      <tr>
                        <td style="padding: 8px 0;">
                          <strong style="color: #8B6914;">👤 Med:</strong>
                          <span style="color: #2d2d2d; margin-left: 12px;">${reviewerName}</span>
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
              
              <p style="color: #2d2d2d; font-size: 16px; line-height: 1.6; margin: 32px 0 0 0;">
                Vi sees!<br>
                <strong>Hår1 Portalen</strong>
              </p>
            </td>
          </tr>
          <tr>
            <td style="background-color: #f8f5f1; padding: 24px; border-radius: 0 0 16px 16px; text-align: center;">
              <p style="color: #888888; font-size: 12px; margin: 0;">
                © ${new Date().getFullYear()} Hår1 Portalen
              </p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
};

const generateSummaryEmail = (
  employeeName: string,
  reviewerName: string,
  reviewType: string,
  date: string,
  summary: string,
  actions: { tittel: string; frist: string | null }[]
): string => {
  const actionsList = actions.length > 0 
    ? actions.map(a => `<li style="padding: 8px 0;">${a.tittel}${a.frist ? ` <span style="color: #888;">(frist: ${formatDate(a.frist)})</span>` : ''}</li>`).join('')
    : '<li style="padding: 8px 0; color: #888;">Ingen tiltak registrert</li>';

  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; background-color: #faf8f5; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #faf8f5; padding: 40px 20px;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 16px; box-shadow: 0 4px 24px rgba(0,0,0,0.08);">
          <tr>
            <td style="background: linear-gradient(135deg, #4a9e6b 0%, #3d8759 100%); padding: 32px; border-radius: 16px 16px 0 0; text-align: center;">
              <img src="https://asaiahiimtsazwbekako.supabase.co/storage/v1/object/public/email-assets/haar1-logo-white.png" alt="Hår1" height="40" style="height: 40px;">
              <h1 style="color: #ffffff; font-size: 22px; margin: 16px 0 0 0; font-weight: 500;">Sammendrag: ${REVIEW_TYPE_LABELS[reviewType] || reviewType}</h1>
            </td>
          </tr>
          <tr>
            <td style="padding: 40px;">
              <p style="color: #2d2d2d; font-size: 16px; line-height: 1.6; margin: 0 0 24px 0;">
                Hei ${employeeName},
              </p>
              <p style="color: #2d2d2d; font-size: 16px; line-height: 1.6; margin: 0 0 24px 0;">
                Takk for samtalen ${formatDate(date)}. Her er et sammendrag av det vi snakket om.
              </p>
              
              ${summary ? `
              <table width="100%" cellpadding="0" cellspacing="0" style="background: linear-gradient(180deg, #FAF7F2 0%, #F5EEE6 100%); border-radius: 12px; padding: 24px; margin-bottom: 24px;">
                <tr>
                  <td>
                    <strong style="color: #6B5440; display: block; margin-bottom: 12px;">Oppsummering:</strong>
                    <p style="color: #2d2d2d; font-size: 14px; line-height: 1.6; margin: 0;">${summary}</p>
                  </td>
                </tr>
              </table>
              ` : ''}
              
              <table width="100%" cellpadding="0" cellspacing="0" style="background: linear-gradient(180deg, #E8F5E9 0%, #C8E6C9 100%); border-radius: 12px; padding: 24px; margin-bottom: 24px;">
                <tr>
                  <td>
                    <strong style="color: #2E7D32; display: block; margin-bottom: 12px;">✅ Avtalte tiltak:</strong>
                    <ul style="color: #2d2d2d; font-size: 14px; line-height: 1.6; margin: 0; padding-left: 20px;">
                      ${actionsList}
                    </ul>
                  </td>
                </tr>
              </table>
              
              <p style="color: #666666; font-size: 14px; line-height: 1.6; margin: 0 0 24px 0;">
                Du kan se alle dine utviklingsplaner og mål i Hår1 Portalen.
              </p>
              
              <p style="color: #2d2d2d; font-size: 16px; line-height: 1.6; margin: 32px 0 0 0;">
                Med vennlig hilsen,<br>
                <strong>${reviewerName}</strong>
              </p>
            </td>
          </tr>
          <tr>
            <td style="background-color: #f8f5f1; padding: 24px; border-radius: 0 0 16px 16px; text-align: center;">
              <p style="color: #888888; font-size: 12px; margin: 0;">
                © ${new Date().getFullYear()} Hår1 Portalen
              </p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
};

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Check if email is enabled
    const { data: settingsData } = await supabase
      .from("system_settings")
      .select("value")
      .eq("key", "email_enabled")
      .single();

    const emailEnabled = settingsData?.value === true || settingsData?.value === "true";
    if (!emailEnabled) {
      console.log("Email sending is disabled in system settings");
      return new Response(JSON.stringify({ success: true, message: "Email disabled" }), {
        status: 200,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });
    }

    const { action, review_id }: ReviewNotificationRequest = await req.json();
    console.log(`Processing ${action} notification for review ${review_id}`);

    // Fetch review details
    const { data: review, error: reviewError } = await supabase
      .from("ansatt_samtaler")
      .select("*")
      .eq("id", review_id)
      .single();

    if (reviewError || !review) {
      console.error("Review not found:", reviewError);
      return new Response(JSON.stringify({ error: "Review not found" }), {
        status: 404,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });
    }

    // Fetch employee and reviewer info
    const { data: employee } = await supabase
      .from("users")
      .select("id, name, email")
      .eq("id", review.user_id)
      .single();

    const { data: reviewer } = await supabase
      .from("users")
      .select("id, name, email")
      .eq("id", review.utfort_av)
      .single();

    if (!employee?.email) {
      console.error("Employee email not found");
      return new Response(JSON.stringify({ error: "Employee email not found" }), {
        status: 400,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });
    }

    let subject: string;
    let html: string;

    if (action === "invitation") {
      subject = `Invitasjon: ${REVIEW_TYPE_LABELS[review.samtale_type] || review.samtale_type} - ${formatDate(review.dato)}`;
      html = generateInvitationEmail(
        employee.name,
        reviewer?.name || "Din leder",
        review.samtale_type,
        review.dato,
        review.sted || "fysisk"
      );
    } else if (action === "reminder") {
      const reviewDate = new Date(review.dato);
      const today = new Date();
      const daysUntil = Math.ceil((reviewDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
      
      subject = `Påminnelse: ${REVIEW_TYPE_LABELS[review.samtale_type] || review.samtale_type} ${daysUntil === 1 ? "i morgen" : `om ${daysUntil} dager`}`;
      html = generateReminderEmail(
        employee.name,
        reviewer?.name || "Din leder",
        review.samtale_type,
        review.dato,
        review.sted || "fysisk",
        daysUntil
      );
    } else if (action === "summary") {
      // Fetch development plans created from this review
      const { data: plans } = await supabase
        .from("ansatt_utviklingsplan")
        .select("tittel, frist")
        .eq("samtale_id", review_id);

      subject = `Sammendrag: ${REVIEW_TYPE_LABELS[review.samtale_type] || review.samtale_type} - ${formatDate(review.dato)}`;
      html = generateSummaryEmail(
        employee.name,
        reviewer?.name || "Din leder",
        review.samtale_type,
        review.dato,
        review.sammendrag || "",
        plans || []
      );
    } else {
      return new Response(JSON.stringify({ error: "Invalid action" }), {
        status: 400,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      });
    }

    // Send email
    const emailResponse = await resend.emails.send({
      from: "Hår1 Portalen <noreply@har1.no>",
      to: [employee.email],
      subject,
      html,
    });

    console.log("Email sent successfully:", emailResponse);

    return new Response(JSON.stringify({ success: true, emailId: emailResponse.data?.id }), {
      status: 200,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });

  } catch (error: any) {
    console.error("Error in send-review-notification:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  }
};

serve(handler);
