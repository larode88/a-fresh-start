import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { Resend } from "https://esm.sh/resend@2.0.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface SendOtpRequest {
  phone?: string;
  email?: string;
  type: "login" | "password_reset" | "signup";
}

// Generate 6-digit OTP
function generateOtp(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// Hash OTP using SHA-256
async function hashOtp(otp: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(otp);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
}

// Format phone number to E.164 format
function formatPhoneNumber(phone: string): string {
  let cleaned = phone.replace(/[^\d+]/g, "");
  if (cleaned.startsWith("00")) {
    cleaned = "+" + cleaned.substring(2);
  }
  if (!cleaned.startsWith("+")) {
    if (cleaned.startsWith("0")) {
      cleaned = cleaned.substring(1);
    }
    cleaned = "+47" + cleaned;
  }
  return cleaned;
}

// Extract just the digits from a phone number (last 8 digits for Norwegian numbers)
function getNorwegianNumber(phone: string): string {
  const digits = phone.replace(/\D/g, "");
  // Norwegian numbers are 8 digits, remove country code if present
  if (digits.length > 8) {
    return digits.slice(-8);
  }
  return digits;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }
  
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    
    const { phone, email, type }: SendOtpRequest = await req.json();
    
    if (!phone && !email) {
      return new Response(
        JSON.stringify({ error: "Telefonnummer eller e-post er påkrevd" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    
    // Determine if this is email or phone OTP
    const isEmail = !!email && !phone;
    const contactIdentifier = isEmail ? email.toLowerCase().trim() : formatPhoneNumber(phone!);
    
    // Rate limiting: Check attempts in last hour
    const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000).toISOString();
    const rateLimitQuery = isEmail 
      ? supabase.from("auth_otp").select("*", { count: "exact", head: true }).eq("email", contactIdentifier).gte("created_at", oneHourAgo)
      : supabase.from("auth_otp").select("*", { count: "exact", head: true }).eq("phone_number", contactIdentifier).gte("created_at", oneHourAgo);
    
    const { count } = await rateLimitQuery;
    
    if (count && count >= 5) {
      return new Response(
        JSON.stringify({ error: "For mange forsøk. Prøv igjen om en time." }),
        { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    
    // For login/password_reset, verify user exists
    if (type === "login" || type === "password_reset") {
      if (isEmail) {
        // Look up user by email
        const { data: user, error: userError } = await supabase
          .from("users")
          .select("id, email")
          .eq("email", contactIdentifier)
          .single();
        
        if (userError || !user) {
          console.log(`No user found with email ${contactIdentifier}`);
          return new Response(
            JSON.stringify({ error: "Ingen bruker funnet med denne e-postadressen" }),
            { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        
        console.log(`Found user: ${user.id} with email: ${user.email}`);
      } else {
        // Look up user by phone via ansatte table
        const norwegianNumber = getNorwegianNumber(contactIdentifier);
        console.log(`Looking up phone: ${contactIdentifier}, norwegian number: ${norwegianNumber}`);
        
        const { data: ansatteWithPhone, error: lookupError } = await supabase
          .from("ansatte")
          .select("id, user_id, telefon")
          .not("user_id", "is", null)
          .not("telefon", "is", null);
        
        if (lookupError) {
          console.error("Error looking up ansatte:", lookupError);
          throw new Error("Kunne ikke søke etter bruker");
        }
        
        const matchingAnsatt = ansatteWithPhone?.find(a => {
          const ansattNumber = getNorwegianNumber(a.telefon);
          return ansattNumber === norwegianNumber;
        });
        
        if (!matchingAnsatt) {
          console.log(`No user found with phone ${norwegianNumber}`);
          return new Response(
            JSON.stringify({ error: "Ingen bruker funnet med dette telefonnummeret" }),
            { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        
        console.log(`Found ansatt: ${matchingAnsatt.id} with user_id: ${matchingAnsatt.user_id}`);
      }
    }
    
    // Generate OTP
    const otp = generateOtp();
    const otpHash = await hashOtp(otp);
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes
    
    // Delete old OTPs for this contact
    if (isEmail) {
      await supabase.from("auth_otp").delete().eq("email", contactIdentifier);
    } else {
      await supabase.from("auth_otp").delete().eq("phone_number", contactIdentifier);
    }
    
    // Store new OTP
    const insertData = isEmail 
      ? { email: contactIdentifier, otp_hash: otpHash, expires_at: expiresAt.toISOString() }
      : { phone_number: contactIdentifier, otp_hash: otpHash, expires_at: expiresAt.toISOString() };
    
    const { error: insertError } = await supabase.from("auth_otp").insert(insertData);
    
    if (insertError) {
      console.error("Error storing OTP:", insertError);
      throw new Error("Kunne ikke opprette engangskode");
    }
    
    // Send OTP via email or SMS
    if (isEmail) {
      // Send via Resend
      const resendApiKey = Deno.env.get("RESEND_API_KEY");
      if (!resendApiKey) {
        console.error("RESEND_API_KEY not configured");
        throw new Error("E-posttjenesten er ikke konfigurert");
      }
      
      const resend = new Resend(resendApiKey);
      
      const emailHtml = `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
        </head>
        <body style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; background-color: #f9f7f4; margin: 0; padding: 40px 20px;">
          <div style="max-width: 480px; margin: 0 auto; background-color: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.08);">
            <div style="background-color: #1a1a1a; padding: 32px; text-align: center;">
              <img src="https://portal.har1.no/haar1-logo-white.png" alt="Hår1" style="height: 40px; width: auto;">
            </div>
            <div style="padding: 40px 32px; text-align: center;">
              <h1 style="color: #1a1a1a; font-size: 24px; font-weight: 600; margin: 0 0 16px 0;">Din engangskode</h1>
              <p style="color: #666666; font-size: 16px; line-height: 1.5; margin: 0 0 32px 0;">
                Bruk koden nedenfor for å logge inn på Hår1 Portalen.
              </p>
              <div style="background-color: #f9f7f4; border-radius: 12px; padding: 24px; margin-bottom: 32px;">
                <span style="font-family: 'Monaco', 'Consolas', monospace; font-size: 36px; font-weight: 700; letter-spacing: 8px; color: #1a1a1a;">${otp}</span>
              </div>
              <p style="color: #999999; font-size: 14px; margin: 0;">
                Koden er gyldig i 10 minutter.
              </p>
            </div>
            <div style="background-color: #f9f7f4; padding: 24px 32px; text-align: center;">
              <p style="color: #999999; font-size: 12px; margin: 0;">
                Hvis du ikke ba om denne koden, kan du trygt ignorere denne e-posten.
              </p>
            </div>
          </div>
        </body>
        </html>
      `;
      
      const { error: emailError } = await resend.emails.send({
        from: "Hår1 Portalen <noreply@har1.no>",
        to: [contactIdentifier],
        subject: `Din engangskode: ${otp}`,
        html: emailHtml,
      });
      
      if (emailError) {
        console.error("Error sending email:", emailError);
        throw new Error("Kunne ikke sende e-post");
      }
      
      console.log(`OTP sent via email to ${contactIdentifier} for ${type}`);
    } else {
      // Send via SMS
      const templateSlug = type === "password_reset" ? "password-reset" : "auth-otp";
      const { data: template } = await supabase
        .from("sms_templates")
        .select("body_template")
        .eq("slug", templateSlug)
        .single();
      
      const messageTemplate = template?.body_template || 
        "Din kode for Hår1 Portalen: {otp}. Koden utløper om 10 minutter.";
      
      const message = messageTemplate.replace("{otp}", otp);
      
      const { error: smsError } = await supabase.functions.invoke("send-sms", {
        body: {
          phone: contactIdentifier,
          message,
          messageType: type === "password_reset" ? "password_reset" : "auth_otp",
        },
      });
      
      if (smsError) {
        console.error("Error sending SMS:", smsError);
        throw new Error("Kunne ikke sende SMS");
      }
      
      console.log(`OTP sent via SMS to ${contactIdentifier} for ${type}`);
    }
    
    return new Response(
      JSON.stringify({ 
        success: true, 
        message: isEmail ? "Engangskode sendt til e-posten din" : "Engangskode sendt til telefonen din",
        expiresAt: expiresAt.toISOString(),
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
    
  } catch (error: unknown) {
    console.error("Error in send-auth-otp:", error);
    const errorMessage = error instanceof Error ? error.message : "Kunne ikke sende engangskode";
    
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
