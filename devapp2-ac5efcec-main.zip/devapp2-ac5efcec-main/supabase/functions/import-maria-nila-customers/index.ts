import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const MARIA_NILA_SUPPLIER_ID = 'fc773f13-16df-4eb6-8760-a4d82c7abed7';

// Complete list of Maria Nila customers with their customer numbers and org numbers
const customerData = [
  { kundenummer: 'N999145736', org: '999145736' },
  { kundenummer: 'N998900522', org: '998900522' },
  { kundenummer: 'N998536782', org: '998536782' },
  { kundenummer: 'N998288819', org: '998288819' },
  { kundenummer: 'N996562794', org: '996562794' },
  { kundenummer: 'N995390051', org: '995390051' },
  { kundenummer: 'N995354020', org: '995354020' },
  { kundenummer: 'N994480936', org: '994480936' },
  { kundenummer: 'N993863823', org: '993863823' },
  { kundenummer: 'N992927887', org: '992927887' },
  { kundenummer: 'N992691336', org: '992691336' },
  { kundenummer: 'NO991442499', org: '991442499' },
  { kundenummer: 'N989886800', org: '989886800' },
  { kundenummer: 'N988613398', org: '988613398' },
  { kundenummer: 'N984940440', org: '984940440' },
  { kundenummer: 'NO984475144', org: '984475144' },
  { kundenummer: '984234724', org: '984234724' },
  { kundenummer: 'N984062516', org: '984062516' },
  { kundenummer: 'N980363376', org: '980363376' },
  { kundenummer: 'N977558344', org: '977558344' },
  { kundenummer: 'N977377714', org: '977377714' },
  { kundenummer: 'N976188284', org: '976188284' },
  { kundenummer: 'NO974430355', org: '974430355' },
  { kundenummer: 'N971193573', org: '971193573' },
  { kundenummer: 'NO958075979', org: '958075979' },
  { kundenummer: 'N946473766', org: '946473766' },
  { kundenummer: 'N940033500', org: '940033500' },
  { kundenummer: 'NO935619874', org: '935619874' },
  { kundenummer: 'NO933221337', org: '933221337' },
  { kundenummer: 'N932593610', org: '932593610' },
  { kundenummer: 'N931851411', org: '931851411' },
  { kundenummer: 'NO931432044', org: '931432044' },
  { kundenummer: 'NO931313274', org: '931313274' },
  { kundenummer: 'N930353205', org: '930353205' },
  { kundenummer: 'N929391020', org: '929391020' },
  { kundenummer: 'N927196689', org: '927196689' },
  { kundenummer: 'N927077744', org: '927077744' },
  { kundenummer: 'N926732749', org: '926732749' },
  { kundenummer: 'N925178934', org: '925178934' },
  { kundenummer: 'N924358890', org: '924358890' },
  { kundenummer: 'N922622598', org: '922622598' },
  { kundenummer: 'NO921887981', org: '921887981' },
  { kundenummer: 'NO920973140', org: '920973140' },
  { kundenummer: 'NO920459854', org: '920459854' },
  { kundenummer: 'N920342205', org: '920342205' },
  { kundenummer: 'N920051103', org: '920051103' },
  { kundenummer: 'N919294256', org: '919294256' },
  { kundenummer: 'N918817182', org: '918817182' },
  { kundenummer: 'NO917010609', org: '917010609' },
  { kundenummer: 'N916331614', org: '916331614' },
  { kundenummer: 'N915922880', org: '915922880' },
  { kundenummer: 'N915519970', org: '915519970' },
  { kundenummer: 'NO915319483', org: '915319483' },
  { kundenummer: 'NO912341100', org: '912341100' },
  { kundenummer: 'NO912256308', org: '912256308' },
  { kundenummer: 'N885923992', org: '885923992' },
  { kundenummer: 'N881711192', org: '881711192' },
  { kundenummer: 'N873191732', org: '873191732' },
  { kundenummer: 'N823807252', org: '823807252' },
  { kundenummer: 'N819165742', org: '819165742' },
  { kundenummer: '812450352', org: '812450352' },
  { kundenummer: 'NOC1000392', org: '925573388' },
  { kundenummer: 'NOC1000364', org: '985506140' },
  { kundenummer: 'NOC1000360', org: '933085570' },
  { kundenummer: 'NOC1000264', org: '973192302' },
  { kundenummer: 'NOC1000166', org: '976792246' },
  { kundenummer: 'NOC1000388', org: '982785944' },
  { kundenummer: 'NOC1000397', org: '922103887' },
  { kundenummer: 'NOC1000365', org: '989348809' },
  { kundenummer: 'NOC1000306', org: '912341127' },
  { kundenummer: 'NOC1000393', org: '993294756' },
  { kundenummer: 'N92608611', org: '926086111' },
  { kundenummer: 'NOC1000326', org: '998508576' },
  { kundenummer: 'NOC1000177', org: '988357677' },
  { kundenummer: 'NOC1000010', org: '993812102' },
  { kundenummer: 'NOC1000438', org: '920459854' },
  { kundenummer: 'N98876424', org: '988764248' },
];

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    console.log(`Starting Maria Nila customer import. Total customers: ${customerData.length}`);

    // Fetch all salons
    const { data: salons, error: salonsError } = await supabase
      .from('salons')
      .select('id, name, org_number');

    if (salonsError) {
      throw new Error(`Failed to fetch salons: ${salonsError.message}`);
    }

    // Create mapping from org_number to salon
    const salonMap = new Map<string, { id: string; name: string }>();
    for (const salon of salons || []) {
      if (salon.org_number) {
        const normalizedOrg = salon.org_number.replace(/\D/g, '');
        salonMap.set(normalizedOrg, { id: salon.id, name: salon.name });
      }
    }

    console.log(`Loaded ${salonMap.size} salons with org numbers`);

    let matched = 0;
    let notFound = 0;
    let inserted = 0;
    const notFoundList: string[] = [];
    const errors: string[] = [];

    for (const customer of customerData) {
      const normalizedOrg = customer.org.replace(/\D/g, '');
      const salon = salonMap.get(normalizedOrg);

      if (!salon) {
        notFound++;
        notFoundList.push(`${customer.kundenummer} (org: ${customer.org})`);
        continue;
      }

      matched++;

      // Upsert to supplier_identifiers
      const { error: upsertError } = await supabase
        .from('supplier_identifiers')
        .upsert({
          supplier_id: MARIA_NILA_SUPPLIER_ID,
          salon_id: salon.id,
          supplier_customer_number: customer.kundenummer,
          identifier_type: 'maria_nila_kundenr',
        }, {
          onConflict: 'supplier_id,salon_id,identifier_type',
        });

      if (upsertError) {
        errors.push(`Error for ${customer.kundenummer}: ${upsertError.message}`);
      } else {
        inserted++;
      }
    }

    console.log(`Import complete. Matched: ${matched}, Not found: ${notFound}, Inserted: ${inserted}`);
    if (notFoundList.length > 0) {
      console.log('Not found:', notFoundList);
    }

    return new Response(JSON.stringify({
      success: true,
      total: customerData.length,
      matched,
      notFoundCount: notFound,
      inserted,
      notFound: notFoundList,
      errors: errors.length > 0 ? errors : undefined,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Import error:', error);
    return new Response(JSON.stringify({
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error',
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
