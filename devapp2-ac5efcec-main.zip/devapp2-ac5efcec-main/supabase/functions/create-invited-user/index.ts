import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

interface CreateInvitedUserRequest {
  invitation_id: string;
  email: string;
  first_name: string;
  last_name: string;
  phone: string;
  avatar_url?: string;
  role: string;
  salon_id?: string;
  district_id?: string;
  supplier_id?: string;
  hubspot_contact_id?: string;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const body: CreateInvitedUserRequest = await req.json();
    const { 
      invitation_id,
      email, 
      first_name, 
      last_name, 
      phone, 
      avatar_url,
      role,
      salon_id,
      district_id,
      supplier_id,
      hubspot_contact_id,
    } = body;

    console.log(`Creating user for invitation ${invitation_id} with email ${email}`);

    // Validate required fields
    if (!invitation_id || !email || !first_name || !last_name || !role) {
      return new Response(JSON.stringify({ error: "Missing required fields" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const fullName = `${first_name} ${last_name}`;

    // Check if user already exists
    const { data: existingAuthUser } = await supabase.auth.admin.listUsers();
    const existingUser = existingAuthUser?.users?.find(u => u.email?.toLowerCase() === email.toLowerCase());

    let userId: string;

    if (existingUser) {
      userId = existingUser.id;
      console.log(`User already exists with id ${userId}`);
    } else {
      // Create user in auth.users using Admin API
      // Generate a random password (user will use OTP to log in, never this password)
      const randomPassword = crypto.randomUUID() + crypto.randomUUID();

      const { data: authUser, error: authError } = await supabase.auth.admin.createUser({
        email,
        password: randomPassword,
        email_confirm: true,
        user_metadata: {
          name: fullName,
          first_name,
          last_name,
        },
      });

      if (authError) {
        console.error("Error creating auth user:", authError);
        return new Response(JSON.stringify({ error: authError.message }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      userId = authUser.user.id;
      console.log(`Created auth user ${userId}`);
    }

    // Upsert user profile in users table
    const userData: Record<string, any> = {
      id: userId,
      email,
      first_name,
      last_name,
      name: fullName,
      phone,
      role,
      salon_id: salon_id || null,
      district_id: district_id || null,
      gdpr_consent_given_at: new Date().toISOString(),
      gdpr_consent_source: 'onboarding',
    };
    
    if (avatar_url) {
      userData.avatar_url = avatar_url;
    }
    if (hubspot_contact_id) {
      userData.hubspot_contact_id = hubspot_contact_id;
    }

    const { error: upsertError } = await supabase
      .from("users")
      .upsert(userData as any, { onConflict: "id" });

    if (upsertError) {
      console.error("Error upserting user:", upsertError);
      return new Response(JSON.stringify({ error: "Failed to create user profile" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Create or update user_roles entry using SECURITY DEFINER function
    const { error: roleError } = await supabase
      .rpc("create_user_role_for_onboarding", {
        p_user_id: userId,
        p_role: role,
      });

    if (roleError) {
      console.error("Error creating role:", roleError);
    }

    // Map role to lederstilling for ansatte
    const mapRoleToLederstilling = (r: string): string | null => {
      switch (r) {
        case 'admin': return 'daglig_leder';
        case 'salon_owner': return 'styreleder';
        case 'daglig_leder': return 'daglig_leder';
        case 'avdelingsleder': return 'avdelingsleder';
        case 'district_manager': return 'avdelingsleder';
        default: return null;
      }
    };

    // Create ansatte record for HR system (if salon_id is present)
    if (salon_id) {
      const { error: ansatteError } = await supabase
        .from("ansatte")
        .insert({
          user_id: userId,
          fornavn: first_name,
          etternavn: last_name,
          epost: email,
          telefon: phone,
          salong_id: salon_id,
          status: 'Aktiv',
          stillingsprosent: 100,
          lederstilling: mapRoleToLederstilling(role),
          profilbilde_url: avatar_url || null,
        } as any);

      if (ansatteError) {
        console.error("Error creating ansatte record:", ansatteError);
        // Don't fail - user profile still works
      }
    }

    // Handle supplier roles
    if (supplier_id && ['supplier_admin', 'supplier_sales', 'supplier_business_dev'].includes(role)) {
      const { error: supplierError } = await supabase
        .from("supplier_team_users")
        .upsert({
          user_id: userId,
          supplier_id,
          role: role as any,
        }, { onConflict: "user_id,supplier_id" });

      if (supplierError) {
        console.error("Error creating supplier_team_users:", supplierError);
      }
    }

    // Mark invitation as accepted
    const { error: inviteError } = await supabase
      .from("invitations")
      .update({ accepted: true, accepted_at: new Date().toISOString() })
      .eq("id", invitation_id);

    if (inviteError) {
      console.error("Error marking invitation accepted:", inviteError);
    }

    console.log(`Successfully created user ${userId} for invitation ${invitation_id}`);

    return new Response(JSON.stringify({
      success: true,
      user_id: userId,
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error: any) {
    console.error("Error in create-invited-user:", error);
    return new Response(JSON.stringify({ error: error?.message || String(error) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
