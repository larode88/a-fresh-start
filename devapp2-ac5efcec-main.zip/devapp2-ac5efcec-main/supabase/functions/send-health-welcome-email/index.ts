import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";
import { Resend } from "https://esm.sh/resend@2.0.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface EmployeeEmailData {
  userId: string;
  avtalenummer: string;
  oppstartsdato: string;
}

interface RequestBody {
  employees: EmployeeEmailData[];
}

// Try to render email from database template via render-email-template function
async function tryRenderFromTemplate(
  supabaseUrl: string,
  supabaseServiceKey: string,
  templateSlug: string,
  variables: Record<string, string>
): Promise<{ html: string; subject: string } | null> {
  try {
    const response = await fetch(`${supabaseUrl}/functions/v1/render-email-template`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${supabaseServiceKey}`,
      },
      body: JSON.stringify({
        template_slug: templateSlug,
        variables
      }),
    });

    if (response.ok) {
      const data = await response.json();
      if (data.html && data.subject) {
        console.log(`Successfully rendered template: ${templateSlug}`);
        return { html: data.html, subject: data.subject };
      }
    }
    console.log(`Template ${templateSlug} not found or rendering failed, using fallback`);
    return null;
  } catch (error) {
    console.error(`Error rendering template ${templateSlug}:`, error);
    return null;
  }
}

// Fallback HTML generator - tighter, cleaner design
function generateWelcomeEmailHtml(firstName: string, avtalenummer: string, oppstartsdato: string, logoUrl: string): string {
  return `
<!DOCTYPE html>
<html lang="no">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Velkommen til Hår1 Helseforsikring</title>
</head>
<body style="font-family: 'DM Sans', 'Segoe UI', Arial, sans-serif; line-height: 1.6; color: #3D3D3D; margin: 0; padding: 0; background-color: #FAF8F5;">
  <div style="max-width: 580px; margin: 0 auto; padding: 32px 16px;">
    
    <!-- Logo Header -->
    <div style="text-align: center; margin-bottom: 24px;">
      <img src="${logoUrl}" alt="Hår1 Forsikring" style="max-height: 50px; width: auto;" />
    </div>
    
    <!-- Main Content Card -->
    <div style="background: #FFFFFF; border-radius: 16px; padding: 32px 28px; box-shadow: 0 4px 20px rgba(139, 115, 85, 0.06);">
      
      <!-- Welcome Banner -->
      <div style="background: linear-gradient(135deg, #E8F5E9 0%, #C8E6C9 100%); border-radius: 12px; padding: 24px; margin-bottom: 24px; text-align: center;">
        <div style="font-size: 40px; margin-bottom: 8px;">🎉</div>
        <h2 style="color: #2E7D32; margin: 0; font-size: 20px; font-weight: 600;">Velkommen til Hår1 Helseforsikring!</h2>
      </div>
      
      <p style="font-size: 17px; margin: 0 0 12px 0;">Kjære ${firstName} 👋</p>
      
      <p style="margin: 0 0 20px 0; color: #5A5A5A; font-size: 15px;">
        Vi er glade for at du har valgt Hår1 Helseforsikring hos ERGO! Du har nå tilgang til en forsikring som gir deg trygghet og rask tilgang til medisinsk behandling når du trenger det.
      </p>
      
      <!-- Start Date Highlight -->
      <div style="background: linear-gradient(135deg, #FEF3C7 0%, #FDE68A 100%); border-radius: 12px; padding: 16px 20px; margin: 20px 0; text-align: center;">
        <p style="margin: 0 0 2px 0; font-size: 13px; color: #92400E; font-weight: 500;">Oppstart for forsikringen</p>
        <p style="margin: 0; font-size: 22px; font-weight: 700; color: #78350F;">${oppstartsdato}</p>
      </div>
      
      <!-- Coverage List -->
      <div style="background: linear-gradient(135deg, #FAF7F2 0%, #F5EEE6 100%); border-radius: 12px; padding: 20px; margin: 20px 0;">
        <p style="margin: 0 0 12px 0; font-weight: 600; color: #8B7355; font-size: 15px;">Forsikringen din dekker blant annet:</p>
        <p style="margin: 0; color: #5A5A5A; line-height: 1.9; font-size: 14px;">
          ✓ Operasjoner og dagkirurgi<br/>
          ✓ Sykehusinnleggelse<br/>
          ✓ Behandling hos legespesialist<br/>
          ✓ Kreftbehandling<br/>
          ✓ Psykologisk førstehjelp (12 behandlingstimer)<br/>
          ✓ Fysikalsk behandling (12 timer, egenandel 250 kr)
        </p>
      </div>
      
      <!-- How to Use Section -->
      <h3 style="color: #3D3D3D; font-weight: 600; margin: 24px 0 12px 0; font-size: 15px;">Slik bruker du forsikringen</h3>
      
      <p style="margin: 0 0 16px 0; color: #5A5A5A; font-size: 14px;">
        📲 <strong>Last ned BliFrisk-appen</strong> på <a href="https://blifrisk.no/last-ned" style="color: #8B7355;">blifrisk.no/last-ned</a> for å få rask tilgang til helsetjenester, bestille behandling og se oversikt over forsikringen din.
      </p>
      
      <!-- Agreement Number Box -->
      <div style="background: #FAFAFA; border: 2px dashed #D1D5DB; border-radius: 12px; padding: 20px; margin: 20px 0; text-align: center;">
        <p style="margin: 0 0 6px 0; font-size: 12px; color: #6B7280; text-transform: uppercase; letter-spacing: 0.5px;">Ditt avtalenummer (bruk ved registrering)</p>
        <p style="margin: 0; font-size: 28px; font-weight: 700; color: #374151; font-family: monospace; letter-spacing: 2px;">${avtalenummer}</p>
      </div>
      
      <p style="margin: 20px 0 0 0; color: #5A5A5A; font-size: 14px;">
        Takk for at du valgte Hår1 Helseforsikring – vi er her for deg!
      </p>
      
    </div>
    
    <!-- Footer -->
    <div style="text-align: center; margin-top: 24px; padding: 20px; color: #6B5440;">
      <p style="margin: 0 0 2px 0; font-size: 14px;">Med varm hilsen,</p>
      <p style="margin: 0; font-weight: 600; color: #8B7355; font-size: 15px;">Hår1-teamet</p>
      <p style="margin: 14px 0 0 0; font-size: 13px; color: #888;">
        📞 +47 4000 3345<br/>
        ✉️ <a href="mailto:forsikring@har1.no" style="color: #8B7355; text-decoration: none;">forsikring@har1.no</a><br/>
        🌐 <a href="https://www.har1.no" style="color: #8B7355; text-decoration: none;">www.har1.no</a>
      </p>
    </div>
    
  </div>
</body>
</html>
  `;
}

const handler = async (req: Request): Promise<Response> => {
  console.log("send-health-welcome-email function called");

  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const resendApiKey = Deno.env.get("RESEND_API_KEY");
    
    // Use production URL for logo
    const logoUrl = "https://portal.har1.no/haar1-forsikring-email-logo.png";

    if (!resendApiKey) {
      console.error("RESEND_API_KEY not configured");
      return new Response(
        JSON.stringify({ error: "Email service not configured" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const supabase = createClient(supabaseUrl, supabaseKey);
    const resend = new Resend(resendApiKey);

    // Check if email is enabled
    const { data: settings } = await supabase
      .from("system_settings")
      .select("value")
      .eq("key", "email_enabled")
      .single();

    const emailEnabled = settings?.value === true || settings?.value === "true";
    
    if (!emailEnabled) {
      console.log("Email sending is disabled in system settings");
      return new Response(
        JSON.stringify({ success: true, message: "Email disabled - skipped", sent: 0 }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const { employees }: RequestBody = await req.json();
    console.log(`Processing ${employees.length} employees for welcome emails`);

    let successCount = 0;
    let errorCount = 0;

    for (const emp of employees) {
      // Fetch employee details
      const { data: user, error: userError } = await supabase
        .from("users")
        .select("email, first_name, name")
        .eq("id", emp.userId)
        .single();

      if (userError || !user?.email) {
        console.error(`Failed to fetch user ${emp.userId}:`, userError);
        errorCount++;
        continue;
      }

      const firstName = user.first_name || user.name?.split(" ")[0] || "Kollega";

      // Try database template first
      const templateResult = await tryRenderFromTemplate(
        supabaseUrl,
        supabaseKey,
        'health-insurance-welcome',
        {
          fornavn: firstName,
          avtalenummer: emp.avtalenummer,
          oppstartsdato: emp.oppstartsdato,
          logoUrl: logoUrl,
        }
      );

      let emailHtml: string;
      let subject: string;

      if (templateResult) {
        emailHtml = templateResult.html;
        subject = templateResult.subject;
      } else {
        // Fallback to hardcoded HTML
        emailHtml = generateWelcomeEmailHtml(firstName, emp.avtalenummer, emp.oppstartsdato, logoUrl);
        subject = "Velkommen til Hår1 Helseforsikring 🎉";
      }

      try {
        const { error: sendError } = await resend.emails.send({
          from: "Hår1 Forsikring <forsikring@har1.no>",
          to: [user.email],
          subject: subject,
          html: emailHtml,
        });

        if (sendError) {
          console.error(`Failed to send email to ${user.email}:`, sendError);
          errorCount++;
        } else {
          console.log(`Welcome email sent successfully to: ${user.email}`);
          successCount++;
        }
      } catch (sendErr) {
        console.error(`Error sending email to ${user.email}:`, sendErr);
        errorCount++;
      }
    }

    console.log(`Email sending complete. Success: ${successCount}, Errors: ${errorCount}`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        sent: successCount, 
        errors: errorCount 
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );

  } catch (error: any) {
    console.error("Error in send-health-welcome-email:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
};

serve(handler);
