import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// L'Oréal supplier ID
const LOREAL_SUPPLIER_ID = "ba0636af-39df-4a0b-9792-79a3784f3970";

// Data from user's list - ONLY entries with L'Oréal customer number (column 5)
// org = Organisasjonsnummer (column 2)
// loreal_kundenummer = Kundenummer L'Oréal (column 5) - this is what L'Oréal sales files use
const customerData = [
  { org: "984913710", loreal_kundenummer: "43736" },
  { org: "885094732", loreal_kundenummer: "52678" },
  { org: "917446636", loreal_kundenummer: "9000269206" },
  { org: "994266799", loreal_kundenummer: "9000156096" },
  { org: "928703878", loreal_kundenummer: "9000229541" },
  { org: "917317690", loreal_kundenummer: "350099" },
  { org: "915218326", loreal_kundenummer: "310076" },
  { org: "899002962", loreal_kundenummer: "288597" },
  { org: "933944174", loreal_kundenummer: "9000254165" },
  { org: "997031830", loreal_kundenummer: "254710" },
  { org: "970348115", loreal_kundenummer: "26551" },
  { org: "998037980", loreal_kundenummer: "353231" },
  { org: "915066704", loreal_kundenummer: "314316" },
  { org: "929973321", loreal_kundenummer: "9000236830" },
  { org: "934181115", loreal_kundenummer: "9000260481" },
  { org: "990841977", loreal_kundenummer: "232457" },
  { org: "936120121", loreal_kundenummer: "26639" },
  { org: "923959335", loreal_kundenummer: "9000229019" },
  { org: "933183483", loreal_kundenummer: "9000246472" },
  { org: "989397516", loreal_kundenummer: "71293" },
  { org: "917825300", loreal_kundenummer: "352551" },
  { org: "916266928", loreal_kundenummer: "316149" },
  { org: "912827313", loreal_kundenummer: "296814" },
  { org: "976792246", loreal_kundenummer: "9000137376" },
  { org: "992691336", loreal_kundenummer: "69398" },
  { org: "971193573", loreal_kundenummer: "244593" },
  { org: "981873858", loreal_kundenummer: "37738" },
  { org: "984940440", loreal_kundenummer: "43801" },
  { org: "990163340", loreal_kundenummer: "71896" },
  { org: "997603540", loreal_kundenummer: "286564" },
  { org: "992101725", loreal_kundenummer: "68540" },
  { org: "977674093", loreal_kundenummer: "26764" },
  { org: "887944482", loreal_kundenummer: "26766" },
  { org: "996772772", loreal_kundenummer: "39545" },
  { org: "927452820", loreal_kundenummer: "9000229065" },
  { org: "812450352", loreal_kundenummer: "295226" },
  { org: "920051103", loreal_kundenummer: "9000088610" },
  { org: "991418415", loreal_kundenummer: "9000199854" },
  { org: "947091336", loreal_kundenummer: "26823" },
  { org: "999615112", loreal_kundenummer: "308868" },
  { org: "918004289", loreal_kundenummer: "9000156954" },
  { org: "928764125", loreal_kundenummer: "9000219650" },
  { org: "923808388", loreal_kundenummer: "9000132925" },
  { org: "817409822", loreal_kundenummer: "351406" },
  { org: "923029737", loreal_kundenummer: "9000136887" },
  { org: "996274624", loreal_kundenummer: "246491" },
  { org: "928620301", loreal_kundenummer: "9000199794" },
  { org: "914836123", loreal_kundenummer: "319453" },
  { org: "890827292", loreal_kundenummer: "295577" },
  { org: "925573388", loreal_kundenummer: "9000153866" },
  { org: "970113053", loreal_kundenummer: "80066" },
  { org: "998936845", loreal_kundenummer: "288796" },
  { org: "891174292", loreal_kundenummer: "65001" },
  { org: "918515585", loreal_kundenummer: "27871" },
  { org: "893042652", loreal_kundenummer: "70152" },
  { org: "825243542", loreal_kundenummer: "9000182267" },
  { org: "988419141", loreal_kundenummer: "296164" },
  { org: "924358890", loreal_kundenummer: "9000229926" },
  { org: "970312285", loreal_kundenummer: "9000154568" }, // FRANDSEN ANN - Avdeling 1
  { org: "979877463", loreal_kundenummer: "26913" },
  { org: "915491987", loreal_kundenummer: "312102" },
  { org: "829776782", loreal_kundenummer: "9000229020" },
  { org: "988613398", loreal_kundenummer: "307369" },
  { org: "832918962", loreal_kundenummer: "9000151740" },
  { org: "989594915", loreal_kundenummer: "27076" },
  { org: "965075097", loreal_kundenummer: "27094" },
  { org: "920233260", loreal_kundenummer: "9000115407" },
  { org: "994480936", loreal_kundenummer: "71492" },
  { org: "928899829", loreal_kundenummer: "9000230234" },
  { org: "927163047", loreal_kundenummer: "9000186945" },
  { org: "927281600", loreal_kundenummer: "9000116589" },
  { org: "934513045", loreal_kundenummer: "9000267368" },
  { org: "988946737", loreal_kundenummer: "grasdal" }, // Note: This appears to be invalid
  { org: "984234724", loreal_kundenummer: "66035" },
  { org: "813221322", loreal_kundenummer: "297611" },
  { org: "976483839", loreal_kundenummer: "27196" },
  { org: "981466586", loreal_kundenummer: "27198" },
  { org: "988764248", loreal_kundenummer: "59250" },
  { org: "983431631", loreal_kundenummer: "27199" },
  { org: "981514319", loreal_kundenummer: "9000155767" },
  { org: "915004067", loreal_kundenummer: "316808" },
  { org: "920342205", loreal_kundenummer: "9000178232" },
  { org: "979798482", loreal_kundenummer: "80335" },
  { org: "953333651", loreal_kundenummer: "9000266456" },
  { org: "976053605", loreal_kundenummer: "44061" },
  { org: "920197167", loreal_kundenummer: "9000139061" },
  { org: "917973075", loreal_kundenummer: "357479" },
  { org: "997198409", loreal_kundenummer: "306013" },
  { org: "925611050", loreal_kundenummer: "9000179119" },
  { org: "927196689", loreal_kundenummer: "9000186954" },
  { org: "930353205", loreal_kundenummer: "9000231649" },
  { org: "995354020", loreal_kundenummer: "234491" },
  { org: "928715027", loreal_kundenummer: "9000219353" },
  { org: "916562047", loreal_kundenummer: "314015" },
  { org: "913307887", loreal_kundenummer: "9000075439" },
  { org: "926317059", loreal_kundenummer: "363803" },
  { org: "989572679", loreal_kundenummer: "60556" },
  { org: "994494368", loreal_kundenummer: "285587" },
  { org: "996405583", loreal_kundenummer: "287677" },
  { org: "995519348", loreal_kundenummer: "244972" },
  { org: "987658738", loreal_kundenummer: "58983" }, // HÅR1. KJEDEN AS
  { org: "979534426", loreal_kundenummer: "27662" },
  { org: "998288819", loreal_kundenummer: "287177" },
  { org: "998503647", loreal_kundenummer: "hårfeen" }, // Note: Invalid
  { org: "984840136", loreal_kundenummer: "245341" },
  { org: "996655229", loreal_kundenummer: "253463" },
  { org: "968468235", loreal_kundenummer: "27428" },
  { org: "993812102", loreal_kundenummer: "221353" },
  { org: "929721225", loreal_kundenummer: "9000229113" },
  { org: "995390051", loreal_kundenummer: "303790" },
  { org: "918902198", loreal_kundenummer: "354130" },
  { org: "997943392", loreal_kundenummer: "9000075982" },
  { org: "915319483", loreal_kundenummer: "9000182871" },
  { org: "934266714", loreal_kundenummer: "9000121582" },
  { org: "998610923", loreal_kundenummer: "289283" },
  { org: "913865545", loreal_kundenummer: "305946" },
  { org: "917396280", loreal_kundenummer: "350907" },
  { org: "977558344", loreal_kundenummer: "27575" },
  { org: "986979778", loreal_kundenummer: "kleo" }, // Note: Invalid
  { org: "994276859", loreal_kundenummer: "319228" },
  { org: "912155625", loreal_kundenummer: "9000078208" },
  { org: "973192302", loreal_kundenummer: "26835" },
  { org: "984062516", loreal_kundenummer: "80346" },
  { org: "914738857", loreal_kundenummer: "353736" },
  { org: "918323236", loreal_kundenummer: "9000078272" },
  { org: "974430355", loreal_kundenummer: "37989" },
  { org: "988421804", loreal_kundenummer: "51080" }, // LA FEMME AS Brotorget
  { org: "925288241", loreal_kundenummer: "9000155950" },
  { org: "830877622", loreal_kundenummer: "9000235142" },
  { org: "981710673", loreal_kundenummer: "35606" },
  { org: "953138557", loreal_kundenummer: "m-frisør" }, // Note: Invalid
  { org: "824347352", loreal_kundenummer: "9000136984" },
  { org: "921441959", loreal_kundenummer: "9000078556" },
  { org: "926086111", loreal_kundenummer: "9000181259" },
  { org: "821422442", loreal_kundenummer: "9000132157" },
  { org: "980123499", loreal_kundenummer: "304895" },
  { org: "997943392", loreal_kundenummer: "244542" },
  { org: "815614372", loreal_kundenummer: "352975" },
  { org: "927332809", loreal_kundenummer: "9000188419" },
  { org: "931851411", loreal_kundenummer: "9000242650" },
  { org: "977067022", loreal_kundenummer: "35728" },
  { org: "996760618", loreal_kundenummer: "310168" },
  { org: "922609624", loreal_kundenummer: "9000132069" },
  { org: "927077744", loreal_kundenummer: "naomi" }, // Note: Invalid
  { org: "961472229", loreal_kundenummer: "27950" },
  { org: "946473766", loreal_kundenummer: "26470" },
  { org: "933498409", loreal_kundenummer: "9000252602" },
  { org: "824646872", loreal_kundenummer: "9000116396" },
  { org: "911662396", loreal_kundenummer: "9000182870" },
  { org: "932593610", loreal_kundenummer: "9000245573" },
  { org: "926732749", loreal_kundenummer: "9000185335" },
  { org: "918741003", loreal_kundenummer: "80448" },
  { org: "968602241", loreal_kundenummer: "28660" },
  { org: "992849673", loreal_kundenummer: "35727" },
  { org: "998911664", loreal_kundenummer: "288596" },
  { org: "984475144", loreal_kundenummer: "28040" },
  { org: "932841363", loreal_kundenummer: "9000247860" },
  { org: "988016853", loreal_kundenummer: "80065" },
  { org: "931313274", loreal_kundenummer: "9000233657" },
  { org: "820351622", loreal_kundenummer: "9000088579" },
  { org: "998545145", loreal_kundenummer: "358830" },
  { org: "911828189", loreal_kundenummer: "9000079093" },
  { org: "922321620", loreal_kundenummer: "9000156099" },
  { org: "824190992", loreal_kundenummer: "9000135333" },
  { org: "888802932", loreal_kundenummer: "231613" },
  { org: "913332156", loreal_kundenummer: "9000229462" },
  { org: "913222512", loreal_kundenummer: "salong" }, // Note: Invalid
  { org: "927968169", loreal_kundenummer: "9000197173" },
  { org: "940033500", loreal_kundenummer: "35354" },
  { org: "980441687", loreal_kundenummer: "26967" },
  { org: "980395898", loreal_kundenummer: "27206" },
  { org: "918713999", loreal_kundenummer: "70388" },
  { org: "976188284", loreal_kundenummer: "65375" },
  { org: "967300810", loreal_kundenummer: "27925" },
  { org: "999166628", loreal_kundenummer: "289201" },
  { org: "984238355", loreal_kundenummer: "28231" },
  { org: "989620231", loreal_kundenummer: "60583" },
  { org: "964839123", loreal_kundenummer: "80187" },
  { org: "992674016", loreal_kundenummer: "saxen" }, // Note: Invalid
  { org: "999503799", loreal_kundenummer: "290304" },
  { org: "921416849", loreal_kundenummer: "9000120660" },
  { org: "981711939", loreal_kundenummer: "28259" },
  { org: "923060235", loreal_kundenummer: "siri" }, // Note: Invalid
  { org: "913441826", loreal_kundenummer: "60272" },
  { org: "889040432", loreal_kundenummer: "59737" },
  { org: "912341127", loreal_kundenummer: "snæbbus1" }, // Note: Invalid
  { org: "912341100", loreal_kundenummer: "snæbbus2" }, // Note: Invalid
  { org: "889884762", loreal_kundenummer: "356398" },
  { org: "917063591", loreal_kundenummer: "28312" },
  { org: "955151682", loreal_kundenummer: "28318" },
  { org: "979783604", loreal_kundenummer: "28327" },
  { org: "918588493", loreal_kundenummer: "353613" },
  { org: "918771824", loreal_kundenummer: "stebi" }, // Note: Invalid
  { org: "998550955", loreal_kundenummer: "9000245561" },
  { org: "980363376", loreal_kundenummer: "9000231226" },
  { org: "933410889", loreal_kundenummer: "9000252235" },
  { org: "930683701", loreal_kundenummer: "9000266068" },
  { org: "813413892", loreal_kundenummer: "304741" },
  { org: "986623175", loreal_kundenummer: "9000190110" },
  { org: "911879492", loreal_kundenummer: "9000079668" },
  { org: "921133464", loreal_kundenummer: "9000121012" },
  { org: "873191732", loreal_kundenummer: "80265" },
  { org: "998006791", loreal_kundenummer: "353664" },
  { org: "925719315", loreal_kundenummer: "9000196362" },
  { org: "819165742", loreal_kundenummer: "9000267077" },
  { org: "971190140", loreal_kundenummer: "28390" },
  { org: "998900522", loreal_kundenummer: "294903" },
  { org: "921219172", loreal_kundenummer: "9000130503" },
  { org: "923208801", loreal_kundenummer: "361103" },
  { org: "996562794", loreal_kundenummer: "247367" },
  { org: "985506140", loreal_kundenummer: "28490" },
  { org: "911559676", loreal_kundenummer: "291669" },
  { org: "998437458", loreal_kundenummer: "286176" },
  { org: "917338213", loreal_kundenummer: "350659" },
  { org: "990542414", loreal_kundenummer: "63173" },
  { org: "922103887", loreal_kundenummer: "9000155372" },
  { org: "919905751", loreal_kundenummer: "9000127531" },
  { org: "918067833", loreal_kundenummer: "352642" },
  { org: "895833622", loreal_kundenummer: "9000079909" },
  { org: "926544594", loreal_kundenummer: "9000182925" },
  { org: "915597920", loreal_kundenummer: "310969" },
  { org: "991442499", loreal_kundenummer: "unicut" }, // Note: Invalid
  { org: "917095795", loreal_kundenummer: "317218" },
  { org: "968602241", loreal_kundenummer: "28551" }, // UNIQUE
  { org: "889537582", loreal_kundenummer: "60510" },
  { org: "995145472", loreal_kundenummer: "234408" },
  { org: "992074450", loreal_kundenummer: "66267" },
];

// Filter out invalid (non-numeric) customer numbers
const validCustomerData = customerData.filter(c => /^\d+$/.test(c.loreal_kundenummer));

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    console.log(`Starting L'Oréal customer import with ${validCustomerData.length} valid entries`);

    // Fetch all salons to match by org_number
    const { data: salons, error: salonsError } = await supabase
      .from("salons")
      .select("id, org_number, name");

    if (salonsError) {
      throw new Error(`Failed to fetch salons: ${salonsError.message}`);
    }

    console.log(`Found ${salons?.length || 0} salons in database`);

    // Create a map of org_number -> salon
    const salonMap = new Map<string, { id: string; name: string }>();
    for (const salon of salons || []) {
      if (salon.org_number) {
        // Normalize org_number (remove spaces)
        const normalizedOrg = salon.org_number.replace(/\s/g, "");
        salonMap.set(normalizedOrg, { id: salon.id, name: salon.name });
      }
    }

    const results = {
      matched: 0,
      notFound: [] as string[],
      errors: [] as string[],
      inserted: 0,
    };

    // Process each customer
    for (const customer of validCustomerData) {
      const normalizedOrg = customer.org.replace(/\s/g, "");
      const salon = salonMap.get(normalizedOrg);

      if (!salon) {
        results.notFound.push(`Org: ${normalizedOrg}, L'Oréal: ${customer.loreal_kundenummer}`);
        continue;
      }

      results.matched++;

      // Insert/update L'Oréal customer number
      const { error: insertError } = await supabase
        .from("supplier_identifiers")
        .upsert({
          salon_id: salon.id,
          supplier_id: LOREAL_SUPPLIER_ID,
          supplier_customer_number: customer.loreal_kundenummer,
          identifier_type: "loreal_kundenummer",
        }, {
          onConflict: "salon_id,supplier_id,identifier_type",
        });

      if (insertError) {
        console.error(`Error inserting for ${salon.name}:`, insertError);
        results.errors.push(`${salon.name}: ${insertError.message}`);
      } else {
        results.inserted++;
        console.log(`Inserted L'Oréal kundenr ${customer.loreal_kundenummer} for ${salon.name}`);
      }
    }

    console.log(`Import complete: ${results.matched} matched, ${results.inserted} inserted, ${results.notFound.length} not found`);

    return new Response(JSON.stringify({
      success: true,
      totalInList: validCustomerData.length,
      matched: results.matched,
      notFoundCount: results.notFound.length,
      notFound: results.notFound.slice(0, 20), // Limit to first 20 for readability
      inserted: results.inserted,
      errors: results.errors,
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error: unknown) {
    console.error("Error:", error);
    const message = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
