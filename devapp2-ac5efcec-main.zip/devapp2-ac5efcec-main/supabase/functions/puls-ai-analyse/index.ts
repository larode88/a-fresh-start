import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface TemaData {
  avg: number;
  risikoCount: number;
}

interface AnalyseRequest {
  temaData: Record<string, TemaData>;
  overallScore: number;
  antallSvar: number;
  antallAnsatte: number;
  openRisikoer: Array<{
    tema: string;
    score: number;
    foreslatte_tiltak: string[];
  }>;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY is not configured");
    }

    const { temaData, overallScore, antallSvar, antallAnsatte, openRisikoer } = await req.json() as AnalyseRequest;

    console.log("Puls AI analyse request:", { 
      overallScore, 
      antallSvar, 
      antallAnsatte,
      temaCount: Object.keys(temaData).length,
      risikoCount: openRisikoer.length 
    });

    // Build analysis prompt
    const temaLabels: Record<string, string> = {
      trivsel: "Trivsel",
      arbeidsbelastning: "Arbeidsbelastning",
      psykologisk_trygghet: "Psykologisk trygghet",
      ledelse: "Ledelse",
      hms_sikkerhet: "HMS/Sikkerhet",
      utvikling: "Utvikling"
    };

    const temaAnalyse = Object.entries(temaData)
      .map(([tema, data]) => `- ${temaLabels[tema] || tema}: Score ${data.avg.toFixed(1)}/5, ${data.risikoCount} åpne risikoer`)
      .join("\n");

    const risikoListe = openRisikoer.length > 0
      ? openRisikoer.map(r => `- ${temaLabels[r.tema] || r.tema}: Score ${r.score}/5`).join("\n")
      : "Ingen åpne risikoflagg";

    const systemPrompt = `Du er en HR-ekspert som analyserer pulsundersøkelser for norske frisørsalonger.
Din oppgave er å generere en innsiktsfull analyse basert på teamets pulsdata.

Bruk en varm, profesjonell tone tilpasset Hår1 sin merkevare.
Fokuser på handlingsrettede tiltak som er relevante for salonger og frisøryrket.
Alle tiltak skal være konkrete og gjennomførbare.`;

    const userPrompt = `Analyser følgende pulsdata for en frisørsalong:

**Samlet score:** ${overallScore.toFixed(1)}/5
**Antall svar:** ${antallSvar}
**Antall ansatte:** ${antallAnsatte}
**Svarprosent:** ${antallAnsatte > 0 ? ((antallSvar / antallAnsatte) * 100).toFixed(0) : 0}%

**Score per tema:**
${temaAnalyse}

**Åpne risikoflagg:**
${risikoListe}

Generer en analyse med:
1. Positive drivere (2-4 punkter om hva teamet gjør bra)
2. Risikoflagg (2-4 punkter om områder som trenger oppmerksomhet)
3. Tiltaksplan med konkrete handlinger for 30, 60 og 90 dager
4. En overordnet vurdering av team-sentiment
5. Et kort sammendrag (2-3 setninger)`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt }
        ],
        tools: [
          {
            type: "function",
            function: {
              name: "generate_puls_analyse",
              description: "Generer en strukturert pulsanalyse",
              parameters: {
                type: "object",
                properties: {
                  positiveDrivere: {
                    type: "array",
                    items: { type: "string" },
                    description: "2-4 positive aspekter ved teamets arbeidsmiljø"
                  },
                  risikoFlagg: {
                    type: "array",
                    items: { type: "string" },
                    description: "2-4 områder som trenger oppmerksomhet"
                  },
                  tiltaksplan: {
                    type: "object",
                    properties: {
                      dag30: {
                        type: "array",
                        items: { type: "string" },
                        description: "2-3 tiltak for de første 30 dagene"
                      },
                      dag60: {
                        type: "array",
                        items: { type: "string" },
                        description: "2-3 tiltak for dag 31-60"
                      },
                      dag90: {
                        type: "array",
                        items: { type: "string" },
                        description: "2-3 tiltak for dag 61-90"
                      }
                    },
                    required: ["dag30", "dag60", "dag90"]
                  },
                  teamSentiment: {
                    type: "string",
                    enum: ["positiv", "nøytral", "negativ"],
                    description: "Overordnet vurdering av teamets sentiment"
                  },
                  sammendrag: {
                    type: "string",
                    description: "Kort sammendrag på 2-3 setninger"
                  }
                },
                required: ["positiveDrivere", "risikoFlagg", "tiltaksplan", "teamSentiment", "sammendrag"]
              }
            }
          }
        ],
        tool_choice: { type: "function", function: { name: "generate_puls_analyse" } }
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limits exceeded, please try again later." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Payment required, please add funds to your Lovable AI workspace." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      throw new Error(`AI gateway error: ${response.status}`);
    }

    const data = await response.json();
    console.log("AI response received:", JSON.stringify(data).slice(0, 200));

    // Extract tool call result
    const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall || toolCall.function.name !== "generate_puls_analyse") {
      throw new Error("Invalid AI response structure");
    }

    const analyse = JSON.parse(toolCall.function.arguments);
    console.log("Parsed analyse:", JSON.stringify(analyse).slice(0, 200));

    return new Response(JSON.stringify(analyse), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error) {
    console.error("Error in puls-ai-analyse:", error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : "Unknown error" 
    }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
