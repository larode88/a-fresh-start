import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { Resend } from "https://esm.sh/resend@2.0.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");

interface CreateEmployeeUserRequest {
  ansatt_id: string;
  email: string;
  fornavn: string;
  etternavn?: string;
  telefon?: string;
  salon_id: string;
  stilling?: string;
  send_welcome_email?: boolean;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Validate authorization
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Create service role client for admin operations
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    const body: CreateEmployeeUserRequest = await req.json();
    const { 
      ansatt_id, 
      email, 
      fornavn, 
      etternavn, 
      telefon, 
      salon_id, 
      stilling,
      send_welcome_email = true 
    } = body;

    console.log(`Creating user for employee ${ansatt_id} with email ${email}`);

    // Validate required fields
    if (!ansatt_id || !email || !fornavn || !salon_id) {
      return new Response(JSON.stringify({ error: "Missing required fields" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Check if user already exists
    const { data: existingUser } = await supabase
      .from("users")
      .select("id")
      .eq("email", email)
      .maybeSingle();

    if (existingUser) {
      // User already exists, just link to ansatt
      await supabase
        .from("ansatte")
        .update({ user_id: existingUser.id })
        .eq("id", ansatt_id);

      console.log(`Linked existing user ${existingUser.id} to ansatt ${ansatt_id}`);

      return new Response(JSON.stringify({ 
        success: true, 
        user_id: existingUser.id,
        already_existed: true 
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Create user in auth.users using Admin API
    const { data: authUser, error: authError } = await supabase.auth.admin.createUser({
      email,
      email_confirm: true, // Auto-confirm so they can log in immediately
      user_metadata: {
        name: etternavn ? `${fornavn} ${etternavn}` : fornavn,
      },
    });

    if (authError) {
      console.error("Error creating auth user:", authError);
      return new Response(JSON.stringify({ error: authError.message }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const userId = authUser.user.id;
    console.log(`Created auth user ${userId}`);

    // The handle_new_user trigger creates the users table entry automatically
    // But we need to update it with the correct salon_id
    await supabase
      .from("users")
      .update({ 
        salon_id,
        phone: telefon || null,
      })
      .eq("id", userId);

    // Link user to ansatt
    await supabase
      .from("ansatte")
      .update({ user_id: userId })
      .eq("id", ansatt_id);

    console.log(`Linked user ${userId} to ansatt ${ansatt_id}`);

    // === HubSpot Sync ===
    let hubspot_contact_id: string | null = null;
    let hubspot_error: string | null = null;

    try {
      // Get salon's HubSpot company ID
      const { data: salon } = await supabase
        .from("salons")
        .select("hs_object_id, hubspot_owner_id")
        .eq("id", salon_id)
        .single();

      if (salon?.hs_object_id) {
        console.log(`Syncing to HubSpot company ${salon.hs_object_id}`);

        // Get HubSpot access token
        const { data: tokenData } = await supabase
          .from("hubspot_oauth_tokens")
          .select("access_token")
          .limit(1)
          .single();

        if (tokenData?.access_token) {
          // Create HubSpot contact with marketing/GDPR properties
          const contactProperties: Record<string, string> = {
            firstname: fornavn,
            email,
            lifecyclestage: "Medlem",
            // Marketing contact settings
            hs_marketable_status: "true",
            hs_marketable_reason_type: "INTEGRATOR_SET",
            // GDPR legal basis
            hs_legal_basis_for_email: "Freely given consent from contact",
            hs_legal_basis_for_processing_data: "Freely given consent from contact",
          };

          if (etternavn) contactProperties.lastname = etternavn;
          if (telefon) contactProperties.phone = telefon;
          // Use standard HubSpot jobtitle property instead of custom stilling
          if (stilling) contactProperties.jobtitle = stilling;

          const createContactResponse = await fetch("https://api.hubapi.com/crm/v3/objects/contacts", {
            method: "POST",
            headers: {
              Authorization: `Bearer ${tokenData.access_token}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ properties: contactProperties }),
          });

          if (createContactResponse.ok) {
            const contactResult = await createContactResponse.json();
            hubspot_contact_id = contactResult.id;
            console.log(`Created HubSpot contact ${hubspot_contact_id}`);

            // Associate contact with company
            await fetch(
              `https://api.hubapi.com/crm/v4/objects/contact/${hubspot_contact_id}/associations/company/${salon.hs_object_id}`,
              {
                method: "PUT",
                headers: {
                  Authorization: `Bearer ${tokenData.access_token}`,
                  "Content-Type": "application/json",
                },
                body: JSON.stringify([{ associationCategory: "HUBSPOT_DEFINED", associationTypeId: 1 }]),
              }
            );

            console.log(`Associated contact ${hubspot_contact_id} with company ${salon.hs_object_id}`);

            // Update ansatte with HubSpot contact ID
            await supabase
              .from("ansatte")
              .update({ 
                hubspot_contact_id,
                hubspot_synced_at: new Date().toISOString(),
              })
              .eq("id", ansatt_id);
          } else {
            const errorText = await createContactResponse.text();
            hubspot_error = `HubSpot contact creation failed: ${errorText}`;
            console.error(hubspot_error);
          }
        } else {
          hubspot_error = "HubSpot not connected";
          console.log(hubspot_error);
        }
      } else {
        console.log("Salon has no HubSpot company ID, skipping sync");
      }
    } catch (e: any) {
      hubspot_error = `HubSpot sync error: ${e?.message || String(e)}`;
      console.error(hubspot_error);
    }

    // === Send Welcome Email ===
    let welcome_email_sent = false;
    let email_error: string | null = null;

    if (send_welcome_email && RESEND_API_KEY) {
      try {
        // Check if email is enabled
        const { data: settings } = await supabase
          .from("system_settings")
          .select("value")
          .eq("key", "email_enabled")
          .single();

        const emailEnabled = settings?.value === true || settings?.value === "true";

        if (emailEnabled) {
          const resend = new Resend(RESEND_API_KEY);
          const loginUrl = "https://portal.har1.no";

          const { error: emailErr } = await resend.emails.send({
            from: "Hår1 Portalen <noreply@har1.no>",
            to: [email],
            subject: "Velkommen til Hår1 Portalen!",
            html: `
              <!DOCTYPE html>
              <html>
              <head>
                <meta charset="utf-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
              </head>
              <body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; background-color: #f9fafb;">
                <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f9fafb; padding: 40px 20px;">
                  <tr>
                    <td align="center">
                      <table width="100%" cellpadding="0" cellspacing="0" style="max-width: 600px; background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);">
                        <!-- Header -->
                        <tr>
                          <td style="background: linear-gradient(135deg, #7c3aed 0%, #9333ea 100%); padding: 40px 40px; text-align: center;">
                            <img src="https://portal.har1.no/haar1-logo-white.png" alt="Hår1" style="height: 48px; width: auto;">
                          </td>
                        </tr>
                        
                        <!-- Content -->
                        <tr>
                          <td style="padding: 40px;">
                            <h1 style="margin: 0 0 24px; font-size: 24px; font-weight: 600; color: #111827;">
                              Hei ${fornavn}! 👋
                            </h1>
                            
                            <p style="margin: 0 0 16px; font-size: 16px; line-height: 1.6; color: #4b5563;">
                              Velkommen til Hår1 Portalen – din nye arbeidsplattform!
                            </p>
                            
                            <p style="margin: 0 0 24px; font-size: 16px; line-height: 1.6; color: #4b5563;">
                              Du kan nå logge inn med e-postadressen din. Vi bruker engangskode (OTP) for sikker innlogging – ingen passord å huske!
                            </p>
                            
                            <div style="background-color: #f3e8ff; border-radius: 8px; padding: 20px; margin-bottom: 24px;">
                              <h3 style="margin: 0 0 12px; font-size: 14px; font-weight: 600; color: #7c3aed;">Slik logger du inn:</h3>
                              <ol style="margin: 0; padding-left: 20px; color: #4b5563; font-size: 14px; line-height: 1.8;">
                                <li>Gå til <a href="${loginUrl}" style="color: #7c3aed;">${loginUrl}</a></li>
                                <li>Skriv inn e-postadressen din: <strong>${email}</strong></li>
                                <li>Du mottar en 6-sifret kode på e-post</li>
                                <li>Skriv inn koden og du er logget inn!</li>
                              </ol>
                            </div>
                            
                            <a href="${loginUrl}" style="display: inline-block; background: linear-gradient(135deg, #7c3aed 0%, #9333ea 100%); color: #ffffff; text-decoration: none; padding: 14px 32px; border-radius: 8px; font-weight: 600; font-size: 16px;">
                              Logg inn nå
                            </a>
                          </td>
                        </tr>
                        
                        <!-- Footer -->
                        <tr>
                          <td style="padding: 24px 40px; background-color: #f9fafb; text-align: center;">
                            <p style="margin: 0; font-size: 12px; color: #9ca3af;">
                              Dette er en automatisk melding fra Hår1 Portalen.<br>
                              Har du spørsmål? Kontakt din leder.
                            </p>
                          </td>
                        </tr>
                      </table>
                    </td>
                  </tr>
                </table>
              </body>
              </html>
            `,
          });

          if (emailErr) {
            email_error = emailErr.message;
            console.error("Welcome email error:", emailErr);
          } else {
            welcome_email_sent = true;
            console.log(`Welcome email sent to ${email}`);
          }
        } else {
          email_error = "Email sending is disabled in system settings";
          console.log(email_error);
        }
      } catch (e: any) {
        email_error = `Email error: ${e?.message || String(e)}`;
        console.error(email_error);
      }
    }

    return new Response(JSON.stringify({
      success: true,
      user_id: userId,
      hubspot_contact_id,
      hubspot_error,
      welcome_email_sent,
      email_error,
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (error: any) {
    console.error("Error in create-employee-user:", error);
    return new Response(JSON.stringify({ error: error?.message || String(error) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
