import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "https://esm.sh/resend@2.0.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface DMWelcomeRequest {
  districtManagerIds?: string[]; // If empty, send to all DMs
  senderName: string;
  senderEmail: string;
  recipientEmail?: string; // For manual single recipient
  recipientName?: string;  // Name for manual recipient
}

// Sleep function for rate limiting
const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

const generateWelcomeEmailHtml = (dmName: string, senderName: string, senderEmail: string): string => {
  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; background-color: #f9f7f4; margin: 0; padding: 40px 20px;">
  <div style="max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.08);">
    
    <!-- Header -->
    <div style="background-color: #1a1a1a; padding: 32px; text-align: center;">
      <img src="https://portal.har1.no/haar1-logo-white.png" alt="Hår1" style="height: 40px; width: auto;">
    </div>
    
    <!-- Content -->
    <div style="padding: 40px 32px;">
      <h1 style="color: #1a1a1a; font-size: 24px; font-weight: 600; margin: 0 0 24px 0;">
        Hei ${dmName}! 👋
      </h1>
      
      <p style="color: #4a4a4a; font-size: 16px; line-height: 1.6; margin: 0 0 16px 0;">
        Vi har nå lansert nye funksjoner i Hår1 Portalen som gjør det enklere for deg å følge opp bonus og vekstbonus for dine salonger.
      </p>
      
      <h2 style="color: #1a1a1a; font-size: 18px; font-weight: 600; margin: 24px 0 16px 0;">
        Slik logger du inn:
      </h2>
      
      <ol style="color: #4a4a4a; font-size: 16px; line-height: 1.8; margin: 0 0 24px 0; padding-left: 20px;">
        <li>Gå til <a href="https://portal.har1.no" style="color: #7c3aed; text-decoration: none; font-weight: 500;">portal.har1.no</a></li>
        <li>Fyll inn din e-postadresse</li>
        <li>Klikk på <strong>"Send engangskode"</strong></li>
        <li>Engangskode sendes til e-posten din</li>
        <li>Fyll inn den 6-sifrede koden</li>
      </ol>
      
      <h2 style="color: #1a1a1a; font-size: 18px; font-weight: 600; margin: 24px 0 16px 0;">
        Slik finner du Bonus & Vekstbonus:
      </h2>
      
      <ol style="color: #4a4a4a; font-size: 15px; line-height: 1.8; margin: 0 0 24px 0; padding-left: 20px;">
        <li>Når du er logget inn, klikk på <strong>"Bonus & Vekstbonus"</strong> i sidemenyen under "Distriktsjef"</li>
        <li>Du får to faner: <strong>"Lojalitetsbonus"</strong> og <strong>"Vekstbonus"</strong></li>
      </ol>
      
      <h2 style="color: #1a1a1a; font-size: 18px; font-weight: 600; margin: 24px 0 16px 0;">
        Slik sender du vekstbonus-rapport til en salong:
      </h2>
      
      <ol style="color: #4a4a4a; font-size: 15px; line-height: 1.8; margin: 0 0 24px 0; padding-left: 20px;">
        <li>Gå til <strong>Bonus & Vekstbonus</strong> i sidemenyen og velg <strong>"Vekstbonus"</strong>-fanen</li>
        <li>Klikk på en salong i tabellen</li>
        <li>En detaljvisning åpnes med:
          <ul style="margin: 8px 0 8px 16px; padding-left: 16px; list-style-type: disc;">
            <li>Innkjøpstall hittil i år vs. fjorår</li>
            <li>Vekstprosent og tier-status</li>
            <li>Estimert bonus</li>
          </ul>
        </li>
        <li>Under <strong>"Send rapport til salongen"</strong>:
          <ul style="margin: 8px 0 8px 16px; padding-left: 16px; list-style-type: disc;">
            <li>Velg mottaker fra nedtrekkslisten (eller skriv inn e-post manuelt)</li>
            <li>Klikk <strong>"Send vekstbonus-rapport"</strong></li>
          </ul>
        </li>
      </ol>
      
      <div style="background-color: #ecfdf5; border-left: 4px solid #10b981; border-radius: 0 12px 12px 0; padding: 16px 20px; margin-bottom: 24px;">
        <p style="color: #065f46; font-size: 14px; line-height: 1.6; margin: 0;">
          <strong>Tips:</strong> Bruk vekstbonus-rapporten som utgangspunkt for samtaler med salongene om deres utvikling og potensial.
        </p>
      </div>
      
      <p style="color: #4a4a4a; font-size: 16px; line-height: 1.6; margin: 0 0 24px 0;">
        Har du spørsmål? Ta gjerne kontakt med meg.
      </p>
      
      <!-- CTA Button -->
      <div style="text-align: center; margin: 32px 0;">
        <a href="https://portal.har1.no" style="display: inline-block; background: linear-gradient(135deg, #7c3aed 0%, #9333ea 100%); color: white; padding: 14px 32px; text-decoration: none; border-radius: 8px; font-weight: 600; font-size: 16px;">
          Gå til Hår1 Portalen
        </a>
      </div>
      
      <p style="color: #4a4a4a; font-size: 16px; line-height: 1.6; margin: 24px 0 0 0;">
        Med vennlig hilsen,<br>
        <strong>${senderName}</strong><br>
        <a href="mailto:${senderEmail}" style="color: #7c3aed; text-decoration: none;">${senderEmail}</a>
      </p>
    </div>
    
    <!-- Footer -->
    <div style="background-color: #f9f7f4; padding: 24px 32px; text-align: center;">
      <p style="color: #9ca3af; font-size: 12px; margin: 0;">
        Hår1. Kjeden AS • Apotekergata 10 B, 0180 Oslo
      </p>
    </div>
  </div>
</body>
</html>
  `;
};

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const resendApiKey = Deno.env.get("RESEND_API_KEY");
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!resendApiKey || !supabaseUrl || !supabaseServiceKey) {
      throw new Error("Missing required environment variables");
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const resend = new Resend(resendApiKey);

    const { districtManagerIds, senderName, senderEmail, recipientEmail, recipientName }: DMWelcomeRequest = await req.json();

    // Check if email sending is enabled
    const { data: settings } = await supabase
      .from("system_settings")
      .select("value")
      .eq("key", "email_enabled")
      .single();

    if (settings?.value !== true && settings?.value !== "true") {
      return new Response(
        JSON.stringify({ 
          success: false, 
          error: "E-postutsending er deaktivert i systeminnstillingene" 
        }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // If manual recipient is specified, send only to that recipient
    if (recipientEmail && recipientName) {
      console.log(`Sending welcome email to manual recipient: ${recipientEmail}`);
      
      const firstName = recipientName.split(" ")[0] || recipientName;
      const html = generateWelcomeEmailHtml(firstName, senderName, senderEmail);

      const { error: emailError } = await resend.emails.send({
        from: `${senderName} <${senderEmail}>`,
        to: [recipientEmail],
        subject: "Velkommen til nye Hår1-Portalen!",
        html,
      });

      if (emailError) {
        console.error(`Failed to send to ${recipientEmail}:`, emailError);
        return new Response(
          JSON.stringify({ 
            success: false, 
            error: `Kunne ikke sende til ${recipientEmail}: ${emailError.message}` 
          }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      console.log(`Successfully sent to ${recipientEmail}`);
      return new Response(
        JSON.stringify({
          success: true,
          sent: 1,
          failed: 0,
          total: 1,
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Fetch district managers
    let query = supabase
      .from("users")
      .select("id, name, email")
      .not("email", "is", null);

    if (districtManagerIds && districtManagerIds.length > 0) {
      query = query.in("id", districtManagerIds);
    }

    // Get users with district_manager role
    const { data: dmUsers, error: dmError } = await supabase
      .from("user_roles")
      .select("user_id")
      .eq("role", "district_manager");

    if (dmError) {
      throw new Error(`Failed to fetch district managers: ${dmError.message}`);
    }

    const dmUserIds = dmUsers?.map(u => u.user_id) || [];

    if (dmUserIds.length === 0) {
      return new Response(
        JSON.stringify({ success: false, error: "Ingen distriktsjefer funnet" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Filter by DM user IDs
    const targetIds = districtManagerIds && districtManagerIds.length > 0
      ? districtManagerIds.filter(id => dmUserIds.includes(id))
      : dmUserIds;

    const { data: users, error: usersError } = await supabase
      .from("users")
      .select("id, name, email")
      .in("id", targetIds)
      .not("email", "is", null);

    if (usersError) {
      throw new Error(`Failed to fetch users: ${usersError.message}`);
    }

    if (!users || users.length === 0) {
      return new Response(
        JSON.stringify({ success: false, error: "Ingen distriktsjefer med e-post funnet" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`Sending welcome email to ${users.length} district managers`);

    let successCount = 0;
    let errorCount = 0;
    const errors: string[] = [];

    for (const user of users) {
      try {
        const firstName = user.name?.split(" ")[0] || "Distriktsjef";
        const html = generateWelcomeEmailHtml(firstName, senderName, senderEmail);

        const { error: emailError } = await resend.emails.send({
          from: `${senderName} <${senderEmail}>`,
          to: [user.email],
          subject: "Velkommen til nye Hår1-Portalen!",
          html,
        });

        if (emailError) {
          console.error(`Failed to send to ${user.email}:`, emailError);
          errors.push(`${user.name}: ${emailError.message}`);
          errorCount++;
        } else {
          console.log(`Successfully sent to ${user.email}`);
          successCount++;
        }
      } catch (err: unknown) {
        const errorMessage = err instanceof Error ? err.message : String(err);
        console.error(`Error sending to ${user.email}:`, err);
        errors.push(`${user.name}: ${errorMessage}`);
        errorCount++;
      }

      // Rate limiting: wait 600ms between emails to respect Resend's 2/sec limit
      await sleep(600);
    }

    return new Response(
      JSON.stringify({
        success: true,
        sent: successCount,
        failed: errorCount,
        total: users.length,
        errors: errors.length > 0 ? errors : undefined,
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error("Error in send-dm-welcome-email:", error);
    return new Response(
      JSON.stringify({ success: false, error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
};

serve(handler);
