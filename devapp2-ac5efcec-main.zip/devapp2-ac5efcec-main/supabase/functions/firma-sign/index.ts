import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const FIRMA_API_KEY = Deno.env.get('FIRMA_API_KEY');
const FIRMA_WEBHOOK_SECRET = Deno.env.get('FIRMA_WEBHOOK_SECRET');
const FIRMA_API_URL = 'https://api.firma.dev/functions/v1/signing-request-api';
const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

// Hardcoded workspace ID
const WORKSPACE_ID = '267e584f-17fd-47a4-b6d7-1b9768af4714';

// Verify webhook signature from Firma.dev
async function verifyWebhookSignature(payload: string, signature: string | null): Promise<boolean> {
  if (!FIRMA_WEBHOOK_SECRET || !signature) {
    console.log('No webhook secret or signature, skipping verification');
    return true; // Allow if no secret configured (for initial setup)
  }
  
  try {
    const encoder = new TextEncoder();
    const key = await crypto.subtle.importKey(
      'raw',
      encoder.encode(FIRMA_WEBHOOK_SECRET),
      { name: 'HMAC', hash: 'SHA-256' },
      false,
      ['sign']
    );
    
    const signatureBuffer = await crypto.subtle.sign('HMAC', key, encoder.encode(payload));
    const computedSignature = Array.from(new Uint8Array(signatureBuffer))
      .map(b => b.toString(16).padStart(2, '0'))
      .join('');
    
    return computedSignature === signature;
  } catch (error) {
    console.error('Webhook signature verification failed:', error);
    return false;
  }
}

// Create signing request via Firma.dev API - receives PDF from frontend
async function createSigningRequest(data: any, pdfBase64: string): Promise<any> {
  console.log('Creating signing request for:', data.salongnavn);
  console.log('Using workspace:', WORKSPACE_ID);
  console.log('PDF received from frontend, length:', pdfBase64.length);
  
  // Split contact name into first/last name for salon signer
  const nameParts = (data.kontaktperson_navn || 'Kontakt Person').split(' ');
  const salonFirstName = nameParts[0] || 'Kontakt';
  const salonLastName = nameParts.slice(1).join(' ') || 'Person';
  
  // Hår1 representative info (from current user or default)
  const haar1NameParts = (data.created_by_name || 'Hår1 Medlem').split(' ');
  const haar1FirstName = haar1NameParts[0] || 'Hår1';
  const haar1LastName = haar1NameParts.slice(1).join(' ') || 'Medlem';
  const haar1Email = data.created_by_email || 'post@har1.no';
  
  const requestBody = {
    name: `Medlemsavtale - ${data.salongnavn}`,
    description: `Samarbeidsavtale mellom ${data.salongnavn} og Hår1. Kjeden AS`,
    document: pdfBase64, // Use the PDF received from frontend
    expiration_hours: 168, // 7 days
    recipients: [
      {
        id: 'temp_1',
        first_name: haar1FirstName,
        last_name: haar1LastName,
        email: haar1Email,
        designation: 'Signer',
        order: 1, // Hår1 signs first
        company: 'Hår1. Kjeden AS',
        title: 'Distriktssjef'
      },
      {
        id: 'temp_2',
        first_name: salonFirstName,
        last_name: salonLastName,
        email: data.kontaktperson_epost,
        designation: 'Signer',
        order: 2, // Salon signs after Hår1
        company: data.salongnavn,
        title: 'Daglig leder'
      }
    ],
    settings: {
      allow_download: true,
      attach_pdf_on_finish: true
    }
  };

  console.log('Creating signing request with 2 signers:');
  console.log('Signer 1 (Hår1):', haar1Email, '- Company:', 'Hår1. Kjeden AS');
  console.log('Signer 2 (Salong):', data.kontaktperson_epost, '- Company:', data.salongnavn);
  
  // Step 1: Create the signing request
  const createResponse = await fetch(`${FIRMA_API_URL}/signing-requests`, {
    method: 'POST',
    headers: {
      'Authorization': FIRMA_API_KEY!,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(requestBody),
  });

  if (!createResponse.ok) {
    const errorText = await createResponse.text();
    console.error('Firma.dev API error (create):', createResponse.status, errorText);
    throw new Error(`Firma.dev API error: ${createResponse.status} - ${errorText}`);
  }

  const createResult = await createResponse.json();
  console.log('Signing request created:', createResult.id, 'Status:', createResult.status);
  
  // Step 2: Send the signing request (separate API call required)
  console.log('Sending signing request...');
  const sendResponse = await fetch(`${FIRMA_API_URL}/signing-requests/${createResult.id}/send`, {
    method: 'POST',
    headers: {
      'Authorization': FIRMA_API_KEY!,
    },
  });

  if (!sendResponse.ok) {
    const errorText = await sendResponse.text();
    console.error('Firma.dev API error (send):', sendResponse.status, errorText);
    throw new Error(`Firma.dev API error (send): ${sendResponse.status} - ${errorText}`);
  }

  const sendResult = await sendResponse.json();
  console.log('Signing request sent successfully:', sendResult);
  
  // Return combined result
  return {
    ...createResult,
    status: 'sent',
    sent_date: sendResult.sent_date || new Date().toISOString()
  };
}

// Delete/cancel a signing request
async function deleteSigningRequest(requestId: string): Promise<any> {
  console.log('Deleting signing request:', requestId);
  
  const response = await fetch(`${FIRMA_API_URL}/signing-requests/${requestId}`, {
    method: 'DELETE',
    headers: {
      'Authorization': FIRMA_API_KEY!,
    },
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error('Firma.dev API error:', response.status, errorText);
    throw new Error(`Firma.dev API error: ${response.status} - ${errorText}`);
  }

  console.log('Signing request deleted');
  return { success: true };
}

// Get signing request status
async function getSigningStatus(requestId: string): Promise<any> {
  console.log('Getting status for signing request:', requestId);
  
  const response = await fetch(`${FIRMA_API_URL}/signing-requests/${requestId}`, {
    method: 'GET',
    headers: {
      'Authorization': FIRMA_API_KEY!,
    },
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error('Firma.dev API error:', response.status, errorText);
    throw new Error(`Firma.dev API error: ${response.status} - ${errorText}`);
  }

  const result = await response.json();
  console.log('Signing status:', result);
  return result;
}

// Send reminder
async function sendReminder(requestId: string): Promise<any> {
  console.log('Sending reminder for signing request:', requestId);
  
  const response = await fetch(`${FIRMA_API_URL}/signing-requests/${requestId}/remind`, {
    method: 'POST',
    headers: {
      'Authorization': FIRMA_API_KEY!,
    },
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error('Firma.dev API error:', response.status, errorText);
    throw new Error(`Firma.dev API error: ${response.status} - ${errorText}`);
  }

  const result = await response.json();
  console.log('Reminder sent:', result);
  return result;
}

// Download signed document
async function downloadSignedDocument(requestId: string): Promise<any> {
  console.log('Downloading signed document for:', requestId);
  
  const response = await fetch(`${FIRMA_API_URL}/signing-requests/${requestId}/documents`, {
    method: 'GET',
    headers: {
      'Authorization': FIRMA_API_KEY!,
    },
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error('Firma.dev API error:', response.status, errorText);
    throw new Error(`Firma.dev API error: ${response.status} - ${errorText}`);
  }

  const result = await response.json();
  console.log('Document downloaded');
  return result;
}

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const actionParam = url.searchParams.get('action');
    
    // Handle webhook callbacks (GET or POST)
    if (actionParam === 'webhook') {
      console.log('Received webhook callback');
      
      const rawBody = await req.text();
      const signature = req.headers.get('x-firma-signature') || req.headers.get('x-webhook-signature');
      
      // Verify signature if secret is configured
      if (FIRMA_WEBHOOK_SECRET && signature) {
        const isValid = await verifyWebhookSignature(rawBody, signature);
        if (!isValid) {
          console.error('Invalid webhook signature');
          return new Response(JSON.stringify({ error: 'Invalid signature' }), {
            status: 401,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }
        console.log('Webhook signature verified');
      }
      
      const webhookData = rawBody ? JSON.parse(rawBody) : {};
      console.log('Webhook data:', JSON.stringify(webhookData, null, 2));
      
      const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
      const signingRequestId = webhookData.signing_request_id || webhookData.id || webhookData.data?.id;
      const eventType = webhookData.event || webhookData.type;
      const status = webhookData.status || webhookData.data?.status;
      
      console.log('Processing webhook - Event:', eventType, 'Status:', status, 'Request ID:', signingRequestId);
      
      if (signingRequestId) {
        const statusMap: Record<string, string> = {
          'pending': 'sendt',
          'sent': 'sendt',
          'viewed': 'apnet',
          'signed': 'signert',
          'completed': 'fullfort',
          'declined': 'avvist',
          'expired': 'utlopt',
          'cancelled': 'kansellert'
        };
        
        const mappedStatus = statusMap[status] || status;
        
        // Update avtaler table
        const avtaleUpdateData: any = {
          signing_status: mappedStatus,
          updated_at: new Date().toISOString()
        };
        
        if (status === 'viewed') {
          avtaleUpdateData.viewed_at = new Date().toISOString();
        } else if (status === 'signed' || status === 'completed') {
          avtaleUpdateData.signed_at = new Date().toISOString();
          avtaleUpdateData.completed_at = new Date().toISOString();
        }
        
        const { data: avtale, error: avtaleError } = await supabase
          .from('avtaler')
          .update(avtaleUpdateData)
          .eq('adobe_agreement_id', signingRequestId)
          .select('id, innmelding_utkast_id')
          .single();
        
        if (avtaleError) {
          console.error('Error updating avtaler:', avtaleError);
        } else {
          console.log('Successfully updated avtaler status to:', mappedStatus);
          
          // Log the event
          await supabase.from('avtale_logg').insert({
            avtale_id: avtale.id,
            hendelse: `Webhook: Status endret til ${mappedStatus}`,
            detaljer: JSON.stringify(webhookData)
          });
        }
        
        // Handle completed/signed status - update innmelding_utkast and download PDF
        if ((status === 'signed' || status === 'completed' || eventType === 'signing_request.completed') && avtale?.innmelding_utkast_id) {
          console.log('Agreement signed! Updating innmelding_utkast:', avtale.innmelding_utkast_id);
          
          let signedPdfUrl = null;
          
          // Try to download and store signed PDF
          try {
            console.log('Downloading signed document from Firma.dev...');
            const documentsResponse = await fetch(`${FIRMA_API_URL}/signing-requests/${signingRequestId}/documents`, {
              method: 'GET',
              headers: {
                'Authorization': FIRMA_API_KEY!,
              },
            });
            
            if (documentsResponse.ok) {
              const documents = await documentsResponse.json();
              console.log('Documents response:', JSON.stringify(documents, null, 2));
              
              // Get the signed PDF URL or base64 content
              const signedDoc = documents.signed_document || documents.document || documents[0];
              
              if (signedDoc) {
                let pdfContent: Uint8Array;
                
                if (signedDoc.content || signedDoc.base64) {
                  // Base64 encoded content
                  const base64 = signedDoc.content || signedDoc.base64;
                  const binaryString = atob(base64);
                  pdfContent = new Uint8Array(binaryString.length);
                  for (let i = 0; i < binaryString.length; i++) {
                    pdfContent[i] = binaryString.charCodeAt(i);
                  }
                } else if (signedDoc.url || signedDoc.download_url) {
                  // Download from URL
                  const downloadUrl = signedDoc.url || signedDoc.download_url;
                  const pdfResponse = await fetch(downloadUrl);
                  if (pdfResponse.ok) {
                    const arrayBuffer = await pdfResponse.arrayBuffer();
                    pdfContent = new Uint8Array(arrayBuffer);
                  } else {
                    throw new Error('Failed to download PDF from URL');
                  }
                } else {
                  throw new Error('No PDF content found in response');
                }
                
                // Upload to Supabase storage
                const fileName = `samarbeidsavtaler/${signingRequestId}_signed.pdf`;
                const { error: uploadError } = await supabase.storage
                  .from('insurance-documents')
                  .upload(fileName, pdfContent, {
                    contentType: 'application/pdf',
                    upsert: true
                  });
                
                if (uploadError) {
                  console.error('Error uploading signed PDF:', uploadError);
                } else {
                  const { data: publicUrlData } = supabase.storage
                    .from('insurance-documents')
                    .getPublicUrl(fileName);
                  signedPdfUrl = publicUrlData.publicUrl;
                  console.log('Signed PDF uploaded to:', signedPdfUrl);
                }
              }
            } else {
              console.error('Failed to download signed document:', documentsResponse.status);
            }
          } catch (pdfError) {
            console.error('Error downloading/uploading signed PDF:', pdfError);
          }
          
          // Fetch current wizard_data
          const { data: currentUtkast } = await supabase
            .from('innmelding_utkast')
            .select('wizard_data')
            .eq('id', avtale.innmelding_utkast_id)
            .single();
          
          const updatedWizardData = {
            ...(currentUtkast?.wizard_data || {}),
            avtale_status: 'signert'
          };
          
          // Update innmelding_utkast to completed
          const utkastUpdateData: any = {
            status: 'ferdig',
            avtale_status: 'signert',
            current_step: 7,
            agreement_signed_at: new Date().toISOString(),
            wizard_data: updatedWizardData,
            updated_at: new Date().toISOString()
          };
          
          if (signedPdfUrl) {
            utkastUpdateData.signed_pdf_url = signedPdfUrl;
          }
          
          const { error: utkastError } = await supabase
            .from('innmelding_utkast')
            .update(utkastUpdateData)
            .eq('id', avtale.innmelding_utkast_id);
          
          if (utkastError) {
            console.error('Error updating innmelding_utkast:', utkastError);
          } else {
            console.log('Successfully updated innmelding_utkast to ferdig with current_step=7');
          }
        }
        
        // Handle cancelled/expired/declined
        if (status === 'cancelled' || status === 'expired' || status === 'declined') {
          if (avtale?.innmelding_utkast_id) {
            const { data: currentUtkast } = await supabase
              .from('innmelding_utkast')
              .select('wizard_data')
              .eq('id', avtale.innmelding_utkast_id)
              .single();
            
            const updatedWizardData = {
              ...(currentUtkast?.wizard_data || {}),
              avtale_status: mappedStatus
            };
            
            await supabase
              .from('innmelding_utkast')
              .update({
                status: status === 'expired' ? 'utlopt' : 'utkast',
                avtale_status: mappedStatus,
                wizard_data: updatedWizardData,
                updated_at: new Date().toISOString()
              })
              .eq('id', avtale.innmelding_utkast_id);
            
            console.log('Updated innmelding_utkast for', status, 'status');
          }
        }
      }
      
      return new Response(JSON.stringify({ success: true }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Handle regular API calls
    const { action, ...params } = await req.json();
    console.log('Action:', action, 'Params:', params);

    let result;

    switch (action) {
      case 'create_agreement':
        const signingRequest = await createSigningRequest(params.data, params.pdfBase64);
        
        // Store in avtaler table
        const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
        
        const avtaleData = {
          adobe_agreement_id: signingRequest.id,
          salongnavn: params.data.salongnavn,
          org_nummer: params.data.org_nummer,
          kontaktperson_navn: params.data.kontaktperson_navn,
          kontaktperson_epost: params.data.kontaktperson_epost,
          signing_status: 'sendt',
          sent_at: new Date().toISOString(),
          avtale_type: 'medlemsavtale',
          district_id: params.data.district_id,
          hubspot_owner_id: params.data.hubspot_owner_id,
          innmelding_utkast_id: params.innmeldingUtkastId,
          created_by: params.userId
        };
        
        const { data: avtale, error: avtaleError } = await supabase
          .from('avtaler')
          .insert(avtaleData)
          .select()
          .single();
        
        if (avtaleError) {
          console.error('Error creating avtale record:', avtaleError);
        }
        
        // Update innmelding_utkast with agreement status (both columns AND wizard_data)
        if (params.innmeldingUtkastId) {
          // First fetch current wizard_data
          const { data: currentUtkast } = await supabase
            .from('innmelding_utkast')
            .select('wizard_data')
            .eq('id', params.innmeldingUtkastId)
            .single();
          
          const updatedWizardData = {
            ...(currentUtkast?.wizard_data || {}),
            avtale_status: 'sendt',
            avtale_url: `https://app.firma.dev/sign/${signingRequest.id}`
          };
          
          const { error: utkastError } = await supabase
            .from('innmelding_utkast')
            .update({
              status: 'venter_signering',
              avtale_status: 'sendt',
              adobe_signing_status: 'sent',
              agreement_sent_at: new Date().toISOString(),
              wizard_data: updatedWizardData,
              updated_at: new Date().toISOString()
            })
            .eq('id', params.innmeldingUtkastId);
          
          if (utkastError) {
            console.error('Error updating innmelding_utkast:', utkastError);
          } else {
            console.log('Updated innmelding_utkast status to sendt (both columns and wizard_data)');
          }
        }
        
        // Log the event
        if (avtale) {
          await supabase.from('avtale_logg').insert({
            avtale_id: avtale.id,
            hendelse: 'Avtale opprettet og sendt til signering',
            utfort_av: params.userId,
            detaljer: JSON.stringify({
              salongnavn: params.data.salongnavn,
              kontaktperson: params.data.kontaktperson_navn,
              firma_request_id: signingRequest.id
            })
          });
        }
        
        // Return format expected by frontend
        result = { 
          success: true, 
          agreementId: signingRequest.id,
          signingUrl: `https://app.firma.dev/sign/${signingRequest.id}`,
          signingRequest,
          avtale 
        };
        break;

      case 'get_status':
        const status = await getSigningStatus(params.agreementId);
        result = status;
        break;

      case 'send_reminder':
        const reminder = await sendReminder(params.agreementId);
        result = reminder;
        break;

      case 'download_signed':
        const documents = await downloadSignedDocument(params.agreementId);
        result = { documents };
        break;

      case 'delete':
        await deleteSigningRequest(params.agreementId);
        
        // Also delete from avtaler table
        const supabaseDelete = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);
        await supabaseDelete
          .from('avtaler')
          .delete()
          .eq('adobe_agreement_id', params.agreementId);
        
        result = { success: true, message: 'Signeringsforespørsel slettet' };
        break;

      default:
        throw new Error(`Unknown action: ${action}`);
    }

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('Error in firma-sign function:', error);
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});
