import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface SelectedEmployee {
  user_id: string;
  name: string;
  personnummer?: string;
}

interface QuoteProduct {
  product_id: string;
  product_name: string;
  price: number;
  quantity: number;
  tier_id?: string;
  tier_name?: string;
  arsverk?: number;
  selected_employees?: SelectedEmployee[];
}

interface PreviousInsurer {
  company: string;
  policy_number: string;
}

interface ConfirmedAddress {
  address: string;
  postal_code: string;
  city: string;
}

interface AcceptQuoteRequest {
  token: string;
  ipAddress?: string;
  userAgent?: string;
  updatedProducts?: QuoteProduct[];
  hasExistingInsurance?: boolean;
  previousInsurers?: PreviousInsurer[];
  confirmedAddress?: ConfirmedAddress;
}

// Create insurance order from quote (for cases without POA)
// Split into bedrift and helse orders
async function createOrdersFromQuote(
  supabase: any, 
  quote: any,
  confirmedAddress?: ConfirmedAddress
): Promise<{ bedriftOrderId: string | null; helseOrderId: string | null; error: string | null }> {
  console.log("Creating insurance orders from quote:", quote.id);

  try {
    const products = quote.products || [];
    if (products.length === 0) {
      console.log("No products in quote, skipping order creation");
      return { bedriftOrderId: null, helseOrderId: null, error: "No products in quote" };
    }

    // Split products into bedrift and helse
    const helseProducts = products.filter((p: QuoteProduct) => 
      p.product_name === "Helseforsikring" || (p.selected_employees && p.selected_employees.length > 0)
    );
    const bedriftProducts = products.filter((p: QuoteProduct) => 
      p.product_name !== "Helseforsikring" && (!p.selected_employees || p.selected_employees.length === 0)
    );

    console.log(`Splitting: ${bedriftProducts.length} bedrift products, ${helseProducts.length} helse products`);

    // Fetch product details to get product_id mappings
    const productNames = products.map((p: any) => p.product_name);
    const { data: dbProducts } = await supabase
      .from("insurance_products")
      .select("id, name")
      .in("name", productNames);

    const productNameToId: Record<string, string> = {};
    if (dbProducts) {
      for (const p of dbProducts) {
        productNameToId[p.name] = p.id;
      }
    }

    // Fetch tier details if needed
    const tierNames = products.filter((p: any) => p.tier_name).map((p: any) => p.tier_name);
    const { data: dbTiers } = await supabase
      .from("insurance_product_tiers")
      .select("id, tier_name, product_id")
      .in("tier_name", tierNames);

    const tierNameToId: Record<string, string> = {};
    if (dbTiers) {
      for (const t of dbTiers) {
        tierNameToId[`${t.product_id}:${t.tier_name}`] = t.id;
      }
    }

    let bedriftOrderId: string | null = null;
    let helseOrderId: string | null = null;

    // Create Bedrift order if there are bedrift products
    if (bedriftProducts.length > 0) {
      let bedriftTotal = 0;
      for (const p of bedriftProducts) {
        const qty = p.quantity || p.arsverk || 1;
        bedriftTotal += p.price * qty;
      }

      const { data: bedriftOrder, error: bedriftError } = await supabase
        .from("insurance_orders")
        .insert({
          salon_id: quote.member_salon_id,
          ordered_by_user_id: quote.district_manager_id,
          status: "pending_approval",
          order_type: "new",
          order_category: "bedrift",
          total_price: bedriftTotal,
          contact_name: quote.contact_name,
          contact_email: quote.email,
          contact_phone: quote.phone,
          switching_provider: false,
          previous_insurances: null,
          source_quote_id: quote.id,
          salon_address: confirmedAddress?.address || quote.salon_address,
          salon_postal_code: confirmedAddress?.postal_code || quote.salon_postal_code,
          salon_city: confirmedAddress?.city || quote.salon_city,
          antall_ansatte: quote.antall_ansatte || null,
          antall_arsverk: quote.antall_arsverk || null,
          aarlig_omsetning: quote.aarlig_omsetning || null,
        })
        .select()
        .single();

      if (bedriftError) {
        console.error("Error creating bedrift order:", bedriftError);
      } else {
        bedriftOrderId = bedriftOrder.id;
        console.log("Bedrift order created:", bedriftOrderId);

        // Create order items for bedrift products
        for (const product of bedriftProducts) {
          const productId = product.product_id || productNameToId[product.product_name];
          if (!productId) {
            console.error("Could not find product_id for:", product.product_name);
            continue;
          }

          // For YSF products (Yrkesskade), use arsverk as quantity
          const isYsfProduct = product.product_name?.toLowerCase().includes('yrkesskade');
          const quantity = isYsfProduct ? (product.arsverk || product.quantity || 1) : (product.quantity || 1);
          const tierId = product.tier_id || (product.tier_name ? tierNameToId[`${productId}:${product.tier_name}`] : null);

          const { error: itemError } = await supabase
            .from("insurance_order_items")
            .insert({
              order_id: bedriftOrderId,
              product_id: productId,
              tier_id: tierId || null,
              quantity: quantity,
              unit_price: product.price,
              total_price: product.price * quantity,
            });

          if (itemError) {
            console.error("Error creating bedrift order item:", itemError);
          }
        }
      }
    }

    // Create Helse order if there are helse products
    if (helseProducts.length > 0) {
      let helseTotal = 0;
      for (const p of helseProducts) {
        const qty = p.selected_employees?.length || p.quantity || 1;
        helseTotal += p.price * qty;
      }

      const { data: helseOrder, error: helseError } = await supabase
        .from("insurance_orders")
        .insert({
          salon_id: quote.member_salon_id,
          ordered_by_user_id: quote.district_manager_id,
          status: "pending_approval",
          order_type: "new",
          order_category: "helse",
          total_price: helseTotal,
          contact_name: quote.contact_name,
          contact_email: quote.email,
          contact_phone: quote.phone,
          switching_provider: false,
          previous_insurances: null,
          source_quote_id: quote.id,
          salon_address: confirmedAddress?.address || quote.salon_address,
          salon_postal_code: confirmedAddress?.postal_code || quote.salon_postal_code,
          salon_city: confirmedAddress?.city || quote.salon_city,
          antall_ansatte: quote.antall_ansatte || null,
          antall_arsverk: quote.antall_arsverk || null,
          aarlig_omsetning: quote.aarlig_omsetning || null,
        })
        .select()
        .single();

      if (helseError) {
        console.error("Error creating helse order:", helseError);
      } else {
        helseOrderId = helseOrder.id;
        console.log("Helse order created:", helseOrderId);

        // Create order items for helse products
        for (const product of helseProducts) {
          const productId = product.product_id || productNameToId[product.product_name];
          if (!productId) {
            console.error("Could not find product_id for:", product.product_name);
            continue;
          }

          const quantity = product.selected_employees?.length || product.quantity || 1;

          const { data: orderItem, error: itemError } = await supabase
            .from("insurance_order_items")
            .insert({
              order_id: helseOrderId,
              product_id: productId,
              tier_id: null,
              quantity: quantity,
              unit_price: product.price,
              total_price: product.price * quantity,
            })
            .select()
            .single();

          if (itemError) {
            console.error("Error creating helse order item:", itemError);
            continue;
          }

          // Create employee links for health insurance
          if (product.selected_employees && product.selected_employees.length > 0) {
            for (const emp of product.selected_employees) {
              if (emp.user_id) {
                const { error: empError } = await supabase
                  .from("insurance_order_employees")
                  .insert({
                    order_item_id: orderItem.id,
                    user_id: emp.user_id,
                  });

                if (empError) {
                  console.error("Error creating employee link:", empError);
                } else {
                  console.log("Employee link created for:", emp.user_id);
                }
              }
            }
          }
        }
      }
    }

    return { bedriftOrderId, helseOrderId, error: null };
  } catch (err: any) {
    console.error("Error in createOrdersFromQuote:", err);
    return { bedriftOrderId: null, helseOrderId: null, error: err.message };
  }
}

const handler = async (req: Request): Promise<Response> => {
  console.log("accept-quote function called");

  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { 
      token, 
      ipAddress, 
      userAgent, 
      updatedProducts,
      hasExistingInsurance,
      previousInsurers,
      confirmedAddress 
    }: AcceptQuoteRequest = await req.json();
    
    console.log(`Processing acceptance for token: ${token}`);
    console.log(`Has existing insurance: ${hasExistingInsurance}`);
    console.log(`Confirmed address:`, confirmedAddress);

    // Fetch quote by token
    const { data: quote, error: quoteError } = await supabase
      .from("insurance_quotes")
      .select("*")
      .eq("acceptance_token", token)
      .single();

    if (quoteError || !quote) {
      console.error("Quote not found:", quoteError);
      return new Response(
        JSON.stringify({ error: "Tilbudet ble ikke funnet", code: "NOT_FOUND" }),
        { status: 404, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Check status
    if (quote.status === "accepted" || quote.status === "completed") {
      return new Response(
        JSON.stringify({ 
          error: "Du har allerede akseptert dette tilbudet", 
          code: "ALREADY_ACCEPTED",
          quote: {
            id: quote.id,
            salon_name: quote.salon_name,
            status: quote.status
          }
        }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    if (quote.status !== "sent") {
      return new Response(
        JSON.stringify({ error: "Dette tilbudet kan ikke aksepteres", code: "INVALID_STATUS" }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Check expiry
    if (quote.expires_at && new Date(quote.expires_at) < new Date()) {
      return new Response(
        JSON.stringify({ error: "Tilbudet har utløpt. Kontakt din distriktsleder.", code: "EXPIRED" }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Use updated products with personnummer if provided, otherwise use existing
    const finalProducts = updatedProducts || quote.products;

    // Determine final status based on whether POA is needed
    // If no existing insurance, we can mark as completed immediately (no POA needed)
    const newStatus = hasExistingInsurance === false ? "completed" : "accepted";
    const completedAt = hasExistingInsurance === false ? new Date().toISOString() : null;

    // Update quote as accepted with updated products and address
    const { error: updateError } = await supabase
      .from("insurance_quotes")
      .update({
        status: newStatus,
        accepted_at: new Date().toISOString(),
        acceptance_ip: ipAddress || null,
        acceptance_user_agent: userAgent || null,
        products: finalProducts,
        completed_at: completedAt,
        salon_address: confirmedAddress?.address || quote.salon_address,
        salon_postal_code: confirmedAddress?.postal_code || quote.salon_postal_code,
        salon_city: confirmedAddress?.city || quote.salon_city,
      })
      .eq("id", quote.id);

    if (updateError) {
      console.error("Error updating quote:", updateError);
      throw new Error("Kunne ikke oppdatere tilbudet");
    }

    // If there are health insurance employees with personnummer, store them securely
    if (updatedProducts) {
      for (const product of updatedProducts) {
        if (product.selected_employees) {
          for (const emp of product.selected_employees) {
            if (emp.personnummer) {
              const { error: userUpdateError } = await supabase
                .from("users")
                .update({
                  helseforsikring_personnummer: emp.personnummer
                })
                .eq("id", emp.user_id);

              if (userUpdateError) {
                console.error(`Error updating personnummer for user ${emp.user_id}:`, userUpdateError);
              } else {
                console.log(`Personnummer stored for user ${emp.user_id}`);
              }
            }
          }
        }
      }
    }

    // Variable to track created orders
    let bedriftOrderId: string | null = null;
    let helseOrderId: string | null = null;

    // If has existing insurance, create a POA record to be signed
    if (hasExistingInsurance === true && previousInsurers && previousInsurers.length > 0) {
      console.log("Creating POA record with previous insurers:", previousInsurers);
      
      const tempHash = crypto.randomUUID();
      
      const { data: poa, error: poaError } = await supabase
        .from("insurance_power_of_attorney")
        .insert({
          salon_name: quote.salon_name,
          org_number: quote.org_number,
          contact_name: quote.contact_name,
          email: quote.email,
          phone: quote.phone || null,
          has_existing_insurance: true,
          previous_insurers: previousInsurers,
          quote_id: quote.id,
          otp_code_hash: tempHash,
          otp_expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
          consent_transfer: false,
          consent_privacy: false,
        })
        .select()
        .single();

      if (poaError) {
        console.error("Error creating POA:", poaError);
      } else {
        console.log(`POA record created: ${poa.id}`);
      }
    } else if (hasExistingInsurance === false) {
      // No POA needed - create orders immediately (split into bedrift and helse)
      const quoteWithProducts = { ...quote, products: finalProducts };
      const result = await createOrdersFromQuote(supabase, quoteWithProducts, confirmedAddress);
      
      if (result.error) {
        console.error("Failed to create orders from quote:", result.error);
      } else {
        bedriftOrderId = result.bedriftOrderId;
        helseOrderId = result.helseOrderId;
        console.log("Insurance orders created - Bedrift:", bedriftOrderId, "Helse:", helseOrderId);
      }
    }

    // Send notification email to admin
    try {
      await supabase.functions.invoke("send-quote-email", {
        body: { 
          quoteId: quote.id, 
          action: "notify_acceptance",
          hasExistingInsurance,
          previousInsurers,
          bedriftOrderId,
          helseOrderId
        }
      });
    } catch (emailError) {
      console.error("Error sending acceptance notification:", emailError);
    }

    console.log(`Quote ${quote.id} accepted successfully with status: ${newStatus}`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        quote: {
          id: quote.id,
          salon_name: quote.salon_name,
          org_number: quote.org_number,
          contact_name: quote.contact_name,
          email: quote.email,
          phone: quote.phone,
          products: finalProducts,
          total_price: quote.total_price,
          notes: quote.notes
        },
        hasExistingInsurance,
        requiresPoa: hasExistingInsurance === true,
        bedriftOrderId,
        helseOrderId
      }),
      { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );

  } catch (error: any) {
    console.error("Error in accept-quote:", error);
    return new Response(
      JSON.stringify({ error: error.message || "An error occurred" }),
      { status: 500, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );
  }
};

serve(handler);