import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface SendOtpRequest {
  poaId: string;
  email: string;
}

// Generate a 6-digit OTP
function generateOtp(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// Simple hash function for OTP (not cryptographically secure, but sufficient for short-lived codes)
async function hashOtp(otp: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(otp + Deno.env.get("SUPABASE_SERVICE_ROLE_KEY"));
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, "0")).join("");
}

// Try to render email from database template via render-email-template function
async function tryRenderFromTemplate(
  supabaseUrl: string,
  supabaseServiceKey: string,
  templateSlug: string,
  variables: Record<string, string>
): Promise<{ html: string; subject: string } | null> {
  try {
    const response = await fetch(`${supabaseUrl}/functions/v1/render-email-template`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${supabaseServiceKey}`,
      },
      body: JSON.stringify({
        template_slug: templateSlug,
        variables
      }),
    });

    if (response.ok) {
      const data = await response.json();
      if (data.html && data.subject) {
        console.log(`Successfully rendered template: ${templateSlug}`);
        return { html: data.html, subject: data.subject };
      }
    }
    console.log(`Template ${templateSlug} not found or rendering failed, using fallback`);
    return null;
  } catch (error) {
    console.error(`Error rendering template ${templateSlug}:`, error);
    return null;
  }
}

const handler = async (req: Request): Promise<Response> => {
  console.log("send-poa-otp function called");

  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const resendApiKey = Deno.env.get("RESEND_API_KEY");
    const siteUrl = Deno.env.get("SITE_URL") || "https://devapp2.lovable.app";
    const logoUrl = `${siteUrl}/haar1-forsikring-email-logo.png`;

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Check if email is enabled
    const { data: settings } = await supabase
      .from("system_settings")
      .select("value")
      .eq("key", "email_enabled")
      .single();

    const emailEnabled = settings?.value === true || settings?.value === "true";

    const { poaId, email }: SendOtpRequest = await req.json();
    console.log("Sending OTP to:", email, "for POA:", poaId);

    // Generate OTP and hash
    const otp = generateOtp();
    const otpHash = await hashOtp(otp);
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

    // Update POA record with OTP hash and expiry
    const { error: updateError } = await supabase
      .from("insurance_power_of_attorney")
      .update({
        otp_code_hash: otpHash,
        otp_expires_at: expiresAt.toISOString(),
        otp_attempts: 0,
      })
      .eq("id", poaId);

    if (updateError) {
      console.error("Error updating POA with OTP:", updateError);
      throw new Error("Kunne ikke oppdatere fullmakt med OTP");
    }

    // Send email if enabled
    if (emailEnabled && resendApiKey) {
      // Try database template first
      const templateResult = await tryRenderFromTemplate(
        supabaseUrl,
        supabaseServiceKey,
        'poa-otp-code',
        {
          otp_code: otp,
          utloper_minutter: '10',
          logoUrl: logoUrl,
        }
      );

      let emailHtml: string;
      let subject: string;

      if (templateResult) {
        emailHtml = templateResult.html;
        subject = templateResult.subject;
      } else {
        // Fallback to hardcoded HTML
        subject = "Din signeringskode for fullmakt til Hår1";
        emailHtml = `
          <!DOCTYPE html>
          <html>
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
          </head>
          <body style="font-family: 'Segoe UI', 'DM Sans', Arial, sans-serif; line-height: 1.7; color: #3D3D3D; margin: 0; padding: 0; background-color: #FAF8F5;">
            <div style="max-width: 600px; margin: 0 auto; padding: 40px 20px;">
              
              <!-- Logo Header -->
              <div style="text-align: center; margin-bottom: 32px;">
                <img src="${logoUrl}" alt="Hår1 Forsikring" style="max-height: 70px; width: auto;" />
              </div>
              
              <!-- Main Content Card -->
              <div style="background: #FFFFFF; border-radius: 16px; padding: 40px 32px; box-shadow: 0 4px 24px rgba(139, 115, 85, 0.08);">
                
                <p style="font-size: 18px; margin: 0 0 16px 0;">Hei! 👋</p>
                
                <p style="margin: 0 0 24px 0; color: #5A5A5A;">
                  For å fullføre signeringen av fullmakten, bruk koden under:
                </p>
                
                <!-- OTP Code Box -->
                <div style="background: linear-gradient(135deg, #FAF7F2 0%, #F5EEE6 100%); border-radius: 16px; padding: 32px; text-align: center; margin: 24px 0;">
                  <p style="margin: 0 0 12px 0; font-size: 14px; color: #8B7355; font-weight: 500; text-transform: uppercase; letter-spacing: 1px;">Din signeringskode</p>
                  <div style="font-size: 42px; font-weight: 700; letter-spacing: 12px; color: #3D3D3D; font-family: monospace; margin: 16px 0;">${otp}</div>
                  <p style="margin: 16px 0 0 0; font-size: 14px; color: #888;">Koden er gyldig i 10 minutter</p>
                </div>
                
                <p style="margin: 24px 0; color: #5A5A5A;">
                  Gå tilbake til siden du ble sendt til og legg inn koden for å fullføre signeringen.
                </p>
                
                <!-- Info Box -->
                <div style="background: #F8F9FA; border-left: 4px solid #8B7355; border-radius: 0 8px 8px 0; padding: 16px 20px; margin: 24px 0;">
                  <p style="margin: 0; font-size: 14px; color: #5A5A5A;">
                    💡 Hvis du ikke har bedt om denne koden, kan du trygt ignorere denne e-posten.
                  </p>
                </div>
                
              </div>
              
              <!-- Footer -->
              <div style="text-align: center; margin-top: 32px; padding: 24px; color: #6B5440;">
                <p style="margin: 0 0 4px 0; font-size: 15px;">Varm hilsen,</p>
                <p style="margin: 0; font-weight: 600; color: #8B7355; font-size: 16px;">Hår1 Forsikringsteamet</p>
                <p style="margin: 16px 0 0 0; font-size: 14px; color: #888;">
                  📧 <a href="mailto:forsikring@har1.no" style="color: #8B7355; text-decoration: none;">forsikring@har1.no</a><br/>
                  📞 +47 4000 3345
                </p>
              </div>
              
            </div>
          </body>
          </html>
        `;
      }

      const emailResponse = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${resendApiKey}`,
        },
        body: JSON.stringify({
          from: "Hår1 Forsikring <forsikring@har1.no>",
          to: [email],
          subject: subject,
          html: emailHtml,
        }),
      });

      if (!emailResponse.ok) {
        const errorData = await emailResponse.text();
        console.error("Error sending OTP email:", errorData);

      } else {
        console.log("OTP email sent successfully to:", email);
      }
    } else {
      console.log("Email disabled or no API key - OTP:", otp, "(logged for testing only)");
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: "OTP sendt",
        // Only include OTP in response if email is disabled (for testing)
        ...((!emailEnabled || !resendApiKey) && { testOtp: otp })
      }),
      { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );

  } catch (error: any) {
    console.error("Error in send-poa-otp:", error);
    return new Response(
      JSON.stringify({ error: error.message || "En feil oppstod" }),
      { status: 500, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );
  }
};

serve(handler);
