import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface VerifyOtpRequest {
  phone?: string;
  email?: string;
  otp: string;
  type: "login" | "password_reset" | "signup";
  newPassword?: string; // For password reset
  name?: string; // For signup
}

// Hash OTP using SHA-256
async function hashOtp(otp: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(otp);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
}

// Format phone number to E.164 format
function formatPhoneNumber(phone: string): string {
  let cleaned = phone.replace(/[^\d+]/g, "");
  if (cleaned.startsWith("00")) {
    cleaned = "+" + cleaned.substring(2);
  }
  if (!cleaned.startsWith("+")) {
    if (cleaned.startsWith("0")) {
      cleaned = cleaned.substring(1);
    }
    cleaned = "+47" + cleaned;
  }
  return cleaned;
}

// Extract just the digits from a phone number (last 8 digits for Norwegian numbers)
function getNorwegianNumber(phone: string): string {
  const digits = phone.replace(/\D/g, "");
  if (digits.length > 8) {
    return digits.slice(-8);
  }
  return digits;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }
  
  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    
    const { phone, email, otp, type, newPassword, name }: VerifyOtpRequest = await req.json();
    
    if (!otp || (!phone && !email)) {
      return new Response(
        JSON.stringify({ error: "Kode og kontaktinformasjon er påkrevd" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    
    const isEmail = !!email && !phone;
    const contactIdentifier = isEmail ? email.toLowerCase().trim() : formatPhoneNumber(phone!);
    const otpHash = await hashOtp(otp);
    
    console.log(`Verifying OTP for ${isEmail ? 'email' : 'phone'}:`, contactIdentifier, "Hash:", otpHash);
    
    // Find valid OTP
    let otpRecord = null;
    
    if (isEmail) {
      const { data, error } = await supabase
        .from("auth_otp")
        .select("*")
        .eq("email", contactIdentifier)
        .eq("otp_hash", otpHash)
        .eq("verified", false)
        .gt("expires_at", new Date().toISOString())
        .single();
      
      if (!error && data) {
        otpRecord = data;
      }
    } else {
      // Try exact phone match first
      const { data: exactMatch } = await supabase
        .from("auth_otp")
        .select("*")
        .eq("phone_number", contactIdentifier)
        .eq("otp_hash", otpHash)
        .eq("verified", false)
        .gt("expires_at", new Date().toISOString())
        .single();
      
      if (exactMatch) {
        otpRecord = exactMatch;
      } else {
        // Try flexible match using Norwegian number
        const norwegianNumber = getNorwegianNumber(phone!);
        const { data: allOtps } = await supabase
          .from("auth_otp")
          .select("*")
          .eq("otp_hash", otpHash)
          .eq("verified", false)
          .gt("expires_at", new Date().toISOString());
        
        if (allOtps && allOtps.length > 0) {
          otpRecord = allOtps.find(o => o.phone_number && getNorwegianNumber(o.phone_number) === norwegianNumber);
        }
      }
    }
    
    if (!otpRecord) {
      // Increment attempts
      if (isEmail) {
        await supabase
          .from("auth_otp")
          .update({ attempts: 1 })
          .eq("email", contactIdentifier)
          .eq("verified", false);
      } else {
        await supabase
          .from("auth_otp")
          .update({ attempts: 1 })
          .eq("phone_number", contactIdentifier)
          .eq("verified", false);
      }
      
      return new Response(
        JSON.stringify({ error: "Ugyldig eller utløpt kode" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    
    // Check max attempts
    if (otpRecord.attempts >= 5) {
      return new Response(
        JSON.stringify({ error: "For mange mislykkede forsøk. Be om ny kode." }),
        { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    
    // Mark OTP as verified
    await supabase
      .from("auth_otp")
      .update({ verified: true })
      .eq("id", otpRecord.id);
    
    // Handle login
    if (type === "login") {
      let userId: string | null = null;
      let userEmail: string | null = null;
      
      if (isEmail) {
        // Look up user by email
        const { data: user } = await supabase
          .from("users")
          .select("id, email")
          .eq("email", contactIdentifier)
          .single();
        
        if (!user) {
          return new Response(
            JSON.stringify({ error: "Bruker ikke funnet" }),
            { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        
        userId = user.id;
        userEmail = user.email;
      } else {
        // Look up user by phone via ansatte
        const norwegianNumber = getNorwegianNumber(contactIdentifier);
        
        const { data: ansatteWithPhone } = await supabase
          .from("ansatte")
          .select("id, user_id, telefon, epost")
          .not("user_id", "is", null)
          .not("telefon", "is", null);
        
        const matchingAnsatt = ansatteWithPhone?.find(a => {
          const ansattNumber = getNorwegianNumber(a.telefon);
          return ansattNumber === norwegianNumber;
        });
        
        if (!matchingAnsatt) {
          return new Response(
            JSON.stringify({ error: "Bruker ikke funnet" }),
            { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        
        // Get user email
        const { data: user } = await supabase
          .from("users")
          .select("id, email")
          .eq("id", matchingAnsatt.user_id)
          .single();
        
        if (!user) {
          return new Response(
            JSON.stringify({ error: "Bruker ikke funnet" }),
            { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        
        userId = user.id;
        userEmail = user.email;
      }
      
      // Generate magic link
      const { data: authData, error: authError } = await supabase.auth.admin.generateLink({
        type: "magiclink",
        email: userEmail!,
        options: {
          redirectTo: `${req.headers.get("origin") || supabaseUrl}/dashboard`,
        },
      });
      
      if (authError) {
        console.error("Error generating auth link:", authError);
        throw new Error("Kunne ikke opprette innlogging");
      }
      
      // Update verified status
      if (isEmail) {
        await supabase.from("users").update({ email_verified: true }).eq("id", userId);
      } else {
        await supabase.from("users").update({ phone_verified: true }).eq("id", userId);
      }
      
      return new Response(
        JSON.stringify({ 
          success: true, 
          type: "login",
          authUrl: authData.properties?.action_link,
          message: "Kode verifisert! Du blir logget inn.",
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    
    // Handle password reset
    if (type === "password_reset") {
      if (!newPassword) {
        return new Response(
          JSON.stringify({ error: "Nytt passord er påkrevd" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      
      if (newPassword.length < 6) {
        return new Response(
          JSON.stringify({ error: "Passordet må være minst 6 tegn" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      
      let userId: string | null = null;
      
      if (isEmail) {
        const { data: user } = await supabase
          .from("users")
          .select("id")
          .eq("email", contactIdentifier)
          .single();
        
        if (!user) {
          return new Response(
            JSON.stringify({ error: "Bruker ikke funnet" }),
            { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        
        userId = user.id;
      } else {
        const norwegianNumber = getNorwegianNumber(contactIdentifier);
        
        const { data: ansatteWithPhone } = await supabase
          .from("ansatte")
          .select("id, user_id, telefon")
          .not("user_id", "is", null)
          .not("telefon", "is", null);
        
        const matchingAnsatt = ansatteWithPhone?.find(a => {
          const ansattNumber = getNorwegianNumber(a.telefon);
          return ansattNumber === norwegianNumber;
        });
        
        if (!matchingAnsatt) {
          return new Response(
            JSON.stringify({ error: "Bruker ikke funnet" }),
            { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
        
        userId = matchingAnsatt.user_id;
      }
      
      // Update password
      const { error: updateError } = await supabase.auth.admin.updateUserById(
        userId!,
        { password: newPassword }
      );
      
      if (updateError) {
        console.error("Error updating password:", updateError);
        throw new Error("Kunne ikke oppdatere passord");
      }
      
      // Update verified status
      if (isEmail) {
        await supabase.from("users").update({ email_verified: true }).eq("id", userId);
      } else {
        await supabase.from("users").update({ phone_verified: true }).eq("id", userId);
      }
      
      return new Response(
        JSON.stringify({ 
          success: true, 
          type: "password_reset",
          message: "Passordet ditt er oppdatert!",
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    
    // Handle signup
    if (type === "signup") {
      if (!name) {
        return new Response(
          JSON.stringify({ error: "Navn er påkrevd for registrering" }),
          { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      
      if (isEmail) {
        // Check if email already registered
        const { data: existingUser } = await supabase
          .from("users")
          .select("id")
          .eq("email", contactIdentifier)
          .single();
        
        if (existingUser) {
          return new Response(
            JSON.stringify({ error: "Denne e-postadressen er allerede registrert" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
      } else {
        // Check if phone already registered
        const norwegianNumber = getNorwegianNumber(contactIdentifier);
        
        const { data: ansatteWithPhone } = await supabase
          .from("ansatte")
          .select("id, user_id, telefon")
          .not("user_id", "is", null)
          .not("telefon", "is", null);
        
        const existingAnsatt = ansatteWithPhone?.find(a => {
          const ansattNumber = getNorwegianNumber(a.telefon);
          return ansattNumber === norwegianNumber;
        });
        
        if (existingAnsatt) {
          return new Response(
            JSON.stringify({ error: "Dette telefonnummeret er allerede registrert" }),
            { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
      }
      
      // Verified - return success so frontend can proceed with signup
      return new Response(
        JSON.stringify({ 
          success: true, 
          type: "signup",
          phoneVerified: !isEmail,
          emailVerified: isEmail,
          message: isEmail 
            ? "E-postadresse verifisert! Du kan nå fullføre registreringen."
            : "Telefonnummer verifisert! Du kan nå fullføre registreringen.",
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
    
    return new Response(
      JSON.stringify({ error: "Ugyldig forespørselstype" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
    
  } catch (error: unknown) {
    console.error("Error in verify-auth-otp:", error);
    const errorMessage = error instanceof Error ? error.message : "Kunne ikke verifisere kode";
    
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
