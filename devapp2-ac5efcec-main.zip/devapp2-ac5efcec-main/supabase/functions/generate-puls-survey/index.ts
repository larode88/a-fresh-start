import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const TEMAER = ['trivsel', 'arbeidsbelastning', 'psykologisk_trygghet', 'ledelse', 'hms_sikkerhet', 'utvikling'];

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Get all active automatic plans where neste_utsendelse <= today
    const today = new Date().toISOString().split('T')[0];
    
    const { data: plans, error: plansError } = await supabase
      .from('puls_automatisk_plan')
      .select('*')
      .eq('aktiv', true)
      .lte('neste_utsendelse', today);

    if (plansError) {
      console.error('Error fetching plans:', plansError);
      throw plansError;
    }

    if (!plans || plans.length === 0) {
      console.log('No plans due for today');
      return new Response(
        JSON.stringify({ message: 'Ingen planer å generere i dag', generated: 0 }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get question bank
    const { data: questionBank, error: qbError } = await supabase
      .from('puls_sporsmal_bank')
      .select('*')
      .eq('aktiv', true);

    if (qbError || !questionBank) {
      console.error('Error fetching question bank:', qbError);
      throw qbError || new Error('No questions found');
    }

    const generatedSurveys: { surveyId: string; salonId: string; type: string; questionsCount: number }[] = [];

    for (const plan of plans) {
      console.log(`Processing plan for salon ${plan.salon_id}, type: ${plan.puls_type}`);
      
      const selectedQuestions: Array<{ id: string; tema: string; sporsmal_type: string; tekst: string }> = [];
      const excludeIds = plan.siste_sporsmal_ids || [];

      if (plan.puls_type === 'hurtigpuls') {
        // Hurtigpuls: 1 scale question per tema (6 total)
        for (const tema of TEMAER) {
          const temaQuestions = questionBank.filter(q => 
            q.tema === tema && 
            q.sporsmal_type === 'skala' &&
            !excludeIds.includes(q.id)
          );
          
          if (temaQuestions.length > 0) {
            const randomIndex = Math.floor(Math.random() * temaQuestions.length);
            selectedQuestions.push(temaQuestions[randomIndex]);
          } else {
            // Fallback: use any scale question from this tema
            const fallback = questionBank.filter(q => q.tema === tema && q.sporsmal_type === 'skala');
            if (fallback.length > 0) {
              selectedQuestions.push(fallback[Math.floor(Math.random() * fallback.length)]);
            }
          }
        }
      } else if (plan.puls_type === 'dyppuls') {
        // Dyppuls: 2-3 scale questions per tema + 2 free text
        for (const tema of TEMAER) {
          const temaScaleQuestions = questionBank.filter(q => 
            q.tema === tema && 
            q.sporsmal_type === 'skala' &&
            !excludeIds.includes(q.id)
          );
          
          // Take 2-3 questions per tema
          const numToTake = Math.min(temaScaleQuestions.length, Math.random() > 0.5 ? 3 : 2);
          const shuffled = temaScaleQuestions.sort(() => Math.random() - 0.5);
          selectedQuestions.push(...shuffled.slice(0, numToTake));
        }

        // Add 2 free text questions from different temas
        const fritekstQuestions = questionBank.filter(q => 
          q.sporsmal_type === 'fritekst' &&
          !excludeIds.includes(q.id)
        ).sort(() => Math.random() - 0.5);
        
        selectedQuestions.push(...fritekstQuestions.slice(0, 2));
      }

      if (selectedQuestions.length === 0) {
        console.log(`No questions selected for plan ${plan.id}, skipping`);
        continue;
      }

      // Create the survey
      const surveyName = plan.puls_type === 'hurtigpuls' 
        ? `Hurtigpuls - Uke ${getWeekNumber(new Date())}`
        : `Dyppuls - ${getMonthName(new Date())}`;

      const startDato = new Date();
      const sluttDato = new Date();
      sluttDato.setDate(sluttDato.getDate() + (plan.puls_type === 'hurtigpuls' ? 5 : 14));

      const { data: survey, error: surveyError } = await supabase
        .from('pulsundersokelser')
        .insert({
          salon_id: plan.salon_id,
          navn: surveyName,
          beskrivelse: plan.puls_type === 'hurtigpuls' 
            ? 'Rask ukentlig pulssjekk med 6 spørsmål'
            : 'Grundig månedlig pulsundersøkelse',
          puls_type: plan.puls_type,
          status: 'aktiv',
          start_dato: startDato.toISOString().split('T')[0],
          slutt_dato: sluttDato.toISOString().split('T')[0],
          frekvens: plan.frekvens === 'annenhver_uke' ? 'ukentlig' : 'maanedlig',
          rotasjon_aktivert: true
        })
        .select()
        .single();

      if (surveyError) {
        console.error('Error creating survey:', surveyError);
        continue;
      }

      // Log questions to rotation table
      for (const q of selectedQuestions) {
        await supabase.from('puls_sporsmal_rotasjon').insert({
          undersokelse_id: survey.id,
          sporsmal_id: q.id,
          uke_nummer: getWeekNumber(new Date())
        });
      }

      // Update plan with next date and used question IDs
      const nesteUtsendelse = new Date(plan.neste_utsendelse);
      if (plan.frekvens === 'annenhver_uke') {
        nesteUtsendelse.setDate(nesteUtsendelse.getDate() + 14);
      } else {
        nesteUtsendelse.setMonth(nesteUtsendelse.getMonth() + 1);
      }

      await supabase
        .from('puls_automatisk_plan')
        .update({
          neste_utsendelse: nesteUtsendelse.toISOString().split('T')[0],
          siste_sporsmal_ids: selectedQuestions.map(q => q.id)
        })
        .eq('id', plan.id);

      generatedSurveys.push({
        surveyId: survey.id,
        salonId: plan.salon_id,
        type: plan.puls_type,
        questionsCount: selectedQuestions.length
      });

      console.log(`Generated ${plan.puls_type} survey with ${selectedQuestions.length} questions`);
    }

    return new Response(
      JSON.stringify({ 
        message: `Genererte ${generatedSurveys.length} undersøkelse(r)`,
        generated: generatedSurveys.length,
        surveys: generatedSurveys
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: unknown) {
    console.error('Error in generate-puls-survey:', error);
    const message = error instanceof Error ? error.message : 'Unknown error';
    return new Response(
      JSON.stringify({ error: message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

function getWeekNumber(date: Date): number {
  const d = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
  const dayNum = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  return Math.ceil((((d.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
}

function getMonthName(date: Date): string {
  const months = ['Januar', 'Februar', 'Mars', 'April', 'Mai', 'Juni', 
                  'Juli', 'August', 'September', 'Oktober', 'November', 'Desember'];
  return `${months[date.getMonth()]} ${date.getFullYear()}`;
}
