import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "https://esm.sh/resend@2.0.0";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface RoleChangeRequest {
  userEmail: string;
  userName: string;
  oldRole: string;
  newRole: string;
}

const getRoleLabel = (role: string): string => {
  const labels: Record<string, string> = {
    admin: "Admin",
    district_manager: "Distriktsleder",
    salon_owner: "Salongeier",
    stylist: "Frisør",
    apprentice: "Lærling",
    supplier_admin: "Leverandør Admin",
    supplier_sales: "Leverandør Salg",
    supplier_business_dev: "Leverandør Business Dev",
  };
  return labels[role] || role;
};

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Verify user is authenticated and has admin role
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      console.error("No authorization header provided");
      return new Response(
        JSON.stringify({ error: "Unauthorized - no authorization header" }),
        { status: 401, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Check if email sending is enabled
    const { data: emailSetting } = await supabase
      .from("system_settings")
      .select("value")
      .eq("key", "email_enabled")
      .single();

    const isEmailEnabled = emailSetting?.value === true;

    if (!isEmailEnabled) {
      console.log("Email sending is disabled - skipping role change notification");
      return new Response(
        JSON.stringify({ success: true, skipped: true, reason: "Email sending disabled" }),
        { status: 200, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Get user from JWT token
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    
    if (authError || !user) {
      console.error("Auth error:", authError);
      return new Response(
        JSON.stringify({ error: "Unauthorized - invalid token" }),
        { status: 401, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    // Check if user has admin role (only admins can change roles)
    const { data: userRole, error: roleError } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .single();

    if (roleError || !userRole) {
      console.error("Role lookup error:", roleError);
      return new Response(
        JSON.stringify({ error: "Unauthorized - could not verify role" }),
        { status: 401, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    if (userRole.role !== "admin") {
      console.error("User does not have admin role:", userRole.role);
      return new Response(
        JSON.stringify({ error: "Forbidden - only admins can send role change notifications" }),
        { status: 403, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    console.log(`Authorized admin ${user.email} sending role change notification`);

    const { userEmail, userName, oldRole, newRole }: RoleChangeRequest = await req.json();

    // Validate required fields
    if (!userEmail || !userName || !oldRole || !newRole) {
      return new Response(
        JSON.stringify({ error: "Missing required fields: userEmail, userName, oldRole, newRole" }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    console.log(`Sending role change notification to ${userEmail}`);

    const emailResponse = await resend.emails.send({
      from: "Hår1 Portalen <noreply@har1.no>",
      to: [userEmail],
      subject: "Din rolle er endret",
      html: `
        <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
          <h1 style="color: #1a1a1a; margin-bottom: 24px;">Hei ${userName}!</h1>
          <p style="color: #4a4a4a; font-size: 16px; line-height: 1.6;">
            Din rolle i Merbehandling Challenge 2026 har blitt endret av en administrator.
          </p>
          <div style="background: #f4f4f5; border-radius: 8px; padding: 16px; margin: 24px 0;">
            <p style="margin: 0 0 8px 0; color: #71717a; font-size: 14px;">Tidligere rolle:</p>
            <p style="margin: 0 0 16px 0; color: #1a1a1a; font-size: 18px; font-weight: 600;">${getRoleLabel(oldRole)}</p>
            <p style="margin: 0 0 8px 0; color: #71717a; font-size: 14px;">Ny rolle:</p>
            <p style="margin: 0; color: #1a1a1a; font-size: 18px; font-weight: 600;">${getRoleLabel(newRole)}</p>
          </div>
          <p style="color: #4a4a4a; font-size: 16px; line-height: 1.6;">
            Du kan nå logge inn for å se dine nye tilganger og funksjoner.
          </p>
          <p style="color: #71717a; font-size: 14px; margin-top: 32px;">
            Med vennlig hilsen,<br>
            Hår1 / Merbehandling Challenge Team
          </p>
        </div>
      `,
    });

    console.log("Email sent successfully:", emailResponse);

    return new Response(JSON.stringify({ success: true, data: emailResponse }), {
      status: 200,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  } catch (error: any) {
    console.error("Error sending role change notification:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
