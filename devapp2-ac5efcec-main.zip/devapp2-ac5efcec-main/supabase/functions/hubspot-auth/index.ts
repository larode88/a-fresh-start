import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const HUBSPOT_CLIENT_ID = Deno.env.get("HUBSPOT_CLIENT_ID");
const HUBSPOT_CLIENT_SECRET = Deno.env.get("HUBSPOT_CLIENT_SECRET");
const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Validate authentication
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      console.error("No authorization header provided");
      return new Response(JSON.stringify({ error: 'Unauthorized' }), { 
        status: 401, 
        headers: { ...corsHeaders, "Content-Type": "application/json" } 
      });
    }

    const token = authHeader.replace('Bearer ', '');
    const supabase = createClient(SUPABASE_URL!, SUPABASE_SERVICE_ROLE_KEY!);
    
    // Verify the user's JWT token
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !user) {
      console.error("Invalid token:", authError?.message);
      return new Response(JSON.stringify({ error: 'Invalid token' }), { 
        status: 401, 
        headers: { ...corsHeaders, "Content-Type": "application/json" } 
      });
    }

    // Check if user has admin role
    const { data: roleData, error: roleError } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id)
      .eq('role', 'admin')
      .maybeSingle();

    if (roleError || !roleData) {
      console.error("User does not have admin role:", user.id);
      return new Response(JSON.stringify({ error: 'Forbidden: Admin access required' }), { 
        status: 403, 
        headers: { ...corsHeaders, "Content-Type": "application/json" } 
      });
    }

    console.log(`HubSpot auth request by admin user: ${user.id}`);
    const { action, code, redirect_uri } = await req.json();

    console.log(`HubSpot auth action: ${action}`);

    switch (action) {
      case "exchange": {
        // Exchange authorization code for tokens
        if (!code || !redirect_uri) {
          throw new Error("Missing code or redirect_uri");
        }

        console.log("Exchanging code for tokens...");
        const tokenResponse = await fetch("https://api.hubapi.com/oauth/v1/token", {
          method: "POST",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: new URLSearchParams({
            grant_type: "authorization_code",
            client_id: HUBSPOT_CLIENT_ID!,
            client_secret: HUBSPOT_CLIENT_SECRET!,
            redirect_uri: redirect_uri,
            code: code,
          }),
        });

        if (!tokenResponse.ok) {
          const errorText = await tokenResponse.text();
          console.error("Token exchange failed:", errorText);
          throw new Error(`Token exchange failed: ${errorText}`);
        }

        const tokens = await tokenResponse.json();
        console.log("Token exchange successful");

        // Calculate expiry time (HubSpot tokens expire in expires_in seconds)
        const expiresAt = new Date(Date.now() + tokens.expires_in * 1000);

        // Store tokens in database (upsert - only one row)
        const { data: existingTokens } = await supabase
          .from("hubspot_oauth_tokens")
          .select("id")
          .limit(1);

        if (existingTokens && existingTokens.length > 0) {
          // Update existing
          const { error } = await supabase
            .from("hubspot_oauth_tokens")
            .update({
              access_token: tokens.access_token,
              refresh_token: tokens.refresh_token,
              expires_at: expiresAt.toISOString(),
              updated_at: new Date().toISOString(),
            })
            .eq("id", existingTokens[0].id);

          if (error) throw error;
        } else {
          // Insert new
          const { error } = await supabase.from("hubspot_oauth_tokens").insert({
            access_token: tokens.access_token,
            refresh_token: tokens.refresh_token,
            expires_at: expiresAt.toISOString(),
          });

          if (error) throw error;
        }

        return new Response(JSON.stringify({ success: true }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "refresh": {
        // Get current tokens
        const { data: tokenData, error: fetchError } = await supabase
          .from("hubspot_oauth_tokens")
          .select("*")
          .limit(1)
          .single();

        if (fetchError || !tokenData) {
          throw new Error("No HubSpot connection found");
        }

        console.log("Refreshing access token...");
        const refreshResponse = await fetch("https://api.hubapi.com/oauth/v1/token", {
          method: "POST",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: new URLSearchParams({
            grant_type: "refresh_token",
            client_id: HUBSPOT_CLIENT_ID!,
            client_secret: HUBSPOT_CLIENT_SECRET!,
            refresh_token: tokenData.refresh_token,
          }),
        });

        if (!refreshResponse.ok) {
          const errorText = await refreshResponse.text();
          console.error("Token refresh failed:", errorText);
          throw new Error(`Token refresh failed: ${errorText}`);
        }

        const newTokens = await refreshResponse.json();
        const expiresAt = new Date(Date.now() + newTokens.expires_in * 1000);

        // Update stored tokens
        const { error: updateError } = await supabase
          .from("hubspot_oauth_tokens")
          .update({
            access_token: newTokens.access_token,
            refresh_token: newTokens.refresh_token,
            expires_at: expiresAt.toISOString(),
            updated_at: new Date().toISOString(),
          })
          .eq("id", tokenData.id);

        if (updateError) throw updateError;

        return new Response(JSON.stringify({ success: true, access_token: newTokens.access_token }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "status": {
        // Check connection status
        const { data: tokenData, error } = await supabase
          .from("hubspot_oauth_tokens")
          .select("expires_at, updated_at")
          .limit(1)
          .single();

        if (error || !tokenData) {
          return new Response(JSON.stringify({ connected: false }), {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        const isExpired = new Date(tokenData.expires_at) < new Date();

        return new Response(
          JSON.stringify({
            connected: true,
            expires_at: tokenData.expires_at,
            updated_at: tokenData.updated_at,
            is_expired: isExpired,
          }),
          { headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }

      case "disconnect": {
        // Remove tokens
        const { error } = await supabase.from("hubspot_oauth_tokens").delete().neq("id", "00000000-0000-0000-0000-000000000000");

        if (error) throw error;

        return new Response(JSON.stringify({ success: true }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      default:
        throw new Error(`Unknown action: ${action}`);
    }
  } catch (error) {
    console.error("HubSpot auth error:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
