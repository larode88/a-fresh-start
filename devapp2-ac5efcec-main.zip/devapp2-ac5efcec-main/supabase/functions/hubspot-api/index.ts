import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const HUBSPOT_CLIENT_ID = Deno.env.get("HUBSPOT_CLIENT_ID");
const HUBSPOT_CLIENT_SECRET = Deno.env.get("HUBSPOT_CLIENT_SECRET");
const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

// Insurance properties from HubSpot (company level)
const INSURANCE_PROPERTIES = [
  "avsluttede_forsikringser",
  "dato_for_aktivering_av_forsikring",
  "dato_for_innmelding_av_forsikring",
  "dato_for_oppsigelse_av_forsikring",
  "forsikring_antall_ansatte",
  "forsikring_antall_arsverk",
  "forsikring_antall_personer_fritidsulykke",
  "forsikring_antall_personer_reiseforsikring",
  "forsikring_arlig_omsetning__nok_",
  "forsikring_cyberforsikring",
  "forsikring_e_post",
  "forsikring_fritidsulykkeforsikring",
  "forsikring_kontaktperson",
  "forsikring_pris_cyberforsikring",
  "forsikring_pris_fritidsulykkeforsikring",
  "forsikring_pris_reiseforsikring",
  "forsikring_pris_salongforsikring_niva1",
  "forsikring_pris_yrkesskadeforsikring",
  "forsikring_reiseforsikring",
  "forsikring_salongforsikring",
  "forsikring_salongforsikring_niva",
  "forsikring_status_helse",
  "forsikring_sum_fritidsulykkeforsikring",
  "forsikring_sum_mvil",
  "forsikring_sum_reiseforsikring",
  "forsikring_sum_totalt",
  "forsikring_sum_yrkesskadeforsikring",
  "forsikring_yrkesskadeforsikring",
  // New fields
  "bytter_selskap_forsikring",
  "tidligere_forsikringer",
  "forsikring_bestillingsdato",
  "forsikring_oppstartsdato",
  // Health insurance company fields
  "helseforsikring",
  "helseforsikring_avtalenummer",
  "helseforsikring_oppstartsdato",
  "helseforsikring_premie",
  "helseforsikrings_oppsigelses_dato",
];

// Health insurance properties from HubSpot (contact level)
const HEALTH_INSURANCE_PROPERTIES = [
  "helseforsikring",
  "helseforsikring_oppstartsdato",
  "helseforsikrings_oppsigelses_dato",
];

// Health insurance properties at company level (new)
const HEALTH_INSURANCE_COMPANY_PROPERTIES = [
  "helseforsikring",
  "helseforsikring_avtalenummer",
  "helseforsikring_oppstartsdato",
  "helseforsikring_premie",
  "helseforsikrings_oppsigelses_dato",
];

async function getValidAccessToken(supabase: any): Promise<string> {
  const { data: tokenData, error } = await supabase
    .from("hubspot_oauth_tokens")
    .select("*")
    .limit(1)
    .single();

  if (error || !tokenData) {
    throw new Error("HubSpot is not connected");
  }

  const expiresAt = new Date(tokenData.expires_at);
  const fiveMinutesFromNow = new Date(Date.now() + 5 * 60 * 1000);

  if (expiresAt > fiveMinutesFromNow) {
    return tokenData.access_token;
  }

  console.log("Access token expired, refreshing...");
  
  const refreshResponse = await fetch("https://api.hubapi.com/oauth/v1/token", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: new URLSearchParams({
      grant_type: "refresh_token",
      client_id: HUBSPOT_CLIENT_ID!,
      client_secret: HUBSPOT_CLIENT_SECRET!,
      refresh_token: tokenData.refresh_token,
    }),
  });

  if (!refreshResponse.ok) {
    const errorText = await refreshResponse.text();
    console.error("Token refresh failed:", errorText);
    throw new Error("Failed to refresh HubSpot token");
  }

  const newTokens = await refreshResponse.json();
  const newExpiresAt = new Date(Date.now() + newTokens.expires_in * 1000);

  await supabase
    .from("hubspot_oauth_tokens")
    .update({
      access_token: newTokens.access_token,
      refresh_token: newTokens.refresh_token,
      expires_at: newExpiresAt.toISOString(),
      updated_at: new Date().toISOString(),
    })
    .eq("id", tokenData.id);

  return newTokens.access_token;
}

async function hubspotRequest(accessToken: string, endpoint: string, options: RequestInit = {}) {
  const response = await fetch(`https://api.hubapi.com${endpoint}`, {
    ...options,
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
      ...options.headers,
    },
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error(`HubSpot API error (${endpoint}):`, errorText);
    throw new Error(`HubSpot API error: ${response.status}`);
  }

  return response.json();
}

// Helper function to normalize type_medlemskap for HubSpot
// HubSpot expects: Salong, Skole, Stol, Hjemmesalong, Barber (capitalized)
function normalizeTypeMedlemskap(value: string | null | undefined): string | null {
  if (!value) return null;
  
  const mapping: Record<string, string> = {
    'salong': 'Salong',
    'skole': 'Skole',
    'stol': 'Stol',
    'hjemmesalong': 'Hjemmesalong',
    'barber': 'Barber',
  };
  
  const normalized = mapping[value.toLowerCase()];
  return normalized || value; // Return original if not in mapping
}

// Helper function to normalize medlmestype (membership status) for HubSpot
// HubSpot expects: Medlem, Pause, Oppsagt, Innkasso, Utmeldt, Konkurs (capitalized)
function normalizeMedlmestype(value: string | null | undefined): string | null {
  if (!value) return null;
  
  const mapping: Record<string, string> = {
    'medlem': 'Medlem',
    'pause': 'Pause',
    'oppsagt': 'Oppsagt',
    'innkasso': 'Innkasso',
    'utmeldt': 'Utmeldt',
    'konkurs': 'Konkurs',
  };
  
  const normalized = mapping[value.toLowerCase()];
  return normalized || value; // Return original if not in mapping
}

// Helper function to normalize properties before sending to HubSpot
function normalizePropertiesForHubSpot(properties: Record<string, any>): Record<string, any> {
  const normalized = { ...properties };
  
  if (normalized.type_medlemskap) {
    normalized.type_medlemskap = normalizeTypeMedlemskap(normalized.type_medlemskap);
  }
  
  if (normalized.medlmestype) {
    normalized.medlmestype = normalizeMedlmestype(normalized.medlmestype);
  }
  
  return normalized;
}

// Helper function to parse HubSpot insurance data
function parseInsuranceData(properties: any) {
  const parseBoolean = (val: string | undefined) => val === "Ja" || val === "true";
  const parseNumber = (val: string | undefined) => val ? parseFloat(val) : null;
  const parseDate = (val: string | undefined) => val || null;

  return {
    aktivering_dato: parseDate(properties.dato_for_aktivering_av_forsikring),
    innmelding_dato: parseDate(properties.dato_for_innmelding_av_forsikring),
    oppsigelse_dato: parseDate(properties.dato_for_oppsigelse_av_forsikring),
    avsluttede_forsikringer: parseBoolean(properties.avsluttede_forsikringser),
    helse_status: parseBoolean(properties.forsikring_status_helse),
    antall_ansatte: parseNumber(properties.forsikring_antall_ansatte),
    antall_arsverk: parseNumber(properties.forsikring_antall_arsverk),
    antall_fritidsulykke: parseNumber(properties.forsikring_antall_personer_fritidsulykke),
    antall_reiseforsikring: parseNumber(properties.forsikring_antall_personer_reiseforsikring),
    arlig_omsetning: parseNumber(properties.forsikring_arlig_omsetning__nok_),
    cyber_aktiv: parseBoolean(properties.forsikring_cyberforsikring),
    fritidsulykke_aktiv: parseBoolean(properties.forsikring_fritidsulykkeforsikring),
    reise_aktiv: parseBoolean(properties.forsikring_reiseforsikring),
    salong_aktiv: parseBoolean(properties.forsikring_salongforsikring),
    yrkesskadeforsikring_aktiv: parseBoolean(properties.forsikring_yrkesskadeforsikring),
    salong_niva: properties.forsikring_salongforsikring_niva || null,
    sum_mvil: properties.forsikring_sum_mvil || null,
    pris_cyber: parseNumber(properties.forsikring_pris_cyberforsikring),
    pris_fritidsulykke: parseNumber(properties.forsikring_pris_fritidsulykkeforsikring),
    pris_reise: parseNumber(properties.forsikring_pris_reiseforsikring),
    pris_salong: parseNumber(properties.forsikring_pris_salongforsikring_niva1),
    pris_yrkesskadeforsikring: parseNumber(properties.forsikring_pris_yrkesskadeforsikring),
    sum_fritidsulykke: parseNumber(properties.forsikring_sum_fritidsulykkeforsikring),
    sum_reise: parseNumber(properties.forsikring_sum_reiseforsikring),
    sum_totalt: parseNumber(properties.forsikring_sum_totalt),
    sum_yrkesskadeforsikring: parseNumber(properties.forsikring_sum_yrkesskadeforsikring),
    kontaktperson_navn: properties.forsikring_kontaktperson || null,
    kontaktperson_epost: properties.forsikring_e_post || null,
    // New fields
    bytter_selskap: properties.bytter_selskap_forsikring === "true",
    tidligere_forsikringer: properties.tidligere_forsikringer || null,
    bestillingsdato: parseDate(properties.forsikring_bestillingsdato),
    oppstartsdato: parseDate(properties.forsikring_oppstartsdato),
    // Health insurance company-level fields
    helseforsikring_status: properties.helseforsikring || null,
    helseforsikring_avtalenummer: properties.helseforsikring_avtalenummer || null,
    helseforsikring_oppstartsdato: parseDate(properties.helseforsikring_oppstartsdato),
    helseforsikring_premie: parseNumber(properties.helseforsikring_premie),
    helseforsikring_oppsigelsesdato: parseDate(properties.helseforsikrings_oppsigelses_dato),
  };
}

// Fixed unit prices - ALLTID bruk disse verdiene
const FIXED_UNIT_PRICES = {
  yrkesskade: 1499,
  reise: 1499,
  fritidsulykke: 949,
  cyber: 949,
};

// Helper function to apply FIXED unit prices - ALLTID overskriver eksisterende verdier
async function applyDefaultPrices(supabase: any, insuranceData: any) {
  const result = { ...insuranceData };

  // Fetch salong tier prices from database (variable priser per nivå)
  const { data: tiers } = await supabase
    .from('insurance_product_tiers')
    .select('tier_name, price')
    .eq('product_id', 'eaafac64-d835-49dd-9eaa-0da9fcee2431'); // Salongforsikring product ID

  const salongTierPrices: Record<string, number> = {};
  for (const t of tiers || []) {
    salongTierPrices[t.tier_name] = parseFloat(t.price);
  }

  // ALLTID sett faste enhetspriser for aktive forsikringer (ignorer HubSpot-verdier)
  if (result.cyber_aktiv) {
    result.pris_cyber = FIXED_UNIT_PRICES.cyber;
    console.log(`Set fixed cyber unit price: ${result.pris_cyber}`);
  }

  if (result.fritidsulykke_aktiv) {
    result.pris_fritidsulykke = FIXED_UNIT_PRICES.fritidsulykke;
    console.log(`Set fixed fritidsulykke unit price: ${result.pris_fritidsulykke}`);
  }

  if (result.reise_aktiv) {
    result.pris_reise = FIXED_UNIT_PRICES.reise;
    console.log(`Set fixed reise unit price: ${result.pris_reise}`);
  }

  if (result.yrkesskadeforsikring_aktiv) {
    result.pris_yrkesskadeforsikring = FIXED_UNIT_PRICES.yrkesskade;
    console.log(`Set fixed yrkesskadeforsikring unit price: ${result.pris_yrkesskadeforsikring}`);
  }

  // Salong uses tier prices from database
  if (result.salong_aktiv && result.salong_niva) {
    const tierPrice = salongTierPrices[result.salong_niva];
    if (tierPrice) {
      result.pris_salong = tierPrice;
      console.log(`Set salong price for ${result.salong_niva}: ${result.pris_salong}`);
    }
  }

  return result;
}

// Helper function to ALLTID calculate sum fields based on fixed prices and quantities
function applyDefaultSums(insuranceData: any) {
  const result = { ...insuranceData };

  // ALLTID beregn sum_yrkesskadeforsikring = pris × antall_arsverk (ingen betingelse)
  if (result.yrkesskadeforsikring_aktiv && result.pris_yrkesskadeforsikring && result.antall_arsverk) {
    result.sum_yrkesskadeforsikring = result.pris_yrkesskadeforsikring * result.antall_arsverk;
    console.log(`Recalculated sum_yrkesskadeforsikring: ${result.pris_yrkesskadeforsikring} × ${result.antall_arsverk} = ${result.sum_yrkesskadeforsikring}`);
  } else if (!result.yrkesskadeforsikring_aktiv) {
    result.sum_yrkesskadeforsikring = null;
  }

  // ALLTID beregn sum_reise = pris × antall_reiseforsikring (ingen betingelse)
  if (result.reise_aktiv && result.pris_reise && result.antall_reiseforsikring) {
    result.sum_reise = result.pris_reise * result.antall_reiseforsikring;
    console.log(`Recalculated sum_reise: ${result.pris_reise} × ${result.antall_reiseforsikring} = ${result.sum_reise}`);
  } else if (!result.reise_aktiv) {
    result.sum_reise = null;
  }

  // ALLTID beregn sum_fritidsulykke = pris × antall_fritidsulykke (ingen betingelse)
  if (result.fritidsulykke_aktiv && result.pris_fritidsulykke && result.antall_fritidsulykke) {
    result.sum_fritidsulykke = result.pris_fritidsulykke * result.antall_fritidsulykke;
    console.log(`Recalculated sum_fritidsulykke: ${result.pris_fritidsulykke} × ${result.antall_fritidsulykke} = ${result.sum_fritidsulykke}`);
  } else if (!result.fritidsulykke_aktiv) {
    result.sum_fritidsulykke = null;
  }

  // ALLTID beregn sum_totalt på nytt (ingen betingelse)
  let total = 0;
  
  // Salong (uses pris directly, no separate sum)
  if (result.salong_aktiv && result.pris_salong) {
    total += result.pris_salong;
  }
  
  // Yrkesskade (uses calculated sum)
  if (result.yrkesskadeforsikring_aktiv && result.sum_yrkesskadeforsikring) {
    total += result.sum_yrkesskadeforsikring;
  }
  
  // Cyber (uses pris directly, no separate sum)
  if (result.cyber_aktiv && result.pris_cyber) {
    total += result.pris_cyber;
  }
  
  // Fritidsulykke (uses calculated sum)
  if (result.fritidsulykke_aktiv && result.sum_fritidsulykke) {
    total += result.sum_fritidsulykke;
  }
  
  // Reise (uses calculated sum)
  if (result.reise_aktiv && result.sum_reise) {
    total += result.sum_reise;
  }

  result.sum_totalt = total;
  console.log(`Recalculated sum_totalt: ${result.sum_totalt}`);

  return result;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Validate authentication
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      console.error("No authorization header provided");
      return new Response(JSON.stringify({ error: 'Unauthorized' }), { 
        status: 401, 
        headers: { ...corsHeaders, "Content-Type": "application/json" } 
      });
    }

    // Create a client with the user's auth header to verify their session
    const supabaseAuth = createClient(
      SUPABASE_URL!,
      Deno.env.get('SUPABASE_ANON_KEY')!,
      { global: { headers: { Authorization: authHeader } } }
    );
    
    // Verify the user's JWT token
    const { data: { user }, error: authError } = await supabaseAuth.auth.getUser();
    if (authError || !user) {
      console.error("Invalid token:", authError?.message);
      return new Response(JSON.stringify({ error: 'Invalid token' }), { 
        status: 401, 
        headers: { ...corsHeaders, "Content-Type": "application/json" } 
      });
    }

    // Create service role client for admin operations
    const supabase = createClient(SUPABASE_URL!, SUPABASE_SERVICE_ROLE_KEY!);

    // Check if user has admin role
    const { data: roleData, error: roleError } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id)
      .eq('role', 'admin')
      .maybeSingle();

    if (roleError || !roleData) {
      console.error("User does not have admin role:", user.id);
      return new Response(JSON.stringify({ error: 'Forbidden: Admin access required' }), { 
        status: 403, 
        headers: { ...corsHeaders, "Content-Type": "application/json" } 
      });
    }

    console.log(`HubSpot API request by admin user: ${user.id}`);
    const accessToken = await getValidAccessToken(supabase);
    const { action, ...params } = await req.json();

    console.log(`HubSpot API action: ${action}`);

    // Standard company properties to fetch (including custom Hår1 properties)
    const COMPANY_PROPERTIES = [
      "name", "domain", "city", "phone", "industry", "address", "zip", 
      "hubspot_owner_id", "orgnr", "lifecyclestage", "type", "hs_object_id",
      // Custom Hår1 properties
      "medlemsavgift", "medlmestype", "type_medlemskap", "bankkontonummer", "kundenummer",
      // Supplier identification
      "samarbeidspartnerleverandr",
      // Date fields
      "start_medlemskap_dato", "oppsigelsesdato_for_medlemskap", "avsluttet_medlemskap_dato",
      "registreringsdato", "utlpsdato_for_medlemskap",
      // BRREG financial fields
      "ar_reg_omsetning", "reg_omsetning", "reg_resultat"
    ];

    switch (action) {
      case "search_companies": {
        const { query } = params;
        const result = await hubspotRequest(accessToken, "/crm/v3/objects/companies/search", {
          method: "POST",
          body: JSON.stringify({
            filterGroups: [
              {
                filters: [
                  {
                    propertyName: "name",
                    operator: "CONTAINS_TOKEN",
                    value: query,
                  },
                ],
              },
            ],
            properties: COMPANY_PROPERTIES,
            limit: 20,
          }),
        });

        // Fetch owner details for each company that has an owner
        const companiesWithOwners = await Promise.all(
          (result.results || []).map(async (company: any) => {
            const ownerId = company.properties?.hubspot_owner_id;
            if (ownerId) {
              try {
                const owner = await hubspotRequest(accessToken, `/crm/v3/owners/${ownerId}`);
                return {
                  ...company,
                  owner: {
                    id: owner.id,
                    email: owner.email,
                    firstName: owner.firstName,
                    lastName: owner.lastName,
                  },
                };
              } catch (e) {
                console.error(`Could not fetch owner ${ownerId}:`, e);
                return company;
              }
            }
            return company;
          })
        );

        return new Response(JSON.stringify({ ...result, results: companiesWithOwners }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "batch_get_companies": {
        const { companyIds } = params;
        
        if (!companyIds || !Array.isArray(companyIds) || companyIds.length === 0) {
          return new Response(JSON.stringify({ error: "companyIds array is required" }), {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        console.log(`Batch fetching ${companyIds.length} companies from HubSpot`);
        
        // HubSpot batch read API allows up to 100 IDs per request
        const BATCH_SIZE = 100;
        const allResults: any[] = [];
        
        for (let i = 0; i < companyIds.length; i += BATCH_SIZE) {
          const batch = companyIds.slice(i, i + BATCH_SIZE);
          console.log(`Fetching batch ${Math.floor(i / BATCH_SIZE) + 1}: ${batch.length} companies`);
          
          try {
            const result = await hubspotRequest(accessToken, "/crm/v3/objects/companies/batch/read", {
              method: "POST",
              body: JSON.stringify({
                inputs: batch.map((id: string) => ({ id })),
                properties: ["name", "medlmestype", "hubspot_owner_id"],
              }),
            });
            
            if (result.results) {
              allResults.push(...result.results);
            }
          } catch (batchError) {
            console.error(`Batch fetch error for batch starting at ${i}:`, batchError);
            // Continue with other batches even if one fails
          }
        }

        console.log(`Successfully fetched ${allResults.length} companies in batch`);
        
        return new Response(JSON.stringify({ results: allResults }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "search_suppliers": {
        const { query } = params;
        // Search for companies with samarbeidspartnerleverandr = "true" (checkbox internal value)
        const filterGroups = query
          ? [
              {
                filters: [
                  { propertyName: "name", operator: "CONTAINS_TOKEN", value: query },
                  { propertyName: "samarbeidspartnerleverandr", operator: "EQ", value: "true" },
                ],
              },
            ]
          : [
              {
                filters: [
                  { propertyName: "samarbeidspartnerleverandr", operator: "EQ", value: "true" },
                ],
              },
            ];

        const result = await hubspotRequest(accessToken, "/crm/v3/objects/companies/search", {
          method: "POST",
          body: JSON.stringify({
            filterGroups,
            properties: COMPANY_PROPERTIES,
            limit: 50,
          }),
        });

        console.log(`Found ${result.results?.length || 0} suppliers`);

        return new Response(JSON.stringify(result), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "search_companies_by_status": {
        const { status } = params;
        
        console.log(`Searching ALL HubSpot companies with medlmestype = ${status}`);
        
        let allResults: any[] = [];
        let after: string | undefined = undefined;
        let pageCount = 0;
        const maxPages = 50; // Safety limit to prevent infinite loops
        
        // Paginate through all results
        do {
          const searchBody: any = {
            filterGroups: [
              {
                filters: [
                  { propertyName: "medlmestype", operator: "EQ", value: status },
                ],
              },
            ],
            properties: COMPANY_PROPERTIES,
            limit: 100,
          };
          
          if (after) {
            searchBody.after = after;
          }

          const result = await hubspotRequest(accessToken, "/crm/v3/objects/companies/search", {
            method: "POST",
            body: JSON.stringify(searchBody),
          });

          if (result.results && result.results.length > 0) {
            allResults = [...allResults, ...result.results];
          }
          
          after = result.paging?.next?.after;
          pageCount++;
          
          console.log(`Page ${pageCount}: Found ${result.results?.length || 0} companies, total: ${allResults.length}`);
          
        } while (after && pageCount < maxPages);

        console.log(`Total found: ${allResults.length} companies with status ${status}`);

        return new Response(JSON.stringify({ results: allResults, total: allResults.length }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "get_owners": {
        const result = await hubspotRequest(accessToken, "/crm/v3/owners?limit=100");
        return new Response(JSON.stringify(result), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "search_contacts": {
        const { query } = params;
        // Search by email OR by name
        const result = await hubspotRequest(accessToken, "/crm/v3/objects/contacts/search", {
          method: "POST",
          body: JSON.stringify({
            filterGroups: [
              {
                filters: [
                  {
                    propertyName: "email",
                    operator: "CONTAINS_TOKEN",
                    value: query,
                  },
                ],
              },
              {
                filters: [
                  {
                    propertyName: "firstname",
                    operator: "CONTAINS_TOKEN",
                    value: query,
                  },
                ],
              },
              {
                filters: [
                  {
                    propertyName: "lastname",
                    operator: "CONTAINS_TOKEN",
                    value: query,
                  },
                ],
              },
            ],
            properties: ["firstname", "lastname", "email", "phone", "company", "stilling"],
            limit: 20,
          }),
        });

        return new Response(JSON.stringify(result), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "get_company": {
        const { companyId } = params;
        const result = await hubspotRequest(
          accessToken,
          `/crm/v3/objects/companies/${companyId}?properties=${COMPANY_PROPERTIES.join(",")}`
        );

        // Fetch owner details if company has an owner
        if (result.properties?.hubspot_owner_id) {
          try {
            const owner = await hubspotRequest(accessToken, `/crm/v3/owners/${result.properties.hubspot_owner_id}`);
            result.owner = {
              id: owner.id,
              email: owner.email,
              firstName: owner.firstName,
              lastName: owner.lastName,
            };
          } catch (e) {
            console.error("Could not fetch owner:", e);
          }
        }

        return new Response(JSON.stringify(result), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "get_company_contacts": {
        const { companyId, includeHealthInsurance } = params;
        console.log(`Fetching contacts for company ${companyId}, includeHealthInsurance: ${includeHealthInsurance}`);
        
        // First get associated contact IDs using HubSpot Associations API v4
        const associations = await hubspotRequest(
          accessToken,
          `/crm/v4/objects/company/${companyId}/associations/contact`
        );
        
        console.log(`Found ${associations.results?.length || 0} associated contacts`);
        
        if (!associations.results || associations.results.length === 0) {
          return new Response(JSON.stringify({ contacts: [] }), {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        
        // Get the contact IDs
        const contactIds = associations.results.map((assoc: any) => assoc.toObjectId);
        
        // Build properties list - include health insurance if requested
        const contactProperties = ["firstname", "lastname", "email", "phone", "stilling", "leverandrrolle"];
        if (includeHealthInsurance) {
          contactProperties.push(...HEALTH_INSURANCE_PROPERTIES);
        }
        
        // Fetch contact details in batch
        const contactsResult = await hubspotRequest(accessToken, "/crm/v3/objects/contacts/batch/read", {
          method: "POST",
          body: JSON.stringify({
            properties: contactProperties,
            inputs: contactIds.map((id: string) => ({ id })),
          }),
        });
        
        const contacts = (contactsResult.results || []).map((contact: any) => ({
          id: contact.id,
          properties: {
            firstname: contact.properties?.firstname || "",
            lastname: contact.properties?.lastname || "",
            email: contact.properties?.email || "",
            phone: contact.properties?.phone || "",
            stilling: contact.properties?.stilling || "",
            leverandrrolle: contact.properties?.leverandrrolle || "",
            // Health insurance fields
            helseforsikring: contact.properties?.helseforsikring || null,
            helseforsikring_oppstartsdato: contact.properties?.helseforsikring_oppstartsdato || null,
            helseforsikrings_oppsigelses_dato: contact.properties?.helseforsikrings_oppsigelses_dato || null,
          },
        }));
        
        console.log(`Returning ${contacts.length} contacts with details`);
        
        return new Response(JSON.stringify({ contacts }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "get_contact": {
        const { contactId } = params;
        const result = await hubspotRequest(
          accessToken,
          `/crm/v3/objects/contacts/${contactId}?properties=firstname,lastname,email,phone,company,stilling`
        );

        return new Response(JSON.stringify(result), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "create_company": {
        const { properties, hubspot_owner_id } = params;
        const normalizedProperties = normalizePropertiesForHubSpot(properties);
        const companyProperties = {
          ...normalizedProperties,
          ...(hubspot_owner_id && { hubspot_owner_id }),
        };
        const result = await hubspotRequest(accessToken, "/crm/v3/objects/companies", {
          method: "POST",
          body: JSON.stringify({ properties: companyProperties }),
        });

        return new Response(JSON.stringify(result), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "update_company": {
        const { companyId, properties } = params;
        const normalizedProperties = normalizePropertiesForHubSpot(properties);
        const result = await hubspotRequest(accessToken, `/crm/v3/objects/companies/${companyId}`, {
          method: "PATCH",
          body: JSON.stringify({ properties: normalizedProperties }),
        });

        return new Response(JSON.stringify(result), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "create_contact": {
        const { properties, hubspot_owner_id } = params;
        const contactProperties = {
          ...properties,
          ...(hubspot_owner_id && { hubspot_owner_id }),
        };
        const result = await hubspotRequest(accessToken, "/crm/v3/objects/contacts", {
          method: "POST",
          body: JSON.stringify({ properties: contactProperties }),
        });

        return new Response(JSON.stringify(result), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "update_contact": {
        const { contactId, properties } = params;
        const result = await hubspotRequest(accessToken, `/crm/v3/objects/contacts/${contactId}`, {
          method: "PATCH",
          body: JSON.stringify({ properties }),
        });

        return new Response(JSON.stringify(result), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "get_company_properties": {
        const { propertyNames } = params;
        const properties: Record<string, Array<{label: string, value: string}>> = {};
        
        // Fetch all company properties
        const allProps = await hubspotRequest(accessToken, "/crm/v3/properties/companies");
        
        // Filter to requested properties and extract options for enumeration types
        for (const prop of allProps.results || []) {
          if (propertyNames.includes(prop.name) && prop.type === "enumeration" && prop.options) {
            properties[prop.name] = prop.options.map((opt: any) => ({
              label: opt.label,
              value: opt.value,
            }));
          }
        }
        
        console.log("Fetched property options for:", Object.keys(properties));
        
        return new Response(JSON.stringify({ properties }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      // Insurance-specific actions
      case "get_company_insurance": {
        const { companyId } = params;
        console.log(`Fetching insurance data for company ${companyId}`);
        
        const result = await hubspotRequest(
          accessToken,
          `/crm/v3/objects/companies/${companyId}?properties=${INSURANCE_PROPERTIES.join(",")}`
        );

        const insuranceData = parseInsuranceData(result.properties);
        
        return new Response(JSON.stringify({ 
          companyId,
          properties: result.properties,
          parsed: insuranceData
        }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "sync_salon_insurance": {
        const { salonId, hubspotCompanyId } = params;
        console.log(`Syncing insurance for salon ${salonId} from HubSpot company ${hubspotCompanyId}`);
        
        // Fetch insurance data from HubSpot
        const result = await hubspotRequest(
          accessToken,
          `/crm/v3/objects/companies/${hubspotCompanyId}?properties=${INSURANCE_PROPERTIES.join(",")}`
        );

        const rawInsuranceData = parseInsuranceData(result.properties);
        const insuranceDataWithPrices = await applyDefaultPrices(supabase, rawInsuranceData);
        const insuranceData = applyDefaultSums(insuranceDataWithPrices);
        
        // Also fetch health insurance from contacts
        let helseAntallAktive = 0;
        const healthInsuranceContacts: any[] = [];
        
        try {
          const associations = await hubspotRequest(
            accessToken,
            `/crm/v4/objects/company/${hubspotCompanyId}/associations/contact`
          );
          
          if (associations.results && associations.results.length > 0) {
            const contactIds = associations.results.map((assoc: any) => assoc.toObjectId);
            
            const contactsResult = await hubspotRequest(accessToken, "/crm/v3/objects/contacts/batch/read", {
              method: "POST",
              body: JSON.stringify({
                properties: ["firstname", "lastname", "email", ...HEALTH_INSURANCE_PROPERTIES],
                inputs: contactIds.map((id: string) => ({ id })),
              }),
            });
            
            for (const contact of contactsResult.results || []) {
              const status = contact.properties?.helseforsikring;
              if (status) {
                healthInsuranceContacts.push({
                  hubspot_contact_id: contact.id,
                  email: contact.properties?.email,
                  name: `${contact.properties?.firstname || ''} ${contact.properties?.lastname || ''}`.trim(),
                  status: status,
                  oppstartsdato: contact.properties?.helseforsikring_oppstartsdato,
                  oppsigelsesdato: contact.properties?.helseforsikrings_oppsigelses_dato,
                });
                
                if (status === 'Aktiv') {
                  helseAntallAktive++;
                }
                
                // Update user if they exist in our system
                if (contact.properties?.email) {
                  // Get health insurance price
                  const { data: helseProduct } = await supabase
                    .from('insurance_products')
                    .select('base_price')
                    .eq('product_type', 'helse')
                    .single();
                  const helsePris = (helseProduct?.base_price && status === 'Aktiv') 
                    ? parseFloat(helseProduct.base_price) 
                    : null;
                  
                  await supabase
                    .from('users')
                    .update({
                      helseforsikring_status: status,
                      helseforsikring_oppstartsdato: contact.properties?.helseforsikring_oppstartsdato || null,
                      helseforsikring_oppsigelsesdato: contact.properties?.helseforsikrings_oppsigelses_dato || null,
                      helseforsikring_pris: helsePris,
                    })
                    .eq('email', contact.properties.email);
                }
              }
            }
          }
        } catch (e) {
          console.error("Error fetching health insurance from contacts:", e);
        }
        
        // Calculate helse_status based on contacts
        const helseStatus = helseAntallAktive > 0;
        
        // Upsert into salon_insurance table
        const { data, error } = await supabase
          .from('salon_insurance')
          .upsert({
            salon_id: salonId,
            hubspot_company_id: hubspotCompanyId,
            hubspot_synced_at: new Date().toISOString(),
            ...insuranceData,
            helse_status: helseStatus,
            helse_antall_aktive: helseAntallAktive,
          }, {
            onConflict: 'salon_id'
          })
          .select()
          .single();

        if (error) {
          console.error("Error upserting insurance data:", error);
          throw new Error(`Database error: ${error.message}`);
        }
        
        console.log(`Successfully synced insurance for salon ${salonId}, ${helseAntallAktive} active health insurance`);
        
        return new Response(JSON.stringify({ 
          success: true,
          data,
          healthInsuranceContacts
        }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "sync_all_insurance": {
        console.log("Starting batch insurance sync for all salons with HubSpot IDs");
        
        // Get all salons with HubSpot company IDs
        const { data: salons, error: salonsError } = await supabase
          .from('salons')
          .select('id, hs_object_id, name')
          .not('hs_object_id', 'is', null);

        if (salonsError) {
          throw new Error(`Failed to fetch salons: ${salonsError.message}`);
        }

        console.log(`Found ${salons?.length || 0} salons with HubSpot IDs`);
        
        const results = {
          synced: 0,
          failed: 0,
          errors: [] as string[]
        };

        for (const salon of salons || []) {
          try {
            // Fetch company insurance data
            const result = await hubspotRequest(
              accessToken,
              `/crm/v3/objects/companies/${salon.hs_object_id}?properties=${INSURANCE_PROPERTIES.join(",")}`
            );

            const rawInsuranceData = parseInsuranceData(result.properties);
            const insuranceDataWithPrices = await applyDefaultPrices(supabase, rawInsuranceData);
            const insuranceData = applyDefaultSums(insuranceDataWithPrices);
            
            // Fetch health insurance from contacts
            let helseAntallAktive = 0;
            try {
              const associations = await hubspotRequest(
                accessToken,
                `/crm/v4/objects/company/${salon.hs_object_id}/associations/contact`
              );
              
              if (associations.results && associations.results.length > 0) {
                const contactIds = associations.results.map((assoc: any) => assoc.toObjectId);
                
                const contactsResult = await hubspotRequest(accessToken, "/crm/v3/objects/contacts/batch/read", {
                  method: "POST",
                  body: JSON.stringify({
                    properties: ["email", ...HEALTH_INSURANCE_PROPERTIES],
                    inputs: contactIds.map((id: string) => ({ id })),
                  }),
                });
                
                for (const contact of contactsResult.results || []) {
                  const status = contact.properties?.helseforsikring;
                  if (status === 'Aktiv') {
                    helseAntallAktive++;
                  }
                  
                  // Update user if they exist
                  if (contact.properties?.email && status) {
                    // Get health insurance price
                    const { data: helseProduct } = await supabase
                      .from('insurance_products')
                      .select('base_price')
                      .eq('product_type', 'helse')
                      .single();
                    const helsePris = (helseProduct?.base_price && status === 'Aktiv') 
                      ? parseFloat(helseProduct.base_price) 
                      : null;
                    
                    await supabase
                      .from('users')
                      .update({
                        helseforsikring_status: status,
                        helseforsikring_oppstartsdato: contact.properties?.helseforsikring_oppstartsdato || null,
                        helseforsikring_oppsigelsesdato: contact.properties?.helseforsikrings_oppsigelses_dato || null,
                        helseforsikring_pris: helsePris,
                      })
                      .eq('email', contact.properties.email);
                  }
                }
              }
            } catch (e) {
              console.error(`Error fetching health insurance for ${salon.name}:`, e);
            }
            
            const { error } = await supabase
              .from('salon_insurance')
              .upsert({
                salon_id: salon.id,
                hubspot_company_id: salon.hs_object_id,
                hubspot_synced_at: new Date().toISOString(),
                ...insuranceData,
                helse_status: helseAntallAktive > 0,
                helse_antall_aktive: helseAntallAktive,
              }, {
                onConflict: 'salon_id'
              });

            if (error) {
              throw error;
            }
            
            results.synced++;
          } catch (e) {
            results.failed++;
            results.errors.push(`${salon.name}: ${e instanceof Error ? e.message : 'Unknown error'}`);
          }
        }

        console.log(`Batch sync complete: ${results.synced} synced, ${results.failed} failed`);
        
        return new Response(JSON.stringify(results), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "import_insured_salons": {
        console.log("Starting import of all salons with active insurance from HubSpot");
        
        // Search for companies with active insurance (not terminated)
        // Using forsikring_salongforsikring = "Ja" as the main indicator
        let allCompanies: any[] = [];
        let after: string | undefined = undefined;
        
        // Paginate through all results
        do {
          const searchBody: any = {
            filterGroups: [
              {
                filters: [
                  {
                    propertyName: "forsikring_salongforsikring",
                    operator: "EQ",
                    value: "Ja",
                  },
                ],
              },
            ],
            properties: [
              "name", "domain", "city", "phone", "address", "zip", 
              "orgnr", "hubspot_owner_id", "hs_object_id",
              ...INSURANCE_PROPERTIES
            ],
            limit: 100,
          };
          
          if (after) {
            searchBody.after = after;
          }
          
          const result = await hubspotRequest(accessToken, "/crm/v3/objects/companies/search", {
            method: "POST",
            body: JSON.stringify(searchBody),
          });
          
          allCompanies = allCompanies.concat(result.results || []);
          after = result.paging?.next?.after;
          
          console.log(`Fetched ${result.results?.length || 0} companies, total: ${allCompanies.length}`);
        } while (after);
        
        console.log(`Found ${allCompanies.length} companies with active insurance`);
        
        // Filter out terminated insurance
        const activeCompanies = allCompanies.filter(company => {
          const terminated = company.properties?.avsluttede_forsikringser;
          return terminated !== "Ja" && terminated !== "true";
        });
        
        console.log(`${activeCompanies.length} companies have non-terminated insurance`);
        
        // Get existing salons by hs_object_id
        const { data: existingSalons } = await supabase
          .from('salons')
          .select('hs_object_id');
        
        const existingHubspotIds = new Set((existingSalons || []).map(s => s.hs_object_id));
        
        const importResults = {
          imported: 0,
          skipped: 0,
          failed: 0,
          errors: [] as string[],
          importedSalons: [] as string[]
        };

        for (const company of activeCompanies) {
          const hubspotId = company.id;
          const companyName = company.properties?.name || 'Ukjent';
          
          // Skip if already exists
          if (existingHubspotIds.has(hubspotId)) {
            importResults.skipped++;
            continue;
          }
          
          try {
            // Map HubSpot owner to district
            let districtId = null;
            if (company.properties?.hubspot_owner_id) {
              const { data: ownerMapping } = await supabase
                .from('hubspot_owner_district_mapping')
                .select('district_id')
                .eq('hubspot_owner_id', company.properties.hubspot_owner_id)
                .maybeSingle();
              
              if (ownerMapping) {
                districtId = ownerMapping.district_id;
              }
            }
            
            // Create the salon
            const { data: newSalon, error: salonError } = await supabase
              .from('salons')
              .insert({
                name: companyName,
                hs_object_id: hubspotId,
                hubspot_synced_at: new Date().toISOString(),
                org_number: company.properties?.orgnr || null,
                address: company.properties?.address || null,
                city: company.properties?.city || null,
                district_id: districtId,
              })
              .select()
              .single();

            if (salonError) {
              throw salonError;
            }
            
            // Parse and insert insurance data
            const rawInsuranceData = parseInsuranceData(company.properties);
            const insuranceDataWithPrices = await applyDefaultPrices(supabase, rawInsuranceData);
            const insuranceData = applyDefaultSums(insuranceDataWithPrices);
            
            const { error: insuranceError } = await supabase
              .from('salon_insurance')
              .insert({
                salon_id: newSalon.id,
                hubspot_company_id: hubspotId,
                hubspot_synced_at: new Date().toISOString(),
                ...insuranceData,
              });

            if (insuranceError) {
              console.error(`Error inserting insurance for ${companyName}:`, insuranceError);
            }
            
            importResults.imported++;
            importResults.importedSalons.push(companyName);
            
          } catch (e) {
            importResults.failed++;
            importResults.errors.push(`${companyName}: ${e instanceof Error ? e.message : 'Unknown error'}`);
          }
        }

        console.log(`Import complete: ${importResults.imported} imported, ${importResults.skipped} skipped, ${importResults.failed} failed`);
        
        return new Response(JSON.stringify(importResults), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "sync_insurance_to_hubspot": {
        // Sync local insurance data to HubSpot (App → HubSpot)
        const { salonId } = params;
        
        console.log(`Syncing insurance data for salon ${salonId} to HubSpot`);
        
        // Get salon with HubSpot ID
        const { data: salon, error: salonError } = await supabase
          .from('salons')
          .select('id, name, hs_object_id')
          .eq('id', salonId)
          .single();
        
        if (salonError || !salon) {
          throw new Error(`Salon not found: ${salonId}`);
        }
        
        if (!salon.hs_object_id) {
          console.log("Salon has no HubSpot company ID, skipping sync");
          return new Response(JSON.stringify({ 
            success: false, 
            message: "Salon has no HubSpot company ID" 
          }), {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        
        // Get current local insurance data
        const { data: insurance, error: insuranceError } = await supabase
          .from('salon_insurance')
          .select('*')
          .eq('salon_id', salonId)
          .single();
        
        if (insuranceError || !insurance) {
          throw new Error(`Insurance data not found for salon: ${salonId}`);
        }
        
        // Build HubSpot properties from local data
        const hubspotProperties: Record<string, string> = {};
        
        // Boolean fields (local → HubSpot: true → "Ja", false → "Nei")
        const boolToJaNei = (val: boolean | null) => val ? "Ja" : "Nei";
        
        hubspotProperties.forsikring_salongforsikring = boolToJaNei(insurance.salong_aktiv);
        hubspotProperties.forsikring_yrkesskadeforsikring = boolToJaNei(insurance.yrkesskadeforsikring_aktiv);
        hubspotProperties.forsikring_cyberforsikring = boolToJaNei(insurance.cyber_aktiv);
        hubspotProperties.forsikring_reiseforsikring = boolToJaNei(insurance.reise_aktiv);
        hubspotProperties.forsikring_fritidsulykkeforsikring = boolToJaNei(insurance.fritidsulykke_aktiv);
        hubspotProperties.forsikring_status_helse = boolToJaNei(insurance.helse_status);
        
        // avsluttede_forsikringser is a checkbox - only send "true" when checked, don't send when false
        if (insurance.avsluttede_forsikringer === true) {
          hubspotProperties.avsluttede_forsikringser = "true";
        }
        
        hubspotProperties.bytter_selskap_forsikring = insurance.bytter_selskap ? "true" : "false";
        
        // Salong level
        if (insurance.salong_niva) {
          hubspotProperties.forsikring_salongforsikring_niva = insurance.salong_niva;
        }
        
        // Price fields
        if (insurance.pris_salong != null) {
          hubspotProperties.forsikring_pris_salongforsikring_niva1 = String(insurance.pris_salong);
        }
        if (insurance.pris_yrkesskadeforsikring != null) {
          hubspotProperties.forsikring_pris_yrkesskadeforsikring = String(insurance.pris_yrkesskadeforsikring);
        }
        if (insurance.pris_cyber != null) {
          hubspotProperties.forsikring_pris_cyberforsikring = String(insurance.pris_cyber);
        }
        if (insurance.pris_reise != null) {
          hubspotProperties.forsikring_pris_reiseforsikring = String(insurance.pris_reise);
        }
        if (insurance.pris_fritidsulykke != null) {
          hubspotProperties.forsikring_pris_fritidsulykkeforsikring = String(insurance.pris_fritidsulykke);
        }
        
        // Sum fields
        if (insurance.sum_yrkesskadeforsikring != null) {
          hubspotProperties.forsikring_sum_yrkesskadeforsikring = String(insurance.sum_yrkesskadeforsikring);
        }
        if (insurance.sum_reise != null) {
          hubspotProperties.forsikring_sum_reiseforsikring = String(insurance.sum_reise);
        }
        if (insurance.sum_fritidsulykke != null) {
          hubspotProperties.forsikring_sum_fritidsulykkeforsikring = String(insurance.sum_fritidsulykke);
        }
        if (insurance.sum_totalt != null) {
          hubspotProperties.forsikring_sum_totalt = String(insurance.sum_totalt);
        }
        if (insurance.sum_mvil) {
          hubspotProperties.forsikring_sum_mvil = insurance.sum_mvil;
        }
        
        // Number fields
        if (insurance.antall_ansatte != null) {
          hubspotProperties.forsikring_antall_ansatte = String(insurance.antall_ansatte);
        }
        if (insurance.antall_arsverk != null) {
          hubspotProperties.forsikring_antall_arsverk = String(insurance.antall_arsverk);
        }
        if (insurance.antall_fritidsulykke != null) {
          hubspotProperties.forsikring_antall_personer_fritidsulykke = String(insurance.antall_fritidsulykke);
        }
        if (insurance.antall_reiseforsikring != null) {
          hubspotProperties.forsikring_antall_personer_reiseforsikring = String(insurance.antall_reiseforsikring);
        }
        if (insurance.arlig_omsetning != null) {
          hubspotProperties["forsikring_arlig_omsetning__nok_"] = String(insurance.arlig_omsetning);
        }
        
        // Date fields (format: YYYY-MM-DD)
        if (insurance.aktivering_dato) {
          hubspotProperties.dato_for_aktivering_av_forsikring = insurance.aktivering_dato;
        }
        if (insurance.innmelding_dato) {
          hubspotProperties.dato_for_innmelding_av_forsikring = insurance.innmelding_dato;
        }
        if (insurance.oppsigelse_dato) {
          hubspotProperties.dato_for_oppsigelse_av_forsikring = insurance.oppsigelse_dato;
        }
        if (insurance.bestillingsdato) {
          hubspotProperties.forsikring_bestillingsdato = insurance.bestillingsdato;
        }
        if (insurance.oppstartsdato) {
          hubspotProperties.forsikring_oppstartsdato = insurance.oppstartsdato;
        }
        
        // Contact info
        if (insurance.kontaktperson_navn) {
          hubspotProperties.forsikring_kontaktperson = insurance.kontaktperson_navn;
        }
        if (insurance.kontaktperson_epost) {
          hubspotProperties.forsikring_e_post = insurance.kontaktperson_epost;
        }
        
        // Text fields
        if (insurance.tidligere_forsikringer) {
          hubspotProperties.tidligere_forsikringer = insurance.tidligere_forsikringer;
        }
        
        // Note: Health insurance fields (helseforsikring, helseforsikring_premie) are stored at contact level in HubSpot, not company level
        // Only sync fields that exist at company level
        if (insurance.helseforsikring_avtalenummer) {
          hubspotProperties.helseforsikring_avtalenummer = insurance.helseforsikring_avtalenummer;
        }
        if (insurance.helseforsikring_oppstartsdato) {
          hubspotProperties.helseforsikring_oppstartsdato = insurance.helseforsikring_oppstartsdato;
        }
        if (insurance.helseforsikring_oppsigelsesdato) {
          hubspotProperties.helseforsikrings_oppsigelses_dato = insurance.helseforsikring_oppsigelsesdato;
        }
        
        console.log(`Updating HubSpot company ${salon.hs_object_id} with ${Object.keys(hubspotProperties).length} properties`);
        console.log(`Insurance data - antall_ansatte: ${insurance.antall_ansatte}, antall_arsverk: ${insurance.antall_arsverk}`);
        console.log(`Mapped HubSpot properties for ansatte/arsverk:`, {
          forsikring_antall_ansatte: hubspotProperties.forsikring_antall_ansatte,
          forsikring_antall_arsverk: hubspotProperties.forsikring_antall_arsverk,
        });
        
        // Update HubSpot company
        await hubspotRequest(accessToken, `/crm/v3/objects/companies/${salon.hs_object_id}`, {
          method: "PATCH",
          body: JSON.stringify({ properties: hubspotProperties }),
        });
        
        // Update local sync timestamp
        await supabase
          .from('salon_insurance')
          .update({ hubspot_synced_at: new Date().toISOString() })
          .eq('salon_id', salonId);
        
        console.log(`Successfully synced insurance data for salon ${salon.name} to HubSpot`);
        
        return new Response(JSON.stringify({ 
          success: true, 
          message: `Synkronisert til HubSpot`,
          propertiesUpdated: Object.keys(hubspotProperties).length
        }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "sync_completed_order": {
        // Sync a completed insurance order back to HubSpot
        const { orderId } = params;
        
        console.log(`Syncing completed order ${orderId} to HubSpot`);
        
        // Get order with salon info
        const { data: order, error: orderError } = await supabase
          .from('insurance_orders')
          .select(`
            *,
            salons:salon_id (
              id,
              name,
              hs_object_id
            )
          `)
          .eq('id', orderId)
          .single();
        
        if (orderError || !order) {
          throw new Error(`Order not found: ${orderId}`);
        }
        
        if (!order.salons?.hs_object_id) {
          console.log("Salon has no HubSpot company ID, skipping sync");
          return new Response(JSON.stringify({ 
            success: false, 
            message: "Salon has no HubSpot company ID" 
          }), {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }
        
        // Get order items with product info
        const { data: orderItems } = await supabase
          .from('insurance_order_items')
          .select(`
            *,
            insurance_products:product_id (name, product_type)
          `)
          .eq('order_id', orderId);
        
        // Get current insurance data from local DB
        const { data: currentInsurance } = await supabase
          .from('salon_insurance')
          .select('*')
          .eq('salon_id', order.salon_id)
          .single();
        
        // Build HubSpot properties to update based on ordered products
        const hubspotProperties: Record<string, string> = {};
        
        // Update activation date if this is a new order
        if (order.order_type === 'new' || !currentInsurance?.aktivering_dato) {
          hubspotProperties.dato_for_aktivering_av_forsikring = new Date().toISOString().split('T')[0];
        }
        
        // Update contact info
        if (order.contact_name) {
          hubspotProperties.forsikring_kontaktperson = order.contact_name;
        }
        if (order.contact_email) {
          hubspotProperties.forsikring_e_post = order.contact_email;
        }
        
        // Map product types to HubSpot properties
        const productTypeMapping: Record<string, { activeField: string; priceField?: string }> = {
          'salong': { activeField: 'forsikring_salongforsikring', priceField: 'forsikring_pris_salongforsikring_niva1' },
          'yrkesskade': { activeField: 'forsikring_yrkesskadeforsikring', priceField: 'forsikring_pris_yrkesskadeforsikring' },
          'cyber': { activeField: 'forsikring_cyberforsikring', priceField: 'forsikring_pris_cyberforsikring' },
          'reise': { activeField: 'forsikring_reiseforsikring', priceField: 'forsikring_pris_reiseforsikring' },
          'fritidsulykke': { activeField: 'forsikring_fritidsulykkeforsikring', priceField: 'forsikring_pris_fritidsulykkeforsikring' },
          'helse': { activeField: 'forsikring_status_helse' },
        };
        
        let totalPremium = currentInsurance?.sum_totalt || 0;
        
        for (const item of (orderItems || [])) {
          const productType = item.insurance_products?.product_type;
          if (productType && productTypeMapping[productType]) {
            const mapping = productTypeMapping[productType];
            hubspotProperties[mapping.activeField] = 'Ja';
            
            if (mapping.priceField && item.total_price) {
              hubspotProperties[mapping.priceField] = String(item.total_price);
              totalPremium += item.total_price;
            }
          }
        }
        
        // Update total premium
        hubspotProperties.forsikring_sum_totalt = String(totalPremium);
        
        console.log(`Updating HubSpot company ${order.salons.hs_object_id} with properties:`, hubspotProperties);
        
        // Update HubSpot company
        await hubspotRequest(accessToken, `/crm/v3/objects/companies/${order.salons.hs_object_id}`, {
          method: "PATCH",
          body: JSON.stringify({ properties: hubspotProperties }),
        });
        
        // Update local insurance record
        const localUpdates: Record<string, any> = {
          hubspot_synced_at: new Date().toISOString(),
        };
        
        for (const item of (orderItems || [])) {
          const productType = item.insurance_products?.product_type;
          switch (productType) {
            case 'salong':
              localUpdates.salong_aktiv = true;
              localUpdates.pris_salong = (currentInsurance?.pris_salong || 0) + item.total_price;
              break;
            case 'yrkesskade':
              localUpdates.yrkesskadeforsikring_aktiv = true;
              localUpdates.pris_yrkesskadeforsikring = (currentInsurance?.pris_yrkesskadeforsikring || 0) + item.total_price;
              break;
            case 'cyber':
              localUpdates.cyber_aktiv = true;
              localUpdates.pris_cyber = (currentInsurance?.pris_cyber || 0) + item.total_price;
              break;
            case 'reise':
              localUpdates.reise_aktiv = true;
              localUpdates.pris_reise = (currentInsurance?.pris_reise || 0) + item.total_price;
              break;
            case 'fritidsulykke':
              localUpdates.fritidsulykke_aktiv = true;
              localUpdates.pris_fritidsulykke = (currentInsurance?.pris_fritidsulykke || 0) + item.total_price;
              break;
            case 'helse':
              localUpdates.helse_status = true;
              break;
          }
        }
        
        localUpdates.sum_totalt = totalPremium;
        if (!currentInsurance?.aktivering_dato) {
          localUpdates.aktivering_dato = new Date().toISOString().split('T')[0];
        }
        
        if (currentInsurance) {
          await supabase
            .from('salon_insurance')
            .update(localUpdates)
            .eq('id', currentInsurance.id);
        } else {
          // Create insurance record if it doesn't exist
          await supabase
            .from('salon_insurance')
            .insert({
              salon_id: order.salon_id,
              hubspot_company_id: order.salons.hs_object_id,
              ...localUpdates,
            });
        }
        
        console.log(`Successfully synced order ${orderId} to HubSpot`);
        
        return new Response(JSON.stringify({ 
          success: true, 
          hubspotCompanyId: order.salons.hs_object_id,
          updatedProperties: Object.keys(hubspotProperties).length
        }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "import_health_insurance_contacts": {
        console.log("=== STARTING HEALTH INSURANCE IMPORT ===");
        
        // Get health insurance price from insurance_products
        const { data: helseProduct, error: helseError } = await supabase
          .from('insurance_products')
          .select('base_price')
          .eq('product_type', 'helse')
          .single();
        
        if (helseError) {
          console.log("Could not fetch health product price:", helseError.message);
        }
        
        const helsePris = helseProduct?.base_price ? parseFloat(String(helseProduct.base_price)) : 5050;
        console.log(`Using health insurance price: ${helsePris}`);
        
        // Search for all contacts with health insurance - use HAS_PROPERTY to get all, then filter locally
        let allContacts: any[] = [];
        let after: string | undefined = undefined;
        
        // Helper function for case-insensitive "aktiv" check
        const isActiveStatus = (status: string | undefined): boolean => {
          if (!status) return false;
          return status.toLowerCase().trim() === 'aktiv';
        };
        
        // Use HAS_PROPERTY to fetch ALL contacts with helseforsikring field
        // Then filter locally for case-insensitive "aktiv" matching
        console.log("=== HEALTH INSURANCE IMPORT: Fetching all contacts with helseforsikring field ===");
        
        do {
          const searchBody: any = {
            filterGroups: [
              {
                filters: [
                  {
                    propertyName: "helseforsikring",
                    operator: "HAS_PROPERTY",
                  },
                ],
              },
            ],
            properties: [
              "firstname", "lastname", "email", "phone", "mobilephone", "stilling",
              ...HEALTH_INSURANCE_PROPERTIES
            ],
            limit: 100,
          };
          
          if (after) {
            searchBody.after = after;
          }
          
          const result = await hubspotRequest(accessToken, "/crm/v3/objects/contacts/search", {
            method: "POST",
            body: JSON.stringify(searchBody),
          });
          
          console.log(`Batch fetched: ${result.results?.length || 0} contacts`);
          
          allContacts = allContacts.concat(result.results || []);
          after = result.paging?.next?.after;
          
          console.log(`Progress: ${allContacts.length} total contacts fetched, hasMore: ${!!after}`);
        } while (after);
        
        // Log ALL unique helseforsikring values for debugging
        const allUniqueStatuses = [...new Set(allContacts.map(c => c.properties?.helseforsikring))];
        console.log(`=== ALL UNIQUE HELSEFORSIKRING VALUES (${allUniqueStatuses.length}): ===`, allUniqueStatuses);
        
        // Log contact count per status
        const statusCounts: Record<string, number> = {};
        allContacts.forEach(c => {
          const status = c.properties?.helseforsikring || '(empty)';
          statusCounts[status] = (statusCounts[status] || 0) + 1;
        });
        console.log("Contacts per status:", JSON.stringify(statusCounts));
        
        // Filter to only "aktiv" contacts (case-insensitive)
        const activeContacts = allContacts.filter(c => isActiveStatus(c.properties?.helseforsikring));
        console.log(`=== FILTERED TO ACTIVE: ${activeContacts.length} of ${allContacts.length} contacts have 'aktiv' status (case-insensitive) ===`);
        
        // Log contacts that were filtered OUT (for debugging missing contacts)
        const nonActiveContacts = allContacts.filter(c => !isActiveStatus(c.properties?.helseforsikring));
        if (nonActiveContacts.length > 0) {
          console.log(`Contacts with non-active status (${nonActiveContacts.length}):`);
          nonActiveContacts.slice(0, 10).forEach(c => {
            console.log(`  - ${c.properties?.email}: "${c.properties?.helseforsikring}"`);
          });
          if (nonActiveContacts.length > 10) {
            console.log(`  ... and ${nonActiveContacts.length - 10} more`);
          }
        }
        
        const importResults = {
          total: activeContacts.length,
          totalFetched: allContacts.length,
          created: 0,
          updated: 0,
          skipped: 0,
          failed: 0,
          errors: [] as string[],
          uniqueStatuses: allUniqueStatuses,
          statusCounts: statusCounts,
        };
        
        for (const contact of activeContacts) {
          const email = contact.properties?.email;
          const status = contact.properties?.helseforsikring;
          const stilling = contact.properties?.stilling;
          
          // Map HubSpot stilling to app role based on HubSpot internal names
          const mapStillingToRole = (title: string | undefined): string => {
            if (!title) return 'stylist';
            const normalized = title.toLowerCase().trim();
            
            // Eksakt match basert på HubSpot internverdier
            if (normalized === 'lærling') return 'apprentice';
            if (normalized === 'frisør') return 'stylist';
            if (normalized === 'seniorfrisør') return 'seniorfrisor';
            if (normalized === 'avdelingsleder') return 'avdelingsleder';
            if (normalized === 'dagligleder' || normalized === 'daglig leder') return 'daglig_leder';
            if (normalized === 'dagligleder/eier' || normalized === 'eier') return 'salon_owner';
            if (normalized === 'kjede eier') return 'chain_owner';
            if (normalized === 'styreleder') return 'styreleder';
            
            // Fallback for ukjente titler
            return 'stylist';
          };
          
          const mappedRole = mapStillingToRole(stilling);
          
          console.log(`Processing contact: ${email}, status: ${status}, stilling: ${stilling}, role: ${mappedRole}, hubspot_id: ${contact.id}`);
          
          if (!email) {
            console.log(`Skipping contact ${contact.id} - no email`);
            importResults.skipped++;
            continue;
          }
          
          try {
            // Check if user exists
            const { data: existingUser, error: userError } = await supabase
              .from('users')
              .select('id, salon_id, email')
              .eq('email', email.toLowerCase())
              .maybeSingle();
            
            if (userError) {
              console.log(`Error checking user ${email}:`, userError.message);
            }
            
            const isActive = status === 'Aktiv' || status === 'aktiv' || status === 'true' || status === true;
            
            const healthData = {
              helseforsikring_status: status || null,
              helseforsikring_oppstartsdato: contact.properties?.helseforsikring_oppstartsdato || null,
              helseforsikring_oppsigelsesdato: contact.properties?.helseforsikrings_oppsigelses_dato || null,
              helseforsikring_pris: isActive ? helsePris : null,
              hubspot_contact_id: contact.id,
            };
            
            console.log(`Health data for ${email}:`, JSON.stringify(healthData));
            
            if (existingUser) {
              console.log(`Updating existing user ${email} (id: ${existingUser.id}) with role: ${mappedRole}`);
              // Update existing user with health data AND role from HubSpot stilling
              const { error } = await supabase
                .from('users')
                .update({
                  ...healthData,
                  role: mappedRole,
                })
                .eq('id', existingUser.id);
              
              if (error) {
                console.log(`Error updating user ${email}:`, error.message);
                throw error;
              }
              
              // Also update user_roles table - use delete-then-insert since unique constraint is on (user_id, role)
              await supabase
                .from('user_roles')
                .delete()
                .eq('user_id', existingUser.id);
              
              const { error: roleError } = await supabase
                .from('user_roles')
                .insert({ user_id: existingUser.id, role: mappedRole });
              
              if (roleError) {
                console.log(`Error updating user_roles for ${email}:`, roleError.message);
              } else {
                console.log(`Updated user_roles for ${email} to ${mappedRole}`);
              }
              
              console.log(`Successfully updated user ${email}`);
              importResults.updated++;
            } else {
              console.log(`User ${email} not found, checking company association...`);
              // Try to find associated company to get salon_id
              let salonId = null;
              
              try {
                const associations = await hubspotRequest(
                  accessToken,
                  `/crm/v4/objects/contact/${contact.id}/associations/company`
                );
                
                console.log(`Company associations for ${email}:`, JSON.stringify(associations.results?.slice(0, 3)));
                
                if (associations.results && associations.results.length > 0) {
                  const companyId = associations.results[0].toObjectId;
                  console.log(`Found company ${companyId} for contact ${email}`);
                  
                  // Find salon by hs_object_id
                  const { data: salon } = await supabase
                    .from('salons')
                    .select('id, name')
                    .eq('hs_object_id', companyId)
                    .maybeSingle();
                  
                  if (salon) {
                    salonId = salon.id;
                    console.log(`Matched to salon: ${salon.name} (${salon.id})`);
                  } else {
                    console.log(`No salon found for hs_object_id ${companyId}`);
                  }
                }
              } catch (e) {
                console.error(`Could not get company association for contact ${contact.id}:`, e);
              }
              
              if (!salonId) {
                console.log(`Skipping ${email} - no linked salon found`);
                importResults.skipped++;
                continue;
              }
              
              // Create new user via Auth Admin API first
              const firstName = contact.properties?.firstname || '';
              const lastName = contact.properties?.lastname || '';
              const fullName = `${firstName} ${lastName}`.trim() || email.split('@')[0];
              
              console.log(`Creating new user ${email} for salon ${salonId} via Auth Admin API`);
              
              // Step 1: Create user in auth.users via Admin API
              const { data: authUser, error: authError } = await supabase.auth.admin.createUser({
                email: email.toLowerCase(),
                email_confirm: true,
                user_metadata: {
                  first_name: firstName,
                  last_name: lastName,
                  full_name: fullName,
                  source: 'hubspot_health_insurance_import'
                }
              });
              
              if (authError) {
                console.log(`Auth error for ${email}:`, authError.message, authError.code);
                
                // If user already exists in auth, try to find them and create profile
                if (authError.message?.includes('already been registered') || authError.code === 'user_already_exists') {
                  console.log(`User ${email} exists in auth, trying to get their ID...`);
                  
                  // Get user by email from auth - use perPage: 1000 to handle large user bases
                  const { data: existingAuthUsers } = await supabase.auth.admin.listUsers({
                    page: 1,
                    perPage: 1000
                  });
                  console.log(`Found ${existingAuthUsers?.users?.length || 0} users in auth.users`);
                  const existingAuthUser = existingAuthUsers?.users?.find(
                    (u: any) => u.email?.toLowerCase() === email.toLowerCase()
                  );
                  
                  if (existingAuthUser) {
                    console.log(`Found existing auth user ${email} with id ${existingAuthUser.id}`);
                    
                    // Create profile in users table with the existing auth user id
                    const { error: profileError } = await supabase
                      .from('users')
                      .insert({
                        id: existingAuthUser.id,
                        email: email.toLowerCase(),
                        first_name: firstName || null,
                        name: fullName,
                        phone: contact.properties?.mobilephone || contact.properties?.phone || null,
                        salon_id: salonId,
                        role: mappedRole,
                        ...healthData,
                      });
                    
                    if (profileError) {
                      if (profileError.code === '23505') {
                        console.log(`Profile for ${email} already exists, skipping`);
                        importResults.skipped++;
                        continue;
                      }
                      throw profileError;
                    }
                    
                    // Create user_roles entry
                    await supabase
                      .from('user_roles')
                      .insert({ user_id: existingAuthUser.id, role: mappedRole });
                    
                    console.log(`Successfully created profile for existing auth user ${email}`);
                    importResults.created++;
                    continue;
                  }
                }
                
                throw authError;
              }
              
              if (!authUser?.user) {
                console.log(`No auth user returned for ${email}`);
                importResults.failed++;
                importResults.errors.push(`${email}: No auth user created`);
                continue;
              }
              
              console.log(`Auth user created with id: ${authUser.user.id}`);
              
              // Step 2: Create profile in users table with the auth user id
              const { error: profileError } = await supabase
                .from('users')
                .insert({
                  id: authUser.user.id,
                  email: email.toLowerCase(),
                  first_name: firstName || null,
                  name: fullName,
                  phone: contact.properties?.mobilephone || contact.properties?.phone || null,
                  salon_id: salonId,
                  role: mappedRole,
                  ...healthData,
                });
              
              if (profileError) {
                console.log(`Error creating profile for ${email}:`, profileError.message, profileError.code);
                // Rollback: delete auth user if profile creation fails
                await supabase.auth.admin.deleteUser(authUser.user.id);
                throw profileError;
              }
              
              // Step 3: Create user_roles entry
              const { error: roleError } = await supabase
                .from('user_roles')
                .insert({ user_id: authUser.user.id, role: mappedRole });
              
              if (roleError) {
                console.log(`Warning: Could not create user_roles for ${email}:`, roleError.message);
              }
              
              console.log(`Successfully created user ${email} with id ${authUser.user.id}`);
              importResults.created++;
            }
          } catch (e) {
            importResults.failed++;
            const errorMsg = e instanceof Error ? e.message : 'Unknown error';
            importResults.errors.push(`${email}: ${errorMsg}`);
            console.error(`Error processing contact ${email}:`, e);
          }
        }
        
        console.log(`=== HEALTH INSURANCE IMPORT COMPLETE ===`);
        console.log(`Created: ${importResults.created}, Updated: ${importResults.updated}, Skipped: ${importResults.skipped}, Failed: ${importResults.failed}`);
        
        return new Response(JSON.stringify(importResults), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "sync_health_insurance_fields": {
        console.log("=== SYNCING ALL HEALTH INSURANCE FIELDS FROM HUBSPOT ===");
        
        // Get all users with health insurance or HubSpot contact ID
        const { data: usersWithHealthIns, error: usersError } = await supabase
          .from('users')
          .select('id, email, salon_id, hubspot_contact_id, helseforsikring_status, helseforsikring_avtalenummer, helseforsikring_oppstartsdato, helseforsikring_oppsigelsesdato, helseforsikring_pris')
          .or('helseforsikring_status.not.is.null,hubspot_contact_id.not.is.null');
        
        if (usersError) {
          throw new Error(`Failed to fetch users: ${usersError.message}`);
        }
        
        console.log(`Found ${usersWithHealthIns?.length || 0} users to check for health insurance`);
        
        // Get unique salon IDs
        const salonIds = [...new Set(usersWithHealthIns?.map(u => u.salon_id).filter(Boolean))];
        
        // Fetch salon HubSpot company IDs
        const { data: salons, error: salonsError } = await supabase
          .from('salons')
          .select('id, name, hubspot_company_id')
          .in('id', salonIds);
        
        if (salonsError) {
          throw new Error(`Failed to fetch salons: ${salonsError.message}`);
        }
        
        // Create a map of salon_id -> hubspot_company_id
        const salonToHubspot: Record<string, string> = {};
        for (const salon of salons || []) {
          if (salon.hubspot_company_id) {
            salonToHubspot[salon.id] = salon.hubspot_company_id;
          }
        }
        
        // Fetch contact-level health insurance fields from HubSpot
        // Fields are on CONTACT level, not company level
        const contactIds = usersWithHealthIns?.filter(u => u.hubspot_contact_id).map(u => u.hubspot_contact_id) || [];
        const contactData: Record<string, { 
          status?: string; 
          avtalenummer?: string;
          oppstartsdato?: string; 
          oppsigelsesdato?: string;
          pris?: number;
        }> = {};
        
        // HubSpot field names (from user's HubSpot config):
        // - helseforsikring (enumeration) = status
        // - helseforsikring_avtalenummer (string)
        // - helseforsikring_oppstartsdato (date)
        // - helseforsikring_premie (number)
        // - helseforsikrings_oppsigelses_dato (date) - note the different spelling!
        
        for (let i = 0; i < contactIds.length; i += 100) {
          const batchIds = contactIds.slice(i, i + 100);
          try {
            const result = await hubspotRequest(accessToken, "/crm/v3/objects/contacts/batch/read", {
              method: "POST",
              body: JSON.stringify({
                inputs: batchIds.map(id => ({ id })),
                properties: [
                  "helseforsikring",
                  "helseforsikring_avtalenummer",
                  "helseforsikring_oppstartsdato", 
                  "helseforsikrings_oppsigelses_dato",
                  "helseforsikring_premie",
                  "email"
                ],
              }),
            });
            
            for (const contact of result.results || []) {
              const props = contact.properties || {};
              contactData[contact.id] = {
                status: props.helseforsikring || undefined,
                avtalenummer: props.helseforsikring_avtalenummer || undefined,
                oppstartsdato: props.helseforsikring_oppstartsdato || undefined,
                oppsigelsesdato: props.helseforsikrings_oppsigelses_dato || undefined,
                pris: props.helseforsikring_premie ? parseFloat(props.helseforsikring_premie) : undefined,
              };
            }
          } catch (e) {
            console.error(`Error fetching contacts:`, e);
          }
        }
        
        console.log(`Fetched health insurance data for ${Object.keys(contactData).length} contacts`);
        
        // Update users with all health insurance fields
        const results = {
          total: usersWithHealthIns?.length || 0,
          updated: 0,
          noChanges: 0,
          errors: [] as string[],
        };
        
        for (const user of usersWithHealthIns || []) {
          const updates: Record<string, any> = {};
          
          // All health insurance fields are on contact level in HubSpot
          if (user.hubspot_contact_id && contactData[user.hubspot_contact_id]) {
            const cData = contactData[user.hubspot_contact_id];
            
            if (cData.status && user.helseforsikring_status !== cData.status) {
              updates.helseforsikring_status = cData.status;
            }
            if (cData.avtalenummer && user.helseforsikring_avtalenummer !== cData.avtalenummer) {
              updates.helseforsikring_avtalenummer = cData.avtalenummer;
            }
            if (cData.oppstartsdato && user.helseforsikring_oppstartsdato !== cData.oppstartsdato) {
              updates.helseforsikring_oppstartsdato = cData.oppstartsdato;
            }
            if (cData.oppsigelsesdato && user.helseforsikring_oppsigelsesdato !== cData.oppsigelsesdato) {
              updates.helseforsikring_oppsigelsesdato = cData.oppsigelsesdato;
            }
            if (cData.pris && user.helseforsikring_pris !== cData.pris) {
              updates.helseforsikring_pris = cData.pris;
            }
          }
          
          if (Object.keys(updates).length === 0) {
            results.noChanges++;
            continue;
          }
          
          try {
            const { error: updateError } = await supabase
              .from('users')
              .update(updates)
              .eq('id', user.id);
            
            if (updateError) {
              results.errors.push(`${user.email}: ${updateError.message}`);
            } else {
              results.updated++;
              console.log(`Updated ${user.email} with fields:`, Object.keys(updates));
            }
          } catch (e) {
            results.errors.push(`${user.email}: ${e instanceof Error ? e.message : 'Unknown error'}`);
          }
        }
        
        console.log(`=== SYNC COMPLETE === Updated: ${results.updated}, No changes: ${results.noChanges}`);
        
        return new Response(JSON.stringify({ success: true, results }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "sync_health_to_hubspot": {
        // Sync health insurance data from local DB TO HubSpot contacts
        const { userIds, orderId } = params as { userIds: string[]; orderId?: string };
        
        if (!userIds || userIds.length === 0) {
          throw new Error("userIds is required");
        }
        
        console.log(`=== SYNCING HEALTH INSURANCE TO HUBSPOT for ${userIds.length} users ===`);
        
        // Fetch users with their health insurance data
        const { data: users, error: usersError } = await supabase
          .from('users')
          .select('id, email, name, hubspot_contact_id, helseforsikring_status, helseforsikring_avtalenummer, helseforsikring_oppstartsdato, helseforsikring_pris')
          .in('id', userIds);
        
        if (usersError) {
          throw new Error(`Failed to fetch users: ${usersError.message}`);
        }
        
        const results = {
          total: users?.length || 0,
          synced: 0,
          skipped: 0,
          errors: [] as string[],
        };
        
        for (const user of users || []) {
          if (!user.hubspot_contact_id) {
            console.log(`Skipping ${user.email}: no HubSpot contact ID`);
            results.skipped++;
            continue;
          }
          
          // Mapping from database status to HubSpot expected values
          const healthStatusToHubSpot: Record<string, string> = {
            'aktiv': 'Aktiv',
            'søkt': 'Søkt',
            'sokt': 'Søkt',
            'oppsigelse': 'Oppsigelse',
            'avsluttet': 'Avsluttet',
          };
          
          // Build properties to update in HubSpot
          const properties: Record<string, string> = {};
          
          if (user.helseforsikring_status) {
            const statusLower = user.helseforsikring_status.toLowerCase();
            properties.helseforsikring = healthStatusToHubSpot[statusLower] || user.helseforsikring_status;
          }
          if (user.helseforsikring_avtalenummer) {
            properties.helseforsikring_avtalenummer = user.helseforsikring_avtalenummer;
          }
          if (user.helseforsikring_oppstartsdato) {
            properties.helseforsikring_oppstartsdato = user.helseforsikring_oppstartsdato;
          }
          if (user.helseforsikring_pris) {
            properties.helseforsikring_premie = String(user.helseforsikring_pris);
          }
          
          if (Object.keys(properties).length === 0) {
            console.log(`Skipping ${user.email}: no health insurance data to sync`);
            results.skipped++;
            continue;
          }
          
          try {
            await hubspotRequest(accessToken, `/crm/v3/objects/contacts/${user.hubspot_contact_id}`, {
              method: "PATCH",
              body: JSON.stringify({ properties }),
            });
            
            console.log(`Synced ${user.email} to HubSpot:`, properties);
            results.synced++;
          } catch (e) {
            const errorMsg = e instanceof Error ? e.message : 'Unknown error';
            console.error(`Failed to sync ${user.email}:`, errorMsg);
            results.errors.push(`${user.email}: ${errorMsg}`);
          }
        }
        
        console.log(`=== HUBSPOT SYNC COMPLETE === Synced: ${results.synced}, Skipped: ${results.skipped}`);
        
        return new Response(JSON.stringify({ success: true, results }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "get_subscription_types": {
        console.log("=== FETCHING HUBSPOT SUBSCRIPTION TYPES ===");
        
        const result = await hubspotRequest(
          accessToken, 
          "/communication-preferences/v3/definitions"
        );
        
        console.log(`Found ${result.subscriptionDefinitions?.length || 0} subscription types`);
        
        // Log each subscription type for debugging
        if (result.subscriptionDefinitions) {
          result.subscriptionDefinitions.forEach((sub: any) => {
            console.log(`- ${sub.name} (ID: ${sub.id}, Purpose: ${sub.purpose}, Active: ${sub.isActive})`);
          });
        }
        
        return new Response(JSON.stringify({ 
          success: true, 
          subscriptionTypes: result.subscriptionDefinitions || [],
          raw: result 
        }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "associate_contact_to_company": {
        const { contactId, companyId } = params;
        console.log(`Associating contact ${contactId} to company ${companyId}`);
        
        // Use HubSpot v4 associations API
        const result = await hubspotRequest(
          accessToken,
          `/crm/v4/objects/contact/${contactId}/associations/company/${companyId}`,
          {
            method: "PUT",
            body: JSON.stringify([
              {
                associationCategory: "HUBSPOT_DEFINED",
                associationTypeId: 1 // Contact to Company primary association
              }
            ]),
          }
        );
        
        console.log(`Successfully associated contact ${contactId} to company ${companyId}`);
        
        return new Response(JSON.stringify({ success: true, result }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      default:
        throw new Error(`Unknown action: ${action}`);
    }
  } catch (error) {
    console.error("HubSpot API error:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
