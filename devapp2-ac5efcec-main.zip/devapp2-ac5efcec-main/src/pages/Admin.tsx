import { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { DistrictsTab } from "@/components/admin/DistrictsTab";
import { SalonsTab } from "@/components/admin/SalonsTab";
import { ChainsTab } from "@/components/admin/ChainsTab";
import { InvitationsTab } from "@/components/admin/InvitationsTab";
import { UsersTab } from "@/components/admin/UsersTab";
import { AuditLogTab } from "@/components/admin/AuditLogTab";
import { SuppliersTab } from "@/components/admin/SuppliersTab";
import { ChallengesTab } from "@/components/admin/ChallengesTab";
import { AnnouncementsTab } from "@/components/admin/AnnouncementsTab";
import { SeedDataTab } from "@/components/admin/SeedDataTab";
import { SettingsTab } from "@/components/admin/SettingsTab";
import HubSpotTab from "@/components/admin/HubSpotTab";
import { TariffAdminTab } from "@/components/admin/TariffAdminTab";
import { CompetencyAdminTab } from "@/components/admin/CompetencyAdminTab";
import { UserAnsattSyncTab } from "@/components/admin/UserAnsattSyncTab";
import { AppLayout } from "@/components/AppLayout";
import { 
  Mail, 
  Shield, 
  Building2, 
  Users, 
  Briefcase, 
  Link as LinkIcon, 
  Megaphone, 
  Settings,
  ChevronRight,
  ArrowLeft,
  Calculator,
  Package
} from "lucide-react";

interface AdminCategory {
  id: string;
  title: string;
  description: string;
  icon: React.ElementType;
  tabs: { id: string; label: string; component: React.ReactNode }[];
}

const adminCategories: AdminCategory[] = [
  {
    id: "organization",
    title: "Organisasjon",
    description: "Distrikter, kjeder og salonger",
    icon: Building2,
    tabs: [
      { id: "districts", label: "Distrikter", component: <DistrictsTab /> },
      { id: "chains", label: "Kjeder", component: <ChainsTab /> },
      { id: "salons", label: "Salonger", component: <SalonsTab /> },
    ],
  },
  {
    id: "users",
    title: "Brukere & Tilgang",
    description: "Brukere, invitasjoner, synkronisering og aktivitetslogg",
    icon: Users,
    tabs: [
      { id: "users", label: "Brukere", component: <UsersTab /> },
      { id: "invitations", label: "Invitasjoner", component: <InvitationsTab /> },
      { id: "sync", label: "Bruker-Ansatt Sync", component: <UserAnsattSyncTab /> },
      { id: "audit", label: "Aktivitetslogg", component: <AuditLogTab /> },
    ],
  },
  {
    id: "business",
    title: "Forretning",
    description: "Leverandører, tariff og kompetanser",
    icon: Briefcase,
    tabs: [
      { id: "suppliers", label: "Leverandører", component: <SuppliersTab /> },
      { id: "tariff", label: "Tariff", component: <TariffAdminTab /> },
      { id: "competency", label: "Kompetanser", component: <CompetencyAdminTab /> },
    ],
  },
  {
    id: "integrations",
    title: "Integrasjoner",
    description: "HubSpot og eksterne systemer",
    icon: LinkIcon,
    tabs: [
      { id: "hubspot", label: "HubSpot", component: <HubSpotTab /> },
    ],
  },
  {
    id: "engagement",
    title: "Engasjement",
    description: "Challenges og nyheter",
    icon: Megaphone,
    tabs: [
      { id: "challenges", label: "Challenges", component: <ChallengesTab /> },
      { id: "announcements", label: "Nyheter", component: <AnnouncementsTab /> },
    ],
  },
  {
    id: "system",
    title: "System",
    description: "Innstillinger og testdata",
    icon: Settings,
    tabs: [
      { id: "settings", label: "Innstillinger", component: <SettingsTab /> },
      { id: "seed", label: "Testdata", component: <SeedDataTab /> },
    ],
  },
];

const Admin = () => {
  const navigate = useNavigate();
  const { user, profile, loading } = useAuth();
  const [activeCategory, setActiveCategory] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<string>("");

  useEffect(() => {
    if (!loading) {
      if (!user) {
        navigate("/login");
      } else if (profile?.role !== "admin") {
        navigate("/dashboard");
      }
    }
  }, [user, profile, loading, navigate]);

  const handleCategoryClick = (categoryId: string) => {
    const category = adminCategories.find(c => c.id === categoryId);
    if (category) {
      setActiveCategory(categoryId);
      setActiveTab(category.tabs[0].id);
    }
  };

  const handleBackToOverview = () => {
    setActiveCategory(null);
    setActiveTab("");
  };

  if (loading || !profile) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Laster...</p>
        </div>
      </div>
    );
  }

  const currentCategory = adminCategories.find(c => c.id === activeCategory);

  return (
    <AppLayout 
      title={currentCategory ? currentCategory.title : "Admin"} 
      subtitle={currentCategory ? currentCategory.description : "Administrer plattformen"}
    >
      <div className="container mx-auto px-4 py-8">
        {/* Quick Actions - Always visible */}
        <div className="flex flex-wrap gap-3 mb-8">
          <Button variant="default" asChild className="shadow-sm">
            <Link to="/admin/insurance">
              <Shield className="h-4 w-4 mr-2" />
              Forsikringsadmin
            </Link>
          </Button>
          <Button variant="default" asChild className="shadow-sm">
            <Link to="/admin/bonus">
              <Calculator className="h-4 w-4 mr-2" />
              Bonus & Returprovisjon
            </Link>
          </Button>
          <Button variant="default" asChild className="shadow-sm">
            <Link to="/admin/leverandorer">
              <Package className="h-4 w-4 mr-2" />
              Leverandør Admin
            </Link>
          </Button>
          <Button variant="outline" asChild className="shadow-sm">
            <Link to="/admin/email-templates">
              <Mail className="h-4 w-4 mr-2" />
              E-postmaler
            </Link>
          </Button>
        </div>

        {/* Category Overview or Active Category Content */}
        {!activeCategory ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {adminCategories.map((category) => {
              const Icon = category.icon;
              return (
                <Card 
                  key={category.id}
                  className="group cursor-pointer transition-all duration-300 hover:shadow-lg hover:-translate-y-1 border-border/50 hover:border-primary/30"
                  onClick={() => handleCategoryClick(category.id)}
                >
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="p-3 rounded-xl bg-primary/10 group-hover:bg-primary/20 transition-colors duration-300">
                          <Icon className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <CardTitle className="text-lg">{category.title}</CardTitle>
                          <CardDescription className="text-sm mt-0.5">
                            {category.description}
                          </CardDescription>
                        </div>
                      </div>
                      <ChevronRight className="h-5 w-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all duration-300" />
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="flex flex-wrap gap-2">
                      {category.tabs.map((tab) => (
                        <span 
                          key={tab.id}
                          className="text-xs px-2.5 py-1 rounded-full bg-muted text-muted-foreground"
                        >
                          {tab.label}
                        </span>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        ) : (
          <div className="animate-fade-in">
            {/* Back button */}
            <Button 
              variant="ghost" 
              onClick={handleBackToOverview}
              className="mb-6 -ml-2 text-muted-foreground hover:text-foreground"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Tilbake til oversikt
            </Button>

            {/* Category content with tabs */}
            {currentCategory && (
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="mb-6 bg-muted/50 p-1 h-auto">
                  {currentCategory.tabs.map((tab) => (
                    <TabsTrigger 
                      key={tab.id} 
                      value={tab.id}
                      className="px-4 py-2 data-[state=active]:bg-background data-[state=active]:shadow-sm"
                    >
                      {tab.label}
                    </TabsTrigger>
                  ))}
                </TabsList>

                {currentCategory.tabs.map((tab) => (
                  <TabsContent key={tab.id} value={tab.id} className="mt-0">
                    {tab.component}
                  </TabsContent>
                ))}
              </Tabs>
            )}
          </div>
        )}
      </div>
    </AppLayout>
  );
};

export default Admin;
