import { useParams, useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, Building2, User, Mail, Phone, MapPin, FileText, Calendar } from "lucide-react";
import { format } from "date-fns";
import { nb } from "date-fns/locale";
import haar1Logo from "@/assets/haar1-logo-black.png";

interface QuoteProductRaw {
  product_id: string;
  product_name: string;
  tier_id?: string;
  tier_name?: string;
  quantity?: number;
  price: number;
  arsverk?: number;
  selected_employees?: Array<{ user_id: string; name: string }>;
}

interface QuoteProduct {
  productId: string;
  productName: string;
  tierId?: string;
  tierName?: string;
  quantity?: number;
  unitPrice: number;
  totalPrice: number;
  employees?: Array<{ userId: string; userName: string }>;
  arsverk?: number;
}

const statusConfig: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
  draft: { label: "Utkast", variant: "secondary" },
  sent: { label: "Sendt", variant: "default" },
  accepted: { label: "Akseptert", variant: "default" },
  completed: { label: "Fullført", variant: "default" },
  expired: { label: "Utløpt", variant: "destructive" },
  withdrawn: { label: "Trukket", variant: "destructive" },
};

export default function QuoteView() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const { data: quote, isLoading, error } = useQuery({
    queryKey: ["quote-view", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("insurance_quotes")
        .select(`
          *,
          district_manager:district_manager_id (
            name
          )
        `)
        .eq("id", id)
        .single();

      if (error) throw error;
      return data;
    },
    enabled: !!id,
  });

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("nb-NO", {
      style: "currency",
      currency: "NOK",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(price);
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return "-";
    return format(new Date(dateString), "d. MMMM yyyy", { locale: nb });
  };

  const getEffectiveStatus = () => {
    if (!quote) return "draft";
    if (quote.status === "withdrawn") return "withdrawn";
    if (quote.status === "sent" && quote.expires_at && new Date(quote.expires_at) < new Date()) {
      return "expired";
    }
    return quote.status;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background p-8">
        <div className="max-w-4xl mx-auto space-y-6">
          <Skeleton className="h-12 w-48" />
          <Skeleton className="h-64 w-full" />
          <Skeleton className="h-48 w-full" />
        </div>
      </div>
    );
  }

  if (error || !quote) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="pt-6 text-center">
            <p className="text-muted-foreground mb-4">Tilbudet ble ikke funnet.</p>
            <Button onClick={() => navigate(-1)}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Tilbake
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Map raw product data to expected format
  const rawProducts = (quote.products as unknown as QuoteProductRaw[]) || [];
  const products: QuoteProduct[] = rawProducts.map((p) => {
    const qty = p.arsverk || p.quantity || 1;
    const unitPrice = p.price || 0;
    const totalPrice = unitPrice * qty;
    
    return {
      productId: p.product_id,
      productName: p.product_name,
      tierId: p.tier_id,
      tierName: p.tier_name,
      quantity: p.quantity,
      unitPrice,
      totalPrice,
      arsverk: p.arsverk,
      employees: p.selected_employees?.map((e) => ({
        userId: e.user_id,
        userName: e.name,
      })),
    };
  });
  
  const effectiveStatus = getEffectiveStatus();
  const statusInfo = statusConfig[effectiveStatus] || statusConfig.draft;

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto p-6 md:p-8 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <Button variant="ghost" onClick={() => navigate(-1)}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Tilbake
          </Button>
          <img src={haar1Logo} alt="Hår1 Forsikring" className="h-8" />
        </div>

        {/* Quote Header */}
        <Card>
          <CardHeader>
            <div className="flex items-start justify-between">
              <div>
                <CardTitle className="text-2xl flex items-center gap-3">
                  <Building2 className="h-6 w-6 text-primary" />
                  {quote.salon_name}
                </CardTitle>
                <p className="text-muted-foreground mt-1">Org.nr: {quote.org_number}</p>
              </div>
              <Badge variant={statusInfo.variant}>{statusInfo.label}</Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-sm">
                  <User className="h-4 w-4 text-muted-foreground" />
                  <span>{quote.contact_name}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <span>{quote.email}</span>
                </div>
                {quote.phone && (
                  <div className="flex items-center gap-2 text-sm">
                    <Phone className="h-4 w-4 text-muted-foreground" />
                    <span>{quote.phone}</span>
                  </div>
                )}
                {quote.salon_address && (
                  <div className="flex items-center gap-2 text-sm">
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <span>
                      {quote.salon_address}
                      {quote.salon_postal_code && `, ${quote.salon_postal_code}`}
                      {quote.salon_city && ` ${quote.salon_city}`}
                    </span>
                  </div>
                )}
              </div>
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-sm">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <span>Opprettet: {formatDate(quote.created_at)}</span>
                </div>
                {quote.sent_at && (
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span>Sendt: {formatDate(quote.sent_at)}</span>
                  </div>
                )}
                {quote.expires_at && (
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span>Utløper: {formatDate(quote.expires_at)}</span>
                  </div>
                )}
                {quote.accepted_at && (
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span>Akseptert: {formatDate(quote.accepted_at)}</span>
                  </div>
                )}
                {quote.district_manager && (
                  <div className="flex items-center gap-2 text-sm">
                    <User className="h-4 w-4 text-muted-foreground" />
                    <span>Distriktsleder: {(quote.district_manager as any).name}</span>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Products */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Produkter
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {products.map((product, index) => (
                <div
                  key={index}
                  className="flex items-start justify-between p-4 bg-muted/50 rounded-lg"
                >
                  <div>
                    <p className="font-medium">{product.productName}</p>
                    {product.tierName && (
                      <p className="text-sm text-muted-foreground">{product.tierName}</p>
                    )}
                    {product.quantity && product.quantity > 1 && (
                      <p className="text-sm text-muted-foreground">
                        Antall: {product.quantity}
                      </p>
                    )}
                    {product.arsverk && (
                      <p className="text-sm text-muted-foreground">
                        Årsverk: {product.arsverk}
                      </p>
                    )}
                    {product.employees && product.employees.length > 0 && (
                      <div className="mt-2">
                        <p className="text-sm text-muted-foreground">Ansatte:</p>
                        <ul className="text-sm text-muted-foreground ml-4">
                          {product.employees.map((emp, i) => (
                            <li key={i}>• {emp.userName}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                  <div className="text-right">
                    <p className="font-semibold">{formatPrice(product.totalPrice)}</p>
                    {(product.quantity && product.quantity > 1) || product.arsverk ? (
                      <p className="text-sm text-muted-foreground">
                        {formatPrice(product.unitPrice)} / {product.arsverk ? "årsverk" : "stk"}
                      </p>
                    ) : null}
                  </div>
                </div>
              ))}

              <div className="border-t pt-4 mt-4">
                <div className="flex justify-between items-center">
                  <span className="text-lg font-semibold">Total årspremie</span>
                  <span className="text-xl font-bold text-primary">
                    {formatPrice(quote.total_price)}
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Notes */}
        {quote.notes && (
          <Card>
            <CardHeader>
              <CardTitle>Notater</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground whitespace-pre-wrap">{quote.notes}</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
