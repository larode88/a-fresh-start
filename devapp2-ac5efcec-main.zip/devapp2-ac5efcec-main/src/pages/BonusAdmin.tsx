import { AppLayout } from "@/components/AppLayout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Upload, Settings, Calculator, FileSearch, TrendingUp, BarChart3 } from "lucide-react";
import { BonusImportTab } from "@/components/bonus/BonusImportTab";
import { BonusRulesTab } from "@/components/bonus/BonusRulesTab";
import { BonusCalculationTab } from "@/components/bonus/BonusCalculationTab";
import { BonusAuditTab } from "@/components/bonus/BonusAuditTab";
import { GrowthBonusAdminTab } from "@/components/bonus/GrowthBonusAdminTab";
import { AdminBonusOverviewTab } from "@/components/bonus/AdminBonusOverviewTab";

export default function BonusAdmin() {
  return (
    <AppLayout>
      <div className="container mx-auto py-6 space-y-6">
        <div>
          <h1 className="text-3xl font-serif font-semibold">Bonus & Returprovisjon</h1>
          <p className="text-muted-foreground mt-1">
            Administrer bonusregler, importer salgsdata og beregn utbetalinger
          </p>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-6 lg:w-auto lg:inline-flex">
            <TabsTrigger value="overview" className="gap-2">
              <BarChart3 className="h-4 w-4" />
              <span className="hidden sm:inline">Oversikt</span>
            </TabsTrigger>
            <TabsTrigger value="import" className="gap-2">
              <Upload className="h-4 w-4" />
              <span className="hidden sm:inline">Import</span>
            </TabsTrigger>
            <TabsTrigger value="rules" className="gap-2">
              <Settings className="h-4 w-4" />
              <span className="hidden sm:inline">Regler</span>
            </TabsTrigger>
            <TabsTrigger value="calculation" className="gap-2">
              <Calculator className="h-4 w-4" />
              <span className="hidden sm:inline">Beregning</span>
            </TabsTrigger>
            <TabsTrigger value="growth" className="gap-2">
              <TrendingUp className="h-4 w-4" />
              <span className="hidden sm:inline">Vekstbonus</span>
            </TabsTrigger>
            <TabsTrigger value="audit" className="gap-2">
              <FileSearch className="h-4 w-4" />
              <span className="hidden sm:inline">Revisjon</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <AdminBonusOverviewTab />
          </TabsContent>

          <TabsContent value="import">
            <BonusImportTab />
          </TabsContent>

          <TabsContent value="rules">
            <BonusRulesTab />
          </TabsContent>

          <TabsContent value="calculation">
            <BonusCalculationTab />
          </TabsContent>

          <TabsContent value="growth">
            <GrowthBonusAdminTab />
          </TabsContent>

          <TabsContent value="audit">
            <BonusAuditTab />
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}