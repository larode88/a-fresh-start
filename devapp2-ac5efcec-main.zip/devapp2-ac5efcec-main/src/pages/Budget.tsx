import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useSalonContext } from "@/components/SalonSelector";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { BudgetVersionManager } from "@/components/budget/BudgetVersionManager";
import { BudgetGenerator } from "@/components/budget/BudgetGenerator";
import { BudgetOverview } from "@/components/budget/BudgetOverview";
import { BudgetFastsatt } from "@/components/budget/BudgetFastsatt";
import { BudgetManuelt } from "@/components/budget/BudgetManuelt";
import { BudgetVsActual } from "@/components/budget/BudgetVsActual";
import { BudgetMonthlyKPIs } from "@/components/budget/BudgetMonthlyKPIs";
import { AppLayout } from "@/components/AppLayout";
import { 
  Calendar,
  TrendingUp,
  Users,
  FileSpreadsheet,
  CheckCircle,
  Building2,
  BarChart3,
  ChevronLeft,
  ChevronRight,
  Settings2
} from "lucide-react";

const MANAGER_ROLES = ['salon_owner', 'daglig_leder', 'avdelingsleder', 'admin'];

interface BudgetVersion {
  id: string;
  versjon_navn: string;
  versjon_nummer: number;
  aar: number;
  er_aktiv: boolean;
  godkjent_av: string | null;
  godkjent_dato: string | null;
  beskrivelse: string | null;
  created_at: string;
}

export default function Budget() {
  const navigate = useNavigate();
  const { profile, loading: authLoading } = useAuth();
  const { toast } = useToast();
  const { salons, selectedSalonId, setSelectedSalonId, loading: salonLoading, canSelectSalon } = useSalonContext();
  
  const [selectedYear, setSelectedYear] = useState<number>(new Date().getFullYear());
  const [versions, setVersions] = useState<BudgetVersion[]>([]);
  const [activeVersion, setActiveVersion] = useState<BudgetVersion | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("overview");
  const [generatorRefreshKey, setGeneratorRefreshKey] = useState(0);

  const currentYear = new Date().getFullYear();
  const years = Array.from({ length: 9 }, (_, i) => currentYear - 5 + i);

  const isAuthorized = profile?.role && MANAGER_ROLES.includes(profile.role);

  useEffect(() => {
    if (!selectedSalonId) {
      setLoading(false);
      return;
    }

    const fetchVersions = async () => {
      setLoading(true);
      try {
        const { data, error } = await supabase
          .from("budsjett_versjoner")
          .select("*")
          .eq("salon_id", selectedSalonId)
          .eq("aar", selectedYear)
          .order("versjon_nummer", { ascending: false });

        if (error) throw error;
        
        setVersions(data || []);
        const active = data?.find(v => v.er_aktiv) || data?.[0] || null;
        setActiveVersion(active);
      } catch (error) {
        console.error("Error fetching versions:", error);
        toast({
          title: "Feil",
          description: "Kunne ikke hente budsjettversjoner",
          variant: "destructive"
        });
      } finally {
        setLoading(false);
      }
    };

    fetchVersions();
  }, [selectedSalonId, selectedYear]);

  if (authLoading || salonLoading) {
    return (
      <div className="min-h-screen bg-background p-4 md:p-8">
        <Skeleton className="h-8 w-48 mb-6" />
        <Skeleton className="h-[400px] w-full" />
      </div>
    );
  }

  if (!isAuthorized) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>Ingen tilgang</CardTitle>
            <CardDescription>
              Du har ikke tilgang til budsjettadministrasjon.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => navigate("/dashboard")}>
              Tilbake til dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <AppLayout title="Budsjett" subtitle="Administrer budsjetter og mål for salongen">
      <div className="max-w-7xl mx-auto p-4 md:p-8 space-y-6">
        {/* Controls */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8"
              onClick={() => setSelectedYear(y => y - 1)}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Select 
              value={selectedYear.toString()} 
              onValueChange={(v) => setSelectedYear(parseInt(v))}
            >
              <SelectTrigger className="w-[120px]">
                <Calendar className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {years.map(year => (
                  <SelectItem key={year} value={year.toString()}>
                    {year}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8"
              onClick={() => setSelectedYear(y => y + 1)}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Active version indicator */}
        {activeVersion && (
          <Card className="bg-primary/5 border-primary/20">
            <CardContent className="py-3 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <FileSpreadsheet className="h-5 w-5 text-primary" />
                <div>
                  <span className="font-medium">{activeVersion.versjon_navn}</span>
                  <span className="text-muted-foreground ml-2">
                    (v{activeVersion.versjon_nummer})
                  </span>
                </div>
                {activeVersion.er_aktiv && (
                  <Badge variant="default" className="bg-green-600">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    Aktiv
                  </Badge>
                )}
                {activeVersion.godkjent_dato && (
                  <Badge variant="outline">Godkjent</Badge>
                )}
              </div>
              {activeVersion.beskrivelse && (
                <span className="text-sm text-muted-foreground hidden md:block">
                  {activeVersion.beskrivelse}
                </span>
              )}
            </CardContent>
          </Card>
        )}

        {/* Main content tabs */}
        <Tabs value={activeTab} onValueChange={(tab) => {
          setActiveTab(tab);
          if (tab === 'generate') {
            setGeneratorRefreshKey(prev => prev + 1);
          }
        }}>
          <TabsList className="grid w-full grid-cols-7">
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              <span className="hidden sm:inline">Oversikt</span>
            </TabsTrigger>
            <TabsTrigger value="avvik" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              <span className="hidden sm:inline">Avvik</span>
            </TabsTrigger>
            <TabsTrigger value="kpi" className="flex items-center gap-2">
              <Settings2 className="h-4 w-4" />
              <span className="hidden sm:inline">Mnd KPI</span>
            </TabsTrigger>
            <TabsTrigger value="generate" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              <span className="hidden sm:inline">Generer</span>
            </TabsTrigger>
            <TabsTrigger value="manuelt" className="flex items-center gap-2">
              <Building2 className="h-4 w-4" />
              <span className="hidden sm:inline">Manuelt</span>
            </TabsTrigger>
            <TabsTrigger value="fastsatt" className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4" />
              <span className="hidden sm:inline">Fastsatt</span>
            </TabsTrigger>
            <TabsTrigger value="versions" className="flex items-center gap-2">
              <FileSpreadsheet className="h-4 w-4" />
              <span className="hidden sm:inline">Versjoner</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-6">
            {selectedSalonId && activeVersion ? (
              <BudgetOverview 
                salonId={selectedSalonId}
                versionId={activeVersion.id}
                year={selectedYear}
                salonName={salons.find(s => s.id === selectedSalonId)?.name}
                versionName={activeVersion.versjon_navn}
              />
            ) : (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  {!selectedSalonId 
                    ? "Velg en salong for å se budsjettoversikt"
                    : "Ingen aktiv budsjettversjon. Opprett en ny versjon først."
                  }
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="avvik" className="mt-6">
            {selectedSalonId && activeVersion ? (
              <BudgetVsActual 
                salonId={selectedSalonId}
                versionId={activeVersion.id}
                year={selectedYear}
              />
            ) : (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  {!selectedSalonId 
                    ? "Velg en salong for å se avviksrapport"
                    : "Ingen aktiv budsjettversjon."
                  }
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="kpi" className="mt-6">
            {selectedSalonId && activeVersion ? (
              <BudgetMonthlyKPIs
                salonId={selectedSalonId}
                versionId={activeVersion.id}
                year={selectedYear}
              />
            ) : (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  {!selectedSalonId 
                    ? "Velg en salong for å sette månedlige KPI-verdier"
                    : "Opprett en budsjettversjon først."
                  }
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="generate" className="mt-6">
            {selectedSalonId && activeVersion ? (
              <BudgetGenerator
                salonId={selectedSalonId}
                versionId={activeVersion.id}
                year={selectedYear}
                onGenerated={() => setActiveTab("overview")}
                refreshKey={generatorRefreshKey}
              />
            ) : (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  {!selectedSalonId 
                    ? "Velg en salong for å generere budsjett"
                    : "Opprett en budsjettversjon først i Versjoner-fanen."
                  }
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="manuelt" className="mt-6">
            {selectedSalonId && activeVersion ? (
              <BudgetManuelt
                salonId={selectedSalonId}
                versionId={activeVersion.id}
                year={selectedYear}
              />
            ) : (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  {!selectedSalonId 
                    ? "Velg en salong for å legge til manuelt budsjett"
                    : "Opprett en budsjettversjon først."
                  }
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="fastsatt" className="mt-6">
            {selectedSalonId && activeVersion ? (
              <BudgetFastsatt
                salonId={selectedSalonId}
                versionId={activeVersion.id}
                year={selectedYear}
              />
            ) : (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  {!selectedSalonId 
                    ? "Velg en salong for å se fastsatte budsjetter"
                    : "Opprett en budsjettversjon først."
                  }
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="versions" className="mt-6">
            {selectedSalonId ? (
              <BudgetVersionManager
                salonId={selectedSalonId}
                year={selectedYear}
                versions={versions}
                activeVersion={activeVersion}
                onVersionsChange={(newVersions) => {
                  setVersions(newVersions);
                  const active = newVersions.find(v => v.er_aktiv) || newVersions[0] || null;
                  setActiveVersion(active);
                }}
              />
            ) : (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  Velg en salong for å administrere budsjettversjoner
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}
