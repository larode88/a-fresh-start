import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { getISOWeek, getISOWeekYear } from "date-fns";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { WeekSelector } from "@/components/WeekSelector";
import { ArrowLeft, Save, User } from "lucide-react";
import { NavLink } from "@/components/NavLink";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const kpiInputSchema = z.object({
  treatmentRevenue: z.coerce.number().min(0, "Må være 0 eller høyere"),
  retailRevenue: z.coerce.number().min(0, "Må være 0 eller høyere"),
  visitCount: z.coerce.number().int().min(0, "Må være 0 eller høyere"),
  visitsWithAddon: z.coerce.number().int().min(0, "Må være 0 eller høyere"),
  addonCount: z.coerce.number().int().min(0, "Må være 0 eller høyere"),
  rebookedVisits: z.coerce.number().int().min(0, "Må være 0 eller høyere"),
  hoursWorked: z.coerce.number().min(0, "Må være 0 eller høyere"),
  hoursWithClient: z.coerce.number().min(0, "Må være 0 eller høyere"),
});

type KPIInputValues = z.infer<typeof kpiInputSchema>;

interface TeamMember {
  id: string;
  name: string;
  role: string;
  avatar_url: string | null;
}

// Roles that can enter data for others
const MANAGER_ROLES = ['salon_owner', 'daglig_leder', 'avdelingsleder', 'admin'];

export default function KPIInput() {
  const { profile, loading } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { toast } = useToast();
  const [submitting, setSubmitting] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [existingData, setExistingData] = useState<any>(null);
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([]);
  const [selectedStylistId, setSelectedStylistId] = useState<string | null>(null);
  const [loadingTeam, setLoadingTeam] = useState(false);
  const [initializedFromUrl, setInitializedFromUrl] = useState(false);

  const isManager = profile?.role && MANAGER_ROLES.includes(profile.role);

  const form = useForm<KPIInputValues>({
    resolver: zodResolver(kpiInputSchema),
    defaultValues: {
      treatmentRevenue: 0,
      retailRevenue: 0,
      visitCount: 0,
      visitsWithAddon: 0,
      addonCount: 0,
      rebookedVisits: 0,
      hoursWorked: 0,
      hoursWithClient: 0,
    },
  });

  useEffect(() => {
    if (!loading && !profile) {
      navigate("/login");
    }
  }, [loading, profile, navigate]);

  // Fetch team members for managers
  useEffect(() => {
    if (isManager && profile?.salon_id) {
      fetchTeamMembers();
    }
  }, [isManager, profile?.salon_id]);

  // Initialize from URL parameters or set defaults
  useEffect(() => {
    if (initializedFromUrl || !profile?.id) return;

    const urlStylistId = searchParams.get("stylistId");
    const urlYear = searchParams.get("year");
    const urlWeek = searchParams.get("week");

    // Set stylist from URL or default to self
    if (urlStylistId && isManager) {
      setSelectedStylistId(urlStylistId);
    } else if (!selectedStylistId) {
      setSelectedStylistId(profile.id);
    }

    // Set date from URL parameters
    if (urlYear && urlWeek) {
      const year = parseInt(urlYear, 10);
      const week = parseInt(urlWeek, 10);
      // Create date from ISO week
      const date = new Date(year, 0, 1 + (week - 1) * 7);
      // Adjust to Monday of that week
      const dayOfWeek = date.getDay();
      const diff = date.getDate() - dayOfWeek + (dayOfWeek === 0 ? -6 : 1);
      date.setDate(diff);
      setSelectedDate(date);
    }

    setInitializedFromUrl(true);
  }, [profile?.id, searchParams, isManager, initializedFromUrl]);

  // Fetch data when stylist or date changes
  useEffect(() => {
    if (selectedStylistId) {
      fetchExistingData();
    }
  }, [selectedStylistId, selectedDate]);

  const fetchTeamMembers = async () => {
    if (!profile?.salon_id) return;
    
    setLoadingTeam(true);
    try {
      const { data, error } = await supabase
        .from("users")
        .select("id, name, role, avatar_url")
        .eq("salon_id", profile.salon_id)
        .order("name");

      if (error) throw error;
      setTeamMembers(data || []);
    } catch (error) {
      console.error("Error fetching team members:", error);
    } finally {
      setLoadingTeam(false);
    }
  };

  const fetchExistingData = async () => {
    if (!selectedStylistId || !profile?.salon_id) return;

    const week = getISOWeek(selectedDate);
    const year = getISOWeekYear(selectedDate);

    // Reset form first
    form.reset({
      treatmentRevenue: 0,
      retailRevenue: 0,
      visitCount: 0,
      visitsWithAddon: 0,
      addonCount: 0,
      rebookedVisits: 0,
      hoursWorked: 0,
      hoursWithClient: 0,
    });
    setExistingData(null);

    const { data, error } = await supabase
      .from("weekly_kpi_inputs")
      .select("*")
      .eq("stylist_id", selectedStylistId)
      .eq("week", week)
      .eq("year", year)
      .maybeSingle();

    if (error) {
      console.error("Error fetching existing data:", error);
      return;
    }

    if (data) {
      setExistingData(data);
      form.reset({
        treatmentRevenue: data.treatment_revenue,
        retailRevenue: data.retail_revenue,
        visitCount: data.visit_count,
        visitsWithAddon: data.visits_with_addon,
        addonCount: data.addon_count,
        rebookedVisits: data.rebooked_visits,
        hoursWorked: data.hours_worked,
        hoursWithClient: data.hours_with_client,
      });
    }
  };

  const onSubmit = async (values: KPIInputValues) => {
    if (!profile?.id || !profile?.salon_id || !selectedStylistId) {
      toast({
        title: "Feil",
        description: "Du må være tilknyttet en salong for å registrere KPI-data",
        variant: "destructive",
      });
      return;
    }

    setSubmitting(true);

    try {
      const week = getISOWeek(selectedDate);
      const year = getISOWeekYear(selectedDate);

      const dataToSubmit = {
        stylist_id: selectedStylistId,
        salon_id: profile.salon_id,
        week,
        year,
        treatment_revenue: values.treatmentRevenue,
        retail_revenue: values.retailRevenue,
        visit_count: values.visitCount,
        visits_with_addon: values.visitsWithAddon,
        addon_count: values.addonCount,
        rebooked_visits: values.rebookedVisits,
        hours_worked: values.hoursWorked,
        hours_with_client: values.hoursWithClient,
        submitted_by_user_id: profile.id,
      };

      let error;

      if (existingData) {
        const { error: updateError } = await supabase
          .from("weekly_kpi_inputs")
          .update(dataToSubmit)
          .eq("id", existingData.id);
        error = updateError;
      } else {
        const { error: insertError } = await supabase
          .from("weekly_kpi_inputs")
          .insert(dataToSubmit);
        error = insertError;
      }

      if (error) throw error;

      const selectedMember = teamMembers.find(m => m.id === selectedStylistId);
      const isOwnData = selectedStylistId === profile.id;
      
      toast({
        title: "Suksess!",
        description: isOwnData 
          ? (existingData ? "KPI-data oppdatert" : "KPI-data registrert")
          : `KPI-data ${existingData ? "oppdatert" : "registrert"} for ${selectedMember?.name || "frisør"}`,
      });

      navigate("/dashboard");
    } catch (error: any) {
      console.error("Error submitting KPI data:", error);
      toast({
        title: "Feil",
        description: error.message || "Kunne ikke lagre data",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const selectedMember = teamMembers.find(m => m.id === selectedStylistId);
  const isOwnData = selectedStylistId === profile?.id;

  const getRoleLabel = (role: string) => {
    const roleLabels: Record<string, string> = {
      salon_owner: "Eier",
      daglig_leder: "Daglig leder",
      avdelingsleder: "Avdelingsleder",
      stylist: "Frisør",
      seniorfrisor: "Seniorfrisør",
      apprentice: "Lærling",
    };
    return roleLabels[role] || role;
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Laster...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 pb-24">
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row items-start gap-4">
          <div className="flex items-center gap-4">
            <NavLink to="/dashboard">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </NavLink>
            <div>
              <h1 className="text-2xl font-bold">Registrer Ukesdata</h1>
              <p className="text-sm text-muted-foreground">
                Velg uke og fyll inn data
              </p>
            </div>
          </div>
          <div className="sm:ml-auto">
            <WeekSelector
              selectedDate={selectedDate}
              onDateChange={setSelectedDate}
            />
          </div>
        </div>

        {/* Stylist selector for managers */}
        {isManager && teamMembers.length > 0 && (
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <User className="h-4 w-4" />
                Registrer for
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Select
                value={selectedStylistId || ""}
                onValueChange={setSelectedStylistId}
                disabled={loadingTeam}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Velg frisør">
                    {selectedMember && (
                      <div className="flex items-center gap-2">
                        <Avatar className="h-6 w-6">
                          <AvatarImage src={selectedMember.avatar_url || undefined} />
                          <AvatarFallback className="text-xs">
                            {selectedMember.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
                          </AvatarFallback>
                        </Avatar>
                        <span>{selectedMember.name}</span>
                        {isOwnData && <span className="text-muted-foreground">(deg selv)</span>}
                      </div>
                    )}
                  </SelectValue>
                </SelectTrigger>
                <SelectContent>
                  {teamMembers.map((member) => (
                    <SelectItem key={member.id} value={member.id}>
                      <div className="flex items-center gap-2">
                        <Avatar className="h-6 w-6">
                          <AvatarImage src={member.avatar_url || undefined} />
                          <AvatarFallback className="text-xs">
                            {member.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
                          </AvatarFallback>
                        </Avatar>
                        <span>{member.name}</span>
                        <span className="text-muted-foreground text-xs">
                          ({getRoleLabel(member.role)})
                        </span>
                        {member.id === profile?.id && (
                          <span className="text-muted-foreground text-xs">(deg selv)</span>
                        )}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardHeader>
            <CardTitle>Ukentlig KPI-inndata</CardTitle>
            <CardDescription>
              {!isOwnData && selectedMember 
                ? `Registrerer data for ${selectedMember.name}`
                : existingData 
                  ? "Oppdater dine tall for denne uken"
                  : "Fyll inn dine tall for denne uken"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="space-y-4">
                  <h3 className="font-semibold text-sm text-muted-foreground uppercase">
                    Omsetning
                  </h3>
                  <FormField
                    control={form.control}
                    name="treatmentRevenue"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Behandlingsomsetning (kr)</FormLabel>
                        <FormControl>
                          <Input type="number" step="0.01" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="retailRevenue"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Produktomsetning (kr)</FormLabel>
                        <FormControl>
                          <Input type="number" step="0.01" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="space-y-4">
                  <h3 className="font-semibold text-sm text-muted-foreground uppercase">
                    Besøk
                  </h3>
                  <FormField
                    control={form.control}
                    name="visitCount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Antall besøk</FormLabel>
                        <FormControl>
                          <Input type="number" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="visitsWithAddon"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Besøk med tilleggsbehandling</FormLabel>
                        <FormControl>
                          <Input type="number" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="addonCount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Antall tilleggsbehandlinger</FormLabel>
                        <FormControl>
                          <Input type="number" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="rebookedVisits"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Antall rebookinger</FormLabel>
                        <FormControl>
                          <Input type="number" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="space-y-4">
                  <h3 className="font-semibold text-sm text-muted-foreground uppercase">
                    Timer
                  </h3>
                  <FormField
                    control={form.control}
                    name="hoursWorked"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Timer jobbet</FormLabel>
                        <FormControl>
                          <Input type="number" step="0.5" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="hoursWithClient"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Timer med kunde</FormLabel>
                        <FormControl>
                          <Input type="number" step="0.5" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <Button 
                  type="submit" 
                  className="w-full" 
                  size="lg"
                  disabled={submitting}
                >
                  <Save className="mr-2 h-5 w-5" />
                  {submitting ? "Lagrer..." : existingData ? "Oppdater data" : "Lagre data"}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
