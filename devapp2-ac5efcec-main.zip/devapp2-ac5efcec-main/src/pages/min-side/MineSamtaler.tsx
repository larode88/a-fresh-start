// Mine Samtaler - Medarbeidersamtaler for ansatte
import { useAnsattSelectorContext } from "@/components/AnsattSelector";
import { useCurrentAnsatt } from "@/hooks/useCurrentAnsatt";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { format } from "date-fns";
import { nb } from "date-fns/locale";
import { MessageCircle, Calendar, Clock, FileText, ChevronRight, CheckCircle2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { AppLayout } from "@/components/AppLayout";

export default function MineSamtaler() {
  const navigate = useNavigate();
  const { selectedAnsatt, isViewingAsOther } = useAnsattSelectorContext();
  const { ansatt: currentAnsatt, isLoading: isLoadingAnsatt } = useCurrentAnsatt();
  const ansatt = selectedAnsatt || currentAnsatt;

  // Fetch samtaler - bruker ansatt_id som primærnøkkel
  const { data: samtaler, isLoading: isLoadingSamtaler } = useQuery({
    queryKey: ['mine-samtaler', ansatt?.id],
    queryFn: async () => {
      if (!ansatt?.id) return { planlagte: [], tidligere: [] };
      
      const today = new Date().toISOString().split('T')[0];
      
      // Build OR filter - ansatt_id primary, user_id fallback
      const dummyId = '00000000-0000-0000-0000-000000000000';
      const userId = ansatt.user_id || dummyId;
      const orFilter = `ansatt_id.eq.${ansatt.id},user_id.eq.${userId}`;
      
      // Planlagte samtaler
      const { data: planlagte } = await supabase
        .from('ansatt_samtaler')
        .select('*')
        .or(orFilter)
        .gte('dato', today)
        .order('dato', { ascending: true });
      
      // Tidligere samtaler
      const { data: tidligere } = await supabase
        .from('ansatt_samtaler')
        .select('*')
        .or(orFilter)
        .lt('dato', today)
        .order('dato', { ascending: false })
        .limit(10);
      
      return {
        planlagte: planlagte || [],
        tidligere: tidligere || []
      };
    },
    enabled: !!ansatt?.id,
  });

  const isLoading = isLoadingAnsatt || isLoadingSamtaler;

  const getStatusBadge = (status: string | null) => {
    switch (status) {
      case 'planlagt':
        return <Badge variant="outline">Planlagt</Badge>;
      case 'pagar':
        return <Badge className="bg-blue-500/10 text-blue-700">Pågår</Badge>;
      case 'fullfort':
        return <Badge className="bg-green-500/10 text-green-700">Fullført</Badge>;
      case 'kansellert':
        return <Badge variant="destructive">Kansellert</Badge>;
      default:
        return <Badge variant="secondary">{status || 'Ukjent'}</Badge>;
    }
  };

  const getSamtaleTypeLabel = (type: string) => {
    const types: Record<string, string> = {
      'medarbeidersamtale': 'Medarbeidersamtale',
      'oppfolgingssamtale': 'Oppfølgingssamtale',
      'utviklingssamtale': 'Utviklingssamtale',
      'onboarding': 'Onboarding',
      'offboarding': 'Offboarding'
    };
    return types[type] || type;
  };

  if (isLoading) {
    return (
      <AppLayout>
        <div className="container max-w-3xl mx-auto py-8 px-4 space-y-6">
          <Skeleton className="h-10 w-48" />
          <Skeleton className="h-40 w-full" />
          <Skeleton className="h-40 w-full" />
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="container max-w-3xl mx-auto py-8 px-4 space-y-6">
        <div>
          <div className="flex items-center gap-3">
            <MessageCircle className="h-6 w-6 text-primary" />
            <h1 className="text-2xl font-bold">Mine samtaler</h1>
          </div>
          {isViewingAsOther && ansatt && (
            <p className="text-sm text-muted-foreground mt-1 ml-9">
              Viser for: <span className="font-medium text-foreground">{ansatt.fornavn} {ansatt.etternavn}</span>
            </p>
          )}
        </div>

        <Tabs defaultValue="planlagte" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="planlagte">
              Planlagte
              {samtaler?.planlagte && samtaler.planlagte.length > 0 && (
                <Badge variant="secondary" className="ml-2">{samtaler.planlagte.length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="tidligere">Tidligere</TabsTrigger>
          </TabsList>

          <TabsContent value="planlagte" className="space-y-4 mt-4">
            {samtaler?.planlagte && samtaler.planlagte.length > 0 ? (
              samtaler.planlagte.map((samtale: any) => (
                <Card 
                  key={samtale.id} 
                  className="hover:shadow-md transition-shadow cursor-pointer"
                  onClick={() => navigate(`/hr/samtale/${samtale.id}/forberedelse?type=medarbeider`)}
                >
                  <CardContent className="py-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="font-semibold">
                            {getSamtaleTypeLabel(samtale.samtale_type)}
                          </h3>
                          {getStatusBadge(samtale.status)}
                        </div>
                        
                        <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                          <div className="flex items-center gap-1.5">
                            <Calendar className="h-4 w-4" />
                            {format(new Date(samtale.dato), 'd. MMMM yyyy', { locale: nb })}
                          </div>
                          {samtale.sted && (
                            <div className="flex items-center gap-1.5">
                              <Clock className="h-4 w-4" />
                              {samtale.sted}
                            </div>
                          )}
                        </div>

                        {samtale.forberedelses_frist && (
                          <div className="mt-3 p-3 bg-amber-50 dark:bg-amber-950/20 rounded-lg border border-amber-200 dark:border-amber-800">
                            <div className="flex items-center gap-2 text-amber-800 dark:text-amber-200">
                              <FileText className="h-4 w-4" />
                              <span className="text-sm">
                                Forberedelse innen {format(new Date(samtale.forberedelses_frist), 'd. MMM', { locale: nb })}
                              </span>
                            </div>
                            <Button 
                              variant="link" 
                              className="p-0 h-auto mt-1 text-amber-700 dark:text-amber-300"
                              onClick={() => navigate(`/hr/samtale/${samtale.id}/forberedelse`)}
                            >
                              Start forberedelse →
                            </Button>
                          </div>
                        )}
                      </div>
                      <ChevronRight className="h-5 w-5 text-muted-foreground" />
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card>
                <CardContent className="py-12 text-center">
                  <Calendar className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="font-semibold mb-1">Ingen planlagte samtaler</h3>
                  <p className="text-sm text-muted-foreground">
                    Du har ingen kommende samtaler planlagt
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="tidligere" className="space-y-4 mt-4">
            {samtaler?.tidligere && samtaler.tidligere.length > 0 ? (
              samtaler.tidligere.map((samtale: any) => (
                <Card key={samtale.id} className="opacity-80 hover:opacity-100 transition-opacity">
                  <CardContent className="py-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="font-semibold">
                            {getSamtaleTypeLabel(samtale.samtale_type)}
                          </h3>
                          {getStatusBadge(samtale.status)}
                        </div>
                        
                        <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                          <Calendar className="h-4 w-4" />
                          {format(new Date(samtale.dato), 'd. MMMM yyyy', { locale: nb })}
                        </div>

                        {samtale.sammendrag && (
                          <p className="mt-2 text-sm text-muted-foreground line-clamp-2">
                            {samtale.sammendrag}
                          </p>
                        )}
                      </div>
                      {samtale.status === 'fullfort' && (
                        <CheckCircle2 className="h-5 w-5 text-green-500" />
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card>
                <CardContent className="py-12 text-center">
                  <FileText className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="font-semibold mb-1">Ingen tidligere samtaler</h3>
                  <p className="text-sm text-muted-foreground">
                    Historikk over gjennomførte samtaler vises her
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}
