// Min Profil - Ansattens personlige profilside
import { useAnsattSelectorContext } from "@/components/AnsattSelector";
import { useCurrentAnsatt } from "@/hooks/useCurrentAnsatt";
import { format } from "date-fns";
import { nb } from "date-fns/locale";
import { User, Mail, Phone, Building2, Calendar, Clock, Briefcase } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { AnsattStillingssammenligning } from "@/components/ansatte/AnsattStillingssammenligning";
import { AppLayout } from "@/components/AppLayout";

export default function MinProfil() {
  const { selectedAnsatt, isViewingAsOther } = useAnsattSelectorContext();
  const { ansatt: currentAnsatt, isLoading } = useCurrentAnsatt();
  const ansatt = selectedAnsatt || currentAnsatt;

  const getInitials = (fornavn?: string, etternavn?: string | null) => {
    const f = fornavn?.charAt(0) || '';
    const e = etternavn?.charAt(0) || '';
    return (f + e).toUpperCase() || '?';
  };

  if (isLoading) {
    return (
      <AppLayout>
        <div className="container max-w-3xl mx-auto py-8 px-4 space-y-6">
          <Skeleton className="h-40 w-full" />
          <Skeleton className="h-60 w-full" />
        </div>
      </AppLayout>
    );
  }

  if (!ansatt) {
    return (
      <AppLayout>
        <div className="container max-w-3xl mx-auto py-8 px-4">
          <Card>
            <CardContent className="py-12 text-center">
              <User className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <h2 className="text-xl font-semibold mb-2">Ingen profil funnet</h2>
              <p className="text-muted-foreground">
                Du er ikke registrert som ansatt i systemet.
              </p>
            </CardContent>
          </Card>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="container max-w-3xl mx-auto py-8 px-4 space-y-6">
        {/* Profil-header */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
              <Avatar className="h-24 w-24">
                <AvatarImage src={ansatt.profilbilde_url || undefined} />
                <AvatarFallback className="text-2xl bg-primary/10 text-primary">
                  {getInitials(ansatt.fornavn, ansatt.etternavn)}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1 text-center sm:text-left">
                <h1 className="text-2xl font-bold">{ansatt.navn}</h1>
                <p className="text-muted-foreground">{ansatt.rolle_display}</p>
                {isViewingAsOther && (
                  <p className="text-sm text-amber-600 dark:text-amber-400 mt-1">
                    Viser profil for annen ansatt
                  </p>
                )}
                <div className="flex flex-wrap gap-2 mt-3 justify-center sm:justify-start">
                  {ansatt.frisorfunksjon && (
                    <Badge variant="secondary">{ansatt.frisorfunksjon}</Badge>
                  )}
                  {ansatt.lederstilling && (
                    <Badge variant="outline">{ansatt.lederstilling}</Badge>
                  )}
                  <Badge 
                    variant={ansatt.status === 'aktiv' ? 'default' : 'secondary'}
                    className={ansatt.status === 'aktiv' ? 'bg-green-500/10 text-green-700 hover:bg-green-500/20' : ''}
                  >
                    {ansatt.status}
                  </Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Kontaktinformasjon */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Kontaktinformasjon</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {ansatt.epost && (
              <div className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">E-post</p>
                  <p className="font-medium">{ansatt.epost}</p>
                </div>
              </div>
            )}
            
            {ansatt.telefon && (
              <div className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Telefon</p>
                  <p className="font-medium">{ansatt.telefon}</p>
                </div>
              </div>
            )}
            
            {ansatt.salong_navn && (
              <div className="flex items-center gap-3">
                <Building2 className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Salong</p>
                  <p className="font-medium">{ansatt.salong_navn}</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Ansettelsesforhold */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Ansettelsesforhold</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {ansatt.ansatt_dato && (
                <div className="flex items-center gap-3">
                  <Calendar className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Ansatt siden</p>
                    <p className="font-medium">
                      {format(new Date(ansatt.ansatt_dato), 'd. MMMM yyyy', { locale: nb })}
                    </p>
                  </div>
                </div>
              )}
              
              {ansatt.ansiennitet_aar !== null && (
                <div className="flex items-center gap-3">
                  <Briefcase className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Ansiennitet</p>
                    <p className="font-medium">{ansatt.ansiennitet_aar} år</p>
                  </div>
                </div>
              )}
              
              <div className="flex items-center gap-3">
                <Clock className="h-5 w-5 text-muted-foreground" />
                <div>
                  <p className="text-sm text-muted-foreground">Stillingsprosent</p>
                  <p className="font-medium">{ansatt.stillingsprosent}%</p>
                </div>
              </div>
              
              {ansatt.alder !== null && (
                <div className="flex items-center gap-3">
                  <User className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Alder</p>
                    <p className="font-medium">{ansatt.alder} år</p>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Stillingssammenligning */}
        {ansatt.salong_id && (
          <AnsattStillingssammenligning 
            ansattId={ansatt.id}
            salongId={ansatt.salong_id}
            avtaltStillingsprosent={ansatt.stillingsprosent}
          />
        )}
      </div>
    </AppLayout>
  );
}
