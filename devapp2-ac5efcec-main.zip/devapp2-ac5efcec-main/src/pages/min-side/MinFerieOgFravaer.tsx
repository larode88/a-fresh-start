// Min Ferie og Fravær - Feriesaldo og fraværsregistrering
import { useState } from "react";
import { useAnsattSelectorContext } from "@/components/AnsattSelector";
import { useCurrentAnsatt } from "@/hooks/useCurrentAnsatt";
import { useUserRole } from "@/hooks/useUserRole";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { format, parseISO, differenceInBusinessDays } from "date-fns";
import { nb } from "date-fns/locale";
import { Plane, Thermometer, Users, Stethoscope, Calendar, Clock, Plus, ChevronLeft, ChevronRight, CalendarDays, FileText } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AppLayout } from "@/components/AppLayout";
import { MinFerieSoknadDialog } from "@/components/min-side/MinFerieSoknadDialog";
import { MinFravaerRegistreringDialog } from "@/components/min-side/MinFravaerRegistreringDialog";
import { MinPermisjonSoknadDialog } from "@/components/min-side/MinPermisjonSoknadDialog";

export default function MinFerieOgFravaer() {
  const { selectedAnsatt, isViewingAsOther } = useAnsattSelectorContext();
  const { ansatt: currentAnsatt, isLoading: isLoadingAnsatt } = useCurrentAnsatt();
  const { isAdmin } = useUserRole();
  const queryClient = useQueryClient();
  
  // Use selected ansatt if viewing as other, otherwise use current user
  const ansatt = selectedAnsatt || currentAnsatt;
  
  const currentYear = new Date().getFullYear();
  const [selectedYear, setSelectedYear] = useState(currentYear);
  const years = Array.from({ length: 9 }, (_, i) => currentYear - 5 + i);
  
  const [showFerieDialog, setShowFerieDialog] = useState(false);
  const [showFravaerDialog, setShowFravaerDialog] = useState(false);
  const [showPermisjonDialog, setShowPermisjonDialog] = useState(false);

  const handleSuccess = () => {
    queryClient.invalidateQueries({ queryKey: ['min-ferie-og-fravaer'] });
  };

  // Fetch ferie og fravær data
  const { data, isLoading: isLoadingData } = useQuery({
    queryKey: ['min-ferie-og-fravaer', ansatt?.id, selectedYear],
    queryFn: async () => {
      if (!ansatt?.id) return null;
      
      // Get ansatt data including id and user_id
      const { data: ansattData } = await supabase
        .from('ansatte')
        .select('id, user_id, feriekrav_timer_per_aar, stillingsprosent')
        .eq('id', ansatt.id)
        .single();
      
      if (!ansattData) return null;
      
      // Use dummy UUID for null user_id to make OR query work
      const userId = ansattData.user_id || '00000000-0000-0000-0000-000000000000';
      
      // Fetch ferie - use ansatt_id as primary, user_id as fallback
      // Ekskluder estimater fra ansattes visning (kun synlig for ledelse i Ferie-siden)
      const { data: ferieData } = await supabase
        .from('ferie')
        .select('*')
        .or(`ansatt_id.eq.${ansatt.id},user_id.eq.${userId}`)
        .eq('aar', selectedYear)
        .neq('status', 'estimat')
        .order('startdato', { ascending: false });
      
      // Fetch fravær - same logic
      const { data: fravaerData } = await supabase
        .from('fravaer')
        .select('*')
        .or(`ansatt_id.eq.${ansatt.id},user_id.eq.${userId}`)
        .gte('startdato', `${selectedYear}-01-01`)
        .lte('startdato', `${selectedYear}-12-31`)
        .order('startdato', { ascending: false });
      
      // Fetch overføringer
      const { data: overforingData } = await supabase
        .from('ferie_overforing')
        .select('*')
        .or(`ansatt_id.eq.${ansatt.id},user_id.eq.${userId}`)
        .eq('til_aar', selectedYear);
      
      // Calculate brukt (godkjent only)
      const bruktTimer = (ferieData || [])
        .filter((f: any) => f.status === 'godkjent')
        .reduce((sum: number, f: any) => sum + (f.timer || 0), 0);
      
      // Calculate planlagt (pending/planlagt - not yet approved)
      const planlagtTimer = (ferieData || [])
        .filter((f: any) => f.status === 'pending' || f.status === 'planlagt')
        .reduce((sum: number, f: any) => sum + (f.timer || 0), 0);
      
      const overfartTimer = (overforingData || [])
        .filter((o: any) => o.godkjent_dato)
        .reduce((sum: number, o: any) => sum + (o.timer || 0), 0);
      
      const totaltTimer = (ansattData.feriekrav_timer_per_aar || 0) + overfartTimer;
      
      return {
        ferie: ferieData || [],
        fravaer: fravaerData || [],
        saldo: {
          brukt: bruktTimer,
          planlagt: planlagtTimer,
          totalt: totaltTimer,
          overfart: overfartTimer,
          gjenstar: totaltTimer - bruktTimer - planlagtTimer
        },
        feriekrav: ansattData.feriekrav_timer_per_aar || 0
      };
    },
    enabled: !!ansatt?.id,
  });

  const isLoading = isLoadingAnsatt || isLoadingData;

  // Admin can always take actions on behalf of employees
  const canTakeActions = isAdmin || !isViewingAsOther;

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'godkjent':
        return <Badge className="bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400">Godkjent</Badge>;
      case 'pending':
      case 'planlagt':
        return <Badge className="bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400">Venter godkjenning</Badge>;
      case 'avslatt':
        return <Badge className="bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400">Avslått</Badge>;
      case 'aktiv':
        return <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400">Aktiv</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getFravaerIcon = (type: string) => {
    switch (type) {
      case 'egenmelding':
      case 'sykmelding':
        return <Thermometer className="h-4 w-4" />;
      case 'permisjon':
        return <Users className="h-4 w-4" />;
      case 'lege':
        return <Stethoscope className="h-4 w-4" />;
      default:
        return <Calendar className="h-4 w-4" />;
    }
  };

  const getFerieTypeStyle = (type: string | null) => {
    switch (type) {
      case 'Sommerferie':
        return { label: 'Sommerferie', badgeClass: 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400', iconBg: 'bg-amber-100 dark:bg-amber-900/30', iconColor: 'text-amber-600 dark:text-amber-400' };
      case 'Vinterferie':
        return { label: 'Vinterferie', badgeClass: 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400', iconBg: 'bg-blue-100 dark:bg-blue-900/30', iconColor: 'text-blue-600 dark:text-blue-400' };
      case 'Påskeferie':
        return { label: 'Påskeferie', badgeClass: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400', iconBg: 'bg-yellow-100 dark:bg-yellow-900/30', iconColor: 'text-yellow-600 dark:text-yellow-400' };
      case 'Høstferie':
        return { label: 'Høstferie', badgeClass: 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400', iconBg: 'bg-orange-100 dark:bg-orange-900/30', iconColor: 'text-orange-600 dark:text-orange-400' };
      case 'Juleferie':
        return { label: 'Juleferie', badgeClass: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400', iconBg: 'bg-red-100 dark:bg-red-900/30', iconColor: 'text-red-600 dark:text-red-400' };
      case 'Annen ferie':
      default:
        return { label: type || 'Annen ferie', badgeClass: 'bg-slate-100 text-slate-800 dark:bg-slate-900/30 dark:text-slate-400', iconBg: 'bg-slate-100 dark:bg-slate-900/30', iconColor: 'text-slate-600 dark:text-slate-400' };
    }
  };

  const calculateArbeidsdager = (startdato: string, sluttdato: string) => {
    try {
      return differenceInBusinessDays(parseISO(sluttdato), parseISO(startdato)) + 1;
    } catch {
      return null;
    }
  };

  if (isLoading) {
    return (
      <AppLayout>
        <div className="container max-w-3xl mx-auto py-8 px-4 space-y-6">
          <Skeleton className="h-10 w-48" />
          <Skeleton className="h-40 w-full" />
          <Skeleton className="h-60 w-full" />
        </div>
      </AppLayout>
    );
  }

  const isOverbooked = data?.saldo && data.saldo.gjenstar < 0;
  const bruktProsent = data?.saldo ? (data.saldo.brukt / data.saldo.totalt) * 100 : 0;
  const planlagtProsent = data?.saldo ? (data.saldo.planlagt / data.saldo.totalt) * 100 : 0;

  return (
    <AppLayout>
      <div className="container max-w-3xl mx-auto py-8 px-4 space-y-6">
        {/* Clean Header Section */}
        <div className="space-y-4">
          {/* Row 1: Title and Year Selector */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold">Ferie & Fravær</h1>
              {isViewingAsOther && ansatt && (
                <p className="text-sm text-muted-foreground mt-1">
                  Viser for: <span className="font-medium text-foreground">{ansatt.fornavn} {ansatt.etternavn}</span>
                </p>
              )}
            </div>
            
            <div className="flex items-center gap-1">
              <Button
                variant="outline"
                size="icon"
                className="h-8 w-8"
                onClick={() => setSelectedYear(y => y - 1)}
                disabled={selectedYear <= currentYear - 5}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Select value={selectedYear.toString()} onValueChange={(v) => setSelectedYear(parseInt(v))}>
                <SelectTrigger className="w-[90px] h-8">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {years.map((year) => (
                    <SelectItem key={year} value={year.toString()}>{year}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button
                variant="outline"
                size="icon"
                className="h-8 w-8"
                onClick={() => setSelectedYear(y => y + 1)}
                disabled={selectedYear >= currentYear + 3}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Row 2: Action Buttons */}
          {canTakeActions && (
            <div className="flex flex-wrap gap-2">
              <Button onClick={() => setShowFerieDialog(true)} size="sm">
              <Plane className="h-4 w-4 mr-2" />
              Søk ferie
            </Button>
            <Button variant="outline" size="sm" onClick={() => setShowFravaerDialog(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Meld fravær
              </Button>
              <Button variant="outline" size="sm" onClick={() => setShowPermisjonDialog(true)}>
                <Calendar className="h-4 w-4 mr-2" />
                Søk permisjon
              </Button>
            </div>
          )}
        </div>

        {/* Feriesaldo Card - Enhanced with planlagt */}
        {data?.saldo && (
          <Card>
            <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <Plane className="h-5 w-5 text-primary" />
              Feriesaldo {selectedYear}
            </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Progress bar with two segments */}
              <div className="space-y-2">
                <div className="relative h-3 w-full overflow-hidden rounded-full bg-muted">
                  {/* Brukt (dark) */}
                  <div 
                    className="absolute h-full bg-primary transition-all"
                    style={{ width: `${Math.min(bruktProsent, 100)}%` }}
                  />
                  {/* Planlagt (lighter) */}
                  <div 
                    className="absolute h-full bg-primary/40 transition-all"
                    style={{ 
                      left: `${Math.min(bruktProsent, 100)}%`,
                      width: `${Math.min(planlagtProsent, 100 - bruktProsent)}%` 
                    }}
                  />
                </div>
                
                {/* Legend */}
                <div className="flex flex-wrap gap-4 text-xs text-muted-foreground">
                  <div className="flex items-center gap-1.5">
                    <div className="h-2.5 w-2.5 rounded-full bg-primary" />
                    <span>Brukt</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <div className="h-2.5 w-2.5 rounded-full bg-primary/40" />
                    <span>Planlagt</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <div className="h-2.5 w-2.5 rounded-full bg-muted border" />
                    <span>Tilgjengelig</span>
                  </div>
                </div>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
                <div className="text-center p-3 rounded-lg bg-muted/50">
                  <p className="text-xs text-muted-foreground">Opptjent</p>
                  <p className="text-lg font-semibold">{data.saldo.totalt}t</p>
                  {data.saldo.overfart > 0 && (
                    <p className="text-xs text-muted-foreground">inkl. {data.saldo.overfart}t overført</p>
                  )}
                </div>
                <div className="text-center p-3 rounded-lg bg-muted/50">
                  <p className="text-xs text-muted-foreground">Brukt</p>
                  <p className="text-lg font-semibold text-primary">{data.saldo.brukt}t</p>
                </div>
                <div className="text-center p-3 rounded-lg bg-muted/50">
                  <p className="text-xs text-muted-foreground">Planlagt</p>
                  <p className="text-lg font-semibold text-amber-600 dark:text-amber-400">{data.saldo.planlagt}t</p>
                </div>
                <div className={`text-center p-3 rounded-lg ${isOverbooked ? 'bg-red-100 dark:bg-red-900/30' : 'bg-muted/50'}`}>
                  <p className="text-xs text-muted-foreground">Gjenstår</p>
                  <p className={`text-lg font-semibold ${isOverbooked ? 'text-red-600 dark:text-red-400' : 'text-green-600 dark:text-green-400'}`}>
                    {data.saldo.gjenstar}t
                  </p>
                  {isOverbooked && (
                    <p className="text-xs text-red-600 dark:text-red-400">Overbooket!</p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Tabs for ferie og fravær */}
        <Tabs defaultValue="ferie" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="ferie" className="gap-2">
              <Plane className="h-4 w-4" />
              Ferie
              {data?.ferie && data.ferie.length > 0 && (
                <Badge variant="secondary" className="ml-1">{data.ferie.length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="fravaer" className="gap-2">
              <Clock className="h-4 w-4" />
              Fravær
              {data?.fravaer && data.fravaer.length > 0 && (
                <Badge variant="secondary" className="ml-1">{data.fravaer.length}</Badge>
              )}
            </TabsTrigger>
          </TabsList>

          <TabsContent value="ferie" className="space-y-3 mt-4">
            {data?.ferie && data.ferie.length > 0 ? (
              data.ferie.map((ferie: any) => {
                const arbeidsdager = calculateArbeidsdager(ferie.startdato, ferie.sluttdato);
                const ferieStyle = getFerieTypeStyle(ferie.type);
                return (
                  <Card key={ferie.id} className="overflow-hidden">
                    <CardContent className="p-4">
                      <div className="flex gap-3">
                        {/* Colored icon */}
                        <div className={`p-2.5 rounded-lg shrink-0 h-fit ${ferieStyle.iconBg}`}>
                          <Plane className={`h-5 w-5 ${ferieStyle.iconColor}`} />
                        </div>
                        
                        <div className="flex-1 space-y-3">
                          {/* Top row: Type badge and status */}
                          <div className="flex items-center justify-between flex-wrap gap-2">
                            <Badge className={ferieStyle.badgeClass}>
                              {ferieStyle.label}
                            </Badge>
                            {getStatusBadge(ferie.status)}
                          </div>
                        
                          {/* Main content grid */}
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                          {/* Dates */}
                          <div className="flex items-start gap-2">
                            <CalendarDays className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
                            <div>
                              <p className="text-sm font-medium">
                                {format(new Date(ferie.startdato), 'd. MMM', { locale: nb })} - {format(new Date(ferie.sluttdato), 'd. MMM yyyy', { locale: nb })}
                              </p>
                              {arbeidsdager && (
                                <p className="text-xs text-muted-foreground">
                                  {arbeidsdager} arbeidsdager
                                </p>
                              )}
                            </div>
                          </div>
                          
                          {/* Hours */}
                          <div className="flex items-start gap-2">
                            <Clock className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
                            <div>
                              <p className="text-sm font-medium">{ferie.timer || 0} timer</p>
                              <p className="text-xs text-muted-foreground">Ferietimer</p>
                            </div>
                          </div>
                          
                          {/* Request date */}
                          {ferie.created_at && (
                            <div className="flex items-start gap-2">
                              <FileText className="h-4 w-4 text-muted-foreground mt-0.5 shrink-0" />
                              <div>
                                <p className="text-sm font-medium">
                                  {format(new Date(ferie.created_at), 'd. MMM yyyy', { locale: nb })}
                                </p>
                                <p className="text-xs text-muted-foreground">Søknadsdato</p>
                              </div>
                            </div>
                          )}
                        </div>
                        
                          {/* Comment if exists */}
                          {ferie.kommentar && (
                            <div className="pt-2 border-t">
                              <p className="text-sm text-muted-foreground italic">"{ferie.kommentar}"</p>
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })
            ) : (
              <Card>
                <CardContent className="py-12 text-center">
                  <Plane className="h-12 w-12 mx-auto mb-4 text-muted-foreground opacity-30" />
                  <h3 className="font-semibold mb-1">Ingen ferieregistreringer</h3>
                  <p className="text-sm text-muted-foreground">
                    Ingen ferie registrert for {selectedYear}
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="fravaer" className="space-y-3 mt-4">
            {data?.fravaer && data.fravaer.length > 0 ? (
              data.fravaer.map((fravaer: any) => (
                <Card key={fravaer.id}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-start gap-3">
                        <div className="p-2 rounded-lg bg-muted">
                          {getFravaerIcon(fravaer.fravaerstype)}
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <p className="font-medium capitalize">
                              {fravaer.fravaerstype?.replace('_', ' ')}
                            </p>
                            {fravaer.prosent && fravaer.prosent < 100 && (
                              <Badge variant="outline" className="text-xs">
                                {fravaer.prosent}%
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground">
                            {format(new Date(fravaer.startdato), 'd. MMM', { locale: nb })} - {format(new Date(fravaer.sluttdato), 'd. MMM yyyy', { locale: nb })}
                          </p>
                          {fravaer.timer && (
                            <p className="text-xs text-muted-foreground mt-1">{fravaer.timer} timer</p>
                          )}
                        </div>
                      </div>
                      {getStatusBadge(fravaer.status || 'aktiv')}
                    </div>
                    {fravaer.kommentar && (
                      <p className="text-sm text-muted-foreground mt-3 pt-3 border-t italic">"{fravaer.kommentar}"</p>
                    )}
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card>
                <CardContent className="py-12 text-center">
                  <Calendar className="h-12 w-12 mx-auto mb-4 text-muted-foreground opacity-30" />
                  <h3 className="font-semibold mb-1">Ingen fraværsregistreringer</h3>
                  <p className="text-sm text-muted-foreground">
                    Ingen fravær registrert for {selectedYear}
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Dialogs */}
      {ansatt && (
        <>
          <MinFerieSoknadDialog 
            open={showFerieDialog} 
            onOpenChange={setShowFerieDialog}
            onSuccess={handleSuccess}
            ansatt={ansatt}
          />
          <MinFravaerRegistreringDialog 
            open={showFravaerDialog} 
            onOpenChange={setShowFravaerDialog}
            onSuccess={handleSuccess}
            ansatt={ansatt}
          />
          <MinPermisjonSoknadDialog 
            open={showPermisjonDialog} 
            onOpenChange={setShowPermisjonDialog}
            onSuccess={handleSuccess}
            ansatt={ansatt}
          />
        </>
      )}
    </AppLayout>
  );
}
