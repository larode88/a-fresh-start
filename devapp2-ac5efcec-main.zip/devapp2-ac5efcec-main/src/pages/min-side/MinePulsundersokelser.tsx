// Mine Pulsundersøkelser - Besvar og se historikk
import { useState } from "react";
import { useAnsattSelectorContext } from "@/components/AnsattSelector";
import { useCurrentAnsatt } from "@/hooks/useCurrentAnsatt";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { format } from "date-fns";
import { nb } from "date-fns/locale";
import { BarChart3, CheckCircle2, Clock, Send } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { AppLayout } from "@/components/AppLayout";

const SCORE_EMOJIS = ['😢', '😐', '🙂', '😊', '🤩'];
const SCORE_LABELS = ['Svært dårlig', 'Dårlig', 'Nøytral', 'Bra', 'Svært bra'];

export default function MinePulsundersokelser() {
  const queryClient = useQueryClient();
  const { selectedAnsatt, isViewingAsOther } = useAnsattSelectorContext();
  const { ansatt: currentAnsatt, isLoading: isLoadingAnsatt } = useCurrentAnsatt();
  const ansatt = selectedAnsatt || currentAnsatt;
  const [selectedScores, setSelectedScores] = useState<Record<string, number>>({});
  const [kommentar, setKommentar] = useState('');

  // Fetch undersøkelser - bruker ansatt_id som primærnøkkel
  const { data: undersokelser, isLoading: isLoadingPuls } = useQuery({
    queryKey: ['mine-pulsundersokelser', ansatt?.id, ansatt?.salong_id],
    queryFn: async () => {
      if (!ansatt?.id || !ansatt?.salong_id) return { aktive: [], besvarte: [] };
      
      // Build OR filter - ansatt_id primary, user_id fallback
      const dummyId = '00000000-0000-0000-0000-000000000000';
      const userId = ansatt.user_id || dummyId;
      const orFilter = `ansatt_id.eq.${ansatt.id},user_id.eq.${userId}`;
      
      // Get all surveys for the salon
      const { data: alleUndersokelser } = await supabase
        .from('pulsundersokelser')
        .select('*')
        .eq('salon_id', ansatt.salong_id)
        .order('opprettet_dato', { ascending: false });
      
      // Get answers using OR filter
      const { data: svarData } = await supabase
        .from('pulsundersokelse_svar')
        .select('*, undersokelse:pulsundersokelser(*)')
        .or(orFilter)
        .order('opprettet_dato', { ascending: false });
      
      const besvartIds = new Set(svarData?.map(s => s.undersokelse_id) || []);
      
      return {
        aktive: (alleUndersokelser || []).filter(u => u.aktiv && !besvartIds.has(u.id)),
        besvarte: svarData || []
      };
    },
    enabled: !!ansatt?.id && !!ansatt?.salong_id,
  });

  // Submit answer mutation - bruker ansatt_id som primærnøkkel
  const submitMutation = useMutation({
    mutationFn: async ({ undersokelseId, scores, kommentar }: { undersokelseId: string; scores: Record<string, number>; kommentar: string }) => {
      if (!ansatt?.id) throw new Error('Ansatt ikke funnet');

      const { error } = await supabase
        .from('pulsundersokelse_svar')
        .insert({
          undersokelse_id: undersokelseId,
          ansatt_id: ansatt.id,
          user_id: ansatt.user_id || null, // fallback for legacy
          stemning: scores.stemning || 3,
          energi: scores.energi || 3,
          mestring: scores.mestring || 3,
          kommentar: kommentar || null,
          dato: new Date().toISOString().split('T')[0]
        });
      
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success('Takk for din tilbakemelding!');
      setSelectedScores({});
      setKommentar('');
      queryClient.invalidateQueries({ queryKey: ['mine-pulsundersokelser'] });
      queryClient.invalidateQueries({ queryKey: ['ubesvarte-puls'] });
    },
    onError: () => {
      toast.error('Kunne ikke sende svaret');
    }
  });

  const isLoading = isLoadingAnsatt || isLoadingPuls;

  const ScoreSelector = ({ tema, undersokelseId }: { tema: string; undersokelseId: string }) => {
    const key = `${undersokelseId}-${tema}`;
    const selected = selectedScores[key];
    
    return (
      <div className="space-y-2">
        <p className="font-medium capitalize">{tema}</p>
        <div className="flex gap-2">
          {SCORE_EMOJIS.map((emoji, idx) => (
            <button
              key={idx}
              onClick={() => setSelectedScores(prev => ({ ...prev, [key]: idx + 1 }))}
              className={`w-12 h-12 text-2xl rounded-xl transition-all ${
                selected === idx + 1 
                  ? 'bg-primary/20 ring-2 ring-primary scale-110' 
                  : 'bg-muted hover:bg-muted/80 hover:scale-105'
              }`}
              title={SCORE_LABELS[idx]}
            >
              {emoji}
            </button>
          ))}
        </div>
      </div>
    );
  };

  const handleSubmit = (undersokelseId: string) => {
    const scores = {
      stemning: selectedScores[`${undersokelseId}-stemning`],
      energi: selectedScores[`${undersokelseId}-energi`],
      mestring: selectedScores[`${undersokelseId}-mestring`]
    };
    
    if (!scores.stemning && !scores.energi && !scores.mestring) {
      toast.error('Vennligst svar på minst ett spørsmål');
      return;
    }
    
    submitMutation.mutate({ undersokelseId, scores, kommentar });
  };

  if (isLoading) {
    return (
      <AppLayout>
        <div className="container max-w-3xl mx-auto py-8 px-4 space-y-6">
          <Skeleton className="h-10 w-48" />
          <Skeleton className="h-60 w-full" />
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="container max-w-3xl mx-auto py-8 px-4 space-y-6">
        <div>
          <div className="flex items-center gap-3">
            <BarChart3 className="h-6 w-6 text-primary" />
            <h1 className="text-2xl font-bold">Pulsundersøkelser</h1>
          </div>
          {isViewingAsOther && ansatt && (
            <p className="text-sm text-muted-foreground mt-1 ml-9">
              Viser for: <span className="font-medium text-foreground">{ansatt.fornavn} {ansatt.etternavn}</span>
            </p>
          )}
        </div>

        <Tabs defaultValue="aktive" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="aktive">
              Aktive
              {undersokelser?.aktive && undersokelser.aktive.length > 0 && (
                <Badge variant="destructive" className="ml-2">{undersokelser.aktive.length}</Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="besvarte">Tidligere</TabsTrigger>
          </TabsList>

          <TabsContent value="aktive" className="space-y-4 mt-4">
            {undersokelser?.aktive && undersokelser.aktive.length > 0 ? (
              undersokelser.aktive.map((undersokelse: any) => (
                <Card key={undersokelse.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{undersokelse.tittel || 'Pulsundersøkelse'}</CardTitle>
                      <Badge variant="outline">
                        <Clock className="h-3 w-3 mr-1" />
                        Åpen
                      </Badge>
                    </div>
                    {undersokelse.beskrivelse && (
                      <p className="text-sm text-muted-foreground">{undersokelse.beskrivelse}</p>
                    )}
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <ScoreSelector tema="stemning" undersokelseId={undersokelse.id} />
                    <ScoreSelector tema="energi" undersokelseId={undersokelse.id} />
                    <ScoreSelector tema="mestring" undersokelseId={undersokelse.id} />
                    
                    <div className="space-y-2">
                      <p className="font-medium">Kommentar (valgfritt)</p>
                      <Textarea
                        placeholder="Del gjerne dine tanker..."
                        value={kommentar}
                        onChange={(e) => setKommentar(e.target.value)}
                        className="resize-none"
                        rows={3}
                      />
                    </div>
                    
                    <Button 
                      onClick={() => handleSubmit(undersokelse.id)}
                      disabled={submitMutation.isPending}
                      className="w-full"
                    >
                      <Send className="h-4 w-4 mr-2" />
                      {submitMutation.isPending ? 'Sender...' : 'Send svar'}
                    </Button>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card>
                <CardContent className="py-12 text-center">
                  <CheckCircle2 className="h-12 w-12 mx-auto mb-4 text-green-500" />
                  <h3 className="font-semibold mb-1">Ingen aktive undersøkelser</h3>
                  <p className="text-sm text-muted-foreground">
                    Du har besvart alle pulsundersøkelser 🎉
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="besvarte" className="space-y-4 mt-4">
            {undersokelser?.besvarte && undersokelser.besvarte.length > 0 ? (
              undersokelser.besvarte.map((svar: any) => (
                <Card key={svar.id} className="opacity-80">
                  <CardContent className="py-4">
                    <div className="flex justify-between items-start mb-3">
                      <h3 className="font-semibold">
                        {svar.undersokelse?.tittel || 'Pulsundersøkelse'}
                      </h3>
                      <span className="text-sm text-muted-foreground">
                        {format(new Date(svar.opprettet_dato), 'd. MMM yyyy', { locale: nb })}
                      </span>
                    </div>
                    <div className="flex gap-4 text-sm">
                      {svar.stemning_score && (
                        <div className="flex items-center gap-1">
                          <span className="text-muted-foreground">Stemning:</span>
                          <span className="text-lg">{SCORE_EMOJIS[svar.stemning_score - 1]}</span>
                        </div>
                      )}
                      {svar.energi_score && (
                        <div className="flex items-center gap-1">
                          <span className="text-muted-foreground">Energi:</span>
                          <span className="text-lg">{SCORE_EMOJIS[svar.energi_score - 1]}</span>
                        </div>
                      )}
                      {svar.mestring_score && (
                        <div className="flex items-center gap-1">
                          <span className="text-muted-foreground">Mestring:</span>
                          <span className="text-lg">{SCORE_EMOJIS[svar.mestring_score - 1]}</span>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <Card>
                <CardContent className="py-12 text-center">
                  <BarChart3 className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="font-semibold mb-1">Ingen tidligere svar</h3>
                  <p className="text-sm text-muted-foreground">
                    Dine tidligere svar vil vises her
                  </p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}
