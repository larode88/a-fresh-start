// Mine Mål - Budsjett og KPI-mål med periodevalg
import { useState } from "react";
import { useAnsattSelectorContext } from "@/components/AnsattSelector";
import { useCurrentAnsatt } from "@/hooks/useCurrentAnsatt";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { 
  Target, TrendingUp, TrendingDown, Minus, BarChart3, Clock, 
  ShoppingBag, Users, Wallet, Scissors, ChevronLeft, ChevronRight,
  CalendarDays, Calendar, CalendarRange, Sparkles
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Info } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AppLayout } from "@/components/AppLayout";
import { format, addDays, subDays, addWeeks, subWeeks, addMonths, subMonths, startOfWeek, endOfWeek, startOfMonth, endOfMonth } from "date-fns";
import { nb } from "date-fns/locale";
import { getISOWeekNumber } from "@/lib/dateUtils";
import { RegistrerDataDialog } from "@/components/min-side/RegistrerDataDialog";

type PeriodType = 'day' | 'week' | 'month';

interface KPIMal {
  type: string;
  label: string;
  icon: React.ReactNode;
  mal: number;
  faktisk: number | null;
  enhet: string;
}

export default function MineMal() {
  const { selectedAnsatt, isViewingAsOther } = useAnsattSelectorContext();
  const { ansatt: currentAnsatt, isLoading: isLoadingAnsatt } = useCurrentAnsatt();
  const ansatt = selectedAnsatt || currentAnsatt;
  const [periodType, setPeriodType] = useState<PeriodType>('week');
  const [selectedDate, setSelectedDate] = useState(new Date());

  // Get period boundaries
  const getPeriodDates = () => {
    if (periodType === 'day') {
      return { start: selectedDate, end: selectedDate };
    } else if (periodType === 'week') {
      return { 
        start: startOfWeek(selectedDate, { weekStartsOn: 1 }), 
        end: endOfWeek(selectedDate, { weekStartsOn: 1 }) 
      };
    } else {
      return { 
        start: startOfMonth(selectedDate), 
        end: endOfMonth(selectedDate) 
      };
    }
  };

  const { start: periodStart, end: periodEnd } = getPeriodDates();
  const weekNumber = getISOWeekNumber(selectedDate);
  const year = selectedDate.getFullYear();
  const month = selectedDate.getMonth() + 1;

  // Fetch available budget years for salon
  const { data: availableYears, isLoading: isLoadingYears } = useQuery({
    queryKey: ['budsjett-years', ansatt?.salong_id],
    queryFn: async () => {
      if (!ansatt?.salong_id) return [];
      const { data } = await supabase
        .from('budsjett_versjoner')
        .select('aar')
        .eq('salon_id', ansatt.salong_id)
        .eq('er_aktiv', true)
        .order('aar', { ascending: false });
      return data?.map(v => v.aar) || [];
    },
    enabled: !!ansatt?.salong_id,
  });

  // Fetch budget data for selected period
  const { data: budsjettData, isLoading: isLoadingBudsjett } = useQuery({
    queryKey: ['mitt-budsjett', ansatt?.id, ansatt?.salong_id, periodType, format(selectedDate, 'yyyy-MM-dd')],
    queryFn: async () => {
      if (!ansatt?.id || !ansatt?.salong_id) return null;

      // Find active budget version
      const { data: version } = await supabase
        .from('budsjett_versjoner')
        .select('id')
        .eq('salon_id', ansatt.salong_id)
        .eq('aar', year)
        .eq('er_aktiv', true)
        .single();

      if (!version) return null;

      // Build query based on period type
      let query = supabase
        .from('budsjett')
        .select('dato, behandling_budsjett, vare_budsjett, totalt_budsjett, planlagte_timer, kundetimer')
        .eq('ansatt_id', ansatt.id)
        .eq('versjon_id', version.id);

      if (periodType === 'day') {
        query = query.eq('dato', format(selectedDate, 'yyyy-MM-dd'));
      } else if (periodType === 'week') {
        query = query
          .gte('dato', format(periodStart, 'yyyy-MM-dd'))
          .lte('dato', format(periodEnd, 'yyyy-MM-dd'));
      } else {
        query = query
          .gte('dato', format(periodStart, 'yyyy-MM-dd'))
          .lte('dato', format(periodEnd, 'yyyy-MM-dd'));
      }

      const { data } = await query;

      if (!data || data.length === 0) return null;

      return {
        behandling: data.reduce((sum, d) => sum + (d.behandling_budsjett || 0), 0),
        vare: data.reduce((sum, d) => sum + (d.vare_budsjett || 0), 0),
        total: data.reduce((sum, d) => sum + (d.totalt_budsjett || 0), 0),
        planlagte_timer: data.reduce((sum, d) => sum + (d.planlagte_timer || 0), 0),
        kundetimer: data.reduce((sum, d) => sum + (d.kundetimer || 0), 0),
        dager: data.length
      };
    },
    enabled: !!ansatt?.id && !!ansatt?.salong_id,
  });

  // Fetch actual results from daily_kpi_inputs using ansatt_id (works without user_id)
  const { data: actualResults, isLoading: isLoadingActual } = useQuery({
    queryKey: ['mine-faktiske-resultater', ansatt?.id, ansatt?.salong_id, periodType, format(selectedDate, 'yyyy-MM-dd')],
    queryFn: async () => {
      if (!ansatt?.id || !ansatt?.salong_id) return null;

      const dateFormatted = format(selectedDate, 'yyyy-MM-dd');
      const startFormatted = format(periodStart, 'yyyy-MM-dd');
      const endFormatted = format(periodEnd, 'yyyy-MM-dd');

      // Fetch from daily_kpi_inputs using ansatt_id (column is 'date' not 'dato')
      const kpiQuery = supabase
        .from('daily_kpi_inputs')
        .select('treatment_revenue, retail_revenue, visit_count, visits_with_addon, addon_count, rebooked_visits, date')
        .eq('ansatt_id', ansatt.id)
        .eq('salon_id', ansatt.salong_id);

      // Also fetch time entries for hours data (columns: start_time, end_time, break_minutes, hours_with_client)
      const timeQuery = supabase
        .from('daily_time_entries')
        .select('start_time, end_time, break_minutes, hours_with_client, date')
        .eq('ansatt_id', ansatt.id)
        .eq('salon_id', ansatt.salong_id);

      // Apply date filters
      let kpiQueryFiltered;
      let timeQueryFiltered;
      
      if (periodType === 'day') {
        kpiQueryFiltered = kpiQuery.eq('date', dateFormatted);
        timeQueryFiltered = timeQuery.eq('date', dateFormatted);
      } else {
        kpiQueryFiltered = kpiQuery.gte('date', startFormatted).lte('date', endFormatted);
        timeQueryFiltered = timeQuery.gte('date', startFormatted).lte('date', endFormatted);
      }

      const [kpiResult, timeResult] = await Promise.all([kpiQueryFiltered, timeQueryFiltered]);

      const kpiData = kpiResult.data || [];
      const timeData = timeResult.data || [];

      if (kpiData.length === 0 && timeData.length === 0) return null;

      const behandling = kpiData.reduce((sum, d) => sum + (d.treatment_revenue || 0), 0);
      const vare = kpiData.reduce((sum, d) => sum + (d.retail_revenue || 0), 0);
      const visitCount = kpiData.reduce((sum, d) => sum + (d.visit_count || 0), 0);
      const visitsWithAddon = kpiData.reduce((sum, d) => sum + (d.visits_with_addon || 0), 0);
      const addonCount = kpiData.reduce((sum, d) => sum + (d.addon_count || 0), 0);
      const rebookedVisits = kpiData.reduce((sum, d) => sum + (d.rebooked_visits || 0), 0);

      // Calculate hours from time entries
      let hoursWorked = 0;
      let hoursWithClient = 0;
      
      for (const entry of timeData) {
        // Calculate hours worked from start/end time
        if (entry.start_time && entry.end_time) {
          const start = new Date(`2000-01-01T${entry.start_time}`);
          const end = new Date(`2000-01-01T${entry.end_time}`);
          const diffHours = (end.getTime() - start.getTime()) / (1000 * 60 * 60);
          const breakHours = (entry.break_minutes || 0) / 60;
          hoursWorked += Math.max(0, diffHours - breakHours);
        }
        hoursWithClient += entry.hours_with_client || 0;
      }

      return {
        behandling,
        vare,
        total: behandling + vare,
        visitCount,
        visitsWithAddon,
        addonCount,
        rebookedVisits,
        hoursWorked,
        hoursWithClient,
        addonPercent: visitCount > 0 ? (visitsWithAddon / visitCount) * 100 : 0,
        rebookingPercent: visitCount > 0 ? (rebookedVisits / visitCount) * 100 : 0,
        efficiencyPercent: hoursWorked > 0 ? (hoursWithClient / hoursWorked) * 100 : 0,
        revenuePerHour: hoursWithClient > 0 ? (behandling + vare) / hoursWithClient : 0
      };
    },
    enabled: !!ansatt?.id && !!ansatt?.salong_id,
  });

  // Fetch KPI data for selected period
  const { data: kpiData, isLoading: isLoadingKpi } = useQuery({
    queryKey: ['mine-kpi', ansatt?.id, periodType, format(selectedDate, 'yyyy-MM-dd')],
    queryFn: async () => {
      if (!ansatt?.id) return { mal: [], resultater: [] };

      const dummyId = '00000000-0000-0000-0000-000000000000';
      const userId = ansatt.user_id || dummyId;
      const orFilter = `ansatt_id.eq.${ansatt.id},user_id.eq.${userId}`;
      const kpiOrFilter = `ansatt_id.eq.${ansatt.id},stylist_id.eq.${userId}`;

      // Fetch active goals
      const { data: malResult } = await supabase
        .from('ansatt_mal')
        .select('*')
        .or(orFilter)
        .eq('status', 'aktiv');

      // Fetch KPI results based on period
      let kpiQuery = supabase
        .from('weekly_kpis')
        .select('*')
        .or(kpiOrFilter)
        .eq('year', year);

      if (periodType === 'day' || periodType === 'week') {
        kpiQuery = kpiQuery.eq('week', weekNumber);
      } else {
        // For month, get all weeks that fall in the month
        const weeksInMonth = getWeeksInMonth(selectedDate);
        kpiQuery = kpiQuery.in('week', weeksInMonth);
      }

      const { data: kpiResult } = await kpiQuery;

      return {
        mal: malResult || [],
        resultater: kpiResult || []
      };
    },
    enabled: !!ansatt?.id,
  });

  const isLoading = isLoadingAnsatt || isLoadingBudsjett || isLoadingKpi || isLoadingActual;

  // Helper to get weeks in a month
  function getWeeksInMonth(date: Date): number[] {
    const weeks: number[] = [];
    const monthStart = startOfMonth(date);
    const monthEnd = endOfMonth(date);
    let current = monthStart;
    
    while (current <= monthEnd) {
      const week = getISOWeekNumber(current);
      if (!weeks.includes(week)) weeks.push(week);
      current = addDays(current, 7);
    }
    return weeks;
  }

  // Calculate average from results
  const getAverageFromResults = (field: string): number | null => {
    if (!kpiData?.resultater || kpiData.resultater.length === 0) return null;
    const values = kpiData.resultater.map((r: any) => r[field]).filter((v: any) => v !== null);
    if (values.length === 0) return null;
    return values.reduce((sum: number, v: number) => sum + v, 0) / values.length;
  };


  // Tilleggsbehandlinger data from actual results
  const tilleggsbehandlingMal = kpiData?.mal?.find((m: any) => m.mal_type === 'tilleggsbehandling')?.maalverdi || 30;
  const tilleggsbehandlingProgress = actualResults?.addonPercent 
    ? Math.min(150, (actualResults.addonPercent / tilleggsbehandlingMal) * 100)
    : 0;

  // KPI definitions - prefer data from actualResults (daily_kpi_inputs) over weekly_kpis
  const kpis: KPIMal[] = [
    {
      type: 'effektivitet',
      label: 'Effektivitet',
      icon: <Clock className="h-5 w-5" />,
      mal: kpiData?.mal?.find((m: any) => m.mal_type === 'effektivitet')?.maalverdi || 80,
      faktisk: actualResults?.efficiencyPercent ?? getAverageFromResults('efficiency_percent'),
      enhet: '%'
    },
    {
      type: 'omsetning_per_time',
      label: 'Omsetning/time',
      icon: <BarChart3 className="h-5 w-5" />,
      mal: kpiData?.mal?.find((m: any) => m.mal_type === 'omsetning_per_time')?.maalverdi || 1500,
      faktisk: actualResults?.revenuePerHour ?? getAverageFromResults('revenue_per_hour'),
      enhet: 'kr'
    },
    {
      type: 'rebooking',
      label: 'Rebooking',
      icon: <Users className="h-5 w-5" />,
      mal: kpiData?.mal?.find((m: any) => m.mal_type === 'rebooking')?.maalverdi || 85,
      faktisk: actualResults?.rebookingPercent ?? getAverageFromResults('rebooking_percent'),
      enhet: '%'
    },
    {
      type: 'salgsandel',
      label: 'Salgsandel',
      icon: <ShoppingBag className="h-5 w-5" />,
      mal: kpiData?.mal?.find((m: any) => m.mal_type === 'salgsandel')?.maalverdi || 20,
      faktisk: actualResults?.addonPercent ?? getAverageFromResults('addon_share_percent'),
      enhet: '%'
    }
  ];

  // Navigation handlers
  const handlePrevious = () => {
    if (periodType === 'day') setSelectedDate(subDays(selectedDate, 1));
    else if (periodType === 'week') setSelectedDate(subWeeks(selectedDate, 1));
    else setSelectedDate(subMonths(selectedDate, 1));
  };

  const handleNext = () => {
    if (periodType === 'day') setSelectedDate(addDays(selectedDate, 1));
    else if (periodType === 'week') setSelectedDate(addWeeks(selectedDate, 1));
    else setSelectedDate(addMonths(selectedDate, 1));
  };

  // Format period label
  const formatPeriodLabel = () => {
    if (periodType === 'day') {
      return format(selectedDate, 'EEEE d. MMMM yyyy', { locale: nb });
    } else if (periodType === 'week') {
      return `Uke ${weekNumber}, ${year}`;
    } else {
      return format(selectedDate, 'MMMM yyyy', { locale: nb });
    }
  };

  // Format currency
  const formatCurrency = (value: number | null | undefined) => {
    if (value === null || value === undefined) return '-';
    return new Intl.NumberFormat('nb-NO', { 
      style: 'currency', 
      currency: 'NOK',
      maximumFractionDigits: 0
    }).format(value);
  };

  const getProgressColor = (progress: number) => {
    if (progress >= 100) return 'bg-green-500';
    if (progress >= 80) return 'bg-amber-500';
    return 'bg-red-500';
  };

  const getTrendIcon = (progress: number) => {
    if (progress >= 100) return <TrendingUp className="h-4 w-4 text-green-500" />;
    if (progress >= 80) return <Minus className="h-4 w-4 text-amber-500" />;
    return <TrendingDown className="h-4 w-4 text-red-500" />;
  };

  // Calculate progress for budget cards
  const totalProgress = budsjettData?.total && actualResults?.total 
    ? Math.min(150, (actualResults.total / budsjettData.total) * 100)
    : 0;
  const behandlingProgress = budsjettData?.behandling && actualResults?.behandling 
    ? Math.min(150, (actualResults.behandling / budsjettData.behandling) * 100)
    : 0;
  const vareProgress = budsjettData?.vare && actualResults?.vare 
    ? Math.min(150, (actualResults.vare / budsjettData.vare) * 100)
    : 0;

  if (isLoading) {
    return (
      <AppLayout>
        <div className="container max-w-4xl mx-auto py-8 px-4 space-y-6">
          <Skeleton className="h-10 w-48" />
          <Skeleton className="h-12 w-full" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Skeleton className="h-36 w-full" />
            <Skeleton className="h-36 w-full" />
            <Skeleton className="h-36 w-full" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Skeleton className="h-40 w-full" />
            <Skeleton className="h-40 w-full" />
            <Skeleton className="h-40 w-full" />
            <Skeleton className="h-40 w-full" />
          </div>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="container max-w-4xl mx-auto py-8 px-4 space-y-6">
        {/* Header */}
        <div>
          <div className="flex items-center gap-3">
            <Target className="h-6 w-6 text-primary" />
            <h1 className="text-2xl font-bold">Mine Mål & Resultat</h1>
          </div>
          {isViewingAsOther && ansatt && (
            <p className="text-sm text-muted-foreground mt-1 ml-9">
              Viser for: <span className="font-medium text-foreground">{ansatt.fornavn} {ansatt.etternavn}</span>
            </p>
          )}
        </div>

        {/* Period Selector */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-card rounded-lg p-4 border">
          <Tabs value={periodType} onValueChange={(v) => setPeriodType(v as PeriodType)}>
            <TabsList>
              <TabsTrigger value="day" className="gap-2">
                <CalendarDays className="h-4 w-4" />
                <span className="hidden sm:inline">Dag</span>
              </TabsTrigger>
              <TabsTrigger value="week" className="gap-2">
                <Calendar className="h-4 w-4" />
                <span className="hidden sm:inline">Uke</span>
              </TabsTrigger>
              <TabsTrigger value="month" className="gap-2">
                <CalendarRange className="h-4 w-4" />
                <span className="hidden sm:inline">Måned</span>
              </TabsTrigger>
            </TabsList>
          </Tabs>

          <div className="flex items-center gap-2">
            <Button variant="outline" size="icon" onClick={handlePrevious}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <span className="font-medium text-sm min-w-[160px] text-center capitalize">
              {formatPeriodLabel()}
            </span>
            <Button variant="outline" size="icon" onClick={handleNext}>
              <ChevronRight className="h-4 w-4" />
            </Button>
            
              {ansatt && (
                <RegistrerDataDialog 
                  ansatt={ansatt as any}
                  selectedDate={selectedDate}
                  isViewingAsOther={isViewingAsOther}
                />
              )}
          </div>
        </div>

        {/* Budget Section */}
        <div className="space-y-4">
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <Wallet className="h-5 w-5 text-primary" />
            Budsjettmål
          </h2>

          {budsjettData ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Total Budget */}
              <Card className="bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground flex items-center justify-between">
                    <span>Total omsetning</span>
                    {totalProgress >= 100 && (
                      <Badge className="bg-green-500/10 text-green-700 hover:bg-green-500/20 text-xs">
                        Oppnådd! 🎉
                      </Badge>
                    )}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-baseline justify-between">
                    <div className="text-2xl font-bold text-primary">
                      {formatCurrency(budsjettData.total)}
                    </div>
                    {actualResults && (
                      <span className={`text-lg font-semibold ${totalProgress >= 100 ? 'text-green-600' : totalProgress >= 80 ? 'text-amber-600' : 'text-red-600'}`}>
                        {Math.round(totalProgress)}%
                      </span>
                    )}
                  </div>
                  <div className="mt-3 space-y-2">
                    <Progress 
                      value={Math.min(100, totalProgress)} 
                      className={`h-2.5 ${getProgressColor(totalProgress)}`}
                    />
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">
                        Faktisk: {actualResults ? formatCurrency(actualResults.total) : 'Ingen data'}
                      </span>
                      {getTrendIcon(totalProgress)}
                    </div>
                  </div>
                  {budsjettData.dager > 1 && (
                    <p className="text-xs text-muted-foreground mt-2">
                      {budsjettData.dager} arbeidsdager
                    </p>
                  )}
                </CardContent>
              </Card>

              {/* Treatment Budget */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <Scissors className="h-4 w-4" />
                      Behandling
                    </span>
                    {behandlingProgress >= 100 && (
                      <Badge className="bg-green-500/10 text-green-700 hover:bg-green-500/20 text-xs">
                        Oppnådd! 🎉
                      </Badge>
                    )}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-baseline justify-between">
                    <div className="text-2xl font-bold">
                      {formatCurrency(budsjettData.behandling)}
                    </div>
                    {actualResults && (
                      <span className={`text-lg font-semibold ${behandlingProgress >= 100 ? 'text-green-600' : behandlingProgress >= 80 ? 'text-amber-600' : 'text-red-600'}`}>
                        {Math.round(behandlingProgress)}%
                      </span>
                    )}
                  </div>
                  <div className="mt-3 space-y-2">
                    <Progress 
                      value={Math.min(100, behandlingProgress)} 
                      className={`h-2.5 ${getProgressColor(behandlingProgress)}`}
                    />
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">
                        Faktisk: {actualResults ? formatCurrency(actualResults.behandling) : 'Ingen data'}
                      </span>
                      {getTrendIcon(behandlingProgress)}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Product Sales Budget */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <ShoppingBag className="h-4 w-4" />
                      Salgsvarer
                    </span>
                    {vareProgress >= 100 && (
                      <Badge className="bg-green-500/10 text-green-700 hover:bg-green-500/20 text-xs">
                        Oppnådd! 🎉
                      </Badge>
                    )}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-baseline justify-between">
                    <div className="text-2xl font-bold">
                      {formatCurrency(budsjettData.vare)}
                    </div>
                    {actualResults && (
                      <span className={`text-lg font-semibold ${vareProgress >= 100 ? 'text-green-600' : vareProgress >= 80 ? 'text-amber-600' : 'text-red-600'}`}>
                        {Math.round(vareProgress)}%
                      </span>
                    )}
                  </div>
                  <div className="mt-3 space-y-2">
                    <Progress 
                      value={Math.min(100, vareProgress)} 
                      className={`h-2.5 ${getProgressColor(vareProgress)}`}
                    />
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">
                        Faktisk: {actualResults ? formatCurrency(actualResults.vare) : 'Ingen data'}
                      </span>
                      {getTrendIcon(vareProgress)}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <Alert className="bg-amber-50 border-amber-200 dark:bg-amber-900/20 dark:border-amber-800">
              <Info className="h-4 w-4 text-amber-600 dark:text-amber-400" />
              <AlertDescription className="text-amber-800 dark:text-amber-300">
                <p className="font-medium">Ingen budsjett for {year}</p>
                {isLoadingYears ? (
                  <p className="text-sm mt-1">Sjekker tilgjengelige år...</p>
                ) : availableYears && availableYears.length > 0 ? (
                  <div className="mt-2 flex flex-wrap items-center gap-2">
                    <span className="text-sm">Tilgjengelig:</span>
                    {availableYears.map((y) => (
                      <Button
                        key={y}
                        variant="outline"
                        size="sm"
                        className="h-7 text-xs border-amber-300 hover:bg-amber-100 dark:border-amber-700 dark:hover:bg-amber-800"
                        onClick={() => setSelectedDate(new Date(y, 0, 15))}
                      >
                        {y}
                      </Button>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm mt-1">Ingen budsjett er satt opp for denne salongen ennå.</p>
                )}
              </AlertDescription>
            </Alert>
          )}
        </div>

        {/* KPI Section */}
        <div className="space-y-4">
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <Target className="h-5 w-5 text-primary" />
            KPI-mål
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {kpis.map((kpi) => {
              const progress = kpi.faktisk !== null 
                ? Math.min(100, (kpi.faktisk / kpi.mal) * 100)
                : 0;
              
              return (
                <Card key={kpi.type}>
                  <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <div className="flex items-center gap-2">
                      <div className="p-2 rounded-lg bg-primary/10 text-primary">
                        {kpi.icon}
                      </div>
                      <CardTitle className="text-base font-medium">{kpi.label}</CardTitle>
                    </div>
                    {kpi.faktisk !== null && getTrendIcon(progress)}
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between items-end">
                        <div>
                          <span className="text-3xl font-bold">
                            {kpi.faktisk !== null ? Math.round(kpi.faktisk) : '-'}
                          </span>
                          <span className="text-muted-foreground ml-1">{kpi.enhet}</span>
                        </div>
                        <div className="text-right">
                          <span className="text-sm text-muted-foreground">Mål: </span>
                          <span className="font-medium">{kpi.mal}{kpi.enhet}</span>
                        </div>
                      </div>
                      
                      <Progress 
                        value={progress} 
                        className={`h-2 ${getProgressColor(progress)}`}
                      />
                      
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">
                          {kpi.faktisk !== null ? `${Math.round(progress)}% av målet` : 'Ingen data'}
                        </span>
                        {progress >= 100 && (
                          <Badge className="bg-green-500/10 text-green-700 hover:bg-green-500/20">
                            Oppnådd! 🎉
                          </Badge>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}

            {/* Tilleggsbehandlinger Card */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-lg bg-primary/10 text-primary">
                    <Sparkles className="h-5 w-5" />
                  </div>
                  <CardTitle className="text-base font-medium">Tilleggsbehandlinger</CardTitle>
                </div>
                {actualResults?.addonPercent !== undefined && getTrendIcon(tilleggsbehandlingProgress)}
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-end">
                    <div>
                      <span className="text-3xl font-bold">
                        {actualResults?.addonPercent !== undefined ? Math.round(actualResults.addonPercent) : '-'}
                      </span>
                      <span className="text-muted-foreground ml-1">%</span>
                    </div>
                    <div className="text-right">
                      <span className="text-sm text-muted-foreground">Mål: </span>
                      <span className="font-medium">{tilleggsbehandlingMal}%</span>
                    </div>
                  </div>
                  
                  <Progress 
                    value={Math.min(100, tilleggsbehandlingProgress)} 
                    className={`h-2 ${getProgressColor(tilleggsbehandlingProgress)}`}
                  />
                  
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">
                      {actualResults?.visitCount !== undefined 
                        ? `${actualResults.visitsWithAddon} av ${actualResults.visitCount} besøk`
                        : 'Ingen data'}
                    </span>
                    {tilleggsbehandlingProgress >= 100 && (
                      <Badge className="bg-green-500/10 text-green-700 hover:bg-green-500/20">
                        Oppnådd! 🎉
                      </Badge>
                    )}
                  </div>

                  {actualResults?.addonCount !== undefined && actualResults.addonCount > 0 && (
                    <p className="text-xs text-muted-foreground">
                      Totalt {actualResults.addonCount} tilleggsbehandlinger
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Info */}
        <Card className="bg-muted/50">
          <CardContent className="py-4">
            <p className="text-sm text-muted-foreground text-center">
              {periodType === 'day' && 'Viser budsjett og KPI for valgt dag.'}
              {periodType === 'week' && `Viser budsjett og KPI for uke ${weekNumber}.`}
              {periodType === 'month' && `Viser budsjett og KPI for ${format(selectedDate, 'MMMM yyyy', { locale: nb })}.`}
              {(!kpiData?.resultater || kpiData.resultater.length === 0) && (
                <span className="block mt-1">Ingen KPI-data rapportert for denne perioden.</span>
              )}
            </p>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
