// Min Side - Dashboard/Oversikt for ansatte
import { useAnsattSelectorContext } from "@/components/AnsattSelector";
import { useCurrentAnsatt } from "@/hooks/useCurrentAnsatt";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { getGreeting } from "@/lib/greetingUtils";
import { format, startOfWeek, endOfWeek, addDays } from "date-fns";
import { nb } from "date-fns/locale";
import { 
  Calendar, 
  Target, 
  MessageCircle, 
  BarChart3, 
  User, 
  Clock, 
  Umbrella,
  ChevronRight,
  AlertCircle
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { AppLayout } from "@/components/AppLayout";

export default function MinSideIndex() {
  const navigate = useNavigate();
  const { selectedAnsatt, isViewingAsOther } = useAnsattSelectorContext();
  const { ansatt: currentAnsatt, isLoading: isLoadingAnsatt } = useCurrentAnsatt();
  const ansatt = selectedAnsatt || currentAnsatt;

  // Fetch neste samtale - bruker ansatt_id som primærnøkkel
  const { data: nesteSamtale, isLoading: isLoadingNesteSamtale } = useQuery({
    queryKey: ['neste-samtale', ansatt?.id],
    queryFn: async () => {
      if (!ansatt?.id) return null;
      
      // Build OR filter - ansatt_id primary, user_id fallback
      const dummyId = '00000000-0000-0000-0000-000000000000';
      const userId = ansatt.user_id || dummyId;
      const orFilter = `ansatt_id.eq.${ansatt.id},user_id.eq.${userId}`;
      
      const { data, error } = await supabase
        .from('ansatt_samtaler')
        .select('*')
        .or(orFilter)
        .in('status', ['planlagt', 'pagar'])
        .gte('dato', new Date().toISOString().split('T')[0])
        .order('dato', { ascending: true })
        .limit(1);
      
      if (error) throw error;
      return data?.[0] || null;
    },
    enabled: !!ansatt?.id,
  });

  // Fetch ubesvarte pulsundersøkelser - bruker ansatt_id som primærnøkkel
  const { data: ubesvartePuls, isLoading: isLoadingPuls } = useQuery({
    queryKey: ['ubesvarte-puls', ansatt?.id, ansatt?.salong_id],
    queryFn: async () => {
      if (!ansatt?.id || !ansatt?.salong_id) return { count: 0, undersokelseId: null };
      
      // Build OR filter - ansatt_id primary, user_id fallback
      const dummyId = '00000000-0000-0000-0000-000000000000';
      const userId = ansatt.user_id || dummyId;
      const orFilter = `ansatt_id.eq.${ansatt.id},user_id.eq.${userId}`;
      
      // Get active surveys for the salon - using any to avoid deep type instantiation
      const salongId = ansatt.salong_id;
      const undersokelserResult = await (supabase as any)
        .from('pulsundersokelser')
        .select('id')
        .eq('salon_id', salongId)
        .eq('aktiv', true);
      
      const undersokelserData = undersokelserResult.data as { id: string }[] | null;
      
      if (!undersokelserData || undersokelserData.length === 0) {
        return { count: 0, undersokelseId: null };
      }
      
      const undersokelseIds: string[] = undersokelserData.map(u => u.id);
      
      // Get user's answers using OR filter
      const { data: svarData } = await supabase
        .from('pulsundersokelse_svar')
        .select('undersokelse_id')
        .or(orFilter);
      
      const besvartIds = new Set((svarData || []).filter((s: any) => undersokelseIds.includes(s.undersokelse_id)).map((s: any) => s.undersokelse_id));
      const ubesvarteIds = undersokelseIds.filter(id => !besvartIds.has(id));
      
      return { 
        count: ubesvarteIds.length,
        undersokelseId: ubesvarteIds[0] || null
      };
    },
    enabled: !!ansatt?.id && !!ansatt?.salong_id,
  });

  // Fetch turnus for denne uken - bruker ansatt_id som primærnøkkel
  const { data: ukeTurnus, isLoading: isLoadingTurnus } = useQuery({
    queryKey: ['min-turnus-uke', ansatt?.id],
    queryFn: async () => {
      if (!ansatt?.id) return [];
      
      // Build OR filter - ansatt_id primary, user_id fallback
      const dummyId = '00000000-0000-0000-0000-000000000000';
      const userId = ansatt.user_id || dummyId;
      const orFilter = `ansatt_id.eq.${ansatt.id},user_id.eq.${userId}`;
      
      const today = new Date();
      const weekStart = startOfWeek(today, { weekStartsOn: 1 });
      const weekEnd = endOfWeek(today, { weekStartsOn: 1 });
      
      // Get shifts for the week using OR filter
      const { data } = await supabase
        .from('turnus_skift')
        .select('*')
        .or(orFilter)
        .gte('dato', format(weekStart, 'yyyy-MM-dd'))
        .lte('dato', format(weekEnd, 'yyyy-MM-dd'))
        .order('dato');
      
      // If no shifts found, try to get from ansatt_turnus template
      if (!data || data.length === 0) {
        const { data: turnusData } = await supabase
          .from('ansatt_turnus')
          .select('*')
          .or(orFilter)
          .is('gyldig_til', null);
        
        return turnusData || [];
      }
      
      return data;
    },
    enabled: !!ansatt?.id,
  });

  // Fetch ferie-saldo - bruker ansatt_id som primærnøkkel
  const { data: ferieSaldo, isLoading: isLoadingFerie } = useQuery({
    queryKey: ['min-ferie-saldo', ansatt?.id],
    queryFn: async () => {
      if (!ansatt?.id) return null;
      
      // Build OR filter - ansatt_id primary, user_id fallback
      const dummyId = '00000000-0000-0000-0000-000000000000';
      const userId = ansatt.user_id || dummyId;
      const orFilter = `ansatt_id.eq.${ansatt.id},user_id.eq.${userId}`;
      
      const year = new Date().getFullYear();
      
      // Get brukt ferie using OR filter
      const { data: ferieData } = await supabase
        .from('ferie')
        .select('timer')
        .or(orFilter)
        .eq('aar', year)
        .eq('status', 'godkjent');
      
      const bruktTimer = ferieData?.reduce((sum, f) => sum + (f.timer || 0), 0) || 0;
      const totaltTimer = ansatt.feriekrav_timer_per_aar || 0;
      
      return {
        brukt: bruktTimer,
        totalt: totaltTimer,
        gjenstar: totaltTimer - bruktTimer
      };
    },
    enabled: !!ansatt?.id,
  });

  const greeting = getGreeting(ansatt?.fornavn, ansatt?.fodselsdato);
  const isLoading = isLoadingAnsatt;

  if (isLoading) {
    return (
      <AppLayout>
        <div className="container max-w-4xl mx-auto py-8 px-4 space-y-6">
          <Skeleton className="h-24 w-full" />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Skeleton className="h-40 w-full" />
            <Skeleton className="h-40 w-full" />
            <Skeleton className="h-40 w-full" />
            <Skeleton className="h-40 w-full" />
          </div>
        </div>
      </AppLayout>
    );
  }

  if (!ansatt) {
    return (
      <AppLayout>
        <div className="container max-w-4xl mx-auto py-8 px-4">
          <Card>
            <CardContent className="py-12 text-center">
              <AlertCircle className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <h2 className="text-xl font-semibold mb-2">Ingen ansattprofil funnet</h2>
              <p className="text-muted-foreground">
                Du er ikke registrert som ansatt i systemet.
              </p>
            </CardContent>
          </Card>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="container max-w-4xl mx-auto py-8 px-4 space-y-6">
        {/* Velkomst-kort */}
        <Card className="bg-gradient-to-r from-primary/10 to-primary/5 border-primary/20">
          <CardContent className="py-6">
            <h1 className="text-2xl font-bold text-foreground">{greeting}</h1>
            <p className="text-muted-foreground mt-1">
              {ansatt.rolle_display} hos {ansatt.salong_navn || 'din salong'}
            </p>
            {isViewingAsOther && (
              <p className="text-sm text-amber-600 dark:text-amber-400 mt-2">
                Viser for: <span className="font-medium">{ansatt.fornavn} {ansatt.etternavn}</span>
              </p>
            )}
          </CardContent>
        </Card>

        {/* Hovedkort-grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Neste samtale */}
          <Card 
            className="cursor-pointer hover:shadow-md transition-shadow"
            onClick={() => navigate('/min-side/samtaler')}
          >
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Neste samtale
              </CardTitle>
              <MessageCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              {isLoadingNesteSamtale ? (
                <Skeleton className="h-6 w-32" />
              ) : nesteSamtale ? (
                <div>
                  <p className="text-lg font-semibold">
                    {format(new Date(nesteSamtale.dato), 'd. MMMM yyyy', { locale: nb })}
                  </p>
                  <p className="text-sm text-muted-foreground capitalize">
                    {nesteSamtale.samtale_type.replace('_', ' ')}
                  </p>
                </div>
              ) : (
                <p className="text-muted-foreground">Ingen planlagte samtaler</p>
              )}
              <ChevronRight className="h-4 w-4 absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
            </CardContent>
          </Card>

          {/* Pulsundersøkelser */}
          <Card 
            className="cursor-pointer hover:shadow-md transition-shadow"
            onClick={() => navigate('/min-side/puls')}
          >
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Pulsundersøkelser
              </CardTitle>
              <BarChart3 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              {isLoadingPuls ? (
                <Skeleton className="h-6 w-24" />
              ) : ubesvartePuls && ubesvartePuls.count > 0 ? (
                <div className="flex items-center gap-2">
                  <Badge variant="destructive" className="text-sm">
                    {ubesvartePuls.count} ubesvart{ubesvartePuls.count > 1 ? 'e' : ''}
                  </Badge>
                  <span className="text-sm text-muted-foreground">venter på deg</span>
                </div>
              ) : (
                <p className="text-muted-foreground">Alle besvart ✓</p>
              )}
              <ChevronRight className="h-4 w-4 absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
            </CardContent>
          </Card>

          {/* Min turnus denne uken */}
          <Card 
            className="cursor-pointer hover:shadow-md transition-shadow"
            onClick={() => navigate('/min-side/turnus')}
          >
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Min turnus denne uken
              </CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              {isLoadingTurnus ? (
                <Skeleton className="h-6 w-full" />
              ) : ukeTurnus && ukeTurnus.length > 0 ? (
                <div className="flex flex-wrap gap-1.5">
                  {['Ma', 'Ti', 'On', 'To', 'Fr', 'Lø', 'Sø'].map((dag, idx) => {
                    const hasShift = ukeTurnus.some((t: any) => {
                      if (t.dato) {
                        const shiftDate = new Date(t.dato);
                        return shiftDate.getDay() === (idx === 6 ? 0 : idx + 1);
                      }
                      // For template data (ansatt_turnus)
                      return t.ukedag === idx + 1 && !t.fridag;
                    });
                    return (
                      <Badge 
                        key={dag} 
                        variant={hasShift ? "default" : "outline"}
                        className={hasShift ? "" : "opacity-50"}
                      >
                        {dag}
                      </Badge>
                    );
                  })}
                </div>
              ) : (
                <p className="text-muted-foreground">Ingen vakter denne uken</p>
              )}
              <ChevronRight className="h-4 w-4 absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
            </CardContent>
          </Card>

          {/* Ferie-saldo */}
          <Card 
            className="cursor-pointer hover:shadow-md transition-shadow"
            onClick={() => navigate('/min-side/ferie')}
          >
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Ferie i {new Date().getFullYear()}
              </CardTitle>
              <Umbrella className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              {isLoadingFerie ? (
                <Skeleton className="h-6 w-32" />
              ) : ferieSaldo ? (
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Brukt: {ferieSaldo.brukt}t</span>
                    <span className="font-medium">{ferieSaldo.gjenstar}t igjen</span>
                  </div>
                  <Progress 
                    value={(ferieSaldo.brukt / ferieSaldo.totalt) * 100} 
                    className="h-2"
                  />
                </div>
              ) : (
                <p className="text-muted-foreground">Ingen feriedata</p>
              )}
              <ChevronRight className="h-4 w-4 absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
            </CardContent>
          </Card>
        </div>

        {/* Snarveier */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <Button 
            variant="outline" 
            className="h-auto py-4 flex flex-col gap-2"
            onClick={() => navigate('/min-side/profil')}
          >
            <User className="h-5 w-5" />
            <span className="text-xs">Min profil</span>
          </Button>
          <Button 
            variant="outline" 
            className="h-auto py-4 flex flex-col gap-2"
            onClick={() => navigate('/min-side/mal')}
          >
            <Target className="h-5 w-5" />
            <span className="text-xs">Mine mål</span>
          </Button>
          <Button 
            variant="outline" 
            className="h-auto py-4 flex flex-col gap-2"
            onClick={() => navigate('/min-side/turnus')}
          >
            <Clock className="h-5 w-5" />
            <span className="text-xs">Min turnus</span>
          </Button>
          <Button 
            variant="outline" 
            className="h-auto py-4 flex flex-col gap-2"
            onClick={() => navigate('/min-side/ferie')}
          >
            <Umbrella className="h-5 w-5" />
            <span className="text-xs">Ferie & Fravær</span>
          </Button>
        </div>
      </div>
    </AppLayout>
  );
}
