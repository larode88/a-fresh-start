// Min Turnus - Ukeoversikt og stillingsprosent
import { useCurrentAnsatt } from "@/hooks/useCurrentAnsatt";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { format, startOfWeek, endOfWeek, addDays, getISOWeek } from "date-fns";
import { nb } from "date-fns/locale";
import { Calendar, Clock, ChevronLeft, ChevronRight, Palmtree, Briefcase, Stethoscope, AlertCircle, Lock } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useState, useMemo } from "react";

import { AppLayout } from "@/components/AppLayout";
import { useAnsattSelectorContext } from "@/components/AnsattSelector";
import { useSalonContext } from "@/components/SalonSelector";

const UKEDAGER = ['Mandag', 'Tirsdag', 'Onsdag', 'Torsdag', 'Fredag', 'Lørdag', 'Søndag'];

export default function MinTurnus() {
  const { ansatt: currentUserAnsatt, isLoading: isLoadingAnsatt } = useCurrentAnsatt();
  const { selectedAnsatt, isViewingAsOther } = useAnsattSelectorContext();
  const { selectedSalonId } = useSalonContext();
  const [weekOffset, setWeekOffset] = useState(0);

  // Use selected ansatt if viewing as other, otherwise use current user's ansatt
  const ansatt = selectedAnsatt || currentUserAnsatt;

  // Calculate week dates
  const today = new Date();
  const currentWeekStart = startOfWeek(today, { weekStartsOn: 1 });
  const targetWeekStart = addDays(currentWeekStart, weekOffset * 7);
  const targetWeekEnd = endOfWeek(targetWeekStart, { weekStartsOn: 1 });
  const weekNumber = getISOWeek(targetWeekStart);
  const startStr = format(targetWeekStart, 'yyyy-MM-dd');
  const sluttStr = format(targetWeekEnd, 'yyyy-MM-dd');
  
  // Determine effective salon ID
  const effectiveSalonId = selectedSalonId || ansatt?.salong_id;

  // Fetch actual planned shifts from turnus_skift for the target week
  const { data: planlagteSkift, isLoading: isLoadingSkift } = useQuery({
    queryKey: ['min-turnus-skift', ansatt?.id, startStr, sluttStr],
    queryFn: async () => {
      if (!ansatt?.id) return [];
      
      const { data, error } = await supabase
        .from('turnus_skift')
        .select('*')
        .eq('ansatt_id', ansatt.id)
        .gte('dato', startStr)
        .lte('dato', sluttStr)
        .order('dato');
      
      if (error) throw error;
      return data || [];
    },
    enabled: !!ansatt?.id,
  });

  // Fetch helligdager for the week
  const { data: helligdager } = useQuery({
    queryKey: ['helligdager-uke', startStr, sluttStr],
    queryFn: async () => {
      const { data } = await supabase
        .from('kalender')
        .select('dato, helligdag_navn')
        .eq('er_helligdag', true)
        .gte('dato', startStr)
        .lte('dato', sluttStr);
      return data || [];
    },
  });

  // Fetch åpningstider for the salon
  const { data: apningstider } = useQuery({
    queryKey: ['apningstider', effectiveSalonId],
    queryFn: async () => {
      if (!effectiveSalonId) return [];
      
      const { data } = await supabase
        .from('salong_apningstider')
        .select('*')
        .eq('salon_id', effectiveSalonId)
        .order('ukedag');
      
      return data || [];
    },
    enabled: !!effectiveSalonId,
  });

  // Fetch godkjent ferie for the week
  const { data: ferieData } = useQuery({
    queryKey: ['min-ferie', ansatt?.id, effectiveSalonId, weekOffset],
    queryFn: async () => {
      if (!ansatt?.id || !effectiveSalonId) return [];
      
      const { data } = await supabase
        .from('ferie')
        .select('startdato, sluttdato, type')
        .eq('ansatt_id', ansatt.id)
        .eq('salon_id', effectiveSalonId)
        .eq('status', 'godkjent')
        .lte('startdato', sluttStr)
        .gte('sluttdato', startStr);
      
      return data || [];
    },
    enabled: !!ansatt?.id && !!effectiveSalonId,
  });

  // Fetch godkjent fravær for the week
  const { data: fravaerData } = useQuery({
    queryKey: ['min-fravaer', ansatt?.id, effectiveSalonId, weekOffset],
    queryFn: async () => {
      if (!ansatt?.id || !effectiveSalonId) return [];
      
      const { data } = await supabase
        .from('fravaer')
        .select('startdato, sluttdato, fravaerstype')
        .eq('ansatt_id', ansatt.id)
        .eq('salon_id', effectiveSalonId)
        .eq('status', 'godkjent')
        .lte('startdato', sluttStr)
        .gte('sluttdato', startStr);
      
      return data || [];
    },
    enabled: !!ansatt?.id && !!effectiveSalonId,
  });

  const isLoading = isLoadingAnsatt || isLoadingSkift;

  // Build a Set of ferie/fravær dates with their types
  const fravaersDatoer = useMemo(() => {
    const datoer = new Set<string>();
    const typer = new Map<string, string>();
    
    // Process ferie
    (ferieData || []).forEach(periode => {
      let current = new Date(periode.startdato);
      const end = new Date(periode.sluttdato);
      while (current <= end) {
        const dateStr = format(current, 'yyyy-MM-dd');
        datoer.add(dateStr);
        typer.set(dateStr, periode.type || 'ferie');
        current = addDays(current, 1);
      }
    });
    
    // Process fravær
    (fravaerData || []).forEach(periode => {
      let current = new Date(periode.startdato);
      const end = new Date(periode.sluttdato);
      while (current <= end) {
        const dateStr = format(current, 'yyyy-MM-dd');
        datoer.add(dateStr);
        typer.set(dateStr, periode.fravaerstype || 'fravaer');
        current = addDays(current, 1);
      }
    });
    
    return { datoer, typer };
  }, [ferieData, fravaerData]);

  // Build week schedule from actual shifts (same logic as SkiftCelle/TurnusTimeline)
  const getWeekSchedule = () => {
    const schedule: any[] = [];
    
    for (let i = 0; i < 7; i++) {
      const date = addDays(targetWeekStart, i);
      const dateStr = format(date, 'yyyy-MM-dd');
      const ukedag = i + 1; // 1 = Monday, 7 = Sunday
      
      // Find relevant data
      const helligdag = helligdager?.find((h: any) => h.dato === dateStr);
      const apning = apningstider?.find((a: any) => a.ukedag === ukedag);
      const skift = planlagteSkift?.find((s: any) => s.dato === dateStr);
      
      const erHelligdag = !!helligdag;
      const erStengt = apning?.stengt || false;
      const erLaastDag = ukedag === 7 || erHelligdag; // Sunday or holiday
      
      // Check for ferie from shift data (kilde='ferie') OR legacy ferie/fravær tables
      const harFerie = fravaersDatoer.datoer.has(dateStr) || skift?.kilde === 'ferie';
      const ferieType = fravaersDatoer.typer.get(dateStr) || (skift?.kilde === 'ferie' ? 'Ferie' : null);
      
      // Priority 1: Ferie/Fravær
      if (harFerie) {
        schedule.push({
          date,
          ukedag,
          harVakt: false,
          erFerie: true,
          ferieType,
          helligdag: helligdag?.helligdag_navn,
          source: 'ferie'
        });
        continue;
      }
      
      // Priority 2: Stengt salong (not on holidays - those are handled separately)
      if (erStengt && !erHelligdag) {
        schedule.push({
          date,
          ukedag,
          harVakt: false,
          erStengt: true,
          helligdag: null,
          source: 'stengt'
        });
        continue;
      }
      
      // Priority 3: Helligdag/Søndag
      if (erLaastDag) {
        if (skift && skift.start_tid && skift.slutt_tid) {
          // Working on holiday (shift exists for this date)
          schedule.push({
            date,
            ukedag,
            harVakt: true,
            startTid: skift.start_tid,
            sluttTid: skift.slutt_tid,
            timer: skift.timer_planlagt || calculateHours(skift.start_tid, skift.slutt_tid),
            merknad: skift.notat,
            helligdag: helligdag?.helligdag_navn,
            erOpplaast: true,
            source: 'skift'
          });
        } else {
          // Standard day off on holiday/Sunday
          schedule.push({
            date,
            ukedag,
            harVakt: false,
            helligdag: helligdag?.helligdag_navn,
            erSondag: ukedag === 7 && !erHelligdag,
            source: 'helligdag'
          });
        }
        continue;
      }
      
      // Priority 4: Regular day with shift
      if (skift && skift.start_tid && skift.slutt_tid) {
        schedule.push({
          date,
          ukedag,
          harVakt: true,
          startTid: skift.start_tid,
          sluttTid: skift.slutt_tid,
          timer: skift.timer_planlagt || calculateHours(skift.start_tid, skift.slutt_tid),
          merknad: skift.notat,
          helligdag: helligdag?.helligdag_navn,
          source: 'skift'
        });
        continue;
      }
      
      // Priority 5: Regular day off (no shift generated)
      schedule.push({
        date,
        ukedag,
        harVakt: false,
        fridag: true,
        helligdag: helligdag?.helligdag_navn,
        source: 'none'
      });
    }
    
    return schedule;
  };

  const calculateHours = (start: string, slutt: string, pause?: number) => {
    if (!start || !slutt) return 0;
    const [startH, startM] = start.split(':').map(Number);
    const [sluttH, sluttM] = slutt.split(':').map(Number);
    const totalMinutes = (sluttH * 60 + sluttM) - (startH * 60 + startM) - (pause || 0);
    return totalMinutes / 60;
  };

  const weekSchedule = getWeekSchedule();
  const totalTimer = weekSchedule
    .filter(d => d.harVakt && d.timer)
    .reduce((sum, d) => sum + d.timer, 0);

  // Get ferie/fravær badge
  const getFerieBadge = (ferieType: string) => {
    switch (ferieType) {
      case 'ferie':
        return (
          <Badge className="bg-blue-500/20 text-blue-700 border-blue-300">
            <Palmtree className="h-3 w-3 mr-1" />
            Ferie
          </Badge>
        );
      case 'permisjon':
        return (
          <Badge className="bg-purple-500/20 text-purple-700 border-purple-300">
            <Briefcase className="h-3 w-3 mr-1" />
            Permisjon
          </Badge>
        );
      case 'sykmelding':
      case 'egenmelding':
        return (
          <Badge className="bg-red-500/20 text-red-700 border-red-300">
            <Stethoscope className="h-3 w-3 mr-1" />
            Sykmelding
          </Badge>
        );
      default:
        return (
          <Badge className="bg-orange-500/20 text-orange-700 border-orange-300">
            Fravær
          </Badge>
        );
    }
  };

  if (isLoading) {
    return (
      <AppLayout>
        <div className="container max-w-3xl mx-auto py-8 px-4 space-y-6">
          <Skeleton className="h-10 w-48" />
          <Skeleton className="h-20 w-full" />
          <Skeleton className="h-80 w-full" />
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="container max-w-3xl mx-auto py-8 px-4 space-y-6">
        <div className="flex items-center gap-3">
          <Calendar className="h-6 w-6 text-primary" />
          <h1 className="text-2xl font-bold">
            {isViewingAsOther ? `${ansatt?.fornavn}s turnus` : 'Min turnus'}
          </h1>
        </div>

        {isViewingAsOther && (
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Du ser på turnus for {ansatt?.fornavn} {ansatt?.etternavn} i {ansatt?.salong_navn}
            </AlertDescription>
          </Alert>
        )}

        {/* Uke-navigasjon */}
        <Card>
          <CardContent className="py-4">
            <div className="flex items-center justify-between">
              <Button variant="ghost" size="icon" onClick={() => setWeekOffset(prev => prev - 1)}>
                <ChevronLeft className="h-5 w-5" />
              </Button>
              
              <div className="text-center">
                <p className="text-lg font-semibold">
                  Uke {weekNumber}
                </p>
                <p className="text-sm text-muted-foreground">
                  {format(targetWeekStart, 'd. MMM', { locale: nb })} - {format(targetWeekEnd, 'd. MMM yyyy', { locale: nb })}
                </p>
              </div>
              
              <Button variant="ghost" size="icon" onClick={() => setWeekOffset(prev => prev + 1)}>
                <ChevronRight className="h-5 w-5" />
              </Button>
            </div>
            
            {weekOffset !== 0 && (
              <div className="text-center mt-2">
                <Button variant="link" size="sm" onClick={() => setWeekOffset(0)}>
                  Gå til denne uken
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Ukens timer */}
        <Card className="bg-primary/5 border-primary/20">
          <CardContent className="py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-primary" />
                <span className="text-muted-foreground">Totalt denne uken</span>
              </div>
              <span className="text-2xl font-bold">{totalTimer.toFixed(1)}t</span>
            </div>
          </CardContent>
        </Card>

        {/* Dagsoversikt */}
        <div className="space-y-3">
          {weekSchedule.map((dag) => {
            const isToday = format(dag.date, 'yyyy-MM-dd') === format(today, 'yyyy-MM-dd');
            
            return (
              <Card 
                key={format(dag.date, 'yyyy-MM-dd')}
                className={`${isToday ? 'ring-2 ring-primary' : ''} ${!dag.harVakt && !dag.erFerie ? 'opacity-60' : ''}`}
              >
                <CardContent className="py-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="w-20">
                        <p className={`font-semibold ${isToday ? 'text-primary' : ''}`}>
                          {UKEDAGER[dag.ukedag - 1].slice(0, 3)}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {format(dag.date, 'd. MMM', { locale: nb })}
                        </p>
                      </div>
                      
                      {dag.erFerie ? (
                        <p className="text-muted-foreground capitalize">{dag.ferieType || 'Ferie'}</p>
                      ) : dag.erStengt ? (
                        <p className="text-muted-foreground">Stengt</p>
                      ) : dag.harVakt ? (
                        <div>
                          <p className="font-medium">
                            {dag.startTid?.slice(0, 5)} - {dag.sluttTid?.slice(0, 5)}
                          </p>
                          {dag.timer > 0 && (
                            <p className="text-sm text-muted-foreground">{dag.timer.toFixed(1)} timer</p>
                          )}
                        </div>
                      ) : (
                        <p className="text-muted-foreground">Fri</p>
                      )}
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {isToday && (
                        <Badge variant="default" className="bg-primary">I dag</Badge>
                      )}
                      {dag.helligdag && (
                        <Badge variant="outline" className="bg-red-500/10 text-red-700 border-red-300">
                          {dag.helligdag}
                        </Badge>
                      )}
                      {dag.merknad && (
                        <Badge variant="outline">{dag.merknad}</Badge>
                      )}
                      {dag.erStengt ? (
                        <Badge variant="outline" className="bg-muted/50">
                          <Lock className="h-3 w-3 mr-1" />
                          Stengt
                        </Badge>
                      ) : dag.erFerie ? (
                        getFerieBadge(dag.ferieType)
                      ) : dag.harVakt ? (
                        <Badge variant="secondary" className="bg-green-500/10 text-green-700">
                          <Clock className="h-3 w-3 mr-1" />
                          Jobb
                        </Badge>
                      ) : (
                        <Badge variant="outline">Fri</Badge>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

      </div>
    </AppLayout>
  );
}
