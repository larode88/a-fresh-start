import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Loader2, CheckCircle, XCircle, AlertTriangle, Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface DebugInfo {
  code?: string;
  error?: string;
  errorDescription?: string;
  redirectUri?: string;
  timestamp?: string;
  functionResponse?: unknown;
  functionError?: unknown;
}

const HubSpotCallback = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [status, setStatus] = useState<"loading" | "success" | "error">("loading");
  const [errorMessage, setErrorMessage] = useState<string>("");
  const [debugInfo, setDebugInfo] = useState<DebugInfo>({});
  const [showDebug, setShowDebug] = useState(false);

  useEffect(() => {
    const exchangeCode = async () => {
      const code = searchParams.get("code");
      const error = searchParams.get("error");
      const errorDescription = searchParams.get("error_description");
      const state = searchParams.get("state");

      // Initialize debug info
      const debug: DebugInfo = {
        code: code ? `${code.substring(0, 20)}...` : undefined,
        error: error || undefined,
        errorDescription: errorDescription || undefined,
        redirectUri: `${window.location.origin}/auth/hubspot/callback`,
        timestamp: new Date().toISOString(),
      };

      console.log("=== HubSpot Callback Debug ===");
      console.log("Full URL:", window.location.href);
      console.log("Search params:", Object.fromEntries(searchParams.entries()));
      console.log("Code present:", !!code);
      console.log("Error present:", !!error);
      console.log("State:", state);
      console.log("Redirect URI:", debug.redirectUri);

      if (error) {
        const fullErrorMessage = errorDescription 
          ? `HubSpot feil: ${error} - ${errorDescription}`
          : `HubSpot feil: ${error}`;
        
        console.error("HubSpot OAuth error:", { error, errorDescription });
        setStatus("error");
        setErrorMessage(fullErrorMessage);
        setDebugInfo(debug);
        return;
      }

      if (!code) {
        console.error("No authorization code received from HubSpot");
        setStatus("error");
        setErrorMessage("Ingen autorisasjonskode mottatt fra HubSpot. Sjekk at redirect URI er korrekt konfigurert i HubSpot-appen.");
        setDebugInfo(debug);
        return;
      }

      try {
        console.log("Exchanging code for tokens...");
        console.log("Calling hubspot-auth edge function with redirect_uri:", debug.redirectUri);

        const { data, error: functionError } = await supabase.functions.invoke("hubspot-auth", {
          body: {
            action: "exchange",
            code,
            redirect_uri: debug.redirectUri,
          },
        });

        console.log("Edge function response:", { data, functionError });
        debug.functionResponse = data;
        debug.functionError = functionError;

        if (functionError) {
          console.error("Edge function error:", functionError);
          throw new Error(`Edge function feil: ${functionError.message || JSON.stringify(functionError)}`);
        }

        if (data?.error) {
          console.error("HubSpot API error in response:", data);
          const errorDetail = data.error_description || data.error;
          throw new Error(`HubSpot API feil: ${errorDetail}`);
        }

        if (!data?.success) {
          console.error("Unexpected response format:", data);
          throw new Error("Uventet respons fra server. Sjekk edge function logs.");
        }

        console.log("Token exchange successful!");
        setStatus("success");
        setDebugInfo(debug);
        toast.success("HubSpot er nå koblet til!");

        // Redirect to admin after short delay
        setTimeout(() => {
          navigate("/admin");
        }, 2000);
      } catch (err) {
        console.error("HubSpot callback error:", err);
        setStatus("error");
        setErrorMessage(err instanceof Error ? err.message : "Ukjent feil under token-utveksling");
        setDebugInfo(debug);
      }
    };

    exchangeCode();
  }, [searchParams, navigate]);

  const copyDebugInfo = () => {
    const debugText = JSON.stringify(debugInfo, null, 2);
    navigator.clipboard.writeText(debugText);
    toast.success("Debug-info kopiert til utklippstavle");
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="text-center space-y-4 max-w-md w-full">
        {status === "loading" && (
          <>
            <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto" />
            <h1 className="text-2xl font-semibold">Kobler til HubSpot...</h1>
            <p className="text-muted-foreground">Vennligst vent mens vi fullfører tilkoblingen.</p>
          </>
        )}

        {status === "success" && (
          <>
            <CheckCircle className="h-12 w-12 text-green-500 mx-auto" />
            <h1 className="text-2xl font-semibold">HubSpot tilkoblet!</h1>
            <p className="text-muted-foreground">Du blir snart sendt tilbake til admin-panelet.</p>
          </>
        )}

        {status === "error" && (
          <>
            <XCircle className="h-12 w-12 text-destructive mx-auto" />
            <h1 className="text-2xl font-semibold">Tilkobling feilet</h1>
            <p className="text-muted-foreground">{errorMessage}</p>
            
            <div className="flex flex-col gap-2 mt-4">
              <Button onClick={() => navigate("/admin")} variant="default">
                Tilbake til Admin
              </Button>
              <Button 
                onClick={() => setShowDebug(!showDebug)} 
                variant="outline"
                size="sm"
              >
                <AlertTriangle className="h-4 w-4 mr-2" />
                {showDebug ? "Skjul" : "Vis"} debug-info
              </Button>
            </div>

            {showDebug && (
              <Card className="mt-4 text-left">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm flex items-center justify-between">
                    Debug-informasjon
                    <Button size="sm" variant="ghost" onClick={copyDebugInfo}>
                      <Copy className="h-4 w-4" />
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <pre className="text-xs bg-muted p-2 rounded overflow-auto max-h-60">
                    {JSON.stringify(debugInfo, null, 2)}
                  </pre>
                  <p className="text-xs text-muted-foreground mt-2">
                    Sjekk også nettleserens konsoll (F12) og edge function logs for mer informasjon.
                  </p>
                </CardContent>
              </Card>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default HubSpotCallback;
