import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { AppLayout } from "@/components/AppLayout";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calculator, TrendingUp } from "lucide-react";
import { BonusCalculationTab } from "@/components/bonus/BonusCalculationTab";
import { GrowthBonusAdminTab } from "@/components/bonus/GrowthBonusAdminTab";
import { useUserRole } from "@/hooks/useUserRole";
import { supabase } from "@/integrations/supabase/client";
import { Skeleton } from "@/components/ui/skeleton";

export default function DistrictBonus() {
  const { isAdmin, isLoading: isRoleLoading } = useUserRole();
  const [selectedDistrict, setSelectedDistrict] = useState<string>("alle");

  // Hent brukerens distrikt (kjører alltid for å unngå race condition)
  const { data: userDistrictId, isLoading: isDistrictLoading } = useQuery({
    queryKey: ["user-district-id"],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return null;
      
      const { data } = await supabase
        .from("users")
        .select("district_id")
        .eq("id", user.id)
        .single();
      return data?.district_id;
    },
  });

  const { data: districts } = useQuery({
    queryKey: ["districts-for-bonus"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("districts")
        .select("id, name")
        .order("name");
      if (error) throw error;
      return data;
    },
    enabled: isAdmin,
  });

  // For admin: bruk valgt distrikt, for distriktsjefer: bruk deres tilknyttede distrikt
  const effectiveDistrictId = isAdmin 
    ? (selectedDistrict !== "alle" ? selectedDistrict : undefined)
    : userDistrictId;

  // Vent på at rolle og distrikt er lastet for ikke-admin
  const isLoadingUserContext = isRoleLoading || (!isAdmin && isDistrictLoading);

  if (isLoadingUserContext) {
    return (
      <AppLayout>
        <div className="space-y-6">
          <Skeleton className="h-10 w-64" />
          <Skeleton className="h-6 w-96" />
          <Skeleton className="h-12 w-full max-w-md" />
          <Skeleton className="h-96 w-full" />
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="space-y-6">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-3xl font-serif font-semibold text-foreground">
              Bonus & Vekstbonus
            </h1>
            <p className="text-muted-foreground mt-1">
              Se bonusberegninger og vekstbonus for ditt distrikt
            </p>
          </div>

          {isAdmin && districts && (
            <Select value={selectedDistrict} onValueChange={setSelectedDistrict}>
              <SelectTrigger className="w-[280px]">
                <SelectValue placeholder="Velg distrikt" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="alle">Alle distrikter</SelectItem>
                {districts.map(d => (
                  <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>

        <Tabs defaultValue="beregning" className="space-y-6">
          <TabsList>
          <TabsTrigger value="beregning" className="gap-2">
            <Calculator className="h-4 w-4" />
            Lojalitetsbonus
          </TabsTrigger>
            <TabsTrigger value="vekstbonus" className="gap-2">
              <TrendingUp className="h-4 w-4" />
              Vekstbonus
            </TabsTrigger>
          </TabsList>

          <TabsContent value="beregning">
            <BonusCalculationTab hideCalculationControls districtId={effectiveDistrictId} hideReturnCommission />
          </TabsContent>

          <TabsContent value="vekstbonus">
            <GrowthBonusAdminTab districtId={effectiveDistrictId} hideDistrictSelector={!isAdmin} />
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}
