import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { CheckCircle2, Camera, Mail } from "lucide-react";
import { z } from "zod";
import { ImageUpload } from "@/components/ImageUpload";

// Schema without password fields - we use OTP login instead
const onboardingSchema = z.object({
  firstName: z.string().min(2, "Fornavn må være minst 2 tegn").max(50),
  lastName: z.string().min(2, "Etternavn må være minst 2 tegn").max(50),
  phone: z.string().min(8, "Mobil må være minst 8 siffer").regex(/^\+?\d[\d\s-]*$/, "Ugyldig mobilnummer"),
});

const Onboarding = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const token = searchParams.get("token");
  
  const [invitation, setInvitation] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    phone: "",
  });
  const [gdprConsent, setGdprConsent] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (token) {
      fetchInvitation();
    } else {
      setLoading(false);
    }
  }, [token]);

  const fetchInvitation = async () => {
    try {
      const { data, error } = await supabase
        .rpc("get_invitation_by_token", { _token: token });

      if (error) throw error;

      if (!data || data.length === 0) {
        toast.error("Ugyldig eller utløpt invitasjon");
        navigate("/login");
        return;
      }

      setInvitation(data[0]);
    } catch (error) {
      toast.error("Ugyldig invitasjon");
      navigate("/login");
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    if (errors[e.target.name]) {
      setErrors({ ...errors, [e.target.name]: "" });
    }
  };

  const handleAvatarChange = (file: File | null, previewUrl: string | null) => {
    setAvatarFile(file);
    setAvatarPreview(previewUrl);
    if (errors.avatar) {
      setErrors({ ...errors, avatar: "" });
    }
  };

  const uploadAvatar = async (userId: string): Promise<string | null> => {
    if (!avatarFile) return null;

    const fileExt = "jpg";
    const filePath = `${userId}/avatar.${fileExt}`;

    const { error: uploadError } = await supabase.storage
      .from("avatars")
      .upload(filePath, avatarFile, { upsert: true });

    if (uploadError) throw uploadError;

    const { data: urlData } = supabase.storage
      .from("avatars")
      .getPublicUrl(filePath);

    return urlData.publicUrl;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});

    if (!avatarFile) {
      setErrors({ avatar: "Profilbilde er påkrevd" });
      return;
    }

    if (!gdprConsent) {
      setErrors({ gdprConsent: "Du må samtykke til behandling av personopplysninger" });
      return;
    }

    setSubmitting(true);

    try {
      const validated = onboardingSchema.parse(formData);

      const firstName = validated.firstName.trim();
      const lastName = validated.lastName.trim();
      const phone = validated.phone.trim();

      // First, we need to create the user via edge function that uses admin API
      // This creates the user with a random password (they'll use OTP to log in)
      const { data: createResult, error: createError } = await supabase.functions.invoke(
        'create-invited-user',
        {
          body: {
            invitation_id: invitation.id,
            email: invitation.email,
            first_name: firstName,
            last_name: lastName,
            phone: phone,
            role: invitation.role,
            salon_id: invitation.salon_id,
            district_id: invitation.district_id,
            supplier_id: invitation.supplier_id,
            hubspot_contact_id: invitation.hubspot_contact_id,
          }
        }
      );

      if (createError) {
        console.error("Error creating user:", createError);
        toast.error("Kunne ikke opprette brukerkonto");
        return;
      }

      if (!createResult?.success || !createResult?.user_id) {
        toast.error(createResult?.error || "Kunne ikke opprette brukerkonto");
        return;
      }

      const userId = createResult.user_id;

      // Upload avatar
      try {
        const avatarUrl = await uploadAvatar(userId);
        
        if (avatarUrl) {
          // Update user profile with avatar
          await supabase
            .from("users")
            .update({ avatar_url: avatarUrl })
            .eq("id", userId);

          // Update ansatte profile with avatar if exists
          await supabase
            .from("ansatte")
            .update({ profilbilde_url: avatarUrl })
            .eq("user_id", userId);
        }
      } catch (avatarError) {
        console.error("Error uploading avatar:", avatarError);
        // Don't fail the whole process for avatar
      }

      toast.success("Konto aktivert! Du kan nå logge inn med engangskode.");
      navigate("/login");
    } catch (error: any) {
      if (error instanceof z.ZodError) {
        const fieldErrors: Record<string, string> = {};
        error.errors.forEach((err) => {
          if (err.path[0]) {
            fieldErrors[err.path[0] as string] = err.message;
          }
        });
        setErrors(fieldErrors);
      } else {
        toast.error(error.message || "Aktivering feilet");
      }
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Laster invitasjon...</p>
        </div>
      </div>
    );
  }

  if (!invitation) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="w-full max-w-md p-8 text-center">
          <div className="w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center mx-auto mb-4">
            <span className="text-3xl">❌</span>
          </div>
          <h2 className="text-2xl font-bold mb-2">Ugyldig invitasjon</h2>
          <p className="text-muted-foreground mb-6">
            Invitasjonslenken er ugyldig eller har utløpt.
          </p>
          <Button onClick={() => navigate("/login")}>
            Gå til innlogging
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-primary/5 via-accent-light/20 to-info-light/20">
      <Card className="w-full max-w-md p-8 shadow-lg">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full gradient-success mb-4">
            <CheckCircle2 className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-foreground mb-2">
            Aktiver din konto
          </h1>
          <p className="text-muted-foreground mb-4">
            Fullfør registreringen for å komme i gang
          </p>
          <div className="inline-block px-4 py-2 bg-accent-light rounded-lg">
            <p className="text-sm text-muted-foreground">E-post</p>
            <p className="font-semibold text-foreground">{invitation.email}</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Avatar Upload */}
          <div className="flex flex-col items-center space-y-2">
            <Label className="text-center">Profilbilde *</Label>
            <ImageUpload
              value={avatarPreview}
              onChange={handleAvatarChange}
              size="lg"
              shape="circle"
              placeholder={
                <div className="flex flex-col items-center">
                  <Camera className="h-8 w-8 mb-1" />
                  <span className="text-xs">Last opp</span>
                </div>
              }
              disabled={submitting}
            />
            {errors.avatar && (
              <p className="text-sm text-destructive">{errors.avatar}</p>
            )}
            <p className="text-xs text-muted-foreground text-center">
              Klikk for å velge bilde. Du kan tilpasse størrelsen.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="firstName">Fornavn *</Label>
              <Input
                id="firstName"
                name="firstName"
                placeholder="Ola"
                value={formData.firstName}
                onChange={handleChange}
                required
                disabled={submitting}
              />
              {errors.firstName && (
                <p className="text-sm text-destructive">{errors.firstName}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="lastName">Etternavn *</Label>
              <Input
                id="lastName"
                name="lastName"
                placeholder="Nordmann"
                value={formData.lastName}
                onChange={handleChange}
                required
                disabled={submitting}
              />
              {errors.lastName && (
                <p className="text-sm text-destructive">{errors.lastName}</p>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone">Mobil *</Label>
            <Input
              id="phone"
              name="phone"
              type="tel"
              placeholder="+47 123 45 678"
              value={formData.phone}
              onChange={handleChange}
              required
              disabled={submitting}
            />
            {errors.phone && (
              <p className="text-sm text-destructive">{errors.phone}</p>
            )}
          </div>

          {/* OTP Info Box */}
          <div className="bg-primary/5 border border-primary/20 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <Mail className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
              <div className="text-sm">
                <p className="font-medium text-foreground mb-1">Innlogging med engangskode</p>
                <p className="text-muted-foreground">
                  Etter registrering logger du inn med en engangskode som sendes til e-posten din. Ingen passord å huske!
                </p>
              </div>
            </div>
          </div>

          {/* GDPR Consent */}
          <div className="space-y-2 pt-2">
            <div className="flex items-start space-x-3">
              <Checkbox
                id="gdprConsent"
                checked={gdprConsent}
                onCheckedChange={(checked) => setGdprConsent(checked === true)}
                disabled={submitting}
                className="mt-1"
              />
              <Label 
                htmlFor="gdprConsent" 
                className="text-sm font-normal leading-relaxed cursor-pointer"
              >
                Jeg samtykker til at mine personopplysninger behandles i henhold til{" "}
                <a 
                  href="https://www.har1.no/personvern" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline"
                >
                  personvernerklæringen
                </a>
                . *
              </Label>
            </div>
            {errors.gdprConsent && (
              <p className="text-sm text-destructive">{errors.gdprConsent}</p>
            )}
          </div>

          <Button
            type="submit"
            className="w-full gradient-primary"
            disabled={submitting}
            size="lg"
          >
            {submitting ? "Aktiverer konto..." : "Aktiver konto"}
          </Button>
        </form>

        <p className="text-center text-sm text-muted-foreground mt-6">
          Har du allerede en konto?{" "}
          <a href="/login" className="text-primary hover:underline font-medium">
            Logg inn
          </a>
        </p>
      </Card>
    </div>
  );
};

export default Onboarding;
