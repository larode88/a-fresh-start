import { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSalonContext } from '@/components/SalonSelector';
import { AppLayout } from '@/components/AppLayout';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Check, ChevronLeft, ChevronRight, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import AnsattSteg1Grunninfo from '@/components/ansatte/wizard/AnsattSteg1Grunninfo';
import AnsattSteg2Stilling from '@/components/ansatte/wizard/AnsattSteg2Stilling';
import AnsattSteg3Kompetanse from '@/components/ansatte/wizard/AnsattSteg3Kompetanse';
import AnsattSteg4Lonn from '@/components/ansatte/wizard/AnsattSteg4Lonn';
import AnsattSteg5Fullforing from '@/components/ansatte/wizard/AnsattSteg5Fullforing';

export interface AnsattWizardData {
  // Steg 1: Grunninfo
  fornavn: string;
  etternavn?: string;
  epost?: string;
  telefon?: string;
  fodselsdato?: string;
  
  // Steg 2: Stilling
  frisorfunksjon?: string;
  lederstilling?: string;
  ansatt_dato?: string;
  har_provetid: boolean;
  provetid_til?: string;
  stillingsprosent: number;
  arbeidstid_per_uke: number;
  arbeidsdager_pr_uke: number;
  
  // Steg 3: Kompetanse
  fagbrev_dato?: string;
  utdanning_fagbrev?: string;
  verdier?: string;
  motivasjon_i_jobben?: string;
  
  // Steg 4: Lønn
  lonnstype_enum?: string;
  timesats?: number;
  fastlonn?: number;
  provisjon_behandling_prosent: number;
  provisjon_vare_prosent: number;
  provisjon_behandling_hoy_prosent: number;
  provisjon_terskel: number;
  feriekrav_type_enum?: string;
  feriekrav_timer_per_aar: number;
  
  // Steg 5: Fullføring
  send_velkomst: boolean;
}

const STEPS = [
  { id: 1, title: 'Grunninfo', description: 'Personalia' },
  { id: 2, title: 'Stilling', description: 'Rolle og arbeidstid' },
  { id: 3, title: 'Kompetanse', description: 'Fagbrev og utdanning' },
  { id: 4, title: 'Lønn', description: 'Lønn og provisjon' },
  { id: 5, title: 'Fullfør', description: 'Oppsummering' },
];

const INITIAL_DATA: AnsattWizardData = {
  fornavn: '',
  etternavn: '',
  epost: '',
  telefon: '',
  fodselsdato: '',
  frisorfunksjon: undefined,
  lederstilling: undefined,
  ansatt_dato: new Date().toISOString().split('T')[0],
  har_provetid: true,
  provetid_til: '',
  stillingsprosent: 100,
  arbeidstid_per_uke: 37.5,
  arbeidsdager_pr_uke: 5,
  fagbrev_dato: '',
  utdanning_fagbrev: '',
  verdier: '',
  motivasjon_i_jobben: '',
  lonnstype_enum: undefined,
  timesats: undefined,
  fastlonn: undefined,
  provisjon_behandling_prosent: 33,
  provisjon_vare_prosent: 10,
  provisjon_behandling_hoy_prosent: 35,
  provisjon_terskel: 0,
  feriekrav_type_enum: 'tariffavtale',
  feriekrav_timer_per_aar: 187.5,
  send_velkomst: true,
};

export default function AnsattWizard() {
  const navigate = useNavigate();
  const { selectedSalonId } = useSalonContext();
  
  const [currentStep, setCurrentStep] = useState(1);
  const [data, setData] = useState<AnsattWizardData>(INITIAL_DATA);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const updateData = (updates: Partial<AnsattWizardData>) => {
    setData(prev => ({ ...prev, ...updates }));
  };

  const progress = (currentStep / STEPS.length) * 100;
  
  const canGoNext = () => {
    switch (currentStep) {
      case 1:
        return !!data.fornavn;
      case 2:
        return data.stillingsprosent >= 0 && data.stillingsprosent <= 100 && !!data.ansatt_dato;
      case 3:
        return true;
      case 4:
        if (data.lonnstype_enum === 'timelonn' || data.lonnstype_enum === 'timelonn_provisjon') {
          return !!data.timesats && data.timesats > 0;
        }
        return true;
      case 5:
        return true;
      default:
        return false;
    }
  };
  
  const handleNext = () => {
    if (currentStep < STEPS.length) {
      setCurrentStep(prev => prev + 1);
    }
  };
  
  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleComplete = useCallback(async () => {
    if (!selectedSalonId) {
      toast.error('Ingen salong valgt');
      return;
    }

    setIsSubmitting(true);
    try {
      // Helper to convert empty strings to null
      const emptyToNull = (value: string | undefined): string | null => 
        !value || value === '' ? null : value;

      // Create ansatt in database using direct insert
      const insertPayload: Record<string, unknown> = {
        salong_id: selectedSalonId,
        fornavn: data.fornavn,
        etternavn: emptyToNull(data.etternavn),
        epost: emptyToNull(data.epost),
        telefon: emptyToNull(data.telefon),
        fodselsdato: emptyToNull(data.fodselsdato),
        frisorfunksjon: emptyToNull(data.frisorfunksjon),
        lederstilling: emptyToNull(data.lederstilling),
        ansatt_dato: emptyToNull(data.ansatt_dato),
        provetid_til: data.har_provetid ? emptyToNull(data.provetid_til) : null,
        stillingsprosent: data.stillingsprosent,
        arbeidstid_per_uke: data.arbeidstid_per_uke,
        arbeidsdager_pr_uke: data.arbeidsdager_pr_uke,
        fagbrev_dato: emptyToNull(data.fagbrev_dato),
        utdanning_fagbrev: emptyToNull(data.utdanning_fagbrev),
        verdier: emptyToNull(data.verdier),
        motivasjon_i_jobben: emptyToNull(data.motivasjon_i_jobben),
        lonnstype_enum: emptyToNull(data.lonnstype_enum),
        timesats: data.timesats || null,
        fastlonn: data.fastlonn || null,
        provisjon_behandling_prosent: data.provisjon_behandling_prosent,
        provisjon_vare_prosent: data.provisjon_vare_prosent,
        provisjon_behandling_hoy_prosent: data.provisjon_behandling_hoy_prosent,
        provisjon_terskel: data.provisjon_terskel,
        feriekrav_type_enum: emptyToNull(data.feriekrav_type_enum),
        feriekrav_timer_per_aar: data.feriekrav_timer_per_aar,
        status: 'Aktiv',
        inkluder_i_turnus: true,
        inkluder_i_budsjett: true,
      };

      const { data: newAnsatt, error } = await supabase
        .from('ansatte')
        .insert(insertPayload as any)
        .select()
        .single();
      if (error) throw error;

      // If email exists, create user account and sync to HubSpot automatically
      if (newAnsatt && data.epost && data.epost.includes('@')) {
        try {
          // Build stilling string
          const stillingParts: string[] = [];
          if (data.frisorfunksjon) {
            const stillingMap: Record<string, string> = {
              'frisor': 'Frisør',
              'senior_frisor': 'Senior Frisør',
              'laerling': 'Lærling',
            };
            stillingParts.push(stillingMap[data.frisorfunksjon] || data.frisorfunksjon);
          }
          if (data.lederstilling) {
            const lederMap: Record<string, string> = {
              'daglig_leder': 'Daglig leder',
              'avdelingsleder': 'Avdelingsleder',
              'styreleder': 'Styreleder',
            };
            stillingParts.push(lederMap[data.lederstilling] || data.lederstilling);
          }

          const { data: result, error: userError } = await supabase.functions.invoke('create-employee-user', {
            body: {
              ansatt_id: newAnsatt.id,
              email: data.epost,
              fornavn: data.fornavn,
              etternavn: data.etternavn || undefined,
              telefon: data.telefon || undefined,
              salon_id: selectedSalonId,
              stilling: stillingParts.join(', ') || undefined,
              send_welcome_email: data.send_velkomst,
            },
          });

          if (userError) {
            console.error('Error creating user:', userError);
            toast.success('Ansatt opprettet', { 
              description: 'Brukerkonto kunne ikke opprettes automatisk' 
            });
          } else {
            const messages: string[] = ['Ansatt opprettet'];
            if (result?.hubspot_contact_id) messages.push('synkronisert til HubSpot');
            if (result?.welcome_email_sent) messages.push('velkomst-e-post sendt');
            toast.success('Fullført', { description: messages.join(', ') });
          }
        } catch (userErr) {
          console.error('User creation error:', userErr);
          toast.success('Ansatt opprettet', { 
            description: 'Det oppstod en feil ved brukeropprettelse' 
          });
        }
      } else {
        toast.success('Ansatt opprettet');
      }

      navigate('/ansatte');
    } catch (error) {
      console.error('Error creating ansatt:', error);
      toast.error('Kunne ikke opprette ansatt');
    } finally {
      setIsSubmitting(false);
    }
  }, [data, selectedSalonId, navigate]);
  
  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return <AnsattSteg1Grunninfo data={data} updateData={updateData} />;
      case 2:
        return <AnsattSteg2Stilling data={data} updateData={updateData} />;
      case 3:
        return <AnsattSteg3Kompetanse data={data} updateData={updateData} />;
      case 4:
        return <AnsattSteg4Lonn data={data} updateData={updateData} salongId={selectedSalonId || ''} />;
      case 5:
        return <AnsattSteg5Fullforing data={data} updateData={updateData} onComplete={handleComplete} isSubmitting={isSubmitting} />;
      default:
        return null;
    }
  };

  if (!selectedSalonId) {
    return (
      <AppLayout title="Ny ansatt" subtitle="Registrer ny ansatt steg for steg">
        <div className="max-w-4xl mx-auto py-12 text-center">
          <p className="text-muted-foreground">Velg en salong først</p>
          <Button variant="outline" className="mt-4" onClick={() => navigate('/ansatte')}>
            Tilbake til ansatte
          </Button>
        </div>
      </AppLayout>
    );
  }
  
  return (
    <AppLayout title="Ny ansatt" subtitle="Registrer ny ansatt steg for steg">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-serif font-semibold text-foreground">
              Registrer ny ansatt
            </h1>
            <p className="text-muted-foreground">
              Fyll ut informasjon om den nye ansatte
            </p>
          </div>
          <Button variant="outline" onClick={() => navigate('/ansatte')}>
            Tilbake til liste
          </Button>
        </div>
        
        {/* Progress */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-4">
              {STEPS.map((step, index) => (
                <div 
                  key={step.id} 
                  className={`flex flex-col items-center ${index < STEPS.length - 1 ? 'flex-1' : ''}`}
                >
                  <div 
                    className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-medium transition-colors ${
                      step.id < currentStep 
                        ? 'bg-primary text-primary-foreground' 
                        : step.id === currentStep 
                          ? 'bg-primary text-primary-foreground ring-4 ring-primary/20' 
                          : 'bg-muted text-muted-foreground'
                    }`}
                  >
                    {step.id < currentStep ? <Check className="h-5 w-5" /> : step.id}
                  </div>
                  <span className={`text-xs mt-2 text-center hidden sm:block ${
                    step.id === currentStep ? 'text-foreground font-medium' : 'text-muted-foreground'
                  }`}>
                    {step.title}
                  </span>
                </div>
              ))}
            </div>
            <Progress value={progress} className="h-2" />
          </CardContent>
        </Card>
        
        {/* Current Step */}
        <Card>
          <CardContent className="pt-6">
            {renderStep()}
          </CardContent>
        </Card>
        
        {/* Navigation */}
        {currentStep < 5 && (
          <div className="flex justify-between">
            <Button 
              variant="outline" 
              onClick={handleBack} 
              disabled={currentStep === 1}
            >
              <ChevronLeft className="h-4 w-4 mr-2" />
              Forrige
            </Button>
            <div className="text-sm text-muted-foreground self-center">
              Steg {currentStep} av {STEPS.length}
            </div>
            <Button 
              onClick={handleNext} 
              disabled={!canGoNext()}
            >
              Neste
              <ChevronRight className="h-4 w-4 ml-2" />
            </Button>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
