import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { WeekSelector } from "@/components/WeekSelector";
import { SalonComparisonTable } from "@/components/district/SalonComparisonTable";
import { DistrictTrendsChart } from "@/components/district/DistrictTrendsChart";
import { getISOWeek, getISOWeekYear } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { AppLayout } from "@/components/AppLayout";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DollarSign,
  TrendingUp,
  Users,
  Clock,
  Building2,
  MapPin,
} from "lucide-react";

interface SalonWithKPIs {
  id: string;
  name: string;
  city: string | null;
  totalRevenue: number;
  addonSharePercent: number;
  rebookingPercent: number;
  efficiencyPercent: number;
  stylistCount: number;
}

interface DistrictKPIs {
  totalRevenue: number;
  avgAddonShare: number;
  avgRebooking: number;
  avgEfficiency: number;
  salonCount: number;
  stylistCount: number;
}

interface District {
  id: string;
  name: string;
}

const DistrictDashboard = () => {
  const navigate = useNavigate();
  const { user, profile, loading } = useAuth();
  const { toast } = useToast();
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [salons, setSalons] = useState<SalonWithKPIs[]>([]);
  const [districtKPIs, setDistrictKPIs] = useState<DistrictKPIs | null>(null);
  const [districtName, setDistrictName] = useState("");
  const [loadingData, setLoadingData] = useState(true);
  const [districts, setDistricts] = useState<District[]>([]);
  const [selectedDistrictId, setSelectedDistrictId] = useState<string | null>(null);

  const isAdmin = profile?.role === "admin";

  useEffect(() => {
    if (!loading && !user) {
      navigate("/login");
      return;
    }

    if (!loading && profile && !["district_manager", "admin"].includes(profile.role)) {
      toast({
        title: "Ingen tilgang",
        description: "Du har ikke tilgang til distrikts-dashboardet",
        variant: "destructive",
      });
      navigate("/dashboard");
    }
  }, [user, profile, loading, navigate, toast]);

  useEffect(() => {
    const fetchDistricts = async () => {
      if (!isAdmin) return;

      try {
        const { data, error } = await supabase
          .from("districts")
          .select("id, name")
          .order("name");

        if (error) throw error;
        setDistricts(data || []);
      } catch (error) {
        console.error("Error fetching districts:", error);
      }
    };

    fetchDistricts();
  }, [isAdmin]);

  useEffect(() => {
    if (profile?.district_id && !isAdmin) {
      setSelectedDistrictId(profile.district_id);
    }
  }, [profile, isAdmin]);

  const activeDistrictId = isAdmin ? selectedDistrictId : profile?.district_id;

  useEffect(() => {
    if (activeDistrictId || (isAdmin && !selectedDistrictId)) {
      fetchDistrictData();
    }
  }, [activeDistrictId, selectedDate, isAdmin]);

  const fetchDistrictData = async () => {
    setLoadingData(true);
    try {
      const weekNumber = getISOWeek(selectedDate);
      const year = getISOWeekYear(selectedDate);

      if (activeDistrictId) {
        const { data: district } = await supabase
          .from("districts")
          .select("name")
          .eq("id", activeDistrictId)
          .single();
        setDistrictName(district?.name || "");
      } else if (isAdmin) {
        setDistrictName("Alle distrikter");
      }

      let salonsQuery = supabase.from("salons").select("id, name, city");
      
      if (activeDistrictId) {
        salonsQuery = salonsQuery.eq("district_id", activeDistrictId);
      }

      const { data: salonsData, error: salonsError } = await salonsQuery;
      if (salonsError) throw salonsError;

      if (!salonsData || salonsData.length === 0) {
        setSalons([]);
        setDistrictKPIs(null);
        setLoadingData(false);
        return;
      }

      const salonIds = salonsData.map((s) => s.id);
      
      const { data: kpisData, error: kpisError } = await supabase
        .from("weekly_kpis")
        .select("*")
        .in("salon_id", salonIds)
        .eq("week", weekNumber)
        .eq("year", year);

      if (kpisError) throw kpisError;

      const { data: usersData } = await supabase
        .from("users")
        .select("salon_id")
        .in("salon_id", salonIds);

      const stylistCountMap = new Map<string, number>();
      usersData?.forEach((u) => {
        if (u.salon_id) {
          stylistCountMap.set(u.salon_id, (stylistCountMap.get(u.salon_id) || 0) + 1);
        }
      });

      const salonKPIsMap = new Map<string, {
        totalRevenue: number;
        addonShareSum: number;
        rebookingSum: number;
        efficiencySum: number;
        count: number;
      }>();

      kpisData?.forEach((kpi) => {
        if (!kpi.salon_id) return;
        const existing = salonKPIsMap.get(kpi.salon_id) || {
          totalRevenue: 0,
          addonShareSum: 0,
          rebookingSum: 0,
          efficiencySum: 0,
          count: 0,
        };
        salonKPIsMap.set(kpi.salon_id, {
          totalRevenue: existing.totalRevenue + Number(kpi.total_revenue),
          addonShareSum: existing.addonShareSum + Number(kpi.addon_share_percent),
          rebookingSum: existing.rebookingSum + Number(kpi.rebooking_percent),
          efficiencySum: existing.efficiencySum + Number(kpi.efficiency_percent),
          count: existing.count + 1,
        });
      });

      const salonsWithKPIs: SalonWithKPIs[] = salonsData.map((salon) => {
        const kpis = salonKPIsMap.get(salon.id);
        return {
          id: salon.id,
          name: salon.name,
          city: salon.city,
          totalRevenue: kpis?.totalRevenue || 0,
          addonSharePercent: kpis ? kpis.addonShareSum / kpis.count : 0,
          rebookingPercent: kpis ? kpis.rebookingSum / kpis.count : 0,
          efficiencyPercent: kpis ? kpis.efficiencySum / kpis.count : 0,
          stylistCount: stylistCountMap.get(salon.id) || 0,
        };
      });

      salonsWithKPIs.sort((a, b) => b.totalRevenue - a.totalRevenue);
      setSalons(salonsWithKPIs);

      const totalStylistCount = salonsWithKPIs.reduce((sum, s) => sum + s.stylistCount, 0);
      const salonsWithData = salonsWithKPIs.filter((s) => s.totalRevenue > 0);
      
      setDistrictKPIs({
        totalRevenue: salonsWithKPIs.reduce((sum, s) => sum + s.totalRevenue, 0),
        avgAddonShare: salonsWithData.length > 0
          ? salonsWithData.reduce((sum, s) => sum + s.addonSharePercent, 0) / salonsWithData.length
          : 0,
        avgRebooking: salonsWithData.length > 0
          ? salonsWithData.reduce((sum, s) => sum + s.rebookingPercent, 0) / salonsWithData.length
          : 0,
        avgEfficiency: salonsWithData.length > 0
          ? salonsWithData.reduce((sum, s) => sum + s.efficiencyPercent, 0) / salonsWithData.length
          : 0,
        salonCount: salonsData.length,
        stylistCount: totalStylistCount,
      });
    } catch (error) {
      console.error("Error fetching district data:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke laste distriktsdata",
        variant: "destructive",
      });
    } finally {
      setLoadingData(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <AppLayout title="Distriktsoversikt" subtitle={districtName}>
      <div className="max-w-7xl mx-auto p-4 space-y-6">
        {/* Controls */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
          {isAdmin && districts.length > 0 && (
            <Select
              value={selectedDistrictId || "all"}
              onValueChange={(value) => setSelectedDistrictId(value === "all" ? null : value)}
            >
              <SelectTrigger className="w-[200px]">
                <MapPin className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Velg distrikt" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Alle distrikter</SelectItem>
                {districts.map((district) => (
                  <SelectItem key={district.id} value={district.id}>
                    {district.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
          <WeekSelector selectedDate={selectedDate} onDateChange={setSelectedDate} />
        </div>

        {/* Summary Cards */}
        {loadingData ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="h-24 bg-card rounded-lg animate-pulse" />
            ))}
          </div>
        ) : districtKPIs ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            <Card className="p-4">
              <div className="flex items-center gap-2 text-muted-foreground mb-2">
                <Building2 className="h-4 w-4" />
                <span className="text-xs">Salonger</span>
              </div>
              <p className="text-2xl font-bold text-foreground">{districtKPIs.salonCount}</p>
            </Card>
            <Card className="p-4">
              <div className="flex items-center gap-2 text-muted-foreground mb-2">
                <Users className="h-4 w-4" />
                <span className="text-xs">Frisører</span>
              </div>
              <p className="text-2xl font-bold text-foreground">{districtKPIs.stylistCount}</p>
            </Card>
            <Card className="p-4">
              <div className="flex items-center gap-2 text-muted-foreground mb-2">
                <DollarSign className="h-4 w-4" />
                <span className="text-xs">Total Omsetning</span>
              </div>
              <p className="text-2xl font-bold text-foreground">
                {Math.round(districtKPIs.totalRevenue).toLocaleString("nb-NO")} kr
              </p>
            </Card>
            <Card className="p-4">
              <div className="flex items-center gap-2 text-muted-foreground mb-2">
                <TrendingUp className="h-4 w-4" />
                <span className="text-xs">Gj.snitt Merbehandling</span>
              </div>
              <p className="text-2xl font-bold text-foreground">
                {Math.round(districtKPIs.avgAddonShare)}%
              </p>
            </Card>
            <Card className="p-4">
              <div className="flex items-center gap-2 text-muted-foreground mb-2">
                <Users className="h-4 w-4" />
                <span className="text-xs">Gj.snitt Rebooking</span>
              </div>
              <p className="text-2xl font-bold text-foreground">
                {Math.round(districtKPIs.avgRebooking)}%
              </p>
            </Card>
            <Card className="p-4">
              <div className="flex items-center gap-2 text-muted-foreground mb-2">
                <Clock className="h-4 w-4" />
                <span className="text-xs">Gj.snitt Effektivitet</span>
              </div>
              <p className="text-2xl font-bold text-foreground">
                {Math.round(districtKPIs.avgEfficiency)}%
              </p>
            </Card>
          </div>
        ) : (
          <Card className="p-8 text-center">
            <p className="text-muted-foreground">Ingen data tilgjengelig for denne uken</p>
          </Card>
        )}

        {/* Salon Comparison */}
        <div className="grid lg:grid-cols-2 gap-6">
          <SalonComparisonTable salons={salons} loading={loadingData} />
          <DistrictTrendsChart districtId={activeDistrictId} isAdmin={isAdmin && !activeDistrictId} />
        </div>
      </div>
    </AppLayout>
  );
};

export default DistrictDashboard;
