import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { KPICard } from "@/components/dashboard/KPICard";
import { ChallengeCard } from "@/components/dashboard/ChallengeCard";
import { BadgesList } from "@/components/dashboard/BadgesList";
import { InsuranceStatusCard } from "@/components/dashboard/InsuranceStatusCard";
import { WeekSelector } from "@/components/WeekSelector";
import { AnnouncementCarousel } from "@/components/dashboard/AnnouncementCarousel";
import { AppLayout } from "@/components/AppLayout";
import { supabase } from "@/integrations/supabase/client";
import { getISOWeek, getISOWeekYear } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { DollarSign, Users, TrendingUp, Clock, Plus, ClipboardList } from "lucide-react";
import { getGreeting } from "@/lib/greetingUtils";

const MANAGER_ROLES = ['salon_owner', 'daglig_leder', 'avdelingsleder', 'admin'];

interface KPIData {
  totalRevenue: number;
  addonSharePercent: number;
  rebookingPercent: number;
  efficiencyPercent: number;
  trend: {
    totalRevenue: number;
    addonShare: number;
    rebooking: number;
    efficiency: number;
  };
}

const Dashboard = () => {
  const navigate = useNavigate();
  const { user, profile, loading } = useAuth();
  const { toast } = useToast();
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [kpiData, setKpiData] = useState<KPIData | null>(null);
  const [loadingData, setLoadingData] = useState(false);

  useEffect(() => {
    if (!loading && !user) {
      navigate("/login");
    }
  }, [user, loading, navigate]);

  useEffect(() => {
    if (user && profile) {
      fetchKPIData();
    }
  }, [user, profile, selectedDate]);

  const fetchKPIData = async () => {
    setLoadingData(true);
    try {
      const weekNumber = getISOWeek(selectedDate);
      const year = getISOWeekYear(selectedDate);

      const { data: currentKPI, error: currentError } = await supabase
        .from("weekly_kpis")
        .select("*")
        .eq("stylist_id", user!.id)
        .eq("week", weekNumber)
        .eq("year", year)
        .maybeSingle();

      if (currentError) throw currentError;

      const prevWeek = weekNumber === 1 ? 52 : weekNumber - 1;
      const prevYear = weekNumber === 1 ? year - 1 : year;
      
      const { data: prevKPI } = await supabase
        .from("weekly_kpis")
        .select("*")
        .eq("stylist_id", user!.id)
        .eq("week", prevWeek)
        .eq("year", prevYear)
        .maybeSingle();

      if (currentKPI) {
        const calculateTrend = (current: number, previous: number | null) => {
          if (!previous || previous === 0) return 0;
          return Number(((current - previous) / previous * 100).toFixed(1));
        };

        setKpiData({
          totalRevenue: currentKPI.total_revenue,
          addonSharePercent: currentKPI.addon_share_percent,
          rebookingPercent: currentKPI.rebooking_percent,
          efficiencyPercent: currentKPI.efficiency_percent,
          trend: {
            totalRevenue: calculateTrend(currentKPI.total_revenue, prevKPI?.total_revenue || 0),
            addonShare: calculateTrend(currentKPI.addon_share_percent, prevKPI?.addon_share_percent || 0),
            rebooking: calculateTrend(currentKPI.rebooking_percent, prevKPI?.rebooking_percent || 0),
            efficiency: calculateTrend(currentKPI.efficiency_percent, prevKPI?.efficiency_percent || 0),
          },
        });
      } else {
        setKpiData(null);
      }
    } catch (error) {
      console.error("Error fetching KPI data:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke laste KPI-data",
        variant: "destructive",
      });
    } finally {
      setLoadingData(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Laster...</p>
        </div>
      </div>
    );
  }

  return (
    <AppLayout 
      title="Min Challenge" 
      subtitle={getGreeting(profile?.first_name || profile?.name?.split(' ')[0], profile?.fodselsdato)}
    >
      {/* Announcement Carousel - full width */}
      <AnnouncementCarousel />

      <div className="container mx-auto px-4 py-8">

        {/* Week Selector and Quick Actions */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <WeekSelector selectedDate={selectedDate} onDateChange={setSelectedDate} />
          <div className="flex items-center gap-2">
            <Button onClick={() => navigate("/kpi-input")}>
              <Plus className="w-4 h-4 mr-2" />
              Registrer data
            </Button>
            {profile?.role && MANAGER_ROLES.includes(profile.role) && (
              <Button onClick={() => navigate("/batch-kpi-input")}>
                <ClipboardList className="w-4 h-4 mr-2" />
                Batch-registrering
              </Button>
            )}
          </div>
        </div>

        {/* KPI Grid */}
        {loadingData ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-32 bg-card rounded-lg animate-pulse" />
            ))}
          </div>
        ) : kpiData ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <KPICard
              title="Total Omsetning"
              value={Math.round(kpiData.totalRevenue).toLocaleString("nb-NO")}
              subtitle="kr"
              icon={DollarSign}
              variant="info"
              trend={{ value: kpiData.trend.totalRevenue, label: "fra forrige uke" }}
            />
            <KPICard
              title="Merbehandlingsandel"
              value={Math.round(kpiData.addonSharePercent)}
              subtitle="%"
              icon={TrendingUp}
              variant="success"
              trend={{ value: kpiData.trend.addonShare, label: "fra forrige uke" }}
            />
            <KPICard
              title="Rebooking"
              value={Math.round(kpiData.rebookingPercent)}
              subtitle="%"
              icon={Users}
              variant="success"
              trend={{ value: kpiData.trend.rebooking, label: "fra forrige uke" }}
            />
            <KPICard
              title="Effektivitet"
              value={Math.round(kpiData.efficiencyPercent)}
              subtitle="%"
              icon={Clock}
              variant="default"
              trend={{ value: kpiData.trend.efficiency, label: "fra forrige uke" }}
            />
          </div>
        ) : (
          <div className="bg-card border border-border rounded-lg p-8 text-center mb-8">
            <p className="text-muted-foreground mb-4">
              Ingen data registrert for denne uken
            </p>
            <Button onClick={() => navigate("/kpi-input")}>
              <Plus className="w-4 h-4 mr-2" />
              Registrer data
            </Button>
          </div>
        )}

        {/* Challenge & Status Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <ChallengeCard />
          <BadgesList />
          <InsuranceStatusCard />
        </div>
      </div>
    </AppLayout>
  );
};

export default Dashboard;
