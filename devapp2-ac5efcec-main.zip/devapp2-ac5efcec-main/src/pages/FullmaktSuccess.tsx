import { useSearchParams } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Mail, Phone, ExternalLink, ShoppingBag } from "lucide-react";
import haar1ForsikringLogo from "@/assets/haar1-forsikring-logo.png";

export default function FullmaktSuccess() {
  const [searchParams] = useSearchParams();
  const noSignatureRequired = searchParams.get("noSignatureRequired") === "true";

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/30 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="text-center space-y-4">
          <div className="flex justify-center">
            <img src={haar1ForsikringLogo} alt="Hår1 Forsikring" className="h-16" />
          </div>
          <div className="flex justify-center">
            <div className="h-20 w-20 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
              {noSignatureRequired ? (
                <ShoppingBag className="h-12 w-12 text-green-600 dark:text-green-400" />
              ) : (
                <CheckCircle2 className="h-12 w-12 text-green-600 dark:text-green-400" />
              )}
            </div>
          </div>
          <div className="space-y-2">
            <CardTitle className="text-2xl font-serif">
              {noSignatureRequired ? "Bestillingen er fullført!" : "Fullmakten er signert!"}
            </CardTitle>
            <CardDescription className="text-base">
              {noSignatureRequired 
                ? "Takk! Din forsikringsbestilling er nå registrert og Hår1 Forsikringsteamet vil behandle den snarest."
                : "Takk! Fullmakten er nå signert, og Hår1 Forsikringsteamet starter overføringen av forsikringene dine."
              }
            </CardDescription>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="bg-muted/50 rounded-xl p-4 space-y-2">
            <p className="text-sm text-muted-foreground text-center">
              Du vil motta en bekreftelse på e-post.
            </p>
          </div>

          <div className="border-t pt-4 space-y-4">
            <p className="text-sm font-medium text-center">
              Har du spørsmål?
            </p>
            <div className="flex flex-col gap-3">
              <a
                href="mailto:forsikring@har1.no"
                className="flex items-center justify-center gap-2 text-sm text-primary hover:underline"
              >
                <Mail className="h-4 w-4" />
                forsikring@har1.no
              </a>
              <a
                href="tel:+4740003345"
                className="flex items-center justify-center gap-2 text-sm text-primary hover:underline"
              >
                <Phone className="h-4 w-4" />
                +47 4000 3345
              </a>
            </div>
          </div>

          <Button asChild variant="outline" className="w-full" size="lg">
            <a href="https://har1.no" target="_blank" rel="noopener noreferrer">
              <ExternalLink className="mr-2 h-4 w-4" />
              Tilbake til har1.no
            </a>
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
