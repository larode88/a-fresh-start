import { useParams, useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Stethoscope } from "lucide-react";
import { format, differenceInWeeks } from "date-fns";
import { nb } from "date-fns/locale";
import { SykmeldingSummary } from "@/components/sykmelding/SykmeldingSummary";
import { KartleggingSkjema } from "@/components/sykmelding/KartleggingSkjema";
import { OppfolgingsplanBuilder } from "@/components/sykmelding/OppfolgingsplanBuilder";
import { DialogmoteDialog } from "@/components/sykmelding/DialogmoteDialog";
import { TiltakOversikt } from "@/components/sykmelding/TiltakOversikt";
import { FasevurderingDialog } from "@/components/sykmelding/FasevurderingDialog";
import { SykmeldingTimeline } from "@/components/sykmelding/SykmeldingTimeline";

const SykmeldingDetaljer = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { profile } = useAuth();

  const isLeader = profile?.role && ['admin', 'salon_owner', 'daglig_leder', 'avdelingsleder'].includes(profile.role);

  const { data: sykmelding, isLoading, refetch } = useQuery({
    queryKey: ['sykmelding', id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('sykemeldinger')
        .select(`
          *,
          users!sykemeldinger_user_id_fkey(id, name, avatar_url, email, phone),
          sykmelding_oppfolgingsplaner(*),
          sykmelding_dialogmoter(*),
          sykmelding_aktivitetskrav(*),
          sykmelding_tiltak(*),
          sykmelding_fasevurderinger(*),
          sykmelding_evalueringer(*)
        `)
        .eq('id', id)
        .single();

      if (error) throw error;
      return data;
    },
    enabled: !!id,
  });

  if (isLoading) {
    return (
      <div className="container mx-auto py-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 w-64 bg-muted rounded" />
          <div className="h-4 w-48 bg-muted rounded" />
        </div>
      </div>
    );
  }

  if (!sykmelding) {
    return (
      <div className="container mx-auto py-6 text-center">
        <p className="text-muted-foreground">Sykmelding ikke funnet</p>
        <Button variant="outline" onClick={() => navigate(-1)} className="mt-4">
          Gå tilbake
        </Button>
      </div>
    );
  }

  const uker = differenceInWeeks(new Date(), new Date(sykmelding.startdato));
  const ansattNavn = sykmelding.users?.name || 'Ukjent';

  return (
    <div className="container mx-auto py-6 space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div className="space-y-2">
          <Button variant="ghost" size="sm" onClick={() => navigate(-1)} className="gap-2 -ml-2">
            <ArrowLeft className="h-4 w-4" />
            Tilbake
          </Button>
          <div className="flex items-center gap-3">
            <Stethoscope className="h-8 w-8 text-primary" />
            <div>
              <h1 className="text-2xl font-serif font-bold text-foreground">
                {isLeader ? `${ansattNavn} - ` : ''}Sykmelding {sykmelding.grad}%
              </h1>
              <p className="text-muted-foreground">
                Fra {format(new Date(sykmelding.startdato), 'dd. MMMM yyyy', { locale: nb })} · Uke {uker}
              </p>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant={sykmelding.status === 'aktiv' ? 'default' : 'secondary'}>
            {sykmelding.status === 'aktiv' ? 'Aktiv' : sykmelding.status === 'avsluttet' ? 'Avsluttet' : 'Avbrutt'}
          </Badge>
          {sykmelding.oppfolgingslop_startet && (
            <Badge variant="outline">Oppfølging startet</Badge>
          )}
        </div>
      </div>

      {/* Tabs med 7 faner */}
      <Tabs defaultValue="oppsummering" className="w-full">
        <TabsList className="grid w-full grid-cols-7">
          <TabsTrigger value="oppsummering">Oppsummering</TabsTrigger>
          <TabsTrigger value="kartlegging">Kartlegging</TabsTrigger>
          <TabsTrigger value="oppfolgingsplan">Oppfølgingsplan</TabsTrigger>
          <TabsTrigger value="dialogmoter">Dialogmøter</TabsTrigger>
          <TabsTrigger value="tiltak">Tiltak</TabsTrigger>
          <TabsTrigger value="fasevurdering">Fasevurdering</TabsTrigger>
          <TabsTrigger value="tidslinje">Tidslinje</TabsTrigger>
        </TabsList>

        <TabsContent value="oppsummering" className="mt-6">
          <SykmeldingSummary 
            sykmelding={sykmelding} 
            isLeader={isLeader || false}
            onRefresh={refetch}
          />
        </TabsContent>

        <TabsContent value="kartlegging" className="mt-6">
          <KartleggingSkjema 
            sykmelding={sykmelding}
            isLeader={isLeader || false}
            onRefresh={refetch}
          />
        </TabsContent>

        <TabsContent value="oppfolgingsplan" className="mt-6">
          <OppfolgingsplanBuilder 
            sykmelding={sykmelding}
            isLeader={isLeader || false}
            onRefresh={refetch}
          />
        </TabsContent>

        <TabsContent value="dialogmoter" className="mt-6">
          <DialogmoteDialog 
            sykmelding={sykmelding}
            isLeader={isLeader || false}
            onRefresh={refetch}
          />
        </TabsContent>

        <TabsContent value="tiltak" className="mt-6">
          <TiltakOversikt 
            sykmelding={sykmelding}
            isLeader={isLeader || false}
            onRefresh={refetch}
          />
        </TabsContent>

        <TabsContent value="fasevurdering" className="mt-6">
          <FasevurderingDialog 
            sykmelding={sykmelding}
            isLeader={isLeader || false}
            onRefresh={refetch}
          />
        </TabsContent>

        <TabsContent value="tidslinje" className="mt-6">
          <SykmeldingTimeline sykmelding={sykmelding} />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default SykmeldingDetaljer;
