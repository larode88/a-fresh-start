import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, MessageSquare, Search, X, Archive, Inbox } from "lucide-react";
import { ThreadList } from "@/components/messages/ThreadList";
import { ThreadView } from "@/components/messages/ThreadView";
import { ComposeDialog } from "@/components/messages/ComposeDialog";
import { useToast } from "@/hooks/use-toast";
import { AppLayout } from "@/components/AppLayout";

export interface MessageThread {
  id: string;
  subject: string;
  created_at: string;
  created_by_user_id: string;
  salon_id: string | null;
  district_id: string | null;
  supplier_id: string | null;
  last_message?: string;
  last_message_at?: string;
  last_message_text?: string;
  thread_type?: string;
  unread_count?: number;
}

const Messages = () => {
  const { user, profile, loading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [threads, setThreads] = useState<MessageThread[]>([]);
  const [archivedThreads, setArchivedThreads] = useState<MessageThread[]>([]);
  const [filteredThreads, setFilteredThreads] = useState<MessageThread[]>([]);
  const [selectedThread, setSelectedThread] = useState<MessageThread | null>(null);
  const [loadingThreads, setLoadingThreads] = useState(true);
  const [composeOpen, setComposeOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [showSearch, setShowSearch] = useState(false);
  const [activeTab, setActiveTab] = useState<"inbox" | "archived">("inbox");

  useEffect(() => {
    if (!loading && !user) {
      navigate("/login");
    }
  }, [user, loading, navigate]);

  const fetchThreads = async () => {
    if (!user) return;

    try {
      const { data: participations } = await supabase
        .from("thread_participants")
        .select("thread_id, archived_at")
        .eq("user_id", user.id);

      const activeThreadIds: string[] = [];
      const archivedThreadIds: string[] = [];

      participations?.forEach((p: any) => {
        if (p.archived_at) {
          archivedThreadIds.push(p.thread_id);
        } else {
          activeThreadIds.push(p.thread_id);
        }
      });

      if (activeThreadIds.length > 0) {
        const { data: activeData } = await supabase
          .from("message_threads")
          .select("*")
          .in("id", activeThreadIds)
          .order("updated_at", { ascending: false });

        const mappedActive = (activeData || []).map((t: any) => ({
          ...t,
          last_message: t.last_message_text,
        }));
        setThreads(mappedActive);
      } else {
        setThreads([]);
      }

      if (archivedThreadIds.length > 0) {
        const { data: archivedData } = await supabase
          .from("message_threads")
          .select("*")
          .in("id", archivedThreadIds)
          .order("updated_at", { ascending: false });

        const mappedArchived = (archivedData || []).map((t: any) => ({
          ...t,
          last_message: t.last_message_text,
        }));
        setArchivedThreads(mappedArchived);
      } else {
        setArchivedThreads([]);
      }
    } catch (error) {
      console.error("Error fetching threads:", error);
    } finally {
      setLoadingThreads(false);
    }
  };

  useEffect(() => {
    fetchThreads();

    const channel = supabase
      .channel("thread-updates")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "message_threads",
        },
        () => {
          fetchThreads();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  useEffect(() => {
    const sourceThreads = activeTab === "inbox" ? threads : archivedThreads;
    
    if (!searchQuery.trim()) {
      setFilteredThreads(sourceThreads);
      return;
    }

    const query = searchQuery.toLowerCase();
    const filtered = sourceThreads.filter(
      (thread) =>
        thread.subject.toLowerCase().includes(query) ||
        thread.last_message?.toLowerCase().includes(query)
    );
    setFilteredThreads(filtered);
  }, [searchQuery, threads, archivedThreads, activeTab]);

  const handleThreadCreated = (thread: MessageThread) => {
    setThreads((prev) => [thread, ...prev]);
    setSelectedThread(thread);
    setComposeOpen(false);
  };

  const handleSelectThread = async (thread: MessageThread) => {
    setSelectedThread(thread);

    if (user) {
      await supabase
        .from("thread_participants")
        .update({ last_read_at: new Date().toISOString() })
        .eq("thread_id", thread.id)
        .eq("user_id", user.id);
    }
  };

  const handleArchiveThread = async (threadId: string) => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from("thread_participants")
        .update({ archived_at: new Date().toISOString() })
        .eq("thread_id", threadId)
        .eq("user_id", user.id);

      if (error) throw error;

      const thread = threads.find((t) => t.id === threadId);
      if (thread) {
        setThreads((prev) => prev.filter((t) => t.id !== threadId));
        setArchivedThreads((prev) => [thread, ...prev]);
        if (selectedThread?.id === threadId) {
          setSelectedThread(null);
        }
      }

      toast({ title: "Arkivert", description: "Samtalen er arkivert" });
    } catch (error) {
      console.error("Error archiving thread:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke arkivere samtalen",
        variant: "destructive",
      });
    }
  };

  const handleRestoreThread = async (threadId: string) => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from("thread_participants")
        .update({ archived_at: null })
        .eq("thread_id", threadId)
        .eq("user_id", user.id);

      if (error) throw error;

      const thread = archivedThreads.find((t) => t.id === threadId);
      if (thread) {
        setArchivedThreads((prev) => prev.filter((t) => t.id !== threadId));
        setThreads((prev) => [thread, ...prev]);
        if (selectedThread?.id === threadId) {
          setSelectedThread(null);
        }
      }

      toast({ title: "Gjenopprettet", description: "Samtalen er gjenopprettet til innboksen" });
    } catch (error) {
      console.error("Error restoring thread:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke gjenopprette samtalen",
        variant: "destructive",
      });
    }
  };

  const handleDeleteThread = async (threadId: string) => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from("thread_participants")
        .delete()
        .eq("thread_id", threadId)
        .eq("user_id", user.id);

      if (error) throw error;

      setThreads((prev) => prev.filter((t) => t.id !== threadId));
      setArchivedThreads((prev) => prev.filter((t) => t.id !== threadId));
      
      if (selectedThread?.id === threadId) {
        setSelectedThread(null);
      }

      toast({ title: "Slettet", description: "Samtalen er fjernet fra din innboks" });
    } catch (error) {
      console.error("Error deleting thread:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke slette samtalen",
        variant: "destructive",
      });
    }
  };

  const clearSearch = () => {
    setSearchQuery("");
    setShowSearch(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <AppLayout title="Meldinger">
      <div className="max-w-4xl mx-auto p-4">
        {/* Search and compose */}
        <div className="flex items-center gap-2 mb-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setShowSearch(!showSearch)}
          >
            <Search className="h-5 w-5" />
          </Button>
          <Button onClick={() => setComposeOpen(true)} size="sm">
            <Plus className="h-4 w-4 mr-2" />
            Ny melding
          </Button>
        </div>
        
        {showSearch && (
          <div className="mb-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Søk i meldinger..."
                className="pl-9 pr-9"
                autoFocus
              />
              {searchQuery && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute right-1 top-1/2 -translate-y-1/2 h-7 w-7"
                  onClick={clearSearch}
                >
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>
            {searchQuery && (
              <p className="text-xs text-muted-foreground mt-1">
                {filteredThreads.length} resultat{filteredThreads.length !== 1 ? "er" : ""}
              </p>
            )}
          </div>
        )}

        <div className="grid md:grid-cols-3 gap-4 h-[calc(100vh-200px)]">
          {/* Thread list */}
          <div className="md:col-span-1 bg-card rounded-lg border border-border overflow-hidden flex flex-col">
            <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as "inbox" | "archived")} className="w-full">
              <TabsList className="w-full rounded-none border-b">
                <TabsTrigger value="inbox" className="flex-1 gap-2">
                  <Inbox className="h-4 w-4" />
                  Innboks
                  {threads.length > 0 && (
                    <span className="text-xs text-muted-foreground">({threads.length})</span>
                  )}
                </TabsTrigger>
                <TabsTrigger value="archived" className="flex-1 gap-2">
                  <Archive className="h-4 w-4" />
                  Arkiv
                  {archivedThreads.length > 0 && (
                    <span className="text-xs text-muted-foreground">({archivedThreads.length})</span>
                  )}
                </TabsTrigger>
              </TabsList>
            </Tabs>
            
            <div className="flex-1 overflow-hidden">
              <ThreadList
                threads={filteredThreads}
                selectedThread={selectedThread}
                onSelectThread={handleSelectThread}
                onArchiveThread={handleArchiveThread}
                onDeleteThread={handleDeleteThread}
                onRestoreThread={handleRestoreThread}
                loading={loadingThreads}
                currentUserId={user?.id || ""}
                showArchived={activeTab === "archived"}
              />
            </div>
          </div>

          {/* Thread view */}
          <div className="md:col-span-2 bg-card rounded-lg border border-border overflow-hidden">
            {selectedThread ? (
              <ThreadView thread={selectedThread} currentUserId={user?.id || ""} />
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-muted-foreground p-8">
                <MessageSquare className="h-12 w-12 mb-4" />
                <p className="text-center">Velg en samtale for å se meldinger</p>
              </div>
            )}
          </div>
        </div>
      </div>

      <ComposeDialog
        open={composeOpen}
        onOpenChange={setComposeOpen}
        onThreadCreated={handleThreadCreated}
        userSalonId={profile?.salon_id}
        userDistrictId={profile?.district_id}
      />
    </AppLayout>
  );
};

export default Messages;
