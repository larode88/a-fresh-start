import { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Sparkles, Loader2, ArrowLeft, Mail } from "lucide-react";
import haar1LogoWhite from "@/assets/haar1-portalen-logo-white.png";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { useAuth } from "@/hooks/useAuth";

type AuthStep = "input" | "otp";

const Login = () => {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();

  // Auto-redirect if already logged in
  useEffect(() => {
    if (!authLoading && user) {
      navigate("/dashboard");
    }
  }, [user, authLoading, navigate]);

  // Email auth state
  const [email, setEmail] = useState("");
  const [authStep, setAuthStep] = useState<AuthStep>("input");
  const [otp, setOtp] = useState("");
  const [sendingOtp, setSendingOtp] = useState(false);
  const [verifyingOtp, setVerifyingOtp] = useState(false);

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !email.includes("@")) {
      toast.error("Skriv inn en gyldig e-postadresse");
      return;
    }
    
    setSendingOtp(true);
    try {
      const { data, error } = await supabase.functions.invoke("send-auth-otp", {
        body: { email, type: "login" },
      });
      
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      
      toast.success("Engangskode sendt til e-posten din");
      setAuthStep("otp");
    } catch (error: any) {
      console.error("Error sending email OTP:", error);
      toast.error(error.message || "Kunne ikke sende engangskode");
    } finally {
      setSendingOtp(false);
    }
  };

  const handleVerifyOtp = async () => {
    if (otp.length !== 6) {
      toast.error("Vennligst skriv inn hele koden");
      return;
    }
    
    setVerifyingOtp(true);
    try {
      const { data, error } = await supabase.functions.invoke("verify-auth-otp", {
        body: { email, otp, type: "login" },
      });
      
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      
      if (data?.authUrl) {
        window.location.href = data.authUrl;
      } else {
        toast.success("Velkommen tilbake!");
        navigate("/dashboard");
      }
    } catch (error: any) {
      console.error("Error verifying email OTP:", error);
      toast.error(error.message || "Ugyldig kode");
      setOtp("");
    } finally {
      setVerifyingOtp(false);
    }
  };

  const handleBackToInput = () => {
    setAuthStep("input");
    setOtp("");
  };

  return (
    <div className="min-h-screen flex">
      {/* Left side - Decorative */}
      <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden bg-gradient-to-br from-primary/90 via-primary to-primary/80">
        {/* Decorative circles */}
        <div className="absolute top-20 left-20 w-64 h-64 rounded-full bg-white/10 blur-3xl" />
        <div className="absolute bottom-32 right-10 w-96 h-96 rounded-full bg-white/5 blur-3xl" />
        <div className="absolute top-1/2 left-1/3 w-48 h-48 rounded-full bg-accent/20 blur-2xl" />
        
        {/* Content */}
        <div className="relative z-10 flex flex-col justify-center px-16 text-white">
          <div className="mb-8">
            <img 
              src={haar1LogoWhite} 
              alt="Hår1 Portalen" 
              className="h-32 w-auto"
            />
          </div>
          
          <h1 className="font-serif text-3xl font-light mb-4 leading-tight">
            Hår1s platform for<br />
            <span className="font-medium">salongdrift, lønnsomhet og vekst</span>
          </h1>
          
          <p className="text-base text-white/70 max-w-sm leading-relaxed">
            Din komplette løsning for å drive en suksessfull salong.
          </p>
        </div>
      </div>

      {/* Right side - Login form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 bg-background">
        <div className="w-full max-w-md">
          {/* Mobile header */}
          <div className="lg:hidden text-center mb-10">
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl gradient-primary mb-4">
              <Sparkles className="w-7 h-7 text-white" />
            </div>
            <h1 className="font-serif text-xl font-medium text-foreground">
              Hår1s platform for salongdrift, lønnsomhet og vekst
            </h1>
          </div>

          <div className="mb-10">
            <h2 className="font-serif text-3xl font-light text-foreground mb-2">
              Velkommen tilbake
            </h2>
            <p className="text-muted-foreground">
              {authStep === "otp"
                ? "Skriv inn koden du mottok på e-post"
                : "Logg inn for å fortsette til portalen"}
            </p>
          </div>

          {/* Email Login Flow */}
          {authStep === "input" ? (
            <form onSubmit={handleSendOtp} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-sm font-medium">
                  E-postadresse
                </Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="navn@eksempel.no"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    disabled={sendingOtp}
                    className="h-12 pl-11 rounded-xl border-border/50 bg-muted/30 focus:bg-background transition-colors"
                  />
                </div>
                <p className="text-xs text-muted-foreground">
                  Vi sender deg en engangskode på e-post
                </p>
              </div>

              <Button
                type="submit"
                className="w-full h-12 rounded-xl gradient-primary text-base font-medium shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 transition-all duration-300"
                disabled={sendingOtp}
              >
                {sendingOtp ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Sender kode...
                  </>
                ) : (
                  "Send engangskode"
                )}
              </Button>
            </form>
          ) : (
            <div className="space-y-6">
              <button
                type="button"
                onClick={handleBackToInput}
                className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                Tilbake
              </button>
              
              <div className="space-y-4">
                <Label className="text-sm font-medium">
                  Engangskode
                </Label>
                <div className="flex justify-center">
                  <InputOTP
                    maxLength={6}
                    value={otp}
                    onChange={setOtp}
                    disabled={verifyingOtp}
                  >
                    <InputOTPGroup>
                      <InputOTPSlot index={0} />
                      <InputOTPSlot index={1} />
                      <InputOTPSlot index={2} />
                      <InputOTPSlot index={3} />
                      <InputOTPSlot index={4} />
                      <InputOTPSlot index={5} />
                    </InputOTPGroup>
                  </InputOTP>
                </div>
                <p className="text-xs text-muted-foreground text-center">
                  Koden ble sendt til {email}
                </p>
              </div>

              <Button
                onClick={handleVerifyOtp}
                className="w-full h-12 rounded-xl gradient-primary text-base font-medium shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 transition-all duration-300"
                disabled={verifyingOtp || otp.length !== 6}
              >
                {verifyingOtp ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Verifiserer...
                  </>
                ) : (
                  "Logg inn"
                )}
              </Button>

              <button
                type="button"
                onClick={(e) => {
                  e.preventDefault();
                  handleSendOtp(e as any);
                }}
                disabled={sendingOtp}
                className="w-full text-sm text-primary hover:text-primary/80 font-medium transition-colors"
              >
                {sendingOtp ? "Sender..." : "Send ny kode"}
              </button>
            </div>
          )}

          {/* Footer links */}
          <div className="mt-10 pt-6 border-t border-border/50">
            <p className="text-center text-sm text-muted-foreground">
              Har du ikke tilgang?{" "}
              <Link to="/signup" className="text-primary hover:underline font-medium">
                Kontakt din leder
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
