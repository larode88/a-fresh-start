import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { getISOWeek, getISOWeekYear } from "date-fns";
import { Button } from "@/components/ui/button";
import { KPICard } from "@/components/dashboard/KPICard";
import { TeamPerformanceTable } from "@/components/team/TeamPerformanceTable";
import { TeamTrendsChart } from "@/components/team/TeamTrendsChart";
import { WeekSelector } from "@/components/WeekSelector";
import { Building2, ClipboardList } from "lucide-react";
import { DollarSign, TrendingUp, Users, Clock } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { NavLink } from "@/components/NavLink";
import { AppLayout } from "@/components/AppLayout";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface SalonKPIs {
  total_revenue: number;
  addon_share_percent: number;
  rebooking_percent: number;
  efficiency_percent: number;
}

interface Salon {
  id: string;
  name: string;
  district_name?: string;
}

const TeamDashboard = () => {
  const navigate = useNavigate();
  const { user, profile, loading } = useAuth();
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [salonKPIs, setSalonKPIs] = useState<SalonKPIs | null>(null);
  const [loadingKPIs, setLoadingKPIs] = useState(true);
  const [salons, setSalons] = useState<Salon[]>([]);
  const [selectedSalonId, setSelectedSalonId] = useState<string | null>(null);

  const canSelectSalon = profile?.role === 'admin' || profile?.role === 'district_manager';
  const canBatchRegister = ['salon_owner', 'daglig_leder', 'avdelingsleder', 'admin'].includes(profile?.role || '');

  useEffect(() => {
    if (!loading && !user) {
      navigate("/login");
      return;
    }

    if (!loading && profile) {
      const allowedRoles = ['salon_owner', 'district_manager', 'admin'];
      if (!allowedRoles.includes(profile.role)) {
        toast({
          title: "Ingen tilgang",
          description: "Du har ikke tilgang til team dashboard",
          variant: "destructive",
        });
        navigate("/dashboard");
      }
    }
  }, [user, profile, loading, navigate]);

  useEffect(() => {
    const fetchSalons = async () => {
      if (!profile) return;

      try {
        if (profile.role === 'admin') {
          const { data, error } = await supabase
            .from('salons')
            .select('id, name, districts(name)')
            .order('name');
          
          if (error) throw error;
          setSalons((data || []).map(s => ({
            id: s.id,
            name: s.name,
            district_name: (s.districts as any)?.name || undefined
          })));
        } else if (profile.role === 'district_manager' && profile.district_id) {
          const { data, error } = await supabase
            .from('salons')
            .select('id, name, districts(name)')
            .eq('district_id', profile.district_id)
            .order('name');
          
          if (error) throw error;
          setSalons((data || []).map(s => ({
            id: s.id,
            name: s.name,
            district_name: (s.districts as any)?.name || undefined
          })));
        }

        if (profile.salon_id) {
          setSelectedSalonId(profile.salon_id);
        }
      } catch (error) {
        console.error('Error fetching salons:', error);
      }
    };

    fetchSalons();
  }, [profile]);

  const activeSalonId = canSelectSalon && selectedSalonId ? selectedSalonId : profile?.salon_id;

  useEffect(() => {
    const fetchSalonKPIs = async () => {
      if (!activeSalonId) {
        setLoadingKPIs(false);
        setSalonKPIs(null);
        return;
      }

      try {
        setLoadingKPIs(true);
        const year = getISOWeekYear(selectedDate);
        const weekNumber = getISOWeek(selectedDate);

        const { data, error } = await supabase
          .from("weekly_kpis")
          .select("*")
          .eq("salon_id", activeSalonId)
          .eq("year", year)
          .eq("week", weekNumber);

        if (error) throw error;

        if (data && data.length > 0) {
          const aggregated = data.reduce(
            (acc, curr) => ({
              total_revenue: acc.total_revenue + Number(curr.total_revenue),
              addon_share_percent: acc.addon_share_percent + Number(curr.addon_share_percent),
              rebooking_percent: acc.rebooking_percent + Number(curr.rebooking_percent),
              efficiency_percent: acc.efficiency_percent + Number(curr.efficiency_percent),
            }),
            { total_revenue: 0, addon_share_percent: 0, rebooking_percent: 0, efficiency_percent: 0 }
          );

          const count = data.length;
          setSalonKPIs({
            total_revenue: aggregated.total_revenue,
            addon_share_percent: aggregated.addon_share_percent / count,
            rebooking_percent: aggregated.rebooking_percent / count,
            efficiency_percent: aggregated.efficiency_percent / count,
          });
        } else {
          setSalonKPIs(null);
        }
      } catch (error) {
        console.error("Error fetching salon KPIs:", error);
        toast({
          title: "Feil",
          description: "Kunne ikke laste KPI-data",
          variant: "destructive",
        });
      } finally {
        setLoadingKPIs(false);
      }
    };

    fetchSalonKPIs();
  }, [activeSalonId, selectedDate]);

  if (loading || loadingKPIs) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Laster...</p>
        </div>
      </div>
    );
  }

  return (
    <AppLayout title="Team Dashboard" subtitle="Oversikt over teamets prestasjon">
      <div className="container mx-auto px-4 py-8">
        {/* Controls */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 mb-8">
          {canSelectSalon && salons.length > 0 && (
            <Select
              value={selectedSalonId || ""}
              onValueChange={setSelectedSalonId}
            >
              <SelectTrigger className="w-[280px]">
                <Building2 className="w-4 h-4 mr-2" />
                <SelectValue placeholder="Velg salong" />
              </SelectTrigger>
              <SelectContent>
                {salons.map((salon) => (
                  <SelectItem key={salon.id} value={salon.id}>
                    <span>{salon.name}</span>
                    {salon.district_name && (
                      <span className="ml-2 text-muted-foreground text-xs">
                        ({salon.district_name})
                      </span>
                    )}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
          <WeekSelector
            selectedDate={selectedDate}
            onDateChange={setSelectedDate}
          />
          {canBatchRegister && (
            <NavLink to="/batch-kpi-input">
              <Button variant="default" size="sm">
                <ClipboardList className="w-4 h-4 mr-2" />
                Batch-registrering
              </Button>
            </NavLink>
          )}
        </div>

        {!activeSalonId && canSelectSalon ? (
          <div className="text-center py-12">
            <Building2 className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h2 className="text-lg font-semibold mb-2">Velg en salong</h2>
            <p className="text-muted-foreground">
              Velg en salong fra listen for å se teamets KPIer
            </p>
          </div>
        ) : (
          <>
            {/* Aggregated KPI Cards */}
            <div className="mb-8">
              <h2 className="text-lg font-semibold mb-4 text-foreground">
                {salons.find(s => s.id === activeSalonId)?.name || "Salongens"} KPIer
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <KPICard
                  title="Total Omsetning"
                  value={salonKPIs ? Math.round(salonKPIs.total_revenue).toLocaleString() : "0"}
                  subtitle="kr"
                  icon={DollarSign}
                  variant="info"
                />
                <KPICard
                  title="Merbehandlingsandel"
                  value={salonKPIs ? Math.round(salonKPIs.addon_share_percent) : "0"}
                  subtitle="%"
                  icon={TrendingUp}
                  variant="success"
                />
                <KPICard
                  title="Rebooking"
                  value={salonKPIs ? Math.round(salonKPIs.rebooking_percent) : "0"}
                  subtitle="%"
                  icon={Users}
                  variant="success"
                />
                <KPICard
                  title="Effektivitet"
                  value={salonKPIs ? Math.round(salonKPIs.efficiency_percent) : "0"}
                  subtitle="%"
                  icon={Clock}
                  variant="default"
                />
              </div>
            </div>

            {/* Team Performance Table */}
            <div className="mb-8">
              <TeamPerformanceTable salonId={activeSalonId || ""} selectedDate={selectedDate} />
            </div>

            {/* Trends Chart */}
            <div>
              <TeamTrendsChart salonId={activeSalonId || ""} selectedDate={selectedDate} />
            </div>
          </>
        )}
      </div>
    </AppLayout>
  );
};

export default TeamDashboard;
