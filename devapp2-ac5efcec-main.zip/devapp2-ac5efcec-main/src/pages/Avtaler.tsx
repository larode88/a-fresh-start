import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { AppLayout } from '@/components/AppLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  FileText, Send, Check, Clock, Eye, XCircle, 
  Search, Filter, RefreshCw, Download, ExternalLink,
  Building2, Calendar, User
} from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { nb } from 'date-fns/locale';

interface Avtale {
  id: string;
  salon_id: string | null;
  salongnavn: string;
  org_nummer: string;
  kontaktperson_navn: string | null;
  kontaktperson_epost: string | null;
  medlemsniva: string | null;
  signing_status: string;
  sent_at: string | null;
  viewed_at: string | null;
  signed_at: string | null;
  completed_at: string | null;
  signed_pdf_url: string | null;
  created_at: string;
  district_id: string | null;
}

interface AvtaleLogg {
  id: string;
  hendelse: string;
  detaljer: string | null;
  created_at: string;
  utfort_av: string | null;
}

const statusConfig: Record<string, { label: string; color: string; icon: React.ReactNode }> = {
  not_started: { label: 'Utkast', color: 'bg-gray-500', icon: <FileText className="h-3 w-3" /> },
  created: { label: 'Opprettet', color: 'bg-blue-500', icon: <FileText className="h-3 w-3" /> },
  sent: { label: 'Sendt', color: 'bg-yellow-500', icon: <Send className="h-3 w-3" /> },
  viewed: { label: 'Åpnet', color: 'bg-purple-500', icon: <Eye className="h-3 w-3" /> },
  signed: { label: 'Signert', color: 'bg-green-500', icon: <Check className="h-3 w-3" /> },
  completed: { label: 'Fullført', color: 'bg-green-600', icon: <Check className="h-3 w-3" /> },
  cancelled: { label: 'Kansellert', color: 'bg-red-500', icon: <XCircle className="h-3 w-3" /> },
  rejected: { label: 'Avvist', color: 'bg-red-500', icon: <XCircle className="h-3 w-3" /> },
};

export default function Avtaler() {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedAvtale, setSelectedAvtale] = useState<Avtale | null>(null);

  // Fetch user role and district
  const { data: userData } = useQuery({
    queryKey: ['current-user-avtaler'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return null;
      
      const { data } = await supabase
        .from('users')
        .select('id, role, district_id')
        .eq('id', user.id)
        .single();
      
      return data;
    },
  });

  // Fetch avtaler
  const { data: avtaler, isLoading, refetch } = useQuery({
    queryKey: ['avtaler', userData?.district_id, statusFilter],
    queryFn: async () => {
      let query = supabase
        .from('avtaler')
        .select('*')
        .order('created_at', { ascending: false });
      
      // Filter by district for district managers
      if (userData?.role === 'district_manager' && userData.district_id) {
        query = query.eq('district_id', userData.district_id);
      }
      
      if (statusFilter !== 'all') {
        query = query.eq('signing_status', statusFilter);
      }
      
      const { data, error } = await query;
      if (error) throw error;
      return data as Avtale[];
    },
    enabled: !!userData,
  });

  // Fetch logg for selected avtale
  const { data: avtaleLogg } = useQuery({
    queryKey: ['avtale-logg', selectedAvtale?.id],
    queryFn: async () => {
      if (!selectedAvtale) return [];
      
      const { data, error } = await supabase
        .from('avtale_logg')
        .select('*')
        .eq('avtale_id', selectedAvtale.id)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data as AvtaleLogg[];
    },
    enabled: !!selectedAvtale,
  });

  // Filter avtaler by search
  const filteredAvtaler = avtaler?.filter(a => 
    a.salongnavn.toLowerCase().includes(searchTerm.toLowerCase()) ||
    a.org_nummer.includes(searchTerm) ||
    a.kontaktperson_navn?.toLowerCase().includes(searchTerm.toLowerCase())
  ) || [];

  // Stats
  const stats = {
    total: avtaler?.length || 0,
    sent: avtaler?.filter(a => a.signing_status === 'sent').length || 0,
    viewed: avtaler?.filter(a => a.signing_status === 'viewed').length || 0,
    signed: avtaler?.filter(a => ['signed', 'completed'].includes(a.signing_status)).length || 0,
  };

  const handleSendReminder = async (avtale: Avtale) => {
    try {
      const { error } = await supabase.functions.invoke('firma-sign', {
        body: {
          action: 'send_reminder',
          avtale_id: avtale.id,
          user_id: userData?.id,
        },
      });
      
      if (error) throw error;
      toast.success('Påminnelse sendt');
      refetch();
    } catch (error) {
      toast.error('Kunne ikke sende påminnelse');
    }
  };

  const handleDownloadSigned = async (avtale: Avtale) => {
    if (avtale.signed_pdf_url) {
      window.open(avtale.signed_pdf_url, '_blank');
    } else {
      toast.error('Signert dokument ikke tilgjengelig ennå');
    }
  };

  return (
    <AppLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-serif font-semibold text-foreground">Avtaler</h1>
            <p className="text-muted-foreground">
              Pipeline for alle medlemsavtaler og signeringsstatus
            </p>
          </div>
          <Button variant="outline" onClick={() => refetch()}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Oppdater
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="text-2xl font-bold">{stats.total}</div>
              <p className="text-sm text-muted-foreground">Totalt</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-2xl font-bold text-yellow-600">{stats.sent}</div>
              <p className="text-sm text-muted-foreground">Sendt til signering</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-2xl font-bold text-purple-600">{stats.viewed}</div>
              <p className="text-sm text-muted-foreground">Åpnet</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-2xl font-bold text-green-600">{stats.signed}</div>
              <p className="text-sm text-muted-foreground">Signert</p>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <div className="flex gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Søk på salongnavn, org.nummer eller kontaktperson..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[180px]">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Filtrer status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Alle statuser</SelectItem>
              <SelectItem value="not_started">Utkast</SelectItem>
              <SelectItem value="sent">Sendt</SelectItem>
              <SelectItem value="viewed">Åpnet</SelectItem>
              <SelectItem value="signed">Signert</SelectItem>
              <SelectItem value="completed">Fullført</SelectItem>
              <SelectItem value="cancelled">Kansellert</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Avtaler list */}
        <Card>
          <CardHeader>
            <CardTitle>Avtaler ({filteredAvtaler.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-8 text-muted-foreground">Laster avtaler...</div>
            ) : filteredAvtaler.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">Ingen avtaler funnet</div>
            ) : (
              <div className="space-y-3">
                {filteredAvtaler.map((avtale) => {
                  const status = statusConfig[avtale.signing_status] || statusConfig.not_started;
                  
                  return (
                    <div
                      key={avtale.id}
                      className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/30 transition-colors cursor-pointer"
                      onClick={() => setSelectedAvtale(avtale)}
                    >
                      <div className="flex items-center gap-4">
                        <div className={`w-10 h-10 rounded-full ${status.color} flex items-center justify-center text-white`}>
                          {status.icon}
                        </div>
                        <div>
                          <div className="font-medium">{avtale.salongnavn}</div>
                          <div className="text-sm text-muted-foreground flex items-center gap-2">
                            <Building2 className="h-3 w-3" />
                            {avtale.org_nummer}
                            {avtale.kontaktperson_navn && (
                              <>
                                <span className="mx-1">•</span>
                                <User className="h-3 w-3" />
                                {avtale.kontaktperson_navn}
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-3">
                        <Badge variant="secondary" className="gap-1">
                          {status.icon}
                          {status.label}
                        </Badge>
                        
                        {avtale.sent_at && (
                          <div className="text-xs text-muted-foreground flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {format(new Date(avtale.sent_at), 'dd.MM.yyyy', { locale: nb })}
                          </div>
                        )}
                        
                        <div className="flex gap-1">
                          {avtale.signing_status === 'sent' && (
                            <Button 
                              variant="ghost" 
                              size="icon"
                              onClick={(e) => { e.stopPropagation(); handleSendReminder(avtale); }}
                            >
                              <Send className="h-4 w-4" />
                            </Button>
                          )}
                          {['signed', 'completed'].includes(avtale.signing_status) && avtale.signed_pdf_url && (
                            <Button 
                              variant="ghost" 
                              size="icon"
                              onClick={(e) => { e.stopPropagation(); handleDownloadSigned(avtale); }}
                            >
                              <Download className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Detail Sheet */}
      <Sheet open={!!selectedAvtale} onOpenChange={() => setSelectedAvtale(null)}>
        <SheetContent className="w-[500px] sm:max-w-[500px]">
          <SheetHeader>
            <SheetTitle>{selectedAvtale?.salongnavn}</SheetTitle>
          </SheetHeader>
          
          {selectedAvtale && (
            <div className="mt-6 space-y-6">
              {/* Status */}
              <div className="flex items-center gap-3">
                <Badge 
                  variant="secondary" 
                  className={`${statusConfig[selectedAvtale.signing_status]?.color} text-white gap-1`}
                >
                  {statusConfig[selectedAvtale.signing_status]?.icon}
                  {statusConfig[selectedAvtale.signing_status]?.label}
                </Badge>
              </div>

              {/* Info */}
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Organisasjonsnummer</span>
                  <span className="font-medium">{selectedAvtale.org_nummer}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Kontaktperson</span>
                  <span className="font-medium">{selectedAvtale.kontaktperson_navn || '-'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">E-post</span>
                  <span className="font-medium">{selectedAvtale.kontaktperson_epost || '-'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Medlemstype</span>
                  <span className="font-medium capitalize">{selectedAvtale.medlemsniva || '-'}</span>
                </div>
              </div>

              {/* Timestamps */}
              <div className="space-y-2 text-sm border-t pt-4">
                <h4 className="font-medium mb-3">Tidslinje</h4>
                {selectedAvtale.sent_at && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Sendt</span>
                    <span>{format(new Date(selectedAvtale.sent_at), 'dd.MM.yyyy HH:mm', { locale: nb })}</span>
                  </div>
                )}
                {selectedAvtale.viewed_at && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Åpnet</span>
                    <span>{format(new Date(selectedAvtale.viewed_at), 'dd.MM.yyyy HH:mm', { locale: nb })}</span>
                  </div>
                )}
                {selectedAvtale.signed_at && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Signert</span>
                    <span>{format(new Date(selectedAvtale.signed_at), 'dd.MM.yyyy HH:mm', { locale: nb })}</span>
                  </div>
                )}
                {selectedAvtale.completed_at && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Fullført</span>
                    <span>{format(new Date(selectedAvtale.completed_at), 'dd.MM.yyyy HH:mm', { locale: nb })}</span>
                  </div>
                )}
              </div>

              {/* Logg */}
              <div className="border-t pt-4">
                <h4 className="font-medium mb-3">Aktivitetslogg</h4>
                <ScrollArea className="h-[200px]">
                  <div className="space-y-3">
                    {avtaleLogg?.map((logg) => (
                      <div key={logg.id} className="text-sm border-l-2 border-muted pl-3">
                        <div className="font-medium">{logg.hendelse}</div>
                        {logg.detaljer && (
                          <div className="text-muted-foreground">{logg.detaljer}</div>
                        )}
                        <div className="text-xs text-muted-foreground mt-1">
                          {format(new Date(logg.created_at), 'dd.MM.yyyy HH:mm', { locale: nb })}
                        </div>
                      </div>
                    ))}
                    {(!avtaleLogg || avtaleLogg.length === 0) && (
                      <div className="text-muted-foreground text-sm">Ingen aktivitet logget</div>
                    )}
                  </div>
                </ScrollArea>
              </div>

              {/* Actions */}
              <div className="flex gap-2 border-t pt-4">
                {selectedAvtale.signing_status === 'sent' && (
                  <Button 
                    variant="outline" 
                    onClick={() => handleSendReminder(selectedAvtale)}
                    className="flex-1"
                  >
                    <Send className="h-4 w-4 mr-2" />
                    Send påminnelse
                  </Button>
                )}
                {selectedAvtale.signed_pdf_url && (
                  <Button 
                    onClick={() => handleDownloadSigned(selectedAvtale)}
                    className="flex-1"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Last ned signert
                  </Button>
                )}
              </div>
            </div>
          )}
        </SheetContent>
      </Sheet>
    </AppLayout>
  );
}