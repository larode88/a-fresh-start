import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { toast } from "sonner";
import { 
  CheckCircle2, 
  XCircle, 
  Clock, 
  FileSignature, 
  Shield,
  Building2,
  Loader2,
  ArrowRight,
  ArrowLeft,
  Users,
  Lock,
  Plus,
  Trash2,
  AlertCircle
} from "lucide-react";
import haar1ForsikringLogo from "@/assets/haar1-forsikring-logo.png";

interface SelectedEmployee {
  user_id: string;
  name: string;
  personnummer?: string;
}

interface QuoteProduct {
  product_id: string;
  product_name: string;
  price: number;
  quantity: number;
  tier_name?: string;
  arsverk?: number;
  selected_employees?: SelectedEmployee[];
}

interface Quote {
  id: string;
  salon_name: string;
  org_number: string;
  contact_name: string;
  email: string;
  phone: string | null;
  products: QuoteProduct[];
  total_price: number;
  notes: string | null;
  status: string;
  sent_at: string | null;
  accepted_at: string | null;
  expires_at: string | null;
  link_to_fullmakt: string | null;
  salon_address: string | null;
  salon_postal_code: string | null;
  salon_city: string | null;
  district_manager?: {
    name: string;
  };
}

interface PreviousInsurer {
  company: string;
  policy_number: string;
}

export default function QuoteAccept() {
  const { token } = useParams<{ token: string }>();
  const navigate = useNavigate();
  
  const [loading, setLoading] = useState(true);
  const [accepting, setAccepting] = useState(false);
  const [quote, setQuote] = useState<Quote | null>(null);
  const [error, setError] = useState<{ message: string; code: string } | null>(null);
  
  // Multi-step state
  const [step, setStep] = useState(1);
  const [employeePersonnummer, setEmployeePersonnummer] = useState<Record<string, string>>({});
  const [personnummerErrors, setPersonnummerErrors] = useState<Record<string, string>>({});
  
  // Existing insurance state
  const [hasExistingInsurance, setHasExistingInsurance] = useState<string | null>(null);
  const [previousInsurers, setPreviousInsurers] = useState<PreviousInsurer[]>([
    { company: "", policy_number: "" }
  ]);
  
  // Address confirmation state
  const [salonAddress, setSalonAddress] = useState("");
  const [postalCode, setPostalCode] = useState("");
  const [city, setCity] = useState("");

  // Check if quote requires personnummer collection
  const healthProducts = quote?.products.filter(
    p => p.selected_employees && p.selected_employees.length > 0
  ) || [];
  
  const requiresPersonnummer = healthProducts.length > 0;
  
  // Calculate total steps based on conditions
  // Step 1: View quote
  // Step 2: Confirm address
  // Step 3: Personnummer (if health insurance)
  // Step 4: Existing insurance question
  // Step 5: Confirm (or skip to here if no existing insurance)
  const getTotalSteps = () => {
    let steps = 4; // View quote, address, existing insurance question, confirm
    if (requiresPersonnummer) steps += 1;
    return steps;
  };
  
  const totalSteps = getTotalSteps();

  useEffect(() => {
    if (token) {
      fetchQuote();
    }
  }, [token]);

  const fetchQuote = async () => {
    setLoading(true);
    try {
      const { data, error: fetchError } = await supabase.functions.invoke("get-quote-by-token", {
        body: { token }
      });

      if (fetchError) {
        console.error("Error fetching quote:", fetchError);
        setError({ message: "Kunne ikke hente tilbudet", code: "FETCH_ERROR" });
        return;
      }

      if (data.error) {
        setError({ message: data.error, code: data.code });
        if (data.quote) {
          setQuote(data.quote);
        }
        return;
      }

      setQuote(data.quote);
      
      // Initialize address state from quote
      setSalonAddress(data.quote.salon_address || "");
      setPostalCode(data.quote.salon_postal_code || "");
      setCity(data.quote.salon_city || "");
      
      // Initialize personnummer state for health insurance employees
      const initialPersonnummer: Record<string, string> = {};
      data.quote.products.forEach((product: QuoteProduct) => {
        if (product.selected_employees) {
          product.selected_employees.forEach((emp: SelectedEmployee) => {
            initialPersonnummer[emp.user_id] = emp.personnummer || "";
          });
        }
      });
      setEmployeePersonnummer(initialPersonnummer);
      
    } catch (err) {
      console.error("Error:", err);
      setError({ message: "En uventet feil oppstod", code: "UNKNOWN" });
    } finally {
      setLoading(false);
    }
  };

  // Validate personnummer (11 digits)
  const validatePersonnummer = (pnr: string): boolean => {
    return /^\d{11}$/.test(pnr.replace(/\s/g, ""));
  };

  // Check if all personnummer are valid
  const allPersonnummerValid = (): boolean => {
    if (!requiresPersonnummer) return true;
    
    const errors: Record<string, string> = {};
    let allValid = true;

    healthProducts.forEach(product => {
      product.selected_employees?.forEach(emp => {
        const pnr = employeePersonnummer[emp.user_id] || "";
        if (!pnr) {
          errors[emp.user_id] = "Personnummer er påkrevd";
          allValid = false;
        } else if (!validatePersonnummer(pnr)) {
          errors[emp.user_id] = "Personnummer må være 11 siffer";
          allValid = false;
        }
      });
    });

    setPersonnummerErrors(errors);
    return allValid;
  };

  // Validate previous insurers
  const validatePreviousInsurers = (): boolean => {
    if (hasExistingInsurance !== "yes") return true;
    
    const hasValidInsurer = previousInsurers.some(
      insurer => insurer.company.trim() && insurer.policy_number.trim()
    );
    
    if (!hasValidInsurer) {
      toast.error("Vennligst fyll inn minst ett forsikringsselskap og polisenummer");
      return false;
    }
    
    return true;
  };

  // Get current step type
  const getStepType = (stepNum: number): "view" | "address" | "personnummer" | "existing" | "confirm" => {
    if (stepNum === 1) return "view";
    if (stepNum === 2) return "address";
    if (requiresPersonnummer && stepNum === 3) return "personnummer";
    if (stepNum === (requiresPersonnummer ? 4 : 3)) return "existing";
    return "confirm";
  };

  const currentStepType = getStepType(step);
  
  // Validate address
  const validateAddress = (): boolean => {
    if (!salonAddress.trim()) {
      toast.error("Vennligst fyll inn adresse");
      return false;
    }
    if (!postalCode.trim() || !/^\d{4}$/.test(postalCode.trim())) {
      toast.error("Vennligst fyll inn gyldig postnummer (4 siffer)");
      return false;
    }
    if (!city.trim()) {
      toast.error("Vennligst fyll inn sted");
      return false;
    }
    return true;
  };

  const handleNextStep = () => {
    // Validate address step
    if (currentStepType === "address") {
      if (!validateAddress()) {
        return;
      }
    }
    
    // Validate personnummer step
    if (currentStepType === "personnummer") {
      if (!allPersonnummerValid()) {
        toast.error("Vennligst fyll ut alle personnummer korrekt");
        return;
      }
    }
    
    // Validate existing insurance step
    if (currentStepType === "existing") {
      if (!hasExistingInsurance) {
        toast.error("Vennligst velg om du har eksisterende forsikring");
        return;
      }
      if (!validatePreviousInsurers()) {
        return;
      }
    }
    
    setStep(prev => Math.min(prev + 1, totalSteps));
  };

  const handlePrevStep = () => {
    setStep(prev => Math.max(prev - 1, 1));
  };

  const addPreviousInsurer = () => {
    setPreviousInsurers(prev => [...prev, { company: "", policy_number: "" }]);
  };

  const removePreviousInsurer = (index: number) => {
    if (previousInsurers.length > 1) {
      setPreviousInsurers(prev => prev.filter((_, i) => i !== index));
    }
  };

  const updatePreviousInsurer = (index: number, field: keyof PreviousInsurer, value: string) => {
    setPreviousInsurers(prev => prev.map((insurer, i) => 
      i === index ? { ...insurer, [field]: value } : insurer
    ));
  };

  const handleAccept = async () => {
    if (!quote) return;
    
    // Validate personnummer if required
    if (requiresPersonnummer && !allPersonnummerValid()) {
      toast.error("Vennligst fyll ut alle personnummer korrekt");
      setStep(2);
      return;
    }
    
    setAccepting(true);
    try {
      // Build updated products with personnummer
      const updatedProducts = quote.products.map(product => {
        if (product.selected_employees) {
          return {
            ...product,
            selected_employees: product.selected_employees.map(emp => ({
              ...emp,
              personnummer: employeePersonnummer[emp.user_id] || undefined
            }))
          };
        }
        return product;
      });

      const { data, error: acceptError } = await supabase.functions.invoke("accept-quote", {
        body: { 
          token,
          ipAddress: "",
          userAgent: navigator.userAgent,
          updatedProducts,
          hasExistingInsurance: hasExistingInsurance === "yes",
          previousInsurers: hasExistingInsurance === "yes" 
            ? previousInsurers.filter(i => i.company.trim() && i.policy_number.trim())
            : [],
          // Include confirmed address
          confirmedAddress: {
            address: salonAddress.trim(),
            postal_code: postalCode.trim(),
            city: city.trim(),
          }
        }
      });

      if (acceptError) {
        throw new Error("Kunne ikke godkjenne tilbudet");
      }

      if (data.error) {
        if (data.code === "ALREADY_ACCEPTED") {
          toast.info("Du har allerede akseptert dette tilbudet");
          if (hasExistingInsurance === "yes") {
            navigate(`/fullmakt?fromQuote=${quote.id}`);
          } else {
            navigate(`/fullmakt/success?noSignatureRequired=true&quoteId=${quote.id}`);
          }
          return;
        }
        throw new Error(data.error);
      }

      toast.success("Tilbudet er godkjent!");
      
      // If no existing insurance, skip POA and go to success page
      if (hasExistingInsurance === "no") {
        navigate(`/fullmakt/success?noSignatureRequired=true&quoteId=${quote.id}`);
        return;
      }
      
      // Redirect to fullmakt with quote data
      const params = new URLSearchParams({
        fromQuote: quote.id,
        salon_name: quote.salon_name,
        org_number: quote.org_number,
        contact_name: quote.contact_name,
        email: quote.email,
        ...(quote.phone && { phone: quote.phone })
      });
      
      navigate(`/fullmakt?${params.toString()}`);
      
    } catch (err: any) {
      console.error("Error accepting quote:", err);
      toast.error(err.message || "Kunne ikke godkjenne tilbudet");
    } finally {
      setAccepting(false);
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("nb-NO", { maximumFractionDigits: 0 }).format(price);
  };

  const formatDate = (dateStr: string) => {
    return new Date(dateStr).toLocaleDateString("nb-NO", {
      day: "numeric",
      month: "long",
      year: "numeric"
    });
  };

  const calculateProductTotal = (product: QuoteProduct) => {
    if (product.arsverk !== undefined) {
      return product.price * product.arsverk;
    }
    if (product.selected_employees) {
      return product.price * product.selected_employees.length;
    }
    return product.price * product.quantity;
  };

  const getStepLabel = () => {
    switch (currentStepType) {
      case "view": return "Se tilbud";
      case "address": return "Bekreft adresse";
      case "personnummer": return "Fyll inn personnummer";
      case "existing": return "Eksisterende forsikring";
      case "confirm": return "Godkjenn og fullfør";
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-background to-muted/30 flex items-center justify-center p-4">
        <Card className="w-full max-w-2xl">
          <CardHeader className="text-center">
            <Skeleton className="h-12 w-32 mx-auto mb-4" />
            <Skeleton className="h-8 w-48 mx-auto" />
          </CardHeader>
          <CardContent>
            <Skeleton className="h-64 w-full" />
          </CardContent>
        </Card>
      </div>
    );
  }

  // Error states
  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-background to-muted/30 flex items-center justify-center p-4">
        <Card className="w-full max-w-lg">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <img src={haar1ForsikringLogo} alt="Hår1 Forsikring" className="h-16" />
            </div>
            {error.code === "EXPIRED" ? (
              <>
                <Clock className="h-16 w-16 text-orange-500 mx-auto mb-4" />
                <CardTitle>Tilbudet har utløpt</CardTitle>
                <CardDescription className="mt-2">
                  Dette tilbudet er ikke lenger gyldig. Kontakt din distriktsleder for å få et nytt tilbud.
                </CardDescription>
              </>
            ) : error.code === "ALREADY_ACCEPTED" ? (
              <>
                <CheckCircle2 className="h-16 w-16 text-green-500 mx-auto mb-4" />
                <CardTitle>Tilbudet er allerede akseptert</CardTitle>
                <CardDescription className="mt-2">
                  Du har allerede akseptert dette tilbudet.
                  {quote?.link_to_fullmakt ? (
                    " Fullmakten er signert."
                  ) : (
                    " Vennligst fullfør signeringen av fullmakten."
                  )}
                </CardDescription>
              </>
            ) : (
              <>
                <XCircle className="h-16 w-16 text-destructive mx-auto mb-4" />
                <CardTitle>Noe gikk galt</CardTitle>
                <CardDescription className="mt-2">{error.message}</CardDescription>
              </>
            )}
          </CardHeader>
          <CardContent className="text-center">
            {error.code === "ALREADY_ACCEPTED" && quote && !quote.link_to_fullmakt && (
              <Button onClick={() => navigate(`/fullmakt?fromQuote=${quote.id}`)}>
                <FileSignature className="mr-2 h-4 w-4" />
                Fullfør signering
              </Button>
            )}
            {error.code === "EXPIRED" && (
              <p className="text-sm text-muted-foreground">
                📧 forsikring@har1.no | 📞 +47 4000 3345
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!quote) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-background to-muted/30 flex items-center justify-center p-4">
        <Card className="w-full max-w-lg text-center">
          <CardHeader>
            <XCircle className="h-16 w-16 text-destructive mx-auto mb-4" />
            <CardTitle>Tilbud ikke funnet</CardTitle>
            <CardDescription>
              Vi kunne ikke finne dette tilbudet. Kontroller at lenken er riktig.
            </CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  const products = (quote.products as QuoteProduct[]) || [];

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/30 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl shadow-lg">
        <CardHeader className="text-center space-y-4">
          <div className="flex justify-center">
            <img src={haar1ForsikringLogo} alt="Hår1 Forsikring" className="h-16" />
          </div>
          
          {/* Progress indicator */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>Steg {step} av {totalSteps}</span>
              <span>{getStepLabel()}</span>
            </div>
            <Progress value={(step / totalSteps) * 100} className="h-2" />
          </div>

          <div className="space-y-2">
            <Badge variant="secondary" className="mb-2">
              <Shield className="h-3 w-3 mr-1" />
              Forsikringstilbud
            </Badge>
            <CardTitle className="text-2xl font-serif">
              Tilbud til {quote.salon_name}
            </CardTitle>
            <CardDescription className="text-base">
              {currentStepType === "view" && "Gjennomgå tilbudet før du fortsetter"}
              {currentStepType === "personnummer" && "Fyll inn personnummer for helseforsikring"}
              {currentStepType === "existing" && "Har du eksisterende forsikring(er) som skal sies opp?"}
              {currentStepType === "confirm" && "Bekreft og fullfør bestillingen"}
            </CardDescription>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Step 1: View quote */}
          {currentStepType === "view" && (
            <>
              {/* Salon info */}
              <div className="bg-muted/30 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Building2 className="h-4 w-4 text-muted-foreground" />
                  <span className="font-medium">Salonginformasjon</span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>
                    <span className="text-muted-foreground">Org.nummer:</span>
                    <span className="ml-2">{quote.org_number}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Kontakt:</span>
                    <span className="ml-2">{quote.contact_name}</span>
                  </div>
                </div>
              </div>

              {/* Products table */}
              <div>
                <h4 className="font-medium mb-3">Inkluderte forsikringer:</h4>
                <div className="border rounded-lg overflow-hidden">
                  <table className="w-full">
                    <thead className="bg-muted/50">
                      <tr>
                        <th className="text-left p-3 text-sm font-medium">Produkt</th>
                        <th className="text-center p-3 text-sm font-medium">Detaljer</th>
                        <th className="text-right p-3 text-sm font-medium">Pris/år</th>
                      </tr>
                    </thead>
                    <tbody>
                      {products.map((product, idx) => (
                        <tr key={idx} className="border-t">
                          <td className="p-3">
                            {product.product_name}
                            {product.tier_name && (
                              <span className="text-muted-foreground ml-1">({product.tier_name})</span>
                            )}
                          </td>
                          <td className="text-center p-3">
                            {product.arsverk !== undefined 
                              ? `${product.arsverk} årsverk` 
                              : product.selected_employees 
                                ? `${product.selected_employees.length} ansatte`
                                : product.quantity > 1 ? product.quantity : "-"
                            }
                          </td>
                          <td className="text-right p-3">{formatPrice(calculateProductTotal(product))} kr</td>
                        </tr>
                      ))}
                      <tr className="border-t bg-muted/30 font-semibold">
                        <td colSpan={2} className="p-3">Totalpris per år</td>
                        <td className="text-right p-3">{formatPrice(quote.total_price)} kr</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Notes */}
              {quote.notes && (
                <div className="bg-muted/30 rounded-lg p-4">
                  <h4 className="font-medium mb-2">Notater fra din distriktsleder:</h4>
                  <p className="text-sm text-muted-foreground">{quote.notes}</p>
                </div>
              )}

              {/* Expiry warning */}
              {quote.expires_at && (
                <Alert>
                  <Clock className="h-4 w-4" />
                  <AlertTitle>Tilbudet er gyldig til</AlertTitle>
                  <AlertDescription>
                    {formatDate(quote.expires_at)}
                  </AlertDescription>
                </Alert>
              )}
            </>
          )}

          {/* Step 2: Address confirmation */}
          {currentStepType === "address" && (
            <>
              <Alert className="bg-blue-500/10 border-blue-500/30">
                <Building2 className="h-4 w-4 text-blue-600" />
                <AlertTitle>Bekreft salongens adresse</AlertTitle>
                <AlertDescription>
                  Vi trenger riktig adresse for forsikringsdokumentene. Vennligst kontroller og oppdater om nødvendig.
                </AlertDescription>
              </Alert>

              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="salon-address">Adresse *</Label>
                  <Input
                    id="salon-address"
                    type="text"
                    placeholder="Gateadresse"
                    value={salonAddress}
                    onChange={(e) => setSalonAddress(e.target.value)}
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="postal-code">Postnummer *</Label>
                    <Input
                      id="postal-code"
                      type="text"
                      inputMode="numeric"
                      placeholder="0000"
                      maxLength={4}
                      value={postalCode}
                      onChange={(e) => setPostalCode(e.target.value.replace(/\D/g, "").slice(0, 4))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="city">Sted *</Label>
                    <Input
                      id="city"
                      type="text"
                      placeholder="Sted"
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                    />
                  </div>
                </div>
              </div>

              <div className="bg-muted/30 rounded-lg p-4 text-sm">
                <p className="font-medium mb-2">Denne adressen vil bli brukt til:</p>
                <ul className="list-disc list-inside text-muted-foreground space-y-1">
                  <li>Forsikringsdokumenter og poliser</li>
                  <li>Korrespondanse fra forsikringsselskapet</li>
                  <li>Fakturering</li>
                </ul>
              </div>
            </>
          )}

          {/* Step 3: Personnummer collection (only if health insurance with employees) */}
          {currentStepType === "personnummer" && (
            <>
              <Alert className="bg-primary/5 border-primary/20">
                <Lock className="h-4 w-4 text-primary" />
                <AlertTitle>Sikker innsamling av personnummer</AlertTitle>
                <AlertDescription>
                  Personnummer er nødvendig for å registrere helseforsikringen hos forsikringsselskapet. 
                  Informasjonen sendes kryptert og behandles konfidensielt.
                </AlertDescription>
              </Alert>

              {healthProducts.map((product) => (
                <div key={product.product_id} className="space-y-4">
                  <h4 className="font-medium flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    {product.product_name} - Fyll inn personnummer
                  </h4>
                  
                  <div className="space-y-3">
                    {product.selected_employees?.map((emp) => (
                      <div key={emp.user_id} className="border rounded-lg p-4">
                        <Label htmlFor={`pnr-${emp.user_id}`} className="font-medium">
                          {emp.name}
                        </Label>
                        <div className="mt-2">
                          <Input
                            id={`pnr-${emp.user_id}`}
                            type="text"
                            inputMode="numeric"
                            placeholder="11 siffer"
                            maxLength={11}
                            value={employeePersonnummer[emp.user_id] || ""}
                            onChange={(e) => {
                              const value = e.target.value.replace(/\D/g, "").slice(0, 11);
                              setEmployeePersonnummer(prev => ({
                                ...prev,
                                [emp.user_id]: value
                              }));
                              // Clear error when typing
                              if (personnummerErrors[emp.user_id]) {
                                setPersonnummerErrors(prev => ({
                                  ...prev,
                                  [emp.user_id]: ""
                                }));
                              }
                            }}
                            className={personnummerErrors[emp.user_id] ? "border-destructive" : ""}
                          />
                          {personnummerErrors[emp.user_id] && (
                            <p className="text-sm text-destructive mt-1">
                              {personnummerErrors[emp.user_id]}
                            </p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </>
          )}

          {/* Existing insurance question step */}
          {currentStepType === "existing" && (
            <>
              <Alert className="bg-amber-500/10 border-amber-500/30">
                <AlertCircle className="h-4 w-4 text-amber-600" />
                <AlertTitle>Viktig informasjon</AlertTitle>
                <AlertDescription>
                  Hvis du har eksisterende forsikringer som skal sies opp, trenger vi en fullmakt for å gjøre dette på dine vegne.
                  Hvis du ikke har eksisterende forsikringer, kan du hoppe over signeringen.
                </AlertDescription>
              </Alert>

              <div className="space-y-4">
                <Label className="text-base font-medium">
                  Har du eksisterende forsikring(er) som skal sies opp?
                </Label>
                
                <RadioGroup
                  value={hasExistingInsurance || ""}
                  onValueChange={setHasExistingInsurance}
                  className="space-y-3"
                >
                  <div className="flex items-center space-x-3 border rounded-lg p-4 cursor-pointer hover:bg-muted/50 transition-colors">
                    <RadioGroupItem value="yes" id="existing-yes" />
                    <Label htmlFor="existing-yes" className="cursor-pointer flex-1">
                      <span className="font-medium">Ja, jeg har forsikring(er) som skal sies opp</span>
                      <p className="text-sm text-muted-foreground mt-1">
                        Du vil bli bedt om å signere en fullmakt
                      </p>
                    </Label>
                  </div>
                  
                  <div className="flex items-center space-x-3 border rounded-lg p-4 cursor-pointer hover:bg-muted/50 transition-colors">
                    <RadioGroupItem value="no" id="existing-no" />
                    <Label htmlFor="existing-no" className="cursor-pointer flex-1">
                      <span className="font-medium">Nei, jeg har ingen forsikring å si opp</span>
                      <p className="text-sm text-muted-foreground mt-1">
                        Du kan fullføre bestillingen uten signering
                      </p>
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              {/* Previous insurers input */}
              {hasExistingInsurance === "yes" && (
                <div className="space-y-4 pt-4 border-t">
                  <Label className="text-base font-medium">
                    Hvilke forsikringer skal sies opp?
                  </Label>
                  
                  <div className="space-y-3">
                    {previousInsurers.map((insurer, index) => (
                      <div key={index} className="border rounded-lg p-4 space-y-3">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium text-muted-foreground">
                            Forsikring {index + 1}
                          </span>
                          {previousInsurers.length > 1 && (
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              onClick={() => removePreviousInsurer(index)}
                              className="text-destructive hover:text-destructive"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                        
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                          <div>
                            <Label htmlFor={`company-${index}`} className="text-sm">
                              Forsikringsselskap *
                            </Label>
                            <Input
                              id={`company-${index}`}
                              placeholder="F.eks. If, Gjensidige, Tryg"
                              value={insurer.company}
                              onChange={(e) => updatePreviousInsurer(index, "company", e.target.value)}
                              className="mt-1"
                            />
                          </div>
                          <div>
                            <Label htmlFor={`policy-${index}`} className="text-sm">
                              Polisenummer *
                            </Label>
                            <Input
                              id={`policy-${index}`}
                              placeholder="Polisenummer"
                              value={insurer.policy_number}
                              onChange={(e) => updatePreviousInsurer(index, "policy_number", e.target.value)}
                              className="mt-1"
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={addPreviousInsurer}
                    className="w-full"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Legg til flere forsikringer
                  </Button>
                </div>
              )}
            </>
          )}

          {/* Final step: Confirm */}
          {currentStepType === "confirm" && (
            <>
              <div className="bg-primary/5 rounded-lg p-4">
                <h4 className="font-medium mb-2 flex items-center gap-2">
                  <FileSignature className="h-4 w-4" />
                  Hva skjer videre?
                </h4>
                <p className="text-sm text-muted-foreground">
                  {hasExistingInsurance === "yes" ? (
                    "Når du godkjenner tilbudet, blir du sendt til et fullmaktskjema for signering. Fullmakten gir Hår1 rett til å si opp dine eksisterende forsikringer."
                  ) : (
                    "Når du godkjenner tilbudet, er bestillingen fullført. Du trenger ikke signere noen fullmakt siden du ikke har eksisterende forsikringer å si opp."
                  )}
                </p>
              </div>

              {/* Summary */}
              <div className="border rounded-lg p-4">
                <h4 className="font-medium mb-3">Oppsummering</h4>
                <div className="space-y-2 text-sm">
                  {products.map((product, idx) => (
                    <div key={idx} className="flex justify-between">
                      <span>
                        {product.product_name}
                        {product.tier_name && ` (${product.tier_name})`}
                      </span>
                      <span>{formatPrice(calculateProductTotal(product))} kr</span>
                    </div>
                  ))}
                  <div className="flex justify-between pt-2 border-t font-semibold">
                    <span>Totalt per år</span>
                    <span>{formatPrice(quote.total_price)} kr</span>
                  </div>
                </div>
              </div>

              {/* Previous insurers summary if applicable */}
              {hasExistingInsurance === "yes" && previousInsurers.filter(i => i.company.trim()).length > 0 && (
                <div className="border rounded-lg p-4">
                  <h4 className="font-medium mb-3">Forsikringer som skal sies opp</h4>
                  <div className="space-y-2 text-sm">
                    {previousInsurers
                      .filter(i => i.company.trim())
                      .map((insurer, idx) => (
                        <div key={idx} className="flex justify-between">
                          <span>{insurer.company}</span>
                          <span className="text-muted-foreground">{insurer.policy_number}</span>
                        </div>
                      ))}
                  </div>
                </div>
              )}
            </>
          )}

          {/* Navigation buttons */}
          <div className="flex gap-3">
            {step > 1 && (
              <Button variant="outline" onClick={handlePrevStep} className="flex-1">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Tilbake
              </Button>
            )}
            
            {step < totalSteps ? (
              <Button onClick={handleNextStep} className="flex-1">
                Neste
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            ) : (
              <Button 
                onClick={handleAccept}
                disabled={accepting || quote.status !== "sent"}
                className="flex-1"
              >
                {accepting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Godkjenner...
                  </>
                ) : (
                  <>
                    {hasExistingInsurance === "yes" ? "Godkjenn og gå til signering" : "Godkjenn tilbudet"}
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </>
                )}
              </Button>
            )}
          </div>

          {/* Contact info */}
          <p className="text-center text-sm text-muted-foreground">
            Har du spørsmål? Kontakt oss på{" "}
            <a href="mailto:forsikring@har1.no" className="text-primary hover:underline">
              forsikring@har1.no
            </a>
            {" "}eller{" "}
            <a href="tel:+4740003345" className="text-primary hover:underline">
              +47 4000 3345
            </a>
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
