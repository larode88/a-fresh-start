import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { TrendingUp, Phone, Mail, ArrowLeft, Loader2 } from "lucide-react";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";

type ResetMode = "phone" | "email";
type ResetStep = "input" | "otp" | "password";

const ResetPassword = () => {
  const navigate = useNavigate();
  const location = useLocation();
  
  // Determine initial mode from location state or URL
  const initialMode = (location.state as any)?.mode === "phone" ? "phone" : "email";
  const initialPhone = (location.state as any)?.phone || "";
  
  const [mode, setMode] = useState<ResetMode>(initialMode);
  const [step, setStep] = useState<ResetStep>("input");
  
  // Phone flow state
  const [phoneNumber, setPhoneNumber] = useState(initialPhone || "+47");
  const [otp, setOtp] = useState("");
  const [sendingOtp, setSendingOtp] = useState(false);
  const [verifyingOtp, setVerifyingOtp] = useState(false);
  
  // Email flow state (for when coming from email reset link)
  const [isFromEmailLink, setIsFromEmailLink] = useState(false);
  
  // Password state
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Check if we have a valid session from the reset link (email flow)
    supabase.auth.onAuthStateChange((event) => {
      if (event === "PASSWORD_RECOVERY") {
        setIsFromEmailLink(true);
        setStep("password");
        setMode("email");
      }
    });
  }, []);

  const handlePhoneChange = (value: string) => {
    let cleaned = value.replace(/[^\d+]/g, "");
    if (!cleaned.startsWith("+47")) {
      cleaned = "+47" + cleaned.replace(/^\+?47?/, "");
    }
    setPhoneNumber(cleaned.slice(0, 11));
  };

  const validatePhone = (phone: string): boolean => {
    return /^\+47\d{8}$/.test(phone);
  };

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validatePhone(phoneNumber)) {
      toast.error("Telefonnummer må være på formatet +47XXXXXXXX");
      return;
    }
    
    setSendingOtp(true);
    try {
      const { data, error } = await supabase.functions.invoke("send-auth-otp", {
        body: { phone: phoneNumber, type: "password_reset" },
      });
      
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      
      toast.success("Engangskode sendt til telefonen din");
      setStep("otp");
    } catch (error: any) {
      console.error("Error sending OTP:", error);
      toast.error(error.message || "Kunne ikke sende engangskode");
    } finally {
      setSendingOtp(false);
    }
  };

  const handleVerifyOtp = async () => {
    if (otp.length !== 6) {
      toast.error("Vennligst skriv inn hele koden");
      return;
    }
    
    // Just verify OTP, then proceed to password step
    setStep("password");
  };

  const handleResetPasswordWithPhone = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (password !== confirmPassword) {
      toast.error("Passordene matcher ikke");
      return;
    }
    
    if (password.length < 6) {
      toast.error("Passordet må være minst 6 tegn");
      return;
    }

    setLoading(true);

    try {
      const { data, error } = await supabase.functions.invoke("verify-auth-otp", {
        body: { 
          phone: phoneNumber, 
          otp, 
          type: "password_reset",
          newPassword: password,
        },
      });
      
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      
      toast.success("Passordet er oppdatert!");
      navigate("/login");
    } catch (error: any) {
      toast.error(error.message || "Kunne ikke oppdatere passordet");
    } finally {
      setLoading(false);
    }
  };

  const handleResetPasswordWithEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (password !== confirmPassword) {
      toast.error("Passordene matcher ikke");
      return;
    }
    
    if (password.length < 6) {
      toast.error("Passordet må være minst 6 tegn");
      return;
    }

    setLoading(true);

    try {
      const { error } = await supabase.auth.updateUser({
        password: password,
      });

      if (error) throw error;

      toast.success("Passordet er oppdatert!");
      navigate("/login");
    } catch (error: any) {
      toast.error(error.message || "Kunne ikke oppdatere passordet");
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = mode === "email" && isFromEmailLink 
    ? handleResetPasswordWithEmail 
    : handleResetPasswordWithPhone;

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-primary/5 via-accent-light/20 to-info-light/20">
      <Card className="w-full max-w-md p-8 shadow-lg">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full gradient-primary mb-4">
            <TrendingUp className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-foreground mb-2">
            Tilbakestill passord
          </h1>
          <p className="text-muted-foreground">
            {step === "input" && "Velg metode for å tilbakestille passordet"}
            {step === "otp" && "Skriv inn koden du mottok på SMS"}
            {step === "password" && "Skriv inn ditt nye passord"}
          </p>
        </div>

        {/* Mode Toggle - only show on input step and not from email link */}
        {step === "input" && !isFromEmailLink && (
          <div className="flex gap-2 mb-6 p-1 bg-muted/50 rounded-xl">
            <button
              type="button"
              onClick={() => setMode("phone")}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg text-sm font-medium transition-all ${
                mode === "phone"
                  ? "bg-background text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Phone className="w-4 h-4" />
              SMS
            </button>
            <button
              type="button"
              onClick={() => setMode("email")}
              className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg text-sm font-medium transition-all ${
                mode === "email"
                  ? "bg-background text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Mail className="w-4 h-4" />
              E-post
            </button>
          </div>
        )}

        {/* Step: Input (Phone) */}
        {step === "input" && mode === "phone" && (
          <form onSubmit={handleSendOtp} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="phone">Telefonnummer</Label>
              <Input
                id="phone"
                type="tel"
                placeholder="+47XXXXXXXX"
                value={phoneNumber}
                onChange={(e) => handlePhoneChange(e.target.value)}
                required
                disabled={sendingOtp}
                className="font-mono"
              />
              <p className="text-xs text-muted-foreground">
                Vi sender deg en engangskode via SMS
              </p>
            </div>

            <Button
              type="submit"
              className="w-full gradient-primary"
              disabled={sendingOtp}
              size="lg"
            >
              {sendingOtp ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Sender kode...
                </>
              ) : (
                "Send engangskode"
              )}
            </Button>
          </form>
        )}

        {/* Step: Input (Email) - just info to use email link */}
        {step === "input" && mode === "email" && !isFromEmailLink && (
          <div className="space-y-6 text-center">
            <p className="text-muted-foreground">
              For å tilbakestille passord via e-post, gå til innloggingssiden og klikk "Glemt passord?".
            </p>
            <Button
              onClick={() => navigate("/login")}
              className="w-full"
              variant="outline"
              size="lg"
            >
              Gå til innlogging
            </Button>
          </div>
        )}

        {/* Step: OTP Verification */}
        {step === "otp" && (
          <div className="space-y-6">
            <button
              type="button"
              onClick={() => {
                setStep("input");
                setOtp("");
              }}
              className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              Tilbake
            </button>
            
            <div className="space-y-4">
              <Label>Engangskode</Label>
              <div className="flex justify-center">
                <InputOTP
                  maxLength={6}
                  value={otp}
                  onChange={setOtp}
                  disabled={verifyingOtp}
                >
                  <InputOTPGroup>
                    <InputOTPSlot index={0} />
                    <InputOTPSlot index={1} />
                    <InputOTPSlot index={2} />
                    <InputOTPSlot index={3} />
                    <InputOTPSlot index={4} />
                    <InputOTPSlot index={5} />
                  </InputOTPGroup>
                </InputOTP>
              </div>
              <p className="text-xs text-muted-foreground text-center">
                Koden ble sendt til {phoneNumber}
              </p>
            </div>

            <Button
              onClick={handleVerifyOtp}
              className="w-full gradient-primary"
              disabled={otp.length !== 6}
              size="lg"
            >
              Fortsett
            </Button>

            <button
              type="button"
              onClick={handleSendOtp}
              disabled={sendingOtp}
              className="w-full text-sm text-primary hover:text-primary/80 font-medium transition-colors"
            >
              {sendingOtp ? "Sender..." : "Send ny kode"}
            </button>
          </div>
        )}

        {/* Step: New Password */}
        {step === "password" && (
          <form onSubmit={handleSubmit} className="space-y-6">
            {!isFromEmailLink && (
              <button
                type="button"
                onClick={() => setStep("otp")}
                className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                Tilbake
              </button>
            )}
            
            <div className="space-y-2">
              <Label htmlFor="password">Nytt passord</Label>
              <Input
                id="password"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                disabled={loading}
                minLength={6}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="confirmPassword">Bekreft passord</Label>
              <Input
                id="confirmPassword"
                type="password"
                placeholder="••••••••"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
                disabled={loading}
                minLength={6}
              />
            </div>

            <Button
              type="submit"
              className="w-full gradient-primary"
              disabled={loading}
              size="lg"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Oppdaterer...
                </>
              ) : (
                "Oppdater passord"
              )}
            </Button>
          </form>
        )}

        <div className="mt-6 text-center text-sm">
          <p className="text-muted-foreground">
            <a href="/login" className="text-accent hover:underline font-medium">
              Tilbake til innlogging
            </a>
          </p>
        </div>
      </Card>
    </div>
  );
};

export default ResetPassword;
