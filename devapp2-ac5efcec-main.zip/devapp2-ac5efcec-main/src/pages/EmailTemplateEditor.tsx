import { useState, useEffect, useMemo, useCallback } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useEditorHistory } from "@/hooks/useEditorHistory";
import { useAutosave } from "@/hooks/useAutosave";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { 
  ArrowLeft, 
  Save, 
  Send, 
  Settings,
  Check,
  Loader2,
  User,
  Mail,
  History
} from "lucide-react";
import EmailModulePanel from "@/components/email-templates/EmailModulePanel";
import EmailCanvas from "@/components/email-templates/EmailCanvas";
import EmailCanvasToolbar, { type PreviewMode, type ZoomLevel } from "@/components/email-templates/EmailCanvasToolbar";

import EmailModuleEditor from "@/components/email-templates/EmailModuleEditor";
import EmailSubjectGenerator from "@/components/email-templates/EmailSubjectGenerator";
import EmailVersionHistory from "@/components/email-templates/EmailVersionHistory";
import { DndContext, DragEndEvent, DragOverlay, DragStartEvent, closestCenter, PointerSensor, useSensor, useSensors } from "@dnd-kit/core";
import { arrayMove, SortableContext, verticalListSortingStrategy } from "@dnd-kit/sortable";

// Re-export types from shared module for backward compatibility
import type { EmailModule as EmailModuleType, EmailStructure as EmailStructureType } from "@/lib/emailHtmlGenerator";
export type EmailModule = EmailModuleType;
export type EmailStructure = EmailStructureType;

interface EmailTemplate {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  category: string;
  structure: EmailStructure;
  subject_template: string | null;
  status: string;
  is_system_template: boolean;
  tags: string[];
  created_at: string;
  updated_at: string;
}

interface EditorState {
  structure: EmailStructure;
  subjectTemplate: string;
}

export default function EmailTemplateEditor() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { profile, loading: authLoading } = useAuth();
  
  // Editor history for undo/redo
  const {
    state: editorState,
    set: setEditorState,
    undo,
    redo,
    reset: resetHistory,
    canUndo,
    canRedo,
    historyLength,
  } = useEditorHistory<EditorState>({ structure: { modules: [] }, subjectTemplate: "" });

  const [canvasPreviewMode, setCanvasPreviewMode] = useState<PreviewMode>("desktop");
  const [zoom, setZoom] = useState<ZoomLevel>(100);
  const [showTestDialog, setShowTestDialog] = useState(false);
  const [testEmail, setTestEmail] = useState("");
  const [testRecipientType, setTestRecipientType] = useState<"user" | "manual">("user");
  const [selectedUserId, setSelectedUserId] = useState<string>("");
  const [testVariables, setTestVariables] = useState<Record<string, string>>({});
  const [sendingTest, setSendingTest] = useState(false);
  const [activeModuleId, setActiveModuleId] = useState<string | null>(null);
  const [draggedModule, setDraggedModule] = useState<EmailModule | null>(null);
  const [showSettingsDialog, setShowSettingsDialog] = useState(false);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    })
  );

  // Autosave functionality
  const handleAutosave = useCallback(async (data: EditorState) => {
    const { error } = await supabase
      .from("email_templates")
      .update({
        structure: data.structure as unknown as Record<string, never>,
        subject_template: data.subjectTemplate,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id);
    if (error) throw error;
  }, [id]);

  const { status: autosaveStatus, lastSavedAt, forceSave } = useAutosave({
    data: editorState,
    onSave: handleAutosave,
    interval: 30000,
    enabled: !!id && profile?.role === "admin",
  });

  // Redirect non-admin users
  if (!authLoading && profile?.role !== "admin") {
    navigate("/dashboard");
    return null;
  }

  const { data: template, isLoading } = useQuery({
    queryKey: ["email-template", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("email_templates")
        .select("*")
        .eq("id", id)
        .single();
      if (error) throw error;
      return {
        ...data,
        structure: (data.structure as unknown as EmailStructure) || { modules: [] },
      } as EmailTemplate;
    },
    enabled: !!id && profile?.role === "admin",
  });

  const { data: modules } = useQuery({
    queryKey: ["email-modules"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("email_module_library")
        .select("*")
        .order("is_system_module", { ascending: false })
        .order("name");
      if (error) throw error;
      return data.map((m) => ({
        ...m,
        default_content: (m.default_content as Record<string, unknown>) || {},
        default_styles: (m.default_styles as Record<string, unknown>) || {},
      }));
    },
    enabled: profile?.role === "admin",
  });

  // Fetch users for recipient picker
  const { data: users } = useQuery({
    queryKey: ["admin-users-for-test"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("users")
        .select("id, name, email, role")
        .in("role", ["admin", "district_manager", "salon_owner", "daglig_leder"])
        .order("name");
      if (error) throw error;
      return data;
    },
    enabled: profile?.role === "admin",
  });

  // Extract tokens used in template
  const usedTokens = useMemo(() => {
    const tokenRegex = /\{([^}]+)\}/g;
    const tokens = new Set<string>();
    
    // Check subject
    if (editorState.subjectTemplate) {
      let match;
      while ((match = tokenRegex.exec(editorState.subjectTemplate)) !== null) {
        tokens.add(match[1]);
      }
    }
    
    // Check all modules
    const checkContent = (obj: unknown) => {
      if (typeof obj === 'string') {
        let match;
        tokenRegex.lastIndex = 0;
        while ((match = tokenRegex.exec(obj)) !== null) {
          tokens.add(match[1]);
        }
      } else if (Array.isArray(obj)) {
        obj.forEach(checkContent);
      } else if (typeof obj === 'object' && obj !== null) {
        Object.values(obj).forEach(checkContent);
      }
    };
    
    editorState.structure.modules.forEach(m => checkContent(m.content));
    
    return Array.from(tokens);
  }, [editorState]);

  useEffect(() => {
    if (template) {
      const templateStructure = template.structure as unknown as EmailStructure;
      resetHistory({
        structure: templateStructure || { modules: [] },
        subjectTemplate: template.subject_template || "",
      });
    }
  }, [template, resetHistory]);

  // Initialize test variables when tokens change
  useEffect(() => {
    const newVars: Record<string, string> = {};
    usedTokens.forEach(token => {
      newVars[token] = testVariables[token] || getDefaultTokenValue(token);
    });
    setTestVariables(newVars);
  }, [usedTokens]);

  // Get default value for common tokens
  const getDefaultTokenValue = (token: string): string => {
    const defaults: Record<string, string> = {
      fornavn: "Ola",
      navn: "Ola Nordmann",
      salongnavn: "Eksempel Salong AS",
      org_nummer: "123 456 789",
      dato: new Date().toLocaleDateString("nb-NO"),
      premie: "5 050",
      avtalenummer: "12345678",
      link: "https://har1portalen.no",
      distriktsleder: "Kari Hansen",
      oppstartsdato: new Date().toLocaleDateString("nb-NO"),
    };
    return defaults[token] || "";
  };

  // Check if there are unsaved changes
  const hasChanges = useMemo(() => {
    if (!template) return false;
    const originalStructure = JSON.stringify(template.structure);
    const currentStructure = JSON.stringify(editorState.structure);
    const originalSubject = template.subject_template || "";
    return originalStructure !== currentStructure || originalSubject !== editorState.subjectTemplate;
  }, [template, editorState]);

  const saveMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase
        .from("email_templates")
        .update({
          structure: editorState.structure as unknown as Record<string, never>,
          subject_template: editorState.subjectTemplate,
          updated_at: new Date().toISOString(),
        })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Mal lagret");
      queryClient.invalidateQueries({ queryKey: ["email-template", id] });
    },
    onError: (error) => {
      toast.error("Kunne ikke lagre: " + (error as Error).message);
    },
  });

  const publishMutation = useMutation({
    mutationFn: async () => {
      // Create version snapshot
      const { data: versions } = await supabase
        .from("email_template_versions")
        .select("version_number")
        .eq("template_id", id)
        .order("version_number", { ascending: false })
        .limit(1);

      const nextVersion = (versions?.[0]?.version_number || 0) + 1;

      await supabase.from("email_template_versions").insert([{
        template_id: id,
        version_number: nextVersion,
        structure: editorState.structure as unknown as Record<string, never>,
        subject_template: editorState.subjectTemplate,
        created_by: profile?.id,
      }]);

      // Update template status
      const { error } = await supabase
        .from("email_templates")
        .update({
          status: "published",
          published_at: new Date().toISOString(),
          structure: editorState.structure as unknown as Record<string, never>,
          subject_template: editorState.subjectTemplate,
        })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Mal publisert");
      queryClient.invalidateQueries({ queryKey: ["email-template", id] });
    },
    onError: (error) => {
      toast.error("Kunne ikke publisere: " + (error as Error).message);
    },
  });

  const handleDragStart = (event: DragStartEvent) => {
    const { active } = event;
    const activeData = active.data.current;
    
    if (activeData?.isNew) {
      // Dragging from module panel
      const moduleTemplate = modules?.find((m) => m.type === activeData.type);
      if (moduleTemplate) {
        setDraggedModule({
          id: `new-${Date.now()}`,
          type: moduleTemplate.type,
          content: moduleTemplate.default_content,
          styles: moduleTemplate.default_styles,
        });
      }
    } else {
      // Dragging existing module
      const module = editorState.structure.modules.find((m) => m.id === active.id);
      if (module) {
        setDraggedModule(module);
      }
    }
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    setDraggedModule(null);

    if (!over) return;

    const activeData = active.data.current;

    if (activeData?.isNew) {
      // Adding new module from panel
      const moduleTemplate = modules?.find((m) => m.type === activeData.type);
      if (moduleTemplate) {
        const newModule: EmailModule = {
          id: `module-${Date.now()}`,
          type: moduleTemplate.type,
          content: moduleTemplate.default_content,
          styles: moduleTemplate.default_styles,
        };

        const overIndex = editorState.structure.modules.findIndex((m) => m.id === over.id);
        const newModules = [...editorState.structure.modules];
        
        if (overIndex === -1) {
          newModules.push(newModule);
        } else {
          newModules.splice(overIndex, 0, newModule);
        }

        setEditorState({
          ...editorState,
          structure: { ...editorState.structure, modules: newModules },
        });
        setActiveModuleId(newModule.id);
      }
    } else {
      // Reordering existing modules
      const oldIndex = editorState.structure.modules.findIndex((m) => m.id === active.id);
      const newIndex = editorState.structure.modules.findIndex((m) => m.id === over.id);

      if (oldIndex !== newIndex) {
        setEditorState({
          ...editorState,
          structure: {
            ...editorState.structure,
            modules: arrayMove(editorState.structure.modules, oldIndex, newIndex),
          },
        });
      }
    }
  };

  const handleModuleUpdate = (moduleId: string, updates: Partial<EmailModule>) => {
    setEditorState({
      ...editorState,
      structure: {
        ...editorState.structure,
        modules: editorState.structure.modules.map((m) =>
          m.id === moduleId ? { ...m, ...updates } : m
        ),
      },
    });
  };

  const handleModuleDelete = (moduleId: string) => {
    setEditorState({
      ...editorState,
      structure: {
        ...editorState.structure,
        modules: editorState.structure.modules.filter((m) => m.id !== moduleId),
      },
    });
    if (activeModuleId === moduleId) {
      setActiveModuleId(null);
    }
  };

  const handleModuleDuplicate = (moduleId: string) => {
    const moduleToDuplicate = editorState.structure.modules.find(m => m.id === moduleId);
    if (!moduleToDuplicate) return;
    
    const duplicatedModule: EmailModule = {
      ...moduleToDuplicate,
      id: `module-${Date.now()}`,
      content: { ...moduleToDuplicate.content },
      styles: { ...moduleToDuplicate.styles },
    };
    
    const moduleIndex = editorState.structure.modules.findIndex(m => m.id === moduleId);
    const newModules = [...editorState.structure.modules];
    newModules.splice(moduleIndex + 1, 0, duplicatedModule);
    
    setEditorState({
      ...editorState,
      structure: { ...editorState.structure, modules: newModules },
    });
    setActiveModuleId(duplicatedModule.id);
  };

  const handleModuleMove = (fromIndex: number, toIndex: number) => {
    if (fromIndex === toIndex) return;
    setEditorState({
      ...editorState,
      structure: {
        ...editorState.structure,
        modules: arrayMove(editorState.structure.modules, fromIndex, toIndex),
      },
    });
  };

  const handleSubjectChange = (value: string) => {
    setEditorState({
      ...editorState,
      subjectTemplate: value,
    });
  };

  const handleSendTest = async () => {
    const email = testRecipientType === "user" 
      ? users?.find(u => u.id === selectedUserId)?.email 
      : testEmail;
    
    if (!email) {
      toast.error("Vennligst velg en mottaker eller oppgi en e-postadresse");
      return;
    }

    setSendingTest(true);
    try {
      const { data, error } = await supabase.functions.invoke("send-test-email", {
        body: {
          template_id: id,
          recipient_email: email,
          variables: testVariables,
        },
      });

      if (error) throw error;

      toast.success(data.message || `Test-e-post sendt til ${email}`);
      setShowTestDialog(false);
    } catch (error) {
      console.error("Error sending test email:", error);
      toast.error("Kunne ikke sende test-e-post: " + (error as Error).message);
    } finally {
      setSendingTest(false);
    }
  };

  if (authLoading || isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!template) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-xl font-semibold mb-2">Mal ikke funnet</h1>
          <Button onClick={() => navigate("/admin/email-templates")}>
            Tilbake til maler
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted/30 flex flex-col">
      {/* Header */}
      <header className="bg-background border-b px-4 py-3 flex items-center justify-between sticky top-0 z-50">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate("/admin/email-templates")}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-semibold">{template.name}</h1>
              {template.status === "published" && (
                <Badge className="bg-green-100 text-green-800">Publisert</Badge>
              )}
              {hasChanges && (
                <Badge variant="secondary">Ulagrede endringer</Badge>
              )}
            </div>
            <p className="text-sm text-muted-foreground">{template.slug}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <EmailVersionHistory
            templateId={id!}
            currentStructure={editorState.structure}
            currentSubject={editorState.subjectTemplate}
            onRestore={(structure, subject) => {
              setEditorState({ structure, subjectTemplate: subject });
            }}
          />
          <Button variant="outline" size="sm" onClick={() => setShowSettingsDialog(true)}>
            <Settings className="h-4 w-4 mr-2" />
            Innstillinger
          </Button>
          <Button variant="outline" size="sm" onClick={() => setShowTestDialog(true)}>
            <Send className="h-4 w-4 mr-2" />
            Send test
          </Button>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => saveMutation.mutate()}
            disabled={saveMutation.isPending || !hasChanges}
          >
            {saveMutation.isPending ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Save className="h-4 w-4 mr-2" />
            )}
            Lagre
          </Button>
          <Button 
            size="sm" 
            onClick={() => publishMutation.mutate()}
            disabled={publishMutation.isPending}
          >
            {publishMutation.isPending ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Check className="h-4 w-4 mr-2" />
            )}
            Publiser
          </Button>
        </div>
      </header>

      {/* Subject line editor */}
      <div className="bg-background border-b px-4 py-3">
        <div className="max-w-3xl mx-auto">
          <div className="flex items-center justify-between mb-1">
            <Label htmlFor="subject" className="text-sm text-muted-foreground">
              Emnelinje (bruk {"{variabel}"} for tokens)
            </Label>
            <EmailSubjectGenerator
              emailContent={JSON.stringify(editorState.structure)}
              currentSubject={editorState.subjectTemplate}
              onSubjectSelect={handleSubjectChange}
            />
          </div>
          <Input
            id="subject"
            value={editorState.subjectTemplate}
            onChange={(e) => handleSubjectChange(e.target.value)}
            placeholder="F.eks. Velkommen til Hår1, {fornavn}!"
          />
        </div>
      </div>

      {/* Main editor area - 3-column layout */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <DndContext
          sensors={sensors}
          collisionDetection={closestCenter}
          onDragStart={handleDragStart}
          onDragEnd={handleDragEnd}
        >
          <div className="flex flex-1 overflow-hidden">
            {/* Left panel - Module library */}
            <EmailModulePanel modules={modules || []} />

            {/* Center - Canvas with toolbar */}
            <div className="flex-1 flex flex-col overflow-hidden">
              {/* Canvas toolbar */}
              <EmailCanvasToolbar
                canUndo={canUndo}
                canRedo={canRedo}
                onUndo={undo}
                onRedo={redo}
                historyLength={historyLength}
                previewMode={canvasPreviewMode}
                onPreviewModeChange={setCanvasPreviewMode}
                zoom={zoom}
                onZoomChange={setZoom}
                autosaveStatus={autosaveStatus}
                lastSavedAt={lastSavedAt}
              />

              {/* Canvas area */}
              <div className="flex-1 overflow-auto">
                <SortableContext
                  items={editorState.structure.modules.map((m) => m.id)}
                  strategy={verticalListSortingStrategy}
                >
                  <EmailCanvas
                    modules={editorState.structure.modules}
                    activeModuleId={activeModuleId}
                    onModuleSelect={setActiveModuleId}
                    onModuleUpdate={handleModuleUpdate}
                    onModuleDelete={handleModuleDelete}
                    onModuleDuplicate={handleModuleDuplicate}
                    onModuleMove={handleModuleMove}
                    previewMode={canvasPreviewMode}
                    zoom={zoom}
                  />
                </SortableContext>
              </div>
            </div>

            {/* Drag overlay */}
            <DragOverlay>
              {draggedModule && (
                <div className="bg-background border rounded-lg p-4 shadow-lg opacity-80">
                  <p className="text-sm font-medium">{draggedModule.type}</p>
                </div>
              )}
            </DragOverlay>

            {/* Right panel - Fixed Module Editor */}
            <div className="w-80 border-l bg-background flex flex-col">
              {activeModuleId && editorState.structure.modules.find(m => m.id === activeModuleId) ? (
                <EmailModuleEditor
                  module={editorState.structure.modules.find(m => m.id === activeModuleId)!}
                  onUpdate={(updates) => handleModuleUpdate(activeModuleId, updates)}
                />
              ) : (
                <div className="flex-1 flex items-center justify-center p-6">
                  <div className="text-center text-muted-foreground">
                    <Settings className="h-12 w-12 mx-auto mb-4 opacity-30" />
                    <p className="font-medium">Ingen modul valgt</p>
                    <p className="text-sm mt-1">Klikk på en modul i canvas for å redigere den</p>
                    <div className="text-xs mt-4 space-y-1 text-left bg-muted/50 rounded-lg p-3">
                      <p><kbd className="px-1.5 py-0.5 bg-muted rounded text-[10px]">↑↓</kbd> Naviger mellom moduler</p>
                      <p><kbd className="px-1.5 py-0.5 bg-muted rounded text-[10px]">Alt+↑↓</kbd> Flytt modul</p>
                      <p><kbd className="px-1.5 py-0.5 bg-muted rounded text-[10px]">Ctrl+Z</kbd> Angre</p>
                      <p><kbd className="px-1.5 py-0.5 bg-muted rounded text-[10px]">Ctrl+D</kbd> Dupliser</p>
                      <p><kbd className="px-1.5 py-0.5 bg-muted rounded text-[10px]">Del</kbd> Slett modul</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </DndContext>
      </div>


      {/* Test Email Dialog */}
      <Dialog open={showTestDialog} onOpenChange={setShowTestDialog}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Send test-e-post</DialogTitle>
            <DialogDescription>
              Send en forhåndsvisning av denne malen med eksempelverdier.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            {/* Recipient selection */}
            <div className="space-y-3">
              <Label className="text-sm font-medium">Mottaker</Label>
              <Tabs value={testRecipientType} onValueChange={(v) => setTestRecipientType(v as "user" | "manual")}>
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="user" className="flex items-center gap-2">
                    <User className="h-4 w-4" />
                    Velg bruker
                  </TabsTrigger>
                  <TabsTrigger value="manual" className="flex items-center gap-2">
                    <Mail className="h-4 w-4" />
                    Skriv e-post
                  </TabsTrigger>
                </TabsList>
              </Tabs>
              
              {testRecipientType === "user" ? (
                <Select value={selectedUserId} onValueChange={setSelectedUserId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Velg en bruker..." />
                  </SelectTrigger>
                  <SelectContent>
                    {users?.map(user => (
                      <SelectItem key={user.id} value={user.id}>
                        <div className="flex flex-col">
                          <span>{user.name}</span>
                          <span className="text-xs text-muted-foreground">{user.email}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              ) : (
                <Input
                  type="email"
                  value={testEmail}
                  onChange={(e) => setTestEmail(e.target.value)}
                  placeholder="din@epost.no"
                />
              )}
            </div>

            {/* Token values */}
            {usedTokens.length > 0 && (
              <div className="space-y-3">
                <Label className="text-sm font-medium">
                  Testverdier for tokens ({usedTokens.length})
                </Label>
                <ScrollArea className="h-[200px] rounded-md border p-3">
                  <div className="space-y-3">
                    {usedTokens.map(token => (
                      <div key={token} className="space-y-1">
                        <Label className="text-xs text-muted-foreground">{`{${token}}`}</Label>
                        <Input
                          value={testVariables[token] || ""}
                          onChange={(e) => setTestVariables(prev => ({ ...prev, [token]: e.target.value }))}
                          placeholder={`Verdi for ${token}`}
                          className="h-8 text-sm"
                        />
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowTestDialog(false)}>
              Avbryt
            </Button>
            <Button onClick={handleSendTest} disabled={sendingTest}>
              {sendingTest ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Send className="h-4 w-4 mr-2" />
              )}
              Send test
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Settings Dialog */}
      <Dialog open={showSettingsDialog} onOpenChange={setShowSettingsDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Malinnstillinger</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Navn</Label>
              <Input value={template.name} disabled />
            </div>
            <div>
              <Label>Slug</Label>
              <Input value={template.slug} disabled />
            </div>
            <div>
              <Label>Kategori</Label>
              <Input value={template.category} disabled />
            </div>
            <div>
              <Label>Beskrivelse</Label>
              <Textarea value={template.description || ""} disabled />
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => setShowSettingsDialog(false)}>
              Lukk
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
