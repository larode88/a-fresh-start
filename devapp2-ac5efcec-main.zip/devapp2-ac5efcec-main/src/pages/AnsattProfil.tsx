import { useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { AppLayout } from "@/components/AppLayout";
import { ArrowLeft, User, Mail, Phone, Calendar, Briefcase, Award, MapPin, Building } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { getAnsattById, type AnsattUtvidet } from "@/integrations/supabase/ansatteService";
import { 
  getStatusColor, 
  getStatusLabel, 
  getFrisorfunksjonLabel, 
  getLederstillingLabel,
  calculateAnsiennitetYears,
  calculateAge
} from "@/lib/ansattUtils";
import { format } from "date-fns";
import { nb } from "date-fns/locale";
import { AnsattStillingssammenligning } from "@/components/ansatte/AnsattStillingssammenligning";

const AnsattProfil = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user, profile, loading: authLoading } = useAuth();

  const canAccess = ['salon_owner', 'daglig_leder', 'avdelingsleder', 'admin', 'district_manager'].includes(profile?.role || '');

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/login");
    }
  }, [user, authLoading, navigate]);

  const { data: ansatt, isLoading, error } = useQuery({
    queryKey: ["ansatt", id],
    queryFn: () => getAnsattById(id!),
    enabled: !!id && !!user,
  });

  if (authLoading || isLoading) {
    return (
      <AppLayout title="Ansattprofil">
        <div className="container mx-auto px-4 py-6">
          <div className="space-y-6">
            <Skeleton className="h-8 w-32" />
            <Skeleton className="h-48 w-full" />
            <Skeleton className="h-64 w-full" />
          </div>
        </div>
      </AppLayout>
    );
  }

  if (error || !ansatt) {
    return (
      <AppLayout title="Ansattprofil">
        <div className="container mx-auto px-4 py-6">
          <div className="text-center py-12">
            <User className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h2 className="text-lg font-semibold mb-2">Ansatt ikke funnet</h2>
            <p className="text-muted-foreground mb-4">
              Kunne ikke finne den forespurte ansatte.
            </p>
            <Button variant="outline" onClick={() => navigate("/ansatte")}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Tilbake til ansatte
            </Button>
          </div>
        </div>
      </AppLayout>
    );
  }

  const getInitials = (fornavn?: string, etternavn?: string) => {
    const first = fornavn?.[0] || "";
    const last = etternavn?.[0] || "";
    return (first + last).toUpperCase() || "?";
  };

  const ansiennitet = ansatt.ansatt_dato 
    ? calculateAnsiennitetYears(ansatt.ansatt_dato, ansatt.fagbrev_dato) 
    : null;

  const age = ansatt.fodselsdato ? calculateAge(ansatt.fodselsdato) : null;

  return (
    <AppLayout 
      title={`${ansatt.fornavn} ${ansatt.etternavn || ''}`}
      subtitle="Ansattprofil"
    >
      <div className="container mx-auto px-4 py-6 space-y-6">
        {/* Back button */}
        <Button variant="ghost" onClick={() => navigate("/ansatte")} className="mb-2">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Tilbake til ansatte
        </Button>

        {/* Profile Header Card */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col sm:flex-row gap-6 items-start sm:items-center">
              <Avatar className="h-24 w-24">
                <AvatarImage src={ansatt.profilbilde_url || undefined} />
                <AvatarFallback className="text-2xl bg-primary/10 text-primary">
                  {getInitials(ansatt.fornavn, ansatt.etternavn)}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1 space-y-2">
                <div className="flex items-center gap-3 flex-wrap">
                  <h1 className="text-2xl font-semibold">
                    {ansatt.fornavn} {ansatt.etternavn}
                  </h1>
                  <Badge 
                    variant="outline" 
                    className={getStatusColor(ansatt.status)}
                  >
                    {getStatusLabel(ansatt.status)}
                  </Badge>
                </div>
                
                <div className="flex flex-wrap gap-2">
                  {ansatt.frisorfunksjon && (
                    <Badge variant="secondary">
                      {getFrisorfunksjonLabel(ansatt.frisorfunksjon)}
                    </Badge>
                  )}
                  {ansatt.lederstilling && (
                    <Badge variant="secondary">
                      {getLederstillingLabel(ansatt.lederstilling)}
                    </Badge>
                  )}
                </div>

                <div className="flex flex-wrap gap-4 text-sm text-muted-foreground pt-2">
                  {ansatt.epost && (
                    <div className="flex items-center gap-1">
                      <Mail className="h-4 w-4" />
                      <a href={`mailto:${ansatt.epost}`} className="hover:text-foreground">
                        {ansatt.epost}
                      </a>
                    </div>
                  )}
                  {ansatt.telefon && (
                    <div className="flex items-center gap-1">
                      <Phone className="h-4 w-4" />
                      <a href={`tel:${ansatt.telefon}`} className="hover:text-foreground">
                        {ansatt.telefon}
                      </a>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Info Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Personal Info */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <User className="h-5 w-5" />
                Personlig informasjon
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <InfoRow label="Fornavn" value={ansatt.fornavn} />
              <InfoRow label="Etternavn" value={ansatt.etternavn} />
              <InfoRow label="Fødselsdato" value={
                ansatt.fodselsdato 
                  ? `${format(new Date(ansatt.fodselsdato), "d. MMMM yyyy", { locale: nb })}${age ? ` (${age} år)` : ''}`
                  : null
              } />
              <InfoRow label="Kjønn" value={ansatt.kjonn} />
              <InfoRow label="Nasjonalitet" value={ansatt.nasjonalitet} />
              
              <Separator />
              
              {ansatt.adresse && (
                <div className="flex items-start gap-2 text-sm">
                  <MapPin className="h-4 w-4 mt-0.5 text-muted-foreground" />
                  <div>
                    <p>{ansatt.adresse}</p>
                    {(ansatt.postnummer || ansatt.poststed) && (
                      <p>{ansatt.postnummer} {ansatt.poststed}</p>
                    )}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Employment Info */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Briefcase className="h-5 w-5" />
                Ansettelsesforhold
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <InfoRow label="Ansattdato" value={
                ansatt.ansatt_dato 
                  ? format(new Date(ansatt.ansatt_dato), "d. MMMM yyyy", { locale: nb })
                  : null
              } />
              <InfoRow label="Stillingsprosent" value={
                ansatt.stillingsprosent != null ? `${ansatt.stillingsprosent}%` : null
              } />
              <InfoRow label="Arbeidstid per uke" value={
                ansatt.arbeidstid_per_uke != null ? `${ansatt.arbeidstid_per_uke} timer` : null
              } />
              <InfoRow label="Arbeidsdager per uke" value={
                ansatt.arbeidsdager_pr_uke != null ? `${ansatt.arbeidsdager_pr_uke} dager` : null
              } />
              <InfoRow label="Ansiennitet" value={
                ansiennitet != null ? `${ansiennitet.toFixed(1)} år` : null
              } />
              
              <Separator />
              
              <InfoRow label="Prøvetid til" value={
                ansatt.provetid_til 
                  ? format(new Date(ansatt.provetid_til), "d. MMMM yyyy", { locale: nb })
                  : null
              } />
              {ansatt.oppsigelsesdato && (
                <InfoRow label="Oppsigelsesdato" value={
                  format(new Date(ansatt.oppsigelsesdato), "d. MMMM yyyy", { locale: nb })
                } className="text-destructive" />
              )}
            </CardContent>
          </Card>

          {/* Stilling vs. Turnus sammenligning */}
          {ansatt.salong_id && (
            <AnsattStillingssammenligning
              ansattId={ansatt.id}
              salongId={ansatt.salong_id}
              avtaltStillingsprosent={ansatt.stillingsprosent || 100}
            />
          )}

          {/* Competence */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Award className="h-5 w-5" />
                Kompetanse
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <InfoRow label="Utdanning/Fagbrev" value={ansatt.utdanning_fagbrev} />
              <InfoRow label="Fagbrevdato" value={
                ansatt.fagbrev_dato 
                  ? format(new Date(ansatt.fagbrev_dato), "d. MMMM yyyy", { locale: nb })
                  : null
              } />
              {ansatt.kurs_sertifiseringer && (
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Kurs og sertifiseringer</p>
                  <p className="text-sm">{ansatt.kurs_sertifiseringer}</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Salary Info (only for those with access) */}
          {canAccess && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Building className="h-5 w-5" />
                  Lønnsinfo
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <InfoRow label="Lønnstype" value={ansatt.lonnstype_enum} />
                {ansatt.fastlonn != null && (
                  <InfoRow label="Fastlønn" value={`kr ${ansatt.fastlonn.toLocaleString("nb-NO")}`} />
                )}
                {ansatt.timesats != null && (
                  <InfoRow label="Timesats" value={`kr ${ansatt.timesats.toLocaleString("nb-NO")}`} />
                )}
                
                <Separator />
                
                <InfoRow label="Provisjon behandling" value={
                  ansatt.provisjon_behandling_prosent != null 
                    ? `${ansatt.provisjon_behandling_prosent}%` 
                    : null
                } />
                <InfoRow label="Provisjon vare" value={
                  ansatt.provisjon_vare_prosent != null 
                    ? `${ansatt.provisjon_vare_prosent}%` 
                    : null
                } />
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </AppLayout>
  );
};

// Helper component for info rows
function InfoRow({ 
  label, 
  value, 
  className 
}: { 
  label: string; 
  value: string | null | undefined;
  className?: string;
}) {
  if (!value) return null;
  
  return (
    <div className={`flex justify-between text-sm ${className || ''}`}>
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium">{value}</span>
    </div>
  );
}

export default AnsattProfil;
