// EmployeesPage - HR module page for managing employees
// This is a minimal compilable React + TypeScript page

import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { Users } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { EmployeeList } from "@/components/hr/EmployeeList";
import { useSalonContext } from "@/components/SalonSelector";
import { AppLayout } from "@/components/AppLayout";

const EmployeesPage = () => {
  const navigate = useNavigate();
  const { user, profile, loading } = useAuth();
  const { selectedSalonId } = useSalonContext();

  const canAccess = ['salon_owner', 'daglig_leder', 'avdelingsleder', 'admin', 'district_manager'].includes(profile?.role || '');

  useEffect(() => {
    if (!loading && !user) {
      navigate("/login");
      return;
    }

    if (!loading && profile && !canAccess) {
      toast({
        title: "Ingen tilgang",
        description: "Du har ikke tilgang til ansattoversikten",
        variant: "destructive",
      });
      navigate("/dashboard");
    }
  }, [user, profile, loading, navigate, canAccess]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Laster...</p>
        </div>
      </div>
    );
  }

  const activeSalonId = selectedSalonId || profile?.salon_id;

  return (
    <AppLayout title="Ansatte" subtitle="HR - Administrer ansatte, ferie, fravær og samtaler">
      <div className="container mx-auto px-4 py-8">
        {!activeSalonId ? (
          <div className="text-center py-12">
            <Users className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h2 className="text-lg font-semibold mb-2">Velg en salong</h2>
            <p className="text-muted-foreground">
              Velg en salong for å se ansatte
            </p>
          </div>
        ) : (
          <EmployeeList salonId={activeSalonId} />
        )}
      </div>
    </AppLayout>
  );
};

export default EmployeesPage;
