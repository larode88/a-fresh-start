import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useSalonContext } from "@/components/SalonSelector";
import { useQuery } from "@tanstack/react-query";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  MessageSquare, Activity, Bell, Target, User, AlertTriangle,
  Calendar, Users, CheckCircle2, Clock, AlertCircle, ChevronLeft, ChevronRight 
} from "lucide-react";
import { EmployeeKPIConfig } from "@/components/employees/EmployeeKPIConfig";
import { AppLayout } from "@/components/AppLayout";
import { MedarbeidersamtalePlanlegger } from "@/components/utvikling/MedarbeidersamtalePlanlegger";
import { PulsundersokelsePlanlegger } from "@/components/utvikling/PulsundersokelsePlanlegger";
import { AksjonspunktOversikt } from "@/components/utvikling/AksjonspunktOversikt";
import { PaminnelserPanel } from "@/components/utvikling/PaminnelserPanel";

interface SamtaleStats {
  planlagt: number;
  venter_forberedelse: number;
  pagaende: number;
  fullfort: number;
}

export default function UtviklingDashboard() {
  const { user, profile, loading: authLoading } = useAuth();
  const role = profile?.role;
  const { salons, selectedSalonId, setSelectedSalonId, loading: salonLoading, canSelectSalon } = useSalonContext();

  const [stats, setStats] = useState<SamtaleStats>({ planlagt: 0, venter_forberedelse: 0, pagaende: 0, fullfort: 0 });
  const [unreadNotifications, setUnreadNotifications] = useState(0);

  const [selectedYear, setSelectedYear] = useState<number>(new Date().getFullYear());
  const [selectedAnsatt, setSelectedAnsatt] = useState<{
    id: string;
    navn: string;
    user_id: string | null;
  } | null>(null);
  
  // Fetch ansatte for KPI tab
  const { data: ansatte, isLoading: ansatteLoading } = useQuery({
    queryKey: ['kpi-ansatte', selectedSalonId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('ansatte')
        .select('id, fornavn, etternavn, user_id, frisorfunksjon, status')
        .eq('salong_id', selectedSalonId!)
        .neq('status', 'Arkivert')
        .order('fornavn');
      if (error) throw error;
      return data;
    },
    enabled: !!selectedSalonId,
  });
  
  const canManage = ["admin", "salon_owner", "daglig_leder", "avdelingsleder"].includes(role || "");
  
  const currentYear = new Date().getFullYear();
  const years = [currentYear - 1, currentYear, currentYear + 1];

  useEffect(() => {
    const fetchStats = async () => {
      if (!selectedSalonId) return;

      try {
        const { data: samtaler, error } = await supabase
          .from("ansatt_samtaler")
          .select("status")
          .eq("salon_id", selectedSalonId);

        if (error) throw error;

        const newStats = {
          planlagt: samtaler?.filter(s => s.status === "planlagt").length || 0,
          venter_forberedelse: samtaler?.filter(s => s.status === "forberedelse").length || 0,
          pagaende: samtaler?.filter(s => s.status === "gjennomfores").length || 0,
          fullfort: samtaler?.filter(s => s.status === "fullfort").length || 0,
        };
        setStats(newStats);

        // Fetch unread notifications
        const { count } = await supabase
          .from("medarbeidersamtale_paminnelser")
          .select("*", { count: "exact", head: true })
          .eq("lest", false)
          .or(`ansatt_id.eq.${user?.id},leder_id.eq.${user?.id}`);

        setUnreadNotifications(count || 0);
      } catch (error) {
        console.error("Error fetching stats:", error);
      }
    };

    fetchStats();
  }, [selectedSalonId, user?.id]);

  if (authLoading || salonLoading) {
    return (
      <div className="container mx-auto p-6 space-y-6">
        <Skeleton className="h-10 w-48" />
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-24" />)}
        </div>
        <Skeleton className="h-96" />
      </div>
    );
  }

  return (
    <AppLayout title="Medarbeiderutvikling" subtitle="Samtaler, pulsundersøkelser og oppfølging">
      <div className="container mx-auto p-6 space-y-6">
        {/* Header med år-velger og varsler */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Calendar className="h-4 w-4 text-muted-foreground" />
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8"
              onClick={() => setSelectedYear(y => y - 1)}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Select value={selectedYear.toString()} onValueChange={(v) => setSelectedYear(parseInt(v))}>
              <SelectTrigger className="w-[100px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {years.map(year => (
                  <SelectItem key={year} value={year.toString()}>
                    {year}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8"
              onClick={() => setSelectedYear(y => y + 1)}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
          
          <Button variant="outline" className="relative">
            <Bell className="h-4 w-4" />
            {unreadNotifications > 0 && (
              <Badge 
                variant="destructive" 
                className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center p-0 text-xs"
              >
                {unreadNotifications}
              </Badge>
            )}
          </Button>
        </div>

        {/* Statistikk-kort */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardDescription className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                Planlagte
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.planlagt}</div>
              <p className="text-xs text-muted-foreground">samtaler</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardDescription className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                Venter forberedelse
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.venter_forberedelse}</div>
              <p className="text-xs text-muted-foreground">medarbeidere</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardDescription className="flex items-center gap-2">
                <AlertCircle className="h-4 w-4" />
                Pågående
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.pagaende}</div>
              <p className="text-xs text-muted-foreground">samtaler</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardDescription className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4" />
                Fullført
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.fullfort}</div>
              <p className="text-xs text-muted-foreground">denne perioden</p>
            </CardContent>
          </Card>
        </div>

        {!selectedSalonId ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Users className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground">Velg en salong for å se medarbeiderutvikling</p>
            </CardContent>
          </Card>
        ) : (
          <Tabs defaultValue="samtaler" className="space-y-4">
            <TabsList>
              <TabsTrigger value="samtaler" className="flex items-center gap-2">
                <MessageSquare className="h-4 w-4" />
                Samtaler
              </TabsTrigger>
              <TabsTrigger value="puls" className="flex items-center gap-2">
                <Activity className="h-4 w-4" />
                Pulsundersøkelser
              </TabsTrigger>
            <TabsTrigger value="team" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Team-oversikt
            </TabsTrigger>
            <TabsTrigger value="oppgaver" className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4" />
              Mine oppgaver
              {unreadNotifications > 0 && (
                <Badge variant="destructive" className="ml-1 h-5 w-5 flex items-center justify-center p-0 text-xs">
                  {unreadNotifications}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="kpi" className="flex items-center gap-2">
              <Target className="h-4 w-4" />
              KPI-mål
            </TabsTrigger>
            </TabsList>

            <TabsContent value="samtaler">
              <MedarbeidersamtalePlanlegger 
                salonId={selectedSalonId}
                userId={canManage ? undefined : user?.id}
                canManage={canManage}
              />
            </TabsContent>

            <TabsContent value="puls">
              <PulsundersokelsePlanlegger 
                salonId={selectedSalonId}
                canManage={canManage}
              />
            </TabsContent>

            <TabsContent value="team">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5" />
                    Team-oversikt
                  </CardTitle>
                  <CardDescription>
                    Se status på samtaler og pulsundersøkelser for hele teamet
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card className="bg-muted/30">
                      <CardContent className="pt-4">
                        <div className="text-2xl font-bold">{stats.planlagt + stats.venter_forberedelse}</div>
                        <p className="text-sm text-muted-foreground">Kommende samtaler</p>
                      </CardContent>
                    </Card>
                    <Card className="bg-muted/30">
                      <CardContent className="pt-4">
                        <div className="text-2xl font-bold">{stats.fullfort}</div>
                        <p className="text-sm text-muted-foreground">Fullførte samtaler</p>
                      </CardContent>
                    </Card>
                    <Card className="bg-muted/30">
                      <CardContent className="pt-4">
                        <div className="text-2xl font-bold">
                          {stats.planlagt + stats.venter_forberedelse + stats.pagaende + stats.fullfort > 0
                            ? Math.round((stats.fullfort / (stats.planlagt + stats.venter_forberedelse + stats.pagaende + stats.fullfort)) * 100)
                            : 0}%
                        </div>
                        <p className="text-sm text-muted-foreground">Gjennomføringsgrad</p>
                      </CardContent>
                    </Card>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="oppgaver">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <AksjonspunktOversikt 
                  salonId={selectedSalonId}
                  userId={canManage ? undefined : user?.id}
                  canManage={canManage}
                />
                <PaminnelserPanel userId={user?.id || ""} />
              </div>
            </TabsContent>

            <TabsContent value="kpi">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-5 w-5" />
                    KPI-mål for ansatte
                  </CardTitle>
                  <CardDescription>
                    Sett individuelle KPI-mål for hver ansatt
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Ansattliste */}
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-muted-foreground mb-3">Velg ansatt</p>
                      {ansatteLoading ? (
                        <div className="space-y-2">
                          {[1, 2, 3].map(i => <Skeleton key={i} className="h-12" />)}
                        </div>
                      ) : ansatte && ansatte.length > 0 ? (
                        <div className="space-y-1">
                          {ansatte.map((a) => (
                            <button
                              key={a.id}
                              onClick={() => setSelectedAnsatt({
                                id: a.id,
                                navn: `${a.fornavn} ${a.etternavn || ''}`.trim(),
                                user_id: a.user_id
                              })}
                              className={`w-full flex items-center gap-3 p-3 rounded-lg text-left transition-colors ${
                                selectedAnsatt?.id === a.id 
                                  ? 'bg-primary text-primary-foreground' 
                                  : 'hover:bg-muted'
                              }`}
                            >
                              <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center">
                                <User className="h-4 w-4" />
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="font-medium truncate">
                                  {a.fornavn} {a.etternavn || ''}
                                </p>
                                <p className={`text-xs ${
                                  selectedAnsatt?.id === a.id 
                                    ? 'text-primary-foreground/70' 
                                    : 'text-muted-foreground'
                                }`}>
                                  {a.frisorfunksjon || 'Ikke angitt'}
                                </p>
                              </div>
                              {!a.user_id && (
                                <AlertTriangle className="h-4 w-4 text-warning" />
                              )}
                            </button>
                          ))}
                        </div>
                      ) : (
                        <p className="text-sm text-muted-foreground">Ingen ansatte funnet</p>
                      )}
                    </div>

                    {/* KPI-konfigurasjon */}
                    <div className="lg:col-span-2">
                      {selectedAnsatt ? (
                        <EmployeeKPIConfig 
                          employeeId={selectedAnsatt.user_id || undefined} 
                          ansattId={selectedAnsatt.id}
                          salonId={selectedSalonId!} 
                        />
                      ) : (
                        <div className="flex flex-col items-center justify-center py-12 text-center">
                          <Target className="h-12 w-12 text-muted-foreground mb-4" />
                          <p className="text-muted-foreground">Velg en ansatt for å se og redigere KPI-mål</p>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        )}
      </div>
    </AppLayout>
  );
}
