import { useState, useEffect, useCallback } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import type { Json } from "@/integrations/supabase/types";
import { Button } from "@/components/ui/button";
import { Loader2, ArrowLeft, Save } from "lucide-react";
import { AppLayout } from "@/components/AppLayout";
import { SamtaleStegNavigator } from "@/components/utvikling/SamtaleStegNavigator";
import { SamtaleStegInnhold } from "@/components/utvikling/SamtaleStegInnhold";
import { SamtaleLederGuide } from "@/components/utvikling/SamtaleLederGuide";
import { SmartMalDialog } from "@/components/utvikling/SmartMalDialog";
import { SamtaleOppgaveDialog } from "@/components/utvikling/SamtaleOppgaveDialog";

export interface StegNotat {
  notat: string;
  oppgaver: string[];
  mal: string[];
}

export interface Samtale {
  id: string;
  user_id: string;
  utfort_av: string;
  samtale_type: string;
  dato: string;
  status: string;
  steg_notater: Record<string, StegNotat>;
  users: { id: string; name: string };
}

export interface Forberedelse {
  utfylt_av_type: string;
  egen_innsats_score?: number;
  egen_innsats_kommentar?: string;
  arbeid_salong_score?: number;
  arbeid_salong_kommentar?: string;
  hjelp_leder_score?: number;
  hjelp_leder_kommentar?: string;
  kompetanse_score?: number;
  kompetanse_kommentar?: string;
  stotte_leder_score?: number;
  stotte_leder_kommentar?: string;
  ferdigheter_utvikle?: string;
  leder_hjelp_mal?: string;
  framtidige_mal?: string;
  andre_tema?: string;
  prestasjoner_score?: number;
  prestasjoner_kommentar?: string;
  styrker?: string;
  forbedringsomrader?: string;
  andre_tema_leder?: string;
}

const STEG = [
  { id: 1, navn: "Intro", ikon: "👋", key: "intro" },
  { id: 2, navn: "Egen innsats", ikon: "💪", key: "egen_innsats" },
  { id: 3, navn: "Arbeid i salongen", ikon: "💇", key: "arbeid_salong" },
  { id: 4, navn: "Hjelp fra leder", ikon: "🤝", key: "hjelp_leder" },
  { id: 5, navn: "Kompetansenivå", ikon: "📚", key: "kompetanse" },
  { id: 6, navn: "Støtte fra leder", ikon: "🫱", key: "stotte_leder" },
  { id: 7, navn: "Ferdigheter å utvikle", ikon: "🎯", key: "ferdigheter" },
  { id: 8, navn: "Leder-hjelp til mål", ikon: "🗺️", key: "leder_hjelp" },
  { id: 9, navn: "Fremtidige mål", ikon: "🚀", key: "framtidige_mal" },
  { id: 10, navn: "Andre tema", ikon: "💬", key: "andre_tema" },
  { id: 11, navn: "Oppgaver & mål", ikon: "✅", key: "oppgaver_mal" },
  { id: 12, navn: "Oppsummering", ikon: "🏁", key: "oppsummering" },
];

export default function SamtaleGjennomforing() {
  const { samtaleId } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [samtale, setSamtale] = useState<Samtale | null>(null);
  const [medarbeiderForberedelse, setMedarbeiderForberedelse] = useState<Forberedelse | null>(null);
  const [lederForberedelse, setLederForberedelse] = useState<Forberedelse | null>(null);
  const [aktivtSteg, setAktivtSteg] = useState(1);
  const [stegNotater, setStegNotater] = useState<Record<string, StegNotat>>({});
  
  const [smartMalDialogOpen, setSmartMalDialogOpen] = useState(false);
  const [oppgaveDialogOpen, setOppgaveDialogOpen] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      if (!samtaleId) return;

      try {
        // Fetch samtale
        const { data: samtaleData, error: samtaleError } = await supabase
          .from("ansatt_samtaler")
          .select(`
            id, user_id, utfort_av, samtale_type, dato, status, steg_notater,
            users!ansatt_samtaler_user_id_fkey(id, name)
          `)
          .eq("id", samtaleId)
          .single();

        if (samtaleError) throw samtaleError;
        
        const typedSamtale = {
          ...samtaleData,
          users: samtaleData.users as unknown as { id: string; name: string },
          steg_notater: (samtaleData.steg_notater as unknown as Record<string, StegNotat>) || {},
        };
        
        setSamtale(typedSamtale);
        setStegNotater(typedSamtale.steg_notater);

        // Fetch forberedelser
        const { data: forberedelser } = await supabase
          .from("medarbeidersamtale_forberedelse")
          .select("*")
          .eq("samtale_id", samtaleId);

        if (forberedelser) {
          setMedarbeiderForberedelse(
            forberedelser.find(f => f.utfylt_av_type === "medarbeider") || null
          );
          setLederForberedelse(
            forberedelser.find(f => f.utfylt_av_type === "leder") || null
          );
        }

        // Update status to gjennomfores if planlagt
        if (samtaleData.status === "planlagt" || samtaleData.status === "forberedelse") {
          await supabase
            .from("ansatt_samtaler")
            .update({ status: "gjennomfores" })
            .eq("id", samtaleId);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        toast({ title: "Feil", description: "Kunne ikke hente samtaledata", variant: "destructive" });
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [samtaleId]);

  // Auto-save debounced
  const saveStegNotater = useCallback(async () => {
    if (!samtaleId || Object.keys(stegNotater).length === 0) return;

    try {
      await supabase
        .from("ansatt_samtaler")
        .update({ steg_notater: stegNotater as unknown as Json })
        .eq("id", samtaleId);
    } catch (error) {
      console.error("Auto-save failed:", error);
    }
  }, [samtaleId, stegNotater]);

  useEffect(() => {
    const timer = setTimeout(() => {
      saveStegNotater();
    }, 2000);

    return () => clearTimeout(timer);
  }, [stegNotater, saveStegNotater]);

  const handleNotatChange = (stegKey: string, notat: string) => {
    setStegNotater(prev => ({
      ...prev,
      [stegKey]: {
        ...prev[stegKey],
        notat,
        oppgaver: prev[stegKey]?.oppgaver || [],
        mal: prev[stegKey]?.mal || [],
      },
    }));
  };

  const handleFullfor = async () => {
    if (!samtaleId) return;

    setSaving(true);
    try {
      await supabase
        .from("ansatt_samtaler")
        .update({ 
          status: "fullfort",
          steg_notater: stegNotater as unknown as Json,
        })
        .eq("id", samtaleId);

      toast({ title: "Samtale fullført", description: "Samtalen er nå fullført og arkivert" });
      navigate("/hr/utvikling");
    } catch (error) {
      console.error("Error completing samtale:", error);
      toast({ title: "Feil", description: "Kunne ikke fullføre samtalen", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <AppLayout title="Gjennomfør samtale" subtitle="">
        <div className="flex items-center justify-center min-h-[400px]">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
      </AppLayout>
    );
  }

  if (!samtale) {
    return (
      <AppLayout title="Samtale ikke funnet" subtitle="">
        <div className="container mx-auto p-6">
          <Button variant="ghost" onClick={() => navigate("/hr/utvikling")}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Tilbake
          </Button>
        </div>
      </AppLayout>
    );
  }

  const aktivtStegConfig = STEG.find(s => s.id === aktivtSteg);

  return (
    <AppLayout 
      title={`Samtale med ${samtale.users?.name}`}
      subtitle={aktivtStegConfig ? `Steg ${aktivtSteg}: ${aktivtStegConfig.navn}` : ""}
    >
      <div className="flex h-[calc(100vh-120px)]">
        {/* Venstre panel: Steg-navigator */}
        <div className="w-72 border-r bg-muted/30 overflow-y-auto">
          <div className="p-4">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => navigate("/hr/utvikling")}
              className="mb-4"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Tilbake
            </Button>
          </div>
          <SamtaleStegNavigator 
            steg={STEG}
            aktivtSteg={aktivtSteg}
            onStegChange={setAktivtSteg}
            stegNotater={stegNotater}
          />
        </div>

        {/* Midtre panel: Hovedinnhold */}
        <div className="flex-1 overflow-y-auto p-6">
          <SamtaleStegInnhold
            steg={STEG.find(s => s.id === aktivtSteg)!}
            medarbeiderForberedelse={medarbeiderForberedelse}
            notat={stegNotater[aktivtStegConfig?.key || ""]?.notat || ""}
            onNotatChange={(notat) => handleNotatChange(aktivtStegConfig?.key || "", notat)}
            onOpprettOppgave={() => setOppgaveDialogOpen(true)}
            onOpprettMal={() => setSmartMalDialogOpen(true)}
            samtale={samtale}
            onFullfor={handleFullfor}
            saving={saving}
            aktivtSteg={aktivtSteg}
            setAktivtSteg={setAktivtSteg}
            totalSteg={STEG.length}
          />
        </div>

        {/* Høyre panel: Leder-guide (konfidensielt) */}
        <div className="w-80 border-l bg-muted/30 overflow-y-auto">
          <SamtaleLederGuide 
            lederForberedelse={lederForberedelse}
            samtale={samtale}
          />
        </div>
      </div>

      <SmartMalDialog
        open={smartMalDialogOpen}
        onOpenChange={setSmartMalDialogOpen}
        samtaleId={samtale.id}
        userId={samtale.user_id}
        onSuccess={() => {}}
      />

      <SamtaleOppgaveDialog
        open={oppgaveDialogOpen}
        onOpenChange={setOppgaveDialogOpen}
        samtaleId={samtale.id}
        medarbeiderId={samtale.user_id}
        lederId={samtale.utfort_av}
        onSuccess={() => {}}
      />
    </AppLayout>
  );
}
