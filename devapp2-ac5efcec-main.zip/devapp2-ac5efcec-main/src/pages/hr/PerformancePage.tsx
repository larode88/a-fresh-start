import { useAuth } from "@/hooks/useAuth";
import { useSalonContext } from "@/components/SalonSelector";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { MessageSquare, Target } from "lucide-react";
import { PerformanceReviews } from "@/components/hr/PerformanceReviews";
import { DevelopmentPlans } from "@/components/hr/DevelopmentPlans";
import { AppLayout } from "@/components/AppLayout";

export default function PerformancePage() {
  const { user, profile, loading: authLoading } = useAuth();
  const role = profile?.role;
  const { salons, selectedSalonId, setSelectedSalonId, loading: salonLoading, canSelectSalon } = useSalonContext();

  const canManage = ["admin", "salon_owner", "daglig_leder", "avdelingsleder"].includes(role || "");

  if (authLoading || salonLoading) {
    return (
      <div className="container mx-auto p-6 space-y-6">
        <Skeleton className="h-10 w-48" />
        <Skeleton className="h-96" />
      </div>
    );
  }

  return (
    <AppLayout title="Samtaler & Utvikling" subtitle="Medarbeidersamtaler og utviklingsplaner">
      <div className="container mx-auto p-6 space-y-6">

        {!selectedSalonId ? (
          <p className="text-center text-muted-foreground py-8">Velg en salong.</p>
        ) : (
          <Tabs defaultValue="reviews" className="space-y-4">
            <TabsList>
              <TabsTrigger value="reviews" className="flex items-center gap-2">
                <MessageSquare className="h-4 w-4" />
                Samtaler
              </TabsTrigger>
              <TabsTrigger value="development" className="flex items-center gap-2">
                <Target className="h-4 w-4" />
                Utviklingsplaner
              </TabsTrigger>
            </TabsList>

            <TabsContent value="reviews">
              <PerformanceReviews 
                salonId={selectedSalonId}
                userId={canManage ? undefined : user?.id}
                canManage={canManage}
              />
            </TabsContent>

            <TabsContent value="development">
              <DevelopmentPlans 
                salonId={selectedSalonId}
                userId={canManage ? undefined : user?.id}
                canManage={canManage}
              />
            </TabsContent>
          </Tabs>
        )}
      </div>
    </AppLayout>
  );
}
