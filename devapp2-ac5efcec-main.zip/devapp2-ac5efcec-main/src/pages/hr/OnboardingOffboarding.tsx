import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { format, addDays } from "date-fns";
import { nb } from "date-fns/locale";
import { 
  UserPlus, UserMinus, CheckCircle2, Clock, 
  ChevronRight, Plus, Search, AlertCircle,
  FileText, Key, GraduationCap, Shirt, Settings
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { AppLayout } from "@/components/AppLayout";
import { useAuth } from "@/hooks/useAuth";
import { useUserRole } from "@/hooks/useUserRole";
import { useCurrentAnsatt } from "@/hooks/useCurrentAnsatt";

const KATEGORI_ICONS: Record<string, React.ReactNode> = {
  dokumenter: <FileText className="h-4 w-4" />,
  utstyr: <Shirt className="h-4 w-4" />,
  tilganger: <Key className="h-4 w-4" />,
  opplæring: <GraduationCap className="h-4 w-4" />,
};

const KATEGORI_COLORS: Record<string, string> = {
  dokumenter: "bg-blue-500/10 text-blue-700",
  utstyr: "bg-purple-500/10 text-purple-700",
  tilganger: "bg-amber-500/10 text-amber-700",
  opplæring: "bg-green-500/10 text-green-700",
};

export default function OnboardingOffboarding() {
  const { user } = useAuth();
  const { role } = useUserRole();
  const { ansatt } = useCurrentAnsatt();
  const salonId = ansatt?.salong_id;
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState<"onboarding" | "offboarding">("onboarding");
  const [searchQuery, setSearchQuery] = useState("");
  const [showNewDialog, setShowNewDialog] = useState(false);
  const [selectedAnsatt, setSelectedAnsatt] = useState<string | null>(null);
  const [selectedMal, setSelectedMal] = useState<string | null>(null);
  const [startDato, setStartDato] = useState(format(new Date(), "yyyy-MM-dd"));
  const [expandedProsess, setExpandedProsess] = useState<string | null>(null);

  // Fetch prosesser
  const { data: prosesser, isLoading: isLoadingProsesser } = useQuery({
    queryKey: ["ansatt-prosesser", salonId, activeTab],
    queryFn: async () => {
      let query = supabase
        .from("ansatt_prosesser")
        .select(`
          *,
          ansatt:ansatte(id, fornavn, etternavn, profilbilde_url, frisorfunksjon),
          oppgaver:prosess_oppgaver(*)
        `)
        .eq("prosess_type", activeTab)
        .eq("status", "aktiv")
        .order("start_dato", { ascending: false });

      if (role !== "admin" && role !== "district_manager" && salonId) {
        query = query.eq("salon_id", salonId);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data || [];
    },
    enabled: !!user,
  });

  // Fetch maler
  const { data: maler } = useQuery({
    queryKey: ["sjekkliste-maler", activeTab],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("sjekkliste_maler")
        .select("*, oppgaver:sjekkliste_oppgave_maler(*)")
        .eq("prosess_type", activeTab)
        .eq("er_aktiv", true);
      if (error) throw error;
      return data || [];
    },
  });

  // Fetch ansatte for ny prosess
  const { data: ansatteListe } = useQuery({
    queryKey: ["ansatte-for-prosess", salonId],
    queryFn: async () => {
      let query = supabase
        .from("ansatte")
        .select("id, fornavn, etternavn, salong_id")
        .eq("status", "Aktiv");

      if (role !== "admin" && role !== "district_manager" && salonId) {
        query = query.eq("salong_id", salonId);
      }

      const { data, error } = await query.order("fornavn");
      if (error) throw error;
      return data || [];
    },
  });

  // Create prosess mutation
  const createProsessMutation = useMutation({
    mutationFn: async () => {
      if (!selectedAnsatt || !selectedMal) throw new Error("Mangler data");

      const mal = maler?.find((m: any) => m.id === selectedMal);
      const ansatt = ansatteListe?.find((a: any) => a.id === selectedAnsatt);
      if (!mal || !ansatt) throw new Error("Ugyldig valg");

      // Create prosess
      const { data: prosess, error: prosessError } = await supabase
        .from("ansatt_prosesser")
        .insert({
          ansatt_id: selectedAnsatt,
          salon_id: ansatt.salong_id,
          prosess_type: activeTab,
          mal_id: selectedMal,
          start_dato: startDato,
          opprettet_av: user?.id,
        })
        .select()
        .single();

      if (prosessError) throw prosessError;

      // Create oppgaver from mal
      const oppgaver = ((mal as any).oppgaver || []).map((o: any) => ({
        prosess_id: prosess.id,
        mal_oppgave_id: o.id,
        tittel: o.tittel,
        beskrivelse: o.beskrivelse,
        ansvarlig_rolle: o.ansvarlig_rolle,
        frist: o.frist_dager ? format(addDays(new Date(startDato), o.frist_dager), "yyyy-MM-dd") : null,
        kategori: o.kategori,
        prioritet: o.prioritet,
        obligatorisk: o.obligatorisk,
      }));

      const { error: oppgaverError } = await supabase
        .from("prosess_oppgaver")
        .insert(oppgaver);

      if (oppgaverError) throw oppgaverError;

      return prosess;
    },
    onSuccess: () => {
      toast.success(`${activeTab === "onboarding" ? "Onboarding" : "Offboarding"} startet`);
      queryClient.invalidateQueries({ queryKey: ["ansatt-prosesser"] });
      setShowNewDialog(false);
      setSelectedAnsatt(null);
      setSelectedMal(null);
    },
    onError: (error) => {
      console.error(error);
      toast.error("Kunne ikke starte prosess");
    },
  });

  // Toggle oppgave mutation
  const toggleOppgaveMutation = useMutation({
    mutationFn: async ({ oppgaveId, completed }: { oppgaveId: string; completed: boolean }) => {
      const { error } = await supabase
        .from("prosess_oppgaver")
        .update({
          status: completed ? "fullfort" : "ikke_startet",
          fullfort_av: completed ? user?.id : null,
          fullfort_dato: completed ? new Date().toISOString() : null,
        })
        .eq("id", oppgaveId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["ansatt-prosesser"] });
    },
  });

  // Calculate progress
  const getProgress = (oppgaver: any[]) => {
    if (!oppgaver?.length) return 0;
    const completed = oppgaver.filter((o) => o.status === "fullfort").length;
    return Math.round((completed / oppgaver.length) * 100);
  };

  // Filter prosesser
  const filteredProsesser = prosesser?.filter((p: any) => {
    if (!searchQuery) return true;
    const name = `${p.ansatt?.fornavn} ${p.ansatt?.etternavn}`.toLowerCase();
    return name.includes(searchQuery.toLowerCase());
  });

  return (
    <AppLayout>
      <div className="container mx-auto p-6 space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">Onboarding & Offboarding</h1>
            <p className="text-muted-foreground">Sjekklister for nyansatte og sluttende ansatte</p>
          </div>
          <Button onClick={() => setShowNewDialog(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Start ny prosess
          </Button>
        </div>

        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as any)}>
          <TabsList>
            <TabsTrigger value="onboarding" className="gap-2">
              <UserPlus className="h-4 w-4" />
              Onboarding
            </TabsTrigger>
            <TabsTrigger value="offboarding" className="gap-2">
              <UserMinus className="h-4 w-4" />
              Offboarding
            </TabsTrigger>
          </TabsList>

          <div className="mt-4 flex gap-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Søk etter ansatt..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>

          <TabsContent value="onboarding" className="mt-4 space-y-4">
            {isLoadingProsesser ? (
              <Card><CardContent className="py-8 text-center text-muted-foreground">Laster...</CardContent></Card>
            ) : filteredProsesser?.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <UserPlus className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="font-semibold mb-1">Ingen aktive onboardinger</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Start en ny prosess når du ansetter noen
                  </p>
                  <Button onClick={() => setShowNewDialog(true)}>
                    <Plus className="h-4 w-4 mr-2" />
                    Start onboarding
                  </Button>
                </CardContent>
              </Card>
            ) : (
              filteredProsesser?.map((prosess: any) => (
                <ProsessCard
                  key={prosess.id}
                  prosess={prosess}
                  isExpanded={expandedProsess === prosess.id}
                  onToggle={() => setExpandedProsess(expandedProsess === prosess.id ? null : prosess.id)}
                  onToggleOppgave={(oppgaveId, completed) => 
                    toggleOppgaveMutation.mutate({ oppgaveId, completed })
                  }
                  getProgress={getProgress}
                />
              ))
            )}
          </TabsContent>

          <TabsContent value="offboarding" className="mt-4 space-y-4">
            {isLoadingProsesser ? (
              <Card><CardContent className="py-8 text-center text-muted-foreground">Laster...</CardContent></Card>
            ) : filteredProsesser?.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <UserMinus className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="font-semibold mb-1">Ingen aktive offboardinger</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Start en prosess når noen slutter
                  </p>
                  <Button onClick={() => setShowNewDialog(true)}>
                    <Plus className="h-4 w-4 mr-2" />
                    Start offboarding
                  </Button>
                </CardContent>
              </Card>
            ) : (
              filteredProsesser?.map((prosess: any) => (
                <ProsessCard
                  key={prosess.id}
                  prosess={prosess}
                  isExpanded={expandedProsess === prosess.id}
                  onToggle={() => setExpandedProsess(expandedProsess === prosess.id ? null : prosess.id)}
                  onToggleOppgave={(oppgaveId, completed) => 
                    toggleOppgaveMutation.mutate({ oppgaveId, completed })
                  }
                  getProgress={getProgress}
                />
              ))
            )}
          </TabsContent>
        </Tabs>

        {/* New Process Dialog */}
        <Dialog open={showNewDialog} onOpenChange={setShowNewDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                Start {activeTab === "onboarding" ? "onboarding" : "offboarding"}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Velg ansatt</Label>
                <Select value={selectedAnsatt || ""} onValueChange={setSelectedAnsatt}>
                  <SelectTrigger>
                    <SelectValue placeholder="Velg ansatt..." />
                  </SelectTrigger>
                  <SelectContent>
                    {ansatteListe?.map((a: any) => (
                      <SelectItem key={a.id} value={a.id}>
                        {a.fornavn} {a.etternavn}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Velg sjekkliste-mal</Label>
                <Select value={selectedMal || ""} onValueChange={setSelectedMal}>
                  <SelectTrigger>
                    <SelectValue placeholder="Velg mal..." />
                  </SelectTrigger>
                  <SelectContent>
                    {maler?.map((m: any) => (
                      <SelectItem key={m.id} value={m.id}>
                        {m.navn} ({m.oppgaver?.length || 0} oppgaver)
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Startdato</Label>
                <Input
                  type="date"
                  value={startDato}
                  onChange={(e) => setStartDato(e.target.value)}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowNewDialog(false)}>
                Avbryt
              </Button>
              <Button 
                onClick={() => createProsessMutation.mutate()}
                disabled={!selectedAnsatt || !selectedMal || createProsessMutation.isPending}
              >
                {createProsessMutation.isPending ? "Starter..." : "Start prosess"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AppLayout>
  );
}

// Process Card Component
function ProsessCard({ 
  prosess, 
  isExpanded, 
  onToggle, 
  onToggleOppgave,
  getProgress 
}: { 
  prosess: any; 
  isExpanded: boolean;
  onToggle: () => void;
  onToggleOppgave: (oppgaveId: string, completed: boolean) => void;
  getProgress: (oppgaver: any[]) => number;
}) {
  const progress = getProgress(prosess.oppgaver || []);
  const oppgaverByKategori = (prosess.oppgaver || []).reduce((acc: any, o: any) => {
    const kat = o.kategori || "annet";
    if (!acc[kat]) acc[kat] = [];
    acc[kat].push(o);
    return acc;
  }, {});

  const overdueCount = (prosess.oppgaver || []).filter(
    (o: any) => o.status !== "fullfort" && o.frist && new Date(o.frist) < new Date()
  ).length;

  return (
    <Card>
      <CardHeader 
        className="cursor-pointer hover:bg-muted/50 transition-colors"
        onClick={onToggle}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
              {prosess.ansatt?.profilbilde_url ? (
                <img 
                  src={prosess.ansatt.profilbilde_url} 
                  alt="" 
                  className="h-10 w-10 rounded-full object-cover"
                />
              ) : (
                <span className="font-semibold text-primary">
                  {prosess.ansatt?.fornavn?.[0]}{prosess.ansatt?.etternavn?.[0]}
                </span>
              )}
            </div>
            <div>
              <CardTitle className="text-base">
                {prosess.ansatt?.fornavn} {prosess.ansatt?.etternavn}
              </CardTitle>
              <CardDescription>
                Startet {format(new Date(prosess.start_dato), "d. MMM yyyy", { locale: nb })}
              </CardDescription>
            </div>
          </div>
          <div className="flex items-center gap-4">
            {overdueCount > 0 && (
              <Badge variant="destructive" className="gap-1">
                <AlertCircle className="h-3 w-3" />
                {overdueCount} forsinket
              </Badge>
            )}
            <div className="text-right">
              <span className="text-lg font-bold">{progress}%</span>
              <Progress value={progress} className="w-24 h-2 mt-1" />
            </div>
            <ChevronRight className={`h-5 w-5 transition-transform ${isExpanded ? "rotate-90" : ""}`} />
          </div>
        </div>
      </CardHeader>
      
      {isExpanded && (
        <CardContent className="pt-0 space-y-6">
          {Object.entries(oppgaverByKategori).map(([kategori, oppgaver]: [string, any]) => (
            <div key={kategori}>
              <div className="flex items-center gap-2 mb-3">
                <div className={`p-1.5 rounded ${KATEGORI_COLORS[kategori] || "bg-muted"}`}>
                  {KATEGORI_ICONS[kategori] || <Settings className="h-4 w-4" />}
                </div>
                <span className="font-medium capitalize">{kategori}</span>
                <Badge variant="outline" className="ml-auto">
                  {oppgaver.filter((o: any) => o.status === "fullfort").length}/{oppgaver.length}
                </Badge>
              </div>
              <div className="space-y-2 ml-8">
                {oppgaver.sort((a: any, b: any) => a.prioritet - b.prioritet).map((oppgave: any) => {
                  const isOverdue = oppgave.status !== "fullfort" && oppgave.frist && new Date(oppgave.frist) < new Date();
                  const isCompleted = oppgave.status === "fullfort";
                  
                  return (
                    <div 
                      key={oppgave.id}
                      className={`flex items-center gap-3 p-2 rounded-lg border ${
                        isCompleted ? "bg-muted/50 opacity-70" : isOverdue ? "border-destructive/50 bg-destructive/5" : ""
                      }`}
                    >
                      <Checkbox
                        checked={isCompleted}
                        onCheckedChange={(checked) => onToggleOppgave(oppgave.id, !!checked)}
                      />
                      <div className="flex-1">
                        <p className={isCompleted ? "line-through text-muted-foreground" : ""}>
                          {oppgave.tittel}
                        </p>
                        {oppgave.frist && (
                          <p className={`text-xs ${isOverdue ? "text-destructive" : "text-muted-foreground"}`}>
                            <Clock className="inline h-3 w-3 mr-1" />
                            Frist: {format(new Date(oppgave.frist), "d. MMM", { locale: nb })}
                          </p>
                        )}
                      </div>
                      {oppgave.obligatorisk && !isCompleted && (
                        <Badge variant="outline" className="text-xs">Påkrevd</Badge>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </CardContent>
      )}
    </Card>
  );
}