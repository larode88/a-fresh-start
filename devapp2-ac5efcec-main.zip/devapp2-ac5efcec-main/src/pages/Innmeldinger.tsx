import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { AppLayout } from '@/components/AppLayout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Plus, FileText, Clock, CheckCircle, Trash2, ArrowRight, Building2, Construction, Shield } from 'lucide-react';
import { format } from 'date-fns';
import { nb } from 'date-fns/locale';
import { toast } from 'sonner';
import { useUserRole } from '@/hooks/useUserRole';

type DraftStatus = 'utkast' | 'venter_signering' | 'ferdig';

interface InnmeldingUtkast {
  id: string;
  org_nummer: string;
  salongnavn: string;
  current_step: number;
  status: DraftStatus;
  avtale_status: string | null;
  created_at: string;
  updated_at: string;
  created_by: string;
}

export default function Innmeldinger() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const { isAdmin, isDistrictManager } = useUserRole();
  const showComingSoonBanner = isDistrictManager && !isAdmin;

  const { data: drafts, isLoading } = useQuery({
    queryKey: ['innmelding-utkast', statusFilter],
    queryFn: async () => {
      let query = supabase
        .from('innmelding_utkast')
        .select('*')
        .order('updated_at', { ascending: false });
      
      if (statusFilter !== 'all') {
        query = query.eq('status', statusFilter);
      }
      
      const { data, error } = await query;
      if (error) throw error;
      return data as InnmeldingUtkast[];
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('innmelding_utkast')
        .delete()
        .eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['innmelding-utkast'] });
      toast.success('Utkast slettet');
    },
    onError: () => {
      toast.error('Kunne ikke slette utkast');
    },
  });

  const getStatusBadge = (status: DraftStatus) => {
    switch (status) {
      case 'utkast':
        return <Badge variant="outline"><FileText className="h-3 w-3 mr-1" />Utkast</Badge>;
      case 'venter_signering':
        return <Badge variant="secondary"><Clock className="h-3 w-3 mr-1" />Venter signering</Badge>;
      case 'ferdig':
        return <Badge className="bg-green-600"><CheckCircle className="h-3 w-3 mr-1" />Ferdig</Badge>;
    }
  };

  const getStepName = (step: number) => {
    const steps = ['Bedriftsinfo', 'Kontaktpersoner', 'Medlemsoppsett', 'Leverandører', 'Avtale', 'Fullfør'];
    return steps[step - 1] || 'Ukjent';
  };

  const activeDrafts = drafts?.filter(d => d.status !== 'ferdig') || [];
  const waitingCount = drafts?.filter(d => d.status === 'venter_signering').length || 0;
  const draftCount = drafts?.filter(d => d.status === 'utkast').length || 0;

  return (
    <AppLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-serif font-semibold text-foreground">
              Innmeldinger
            </h1>
            <p className="text-muted-foreground">
              Administrer pågående medlemsinnmeldinger
            </p>
          </div>
          <Button 
            onClick={() => navigate('/innmelding')}
            disabled={showComingSoonBanner}
            className={showComingSoonBanner ? "opacity-50 cursor-not-allowed" : ""}
          >
            <Plus className="h-4 w-4 mr-2" />
            Ny innmelding
          </Button>
        </div>

        {/* Coming Soon Banner for District Managers */}
        {showComingSoonBanner && (
          <Alert className="border-amber-200 bg-amber-50 dark:border-amber-800 dark:bg-amber-950/30">
            <Construction className="h-5 w-5 text-amber-600 dark:text-amber-400" />
            <AlertTitle className="text-amber-800 dark:text-amber-200 font-medium">
              Innmeldingsmodulen er under utvikling
            </AlertTitle>
            <AlertDescription className="text-amber-700 dark:text-amber-300">
              <p className="mb-2">
                Denne funksjonaliteten er snart klar for distriktsjefer. 
                I mellomtiden kan du administrere medlemsinnmeldinger via Admin.
              </p>
              <div className="flex items-center gap-2 text-sm">
                <Shield className="h-4 w-4" />
                <span>
                  <strong>Forsikring</strong> er allerede tilgjengelig for deg under Distrikt-menyen.
                </span>
              </div>
            </AlertDescription>
          </Alert>
        )}

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Aktive utkast</p>
                  <p className="text-2xl font-bold">{draftCount}</p>
                </div>
                <FileText className="h-8 w-8 text-muted-foreground/50" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Venter signering</p>
                  <p className="text-2xl font-bold">{waitingCount}</p>
                </div>
                <Clock className="h-8 w-8 text-muted-foreground/50" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Totalt aktive</p>
                  <p className="text-2xl font-bold">{activeDrafts.length}</p>
                </div>
                <Building2 className="h-8 w-8 text-muted-foreground/50" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters and table */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Pågående innmeldinger</CardTitle>
                <CardDescription>Klikk på en rad for å fortsette</CardDescription>
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Filter status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Alle</SelectItem>
                  <SelectItem value="utkast">Utkast</SelectItem>
                  <SelectItem value="venter_signering">Venter signering</SelectItem>
                  <SelectItem value="ferdig">Ferdig</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent>
            {showComingSoonBanner ? (
              <div className="text-center py-12">
                <Construction className="h-16 w-16 mx-auto text-amber-400 mb-4" />
                <p className="text-lg font-medium text-muted-foreground mb-2">
                  Innmeldingsoversikten kommer snart
                </p>
                <p className="text-sm text-muted-foreground max-w-md mx-auto">
                  Du vil snart kunne se og administrere innmeldinger for ditt distrikt her. 
                  Kontakt Admin hvis du har spørsmål.
                </p>
              </div>
            ) : isLoading ? (
              <div className="text-center py-8 text-muted-foreground">
                Laster...
              </div>
            ) : drafts?.length === 0 ? (
              <div className="text-center py-8">
                <FileText className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
                <p className="text-muted-foreground">Ingen innmeldinger funnet</p>
                <Button 
                  variant="outline" 
                  className="mt-4"
                  onClick={() => navigate('/innmelding')}
                >
                  Start ny innmelding
                </Button>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Salong</TableHead>
                    <TableHead>Org.nr</TableHead>
                    <TableHead>Steg</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Sist oppdatert</TableHead>
                    <TableHead className="text-right">Handlinger</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {drafts?.map((draft) => (
                    <TableRow 
                      key={draft.id}
                      className="cursor-pointer hover:bg-muted/50"
                      onClick={() => navigate(`/innmelding?draft=${draft.id}`)}
                    >
                      <TableCell className="font-medium">{draft.salongnavn}</TableCell>
                      <TableCell className="text-muted-foreground">{draft.org_nummer}</TableCell>
                      <TableCell>
                        {draft.status === 'ferdig' ? (
                          <span className="text-sm text-green-600 font-medium flex items-center gap-1">
                            <CheckCircle className="h-4 w-4" />
                            Fullført
                          </span>
                        ) : (
                          <span className="text-sm">
                            {draft.current_step}/6 - {getStepName(draft.current_step)}
                          </span>
                        )}
                      </TableCell>
                      <TableCell>{getStatusBadge(draft.status)}</TableCell>
                      <TableCell className="text-muted-foreground">
                        {format(new Date(draft.updated_at), 'dd. MMM yyyy HH:mm', { locale: nb })}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2" onClick={(e) => e.stopPropagation()}>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => navigate(`/innmelding?draft=${draft.id}`)}
                          >
                            Fortsett
                            <ArrowRight className="h-4 w-4 ml-1" />
                          </Button>
                          {draft.status !== 'ferdig' && (
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button size="sm" variant="ghost" className="text-destructive hover:text-destructive">
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Slett utkast?</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Er du sikker på at du vil slette utkastet for "{draft.salongnavn}"? 
                                    Denne handlingen kan ikke angres.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>Avbryt</AlertDialogCancel>
                                  <AlertDialogAction
                                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                    onClick={() => deleteMutation.mutate(draft.id)}
                                  >
                                    Slett
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
