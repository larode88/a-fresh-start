import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useSalonContext } from "@/components/SalonSelector";
import { AppLayout } from "@/components/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Building2, Plus, Heart, Users } from "lucide-react";
import { InsuranceOrderHistory } from "@/components/insurance/InsuranceOrderHistory";
import { InsuranceDocuments } from "@/components/insurance/InsuranceDocuments";
import { InsuranceFAQ } from "@/components/insurance/InsuranceFAQ";
import { InsuranceCard, InsuranceCardData, HealthEmployee } from "@/components/insurance/InsuranceCard";
import { InsuranceChangeDialog } from "@/components/insurance/InsuranceChangeDialog";
import { InsuranceAddDialog } from "@/components/insurance/InsuranceAddDialog";
import { InsuranceCancelDialog } from "@/components/insurance/InsuranceCancelDialog";
import { HealthEmployeeCancelDialog } from "@/components/insurance/HealthEmployeeCancelDialog";

interface SalonInsurance {
  id: string;
  salon_id: string;
  helse_status: boolean;
  antall_ansatte: number | null;
  antall_arsverk: number | null;
  antall_fritidsulykke: number | null;
  antall_reiseforsikring: number | null;
  cyber_aktiv: boolean;
  fritidsulykke_aktiv: boolean;
  reise_aktiv: boolean;
  salong_aktiv: boolean;
  yrkesskadeforsikring_aktiv: boolean;
  salong_niva: string | null;
  pris_cyber: number | null;
  pris_fritidsulykke: number | null;
  pris_reise: number | null;
  pris_salong: number | null;
  pris_yrkesskadeforsikring: number | null;
  sum_totalt: number | null;
  helse_antall_aktive: number | null;
}

interface ScheduledCancellation {
  id: string;
  insurance_type: string;
  cancellation_date: string;
}

export default function Insurance() {
  const navigate = useNavigate();
  const { profile } = useAuth();
  const { selectedSalonId } = useSalonContext();
  
  // Dialog states
  const [changeDialog, setChangeDialog] = useState<{ open: boolean; type: string; values: Record<string, unknown> }>({ open: false, type: "", values: {} });
  const [addDialog, setAddDialog] = useState(false);
  const [cancelDialog, setCancelDialog] = useState<{ open: boolean; type: string; label: string; isHealth: boolean }>({ open: false, type: "", label: "", isHealth: false });
  const [cancelEmployeeDialog, setCancelEmployeeDialog] = useState<{ open: boolean; employee: { id: string; name: string } | null }>({ open: false, employee: null });

  const salonId = selectedSalonId || profile?.salon_id;

  const { data: myInsurance, isLoading: myInsuranceLoading } = useQuery({
    queryKey: ["my-salon-insurance", salonId],
    queryFn: async () => {
      if (!salonId) return null;
      const { data, error } = await supabase.from("salon_insurance").select("*").eq("salon_id", salonId).maybeSingle();
      if (error) throw error;
      return data as SalonInsurance | null;
    },
    enabled: !!salonId,
  });

  const { data: scheduledCancellations } = useQuery({
    queryKey: ["scheduled-cancellations", salonId],
    queryFn: async () => {
      if (!salonId) return [];
      const { data, error } = await supabase.from("insurance_scheduled_cancellations").select("id, insurance_type, cancellation_date").eq("salon_id", salonId).eq("processed", false);
      if (error) throw error;
      return data as ScheduledCancellation[];
    },
    enabled: !!salonId,
  });

  // Fetch health insurance employees
  const { data: healthEmployees } = useQuery({
    queryKey: ["health-employees", salonId],
    queryFn: async () => {
      if (!salonId) return [];
      const { data, error } = await supabase
        .from("ansatte")
        .select("id, fornavn, etternavn, helseforsikring_status")
        .eq("salong_id", salonId)
        .not("helseforsikring_status", "is", null)
        .not("helseforsikring_status", "eq", "");
      if (error) throw error;
      return (data || []).map(e => ({
        id: e.id,
        name: `${e.fornavn || ""} ${e.etternavn || ""}`.trim(),
        status: e.helseforsikring_status || "",
      })) as HealthEmployee[];
    },
    enabled: !!salonId && !!myInsurance?.helse_status,
  });

  const formatPrice = (price: number) => new Intl.NumberFormat("nb-NO", { style: "currency", currency: "NOK", maximumFractionDigits: 0 }).format(price);

  const getCancellation = (type: string) => scheduledCancellations?.find(c => c.insurance_type === type);

  // Build insurance card data
  const buildInsuranceCards = (): InsuranceCardData[] => {
    if (!myInsurance) return [];
    const cards: InsuranceCardData[] = [];

    if (myInsurance.salong_aktiv) {
      cards.push({ type: "salong", label: "Salongforsikring", isActive: true, price: myInsurance.pris_salong, tierName: myInsurance.salong_niva, scheduledCancellation: getCancellation("salong") ? { date: getCancellation("salong")!.cancellation_date, id: getCancellation("salong")!.id } : null });
    }
    if (myInsurance.yrkesskadeforsikring_aktiv) {
      const total = (myInsurance.pris_yrkesskadeforsikring || 0) * (myInsurance.antall_arsverk || 1);
      cards.push({ type: "yrkesskade", label: "Utvidet Yrkesskade", isActive: true, price: total, quantity: myInsurance.antall_arsverk, unitLabel: "årsverk", scheduledCancellation: getCancellation("yrkesskade") ? { date: getCancellation("yrkesskade")!.cancellation_date, id: getCancellation("yrkesskade")!.id } : null });
    }
    if (myInsurance.cyber_aktiv) {
      cards.push({ type: "cyber", label: "Cyberforsikring", isActive: true, price: myInsurance.pris_cyber, scheduledCancellation: getCancellation("cyber") ? { date: getCancellation("cyber")!.cancellation_date, id: getCancellation("cyber")!.id } : null });
    }
    if (myInsurance.reise_aktiv) {
      const total = (myInsurance.pris_reise || 0) * (myInsurance.antall_reiseforsikring || 1);
      cards.push({ type: "reise", label: "Reiseforsikring", isActive: true, price: total, quantity: myInsurance.antall_reiseforsikring, unitLabel: "personer", scheduledCancellation: getCancellation("reise") ? { date: getCancellation("reise")!.cancellation_date, id: getCancellation("reise")!.id } : null });
    }
    if (myInsurance.fritidsulykke_aktiv) {
      const total = (myInsurance.pris_fritidsulykke || 0) * (myInsurance.antall_fritidsulykke || 1);
      cards.push({ type: "fritidsulykke", label: "Fritidsulykke", isActive: true, price: total, quantity: myInsurance.antall_fritidsulykke, unitLabel: "personer", scheduledCancellation: getCancellation("fritidsulykke") ? { date: getCancellation("fritidsulykke")!.cancellation_date, id: getCancellation("fritidsulykke")!.id } : null });
    }
    return cards;
  };

  const insuranceCards = buildInsuranceCards();
  const existingTypes = insuranceCards.map(c => c.type);
  const businessTotal = insuranceCards.reduce((sum, c) => sum + (c.price || 0), 0);
  const healthTotal = myInsurance?.helse_status && myInsurance.helse_antall_aktive ? myInsurance.helse_antall_aktive * 5050 : 0;
  const grandTotal = businessTotal + healthTotal;

  return (
    <AppLayout title="Forsikring" subtitle="Oversikt over dine forsikringer">
      <div className="container mx-auto px-4 py-8 space-y-6">
        
        {!salonId && (
          <Card>
            <CardContent className="py-12 text-center">
              <Building2 className="h-12 w-12 mx-auto mb-4 text-muted-foreground opacity-50" />
              <p className="text-muted-foreground">Velg en salong i menyen øverst for å se forsikringsoversikt</p>
            </CardContent>
          </Card>
        )}
        
        {salonId && (
        <>
        {/* Bedriftsforsikring */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2"><Building2 className="h-5 w-5" />Bedriftsforsikring</CardTitle>
                <CardDescription>Forsikringer for din salong og ansatte</CardDescription>
              </div>
              {businessTotal > 0 && <div className="text-right"><p className="text-sm text-muted-foreground">Total årlig</p><p className="text-xl font-bold">{formatPrice(businessTotal)}</p></div>}
            </div>
          </CardHeader>
          <CardContent>
            {myInsuranceLoading ? (
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-40" />)}</div>
            ) : insuranceCards.length > 0 ? (
              <div className="space-y-4">
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {insuranceCards.map((card) => (
                    <InsuranceCard
                      key={card.type}
                      insurance={card}
                      onEdit={() => setChangeDialog({ open: true, type: card.type, values: { tierName: card.tierName, quantity: card.quantity, price: card.price, antallAnsatte: myInsurance?.antall_ansatte } })}
                      onCancel={() => setCancelDialog({ open: true, type: card.type, label: card.label, isHealth: false })}
                      onCancelCancellation={() => {/* TODO: implement */}}
                    />
                  ))}
                </div>
                <Button variant="outline" onClick={() => setAddDialog(true)}><Plus className="h-4 w-4 mr-2" />Legg til forsikring</Button>
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Building2 className="h-12 w-12 mx-auto mb-4 opacity-50" /><p>Du har ingen aktive bedriftsforsikringer.</p>
                <Button className="mt-4" onClick={() => setAddDialog(true)}><Plus className="h-4 w-4 mr-2" />Legg til forsikring</Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Helseforsikring */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2"><Heart className="h-5 w-5" />Helseforsikring</CardTitle>
                <CardDescription>Helseforsikring for dine ansatte</CardDescription>
              </div>
              {healthTotal > 0 && <div className="text-right"><p className="text-sm text-muted-foreground">Total årlig</p><p className="text-xl font-bold">{formatPrice(healthTotal)}</p></div>}
            </div>
          </CardHeader>
          <CardContent>
            {myInsuranceLoading ? <Skeleton className="h-40" /> : myInsurance?.helse_status ? (
              <div className="space-y-4">
                <InsuranceCard
                  insurance={{ 
                    type: "helse", 
                    label: "Helseforsikring", 
                    isActive: true, 
                    price: healthTotal, 
                    quantity: myInsurance.helse_antall_aktive, 
                    unitLabel: "ansatte", 
                    employees: healthEmployees || [],
                    scheduledCancellation: getCancellation("helse") ? { date: getCancellation("helse")!.cancellation_date, id: getCancellation("helse")!.id } : null 
                  }}
                  onEdit={() => {}}
                  onCancel={() => setCancelDialog({ open: true, type: "helse", label: "Helseforsikring", isHealth: true })}
                  isHealthInsurance
                  onManageEmployees={() => navigate("/insurance/health")}
                  onCancelEmployee={(id, name) => setCancelEmployeeDialog({ open: true, employee: { id, name } })}
                />
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Heart className="h-12 w-12 mx-auto mb-4 opacity-50" /><p>Du har ingen aktiv helseforsikring.</p>
                <Button className="mt-4" onClick={() => navigate("/insurance/health")}><Users className="h-4 w-4 mr-2" />Bestill Helseforsikring</Button>
              </div>
            )}
          </CardContent>
        </Card>

        {grandTotal > 0 && <div className="p-6 bg-muted rounded-lg"><div className="flex items-center justify-between"><span className="text-lg font-medium">Total årlig premie</span><span className="text-2xl font-bold">{formatPrice(grandTotal)}</span></div></div>}
        
        {myInsurance && <InsuranceDocuments activeProducts={{ salong: myInsurance.salong_aktiv, yrkesskade: myInsurance.yrkesskadeforsikring_aktiv, cyber: myInsurance.cyber_aktiv, reise: myInsurance.reise_aktiv, fritidsulykke: myInsurance.fritidsulykke_aktiv, helse: myInsurance.helse_status }} salongNiva={myInsurance.salong_niva} />}
        {salonId && <InsuranceOrderHistory salonId={salonId} />}
        <InsuranceFAQ />
        </>
        )}
      </div>

      {/* Dialogs */}
      {salonId && (
        <>
          <InsuranceChangeDialog open={changeDialog.open} onOpenChange={(o) => setChangeDialog(v => ({ ...v, open: o }))} salonId={salonId} insuranceType={changeDialog.type} currentValues={changeDialog.values as { tierName?: string; tierId?: string; quantity?: number; price: number; antallAnsatte?: number }} />
          <InsuranceAddDialog open={addDialog} onOpenChange={setAddDialog} salonId={salonId} existingInsurances={existingTypes} arsverk={myInsurance?.antall_arsverk || 1} />
          <InsuranceCancelDialog open={cancelDialog.open} onOpenChange={(o) => setCancelDialog(v => ({ ...v, open: o }))} salonId={salonId} insuranceType={cancelDialog.type} insuranceLabel={cancelDialog.label} isHealthInsurance={cancelDialog.isHealth} />
          <HealthEmployeeCancelDialog 
            open={cancelEmployeeDialog.open} 
            onOpenChange={(o) => setCancelEmployeeDialog(v => ({ ...v, open: o }))} 
            employee={cancelEmployeeDialog.employee} 
            salonId={salonId} 
          />
        </>
      )}
    </AppLayout>
  );
}
