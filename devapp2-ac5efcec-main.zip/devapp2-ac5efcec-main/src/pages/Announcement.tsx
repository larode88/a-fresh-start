import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeft, Calendar } from "lucide-react";
import DOMPurify from "dompurify";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { nb } from "date-fns/locale";

interface AnnouncementData {
  id: string;
  title: string;
  description: string | null;
  image_url: string | null;
  content: string | null;
  published_at: string | null;
  created_at: string;
}

export default function Announcement() {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const [announcement, setAnnouncement] = useState<AnnouncementData | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/login");
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (slug) {
      fetchAnnouncement();
    }
  }, [slug]);

  const fetchAnnouncement = async () => {
    const { data, error } = await supabase
      .from("announcements")
      .select("id, title, description, image_url, content, published_at, created_at")
      .eq("slug", slug)
      .eq("published", true)
      .maybeSingle();

    if (error || !data) {
      setNotFound(true);
    } else {
      setAnnouncement(data);
    }
    setLoading(false);
  };

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-background p-4">
        <Skeleton className="h-8 w-32 mb-4" />
        <Skeleton className="h-48 w-full rounded-xl mb-4" />
        <Skeleton className="h-8 w-3/4 mb-2" />
        <Skeleton className="h-4 w-1/2 mb-6" />
        <Skeleton className="h-32 w-full" />
      </div>
    );
  }

  if (notFound) {
    return (
      <div className="min-h-screen bg-background p-4">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigate("/dashboard")}
          className="mb-4"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Tilbake
        </Button>
        <div className="text-center py-12">
          <h1 className="text-2xl font-bold text-foreground mb-2">
            Nyheten ble ikke funnet
          </h1>
          <p className="text-muted-foreground">
            Denne nyheten finnes ikke eller er ikke lenger tilgjengelig.
          </p>
        </div>
      </div>
    );
  }

  const publishDate = announcement?.published_at || announcement?.created_at;

  return (
    <div className="min-h-screen bg-background">
      <div className="sticky top-0 z-10 bg-background/95 backdrop-blur border-b border-border p-4">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigate("/dashboard")}
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Tilbake til dashboard
        </Button>
      </div>

      {announcement?.image_url && (
        <div className="relative h-48 sm:h-64 w-full">
          <img
            src={announcement.image_url}
            alt={announcement.title}
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent" />
        </div>
      )}

      <div className="p-4 max-w-3xl mx-auto">
        <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-2">
          {announcement?.title}
        </h1>

        {publishDate && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
            <Calendar className="h-4 w-4" />
            <span>
              {format(new Date(publishDate), "d. MMMM yyyy", { locale: nb })}
            </span>
          </div>
        )}

        {announcement?.description && (
          <p className="text-lg text-muted-foreground mb-6">
            {announcement.description}
          </p>
        )}

        {announcement?.content && (
          <div 
            className="prose prose-sm max-w-none dark:prose-invert"
            dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(announcement.content) }}
          />
        )}
      </div>
    </div>
  );
}
