import { useState, useEffect, useMemo } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useSalonContext } from "@/components/SalonSelector";
import { AppLayout } from "@/components/AppLayout";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Calendar, Download, Plus, Users, ChevronLeft, ChevronRight, Sparkles, Trash2, Settings2 } from "lucide-react";
import { FerieRegelEditor } from "@/components/ferie/FerieRegelEditor";
import { FerieAarligOversikt } from "@/components/ferie/FerieAarligOversikt";
import { FerieDialog } from "@/components/ferie/FerieDialog";
import { BulkFerieDialog } from "@/components/ferie/BulkFerieDialog";
import { FerieOverforingDialog } from "@/components/ferie/FerieOverforingDialog";
import { FerieEstimatGenerator } from "@/components/ferie/FerieEstimatGenerator";
import { FerieTabell } from "@/components/ferie/FerieTabell";
import { LeaveCalendar } from "@/components/leave/LeaveCalendar";
import { regenererSkiftForPeriode } from "@/integrations/supabase/turnusService";
import * as XLSX from "xlsx";

export default function Ferie() {
  const { user, profile, loading: authLoading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const role = profile?.role;
  const { salons, selectedSalonId, setSelectedSalonId, loading: salonLoading, canSelectSalon } = useSalonContext();

  const currentYear = new Date().getFullYear();
  const [selectedYear, setSelectedYear] = useState(currentYear);
  const [showFerieDialog, setShowFerieDialog] = useState(false);
  const [showBulkDialog, setShowBulkDialog] = useState(false);
  const [showEstimatDialog, setShowEstimatDialog] = useState(false);
  const [showRegelEditor, setShowRegelEditor] = useState(false);
  const [showOverforingDialog, setShowOverforingDialog] = useState(false);
  const [editingFerie, setEditingFerie] = useState<any>(null);
  const [filterAnsattId, setFilterAnsattId] = useState<string | null>(null);
  const [overforingData, setOverforingData] = useState<{
    ansattId: string;
    ansattNavn: string;
    tilgode: number;
    feriekravType: string;
  } | null>(null);

  const canManage = ["admin", "salon_owner", "daglig_leder", "avdelingsleder"].includes(role || "");

  const years = Array.from({ length: 9 }, (_, i) => currentYear - 5 + i);

  // Fetch ansatte for selected salon (only those included in turnus)
  const { data: ansatte = [], isLoading: ansatteLoading } = useQuery({
    queryKey: ["ansatte-for-ferie", selectedSalonId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("ansatte")
        .select("id, fornavn, etternavn, stillingsprosent, feriekrav_timer_per_aar, feriekrav_type_enum, user_id, inkluder_i_turnus")
        .eq("salong_id", selectedSalonId)
        .eq("status", "Aktiv")
        .eq("inkluder_i_turnus", true)
        .order("fornavn");
      if (error) throw error;
      return data || [];
    },
    enabled: !!selectedSalonId,
  });

  // Get user IDs for ferie queries
  const userIds = useMemo(() => 
    ansatte.map(a => a.user_id).filter(Boolean) as string[], 
    [ansatte]
  );

  // Fetch ferie for selected year with user and ansatte names
  const { data: ferie = [], isLoading: ferieLoading } = useQuery({
    queryKey: ["ferie", selectedSalonId, selectedYear],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("ferie")
        .select(`
          *,
          users!ferie_user_id_fkey(id, name),
          ansatte!ferie_ansatt_id_fkey(id, fornavn, etternavn)
        `)
        .eq("salon_id", selectedSalonId)
        .eq("aar", selectedYear)
        .order("startdato", { ascending: false });
      if (error) throw error;
      return data || [];
    },
    enabled: !!selectedSalonId,
  });

  // Fetch overforinger inn (til dette året)
  const { data: overforingInn = [] } = useQuery({
    queryKey: ["ferie-overforing-inn", userIds, selectedYear],
    queryFn: async () => {
      if (userIds.length === 0) return [];
      const { data, error } = await supabase
        .from("ferie_overforing")
        .select("*")
        .in("user_id", userIds)
        .eq("til_aar", selectedYear);
      if (error) throw error;
      return data || [];
    },
    enabled: userIds.length > 0,
  });

  // Fetch overforinger ut (fra dette året)
  const { data: overforingUt = [] } = useQuery({
    queryKey: ["ferie-overforing-ut", userIds, selectedYear],
    queryFn: async () => {
      if (userIds.length === 0) return [];
      const { data, error } = await supabase
        .from("ferie_overforing")
        .select("*")
        .in("user_id", userIds)
        .eq("fra_aar", selectedYear);
      if (error) throw error;
      return data || [];
    },
    enabled: userIds.length > 0,
  });

  const handleOverfor = (ansattId: string, tilgode: number, feriekravType: string) => {
    const ansatt = ansatte.find(a => a.id === ansattId || a.user_id === ansattId);
    if (!ansatt) return;
    
    setOverforingData({
      ansattId: ansatt.user_id || ansattId,
      ansattNavn: `${ansatt.fornavn} ${ansatt.etternavn || ""}`,
      tilgode,
      feriekravType
    });
    setShowOverforingDialog(true);
  };

  const handleEdit = (ferieItem: any) => {
    setEditingFerie(ferieItem);
    setShowFerieDialog(true);
  };

  const handleDelete = async (ferieId: string) => {
    // Hent ferieinfo før sletting for å få datoer og ansatt_id
    const ferieItem = ferie.find((f: any) => f.id === ferieId);
    
    try {
      const { error } = await supabase.from("ferie").delete().eq("id", ferieId);
      if (error) throw error;
      toast({ title: "Slettet", description: "Ferieregistrering ble slettet" });
      
      // Regenerer skift nå som ferie er fjernet (hvis det var en blokkerende status)
      if (ferieItem && selectedSalonId && 
          ['godkjent', 'planlagt', 'avviklet'].includes(ferieItem.status)) {
        const ansattId = ferieItem.ansatt_id || ferieItem.ansatte?.id;
        if (ansattId) {
          try {
            await regenererSkiftForPeriode(
              ansattId,
              selectedSalonId,
              new Date(ferieItem.startdato),
              new Date(ferieItem.sluttdato)
            );
          } catch (shiftError) {
            console.error("Error regenerating shifts after delete:", shiftError);
          }
        }
      }
      
      // Invalidate alle relevante queries
      queryClient.invalidateQueries({ queryKey: ["ferie"] });
      queryClient.invalidateQueries({ queryKey: ['skift'] });
      queryClient.invalidateQueries({ queryKey: ['ansatt-turnus'] });
      queryClient.invalidateQueries({ queryKey: ['turnus-skift'] });
    } catch (error) {
      console.error("Error deleting ferie:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke slette ferie",
        variant: "destructive"
      });
    }
  };

  const handleApprove = async (ferieItem: any) => {
    if (!selectedSalonId) return;
    
    try {
      const { error } = await supabase
        .from("ferie")
        .update({ status: "godkjent" })
        .eq("id", ferieItem.id);
      
      if (error) throw error;
      toast({ title: "Godkjent", description: "Feriesøknaden ble godkjent" });
      
      // Regenerer skift for ferieperioden
      const ansattId = ferieItem.ansatt_id || ferieItem.ansatte?.id;
      if (ansattId) {
        try {
          await regenererSkiftForPeriode(
            ansattId,
            selectedSalonId,
            new Date(ferieItem.startdato),
            new Date(ferieItem.sluttdato)
          );
        } catch (shiftError) {
          console.error("Error regenerating shifts after approve:", shiftError);
        }
      }
      
      // Invalidate alle relevante queries
      queryClient.invalidateQueries({ queryKey: ["ferie"] });
      queryClient.invalidateQueries({ queryKey: ['skift'] });
      queryClient.invalidateQueries({ queryKey: ['ansatt-turnus'] });
      queryClient.invalidateQueries({ queryKey: ['turnus-skift'] });
    } catch (error) {
      console.error("Error approving ferie:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke godkjenne feriesøknad",
        variant: "destructive"
      });
    }
  };

  const handleReject = async (ferieItem: any) => {
    try {
      const { error } = await supabase
        .from("ferie")
        .update({ status: "avslatt" })
        .eq("id", ferieItem.id);
      
      if (error) throw error;
      toast({ title: "Avslått", description: "Feriesøknaden ble avslått" });
      
      // Invalidate ferie query (ingen skift-regenerering nødvendig for avslag)
      queryClient.invalidateQueries({ queryKey: ["ferie"] });
    } catch (error) {
      console.error("Error rejecting ferie:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke avslå feriesøknad",
        variant: "destructive"
      });
    }
  };

  const exportToExcel = () => {
    const salon = salons.find(s => s.id === selectedSalonId);
    const exportData = ferie.map((f: any) => ({
      Ansatt: f.ansatte 
        ? `${f.ansatte.fornavn} ${f.ansatte.etternavn || ''}`.trim()
        : f.users?.name || "Ukjent",
      "Fra dato": f.startdato,
      "Til dato": f.sluttdato,
      Timer: f.timer,
      Status: f.status,
      Kommentar: f.kommentar || "-",
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Ferie");
    XLSX.writeFile(wb, `ferie-${salon?.name || "salong"}-${selectedYear}.xlsx`);
  };

  const slettEstimaterForAar = async () => {
    if (!selectedSalonId) return;
    
    try {
      const { error, count } = await supabase
        .from("ferie")
        .delete({ count: 'exact' })
        .eq("salon_id", selectedSalonId)
        .eq("aar", selectedYear)
        .eq("status", "estimat");
      
      if (error) throw error;
      
      toast({ 
        title: "Estimater slettet", 
        description: `${count || 0} estimat-poster for ${selectedYear} ble slettet` 
      });
      queryClient.invalidateQueries({ queryKey: ["ferie"] });
    } catch (error) {
      console.error("Error deleting estimates:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke slette estimater",
        variant: "destructive"
      });
    }
  };

  const refreshData = () => {
    queryClient.invalidateQueries({ queryKey: ["ferie"] });
    queryClient.invalidateQueries({ queryKey: ["ferie-overforing-inn"] });
    queryClient.invalidateQueries({ queryKey: ["ferie-overforing-ut"] });
  };

  if (authLoading || salonLoading) {
    return (
      <AppLayout title="Ferie" subtitle="Laster...">
        <div className="container mx-auto p-6 space-y-6">
          <Skeleton className="h-10 w-48" />
          <Skeleton className="h-96" />
        </div>
      </AppLayout>
    );
  }

  // Map ansatte to format expected by FerieAarligOversikt (using user_id)
  const ansatteForOversikt = ansatte.map(a => ({
    ...a,
    id: a.user_id || a.id, // Use user_id for matching with ferie
  }));

  return (
    <AppLayout title="Ferie" subtitle="Ferieregistrering og -oppfølging">
      <div className="container mx-auto p-6 space-y-6">
        {/* Controls */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSelectedYear(prev => prev - 1)}
              className="h-9 w-9"
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Select value={selectedYear.toString()} onValueChange={(v) => setSelectedYear(parseInt(v))}>
              <SelectTrigger className="w-28">
                <Calendar className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {years.map(y => (
                  <SelectItem key={y} value={y.toString()}>{y}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setSelectedYear(prev => prev + 1)}
              className="h-9 w-9"
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>

          {canManage && selectedSalonId && (
            <div className="flex flex-wrap items-center gap-2">
              <Button variant="outline" onClick={exportToExcel}>
                <Download className="h-4 w-4 mr-2" />
                Eksporter
              </Button>
              <Button variant="outline" onClick={() => setShowEstimatDialog(true)}>
                <Sparkles className="h-4 w-4 mr-2" />
                Generer ferieestimat
              </Button>
              <Button variant="outline" onClick={() => setShowRegelEditor(true)}>
                <Settings2 className="h-4 w-4 mr-2" />
                Tilpass ferieregler
              </Button>
              {ferie.some((f: any) => f.status === 'estimat') && (
                <Button 
                  variant="outline" 
                  onClick={slettEstimaterForAar}
                  className="text-destructive hover:text-destructive"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Slett estimater
                </Button>
              )}
              <Button variant="outline" onClick={() => setShowBulkDialog(true)}>
                <Users className="h-4 w-4 mr-2" />
                Flere ansatte
              </Button>
              <Button onClick={() => {
                setEditingFerie(null);
                setShowFerieDialog(true);
              }}>
                <Plus className="h-4 w-4 mr-2" />
                Ny registrering
              </Button>
            </div>
          )}
        </div>

        {selectedSalonId && (
          <div className="space-y-6">
            {/* Årlig oversikt */}
            <FerieAarligOversikt
              ansatte={ansatteForOversikt}
              ferie={ferie}
              overforingInn={overforingInn}
              overforingUt={overforingUt}
              selectedAar={selectedYear}
              onOverfor={handleOverfor}
            />

            {/* Kalender */}
            <LeaveCalendar
              salonId={selectedSalonId}
              year={selectedYear}
              onEditFerie={(ferieId) => {
                const ferieItem = ferie.find((f: any) => f.id === ferieId);
                if (ferieItem) {
                  handleEdit(ferieItem);
                }
              }}
            />

            {/* Ferietabell */}
            <FerieTabell
              ferie={ferie}
              isLoading={ferieLoading}
              onEdit={handleEdit}
              onDelete={handleDelete}
              onApprove={handleApprove}
              onReject={handleReject}
              canManage={canManage}
              ansatte={ansatte}
              selectedAnsattId={filterAnsattId}
              onAnsattChange={setFilterAnsattId}
            />
          </div>
        )}

        {/* Dialogs */}
        <FerieDialog
          open={showFerieDialog}
          onOpenChange={(open) => {
            setShowFerieDialog(open);
            if (!open) setEditingFerie(null);
          }}
          ansatte={ansatte}
          salonId={selectedSalonId || ""}
          ferie={editingFerie}
          onSuccess={refreshData}
        />

        <BulkFerieDialog
          open={showBulkDialog}
          onOpenChange={setShowBulkDialog}
          ansatte={ansatte}
          salonId={selectedSalonId || ""}
          onSuccess={refreshData}
        />

        <FerieEstimatGenerator
          open={showEstimatDialog}
          onOpenChange={setShowEstimatDialog}
          ansatte={ansatte}
          salonId={selectedSalonId || ""}
          currentYear={currentYear}
          eksisterendeEstimater={ferie}
          onSuccess={refreshData}
        />

        <FerieRegelEditor
          open={showRegelEditor}
          onOpenChange={setShowRegelEditor}
          salonId={selectedSalonId || ""}
        />

        {overforingData && (
          <FerieOverforingDialog
            open={showOverforingDialog}
            onOpenChange={(open) => {
              setShowOverforingDialog(open);
              if (!open) setOverforingData(null);
            }}
            ansattId={overforingData.ansattId}
            ansattNavn={overforingData.ansattNavn}
            tilgodeTimer={overforingData.tilgode}
            feriekravType={overforingData.feriekravType}
            fraAar={selectedYear}
            onSuccess={refreshData}
          />
        )}
      </div>
    </AppLayout>
  );
}
