import { useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Loader2, KeyRound, RefreshCw, Mail } from "lucide-react";
import haar1ForsikringLogo from "@/assets/haar1-forsikring-logo.png";

export default function FullmaktVerify() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const email = searchParams.get("email") || "";
  
  const [otp, setOtp] = useState("");
  const [isVerifying, setIsVerifying] = useState(false);
  const [isResending, setIsResending] = useState(false);

  const handleVerify = async () => {
    if (otp.length !== 6) {
      toast.error("Vennligst fyll inn alle 6 sifrene");
      return;
    }

    setIsVerifying(true);
    try {
      const { data, error } = await supabase.functions.invoke("verify-poa-otp", {
        body: {
          email,
          otp,
          ipAddress: "", // Could be captured client-side if needed
          userAgent: navigator.userAgent,
        },
      });

      if (error) {
        console.error("Verification error:", error);
        throw new Error("Verifisering feilet");
      }

      if (data?.error) {
        toast.error(data.error);
        if (data.code === "EXPIRED" || data.code === "TOO_MANY_ATTEMPTS") {
          setOtp("");
        }
        return;
      }

      toast.success("Fullmakten er signert!");
      navigate("/fullmakt/success");
    } catch (error: any) {
      console.error("Error verifying OTP:", error);
      toast.error(error.message || "En feil oppstod");
    } finally {
      setIsVerifying(false);
    }
  };

  const handleResendOtp = async () => {
    setIsResending(true);
    try {
      // Find the latest unsigned POA for this email
      const { data: poa, error: fetchError } = await supabase
        .from("insurance_power_of_attorney")
        .select("id")
        .eq("email", email)
        .eq("signed", false)
        .order("created_at", { ascending: false })
        .limit(1)
        .single();

      if (fetchError || !poa) {
        toast.error("Kunne ikke finne fullmakten. Vennligst start på nytt.");
        navigate("/fullmakt");
        return;
      }

      // Send new OTP
      const { data: otpResult, error: otpError } = await supabase.functions.invoke("send-poa-otp", {
        body: { poaId: poa.id, email },
      });

      if (otpError) {
        throw new Error("Kunne ikke sende ny kode");
      }

      // If email is disabled, show the test OTP
      if (otpResult?.testOtp) {
        toast.info(`Test-kode (e-post deaktivert): ${otpResult.testOtp}`);
      } else {
        toast.success("Ny kode sendt til din e-post");
      }

      setOtp("");
    } catch (error: any) {
      console.error("Error resending OTP:", error);
      toast.error(error.message || "En feil oppstod");
    } finally {
      setIsResending(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/30 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="text-center space-y-4">
          <div className="flex justify-center">
            <img src={haar1ForsikringLogo} alt="Hår1 Forsikring" className="h-16" />
          </div>
          <div className="space-y-2">
            <CardTitle className="text-2xl font-serif flex items-center justify-center gap-2">
              <KeyRound className="h-6 w-6 text-primary" />
              Verifiser fullmakt
            </CardTitle>
            <CardDescription className="text-base">
              Vi har sendt en 6-sifret kode til:
            </CardDescription>
            <div className="flex items-center justify-center gap-2 text-sm font-medium text-foreground bg-muted/50 py-2 px-4 rounded-lg">
              <Mail className="h-4 w-4" />
              {email}
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex flex-col items-center space-y-4">
            <InputOTP
              maxLength={6}
              value={otp}
              onChange={setOtp}
              disabled={isVerifying}
            >
              <InputOTPGroup>
                <InputOTPSlot index={0} />
                <InputOTPSlot index={1} />
                <InputOTPSlot index={2} />
                <InputOTPSlot index={3} />
                <InputOTPSlot index={4} />
                <InputOTPSlot index={5} />
              </InputOTPGroup>
            </InputOTP>
            <p className="text-sm text-muted-foreground">
              Koden er gyldig i 10 minutter
            </p>
          </div>

          <Button
            onClick={handleVerify}
            className="w-full"
            size="lg"
            disabled={isVerifying || otp.length !== 6}
          >
            {isVerifying ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Verifiserer...
              </>
            ) : (
              "Bekreft signatur"
            )}
          </Button>

          <div className="border-t pt-4 space-y-3">
            <p className="text-sm text-center text-muted-foreground">
              Fikk du ikke koden?
            </p>
            <div className="flex flex-col sm:flex-row gap-2 justify-center">
              <Button
                variant="outline"
                size="sm"
                onClick={handleResendOtp}
                disabled={isResending}
              >
                {isResending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <RefreshCw className="mr-2 h-4 w-4" />
                )}
                Send ny kode
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate("/fullmakt")}
              >
                Start på nytt
              </Button>
            </div>
            <p className="text-xs text-center text-muted-foreground">
              Sjekk også søppelpost/spam-mappen
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
