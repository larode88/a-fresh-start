// BudsjettPage - Min Salong module page for budget management
// This is a minimal compilable React + TypeScript page

import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { TrendingUp, DollarSign, Users, Target } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "@/hooks/use-toast";
import { useSalonContext } from "@/components/SalonSelector";
import { AppLayout } from "@/components/AppLayout";
import { 
  getBudgetsBySalon, 
  getBudgetSummary, 
  getActiveBudgetVersion 
} from "@/integrations/supabase/budgetsService";

const BudsjettPage = () => {
  const navigate = useNavigate();
  const { user, profile, loading: authLoading } = useAuth();
  const { selectedSalonId } = useSalonContext();
  const [loading, setLoading] = useState(true);
  const [budgetSummary, setBudgetSummary] = useState<any>(null);
  const [versionId, setVersionId] = useState<string | null>(null);

  const canAccess = ['salon_owner', 'daglig_leder', 'avdelingsleder', 'admin', 'district_manager'].includes(profile?.role || '');

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/login");
      return;
    }

    if (!authLoading && profile && !canAccess) {
      toast({
        title: "Ingen tilgang",
        description: "Du har ikke tilgang til budsjettoversikten",
        variant: "destructive",
      });
      navigate("/dashboard");
    }
  }, [user, profile, authLoading, navigate, canAccess]);

  const activeSalonId = selectedSalonId || profile?.salon_id;

  useEffect(() => {
    if (!activeSalonId) return;

    const fetchBudgetData = async () => {
      setLoading(true);
      try {
        const currentYear = new Date().getFullYear();
        
        // Get active budget version
        const version = await getActiveBudgetVersion(activeSalonId, currentYear);
        
        if (version) {
          setVersionId(version.id);
          
          // Get budget summary
          const summary = await getBudgetSummary(activeSalonId, version.id);
          setBudgetSummary(summary);
        } else {
          setBudgetSummary(null);
          setVersionId(null);
        }
      } catch (error) {
        console.error("Error fetching budget data:", error);
        toast({
          title: "Feil",
          description: "Kunne ikke laste budsjettdata",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    fetchBudgetData();
  }, [activeSalonId]);

  if (authLoading || loading) {
    return (
      <AppLayout title="Budsjett & Mål" subtitle="Min Salong - Oversikt over budsjett og mål">
        <div className="container mx-auto px-4 py-8 space-y-6">
          <Skeleton className="h-32 w-full" />
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-32 w-full" />
            <Skeleton className="h-32 w-full" />
          </div>
        </div>
      </AppLayout>
    );
  }

  if (!activeSalonId) {
    return (
      <AppLayout title="Budsjett & Mål" subtitle="Min Salong - Oversikt over budsjett og mål">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center py-12">
            <TrendingUp className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h2 className="text-lg font-semibold mb-2">Velg en salong</h2>
            <p className="text-muted-foreground">
              Velg en salong for å se budsjettoversikt
            </p>
          </div>
        </div>
      </AppLayout>
    );
  }

  if (!budgetSummary || !versionId) {
    return (
      <AppLayout title="Budsjett & Mål" subtitle="Min Salong - Oversikt over budsjett og mål">
        <div className="container mx-auto px-4 py-8">
          <Card>
            <CardContent className="py-12 text-center">
              <TrendingUp className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">Ingen aktivt budsjett</h3>
              <p className="text-muted-foreground">
                Det er ingen aktivt budsjett for inneværende år
              </p>
            </CardContent>
          </Card>
        </div>
      </AppLayout>
    );
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('nb-NO', {
      style: 'currency',
      currency: 'NOK',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <AppLayout title="Budsjett & Mål" subtitle="Min Salong - Oversikt over budsjett og mål">
      <div className="container mx-auto px-4 py-8 space-y-6">
        <div>
          <h2 className="text-2xl font-bold">Budsjettoversikt</h2>
          <p className="text-muted-foreground">
            Oversikt over budsjett og økonomiske mål
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Totalt budsjett
              </CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {formatCurrency(budgetSummary.total_budget)}
              </div>
              <p className="text-xs text-muted-foreground">
                For inneværende år
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Behandling
              </CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {formatCurrency(budgetSummary.total_behandling)}
              </div>
              <p className="text-xs text-muted-foreground">
                Budsjettert behandlingsinntekt
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Varesalg
              </CardTitle>
              <Target className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {formatCurrency(budgetSummary.total_vare)}
              </div>
              <p className="text-xs text-muted-foreground">
                Budsjettert varesalg
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                Ansatte
              </CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {budgetSummary.employee_count}
              </div>
              <p className="text-xs text-muted-foreground">
                I budsjett
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Kundetimer</CardTitle>
              <CardDescription>Planlagte vs. estimerte kundetimer</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Planlagte timer:</span>
                <span className="font-semibold">
                  {budgetSummary.total_planlagte_timer?.toFixed(1) || '0'} timer
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Kundetimer:</span>
                <span className="font-semibold">
                  {budgetSummary.total_kundetimer?.toFixed(1) || '0'} timer
                </span>
              </div>
              {budgetSummary.total_planlagte_timer > 0 && (
                <div className="flex justify-between pt-2 border-t">
                  <span className="text-muted-foreground">Utnyttelse:</span>
                  <span className="font-semibold">
                    {((budgetSummary.total_kundetimer / budgetSummary.total_planlagte_timer) * 100).toFixed(1)}%
                  </span>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Omsetning per time</CardTitle>
              <CardDescription>Gjennomsnittlig timesinntekt</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">
                {formatCurrency(budgetSummary.avg_omsetning_per_time || 0)}
              </div>
              <p className="text-xs text-muted-foreground mt-2">
                Per kundetime
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
};

export default BudsjettPage;
