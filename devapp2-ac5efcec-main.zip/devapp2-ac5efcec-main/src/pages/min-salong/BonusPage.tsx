import { AppLayout } from "@/components/AppLayout";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useSalonContext } from "@/components/SalonSelector";
import { supabase } from "@/integrations/supabase/client";
import { BonusSummaryCards } from "@/components/bonus/salon/BonusSummaryCards";
import { GrowthBonusCard, calculateGrowthBonus } from "@/components/bonus/salon/GrowthBonusCard";
import { MonthlyPurchaseChart } from "@/components/bonus/salon/MonthlyPurchaseChart";
import { BrandBreakdownTable } from "@/components/bonus/salon/BrandBreakdownTable";
import { Skeleton } from "@/components/ui/skeleton";
import { Package } from "lucide-react";

const LOREAL_SUPPLIER_ID = "ba0636af-39df-4a0b-9792-79a3784f3970"; // L'Oréal supplier ID in leverandorer table

export default function BonusPage() {
  const { selectedSalonId } = useSalonContext();
  const currentYear = new Date().getFullYear();
  const [selectedYear, setSelectedYear] = useState(currentYear);
  const [selectedSupplierId, setSelectedSupplierId] = useState<string>('all');

  // Fetch suppliers that have bonus data for this salon (from leverandorer table)
  const { data: salonSuppliers, isLoading: loadingSuppliers } = useQuery({
    queryKey: ['salon-bonus-suppliers', selectedSalonId],
    queryFn: async () => {
      if (!selectedSalonId) return [];
      
      // Get suppliers from bonus_calculations that have data for this salon
      const { data, error } = await supabase
        .from('bonus_calculations')
        .select('supplier_id, leverandorer!inner(id, navn)')
        .eq('salon_id', selectedSalonId);
      
      if (error) throw error;
      
      // Deduplicate suppliers
      const uniqueSuppliers = new Map<string, { id: string; name: string }>();
      (data || []).forEach(item => {
        const lev = item.leverandorer as any;
        if (lev && !uniqueSuppliers.has(lev.id)) {
          uniqueSuppliers.set(lev.id, { id: lev.id, name: lev.navn });
        }
      });
      
      return Array.from(uniqueSuppliers.values());
    },
    enabled: !!selectedSalonId
  });

  // Fetch bonus calculations for salon
  const { data: bonusData, isLoading: loadingBonus } = useQuery({
    queryKey: ['salon-bonus', selectedSalonId, selectedSupplierId, selectedYear],
    queryFn: async () => {
      if (!selectedSalonId) return null;
      
      // Get all calculations for the salon and year
      const startPeriod = `${selectedYear}-01`;
      const endPeriod = `${selectedYear}-12`;
      
      let query = supabase
        .from('bonus_calculations')
        .select('*')
        .eq('salon_id', selectedSalonId)
        .gte('period', startPeriod)
        .lte('period', endPeriod);
      
      // Filter by supplier if not "all"
      if (selectedSupplierId !== 'all') {
        query = query.eq('supplier_id', selectedSupplierId);
      }
      
      const { data, error } = await query;
      
      if (error) throw error;
      
      // Aggregate totals - exclude return commission from display
      const totals = {
        totalTurnover: 0,
        loyaltyBonus: 0,
        totalBonus: 0 // Only loyalty bonus visible to members
      };
      
      (data || []).forEach(calc => {
        totals.totalTurnover += calc.total_turnover || 0;
        totals.loyaltyBonus += calc.loyalty_bonus_amount || 0;
        totals.totalBonus += calc.loyalty_bonus_amount || 0; // Only loyalty, NOT return commission
      });
      
      return {
        calculations: data || [],
        totals
      };
    },
    enabled: !!selectedSalonId
  });

  // Fetch previous year data for comparison
  const { data: previousYearData } = useQuery({
    queryKey: ['salon-bonus-prev', selectedSalonId, selectedSupplierId, selectedYear - 1],
    queryFn: async () => {
      if (!selectedSalonId) return null;
      
      const startPeriod = `${selectedYear - 1}-01`;
      const endPeriod = `${selectedYear - 1}-12`;
      
      let query = supabase
        .from('bonus_calculations')
        .select('total_turnover')
        .eq('salon_id', selectedSalonId)
        .gte('period', startPeriod)
        .lte('period', endPeriod);
      
      // Filter by supplier if not "all"
      if (selectedSupplierId !== 'all') {
        query = query.eq('supplier_id', selectedSupplierId);
      }
      
      const { data, error } = await query;
      
      if (error) return null;
      
      return (data || []).reduce((sum, calc) => sum + (calc.total_turnover || 0), 0);
    },
    enabled: !!selectedSalonId
  });

  // Fetch L'Oréal specific data for growth bonus (always, regardless of selected supplier)
  const { data: lorealCurrentYearData } = useQuery({
    queryKey: ['salon-loreal-bonus', selectedSalonId, selectedYear],
    queryFn: async () => {
      if (!selectedSalonId) return 0;
      
      const startPeriod = `${selectedYear}-01`;
      const endPeriod = `${selectedYear}-12`;
      
      const { data, error } = await supabase
        .from('bonus_calculations')
        .select('total_turnover')
        .eq('salon_id', selectedSalonId)
        .eq('supplier_id', LOREAL_SUPPLIER_ID)
        .gte('period', startPeriod)
        .lte('period', endPeriod);
      
      if (error) return 0;
      return (data || []).reduce((sum, c) => sum + (c.total_turnover || 0), 0);
    },
    enabled: !!selectedSalonId
  });

  // Fetch L'Oréal previous year for growth bonus comparison
  const { data: lorealPrevYearData } = useQuery({
    queryKey: ['salon-loreal-prev', selectedSalonId, selectedYear - 1],
    queryFn: async () => {
      if (!selectedSalonId) return 0;
      
      const startPeriod = `${selectedYear - 1}-01`;
      const endPeriod = `${selectedYear - 1}-12`;
      
      const { data, error } = await supabase
        .from('bonus_calculations')
        .select('total_turnover')
        .eq('salon_id', selectedSalonId)
        .eq('supplier_id', LOREAL_SUPPLIER_ID)
        .gte('period', startPeriod)
        .lte('period', endPeriod);
      
      if (error) return 0;
      return (data || []).reduce((sum, c) => sum + (c.total_turnover || 0), 0);
    },
    enabled: !!selectedSalonId
  });

  // Fetch baseline override for L'Oréal (if exists) - for salons with incomplete previous year data
  const { data: lorealBaselineOverride } = useQuery({
    queryKey: ['salon-loreal-baseline-override', selectedSalonId, selectedYear - 1],
    queryFn: async () => {
      if (!selectedSalonId) return null;
      
      const { data, error } = await supabase
        .from('bonus_baseline_overrides')
        .select('override_turnover, reason')
        .eq('salon_id', selectedSalonId)
        .eq('supplier_id', LOREAL_SUPPLIER_ID)
        .eq('year', selectedYear - 1)
        .maybeSingle();
      
      if (error) return null;
      return data;
    },
    enabled: !!selectedSalonId
  });


  // Fetch monthly brand data for chart (from calculation_details with delta values)
  const { data: monthlyBrandData, isLoading: loadingMonthly } = useQuery({
    queryKey: ['salon-monthly-brand', selectedSalonId, selectedSupplierId, selectedYear],
    queryFn: async () => {
      if (!selectedSalonId) return [];
      
      const startPeriod = `${selectedYear}-01`;
      const endPeriod = `${selectedYear}-12`;
      
      let query = supabase
        .from('bonus_calculations')
        .select('period, calculation_details')
        .eq('salon_id', selectedSalonId)
        .gte('period', startPeriod)
        .lte('period', endPeriod)
        .order('period');
      
      // Filter by supplier if not "all"
      if (selectedSupplierId !== 'all') {
        query = query.eq('supplier_id', selectedSupplierId);
      }
      
      const { data, error } = await query;
      
      if (error) throw error;
      
      // Transform calculation_details to chart format
      return (data || []).flatMap(calc => {
        const details = (calc.calculation_details as any)?.details || [];
        return details.map((detail: any) => ({
          reported_period: calc.period,
          reported_value: detail.turnover ?? 0,
          brand: detail.brand,
          product_group: detail.product_group
        }));
      });
    },
    enabled: !!selectedSalonId
  });

  // Fetch previous year monthly data for comparison
  const { data: prevYearMonthlyData } = useQuery({
    queryKey: ['salon-monthly-brand-prev', selectedSalonId, selectedSupplierId, selectedYear - 1],
    queryFn: async () => {
      if (!selectedSalonId) return [];
      
      const startPeriod = `${selectedYear - 1}-01`;
      const endPeriod = `${selectedYear - 1}-12`;
      
      let query = supabase
        .from('bonus_calculations')
        .select('period, calculation_details')
        .eq('salon_id', selectedSalonId)
        .gte('period', startPeriod)
        .lte('period', endPeriod)
        .order('period');
      
      // Filter by supplier if not "all"
      if (selectedSupplierId !== 'all') {
        query = query.eq('supplier_id', selectedSupplierId);
      }
      
      const { data, error } = await query;
      
      if (error) return [];
      
      // Transform calculation_details to chart format
      return (data || []).flatMap(calc => {
        const details = (calc.calculation_details as any)?.details || [];
        return details.map((detail: any) => ({
          reported_period: calc.period,
          reported_value: detail.turnover ?? 0,
          brand: detail.brand,
          product_group: detail.product_group
        }));
      });
    },
    enabled: !!selectedSalonId
  });


  // L'Oréal growth bonus - use baseline override if available for incomplete previous year data
  const effectiveLorealPrevYear = lorealBaselineOverride?.override_turnover ?? (lorealPrevYearData || 0);
  const hasAnyLorealPurchases = (lorealCurrentYearData || 0) > 0;
  const isNewLorealCustomer = effectiveLorealPrevYear === 0 && (lorealCurrentYearData || 0) > 0;
  const lorealGrowthPercent = effectiveLorealPrevYear > 0 
    ? ((lorealCurrentYearData || 0) - effectiveLorealPrevYear) / effectiveLorealPrevYear * 100
    : 0;
  
  // Calculate growth bonus amount to include in total
  const lorealGrowthBonusData = calculateGrowthBonus(
    lorealGrowthPercent,
    lorealCurrentYearData || 0,
    effectiveLorealPrevYear
  );
  
  // Total bonus includes loyalty + growth bonus
  const finalTotalBonus = (bonusData?.totals?.loyaltyBonus || 0) + (lorealGrowthBonusData?.totalBonus || 0);

  const years = Array.from({ length: 3 }, (_, i) => currentYear - i);

  if (!selectedSalonId) {
    return (
      <AppLayout>
        <div className="container mx-auto py-6">
          <div className="text-center text-muted-foreground py-12">
            Velg en salong for å se bonusoversikt
          </div>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="container mx-auto py-6 space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-serif font-semibold">Innkjøp & Bonus</h1>
            <p className="text-muted-foreground mt-1">
              Se din bonusoversikt og innkjøpshistorikk
            </p>
          </div>
          
          {/* Filters */}
          <div className="flex gap-3">
            <Select
              value={selectedSupplierId}
              onValueChange={setSelectedSupplierId}
              disabled={loadingSuppliers}
            >
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Velg leverandør" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Alle leverandører</SelectItem>
                {salonSuppliers?.map(supplier => (
                  <SelectItem key={supplier.id} value={supplier.id}>
                    {supplier.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select
              value={selectedYear.toString()}
              onValueChange={(v) => setSelectedYear(parseInt(v))}
            >
              <SelectTrigger className="w-[100px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {years.map(year => (
                  <SelectItem key={year} value={year.toString()}>
                    {year}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {loadingSuppliers ? (
          <div className="space-y-6">
            <div className="grid gap-4 md:grid-cols-3">
              <Skeleton className="h-32" />
              <Skeleton className="h-32" />
              <Skeleton className="h-32" />
            </div>
          </div>
        ) : salonSuppliers?.length === 0 ? (
          <div className="text-center py-12 border rounded-xl bg-muted/20">
            <Package className="h-12 w-12 mx-auto text-muted-foreground/50 mb-4" />
            <p className="text-muted-foreground">
              Ingen leverandører er koblet til denne salongen ennå.
            </p>
          </div>
        ) : (
          <>
            {/* Summary Cards */}
            <BonusSummaryCards
              totalTurnover={bonusData?.totals?.totalTurnover || 0}
              loyaltyBonus={bonusData?.totals?.loyaltyBonus || 0}
              totalBonus={finalTotalBonus}
              previousYearTurnover={previousYearData || 0}
              isLoading={loadingBonus}
              growthBonus={lorealGrowthBonusData?.totalBonus || 0}
            />

            {/* Growth Bonus Card - Shows for L'Oréal purchases regardless of selected supplier */}
            {hasAnyLorealPurchases && (
              <GrowthBonusCard
                currentYearTurnover={lorealCurrentYearData || 0}
                previousYearTurnover={effectiveLorealPrevYear}
                growthPercent={lorealGrowthPercent}
                year={selectedYear}
                supplierName={selectedSupplierId === 'all' ? "L'Oréal" : undefined}
              />
            )}

            {/* Monthly Chart */}
            <MonthlyPurchaseChart
              currentYearData={monthlyBrandData || []}
              previousYearData={prevYearMonthlyData || []}
              selectedYear={selectedYear}
              isLoading={loadingMonthly}
            />

            {/* Brand Breakdown Table */}
            <BrandBreakdownTable
              salonId={selectedSalonId}
              supplierId={selectedSupplierId}
              year={selectedYear}
            />
          </>
        )}
      </div>
    </AppLayout>
  );
}
