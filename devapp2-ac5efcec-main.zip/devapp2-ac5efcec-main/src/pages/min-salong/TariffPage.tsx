import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { Calculator } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { useSalonContext } from "@/components/SalonSelector";
import { AppLayout } from "@/components/AppLayout";
import { SalonTariffSettings } from "@/components/employees/SalonTariffSettings";

const TariffPage = () => {
  const navigate = useNavigate();
  const { user, profile, loading: authLoading } = useAuth();
  const { selectedSalonId } = useSalonContext();

  const canAccess = ['salon_owner', 'daglig_leder', 'avdelingsleder', 'admin', 'district_manager'].includes(profile?.role || '');

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/login");
      return;
    }

    if (!authLoading && profile && !canAccess) {
      toast({
        title: "Ingen tilgang",
        description: "Du har ikke tilgang til tariff-innstillinger",
        variant: "destructive",
      });
      navigate("/dashboard");
    }
  }, [user, profile, authLoading, navigate, canAccess]);

  const activeSalonId = selectedSalonId || profile?.salon_id;

  if (authLoading) {
    return (
      <AppLayout title="Tariff" subtitle="Min Salong - Tariffinnstillinger">
        <div className="container mx-auto px-4 py-8">
          <div className="flex justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        </div>
      </AppLayout>
    );
  }

  if (!activeSalonId) {
    return (
      <AppLayout title="Tariff" subtitle="Min Salong - Tariffinnstillinger">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center py-12">
            <Calculator className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h2 className="text-lg font-semibold mb-2">Velg en salong</h2>
            <p className="text-muted-foreground">
              Velg en salong for å se tariffinnstillinger
            </p>
          </div>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout title="Tariff" subtitle="Min Salong - Tariffinnstillinger">
      <div className="container mx-auto px-4 py-8">
        <SalonTariffSettings salonId={activeSalonId} />
      </div>
    </AppLayout>
  );
};

export default TariffPage;
