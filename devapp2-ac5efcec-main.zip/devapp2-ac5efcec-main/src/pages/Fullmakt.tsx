import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Loader2, FileSignature, CheckCircle2 } from "lucide-react";
import haar1ForsikringLogo from "@/assets/haar1-forsikring-logo.png";
import { lookupOrgNumber } from "@/lib/brreg";

const formSchema = z.object({
  salon_name: z.string().min(2, "Salongnavn må ha minst 2 tegn"),
  org_number: z.string().regex(/^\d{9}$/, "Organisasjonsnummer må være 9 siffer"),
  contact_name: z.string().min(2, "Kontaktperson må ha minst 2 tegn"),
  email: z.string().email("Ugyldig e-postadresse"),
  phone: z.string().min(8, "Telefonnummer må ha minst 8 siffer"),
  consent_transfer: z.boolean().refine(val => val === true, "Du må godta fullmakten"),
  consent_privacy: z.boolean().refine(val => val === true, "Du må godta personvernvilkårene"),
});

type FormValues = z.infer<typeof formSchema>;

export default function Fullmakt() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLookingUp, setIsLookingUp] = useState(false);
  const [orgVerified, setOrgVerified] = useState(false);
  const [existingPoaId, setExistingPoaId] = useState<string | null>(null);
  const [isLoadingPoa, setIsLoadingPoa] = useState(false);

  // Check if coming from quote acceptance
  const fromQuote = searchParams.get("fromQuote");
  const prefillSalonName = searchParams.get("salon_name");
  const prefillOrgNumber = searchParams.get("org_number");
  const prefillContactName = searchParams.get("contact_name");
  const prefillEmail = searchParams.get("email");
  const prefillPhone = searchParams.get("phone");

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      salon_name: prefillSalonName || "",
      org_number: prefillOrgNumber || "",
      contact_name: prefillContactName || "",
      email: prefillEmail || "",
      phone: prefillPhone || "",
      consent_transfer: false,
      consent_privacy: false,
    },
  });

  const orgNumber = form.watch("org_number");

  // If coming from quote, look up existing POA
  useEffect(() => {
    if (fromQuote) {
      loadExistingPoa(fromQuote);
    }
  }, [fromQuote]);

  const loadExistingPoa = async (quoteId: string) => {
    setIsLoadingPoa(true);
    try {
      // Find POA linked to this quote
      const { data: poa, error } = await supabase
        .from("insurance_power_of_attorney")
        .select("*")
        .eq("quote_id", quoteId)
        .eq("signed", false)
        .order("created_at", { ascending: false })
        .limit(1)
        .single();

      if (poa && !error) {
        console.log("Found existing POA for quote:", poa.id);
        setExistingPoaId(poa.id);
        
        // Pre-fill form with POA data
        form.setValue("salon_name", poa.salon_name);
        form.setValue("org_number", poa.org_number);
        form.setValue("contact_name", poa.contact_name);
        form.setValue("email", poa.email);
        form.setValue("phone", poa.phone || "");
        setOrgVerified(true);
      } else {
        console.log("No existing POA found for quote, using prefilled data");
        // Use prefilled data from URL params
        if (prefillOrgNumber) {
          setOrgVerified(true);
        }
      }
    } catch (err) {
      console.error("Error loading existing POA:", err);
    } finally {
      setIsLoadingPoa(false);
    }
  };

  // Auto-lookup when org number is 9 digits (only if not coming from quote with prefilled data)
  useEffect(() => {
    if (fromQuote && prefillOrgNumber) {
      // Skip lookup if we have prefilled data from quote
      return;
    }
    
    const cleanedOrgNumber = orgNumber?.replace(/\s/g, '') || '';
    
    if (cleanedOrgNumber.length === 9 && /^\d{9}$/.test(cleanedOrgNumber)) {
      handleOrgLookup(cleanedOrgNumber);
    } else {
      // Reset if org number changes to invalid
      if (orgVerified && !fromQuote) {
        setOrgVerified(false);
        form.setValue("salon_name", "");
      }
    }
  }, [orgNumber, fromQuote, prefillOrgNumber]);

  const handleOrgLookup = async (orgNum: string) => {
    setIsLookingUp(true);
    setOrgVerified(false);
    
    try {
      const result = await lookupOrgNumber(orgNum);
      form.setValue("salon_name", result.juridiskNavn);
      setOrgVerified(true);
    } catch (error: any) {
      toast.error(error.message || "Kunne ikke hente informasjon fra Brønnøysundregistrene");
      form.setValue("salon_name", "");
      setOrgVerified(false);
    } finally {
      setIsLookingUp(false);
    }
  };

  const onSubmit = async (values: FormValues) => {
    if (!orgVerified) {
      toast.error("Vennligst skriv inn et gyldig organisasjonsnummer");
      return;
    }
    
    setIsSubmitting(true);
    try {
      let poaId = existingPoaId;

      if (existingPoaId) {
        // Update existing POA with consent
        const { error: updateError } = await supabase
          .from("insurance_power_of_attorney")
          .update({
            consent_transfer: values.consent_transfer,
            consent_privacy: values.consent_privacy,
            contact_name: values.contact_name,
            phone: values.phone || null,
          })
          .eq("id", existingPoaId);

        if (updateError) {
          console.error("Error updating POA:", updateError);
          throw new Error("Kunne ikke oppdatere fullmakt");
        }
      } else {
        // Check for existing unsigned POA with same org_number and email to prevent duplicates
        const { data: existingPoa } = await supabase
          .from("insurance_power_of_attorney")
          .select("id")
          .eq("org_number", values.org_number)
          .eq("email", values.email)
          .eq("signed", false)
          .order("created_at", { ascending: false })
          .limit(1)
          .single();

        if (existingPoa) {
          // Use existing POA instead of creating duplicate
          console.log("Found existing unsigned POA, reusing:", existingPoa.id);
          poaId = existingPoa.id;
          
          // Update it with latest consent values
          await supabase
            .from("insurance_power_of_attorney")
            .update({
              salon_name: values.salon_name,
              contact_name: values.contact_name,
              phone: values.phone || null,
              consent_transfer: values.consent_transfer,
              consent_privacy: values.consent_privacy,
            })
            .eq("id", existingPoa.id);
        } else {
          // Create new POA record (standalone flow, not from quote)
          const tempHash = crypto.randomUUID();
          
          const { data: poa, error: insertError } = await supabase
            .from("insurance_power_of_attorney")
            .insert({
              salon_name: values.salon_name,
              org_number: values.org_number,
              contact_name: values.contact_name,
              email: values.email,
              phone: values.phone || null,
              consent_transfer: values.consent_transfer,
              consent_privacy: values.consent_privacy,
              otp_code_hash: tempHash,
              otp_expires_at: new Date(Date.now() + 10 * 60 * 1000).toISOString(),
            })
            .select()
            .single();

          if (insertError) {
            console.error("Error creating POA:", insertError);
            throw new Error("Kunne ikke opprette fullmakt");
          }
          poaId = poa.id;
        }
      }

      // Send OTP via edge function
      const { data: otpResult, error: otpError } = await supabase.functions.invoke("send-poa-otp", {
        body: { poaId, email: values.email },
      });

      if (otpError) {
        console.error("Error sending OTP:", otpError);
        throw new Error("Kunne ikke sende verifiseringskode");
      }

      // If email is disabled, show the test OTP in a toast
      if (otpResult?.testOtp) {
        toast.info(`Test-kode (e-post deaktivert): ${otpResult.testOtp}`);
      }

      toast.success("Verifiseringskode sendt til din e-post");
      navigate(`/fullmakt/verify?email=${encodeURIComponent(values.email)}`);
    } catch (error: any) {
      console.error("Error submitting form:", error);
      toast.error(error.message || "En feil oppstod");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoadingPoa) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-background to-muted/30 flex items-center justify-center p-4">
        <Card className="w-full max-w-lg shadow-lg">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary mb-4" />
            <p className="text-muted-foreground">Laster fullmakt...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/30 flex items-center justify-center p-4">
      <Card className="w-full max-w-lg shadow-lg">
        <CardHeader className="text-center space-y-4">
          <div className="flex justify-center">
            <img src={haar1ForsikringLogo} alt="Hår1 Forsikring" className="h-16" />
          </div>
          <div className="space-y-2">
            <CardTitle className="text-2xl font-serif flex items-center justify-center gap-2">
              <FileSignature className="h-6 w-6 text-primary" />
              Fullmakt for overføring av forsikringer
            </CardTitle>
            <CardDescription className="text-base">
              Ved å signere denne fullmakten gir du Hår1 rett til å innhente, flytte og si opp forsikringer på dine vegne.
            </CardDescription>
          </div>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="space-y-4">
                <FormField
                  control={form.control}
                  name="org_number"
                  render={({ field }) => {
                    // Format display value with spaces (123 456 789)
                    const displayValue = field.value.replace(/(\d{3})(?=\d)/g, '$1 ');
                    
                    return (
                      <FormItem>
                        <FormLabel>Organisasjonsnummer *</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <Input 
                              placeholder="123 456 789" 
                              maxLength={11}
                              value={displayValue}
                              onChange={(e) => {
                                // Remove all non-digits, limit to 9
                                const digits = e.target.value.replace(/\D/g, '').slice(0, 9);
                                field.onChange(digits);
                              }}
                              className={orgVerified ? "pr-10 border-green-500" : ""}
                              readOnly={!!fromQuote}
                            />
                            {isLookingUp && (
                              <div className="absolute right-3 top-1/2 -translate-y-1/2">
                                <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                              </div>
                            )}
                            {orgVerified && !isLookingUp && (
                              <div className="absolute right-3 top-1/2 -translate-y-1/2">
                                <CheckCircle2 className="h-4 w-4 text-green-500" />
                              </div>
                            )}
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    );
                  }}
                />

                <FormField
                  control={form.control}
                  name="salon_name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Salongnavn (fra Brønnøysund)</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder={isLookingUp ? "Henter..." : "Fylles ut automatisk fra org.nr"} 
                          {...field} 
                          readOnly
                          className="bg-muted/50"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="contact_name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Kontaktperson *</FormLabel>
                      <FormControl>
                        <Input placeholder="Fullt navn" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>E-post *</FormLabel>
                      <FormControl>
                        <Input 
                          type="email" 
                          placeholder="din@epost.no" 
                          {...field} 
                          readOnly={!!fromQuote}
                          className={fromQuote ? "bg-muted/50" : ""}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Telefon *</FormLabel>
                      <FormControl>
                        <Input type="tel" placeholder="+47 xxx xx xxx" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="space-y-4 pt-4 border-t">
                <FormField
                  control={form.control}
                  name="consent_transfer"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel className="text-sm font-normal cursor-pointer">
                          Jeg gir Hår1 fullmakt til å innhente, flytte og si opp forsikringer på mine vegne. *
                        </FormLabel>
                        <FormMessage />
                      </div>
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="consent_privacy"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel className="text-sm font-normal cursor-pointer">
                          Jeg samtykker til behandling av personopplysninger iht. personvernlovgivningen. *
                        </FormLabel>
                        <FormMessage />
                      </div>
                    </FormItem>
                  )}
                />
              </div>

              <Button 
                type="submit" 
                className="w-full" 
                size="lg" 
                disabled={isSubmitting || !orgVerified}
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Sender kode...
                  </>
                ) : (
                  "Send signeringskode →"
                )}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
