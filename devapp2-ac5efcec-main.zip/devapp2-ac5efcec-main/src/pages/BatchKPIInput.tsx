import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { useSalonContext } from "@/components/SalonSelector";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { getISOWeek, getISOWeekYear } from "date-fns";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { WeekSelector } from "@/components/WeekSelector";
import { ArrowLeft, Save, Users, Check, AlertCircle } from "lucide-react";
import { NavLink } from "@/components/NavLink";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";

interface TeamMember {
  id: string;
  name: string;
  role: string;
  avatar_url: string | null;
}

interface KPIData {
  treatmentRevenue: number;
  retailRevenue: number;
  visitCount: number;
  visitsWithAddon: number;
  addonCount: number;
  rebookedVisits: number;
  hoursWorked: number;
  hoursWithClient: number;
}

interface TeamMemberKPI extends TeamMember {
  kpiData: KPIData;
  existingDataId: string | null;
  hasData: boolean;
  isDirty: boolean;
}

const MANAGER_ROLES = ['salon_owner', 'daglig_leder', 'avdelingsleder', 'admin'];

const emptyKPIData: KPIData = {
  treatmentRevenue: 0,
  retailRevenue: 0,
  visitCount: 0,
  visitsWithAddon: 0,
  addonCount: 0,
  rebookedVisits: 0,
  hoursWorked: 0,
  hoursWithClient: 0,
};

export default function BatchKPIInput() {
  const { profile, loading } = useAuth();
  const { selectedSalonId } = useSalonContext();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [submitting, setSubmitting] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [teamKPIs, setTeamKPIs] = useState<TeamMemberKPI[]>([]);
  const [loadingData, setLoadingData] = useState(true);

  const isManager = profile?.role && MANAGER_ROLES.includes(profile.role);
  const salonId = selectedSalonId || profile?.salon_id;

  useEffect(() => {
    if (!loading && !profile) {
      navigate("/login");
    }
    if (!loading && profile && !isManager) {
      navigate("/kpi-input");
    }
  }, [loading, profile, navigate, isManager]);

  useEffect(() => {
    if (salonId) {
      fetchTeamAndData();
    }
  }, [salonId, selectedDate]);

  const fetchTeamAndData = async () => {
    if (!salonId) return;
    
    setLoadingData(true);
    try {
      const week = getISOWeek(selectedDate);
      const year = getISOWeekYear(selectedDate);

      // Fetch team members
      const { data: teamData, error: teamError } = await supabase
        .from("users")
        .select("id, name, role, avatar_url")
        .eq("salon_id", salonId)
        .order("name");

      if (teamError) throw teamError;

      // Fetch existing KPI data for this week
      const { data: kpiData, error: kpiError } = await supabase
        .from("weekly_kpi_inputs")
        .select("*")
        .eq("salon_id", salonId)
        .eq("week", week)
        .eq("year", year);

      if (kpiError) throw kpiError;

      // Map team members with their KPI data
      const teamWithKPIs: TeamMemberKPI[] = (teamData || []).map((member) => {
        const existingData = kpiData?.find(k => k.stylist_id === member.id);
        return {
          ...member,
          existingDataId: existingData?.id || null,
          hasData: !!existingData,
          isDirty: false,
          kpiData: existingData ? {
            treatmentRevenue: existingData.treatment_revenue,
            retailRevenue: existingData.retail_revenue,
            visitCount: existingData.visit_count,
            visitsWithAddon: existingData.visits_with_addon,
            addonCount: existingData.addon_count,
            rebookedVisits: existingData.rebooked_visits,
            hoursWorked: existingData.hours_worked,
            hoursWithClient: existingData.hours_with_client,
          } : { ...emptyKPIData },
        };
      });

      setTeamKPIs(teamWithKPIs);
    } catch (error) {
      console.error("Error fetching team data:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke hente teamdata",
        variant: "destructive",
      });
    } finally {
      setLoadingData(false);
    }
  };

  const updateMemberKPI = (memberId: string, field: keyof KPIData, value: number) => {
    setTeamKPIs(prev => prev.map(member => {
      if (member.id === memberId) {
        return {
          ...member,
          isDirty: true,
          kpiData: {
            ...member.kpiData,
            [field]: value,
          },
        };
      }
      return member;
    }));
  };

  const onSubmit = async () => {
    if (!profile?.id || !salonId) {
      toast({
        title: "Feil",
        description: "Du må være tilknyttet en salong",
        variant: "destructive",
      });
      return;
    }

    const dirtyMembers = teamKPIs.filter(m => m.isDirty);
    if (dirtyMembers.length === 0) {
      toast({
        title: "Ingen endringer",
        description: "Du har ikke gjort noen endringer",
      });
      return;
    }

    setSubmitting(true);

    try {
      const week = getISOWeek(selectedDate);
      const year = getISOWeekYear(selectedDate);

      for (const member of dirtyMembers) {
        const dataToSubmit = {
          stylist_id: member.id,
          salon_id: salonId,
          week,
          year,
          treatment_revenue: member.kpiData.treatmentRevenue,
          retail_revenue: member.kpiData.retailRevenue,
          visit_count: member.kpiData.visitCount,
          visits_with_addon: member.kpiData.visitsWithAddon,
          addon_count: member.kpiData.addonCount,
          rebooked_visits: member.kpiData.rebookedVisits,
          hours_worked: member.kpiData.hoursWorked,
          hours_with_client: member.kpiData.hoursWithClient,
          submitted_by_user_id: profile.id,
        };

        if (member.existingDataId) {
          const { error } = await supabase
            .from("weekly_kpi_inputs")
            .update(dataToSubmit)
            .eq("id", member.existingDataId);
          if (error) throw error;
        } else {
          const { error } = await supabase
            .from("weekly_kpi_inputs")
            .insert(dataToSubmit);
          if (error) throw error;
        }
      }

      toast({
        title: "Suksess!",
        description: `KPI-data lagret for ${dirtyMembers.length} ${dirtyMembers.length === 1 ? 'person' : 'personer'}`,
      });

      navigate("/team");
    } catch (error: any) {
      console.error("Error submitting KPI data:", error);
      toast({
        title: "Feil",
        description: error.message || "Kunne ikke lagre data",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const getRoleLabel = (role: string) => {
    const roleLabels: Record<string, string> = {
      salon_owner: "Eier",
      daglig_leder: "Daglig leder",
      avdelingsleder: "Avdelingsleder",
      stylist: "Frisør",
      seniorfrisor: "Seniorfrisør",
      apprentice: "Lærling",
    };
    return roleLabels[role] || role;
  };

  const dirtyCount = teamKPIs.filter(m => m.isDirty).length;
  const registeredCount = teamKPIs.filter(m => m.hasData || m.isDirty).length;

  if (loading || !isManager) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">Laster...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-4 pb-24">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex flex-col sm:flex-row items-start gap-4">
          <div className="flex items-center gap-4">
            <NavLink to="/team">
              <Button variant="ghost" size="icon">
                <ArrowLeft className="h-5 w-5" />
              </Button>
            </NavLink>
            <div>
              <h1 className="text-2xl font-bold flex items-center gap-2">
                <Users className="h-6 w-6" />
                Batch-registrering
              </h1>
              <p className="text-sm text-muted-foreground">
                Registrer data for hele teamet samtidig
              </p>
            </div>
          </div>
          <div className="sm:ml-auto flex items-center gap-4">
            <WeekSelector
              selectedDate={selectedDate}
              onDateChange={setSelectedDate}
            />
          </div>
        </div>

        {/* Status bar */}
        <Card className="p-4">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-4 text-sm">
              <span className="flex items-center gap-1">
                <Check className="h-4 w-4 text-success" />
                {registeredCount}/{teamKPIs.length} registrert
              </span>
              {dirtyCount > 0 && (
                <span className="flex items-center gap-1 text-warning">
                  <AlertCircle className="h-4 w-4" />
                  {dirtyCount} ulagrede endringer
                </span>
              )}
            </div>
            <Button 
              onClick={onSubmit} 
              disabled={submitting || dirtyCount === 0}
              size="lg"
            >
              <Save className="mr-2 h-5 w-5" />
              {submitting ? "Lagrer..." : `Lagre ${dirtyCount > 0 ? `(${dirtyCount})` : ""}`}
            </Button>
          </div>
        </Card>

        {loadingData ? (
          <Card className="p-6">
            <div className="animate-pulse space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-24 bg-muted rounded"></div>
              ))}
            </div>
          </Card>
        ) : teamKPIs.length === 0 ? (
          <Card className="p-6 text-center">
            <p className="text-muted-foreground">Ingen teammedlemmer funnet</p>
          </Card>
        ) : (
          <ScrollArea className="h-[calc(100vh-280px)]">
            <div className="space-y-4 pr-4">
              {teamKPIs.map((member) => (
                <Card key={member.id} className={`p-4 ${member.isDirty ? 'ring-2 ring-primary' : ''}`}>
                  <div className="flex flex-col gap-4">
                    {/* Header with member info */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={member.avatar_url || undefined} />
                          <AvatarFallback>
                            {member.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{member.name}</p>
                          <p className="text-sm text-muted-foreground">{getRoleLabel(member.role)}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {member.hasData && !member.isDirty && (
                          <Badge variant="secondary" className="bg-success/10 text-success">
                            <Check className="h-3 w-3 mr-1" />
                            Registrert
                          </Badge>
                        )}
                        {member.isDirty && (
                          <Badge variant="secondary" className="bg-warning/10 text-warning">
                            Ulagret
                          </Badge>
                        )}
                      </div>
                    </div>

                    {/* KPI Input Grid */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
                      <div>
                        <label className="text-xs text-muted-foreground block mb-1">Behandling (kr)</label>
                        <Input
                          type="number"
                          step="0.01"
                          value={member.kpiData.treatmentRevenue || ""}
                          onChange={(e) => updateMemberKPI(member.id, 'treatmentRevenue', Number(e.target.value))}
                          className="h-9"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-muted-foreground block mb-1">Produkt (kr)</label>
                        <Input
                          type="number"
                          step="0.01"
                          value={member.kpiData.retailRevenue || ""}
                          onChange={(e) => updateMemberKPI(member.id, 'retailRevenue', Number(e.target.value))}
                          className="h-9"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-muted-foreground block mb-1">Besøk</label>
                        <Input
                          type="number"
                          value={member.kpiData.visitCount || ""}
                          onChange={(e) => updateMemberKPI(member.id, 'visitCount', Number(e.target.value))}
                          className="h-9"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-muted-foreground block mb-1">m/Tillegg</label>
                        <Input
                          type="number"
                          value={member.kpiData.visitsWithAddon || ""}
                          onChange={(e) => updateMemberKPI(member.id, 'visitsWithAddon', Number(e.target.value))}
                          className="h-9"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-muted-foreground block mb-1">Tillegg #</label>
                        <Input
                          type="number"
                          value={member.kpiData.addonCount || ""}
                          onChange={(e) => updateMemberKPI(member.id, 'addonCount', Number(e.target.value))}
                          className="h-9"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-muted-foreground block mb-1">Rebooking</label>
                        <Input
                          type="number"
                          value={member.kpiData.rebookedVisits || ""}
                          onChange={(e) => updateMemberKPI(member.id, 'rebookedVisits', Number(e.target.value))}
                          className="h-9"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-muted-foreground block mb-1">Timer</label>
                        <Input
                          type="number"
                          step="0.5"
                          value={member.kpiData.hoursWorked || ""}
                          onChange={(e) => updateMemberKPI(member.id, 'hoursWorked', Number(e.target.value))}
                          className="h-9"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-muted-foreground block mb-1">m/Kunde</label>
                        <Input
                          type="number"
                          step="0.5"
                          value={member.kpiData.hoursWithClient || ""}
                          onChange={(e) => updateMemberKPI(member.id, 'hoursWithClient', Number(e.target.value))}
                          className="h-9"
                        />
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </ScrollArea>
        )}

        {/* Bottom save button for mobile */}
        <div className="fixed bottom-0 left-0 right-0 p-4 bg-background border-t sm:hidden">
          <Button 
            onClick={onSubmit} 
            disabled={submitting || dirtyCount === 0}
            className="w-full"
            size="lg"
          >
            <Save className="mr-2 h-5 w-5" />
            {submitting ? "Lagrer..." : `Lagre ${dirtyCount > 0 ? `(${dirtyCount})` : ""}`}
          </Button>
        </div>
      </div>
    </div>
  );
}
