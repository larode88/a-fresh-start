import { AppLayout } from "@/components/AppLayout";
import { ProspektKanban } from "@/components/prospekter/ProspektKanban";
import { useUserRole } from "@/hooks/useUserRole";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, TrendingUp, Target, Trophy, XCircle } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";

export default function ProspektPipeline() {
  const { isAdmin, isDistrictManager } = useUserRole();
  const { user } = useAuth();

  // Fetch user's district for all users (needed for filtering)
  const { data: userDistrictId } = useQuery({
    queryKey: ["user-district", user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      const { data } = await supabase.from("users").select("district_id").eq("id", user.id).single();
      return data?.district_id;
    },
    enabled: !!user?.id,
  });

  const { data: stats } = useQuery({
    queryKey: ["prospekt-stats", userDistrictId],
    queryFn: async () => {
      let query = supabase
        .from("prospekter")
        .select("id, pipeline_status, estimert_medlemsavgift, sannsynlighet")
        .is("archived_at", null);

      if (isDistrictManager && userDistrictId) {
        query = query.eq("district_id", userDistrictId);
      }

      const { data, error } = await query;
      if (error) throw error;

      const aktive = data?.filter((p) => !["vunnet", "tapt"].includes(p.pipeline_status)) || [];
      const vunnet = data?.filter((p) => p.pipeline_status === "vunnet") || [];
      const tapt = data?.filter((p) => p.pipeline_status === "tapt") || [];
      const storSannsynlighet = aktive.filter((p) => p.sannsynlighet === "stor");

      return {
        totalt: aktive.length,
        vunnet: vunnet.length,
        tapt: tapt.length,
        storSannsynlighet: storSannsynlighet.length,
        estimertVerdi: aktive.reduce((sum, p) => sum + (p.estimert_medlemsavgift || 0), 0),
        vektetVerdi: aktive.reduce((sum, p) => {
          const vekt = p.sannsynlighet === "stor" ? 0.8 : p.sannsynlighet === "medium" ? 0.5 : 0.2;
          return sum + (p.estimert_medlemsavgift || 0) * vekt;
        }, 0),
      };
    },
  });

  return (
    <AppLayout>
      <div className="container mx-auto py-6 space-y-6">
        <div>
          <h1 className="text-2xl font-bold">Prospekt Pipeline</h1>
          <p className="text-muted-foreground">Administrer leads og potensielle medlemmer</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Users className="h-4 w-4" />
                Aktive
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{stats?.totalt || 0}</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Target className="h-4 w-4" />
                Stor sannsynlighet
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-green-600">{stats?.storSannsynlighet || 0}</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <TrendingUp className="h-4 w-4" />
                Estimert verdi
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">{(stats?.estimertVerdi || 0).toLocaleString("nb-NO")} kr</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Trophy className="h-4 w-4" />
                Vunnet
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-green-600">{stats?.vunnet || 0}</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <XCircle className="h-4 w-4" />
                Tapt
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold text-red-600">{stats?.tapt || 0}</p>
            </CardContent>
          </Card>
        </div>

        {/* Kanban */}
        <ProspektKanban 
          districtId={isDistrictManager ? userDistrictId : undefined} 
          userDistrictId={userDistrictId}
        />
      </div>
    </AppLayout>
  );
}
