import { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { AppLayout } from "@/components/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { ArrowLeft, ArrowRight, ShoppingCart, Trash2, Check, Users, Plus, AlertCircle, FileSignature } from "lucide-react";
import { InsuranceProductCatalog } from "@/components/insurance/InsuranceProductCatalog";

interface CartItem {
  productId: string;
  tierId?: string;
  quantity: number;
  selectedEmployees?: string[];
}

interface Product {
  id: string;
  name: string;
  base_price: number;
  price_model: string;
  requires_employee_selection: boolean;
}

interface ProductTier {
  id: string;
  product_id: string;
  tier_name: string;
  price: number;
}

interface Employee {
  id: string;
  name: string;
}

interface SalonInsurance {
  antall_ansatte: number | null;
  antall_arsverk: number | null;
  arlig_omsetning: number | null;
  kontaktperson_navn: string | null;
  kontaktperson_epost: string | null;
}

interface PreviousInsurance {
  company: string;
  policyNumber: string;
}

export default function InsuranceOrder() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { user, profile } = useAuth();
  const queryClient = useQueryClient();
  const [step, setStep] = useState(1);
  const [cart, setCart] = useState<CartItem[]>([]);
  
  // Contact info
  const [contactName, setContactName] = useState("");
  const [contactEmail, setContactEmail] = useState("");
  const [contactPhone, setContactPhone] = useState("");
  
  // Frende info (Step 3)
  const [antallAnsatte, setAntallAnsatte] = useState<string>("");
  const [antallArsverk, setAntallArsverk] = useState<string>("");
  const [aarligOmsetning, setAarligOmsetning] = useState<string>("");
  const [desiredStartDate, setDesiredStartDate] = useState<string>("");
  
  // Switching provider
  const [switchingProvider, setSwitchingProvider] = useState(false);
  const [previousInsurances, setPreviousInsurances] = useState<PreviousInsurance[]>([{ company: "", policyNumber: "" }]);
  
  // POA (Power of Attorney)
  const [signatureName, setSignatureName] = useState("");
  const [signatureValid, setSignatureValid] = useState(false);
  
  // Terms
  const [acceptedTerms, setAcceptedTerms] = useState(false);

  // Use URL param salonId if available, otherwise fall back to profile salon
  const urlSalonId = searchParams.get("salonId");
  const salonId = urlSalonId || profile?.salon_id;
  const isOrderingForOtherSalon = urlSalonId && urlSalonId !== profile?.salon_id;
  
  // Debug log
  console.log("InsuranceOrder - URL salonId:", urlSalonId, "| profile salon:", profile?.salon_id, "| using:", salonId);

  const { data: salon } = useQuery({
    queryKey: ["salon-for-order", salonId],
    queryFn: async () => {
      if (!salonId) return null;
      const { data, error } = await supabase
        .from("salons")
        .select("id, name")
        .eq("id", salonId)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!salonId,
  });

  const { data: salonInsurance } = useQuery({
    queryKey: ["salon-insurance-for-order", salonId],
    queryFn: async () => {
      if (!salonId) return null;
      const { data, error } = await supabase
        .from("salon_insurance")
        .select("antall_ansatte, antall_arsverk, arlig_omsetning, kontaktperson_navn, kontaktperson_epost")
        .eq("salon_id", salonId)
        .single();
      if (error && error.code !== "PGRST116") throw error;
      return data as SalonInsurance | null;
    },
    enabled: !!salonId,
  });

  const { data: employees } = useQuery({
    queryKey: ["employees-for-order", salonId],
    queryFn: async () => {
      if (!salonId) return [];
      const { data, error } = await supabase
        .from("users")
        .select("id, name")
        .eq("salon_id", salonId)
        .order("name");
      if (error) throw error;
      return data as Employee[];
    },
    enabled: !!salonId,
  });

  const { data: products } = useQuery({
    queryKey: ["insurance-products-for-order"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("insurance_products")
        .select("*")
        .eq("active", true);
      if (error) throw error;
      return data as Product[];
    },
  });

  const { data: tiers } = useQuery({
    queryKey: ["insurance-tiers-for-order"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("insurance_product_tiers")
        .select("*");
      if (error) throw error;
      return data as ProductTier[];
    },
  });

  // Initialize form fields from existing data
  useEffect(() => {
    if (salonInsurance) {
      if (salonInsurance.kontaktperson_navn && !contactName) {
        setContactName(salonInsurance.kontaktperson_navn);
      }
      if (salonInsurance.kontaktperson_epost && !contactEmail) {
        setContactEmail(salonInsurance.kontaktperson_epost);
      }
      if (salonInsurance.antall_ansatte && !antallAnsatte) {
        setAntallAnsatte(String(salonInsurance.antall_ansatte));
      }
      if (salonInsurance.antall_arsverk && !antallArsverk) {
        setAntallArsverk(String(salonInsurance.antall_arsverk));
      }
      if (salonInsurance.arlig_omsetning && !aarligOmsetning) {
        setAarligOmsetning(String(salonInsurance.arlig_omsetning));
      }
    }
  }, [salonInsurance]);

  // Validate signature against profile name
  useEffect(() => {
    if (profile?.name && signatureName) {
      const profileNameNormalized = profile.name.toLowerCase().trim();
      const signatureNormalized = signatureName.toLowerCase().trim();
      setSignatureValid(profileNameNormalized === signatureNormalized);
    } else {
      setSignatureValid(false);
    }
  }, [signatureName, profile?.name]);

  const submitOrderMutation = useMutation({
    mutationFn: async () => {
      if (!salonId || !user) throw new Error("Mangler salon eller bruker");

      // Calculate total price
      let totalPrice = 0;
      const orderItems: { product_id: string; tier_id: string | null; quantity: number; unit_price: number; total_price: number }[] = [];

      for (const item of cart) {
        const product = products?.find(p => p.id === item.productId);
        if (!product) continue;

        let unitPrice = product.base_price;
        let quantity = item.quantity;

        if (item.tierId) {
          const tier = tiers?.find(t => t.id === item.tierId);
          if (tier) unitPrice = tier.price;
        }

        if (product.price_model === "per_arsverk" && antallArsverk) {
          quantity = parseFloat(antallArsverk);
        }

        if (product.requires_employee_selection && item.selectedEmployees) {
          quantity = item.selectedEmployees.length;
        }

        const itemTotal = unitPrice * quantity;
        totalPrice += itemTotal;

        orderItems.push({
          product_id: item.productId,
          tier_id: item.tierId || null,
          quantity,
          unit_price: unitPrice,
          total_price: itemTotal,
        });
      }

      // Format previous insurances for storage
      const formattedPreviousInsurances = switchingProvider 
        ? previousInsurances.filter(p => p.company || p.policyNumber)
        : null;

      // Create order with new fields (type assertion for new columns not yet in types)
      const orderData = {
        salon_id: salonId,
        ordered_by_user_id: user.id,
        status: "pending_approval" as const,
        order_type: "new" as const,
        total_price: totalPrice,
        contact_name: contactName,
        contact_email: contactEmail,
        contact_phone: contactPhone || null,
        antall_ansatte: antallAnsatte ? parseInt(antallAnsatte) : null,
        antall_arsverk: antallArsverk ? parseFloat(antallArsverk) : null,
        aarlig_omsetning: aarligOmsetning ? parseFloat(aarligOmsetning) : null,
        switching_provider: switchingProvider,
        previous_insurances: formattedPreviousInsurances,
        poa_signature_name: signatureName,
        poa_signature_at: new Date().toISOString(),
        desired_start_date: desiredStartDate || null,
      };

      const { data: order, error: orderError } = await supabase
        .from("insurance_orders")
        .insert(orderData as any)
        .select()
        .single();

      if (orderError) throw orderError;

      // Create order items
      for (const item of orderItems) {
        const { data: orderItem, error: itemError } = await supabase
          .from("insurance_order_items")
          .insert({
            order_id: order.id,
            ...item,
          })
          .select()
          .single();

        if (itemError) throw itemError;

        // Add selected employees if applicable
        const cartItem = cart.find(c => c.productId === item.product_id);
        if (cartItem?.selectedEmployees && cartItem.selectedEmployees.length > 0) {
          const employeeInserts = cartItem.selectedEmployees.map(empId => ({
            order_item_id: orderItem.id,
            user_id: empId,
          }));

          const { error: empError } = await supabase
            .from("insurance_order_employees")
            .insert(employeeInserts);

          if (empError) throw empError;
        }
      }

      // Send notification email
      try {
        await supabase.functions.invoke("send-insurance-notification", {
          body: {
            type: "order_submitted",
            orderId: order.id,
            salonName: salon?.name,
            recipientEmail: contactEmail,
            recipientName: contactName,
          },
        });
      } catch (notificationError) {
        console.error("Failed to send notification:", notificationError);
      }

      return order;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["insurance-orders"] });
      toast.success("Bestilling sendt inn for godkjenning");
      navigate("/insurance");
    },
    onError: (error) => {
      console.error("Order error:", error);
      toast.error("Kunne ikke sende bestilling");
    },
  });

  const handleAddToCart = (productId: string, tierId?: string, quantity: number = 1) => {
    const product = products?.find(p => p.id === productId);
    setCart(prev => [...prev, { 
      productId, 
      tierId, 
      quantity,
      selectedEmployees: product?.requires_employee_selection ? [] : undefined
    }]);
  };

  const handleRemoveFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.productId !== productId));
  };

  const handleUpdateEmployees = (productId: string, employeeIds: string[]) => {
    setCart(prev => prev.map(item => 
      item.productId === productId 
        ? { ...item, selectedEmployees: employeeIds, quantity: employeeIds.length }
        : item
    ));
  };

  const addPreviousInsurance = () => {
    setPreviousInsurances(prev => [...prev, { company: "", policyNumber: "" }]);
  };

  const updatePreviousInsurance = (index: number, field: keyof PreviousInsurance, value: string) => {
    setPreviousInsurances(prev => prev.map((item, i) => 
      i === index ? { ...item, [field]: value } : item
    ));
  };

  const removePreviousInsurance = (index: number) => {
    if (previousInsurances.length > 1) {
      setPreviousInsurances(prev => prev.filter((_, i) => i !== index));
    }
  };

  const calculateCartTotal = () => {
    let total = 0;
    for (const item of cart) {
      const product = products?.find(p => p.id === item.productId);
      if (!product) continue;

      let unitPrice = product.base_price;
      let quantity = item.quantity;

      if (item.tierId) {
        const tier = tiers?.find(t => t.id === item.tierId);
        if (tier) unitPrice = tier.price;
      }

      if (product.price_model === "per_arsverk" && antallArsverk) {
        quantity = parseFloat(antallArsverk);
      }

      if (product.requires_employee_selection && item.selectedEmployees) {
        quantity = item.selectedEmployees.length;
      }

      total += unitPrice * quantity;
    }
    return total;
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("nb-NO", {
      style: "currency",
      currency: "NOK",
      maximumFractionDigits: 0,
    }).format(price);
  };

  const getProductsRequiringEmployees = () => {
    return cart.filter(item => {
      const product = products?.find(p => p.id === item.productId);
      return product?.requires_employee_selection;
    });
  };

  const canProceedToStep2 = cart.length > 0;
  const canProceedToStep3 = () => {
    const requiresEmployees = getProductsRequiringEmployees();
    return requiresEmployees.every(item => item.selectedEmployees && item.selectedEmployees.length > 0);
  };
  const canSubmit = contactName && contactEmail && acceptedTerms && signatureValid && antallAnsatte && antallArsverk;

  if (!salonId) {
    return (
      <AppLayout title="Bestill forsikring" subtitle="Du må være tilknyttet en salong">
        <div className="container mx-auto px-4 py-8">
          <Card>
            <CardContent className="py-12 text-center">
              <p className="text-muted-foreground">
                Du har ikke tilgang til å bestille forsikring. Ta kontakt med administrator.
              </p>
              <Button className="mt-4" onClick={() => navigate("/insurance")}>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Tilbake
              </Button>
            </CardContent>
          </Card>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout title="Bestill forsikring" subtitle={salon?.name || ""}>
      <div className="container mx-auto px-4 py-8">
        <Button variant="ghost" onClick={() => navigate("/insurance")} className="mb-6">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Tilbake til oversikt
        </Button>

        {/* Admin ordering for other salon warning */}
        {isOrderingForOtherSalon && (
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-6">
            <p className="text-amber-800 flex items-center gap-2">
              <AlertCircle className="h-4 w-4" />
              Du bestiller forsikring på vegne av <strong>{salon?.name}</strong>
            </p>
          </div>
        )}
        <div className="flex items-center justify-center mb-8">
          <div className="flex items-center gap-2">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 1 ? "bg-primary text-primary-foreground" : "bg-muted"}`}>
              1
            </div>
            <span className="text-sm hidden sm:inline">Velg produkter</span>
          </div>
          <div className={`w-12 h-0.5 mx-2 ${step >= 2 ? "bg-primary" : "bg-muted"}`} />
          <div className="flex items-center gap-2">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 2 ? "bg-primary text-primary-foreground" : "bg-muted"}`}>
              2
            </div>
            <span className="text-sm hidden sm:inline">Konfigurer</span>
          </div>
          <div className={`w-12 h-0.5 mx-2 ${step >= 3 ? "bg-primary" : "bg-muted"}`} />
          <div className="flex items-center gap-2">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 3 ? "bg-primary text-primary-foreground" : "bg-muted"}`}>
              3
            </div>
            <span className="text-sm hidden sm:inline">Bekreft</span>
          </div>
        </div>

        {/* Step 1: Select products */}
        {step === 1 && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Velg forsikringer</CardTitle>
                <CardDescription>
                  Klikk på produktene du ønsker å bestille. Du kan lese vilkårene før du legger til.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <InsuranceProductCatalog
                  cart={cart}
                  onAddToCart={handleAddToCart}
                  onRemoveFromCart={handleRemoveFromCart}
                  arsverk={salonInsurance?.antall_arsverk || undefined}
                />
              </CardContent>
            </Card>

            {cart.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <ShoppingCart className="h-5 w-5" />
                    Valgte produkter ({cart.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {cart.map(item => {
                      const product = products?.find(p => p.id === item.productId);
                      const tier = item.tierId ? tiers?.find(t => t.id === item.tierId) : null;
                      return (
                        <div key={item.productId} className="flex items-center justify-between p-3 border rounded-lg">
                          <div>
                            <p className="font-medium">{product?.name}</p>
                            {tier && <p className="text-sm text-muted-foreground">{tier.tier_name}</p>}
                            {item.quantity > 1 && <p className="text-sm text-muted-foreground">{item.quantity} stk</p>}
                          </div>
                          <Button variant="ghost" size="sm" onClick={() => handleRemoveFromCart(item.productId)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      );
                    })}
                  </div>
                  <Separator className="my-4" />
                  <div className="flex items-center justify-between">
                    <span className="text-muted-foreground">Estimert årlig premie</span>
                    <span className="text-xl font-bold">{formatPrice(calculateCartTotal())}</span>
                  </div>
                </CardContent>
              </Card>
            )}

            <div className="flex justify-end">
              <Button onClick={() => setStep(2)} disabled={!canProceedToStep2}>
                Neste
                <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            </div>
          </div>
        )}

        {/* Step 2: Configure (employee selection) */}
        {step === 2 && (
          <div className="space-y-6">
            {getProductsRequiringEmployees().length > 0 ? (
              getProductsRequiringEmployees().map(item => {
                const product = products?.find(p => p.id === item.productId);
                return (
                  <Card key={item.productId}>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Users className="h-5 w-5" />
                        Velg ansatte for {product?.name}
                      </CardTitle>
                      <CardDescription>
                        Velg hvilke ansatte som skal dekkes av denne forsikringen
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                        {employees?.map(emp => {
                          const isSelected = item.selectedEmployees?.includes(emp.id);
                          return (
                            <div
                              key={emp.id}
                              className={`flex items-center gap-3 p-3 border rounded-lg cursor-pointer transition-colors ${
                                isSelected ? "border-primary bg-primary/5" : "hover:border-primary/50"
                              }`}
                              onClick={() => {
                                const newSelection = isSelected
                                  ? (item.selectedEmployees || []).filter(id => id !== emp.id)
                                  : [...(item.selectedEmployees || []), emp.id];
                                handleUpdateEmployees(item.productId, newSelection);
                              }}
                            >
                              <Checkbox checked={isSelected} />
                              <span>{emp.name}</span>
                            </div>
                          );
                        })}
                      </div>
                      <p className="text-sm text-muted-foreground mt-4">
                        {item.selectedEmployees?.length || 0} ansatte valgt × {formatPrice(product?.base_price || 0)} = {formatPrice((item.selectedEmployees?.length || 0) * (product?.base_price || 0))}
                      </p>
                    </CardContent>
                  </Card>
                );
              })
            ) : (
              <Card>
                <CardHeader>
                  <CardTitle>Ingen ansattvalg nødvendig</CardTitle>
                  <CardDescription>
                    De valgte forsikringene krever ikke at du velger spesifikke ansatte.
                  </CardDescription>
                </CardHeader>
              </Card>
            )}

            <div className="flex justify-between">
              <Button variant="outline" onClick={() => setStep(1)}>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Tilbake
              </Button>
              <Button onClick={() => setStep(3)} disabled={!canProceedToStep3()}>
                Neste
                <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            </div>
          </div>
        )}

        {/* Step 3: Confirm with Frende info, switching, and POA */}
        {step === 3 && (
          <div className="space-y-6">
            {/* Order summary */}
            <Card>
              <CardHeader>
                <CardTitle>Ordresammendrag</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {cart.map(item => {
                    const product = products?.find(p => p.id === item.productId);
                    const tier = item.tierId ? tiers?.find(t => t.id === item.tierId) : null;
                    let price = tier?.price || product?.base_price || 0;
                    let quantity = item.quantity;

                    if (product?.price_model === "per_arsverk" && antallArsverk) {
                      quantity = parseFloat(antallArsverk);
                    }
                    if (product?.requires_employee_selection && item.selectedEmployees) {
                      quantity = item.selectedEmployees.length;
                    }

                    return (
                      <div key={item.productId} className="flex items-center justify-between p-3 border rounded-lg">
                        <div>
                          <p className="font-medium">{product?.name}</p>
                          {tier && <Badge variant="outline">{tier.tier_name}</Badge>}
                          {item.selectedEmployees && item.selectedEmployees.length > 0 && (
                            <p className="text-sm text-muted-foreground">{item.selectedEmployees.length} ansatte</p>
                          )}
                        </div>
                        <div className="text-right">
                          <p className="font-medium">{formatPrice(price * quantity)}/år</p>
                          {quantity > 1 && (
                            <p className="text-sm text-muted-foreground">{formatPrice(price)} × {quantity}</p>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
                <Separator className="my-4" />
                <div className="flex items-center justify-between text-lg">
                  <span className="font-medium">Total årlig premie</span>
                  <span className="text-2xl font-bold">{formatPrice(calculateCartTotal())}</span>
                </div>
              </CardContent>
            </Card>

            {/* Frende information */}
            <Card>
              <CardHeader>
                <CardTitle>Informasjon til Frende</CardTitle>
                <CardDescription>
                  Denne informasjonen sendes til forsikringsselskapet
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 sm:grid-cols-3">
                  <div className="space-y-2">
                    <Label htmlFor="antallAnsatte">Antall ansatte *</Label>
                    <Input
                      id="antallAnsatte"
                      type="number"
                      min="1"
                      value={antallAnsatte}
                      onChange={(e) => setAntallAnsatte(e.target.value)}
                      placeholder="f.eks. 5"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="antallArsverk">Antall årsverk *</Label>
                    <Input
                      id="antallArsverk"
                      type="number"
                      min="0.1"
                      step="0.1"
                      value={antallArsverk}
                      onChange={(e) => setAntallArsverk(e.target.value)}
                      placeholder="f.eks. 4.5"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="aarligOmsetning">Årlig omsetning (NOK)</Label>
                    <Input
                      id="aarligOmsetning"
                      type="number"
                      min="0"
                      value={aarligOmsetning}
                      onChange={(e) => setAarligOmsetning(e.target.value)}
                      placeholder="f.eks. 2000000"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="desiredStartDate">Ønsket oppstartsdato</Label>
                  <Input
                    id="desiredStartDate"
                    type="date"
                    value={desiredStartDate}
                    onChange={(e) => setDesiredStartDate(e.target.value)}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Switching provider section */}
            <Card>
              <CardHeader>
                <CardTitle>Bytte forsikringsselskap?</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start gap-3">
                  <Checkbox
                    id="switchingProvider"
                    checked={switchingProvider}
                    onCheckedChange={(checked) => setSwitchingProvider(checked === true)}
                  />
                  <Label htmlFor="switchingProvider" className="cursor-pointer leading-relaxed">
                    Ja, jeg bytter fra et annet forsikringsselskap og ønsker at Hår1/Frende sier opp mine eksisterende forsikringer
                  </Label>
                </div>

                {switchingProvider && (
                  <div className="space-y-4 pt-4 border-t">
                    <p className="text-sm text-muted-foreground">
                      Oppgi tidligere forsikringsselskap og polisenummer for de forsikringene som skal sies opp:
                    </p>
                    {previousInsurances.map((insurance, index) => (
                      <div key={index} className="flex gap-3 items-end">
                        <div className="flex-1 space-y-2">
                          <Label>Forsikringsselskap</Label>
                          <Input
                            value={insurance.company}
                            onChange={(e) => updatePreviousInsurance(index, "company", e.target.value)}
                            placeholder="f.eks. Gjensidige"
                          />
                        </div>
                        <div className="flex-1 space-y-2">
                          <Label>Polisenummer</Label>
                          <Input
                            value={insurance.policyNumber}
                            onChange={(e) => updatePreviousInsurance(index, "policyNumber", e.target.value)}
                            placeholder="f.eks. 123456789"
                          />
                        </div>
                        {previousInsurances.length > 1 && (
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => removePreviousInsurance(index)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    ))}
                    <Button variant="outline" size="sm" onClick={addPreviousInsurance}>
                      <Plus className="h-4 w-4 mr-2" />
                      Legg til flere
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Contact info */}
            <Card>
              <CardHeader>
                <CardTitle>Kontaktinformasjon</CardTitle>
                <CardDescription>
                  Hvem skal kontaktes angående denne bestillingen?
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 sm:grid-cols-3">
                  <div className="space-y-2">
                    <Label htmlFor="contactName">Kontaktperson *</Label>
                    <Input
                      id="contactName"
                      value={contactName}
                      onChange={(e) => setContactName(e.target.value)}
                      placeholder="Navn"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="contactEmail">E-post *</Label>
                    <Input
                      id="contactEmail"
                      type="email"
                      value={contactEmail}
                      onChange={(e) => setContactEmail(e.target.value)}
                      placeholder="e-post@salong.no"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="contactPhone">Telefon</Label>
                    <Input
                      id="contactPhone"
                      value={contactPhone}
                      onChange={(e) => setContactPhone(e.target.value)}
                      placeholder="+47 xxx xx xxx"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Power of Attorney */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileSignature className="h-5 w-5" />
                  Fullmakt
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 bg-muted rounded-lg text-sm space-y-3">
                  <p>
                    Ved å signere denne bestillingen gir jeg Hår1 Portalen AS fullmakt til å:
                  </p>
                  <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                    <li>Tegne de valgte forsikringene hos Frende Forsikring AS på vegne av salongen</li>
                    <li>Innhente nødvendig informasjon for å etablere forsikringsdekningene</li>
                    {switchingProvider && (
                      <li>Si opp eksisterende forsikringer hos tidligere forsikringsselskap</li>
                    )}
                  </ul>
                  <p className="text-muted-foreground">
                    Fullmakten gjelder kun for forsikringene i denne bestillingen.
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="signatureName">
                    Skriv ditt fulle navn for å signere *
                  </Label>
                  <Input
                    id="signatureName"
                    value={signatureName}
                    onChange={(e) => setSignatureName(e.target.value)}
                    placeholder={profile?.name || "Ditt fulle navn"}
                    className={signatureValid ? "border-green-500" : ""}
                  />
                  {signatureName && !signatureValid && (
                    <p className="text-sm text-destructive flex items-center gap-1">
                      <AlertCircle className="h-4 w-4" />
                      Navnet må være identisk med ditt profilnavn: {profile?.name}
                    </p>
                  )}
                  {signatureValid && (
                    <p className="text-sm text-green-600 flex items-center gap-1">
                      <Check className="h-4 w-4" />
                      Signatur validert
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Terms acceptance */}
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <Checkbox
                    id="terms"
                    checked={acceptedTerms}
                    onCheckedChange={(checked) => setAcceptedTerms(checked === true)}
                  />
                  <Label htmlFor="terms" className="text-sm leading-relaxed cursor-pointer">
                    Jeg bekrefter at jeg har lest og godtar vilkårene for de valgte forsikringene, 
                    og at informasjonen jeg har oppgitt er korrekt. 
                    Bestillingen sendes til godkjenning hos Hår1 før den videresendes til Frende.
                  </Label>
                </div>
              </CardContent>
            </Card>

            <div className="flex justify-between">
              <Button variant="outline" onClick={() => setStep(2)}>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Tilbake
              </Button>
              <Button onClick={() => submitOrderMutation.mutate()} disabled={!canSubmit || submitOrderMutation.isPending}>
                {submitOrderMutation.isPending ? "Sender..." : "Send bestilling"}
                <Check className="h-4 w-4 ml-2" />
              </Button>
            </div>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
