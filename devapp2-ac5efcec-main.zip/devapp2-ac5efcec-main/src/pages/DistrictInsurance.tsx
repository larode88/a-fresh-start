import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useNavigate } from "react-router-dom";
import { AppLayout } from "@/components/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Shield, ChevronDown, Building2, FileText, TrendingUp, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { InsuranceSalonList } from "@/components/insurance/InsuranceSalonList";
import { InsuranceSalonDetail } from "@/components/insurance/InsuranceSalonDetail";
import { InsuranceOrderHistory } from "@/components/insurance/InsuranceOrderHistory";
import { InsurancePendingApprovals } from "@/components/insurance/InsurancePendingApprovals";
import { InsuranceProductsTab } from "@/components/admin/InsuranceProductsTab";
import { InsuranceQuotesOverview } from "@/components/insurance/InsuranceQuotesOverview";

interface SalonInsurance {
  id: string;
  salon_id: string;
  hubspot_synced_at: string | null;
  aktivering_dato: string | null;
  innmelding_dato: string | null;
  oppsigelse_dato: string | null;
  avsluttede_forsikringer: boolean;
  helse_status: boolean;
  antall_ansatte: number | null;
  antall_arsverk: number | null;
  antall_fritidsulykke: number | null;
  antall_reiseforsikring: number | null;
  arlig_omsetning: number | null;
  cyber_aktiv: boolean;
  fritidsulykke_aktiv: boolean;
  reise_aktiv: boolean;
  salong_aktiv: boolean;
  yrkesskadeforsikring_aktiv: boolean;
  salong_niva: string | null;
  sum_mvil: string | null;
  pris_cyber: number | null;
  pris_fritidsulykke: number | null;
  pris_reise: number | null;
  pris_salong: number | null;
  pris_yrkesskadeforsikring: number | null;
  sum_fritidsulykke: number | null;
  sum_reise: number | null;
  sum_totalt: number | null;
  sum_yrkesskadeforsikring: number | null;
  kontaktperson_navn: string | null;
  kontaktperson_epost: string | null;
  helse_antall_aktive: number | null;
  salons: {
    id: string;
    name: string;
    hs_object_id: string | null;
    hubspot_owner_id: string | null;
  };
  district_name?: string | null;
  district_id?: string | null;
}

export default function DistrictInsurance() {
  const navigate = useNavigate();
  const { profile } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSalonId, setSelectedSalonId] = useState<string | null>(null);
  const [selectedDistrictId, setSelectedDistrictId] = useState<string | null>(null);

  const isDistrictManager = profile?.role === "district_manager";
  const isAdmin = profile?.role === "admin";

  // Set default district to user's district when profile loads
  useEffect(() => {
    if (profile?.district_id && !selectedDistrictId) {
      setSelectedDistrictId(profile.district_id);
    }
  }, [profile?.district_id]);

  // Redirect if not district manager or admin
  if (!isDistrictManager && !isAdmin) {
    navigate("/dashboard");
    return null;
  }

  // Fetch all districts
  const { data: districts } = useQuery({
    queryKey: ["all-districts"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("districts")
        .select("id, name")
        .order("name");
      if (error) throw error;
      return data;
    },
  });

  // Get selected district name
  const selectedDistrictName = districts?.find(d => d.id === selectedDistrictId)?.name;

  // Fetch insurance data filtered by selected district
  const { data: insuranceData, isLoading } = useQuery({
    queryKey: ["district-salon-insurance", selectedDistrictId],
    queryFn: async () => {
      // First get owner mappings for district names
      const { data: ownerMappings } = await supabase
        .from("hubspot_owner_district_mapping")
        .select("hubspot_owner_id, district_id, districts:district_id (name)");
      
      const ownerToDistrict = new Map(
        ownerMappings?.map(m => [m.hubspot_owner_id, { name: m.districts?.name, id: m.district_id }]) || []
      );

      const { data, error } = await supabase
        .from("salon_insurance")
        .select(`
          *,
          salons:salon_id (
            id,
            name,
            hs_object_id,
            hubspot_owner_id
          )
        `)
        .or("salong_aktiv.eq.true,yrkesskadeforsikring_aktiv.eq.true,cyber_aktiv.eq.true,reise_aktiv.eq.true,fritidsulykke_aktiv.eq.true,helse_status.eq.true")
        .order("created_at", { ascending: false });
      
      if (error) throw error;
      
      // Add district info and filter by selected district
      const enrichedData = (data || []).map(item => {
        const districtInfo = item.salons?.hubspot_owner_id 
          ? ownerToDistrict.get(item.salons.hubspot_owner_id) 
          : null;
        return {
          ...item,
          district_name: districtInfo?.name || null,
          district_id: districtInfo?.id || null
        };
      }) as SalonInsurance[];

      // Filter by selected district
      if (selectedDistrictId) {
        return enrichedData.filter(item => item.district_id === selectedDistrictId);
      }
      return enrichedData;
    },
    enabled: !!selectedDistrictId || isAdmin,
  });

  // Fetch count of salons without insurance in the district
  const { data: salonsWithoutInsuranceCount } = useQuery({
    queryKey: ["salons-without-insurance-count", selectedDistrictId],
    queryFn: async () => {
      // First get all salon IDs that have active insurance
      const { data: insuredSalonIds } = await supabase
        .from("salon_insurance")
        .select("salon_id")
        .or("salong_aktiv.eq.true,yrkesskadeforsikring_aktiv.eq.true,cyber_aktiv.eq.true,reise_aktiv.eq.true,fritidsulykke_aktiv.eq.true,helse_status.eq.true");

      const insuredIds = insuredSalonIds?.map(s => s.salon_id) || [];

      // Count salons in the district that are NOT in the insured list
      let query = supabase
        .from("salons")
        .select("id", { count: "exact", head: true })
        .eq("district_id", selectedDistrictId);

      if (insuredIds.length > 0) {
        query = query.not("id", "in", `(${insuredIds.join(",")})`);
      }

      const { count, error } = await query;
      if (error) throw error;
      return count || 0;
    },
    enabled: !!selectedDistrictId,
  });

  const HELSE_PRIS_PER_PERSON = 5050;

  // Calculate statistics
  const countActivePolicies = () => {
    let count = 0;
    insuranceData?.forEach((i) => {
      if (i.salong_aktiv) count++;
      if (i.cyber_aktiv) count++;
      if (i.reise_aktiv) count++;
      if (i.fritidsulykke_aktiv) count++;
      if (i.yrkesskadeforsikring_aktiv) count++;
      if (i.helse_status) count++;
    });
    return count;
  };

  const calculateTotalPremium = () => {
    let total = 0;
    insuranceData?.forEach((i) => {
      total += i.sum_totalt || 0;
      total += (i.helse_antall_aktive || 0) * HELSE_PRIS_PER_PERSON;
    });
    return total;
  };

  const calculatePremiumBreakdown = () => {
    const breakdown = {
      bedrift: {
        salong: 0,
        yrkesskade: 0,
        cyber: 0,
        reise: 0,
        fritidsulykke: 0,
        total: 0,
      },
      helse: {
        total: 0,
        antall: 0,
      },
    };

    insuranceData?.forEach((i) => {
      if (i.salong_aktiv) breakdown.bedrift.salong += i.pris_salong || 0;
      if (i.yrkesskadeforsikring_aktiv) breakdown.bedrift.yrkesskade += i.sum_yrkesskadeforsikring || 0;
      if (i.cyber_aktiv) breakdown.bedrift.cyber += i.pris_cyber || 0;
      if (i.reise_aktiv) breakdown.bedrift.reise += i.sum_reise || 0;
      if (i.fritidsulykke_aktiv) breakdown.bedrift.fritidsulykke += i.sum_fritidsulykke || 0;
      breakdown.bedrift.total += i.sum_totalt || 0;

      if (i.helse_status && i.helse_antall_aktive) {
        breakdown.helse.total += i.helse_antall_aktive * HELSE_PRIS_PER_PERSON;
        breakdown.helse.antall += i.helse_antall_aktive;
      }
    });

    return breakdown;
  };

  const premiumBreakdown = calculatePremiumBreakdown();

  const stats = {
    totalSalons: insuranceData?.length || 0,
    activePolicies: countActivePolicies(),
    totalPremium: calculateTotalPremium(),
    withSalong: insuranceData?.filter((i) => i.salong_aktiv).length || 0,
    withYrkesskade: insuranceData?.reduce((sum, i) => sum + (i.yrkesskadeforsikring_aktiv ? i.antall_arsverk || 0 : 0), 0) || 0,
    withCyber: insuranceData?.filter((i) => i.cyber_aktiv).length || 0,
    withReise: insuranceData?.reduce((sum, i) => sum + (i.reise_aktiv ? i.antall_reiseforsikring || 0 : 0), 0) || 0,
    withFritidsulykke: insuranceData?.reduce((sum, i) => sum + (i.fritidsulykke_aktiv ? i.antall_fritidsulykke || 0 : 0), 0) || 0,
    withHelse: insuranceData?.reduce((sum, i) => sum + (i.helse_status ? i.helse_antall_aktive || 0 : 0), 0) || 0,
  };

  // Filter insurance data by search
  const filteredData = insuranceData?.filter(
    (item) =>
      item.salons?.name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.district_name?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const selectedInsurance = insuranceData?.find((i) => i.salon_id === selectedSalonId);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("nb-NO", {
      style: "currency",
      currency: "NOK",
      maximumFractionDigits: 0,
    }).format(price);
  };

  return (
    <AppLayout
      title="Forsikring Administrasjon"
      subtitle={selectedDistrictName ? `Oversikt for ${selectedDistrictName}` : "Velg et distrikt"}
    >
      <div className="container mx-auto px-4 py-8 space-y-6">
        {/* District selector */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Building2 className="h-5 w-5 text-muted-foreground" />
            <span className="text-sm font-medium">Distrikt:</span>
          </div>
          {isAdmin ? (
            <Select
              value={selectedDistrictId || ""}
              onValueChange={(value) => setSelectedDistrictId(value)}
            >
              <SelectTrigger className="w-[280px]">
                <SelectValue placeholder="Velg distrikt..." />
              </SelectTrigger>
              <SelectContent>
                {districts?.map((district) => (
                  <SelectItem key={district.id} value={district.id}>
                    {district.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          ) : (
            <div className="flex items-center gap-2 px-3 py-2 bg-muted rounded-md">
              <span className="text-sm font-medium">
                {districts?.find(d => d.id === selectedDistrictId)?.name || "Mitt distrikt"}
              </span>
            </div>
          )}
        </div>

        {/* Stats cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 items-stretch">
          {/* Salonger med forsikring */}
          <Popover>
            <PopoverTrigger asChild>
              <Card className="cursor-pointer hover:bg-muted/50 transition-colors h-full flex flex-col">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Salonger med forsikring</CardTitle>
                  <ChevronDown className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent className="flex-1 flex flex-col justify-between">
                  {isLoading ? (
                    <Skeleton className="h-8 w-16" />
                  ) : (
                    <div className="text-2xl font-bold">{stats.totalSalons}</div>
                  )}
                  <p className="text-xs text-muted-foreground">Klikk for detaljer</p>
                </CardContent>
              </Card>
            </PopoverTrigger>
            <PopoverContent className="w-64 bg-card border shadow-lg z-50" align="start">
              <div className="space-y-3">
                <h4 className="font-semibold text-sm">Salongoversikt</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Salonger med forsikring</span>
                    <span className="font-medium">{stats.totalSalons}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Total premie</span>
                    <span className="font-medium">{formatPrice(stats.totalPremium)}</span>
                  </div>
                </div>
              </div>
            </PopoverContent>
          </Popover>

          {/* Aktive poliser */}
          <Popover>
            <PopoverTrigger asChild>
              <Card className="cursor-pointer hover:bg-muted/50 transition-colors h-full flex flex-col">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Aktive poliser</CardTitle>
                  <ChevronDown className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent className="flex-1 flex flex-col justify-between">
                  {isLoading ? (
                    <Skeleton className="h-8 w-16" />
                  ) : (
                    <div className="text-2xl font-bold">{stats.activePolicies}</div>
                  )}
                  <p className="text-xs text-muted-foreground">Klikk for detaljer</p>
                </CardContent>
              </Card>
            </PopoverTrigger>
            <PopoverContent className="w-64 bg-card border shadow-lg z-50" align="start">
              <div className="space-y-2">
                <h4 className="font-semibold text-sm mb-3">Poliser per produkt</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Salongforsikring</span>
                    <span className="font-medium">{stats.withSalong}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Yrkesskade (årsverk)</span>
                    <span className="font-medium">{Math.round(stats.withYrkesskade)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Cyberforsikring</span>
                    <span className="font-medium">{stats.withCyber}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Reiseforsikring (personer)</span>
                    <span className="font-medium">{stats.withReise}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Fritidsulykke (personer)</span>
                    <span className="font-medium">{stats.withFritidsulykke}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Helseforsikring (personer)</span>
                    <span className="font-medium">{stats.withHelse}</span>
                  </div>
                </div>
              </div>
            </PopoverContent>
          </Popover>

          {/* Total premie */}
          <Popover>
            <PopoverTrigger asChild>
              <Card className="cursor-pointer hover:bg-muted/50 transition-colors h-full flex flex-col">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total premie</CardTitle>
                  <ChevronDown className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent className="flex-1 flex flex-col justify-between">
                  {isLoading ? (
                    <Skeleton className="h-8 w-24" />
                  ) : (
                    <div className="text-2xl font-bold">
                      {new Intl.NumberFormat("nb-NO", { maximumFractionDigits: 0 }).format(stats.totalPremium)} kr
                    </div>
                  )}
                  <p className="text-xs text-muted-foreground">Klikk for detaljer</p>
                </CardContent>
              </Card>
            </PopoverTrigger>
            <PopoverContent className="w-72 bg-card border shadow-lg z-50" align="start">
              <div className="space-y-3">
                <h4 className="font-semibold text-sm">Premiefordeling</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Bedriftsforsikring</span>
                    <span className="font-medium">{formatPrice(premiumBreakdown.bedrift.total)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Helseforsikring ({premiumBreakdown.helse.antall} pers.)</span>
                    <span className="font-medium">{formatPrice(premiumBreakdown.helse.total)}</span>
                  </div>
                  <div className="flex justify-between font-semibold pt-2 border-t">
                    <span>Totalt</span>
                    <span>{formatPrice(stats.totalPremium)}</span>
                  </div>
                </div>
              </div>
            </PopoverContent>
          </Popover>

          {/* Forsikringsfordeling */}
          <Card className="h-full flex flex-col">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Forsikringsfordeling</CardTitle>
              <Shield className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent className="flex-1 flex flex-col justify-between">
              <div className="flex flex-wrap gap-1.5">
                {stats.withSalong > 0 && (
                  <Badge variant="secondary" className="text-xs">Salong {stats.withSalong}</Badge>
                )}
                {stats.withYrkesskade > 0 && (
                  <Badge variant="secondary" className="text-xs">Yrkesskade {Math.round(stats.withYrkesskade)}</Badge>
                )}
                {stats.withCyber > 0 && (
                  <Badge variant="secondary" className="text-xs">Cyber {stats.withCyber}</Badge>
                )}
                {stats.withReise > 0 && (
                  <Badge variant="secondary" className="text-xs">Reise {stats.withReise}</Badge>
                )}
                {stats.withFritidsulykke > 0 && (
                  <Badge variant="secondary" className="text-xs">Fritidsulykke {stats.withFritidsulykke}</Badge>
                )}
                {stats.withHelse > 0 && (
                  <Badge variant="secondary" className="text-xs">Helse {stats.withHelse}</Badge>
                )}
              </div>
              <p className="text-xs text-muted-foreground mt-2">Antall aktive per type</p>
            </CardContent>
          </Card>
        </div>

        {/* Link to salons without insurance page */}
        {salonsWithoutInsuranceCount !== undefined && salonsWithoutInsuranceCount > 0 && (
          <Card 
            className="border-amber-200 bg-gradient-to-r from-amber-50/80 to-orange-50/50 cursor-pointer hover:shadow-md transition-all"
            onClick={() => navigate("/district/insurance/prospects")}
          >
            <CardContent className="py-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-amber-100">
                    <TrendingUp className="h-5 w-5 text-amber-600" />
                  </div>
                  <div>
                    <p className="font-semibold text-amber-900">
                      {salonsWithoutInsuranceCount} salong{salonsWithoutInsuranceCount !== 1 ? "er" : ""} uten forsikring
                    </p>
                    <p className="text-sm text-amber-700">
                      Se alle salgsmuligheter i ditt distrikt
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100 border-amber-200">
                    Salgsmulighet
                  </Badge>
                  <ArrowRight className="h-5 w-5 text-amber-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Tabs for different views */}
        <Tabs defaultValue="salons" className="w-full">
          <TabsList>
            <TabsTrigger value="salons">Salonger</TabsTrigger>
            <TabsTrigger value="quotes">
              <FileText className="h-4 w-4 mr-1" />
              Tilbud
            </TabsTrigger>
            <TabsTrigger value="orders">Alle bestillinger</TabsTrigger>
            <TabsTrigger value="products">Produkter</TabsTrigger>
          </TabsList>

          <TabsContent value="salons" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Salongoversikt</CardTitle>
                <CardDescription>Søk og filtrer forsikringsdata for salonger i ditt distrikt</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Søk på salongnavn..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>

                {isLoading ? (
                  <div className="space-y-2">
                    {[...Array(5)].map((_, i) => (
                      <Skeleton key={i} className="h-16 w-full" />
                    ))}
                  </div>
                ) : (
                  <InsuranceSalonList
                    data={filteredData || []}
                    onSelect={setSelectedSalonId}
                  />
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="quotes" className="mt-4">
            <InsuranceQuotesOverview />
          </TabsContent>

          <TabsContent value="orders" className="mt-4">
            <InsuranceOrderHistory />
          </TabsContent>

          <TabsContent value="products" className="mt-4">
            <InsuranceProductsTab readOnly />
          </TabsContent>
        </Tabs>

        {/* Salon detail dialog */}
        {selectedInsurance && (
          <InsuranceSalonDetail
            insurance={selectedInsurance}
            open={!!selectedSalonId}
            onClose={() => setSelectedSalonId(null)}
            readOnly
          />
        )}
      </div>
    </AppLayout>
  );
}
