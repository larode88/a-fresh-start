import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ArrowLeft, Upload, FileSpreadsheet, Download, CheckCircle, XCircle, AlertCircle } from "lucide-react";
import * as XLSX from 'xlsx';
import { z } from "zod";

const kpiRowSchema = z.object({
  stylist_email: z.string().email("Ugyldig e-post"),
  year: z.number().int().min(2020).max(2030),
  week: z.number().int().min(1).max(53),
  treatment_revenue: z.number().min(0),
  retail_revenue: z.number().min(0),
  visit_count: z.number().int().min(0),
  visits_with_addon: z.number().int().min(0),
  addon_count: z.number().int().min(0),
  rebooked_visits: z.number().int().min(0),
  hours_worked: z.number().min(0),
  hours_with_client: z.number().min(0),
});

type KPIRow = z.infer<typeof kpiRowSchema>;

interface ImportResult {
  success: number;
  failed: number;
  errors: Array<{ row: number; error: string }>;
}

const HistoricalImport = () => {
  const navigate = useNavigate();
  const { profile } = useAuth();
  const { toast } = useToast();
  const [file, setFile] = useState<File | null>(null);
  const [importing, setImporting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState<ImportResult | null>(null);
  const [preview, setPreview] = useState<KPIRow[]>([]);

  const downloadTemplate = () => {
    const template = [
      {
        stylist_email: "stylist@example.com",
        year: 2024,
        week: 48,
        treatment_revenue: 25000,
        retail_revenue: 3500,
        visit_count: 40,
        visits_with_addon: 28,
        addon_count: 32,
        rebooked_visits: 35,
        hours_worked: 40,
        hours_with_client: 34,
      },
    ];

    const ws = XLSX.utils.json_to_sheet(template);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "KPI Import Template");
    XLSX.writeFile(wb, "kpi_import_template.xlsx");

    toast({
      title: "Mal lastet ned",
      description: "Bruk denne malen for å forberede dine data",
    });
  };

  const parseFile = async (file: File): Promise<KPIRow[]> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();

      reader.onload = (e) => {
        try {
          const data = e.target?.result;
          let rows: any[] = [];

          if (file.name.endsWith('.csv')) {
            const text = data as string;
            const lines = text.split('\n');
            const headers = lines[0].split(',').map(h => h.trim());
            
            rows = lines.slice(1)
              .filter(line => line.trim())
              .map(line => {
                const values = line.split(',');
                const obj: any = {};
                headers.forEach((header, i) => {
                  const value = values[i]?.trim();
                  if (header.includes('email')) {
                    obj[header] = value;
                  } else {
                    obj[header] = parseFloat(value) || 0;
                  }
                });
                return obj;
              });
          } else {
            const workbook = XLSX.read(data, { type: 'binary' });
            const sheetName = workbook.SheetNames[0];
            const worksheet = workbook.Sheets[sheetName];
            rows = XLSX.utils.sheet_to_json(worksheet);
          }

          const parsed = rows.map(row => ({
            stylist_email: String(row.stylist_email || ''),
            year: Number(row.year || 0),
            week: Number(row.week || 0),
            treatment_revenue: Number(row.treatment_revenue || 0),
            retail_revenue: Number(row.retail_revenue || 0),
            visit_count: Number(row.visit_count || 0),
            visits_with_addon: Number(row.visits_with_addon || 0),
            addon_count: Number(row.addon_count || 0),
            rebooked_visits: Number(row.rebooked_visits || 0),
            hours_worked: Number(row.hours_worked || 0),
            hours_with_client: Number(row.hours_with_client || 0),
          }));

          resolve(parsed);
        } catch (error) {
          reject(new Error("Kunne ikke lese filen. Sjekk at formatet er korrekt."));
        }
      };

      reader.onerror = () => reject(new Error("Feil ved lesing av fil"));

      if (file.name.endsWith('.csv')) {
        reader.readAsText(file);
      } else {
        reader.readAsBinaryString(file);
      }
    });
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (!selectedFile) return;

    const validExtensions = ['.csv', '.xlsx', '.xls'];
    const extension = selectedFile.name.toLowerCase().slice(selectedFile.name.lastIndexOf('.'));
    
    if (!validExtensions.includes(extension)) {
      toast({
        title: "Ugyldig filtype",
        description: "Vennligst last opp en CSV eller Excel fil",
        variant: "destructive",
      });
      return;
    }

    setFile(selectedFile);
    setResult(null);

    try {
      const rows = await parseFile(selectedFile);
      setPreview(rows.slice(0, 5));
      toast({
        title: "Fil lastet",
        description: `${rows.length} rader funnet. Sjekk forhåndsvisningen.`,
      });
    } catch (error) {
      toast({
        title: "Feil",
        description: error instanceof Error ? error.message : "Kunne ikke lese filen",
        variant: "destructive",
      });
      setFile(null);
    }
  };

  const handleImport = async () => {
    if (!file || !profile?.salon_id) return;

    setImporting(true);
    setProgress(0);
    setResult({ success: 0, failed: 0, errors: [] });

    try {
      const rows = await parseFile(file);
      const total = rows.length;
      let processed = 0;
      let success = 0;
      let failed = 0;
      const errors: Array<{ row: number; error: string }> = [];

      for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        
        try {
          // Validate row
          const validated = kpiRowSchema.parse(row);

          // Get stylist user ID
          const { data: stylist, error: stylistError } = await supabase
            .from("users")
            .select("id")
            .eq("email", validated.stylist_email)
            .eq("salon_id", profile.salon_id)
            .maybeSingle();

          if (stylistError || !stylist) {
            errors.push({ row: i + 1, error: `Stylist ikke funnet: ${validated.stylist_email}` });
            failed++;
            continue;
          }

          // Check if entry already exists
          const { data: existing } = await supabase
            .from("weekly_kpi_inputs")
            .select("id")
            .eq("stylist_id", stylist.id)
            .eq("year", validated.year)
            .eq("week", validated.week)
            .maybeSingle();

          if (existing) {
            // Update existing
            const { error: updateError } = await supabase
              .from("weekly_kpi_inputs")
              .update({
                treatment_revenue: validated.treatment_revenue,
                retail_revenue: validated.retail_revenue,
                visit_count: validated.visit_count,
                visits_with_addon: validated.visits_with_addon,
                addon_count: validated.addon_count,
                rebooked_visits: validated.rebooked_visits,
                hours_worked: validated.hours_worked,
                hours_with_client: validated.hours_with_client,
                submitted_by_user_id: profile.id,
              })
              .eq("id", existing.id);

            if (updateError) throw updateError;
          } else {
            // Insert new
            const { error: insertError } = await supabase
              .from("weekly_kpi_inputs")
              .insert({
                stylist_id: stylist.id,
                salon_id: profile.salon_id,
                year: validated.year,
                week: validated.week,
                treatment_revenue: validated.treatment_revenue,
                retail_revenue: validated.retail_revenue,
                visit_count: validated.visit_count,
                visits_with_addon: validated.visits_with_addon,
                addon_count: validated.addon_count,
                rebooked_visits: validated.rebooked_visits,
                hours_worked: validated.hours_worked,
                hours_with_client: validated.hours_with_client,
                submitted_by_user_id: profile.id,
              });

            if (insertError) throw insertError;
          }

          success++;
        } catch (error) {
          failed++;
          const errorMsg = error instanceof Error ? error.message : "Ukjent feil";
          errors.push({ row: i + 1, error: errorMsg });
        }

        processed++;
        setProgress((processed / total) * 100);
      }

      setResult({ success, failed, errors });
      toast({
        title: "Import fullført",
        description: `${success} rader importert, ${failed} feilet`,
      });
    } catch (error) {
      toast({
        title: "Import feilet",
        description: error instanceof Error ? error.message : "Ukjent feil",
        variant: "destructive",
      });
    } finally {
      setImporting(false);
    }
  };

  if (!profile || !['admin', 'salon_owner'].includes(profile.role)) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Du har ikke tilgang til denne siden.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card sticky top-0 z-10 shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate("/dashboard")}
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Tilbake
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-foreground flex items-center gap-2">
                <FileSpreadsheet className="w-6 h-6" />
                Historisk Import
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                Last opp historiske KPI-data fra Excel eller CSV
              </p>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Instructions */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Hvordan importere data</CardTitle>
            <CardDescription>
              Følg disse stegene for å importere historiske KPI-data
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground font-bold text-sm">
                1
              </div>
              <div>
                <p className="font-medium">Last ned mal</p>
                <p className="text-sm text-muted-foreground">
                  Last ned Excel-malen og fyll inn dine historiske data
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground font-bold text-sm">
                2
              </div>
              <div>
                <p className="font-medium">Fyll inn data</p>
                <p className="text-sm text-muted-foreground">
                  Hver rad skal inneholde: stylist e-post, år, uke, og alle KPI-verdier
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground font-bold text-sm">
                3
              </div>
              <div>
                <p className="font-medium">Last opp fil</p>
                <p className="text-sm text-muted-foreground">
                  Last opp filen (Excel eller CSV) og importer dataene
                </p>
              </div>
            </div>
            <Button onClick={downloadTemplate} variant="outline" className="w-full sm:w-auto">
              <Download className="w-4 h-4 mr-2" />
              Last ned mal
            </Button>
          </CardContent>
        </Card>

        {/* File Upload */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Last opp fil</CardTitle>
            <CardDescription>
              Velg en Excel (.xlsx, .xls) eller CSV fil med KPI-data
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Input
                type="file"
                accept=".csv,.xlsx,.xls"
                onChange={handleFileChange}
                disabled={importing}
              />
              {file && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <FileSpreadsheet className="w-4 h-4" />
                  <span>{file.name}</span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Preview */}
        {preview.length > 0 && !importing && !result && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Forhåndsvisning</CardTitle>
              <CardDescription>
                Viser de første 5 radene. Sjekk at dataene ser riktige ut.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-2">E-post</th>
                      <th className="text-left p-2">År</th>
                      <th className="text-left p-2">Uke</th>
                      <th className="text-right p-2">Behandling</th>
                      <th className="text-right p-2">Produkt</th>
                      <th className="text-right p-2">Besøk</th>
                    </tr>
                  </thead>
                  <tbody>
                    {preview.map((row, i) => (
                      <tr key={i} className="border-b">
                        <td className="p-2">{row.stylist_email}</td>
                        <td className="p-2">{row.year}</td>
                        <td className="p-2">{row.week}</td>
                        <td className="text-right p-2">{row.treatment_revenue}</td>
                        <td className="text-right p-2">{row.retail_revenue}</td>
                        <td className="text-right p-2">{row.visit_count}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <Button onClick={handleImport} className="w-full mt-4" size="lg">
                <Upload className="w-4 h-4 mr-2" />
                Start import
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Progress */}
        {importing && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Importerer...</CardTitle>
              <CardDescription>
                Vennligst vent mens dataene importeres
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Progress value={progress} className="w-full" />
              <p className="text-sm text-muted-foreground mt-2">
                {Math.round(progress)}% fullført
              </p>
            </CardContent>
          </Card>
        )}

        {/* Results */}
        {result && (
          <Card>
            <CardHeader>
              <CardTitle>Importresultat</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="flex items-center gap-3 p-4 bg-success/10 rounded-lg">
                  <CheckCircle className="w-8 h-8 text-success" />
                  <div>
                    <p className="text-2xl font-bold text-success">{result.success}</p>
                    <p className="text-sm text-muted-foreground">Vellykket</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-4 bg-destructive/10 rounded-lg">
                  <XCircle className="w-8 h-8 text-destructive" />
                  <div>
                    <p className="text-2xl font-bold text-destructive">{result.failed}</p>
                    <p className="text-sm text-muted-foreground">Feilet</p>
                  </div>
                </div>
              </div>

              {result.errors.length > 0 && (
                <div>
                  <h3 className="font-semibold mb-2">Feil:</h3>
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {result.errors.map((error, i) => (
                      <Alert key={i} variant="destructive">
                        <AlertDescription>
                          <strong>Rad {error.row}:</strong> {error.error}
                        </AlertDescription>
                      </Alert>
                    ))}
                  </div>
                </div>
              )}

              <Button onClick={() => navigate("/dashboard")} className="w-full">
                Tilbake til dashboard
              </Button>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
};

export default HistoricalImport;
