import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useSalonContext } from "@/components/SalonSelector";
import { AppLayout } from "@/components/AppLayout";
import { Users, UserPlus, Search, LayoutGrid, List, Filter } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { AnsattStats } from "@/components/ansatte/AnsattStats";
import { AnsattTabell } from "@/components/ansatte/AnsattTabell";
import { AnsattKort } from "@/components/ansatte/AnsattKort";
import { AnsattDialog } from "@/components/ansatte/AnsattDialog";
import { getAnsatteBySalong, type AnsattUtvidet } from "@/integrations/supabase/ansatteService";
import { sortByFirstNameFirst } from "@/lib/sortUtils";

const Ansatte = () => {
  const navigate = useNavigate();
  const { user, profile, loading: authLoading } = useAuth();
  const { salons, selectedSalonId, setSelectedSalonId, loading: salonLoading, canSelectSalon } = useSalonContext();
  const [viewMode, setViewMode] = useState<"table" | "cards">("table");
  const [searchQuery, setSearchQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState<string>("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedAnsatt, setSelectedAnsatt] = useState<AnsattUtvidet | null>(null);

  const canAccess = ['salon_owner', 'daglig_leder', 'avdelingsleder', 'admin', 'district_manager'].includes(profile?.role || '');

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/login");
      return;
    }

    if (!authLoading && profile && !canAccess) {
      toast({
        title: "Ingen tilgang",
        description: "Du har ikke tilgang til ansattoversikten",
        variant: "destructive",
      });
      navigate("/dashboard");
    }
  }, [user, profile, authLoading, navigate, canAccess]);

  const { data: ansatte = [], isLoading, refetch } = useQuery({
    queryKey: ["ansatte", selectedSalonId],
    queryFn: () => getAnsatteBySalong(selectedSalonId!),
    enabled: !!selectedSalonId,
  });

  // Filter ansatte based on status tab
  const activeAnsatte = ansatte.filter(a => a.status !== 'Arkivert');
  const archivedAnsatte = ansatte.filter(a => a.status === 'Arkivert');

  // Apply search and filters
  const filterAnsatte = (list: AnsattUtvidet[]) => {
    return list.filter(ansatt => {
      // Search filter
      const searchLower = searchQuery.toLowerCase();
      const matchesSearch = !searchQuery || 
        ansatt.fornavn?.toLowerCase().includes(searchLower) ||
        ansatt.etternavn?.toLowerCase().includes(searchLower) ||
        ansatt.epost?.toLowerCase().includes(searchLower) ||
        ansatt.telefon?.includes(searchQuery);

      // Role filter
      const matchesRole = roleFilter === "all" || 
        ansatt.frisorfunksjon === roleFilter ||
        ansatt.lederstilling === roleFilter;

      return matchesSearch && matchesRole;
    });
  };

  const filteredActive = sortByFirstNameFirst(filterAnsatte(activeAnsatte));
  const filteredArchived = sortByFirstNameFirst(filterAnsatte(archivedAnsatte));

  const handleCreateAnsatt = () => {
    setSelectedAnsatt(null);
    setDialogOpen(true);
  };

  const handleEditAnsatt = (ansatt: AnsattUtvidet) => {
    setSelectedAnsatt(ansatt);
    setDialogOpen(true);
  };

  const handleViewAnsatt = (ansatt: AnsattUtvidet) => {
    navigate(`/ansatte/${ansatt.id}`);
  };

  const handleDialogClose = () => {
    setDialogOpen(false);
    setSelectedAnsatt(null);
    refetch();
  };

  if (authLoading || salonLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Laster...</p>
        </div>
      </div>
    );
  }

  return (
    <AppLayout title="Ansatte" subtitle="Administrer ansatte, roller og kompetanse">
      <div className="container mx-auto px-4 py-6 space-y-6">

        {!selectedSalonId ? (
          <div className="text-center py-12">
            <Users className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <h2 className="text-lg font-semibold mb-2">Velg en salong</h2>
            <p className="text-muted-foreground">
              Velg en salong for å se ansatte
            </p>
          </div>
        ) : (
          <>
            {/* Statistics Cards */}
            <AnsattStats ansatte={activeAnsatte} isLoading={isLoading} />

            {/* Tabs for Active/Archived */}
            <Tabs defaultValue="aktive" className="space-y-4">
              <div className="flex flex-wrap gap-3 items-center justify-between">
                <TabsList>
                  <TabsTrigger value="aktive">
                    Aktive ({filteredActive.length})
                  </TabsTrigger>
                  <TabsTrigger value="arkiverte">
                    Arkiverte ({filteredArchived.length})
                  </TabsTrigger>
                </TabsList>

                {/* Search, filters and actions */}
                <div className="flex flex-wrap gap-3 items-center flex-1 justify-end">
                  <div className="relative min-w-[200px] max-w-md">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Søk etter navn, e-post..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-9"
                    />
                  </div>
                  
                  <Select value={roleFilter} onValueChange={setRoleFilter}>
                    <SelectTrigger className="w-[160px]">
                      <Filter className="h-4 w-4 mr-2" />
                      <SelectValue placeholder="Alle roller" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Alle roller</SelectItem>
                      <SelectItem value="frisor">Frisør</SelectItem>
                      <SelectItem value="senior_frisor">Seniorfrisør</SelectItem>
                      <SelectItem value="laerling">Lærling</SelectItem>
                      <SelectItem value="daglig_leder">Daglig leder</SelectItem>
                      <SelectItem value="avdelingsleder">Avdelingsleder</SelectItem>
                    </SelectContent>
                  </Select>

                  <ToggleGroup 
                    type="single" 
                    value={viewMode} 
                    onValueChange={(v) => v && setViewMode(v as "table" | "cards")}
                    className="border rounded-lg"
                  >
                    <ToggleGroupItem value="table" aria-label="Tabellvisning" className="px-3">
                      <List className="h-4 w-4" />
                    </ToggleGroupItem>
                    <ToggleGroupItem value="cards" aria-label="Kortvisning" className="px-3">
                      <LayoutGrid className="h-4 w-4" />
                    </ToggleGroupItem>
                  </ToggleGroup>

                  <Button onClick={() => navigate('/ansatte/ny')}>
                    <UserPlus className="h-4 w-4 mr-2" />
                    Ny ansatt
                  </Button>
                  <Button variant="outline" onClick={handleCreateAnsatt}>
                    <UserPlus className="h-4 w-4 mr-2" />
                    Legg til ansatt
                  </Button>
                </div>
              </div>

              <TabsContent value="aktive">
                {viewMode === "table" ? (
                  <AnsattTabell 
                    ansatte={filteredActive} 
                    isLoading={isLoading}
                    onEdit={handleEditAnsatt}
                    onView={handleViewAnsatt}
                    onRefetch={refetch}
                  />
                ) : (
                  <AnsattKort 
                    ansatte={filteredActive} 
                    isLoading={isLoading}
                    onEdit={handleEditAnsatt}
                    onView={handleViewAnsatt}
                  />
                )}
              </TabsContent>

              <TabsContent value="arkiverte">
                {viewMode === "table" ? (
                  <AnsattTabell 
                    ansatte={filteredArchived} 
                    isLoading={isLoading}
                    onEdit={handleEditAnsatt}
                    onView={handleViewAnsatt}
                    onRefetch={refetch}
                    isArchived
                  />
                ) : (
                  <AnsattKort 
                    ansatte={filteredArchived} 
                    isLoading={isLoading}
                    onEdit={handleEditAnsatt}
                    onView={handleViewAnsatt}
                    isArchived
                  />
                )}
              </TabsContent>
            </Tabs>
          </>
        )}

        {/* Create/Edit Dialog */}
        <AnsattDialog
          open={dialogOpen}
          onOpenChange={setDialogOpen}
          ansatt={selectedAnsatt}
          salongId={selectedSalonId || ""}
          onSuccess={handleDialogClose}
        />
      </div>
    </AppLayout>
  );
};

export default Ansatte;
