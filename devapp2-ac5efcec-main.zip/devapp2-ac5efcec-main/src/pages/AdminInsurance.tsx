import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { AppLayout } from "@/components/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { toast } from "sonner";
import { RefreshCw, Search, Shield, Building2, Users, DollarSign, AlertCircle, Download, Clock, ChevronDown, FileSignature, FileText } from "lucide-react";
import { InsuranceSalonList } from "@/components/insurance/InsuranceSalonList";
import { InsuranceSalonDetail } from "@/components/insurance/InsuranceSalonDetail";
import { InsuranceOrderHistory } from "@/components/insurance/InsuranceOrderHistory";
import { InsurancePendingApprovals } from "@/components/insurance/InsurancePendingApprovals";
import { InsuranceProductsTab } from "@/components/admin/InsuranceProductsTab";
import { InsuranceAdminForm } from "@/components/insurance/InsuranceAdminForm";
import { PowerOfAttorneyTab } from "@/components/admin/PowerOfAttorneyTab";
import { InsuranceQuotesOverview } from "@/components/insurance/InsuranceQuotesOverview";
interface SalonInsurance {
  id: string;
  salon_id: string;
  hubspot_synced_at: string | null;
  aktivering_dato: string | null;
  innmelding_dato: string | null;
  oppsigelse_dato: string | null;
  avsluttede_forsikringer: boolean;
  helse_status: boolean;
  antall_ansatte: number | null;
  antall_arsverk: number | null;
  antall_fritidsulykke: number | null;
  antall_reiseforsikring: number | null;
  arlig_omsetning: number | null;
  cyber_aktiv: boolean;
  fritidsulykke_aktiv: boolean;
  reise_aktiv: boolean;
  salong_aktiv: boolean;
  yrkesskadeforsikring_aktiv: boolean;
  salong_niva: string | null;
  sum_mvil: string | null;
  pris_cyber: number | null;
  pris_fritidsulykke: number | null;
  pris_reise: number | null;
  pris_salong: number | null;
  pris_yrkesskadeforsikring: number | null;
  sum_fritidsulykke: number | null;
  sum_reise: number | null;
  sum_totalt: number | null;
  sum_yrkesskadeforsikring: number | null;
  kontaktperson_navn: string | null;
  kontaktperson_epost: string | null;
  helse_antall_aktive: number | null;
  salons: {
    id: string;
    name: string;
    hs_object_id: string | null;
    hubspot_owner_id: string | null;
  };
  district_name?: string | null;
}
export default function AdminInsurance() {
  const navigate = useNavigate();
  const {
    profile
  } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSalonId, setSelectedSalonId] = useState<string | null>(null);
  const queryClient = useQueryClient();
  const isAdmin = profile?.role === "admin";
  const isDistrictManager = profile?.role === "district_manager";

  // Redirect if not admin or district manager
  if (!isAdmin && !isDistrictManager) {
    navigate("/dashboard");
    return null;
  }

  // Fetch all insurance data with salon info
  const {
    data: insuranceData,
    isLoading: insuranceLoading
  } = useQuery({
    queryKey: ["salon-insurance"],
    queryFn: async () => {
      // First get owner mappings for district names
      const { data: ownerMappings } = await supabase
        .from("hubspot_owner_district_mapping")
        .select("hubspot_owner_id, districts:district_id (name)");
      
      const ownerToDistrict = new Map(
        ownerMappings?.map(m => [m.hubspot_owner_id, m.districts?.name]) || []
      );

      const { data, error } = await supabase
        .from("salon_insurance")
        .select(`
          *,
          salons:salon_id (
            id,
            name,
            hs_object_id,
            hubspot_owner_id
          )
        `)
        .or("salong_aktiv.eq.true,yrkesskadeforsikring_aktiv.eq.true,cyber_aktiv.eq.true,reise_aktiv.eq.true,fritidsulykke_aktiv.eq.true,helse_status.eq.true")
        .order("created_at", { ascending: false });
      
      if (error) throw error;
      
      // Add district_name to each item
      return (data || []).map(item => ({
        ...item,
        district_name: item.salons?.hubspot_owner_id 
          ? ownerToDistrict.get(item.salons.hubspot_owner_id) || null 
          : null
      })) as SalonInsurance[];
    }
  });

  // Fetch salons without insurance (admin)
  const {
    data: salonsWithoutInsurance
  } = useQuery({
    queryKey: ["salons-without-insurance"],
    queryFn: async () => {
      const {
        data: allSalons
      } = await supabase.from("salons").select("id, name, hs_object_id").not("hs_object_id", "is", null);
      const {
        data: existingInsurance
      } = await supabase.from("salon_insurance").select("salon_id");
      const existingIds = new Set(existingInsurance?.map(i => i.salon_id) || []);
      return allSalons?.filter(s => !existingIds.has(s.id)) || [];
    },
    enabled: isAdmin
  });

  // Fetch pending orders count
  const {
    data: pendingOrdersCount
  } = useQuery({
    queryKey: ["pending-orders-count"],
    queryFn: async () => {
      const {
        count,
        error
      } = await supabase.from("insurance_orders").select("*", {
        count: "exact",
        head: true
      }).eq("status", "pending_approval");
      if (error) throw error;
      return count || 0;
    },
    enabled: isAdmin
  });

  // Fetch order statistics
  const {
    data: orderStats
  } = useQuery({
    queryKey: ["insurance-order-stats"],
    queryFn: async () => {
      const {
        data,
        error
      } = await supabase.from("insurance_orders").select("status, total_price");
      if (error) throw error;
      const stats = {
        pending: 0,
        sent: 0,
        approved: 0,
        invoiced: 0,
        completed: 0,
        rejected: 0,
        totalValue: 0,
        completedValue: 0
      };
      data?.forEach(order => {
        switch (order.status) {
          case "pending_approval":
            stats.pending++;
            stats.totalValue += order.total_price || 0;
            break;
          case "sent_to_frende":
            stats.sent++;
            stats.totalValue += order.total_price || 0;
            break;
          case "approved":
            stats.approved++;
            stats.totalValue += order.total_price || 0;
            break;
          case "invoiced":
            stats.invoiced++;
            stats.totalValue += order.total_price || 0;
            break;
          case "completed":
            stats.completed++;
            stats.completedValue += order.total_price || 0;
            break;
          case "rejected":
            stats.rejected++;
            break;
        }
      });
      return stats;
    },
    enabled: isAdmin
  });

  // Sync all insurance data mutation
  const syncAllMutation = useMutation({
    mutationFn: async () => {
      const {
        data: {
          session
        }
      } = await supabase.auth.getSession();
      if (!session) throw new Error("Ikke logget inn");
      const response = await supabase.functions.invoke("hubspot-api", {
        body: {
          action: "sync_all_insurance"
        }
      });
      if (response.error) throw response.error;
      return response.data;
    },
    onSuccess: data => {
      queryClient.invalidateQueries({
        queryKey: ["salon-insurance"]
      });
      queryClient.invalidateQueries({
        queryKey: ["salons-without-insurance"]
      });
      toast.success(`Synkronisering fullført: ${data.synced} salonger oppdatert`);
    },
    onError: error => {
      toast.error(`Synkronisering feilet: ${error.message}`);
    }
  });

  // Import insured salons mutation
  const importInsuredMutation = useMutation({
    mutationFn: async () => {
      const {
        data: {
          session
        }
      } = await supabase.auth.getSession();
      if (!session) throw new Error("Ikke logget inn");
      const response = await supabase.functions.invoke("hubspot-api", {
        body: {
          action: "import_insured_salons"
        }
      });
      if (response.error) throw response.error;
      return response.data;
    },
    onSuccess: data => {
      queryClient.invalidateQueries({
        queryKey: ["salon-insurance"]
      });
      toast.success(`Import fullført: ${data.imported} nye salonger importert`);
    },
    onError: error => {
      toast.error(`Import feilet: ${error.message}`);
    }
  });

  // Import health insurance contacts mutation
  const importHealthMutation = useMutation({
    mutationFn: async () => {
      const {
        data: {
          session
        }
      } = await supabase.auth.getSession();
      if (!session) throw new Error("Ikke logget inn");
      const response = await supabase.functions.invoke("hubspot-api", {
        body: {
          action: "import_health_insurance_contacts"
        }
      });
      if (response.error) throw response.error;
      return response.data;
    },
    onSuccess: data => {
      queryClient.invalidateQueries({
        queryKey: ["salon-insurance"]
      });
      queryClient.invalidateQueries({
        queryKey: ["salon-health-insurance"]
      });
      toast.success(`Helseforsikring synkronisert: ${data.created} nye, ${data.updated} oppdatert`);
    },
    onError: error => {
      toast.error(`Synkronisering feilet: ${error.message}`);
    }
  });
  const HELSE_PRIS_PER_PERSON = 5050;

  // Calculate statistics
  const countActivePolicies = () => {
    let count = 0;
    insuranceData?.forEach(i => {
      if (i.salong_aktiv) count++;
      if (i.cyber_aktiv) count++;
      if (i.reise_aktiv) count++;
      if (i.fritidsulykke_aktiv) count++;
      if (i.yrkesskadeforsikring_aktiv) count++;
      if (i.helse_status) count++;
    });
    return count;
  };
  const calculateTotalPremium = () => {
    let total = 0;
    insuranceData?.forEach(i => {
      total += i.sum_totalt || 0;
      total += (i.helse_antall_aktive || 0) * HELSE_PRIS_PER_PERSON;
    });
    return total;
  };
  const calculatePremiumBreakdown = () => {
    const breakdown = {
      bedrift: {
        salong: 0,
        yrkesskade: 0,
        cyber: 0,
        reise: 0,
        fritidsulykke: 0,
        total: 0
      },
      helse: {
        total: 0,
        antall: 0
      }
    };
    insuranceData?.forEach(i => {
      if (i.salong_aktiv) breakdown.bedrift.salong += i.pris_salong || 0;
      if (i.yrkesskadeforsikring_aktiv) breakdown.bedrift.yrkesskade += i.sum_yrkesskadeforsikring || 0;
      if (i.cyber_aktiv) breakdown.bedrift.cyber += i.pris_cyber || 0;
      if (i.reise_aktiv) breakdown.bedrift.reise += i.sum_reise || 0;
      if (i.fritidsulykke_aktiv) breakdown.bedrift.fritidsulykke += i.sum_fritidsulykke || 0;
      breakdown.bedrift.total += i.sum_totalt || 0;
      if (i.helse_status && i.helse_antall_aktive) {
        breakdown.helse.total += i.helse_antall_aktive * HELSE_PRIS_PER_PERSON;
        breakdown.helse.antall += i.helse_antall_aktive;
      }
    });
    return breakdown;
  };
  const premiumBreakdown = calculatePremiumBreakdown();
  const stats = {
    totalSalons: insuranceData?.length || 0,
    activePolicies: countActivePolicies(),
    totalPremium: calculateTotalPremium(),
    withSalong: insuranceData?.filter(i => i.salong_aktiv).length || 0,
    withYrkesskade: insuranceData?.reduce((sum, i) => sum + (i.yrkesskadeforsikring_aktiv ? i.antall_arsverk || 0 : 0), 0) || 0,
    withCyber: insuranceData?.filter(i => i.cyber_aktiv).length || 0,
    withReise: insuranceData?.reduce((sum, i) => sum + (i.reise_aktiv ? i.antall_reiseforsikring || 0 : 0), 0) || 0,
    withFritidsulykke: insuranceData?.reduce((sum, i) => sum + (i.fritidsulykke_aktiv ? i.antall_fritidsulykke || 0 : 0), 0) || 0,
    withHelse: insuranceData?.reduce((sum, i) => sum + (i.helse_status ? i.helse_antall_aktive || 0 : 0), 0) || 0
  };

  // Filter insurance data
  const filteredData = insuranceData?.filter(item => item.salons?.name?.toLowerCase().includes(searchQuery.toLowerCase()) || item.district_name?.toLowerCase().includes(searchQuery.toLowerCase()));
  const selectedInsurance = insuranceData?.find(i => i.salon_id === selectedSalonId);
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("nb-NO", {
      style: "currency",
      currency: "NOK",
      maximumFractionDigits: 0
    }).format(price);
  };
  return <AppLayout title="Forsikringsadmin" subtitle="Administrer forsikringer for alle salonger">
      <div className="container mx-auto px-4 py-8 space-y-6">
        {/* Admin actions */}
        {isAdmin && <div className="flex flex-wrap gap-2 justify-end">
            <Button variant="outline" onClick={() => importInsuredMutation.mutate()} disabled={importInsuredMutation.isPending}>
              <Download className={`h-4 w-4 mr-2 ${importInsuredMutation.isPending ? 'animate-pulse' : ''}`} />
              Importer salonger
            </Button>
            <Button variant="outline" onClick={() => importHealthMutation.mutate()} disabled={importHealthMutation.isPending}>
              <Users className={`h-4 w-4 mr-2 ${importHealthMutation.isPending ? 'animate-pulse' : ''}`} />
              Synk helseforsikring
            </Button>
            <Button onClick={() => syncAllMutation.mutate()} disabled={syncAllMutation.isPending}>
              <RefreshCw className={`h-4 w-4 mr-2 ${syncAllMutation.isPending ? 'animate-spin' : ''}`} />
              Synk alle
            </Button>
          </div>}

        {/* Stats cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 items-stretch">
          <Popover>
            <PopoverTrigger asChild>
              <Card className="cursor-pointer hover:bg-muted/50 transition-colors h-full flex flex-col">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Salonger med forsikring</CardTitle>
                  <ChevronDown className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent className="flex-1 flex flex-col justify-between">
                  <div className="text-2xl font-bold">{stats.totalSalons}</div>
                  <p className="text-xs text-muted-foreground">
                    Klikk for detaljer
                  </p>
                </CardContent>
              </Card>
            </PopoverTrigger>
            <PopoverContent className="w-64 bg-card border shadow-lg z-50" align="start">
              <div className="space-y-3">
                <h4 className="font-semibold text-sm">Salongoversikt</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Med forsikring</span>
                    <span className="font-medium">{stats.totalSalons}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Uten forsikring</span>
                    <span className="font-medium">{salonsWithoutInsurance?.length || 0}</span>
                  </div>
                  <div className="flex justify-between font-semibold pt-2 border-t">
                    <span>Totalt</span>
                    <span>{stats.totalSalons + (salonsWithoutInsurance?.length || 0)}</span>
                  </div>
                </div>
                {salonsWithoutInsurance && salonsWithoutInsurance.length > 0 && (
                  <button 
                    onClick={() => navigate("/admin/insurance/prospects")} 
                    className="w-full p-2 rounded-md bg-amber-100 dark:bg-amber-900/50 hover:bg-amber-200 dark:hover:bg-amber-900 transition-colors text-left"
                  >
                    <div className="flex items-center gap-2">
                      <div className="h-1.5 w-1.5 rounded-full bg-amber-500 shrink-0" />
                      <span className="text-xs font-medium text-amber-700 dark:text-amber-400">Se prospekter →</span>
                    </div>
                  </button>
                )}
              </div>
            </PopoverContent>
          </Popover>

          <Popover>
            <PopoverTrigger asChild>
              <Card className="cursor-pointer hover:bg-muted/50 transition-colors h-full flex flex-col">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Aktive poliser</CardTitle>
                  <ChevronDown className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent className="flex-1 flex flex-col justify-between">
                  <div className="text-2xl font-bold">{stats.activePolicies}</div>
                  <p className="text-xs text-muted-foreground">
                    Klikk for detaljer
                  </p>
                </CardContent>
              </Card>
            </PopoverTrigger>
            <PopoverContent className="w-64 bg-card border shadow-lg z-50" align="start">
              <div className="space-y-2">
                <h4 className="font-semibold text-sm mb-3">Poliser per produkt</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Salongforsikring</span>
                    <span className="font-medium">{stats.withSalong}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Yrkesskadeforsikring</span>
                    <span className="font-medium">{Math.round(stats.withYrkesskade)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Cyberforsikring</span>
                    <span className="font-medium">{stats.withCyber}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Reiseforsikring</span>
                    <span className="font-medium">{stats.withReise}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Fritidsulykke</span>
                    <span className="font-medium">{stats.withFritidsulykke}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Helseforsikring</span>
                    <span className="font-medium">{stats.withHelse}</span>
                  </div>
                  <div className="flex justify-between font-semibold pt-2 border-t">
                    <span>Totalt</span>
                    <span>{stats.activePolicies}</span>
                  </div>
                </div>
              </div>
            </PopoverContent>
          </Popover>

          <Popover>
            <PopoverTrigger asChild>
              <Card className="cursor-pointer hover:bg-muted/50 transition-colors h-full flex flex-col">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total premie</CardTitle>
                  <ChevronDown className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent className="flex-1 flex flex-col justify-between">
                  <div className="text-2xl font-bold">
                    {Math.round(stats.totalPremium).toLocaleString("nb-NO")} kr
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Klikk for detaljer
                  </p>
                </CardContent>
              </Card>
            </PopoverTrigger>
            <PopoverContent className="w-80 bg-card border shadow-lg z-50" align="start">
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold text-sm mb-2">Bedriftsforsikring</h4>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Salongforsikring</span>
                      <span>{Math.round(premiumBreakdown.bedrift.salong).toLocaleString("nb-NO")} kr</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Yrkesskadeforsikring</span>
                      <span>{Math.round(premiumBreakdown.bedrift.yrkesskade).toLocaleString("nb-NO")} kr</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Cyberforsikring</span>
                      <span>{Math.round(premiumBreakdown.bedrift.cyber).toLocaleString("nb-NO")} kr</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Reiseforsikring</span>
                      <span>{Math.round(premiumBreakdown.bedrift.reise).toLocaleString("nb-NO")} kr</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Fritidsulykke</span>
                      <span>{Math.round(premiumBreakdown.bedrift.fritidsulykke).toLocaleString("nb-NO")} kr</span>
                    </div>
                    <div className="flex justify-between font-medium pt-1 border-t">
                      <span>Sum bedrift</span>
                      <span>{Math.round(premiumBreakdown.bedrift.total).toLocaleString("nb-NO")} kr</span>
                    </div>
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold text-sm mb-2">Helseforsikring</h4>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">{premiumBreakdown.helse.antall} personer × {HELSE_PRIS_PER_PERSON.toLocaleString("nb-NO")} kr</span>
                      <span>{Math.round(premiumBreakdown.helse.total).toLocaleString("nb-NO")} kr</span>
                    </div>
                  </div>
                </div>
                <div className="pt-2 border-t">
                  <div className="flex justify-between font-semibold">
                    <span>Total årlig premie</span>
                    <span>{Math.round(stats.totalPremium).toLocaleString("nb-NO")} kr</span>
                  </div>
                </div>
              </div>
            </PopoverContent>
          </Popover>

          <Card className="h-full flex flex-col">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Forsikringsfordeling</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent className="flex-1">
              <div className="flex gap-2 flex-wrap">
                <Badge variant="outline">{stats.withSalong} Salong</Badge>
                <Badge variant="outline">{Math.round(stats.withYrkesskade)} Yrkesskade</Badge>
                <Badge variant="outline">{stats.withCyber} Cyber</Badge>
                <Badge variant="outline">{stats.withReise} Reise</Badge>
                <Badge variant="outline">{stats.withFritidsulykke} Fritidsulykke</Badge>
                <Badge variant="outline">{stats.withHelse} Helse</Badge>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Order pipeline stats (admin only) */}
        {isAdmin && orderStats && <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Bestillingspipeline
              </CardTitle>
              <CardDescription>Oversikt over alle bestillinger i systemet</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
                <div className="text-center p-3 rounded-lg bg-amber-50 border border-amber-200">
                  <p className="text-2xl font-bold text-amber-700">{orderStats.pending}</p>
                  <p className="text-xs text-amber-600">Venter godkjenning</p>
                </div>
                <div className="text-center p-3 rounded-lg bg-purple-50 border border-purple-200">
                  <p className="text-2xl font-bold text-purple-700">{orderStats.sent}</p>
                  <p className="text-xs text-purple-600">Sendt til Frende</p>
                </div>
                <div className="text-center p-3 rounded-lg bg-blue-50 border border-blue-200">
                  <p className="text-2xl font-bold text-blue-700">{orderStats.approved}</p>
                  <p className="text-xs text-blue-600">Godkjent</p>
                </div>
                <div className="text-center p-3 rounded-lg bg-orange-50 border border-orange-200">
                  <p className="text-2xl font-bold text-orange-700">{orderStats.invoiced}</p>
                  <p className="text-xs text-orange-600">Fakturert</p>
                </div>
                <div className="text-center p-3 rounded-lg bg-green-50 border border-green-200">
                  <p className="text-2xl font-bold text-green-700">{orderStats.completed}</p>
                  <p className="text-xs text-green-600">Fullført</p>
                </div>
                <div className="text-center p-3 rounded-lg bg-red-50 border border-red-200">
                  <p className="text-2xl font-bold text-red-700">{orderStats.rejected}</p>
                  <p className="text-xs text-red-600">Avvist</p>
                </div>
              </div>
              <div className="mt-4 pt-4 border-t flex justify-between text-sm">
                <span className="text-muted-foreground">Aktive bestillinger (verdi)</span>
                <span className="font-medium">{formatPrice(orderStats.totalValue)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Fullførte bestillinger (verdi)</span>
                <span className="font-medium text-green-600">{formatPrice(orderStats.completedValue)}</span>
              </div>
            </CardContent>
          </Card>}

        {/* Tabs for different views */}
        <Tabs defaultValue="salons" className="w-full">
          <TabsList>
            <TabsTrigger value="salons">Salonger</TabsTrigger>
            <TabsTrigger value="quotes">
              <FileText className="h-4 w-4 mr-1" />
              Tilbud
            </TabsTrigger>
            <TabsTrigger value="orders">Alle bestillinger</TabsTrigger>
            {isAdmin && <TabsTrigger value="pending" className="relative">
                Ventende
                {pendingOrdersCount !== undefined && pendingOrdersCount > 0 && <Badge variant="destructive" className="ml-2 h-5 w-5 p-0 flex items-center justify-center text-xs">
                    {pendingOrdersCount}
                  </Badge>}
              </TabsTrigger>}
            {isAdmin && <TabsTrigger value="fullmakter">
              <FileSignature className="h-4 w-4 mr-1" />
              Fullmakter
            </TabsTrigger>}
            {isAdmin && <TabsTrigger value="products">Produkter</TabsTrigger>}
            {isAdmin && <TabsTrigger value="hubspot-admin">Forsikringsadministrasjon</TabsTrigger>}
          </TabsList>

          <TabsContent value="salons" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Salongoversikt</CardTitle>
                <CardDescription>
                  Søk og filtrer forsikringsdata for salonger
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="Søk på salongnavn eller distrikt..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="pl-10" />
                </div>

                {insuranceLoading ? <div className="space-y-2">
                    {[...Array(5)].map((_, i) => <Skeleton key={i} className="h-16 w-full" />)}
                  </div> : filteredData && filteredData.length > 0 ? <InsuranceSalonList data={filteredData} onSelect={salonId => setSelectedSalonId(salonId)} /> : <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                    <AlertCircle className="h-12 w-12 mb-4" />
                    <p>Ingen forsikringsdata funnet</p>
                    {isAdmin && <Button variant="outline" className="mt-4" onClick={() => syncAllMutation.mutate()} disabled={syncAllMutation.isPending}>
                        Synkroniser fra HubSpot
                      </Button>}
                  </div>}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="quotes" className="mt-4">
            <InsuranceQuotesOverview />
          </TabsContent>

          <TabsContent value="orders" className="mt-4">
            <InsuranceOrderHistory />
          </TabsContent>

          <TabsContent value="pending" className="mt-4">
            {isAdmin && <InsurancePendingApprovals />}
          </TabsContent>

          <TabsContent value="products" className="mt-4">
            {isAdmin && <InsuranceProductsTab />}
          </TabsContent>

          <TabsContent value="fullmakter" className="mt-4">
            {isAdmin && <PowerOfAttorneyTab />}
          </TabsContent>

          <TabsContent value="hubspot-admin" className="mt-4">
            {isAdmin && <InsuranceAdminForm open={true} onOpenChange={() => {}} embedded />}
          </TabsContent>
        </Tabs>

        {/* Detail dialog */}
        {selectedInsurance && <InsuranceSalonDetail insurance={selectedInsurance} open={!!selectedSalonId} onClose={() => setSelectedSalonId(null)} />}
      </div>
    </AppLayout>;
}