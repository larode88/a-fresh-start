import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { AppLayout } from '@/components/AppLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { ChevronDown, ChevronRight, Plus, Pencil, Trash2, Search, Package, Loader2, FlaskConical, ShoppingBag, Upload, Link2 } from 'lucide-react';
import { toast } from 'sonner';

const runLorealImport = async () => {
  const { data, error } = await supabase.functions.invoke('import-loreal-customers');
  if (error) {
    toast.error('Import feilet: ' + error.message);
    return null;
  }
  return data;
};

const runMariaNilaImport = async () => {
  const { data, error } = await supabase.functions.invoke('import-maria-nila-customers');
  if (error) {
    toast.error('Import feilet: ' + error.message);
    return null;
  }
  return data;
};

const runIconHairspaImport = async () => {
  const { data, error } = await supabase.functions.invoke('import-icon-hairspa-customers');
  if (error) {
    toast.error('Import feilet: ' + error.message);
    return null;
  }
  return data;
};

interface Leverandor {
  id: string;
  navn: string;
  hubspot_company_id?: string;
  aktiv: boolean;
  created_at: string;
}

interface Merke {
  id: string;
  leverandor_id: string;
  navn: string;
  har_kjemi: boolean;
  har_produkter: boolean;
  aktiv: boolean;
}

interface SupplierIdentifier {
  id: string;
  supplier_id: string;
  salon_id: string;
  supplier_customer_number: string;
  identifier_type: string;
  created_at: string;
  updated_at: string;
  leverandorer: { navn: string };
  salons: { name: string };
}

export default function LeverandorAdmin() {
  const queryClient = useQueryClient();
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedLeverandorer, setExpandedLeverandorer] = useState<Set<string>>(new Set());
  const [identifiersExpanded, setIdentifiersExpanded] = useState(false);
  const [identifierSearch, setIdentifierSearch] = useState('');
  const [selectedSupplierFilter, setSelectedSupplierFilter] = useState<string>('all');
  
  // Dialog states
  const [leverandorDialog, setLeverandorDialog] = useState<{ open: boolean; leverandor?: Leverandor }>({ open: false });
  const [merkeDialog, setMerkeDialog] = useState<{ open: boolean; leverandorId?: string; merke?: Merke }>({ open: false });
  const [deleteDialog, setDeleteDialog] = useState<{ open: boolean; type: 'leverandor' | 'merke' | 'identifier'; id: string; navn: string } | null>(null);
  
  // Form states
  const [leverandorForm, setLeverandorForm] = useState({ navn: '', aktiv: true });
  const [merkeForm, setMerkeForm] = useState({ navn: '', har_kjemi: false, har_produkter: false, aktiv: true });
  const [isImportingLoreal, setIsImportingLoreal] = useState(false);
  const [isImportingMariaNila, setIsImportingMariaNila] = useState(false);
  const [isImportingIconHairspa, setIsImportingIconHairspa] = useState(false);
  const handleLorealImport = async () => {
    setIsImportingLoreal(true);
    try {
      const result = await runLorealImport();
      if (result) {
        toast.success(`Import fullført: ${result.inserted} L'Oréal kundenumre lagt til. ${result.notFoundCount} salonger ikke funnet i systemet.`);
        console.log('Import result:', result);
      }
    } finally {
      setIsImportingLoreal(false);
    }
  };

  const handleMariaNilaImport = async () => {
    setIsImportingMariaNila(true);
    try {
      const result = await runMariaNilaImport();
      if (result) {
        toast.success(`Import fullført: ${result.inserted} Maria Nila kundenumre lagt til. ${result.notFoundCount} salonger ikke funnet i systemet.`);
        console.log('Import result:', result);
      }
    } finally {
      setIsImportingMariaNila(false);
    }
  };

  const handleIconHairspaImport = async () => {
    setIsImportingIconHairspa(true);
    try {
      const result = await runIconHairspaImport();
      if (result) {
        toast.success(`Import fullført: ${result.inserted} ICON Hairspa kundenumre lagt til. ${result.notFound} salonger ikke funnet i systemet.`);
        console.log('Import result:', result);
      }
    } finally {
      setIsImportingIconHairspa(false);
    }
  };

  const { data: leverandorer = [], isLoading: isLoadingLeverandorer } = useQuery({
    queryKey: ['admin-leverandorer'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('leverandorer')
        .select('*')
        .order('navn');
      if (error) throw error;
      return data as Leverandor[];
    },
  });

  const { data: merker = [] } = useQuery({
    queryKey: ['admin-leverandor-merker'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('leverandor_merker')
        .select('*')
        .order('navn');
      if (error) throw error;
      return data as Merke[];
    },
  });

  const { data: identifiers = [] } = useQuery({
    queryKey: ['admin-supplier-identifiers'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('supplier_identifiers')
        .select(`
          *,
          leverandorer!inner(navn),
          salons!inner(name)
        `)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data as SupplierIdentifier[];
    },
  });

  // Mutations
  const createLeverandor = useMutation({
    mutationFn: async (data: { navn: string; aktiv: boolean }) => {
      const { error } = await supabase.from('leverandorer').insert(data);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-leverandorer'] });
      toast.success('Leverandør opprettet');
      setLeverandorDialog({ open: false });
    },
    onError: () => toast.error('Kunne ikke opprette leverandør'),
  });

  const updateLeverandor = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<Leverandor> }) => {
      const { error } = await supabase.from('leverandorer').update(data).eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-leverandorer'] });
      toast.success('Leverandør oppdatert');
      setLeverandorDialog({ open: false });
    },
    onError: () => toast.error('Kunne ikke oppdatere leverandør'),
  });

  const deleteLeverandor = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('leverandorer').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-leverandorer'] });
      toast.success('Leverandør slettet');
      setDeleteDialog(null);
    },
    onError: () => toast.error('Kunne ikke slette leverandør'),
  });

  const createMerke = useMutation({
    mutationFn: async (data: { navn: string; har_kjemi: boolean; har_produkter: boolean; aktiv: boolean; leverandor_id: string }) => {
      const { error } = await supabase.from('leverandor_merker').insert(data);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-leverandor-merker'] });
      toast.success('Merke opprettet');
      setMerkeDialog({ open: false });
    },
    onError: () => toast.error('Kunne ikke opprette merke'),
  });

  const updateMerke = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<Merke> }) => {
      const { error } = await supabase.from('leverandor_merker').update(data).eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-leverandor-merker'] });
      toast.success('Merke oppdatert');
      setMerkeDialog({ open: false });
    },
    onError: () => toast.error('Kunne ikke oppdatere merke'),
  });

  const deleteMerke = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('leverandor_merker').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-leverandor-merker'] });
      toast.success('Merke slettet');
      setDeleteDialog(null);
    },
    onError: () => toast.error('Kunne ikke slette merke'),
  });

  const deleteIdentifier = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('supplier_identifiers').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-supplier-identifiers'] });
      toast.success('Kobling slettet');
      setDeleteDialog(null);
    },
    onError: () => toast.error('Kunne ikke slette kobling'),
  });

  const toggleExpanded = (id: string) => {
    const newSet = new Set(expandedLeverandorer);
    if (newSet.has(id)) {
      newSet.delete(id);
    } else {
      newSet.add(id);
    }
    setExpandedLeverandorer(newSet);
  };

  const getMerkerForLeverandor = (leverandorId: string) => {
    return merker.filter(m => m.leverandor_id === leverandorId);
  };

  const filteredLeverandorer = leverandorer.filter(l =>
    l.navn.toLowerCase().includes(searchQuery.toLowerCase()) ||
    merker.some(m => m.leverandor_id === l.id && m.navn.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  // Filter identifiers
  const filteredIdentifiers = identifiers.filter(i => {
    const matchesSupplier = selectedSupplierFilter === 'all' || i.supplier_id === selectedSupplierFilter;
    const matchesSearch = identifierSearch === '' ||
      i.supplier_customer_number.toLowerCase().includes(identifierSearch.toLowerCase()) ||
      i.salons?.name?.toLowerCase().includes(identifierSearch.toLowerCase());
    return matchesSupplier && matchesSearch;
  });

  // Get unique suppliers that have identifiers
  const suppliersWithIdentifiers = leverandorer.filter(l => 
    identifiers.some(i => i.supplier_id === l.id)
  );

  const openLeverandorDialog = (leverandor?: Leverandor) => {
    setLeverandorForm(leverandor ? { navn: leverandor.navn, aktiv: leverandor.aktiv } : { navn: '', aktiv: true });
    setLeverandorDialog({ open: true, leverandor });
  };

  const openMerkeDialog = (leverandorId: string, merke?: Merke) => {
    setMerkeForm(merke 
      ? { navn: merke.navn, har_kjemi: merke.har_kjemi, har_produkter: merke.har_produkter, aktiv: merke.aktiv } 
      : { navn: '', har_kjemi: false, har_produkter: false, aktiv: true }
    );
    setMerkeDialog({ open: true, leverandorId, merke });
  };

  const handleSaveLeverandor = () => {
    if (!leverandorForm.navn.trim()) {
      toast.error('Navn er påkrevd');
      return;
    }
    if (leverandorDialog.leverandor) {
      updateLeverandor.mutate({ id: leverandorDialog.leverandor.id, data: leverandorForm });
    } else {
      createLeverandor.mutate(leverandorForm);
    }
  };

  const handleSaveMerke = () => {
    if (!merkeForm.navn.trim()) {
      toast.error('Navn er påkrevd');
      return;
    }
    if (!merkeForm.har_kjemi && !merkeForm.har_produkter) {
      toast.error('Velg minst én produkttype');
      return;
    }
    if (merkeDialog.merke) {
      updateMerke.mutate({ id: merkeDialog.merke.id, data: merkeForm });
    } else if (merkeDialog.leverandorId) {
      createMerke.mutate({ ...merkeForm, leverandor_id: merkeDialog.leverandorId });
    }
  };

  if (isLoadingLeverandorer) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-serif font-semibold text-foreground">Leverandør Admin</h1>
            <p className="text-muted-foreground">Administrer leverandører og deres merker</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={handleLorealImport} disabled={isImportingLoreal}>
              {isImportingLoreal ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Upload className="h-4 w-4 mr-2" />}
              Import L'Oréal
            </Button>
            <Button variant="outline" onClick={handleMariaNilaImport} disabled={isImportingMariaNila}>
              {isImportingMariaNila ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Upload className="h-4 w-4 mr-2" />}
              Import Maria Nila
            </Button>
            <Button variant="outline" onClick={handleIconHairspaImport} disabled={isImportingIconHairspa}>
              {isImportingIconHairspa ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <Upload className="h-4 w-4 mr-2" />}
              Import ICON
            </Button>
            <Button onClick={() => openLeverandorDialog()}>
              <Plus className="h-4 w-4 mr-2" />
              Ny leverandør
            </Button>
          </div>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Søk etter leverandør eller merke..."
            className="pl-10"
          />
        </div>

        {/* Stats */}
        <div className="flex gap-4">
          <Badge variant="secondary" className="gap-1">
            <Package className="h-3 w-3" />
            {leverandorer.length} leverandører
          </Badge>
          <Badge variant="outline" className="gap-1">
            {merker.length} merker totalt
          </Badge>
        </div>

        {/* Leverandører */}
        <div className="space-y-3">
          {filteredLeverandorer.map((leverandor) => {
            const leverandorMerker = getMerkerForLeverandor(leverandor.id);
            const isExpanded = expandedLeverandorer.has(leverandor.id);

            return (
              <Card key={leverandor.id} className={!leverandor.aktiv ? 'opacity-60' : ''}>
                <Collapsible open={isExpanded} onOpenChange={() => toggleExpanded(leverandor.id)}>
                  <CollapsibleTrigger asChild>
                    <CardHeader className="cursor-pointer hover:bg-muted/50 transition-colors py-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          {isExpanded ? (
                            <ChevronDown className="h-4 w-4 text-muted-foreground" />
                          ) : (
                            <ChevronRight className="h-4 w-4 text-muted-foreground" />
                          )}
                          <CardTitle className="text-base">{leverandor.navn}</CardTitle>
                          {!leverandor.aktiv && <Badge variant="outline">Inaktiv</Badge>}
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-muted-foreground">
                            {leverandorMerker.length} merker
                          </span>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={(e) => { e.stopPropagation(); openLeverandorDialog(leverandor); }}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8 text-destructive hover:text-destructive"
                            onClick={(e) => {
                              e.stopPropagation();
                              setDeleteDialog({ open: true, type: 'leverandor', id: leverandor.id, navn: leverandor.navn });
                            }}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                  </CollapsibleTrigger>

                  <CollapsibleContent>
                    <CardContent className="pt-0 space-y-3">
                      {/* Merker */}
                      {leverandorMerker.map((merke) => (
                        <div
                          key={merke.id}
                          className={`flex items-center justify-between p-3 rounded-lg border ${!merke.aktiv ? 'opacity-60 bg-muted/30' : 'bg-muted/30'}`}
                        >
                          <div className="flex items-center gap-3">
                            <span className="font-medium">{merke.navn}</span>
                            <div className="flex gap-1.5">
                              {merke.har_kjemi && (
                                <Badge variant="secondary" className="text-xs gap-1">
                                  <FlaskConical className="h-3 w-3" />
                                  Kjemi
                                </Badge>
                              )}
                              {merke.har_produkter && (
                                <Badge variant="outline" className="text-xs gap-1">
                                  <ShoppingBag className="h-3 w-3" />
                                  Videre salg
                                </Badge>
                              )}
                            </div>
                            {!merke.aktiv && <Badge variant="secondary" className="text-xs">Inaktiv</Badge>}
                          </div>
                          <div className="flex items-center gap-1">
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-7 w-7"
                              onClick={() => openMerkeDialog(leverandor.id, merke)}
                            >
                              <Pencil className="h-3 w-3" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-7 w-7 text-destructive hover:text-destructive"
                              onClick={() => setDeleteDialog({ open: true, type: 'merke', id: merke.id, navn: merke.navn })}
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      ))}

                      <Button
                        variant="outline"
                        size="sm"
                        className="w-full"
                        onClick={() => openMerkeDialog(leverandor.id)}
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        Legg til merke
                      </Button>
                    </CardContent>
                  </CollapsibleContent>
                </Collapsible>
              </Card>
            );
          })}
        </div>

        {filteredLeverandorer.length === 0 && (
          <p className="text-center text-muted-foreground py-8">
            Ingen leverandører funnet
          </p>
        )}

        {/* Kundenummer-koblinger */}
        <Card className="mt-6">
          <Collapsible open={identifiersExpanded} onOpenChange={setIdentifiersExpanded}>
            <CollapsibleTrigger asChild>
              <CardHeader className="cursor-pointer hover:bg-muted/50 transition-colors py-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {identifiersExpanded ? (
                      <ChevronDown className="h-4 w-4 text-muted-foreground" />
                    ) : (
                      <ChevronRight className="h-4 w-4 text-muted-foreground" />
                    )}
                    <Link2 className="h-4 w-4 text-muted-foreground" />
                    <CardTitle className="text-base">Kundenummer-koblinger</CardTitle>
                    <Badge variant="secondary">{identifiers.length}</Badge>
                  </div>
                </div>
              </CardHeader>
            </CollapsibleTrigger>
            
            <CollapsibleContent>
              <CardContent className="pt-0 space-y-4">
                {/* Filters */}
                <div className="flex gap-3">
                  <div className="flex-1">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input
                        value={identifierSearch}
                        onChange={(e) => setIdentifierSearch(e.target.value)}
                        placeholder="Søk kundenummer eller salongnavn..."
                        className="pl-10"
                      />
                    </div>
                  </div>
                  <Select value={selectedSupplierFilter} onValueChange={setSelectedSupplierFilter}>
                    <SelectTrigger className="w-[200px]">
                      <SelectValue placeholder="Alle leverandører" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Alle leverandører</SelectItem>
                      {suppliersWithIdentifiers.map(s => (
                        <SelectItem key={s.id} value={s.id}>
                          {s.navn} ({identifiers.filter(i => i.supplier_id === s.id).length})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Table */}
                {filteredIdentifiers.length > 0 ? (
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Kundenummer</TableHead>
                          <TableHead>Salong</TableHead>
                          <TableHead>Leverandør</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead className="w-[50px]"></TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filteredIdentifiers.slice(0, 100).map((identifier) => (
                          <TableRow key={identifier.id}>
                            <TableCell className="font-mono text-sm">
                              {identifier.supplier_customer_number}
                            </TableCell>
                            <TableCell>{identifier.salons?.name}</TableCell>
                            <TableCell>{identifier.leverandorer?.navn}</TableCell>
                            <TableCell>
                              {identifier.identifier_type === 'manual_match' ? (
                                <Badge variant="default" className="bg-green-600">Manuell</Badge>
                              ) : (
                                <Badge variant="secondary">{identifier.identifier_type}</Badge>
                              )}
                            </TableCell>
                            <TableCell>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-7 w-7 text-destructive hover:text-destructive"
                                onClick={() => setDeleteDialog({
                                  open: true,
                                  type: 'identifier',
                                  id: identifier.id,
                                  navn: `${identifier.supplier_customer_number} → ${identifier.salons?.name}`
                                })}
                              >
                                <Trash2 className="h-3 w-3" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                ) : (
                  <p className="text-center text-muted-foreground py-4 text-sm">
                    Ingen koblinger funnet
                  </p>
                )}
                
                {filteredIdentifiers.length > 100 && (
                  <p className="text-center text-muted-foreground text-xs">
                    Viser 100 av {filteredIdentifiers.length} koblinger
                  </p>
                )}
              </CardContent>
            </CollapsibleContent>
          </Collapsible>
        </Card>
      </div>

      {/* Leverandør Dialog */}
      <Dialog open={leverandorDialog.open} onOpenChange={(open) => setLeverandorDialog({ open })}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{leverandorDialog.leverandor ? 'Rediger leverandør' : 'Ny leverandør'}</DialogTitle>
            <DialogDescription>
              {leverandorDialog.leverandor ? 'Oppdater leverandørens informasjon' : 'Opprett en ny leverandør'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="lev-navn">Navn</Label>
              <Input
                id="lev-navn"
                value={leverandorForm.navn}
                onChange={(e) => setLeverandorForm(f => ({ ...f, navn: e.target.value }))}
                placeholder="Leverandørnavn"
              />
            </div>
            <div className="flex items-center justify-between">
              <Label htmlFor="lev-aktiv">Aktiv</Label>
              <Switch
                id="lev-aktiv"
                checked={leverandorForm.aktiv}
                onCheckedChange={(checked) => setLeverandorForm(f => ({ ...f, aktiv: checked }))}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setLeverandorDialog({ open: false })}>Avbryt</Button>
            <Button 
              onClick={handleSaveLeverandor}
              disabled={createLeverandor.isPending || updateLeverandor.isPending}
            >
              {(createLeverandor.isPending || updateLeverandor.isPending) && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              {leverandorDialog.leverandor ? 'Oppdater' : 'Opprett'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Merke Dialog */}
      <Dialog open={merkeDialog.open} onOpenChange={(open) => setMerkeDialog({ open })}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{merkeDialog.merke ? 'Rediger merke' : 'Nytt merke'}</DialogTitle>
            <DialogDescription>
              {merkeDialog.merke ? 'Oppdater merkets informasjon' : 'Opprett et nytt merke for denne leverandøren'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="merke-navn">Navn</Label>
              <Input
                id="merke-navn"
                value={merkeForm.navn}
                onChange={(e) => setMerkeForm(f => ({ ...f, navn: e.target.value }))}
                placeholder="Merkenavn"
              />
            </div>
            
            <div className="space-y-3">
              <Label>Produkttyper dette merket tilbyr</Label>
              <div className="space-y-3">
                <div className="flex items-start gap-3 p-3 rounded-lg border bg-muted/30">
                  <Checkbox
                    id="har-kjemi"
                    checked={merkeForm.har_kjemi}
                    onCheckedChange={(checked) => setMerkeForm(f => ({ ...f, har_kjemi: !!checked }))}
                  />
                  <div className="space-y-1">
                    <Label htmlFor="har-kjemi" className="font-medium cursor-pointer flex items-center gap-2">
                      <FlaskConical className="h-4 w-4 text-muted-foreground" />
                      Kjemi
                    </Label>
                    <p className="text-xs text-muted-foreground">
                      Farger, blekemidler, permanentvæske, etc.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3 p-3 rounded-lg border bg-muted/30">
                  <Checkbox
                    id="har-produkter"
                    checked={merkeForm.har_produkter}
                    onCheckedChange={(checked) => setMerkeForm(f => ({ ...f, har_produkter: !!checked }))}
                  />
                  <div className="space-y-1">
                    <Label htmlFor="har-produkter" className="font-medium cursor-pointer flex items-center gap-2">
                      <ShoppingBag className="h-4 w-4 text-muted-foreground" />
                      Videre salg
                    </Label>
                    <p className="text-xs text-muted-foreground">
                      Shampoo, balsam, stylingprodukter, etc.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="flex items-center justify-between">
              <Label htmlFor="merke-aktiv">Aktiv</Label>
              <Switch
                id="merke-aktiv"
                checked={merkeForm.aktiv}
                onCheckedChange={(checked) => setMerkeForm(f => ({ ...f, aktiv: checked }))}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setMerkeDialog({ open: false })}>Avbryt</Button>
            <Button 
              onClick={handleSaveMerke}
              disabled={createMerke.isPending || updateMerke.isPending}
            >
              {(createMerke.isPending || updateMerke.isPending) && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              {merkeDialog.merke ? 'Oppdater' : 'Opprett'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteDialog?.open} onOpenChange={(open) => !open && setDeleteDialog(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Er du sikker?</AlertDialogTitle>
            <AlertDialogDescription>
              Dette vil slette {deleteDialog?.type === 'leverandor' ? 'leverandøren' : deleteDialog?.type === 'merke' ? 'merket' : 'koblingen'} "{deleteDialog?.navn}".
              {deleteDialog?.type === 'leverandor' && ' Alle tilknyttede merker vil også bli slettet.'}
              Denne handlingen kan ikke angres.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Avbryt</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => {
                if (deleteDialog?.type === 'leverandor') {
                  deleteLeverandor.mutate(deleteDialog.id);
                } else if (deleteDialog?.type === 'merke') {
                  deleteMerke.mutate(deleteDialog.id);
                } else if (deleteDialog?.type === 'identifier') {
                  deleteIdentifier.mutate(deleteDialog.id);
                }
              }}
            >
              Slett
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AppLayout>
  );
}
