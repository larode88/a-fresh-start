import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Stethoscope, Plus, Calendar, FileText, AlertCircle } from "lucide-react";
import { format, differenceInWeeks } from "date-fns";
import { nb } from "date-fns/locale";
import { SykmeldingRegistreringDialog } from "@/components/sykmelding/SykmeldingRegistreringDialog";
import { Link } from "react-router-dom";

const Sykmelding = () => {
  const { user, profile } = useAuth();
  const [showRegistreringsDialog, setShowRegistreringsDialog] = useState(false);

  const { data: mineSykmeldinger, isLoading, refetch } = useQuery({
    queryKey: ['mine-sykmeldinger', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('sykemeldinger')
        .select(`
          *,
          sykmelding_oppfolgingsplaner(id, laast, versjon),
          sykmelding_dialogmoter(id, motetype, status)
        `)
        .eq('user_id', user?.id)
        .order('startdato', { ascending: false });

      if (error) throw error;
      return data;
    },
    enabled: !!user?.id,
  });

  const aktiveSykmeldinger = mineSykmeldinger?.filter(s => s.status === 'aktiv') || [];
  const historiskeSykmeldinger = mineSykmeldinger?.filter(s => s.status !== 'aktiv') || [];

  const getGradBadgeColor = (grad: number) => {
    if (grad === 100) return "destructive";
    if (grad >= 50) return "secondary";
    return "outline";
  };

  const getUkerSykemeldt = (startdato: string) => {
    return differenceInWeeks(new Date(), new Date(startdato));
  };

  return (
    <div className="container mx-auto py-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-serif font-bold text-foreground">Min Sykmelding</h1>
          <p className="text-muted-foreground mt-1">Registrer og følg opp sykmeldinger</p>
        </div>
        <Button onClick={() => setShowRegistreringsDialog(true)} className="gap-2">
          <Plus className="h-4 w-4" />
          Jeg er sykmeldt
        </Button>
      </div>

      {/* Aktive sykmeldinger */}
      <div className="space-y-4">
        <h2 className="text-xl font-semibold flex items-center gap-2">
          <Stethoscope className="h-5 w-5 text-primary" />
          Aktive sykmeldinger
        </h2>
        
        {isLoading ? (
          <Card>
            <CardContent className="py-8 text-center text-muted-foreground">
              Laster...
            </CardContent>
          </Card>
        ) : aktiveSykmeldinger.length === 0 ? (
          <Card>
            <CardContent className="py-8 text-center text-muted-foreground">
              <div className="flex flex-col items-center gap-2">
                <Stethoscope className="h-8 w-8 text-muted-foreground/50" />
                <p>Du har ingen aktive sykmeldinger</p>
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-4 md:grid-cols-2">
            {aktiveSykmeldinger.map((sykmelding) => {
              const uker = getUkerSykemeldt(sykmelding.startdato);
              const harPlan = sykmelding.sykmelding_oppfolgingsplaner?.some((p: any) => p.laast);
              const harDialogmote1 = sykmelding.sykmelding_dialogmoter?.some(
                (m: any) => m.motetype === 'dialogmote_1' && m.status === 'gjennomfort'
              );

              return (
                <Card key={sykmelding.id} className="hover:shadow-md transition-shadow">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg">
                          Sykmelding {sykmelding.grad}%
                        </CardTitle>
                        <CardDescription>
                          Fra {format(new Date(sykmelding.startdato), 'dd. MMMM yyyy', { locale: nb })}
                        </CardDescription>
                      </div>
                      <Badge variant={getGradBadgeColor(sykmelding.grad)}>
                        Uke {uker}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {sykmelding.beskrivelse && (
                      <p className="text-sm text-muted-foreground">{sykmelding.beskrivelse}</p>
                    )}
                    
                    <div className="flex flex-wrap gap-2">
                      {harPlan ? (
                        <Badge variant="outline" className="gap-1">
                          <FileText className="h-3 w-3" />
                          Oppfølgingsplan klar
                        </Badge>
                      ) : uker >= 4 ? (
                        <Badge variant="destructive" className="gap-1">
                          <AlertCircle className="h-3 w-3" />
                          Oppfølgingsplan mangler
                        </Badge>
                      ) : null}
                      
                      {harDialogmote1 ? (
                        <Badge variant="outline" className="gap-1">
                          <Calendar className="h-3 w-3" />
                          Dialogmøte 1 gjennomført
                        </Badge>
                      ) : uker >= 7 ? (
                        <Badge variant="destructive" className="gap-1">
                          <AlertCircle className="h-3 w-3" />
                          Dialogmøte 1 mangler
                        </Badge>
                      ) : null}
                    </div>

                    <Link to={`/sykmelding/${sykmelding.id}`}>
                      <Button variant="outline" className="w-full mt-2">
                        Se detaljer
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      {/* Historiske sykmeldinger */}
      {historiskeSykmeldinger.length > 0 && (
        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-muted-foreground">Tidligere sykmeldinger</h2>
          <div className="grid gap-4 md:grid-cols-3">
            {historiskeSykmeldinger.map((sykmelding) => (
              <Card key={sykmelding.id} className="opacity-75">
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between">
                    <CardTitle className="text-base">
                      {sykmelding.grad}% sykmelding
                    </CardTitle>
                    <Badge variant="outline">
                      {sykmelding.status === 'avsluttet' ? 'Avsluttet' : 'Avbrutt'}
                    </Badge>
                  </div>
                  <CardDescription>
                    {format(new Date(sykmelding.startdato), 'MMM yyyy', { locale: nb })}
                    {sykmelding.faktisk_sluttdato && (
                      <> – {format(new Date(sykmelding.faktisk_sluttdato), 'MMM yyyy', { locale: nb })}</>
                    )}
                  </CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>
      )}

      <SykmeldingRegistreringDialog
        open={showRegistreringsDialog}
        onOpenChange={setShowRegistreringsDialog}
        onSuccess={() => {
          refetch();
          setShowRegistreringsDialog(false);
        }}
      />
    </div>
  );
};

export default Sykmelding;
