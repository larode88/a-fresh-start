import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { AppLayout } from "@/components/AppLayout";
import {
  Building2,
  MessageSquare,
  Users,
  TrendingUp,
} from "lucide-react";

interface PartnerSalon {
  id: string;
  name: string;
  city: string | null;
  address: string | null;
  stylistCount: number;
}

interface SupplierInfo {
  id: string;
  name: string;
}

const SupplierDashboard = () => {
  const navigate = useNavigate();
  const { user, profile, loading } = useAuth();
  const { toast } = useToast();
  const [supplierInfo, setSupplierInfo] = useState<SupplierInfo | null>(null);
  const [partnerSalons, setPartnerSalons] = useState<PartnerSalon[]>([]);
  const [loadingData, setLoadingData] = useState(true);

  useEffect(() => {
    if (!loading && !user) {
      navigate("/login");
      return;
    }

    if (!loading && profile && !["supplier_admin", "supplier_sales", "supplier_business_dev", "admin"].includes(profile.role)) {
      toast({
        title: "Ingen tilgang",
        description: "Du har ikke tilgang til leverandør-dashboardet",
        variant: "destructive",
      });
      navigate("/dashboard");
    }
  }, [user, profile, loading, navigate, toast]);

  useEffect(() => {
    if (user && profile) {
      fetchSupplierData();
    }
  }, [user, profile]);

  const fetchSupplierData = async () => {
    setLoadingData(true);
    try {
      if (profile?.role === "admin") {
        const { data: suppliers } = await supabase
          .from("suppliers")
          .select("id, name")
          .eq("active", true)
          .limit(1);

        if (suppliers && suppliers.length > 0) {
          setSupplierInfo(suppliers[0]);
          await fetchPartnerSalons(suppliers[0].id);
        }
      } else {
        const { data: teamData } = await supabase
          .from("supplier_team_users")
          .select("supplier_id")
          .eq("user_id", user!.id)
          .eq("active", true)
          .single();

        if (teamData) {
          const { data: supplier } = await supabase
            .from("suppliers")
            .select("id, name")
            .eq("id", teamData.supplier_id)
            .single();

          if (supplier) {
            setSupplierInfo(supplier);
            await fetchPartnerSalons(supplier.id);
          }
        }
      }
    } catch (error) {
      console.error("Error fetching supplier data:", error);
    } finally {
      setLoadingData(false);
    }
  };

  const fetchPartnerSalons = async (supplierId: string) => {
    try {
      const { data: relationships } = await supabase
        .from("salon_suppliers")
        .select("salon_id")
        .eq("supplier_id", supplierId);

      if (!relationships || relationships.length === 0) {
        setPartnerSalons([]);
        return;
      }

      const salonIds = relationships.map((r) => r.salon_id);

      const { data: salons } = await supabase
        .from("salons")
        .select("id, name, city, address")
        .in("id", salonIds);

      const { data: users } = await supabase
        .from("users")
        .select("salon_id")
        .in("salon_id", salonIds);

      const countMap = new Map<string, number>();
      users?.forEach((u) => {
        if (u.salon_id) {
          countMap.set(u.salon_id, (countMap.get(u.salon_id) || 0) + 1);
        }
      });

      const salonsWithCount: PartnerSalon[] = (salons || []).map((s) => ({
        ...s,
        stylistCount: countMap.get(s.id) || 0,
      }));

      setPartnerSalons(salonsWithCount);
    } catch (error) {
      console.error("Error fetching partner salons:", error);
    }
  };

  const startConversation = (salonId: string, salonName: string) => {
    navigate(`/messages?salon=${salonId}&subject=Kontakt fra ${supplierInfo?.name} til ${salonName}`);
  };

  if (loading || loadingData) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <AppLayout title="Leverandør Dashboard" subtitle={supplierInfo?.name}>
      <div className="max-w-6xl mx-auto p-4 space-y-6">
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="p-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <Building2 className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Partnersalonger</p>
                <p className="text-2xl font-bold text-foreground">{partnerSalons.length}</p>
              </div>
            </div>
          </Card>
          <Card className="p-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-success/10 flex items-center justify-center">
                <Users className="h-5 w-5 text-success" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Frisører totalt</p>
                <p className="text-2xl font-bold text-foreground">
                  {partnerSalons.reduce((sum, s) => sum + s.stylistCount, 0)}
                </p>
              </div>
            </div>
          </Card>
          <Card className="p-6">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-warning/10 flex items-center justify-center">
                <TrendingUp className="h-5 w-5 text-warning" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Status</p>
                <p className="text-lg font-bold text-foreground">Aktiv</p>
              </div>
            </div>
          </Card>
        </div>

        {/* Partner Salons */}
        <Card className="p-6">
          <h2 className="text-lg font-semibold text-foreground mb-4">Partnersalonger</h2>
          
          {partnerSalons.length === 0 ? (
            <div className="text-center py-8">
              <Building2 className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground">Ingen partnersalonger ennå</p>
              <p className="text-sm text-muted-foreground mt-1">
                Kontakt administrator for å koble salonger
              </p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Salong</TableHead>
                  <TableHead>By</TableHead>
                  <TableHead>Adresse</TableHead>
                  <TableHead>Frisører</TableHead>
                  <TableHead className="text-right">Handlinger</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {partnerSalons.map((salon) => (
                  <TableRow key={salon.id}>
                    <TableCell className="font-medium">{salon.name}</TableCell>
                    <TableCell>{salon.city || "-"}</TableCell>
                    <TableCell>{salon.address || "-"}</TableCell>
                    <TableCell>
                      <Badge variant="secondary">{salon.stylistCount}</Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => startConversation(salon.id, salon.name)}
                      >
                        <MessageSquare className="h-4 w-4 mr-2" />
                        Kontakt
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </Card>
      </div>
    </AppLayout>
  );
};

export default SupplierDashboard;
