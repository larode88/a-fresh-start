import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useSalonContext } from "@/components/SalonSelector";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { AlertCircle, Stethoscope, Plus, ChevronLeft, ChevronRight } from "lucide-react";
import { AbsenceList } from "@/components/leave/AbsenceList";
import { SykmeldingDashboard } from "@/components/sykmelding/SykmeldingDashboard";
import { SykmeldingRegistreringDialog } from "@/components/sykmelding/SykmeldingRegistreringDialog";
import { AppLayout } from "@/components/AppLayout";

export default function LeaveAbsence() {
  const { user, profile, loading: authLoading } = useAuth();
  const role = profile?.role;
  const { salons, selectedSalonId, setSelectedSalonId, loading: salonLoading, canSelectSalon } = useSalonContext();

  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [sykmeldinger, setSykmeldinger] = useState<any[]>([]);
  const [sykmeldingLoading, setSykmeldingLoading] = useState(false);
  const [showRegistreringDialog, setShowRegistreringDialog] = useState(false);

  const canManage = ["admin", "salon_owner", "daglig_leder", "avdelingsleder"].includes(role || "");

  const years = [selectedYear - 1, selectedYear, selectedYear + 1];

  // Fetch sykmeldinger for the selected salon
  useEffect(() => {
    const fetchSykmeldinger = async () => {
      if (!selectedSalonId || !canManage) return;

      setSykmeldingLoading(true);
      try {
        const { data, error } = await supabase
          .from("sykemeldinger" as any)
          .select(`
            *,
            users:user_id(id, name, avatar_url),
            sykmelding_oppfolgingsplaner(*),
            sykmelding_dialogmoter(*)
          `)
          .eq("salon_id", selectedSalonId)
          .eq("status", "aktiv");

        if (error) throw error;
        setSykmeldinger(data || []);
      } catch (error) {
        console.error("Error fetching sykmeldinger:", error);
      } finally {
        setSykmeldingLoading(false);
      }
    };

    fetchSykmeldinger();
  }, [selectedSalonId, canManage]);

  if (authLoading || salonLoading) {
    return (
      <div className="container mx-auto p-6 space-y-6">
        <Skeleton className="h-10 w-48" />
        <Skeleton className="h-96" />
      </div>
    );
  }

  return (
    <AppLayout title="Fravær" subtitle="Administrer fravær og sykefraværsoppfølging">
      <div className="container mx-auto p-6 space-y-6">
        {/* Controls */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8"
              onClick={() => setSelectedYear(y => y - 1)}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Select value={selectedYear.toString()} onValueChange={(v) => setSelectedYear(parseInt(v))}>
              <SelectTrigger className="w-28">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {years.map(y => (
                  <SelectItem key={y} value={y.toString()}>{y}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8"
              onClick={() => setSelectedYear(y => y + 1)}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>

        </div>

        {!selectedSalonId ? (
          <Card>
            <CardContent className="pt-6">
              <p className="text-center text-muted-foreground">Velg en salong.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            <Tabs defaultValue="absence" className="space-y-4">
              <TabsList>
                <TabsTrigger value="absence" className="flex items-center gap-2">
                  <AlertCircle className="h-4 w-4" />
                  Fravær
                </TabsTrigger>
                {canManage && (
                  <TabsTrigger value="sickleave" className="flex items-center gap-2">
                    <Stethoscope className="h-4 w-4" />
                    Sykefraværsoppfølging
                  </TabsTrigger>
                )}
              </TabsList>

              <TabsContent value="absence" className="space-y-6">
                <AbsenceList 
                  salonId={selectedSalonId} 
                  userId={canManage ? undefined : user?.id}
                  year={selectedYear}
                  canManage={canManage} 
                />
              </TabsContent>

              {canManage && (
                <TabsContent value="sickleave" className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-lg font-semibold">Aktive sykmeldinger</h3>
                      <p className="text-sm text-muted-foreground">
                        Trafikklyssystem for oppfølging av sykmeldte ansatte
                      </p>
                    </div>
                    <Button onClick={() => setShowRegistreringDialog(true)} className="gap-2">
                      <Plus className="h-4 w-4" />
                      Registrer sykmelding
                    </Button>
                  </div>

                  <SykmeldingDashboard 
                    sykmeldinger={sykmeldinger}
                    isLoading={sykmeldingLoading}
                  />
                </TabsContent>
              )}
            </Tabs>
          </div>
        )}

        <SykmeldingRegistreringDialog
          open={showRegistreringDialog}
          onOpenChange={setShowRegistreringDialog}
          onSuccess={() => {
            setShowRegistreringDialog(false);
            // Refresh sykmeldinger
            if (selectedSalonId && canManage) {
              supabase
                .from("sykemeldinger" as any)
                .select(`
                  *,
                  users:user_id(id, name, avatar_url),
                  sykmelding_oppfolgingsplaner(*),
                  sykmelding_dialogmoter(*)
                `)
                .eq("salon_id", selectedSalonId)
                .eq("status", "aktiv")
                .then(({ data }) => {
                  if (data) setSykmeldinger(data);
                });
            }
          }}
        />
      </div>
    </AppLayout>
  );
}
