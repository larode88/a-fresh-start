import { useState, useEffect, useCallback } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { AppLayout } from '@/components/AppLayout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Check, ChevronLeft, ChevronRight, Save, Loader2, Cloud, CloudOff } from 'lucide-react';
import { useAutosave, AutosaveStatus } from '@/hooks/useAutosave';
import { toast } from 'sonner';
import InnmeldingSteg1 from '@/components/innmelding/InnmeldingSteg1';
import InnmeldingSteg2 from '@/components/innmelding/InnmeldingSteg2';
import InnmeldingSteg3 from '@/components/innmelding/InnmeldingSteg3';
import InnmeldingSteg4 from '@/components/innmelding/InnmeldingSteg4';
import InnmeldingSteg5 from '@/components/innmelding/InnmeldingSteg5';
import InnmeldingSteg6 from '@/components/innmelding/InnmeldingSteg7';

export interface InnmeldingData {
  // Steg 1: Bedriftsinfo
  org_nummer: string;
  navn: string;
  adresse: string;
  postnummer: string;
  poststed: string;
  telefon: string;
  epost: string;
  stiftelsesdato?: string;
  antall_ansatte?: number;
  // Finansiell info
  sum_driftsinntekter?: number;
  driftsresultat?: number;
  regnskapsaar?: number;
  
  // Steg 2: Kontaktpersoner
  kontaktpersoner: KontaktpersonData[];
  
  // Steg 3: Medlemsoppsett
  type_medlemskap: string;
  medlemsavgift: number;
  medlemsavgift_type: 'prosent' | 'fast'; // 1% av omsetning eller fast avgift
  har_provetid: boolean; // 12 måneders prøvetid
  innmeldingsavgift_rabatt: number; // 0-100%
  bankkontonummer?: string;
  fakturaadresse?: string;
  district_id?: string;
  hubspot_owner_id?: string;
  hubspot_owner_name?: string;
  
  // Steg 4: Leverandører
  leverandorer: LeverandorValg[];
  
  // Steg 5: Avtale
  avtale_url?: string;
  avtale_status: 'utkast' | 'sendt' | 'signert' | 'manuell';
  
  // Fra prospekt (hvis relevant)
  prospekt_id?: string;
}

export interface KontaktpersonData {
  id?: string;
  fornavn: string;
  etternavn: string;
  epost: string;
  telefon?: string;
  tittel: string;
  er_hovedkontakt: boolean;
}

export type Rapporteringstype = 'kjemi' | 'produkt' | 'samlet' | 'begge_separat';

export interface MerkeValg {
  merke_id: string;
  merke_navn: string;
  rapporteringstype?: Rapporteringstype; // Optional - defined at brand level in admin
}

export interface LeverandorValg {
  leverandor_id: string;
  leverandor_navn: string;
  valgte_merker: MerkeValg[];
}

const STEPS = [
  { id: 1, title: 'Bedriftsinfo', description: 'BRREG-oppslag' },
  { id: 2, title: 'Kontaktpersoner', description: 'Legg til kontakter' },
  { id: 3, title: 'Medlemsoppsett', description: 'Type og avgift' },
  { id: 4, title: 'Leverandører', description: 'Velg leverandører' },
  { id: 5, title: 'Avtale', description: 'Generer og signer' },
  { id: 6, title: 'Fullfør', description: 'Opprett medlem' },
];

const INITIAL_DATA: InnmeldingData = {
  org_nummer: '',
  navn: '',
  adresse: '',
  postnummer: '',
  poststed: '',
  telefon: '',
  epost: '',
  kontaktpersoner: [],
  type_medlemskap: 'salong',
  medlemsavgift: 0,
  medlemsavgift_type: 'fast', // Default fast avgift
  har_provetid: false, // Default ingen prøvetid
  innmeldingsavgift_rabatt: 100, // Default 100% rabatt
  leverandorer: [],
  avtale_status: 'utkast',
};

export default function InnmeldingWizard() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [searchParams] = useSearchParams();
  const prospektId = searchParams.get('prospekt');
  const draftId = searchParams.get('draft');
  
  const [currentStep, setCurrentStep] = useState(1);
  const [data, setData] = useState<InnmeldingData>(INITIAL_DATA);
  const [isSaving, setIsSaving] = useState(false);
  const [loadedDraftId, setLoadedDraftId] = useState<string | null>(null);
  
  // Load draft if draftId is provided
  const { data: draft, isLoading: isDraftLoading } = useQuery({
    queryKey: ['innmelding-draft', draftId],
    queryFn: async () => {
      if (!draftId) return null;
      const { data, error } = await supabase
        .from('innmelding_utkast')
        .select('*')
        .eq('id', draftId)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!draftId,
  });

  // Pre-fill from prospekt if provided
  const { data: prospekt } = useQuery({
    queryKey: ['prospekt-for-innmelding', prospektId],
    queryFn: async () => {
      if (!prospektId) return null;
      const { data, error } = await supabase
        .from('prospekter')
        .select('*')
        .eq('id', prospektId)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!prospektId && !draftId,
  });

  // Get current user and their owner mapping (for district managers)
  const { data: ownerData } = useQuery({
    queryKey: ['current-user-owner'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return null;
      
      const { data: userData } = await supabase
        .from('users')
        .select('id, email, role, district_id')
        .eq('id', user.id)
        .single();
      
      let ownerMapping = null;
      if (userData?.role === 'district_manager') {
        const { data } = await supabase
          .from('hubspot_owner_district_mapping')
          .select('hubspot_owner_id, hubspot_owner_name, district_id')
          .eq('hubspot_owner_email', userData.email)
          .single();
        ownerMapping = data;
      }
      
      return { user: userData, owner: ownerMapping };
    },
  });

  // Load draft data when it's fetched
  useEffect(() => {
    if (draft && draft.id !== loadedDraftId) {
      const wizardData = draft.wizard_data as unknown as InnmeldingData;
      setData(wizardData);
      setCurrentStep(draft.current_step);
      setLoadedDraftId(draft.id);
    }
  }, [draft, loadedDraftId]);
  
  // Update data when prospekt loads (only if not loading a draft)
  useEffect(() => {
    if (prospekt && !draftId) {
      setData(prev => ({
        ...prev,
        org_nummer: prospekt.org_nummer || '',
        navn: prospekt.salongnavn || '',
        adresse: prospekt.adresse || '',
        postnummer: prospekt.postnummer || '',
        poststed: prospekt.sted || '',
        type_medlemskap: prospekt.type_medlemskap || 'salong',
        medlemsavgift: prospekt.estimert_medlemsavgift || 0,
        prospekt_id: prospekt.id,
        district_id: prospekt.district_id,
      }));
    }
  }, [prospekt, draftId]);

  // Auto-set owner for district managers
  useEffect(() => {
    if (ownerData?.user?.role === 'district_manager' && ownerData.owner && !draftId) {
      setData(prev => ({
        ...prev,
        hubspot_owner_id: ownerData.owner.hubspot_owner_id,
        hubspot_owner_name: ownerData.owner.hubspot_owner_name,
        district_id: prev.district_id || ownerData.owner.district_id,
      }));
    }
  }, [ownerData, draftId]);
  
  const updateData = (updates: Partial<InnmeldingData>) => {
    setData(prev => ({ ...prev, ...updates }));
  };

  // Save draft function (used by both manual save and autosave)
  const saveDraftToDb = useCallback(async (dataToSave: { data: InnmeldingData; currentStep: number }, status: 'utkast' | 'venter_signering' = 'utkast') => {
    const { data: saveData, currentStep: step } = dataToSave;
    if (!saveData.org_nummer || !saveData.navn) {
      return null;
    }

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Ikke innlogget');

    if (loadedDraftId) {
      // Update existing draft
      const { error } = await supabase
        .from('innmelding_utkast')
        .update({
          wizard_data: JSON.parse(JSON.stringify(saveData)),
          current_step: step,
          status,
          avtale_status: saveData.avtale_status,
        })
        .eq('id', loadedDraftId);
      
      if (error) throw error;
      return loadedDraftId;
    } else {
      // Create new draft
      const { data: newDraft, error } = await supabase
        .from('innmelding_utkast')
        .insert({
          wizard_data: JSON.parse(JSON.stringify(saveData)),
          current_step: step,
          org_nummer: saveData.org_nummer,
          salongnavn: saveData.navn,
          prospekt_id: saveData.prospekt_id || null,
          status,
          avtale_status: saveData.avtale_status,
          created_by: user.id,
        })
        .select('id')
        .single();
      
      if (error) throw error;
      setLoadedDraftId(newDraft.id);
      
      // Update URL with draft ID
      const newUrl = new URL(window.location.href);
      newUrl.searchParams.set('draft', newDraft.id);
      window.history.replaceState({}, '', newUrl.toString());
      
      return newDraft.id;
    }
  }, [loadedDraftId]);

  // Autosave hook - saves every 30 seconds when data changes
  const { status: autosaveStatus, lastSavedAt, forceSave } = useAutosave({
    data: { data, currentStep },
    onSave: async (dataToSave) => {
      await saveDraftToDb(dataToSave);
      queryClient.invalidateQueries({ queryKey: ['innmelding-utkast'] });
      if (loadedDraftId) {
        queryClient.invalidateQueries({ queryKey: ['innmelding-draft', loadedDraftId] });
      }
    },
    interval: 30000, // 30 seconds
    enabled: !!(data.org_nummer && data.navn), // Only autosave when we have basic data
  });

  // Manual save function
  const saveDraft = useCallback(async (status: 'utkast' | 'venter_signering' = 'utkast') => {
    if (!data.org_nummer || !data.navn) {
      toast.error('Fyll ut org.nummer og navn før du lagrer');
      return null;
    }

    setIsSaving(true);
    try {
      const result = await saveDraftToDb({ data, currentStep }, status);
      toast.success(loadedDraftId ? 'Utkast oppdatert' : 'Utkast lagret');
      return result;
    } catch (error) {
      console.error('Save draft error:', error);
      toast.error('Kunne ikke lagre utkast');
      return null;
    } finally {
      setIsSaving(false);
      queryClient.invalidateQueries({ queryKey: ['innmelding-utkast'] });
      if (loadedDraftId) {
        queryClient.invalidateQueries({ queryKey: ['innmelding-draft', loadedDraftId] });
      }
    }
  }, [data, currentStep, loadedDraftId, queryClient, saveDraftToDb]);

  // Auto-save when agreement is sent
  const handleAgreementSent = useCallback(async () => {
    await saveDraft('venter_signering');
    // Invalidate draft cache to ensure fresh data is loaded
    if (loadedDraftId) {
      queryClient.invalidateQueries({ queryKey: ['innmelding-draft', loadedDraftId] });
    }
  }, [saveDraft, loadedDraftId, queryClient]);

  // Mark draft as complete
  const markDraftComplete = useCallback(async () => {
    if (loadedDraftId) {
      await supabase
        .from('innmelding_utkast')
        .update({ status: 'ferdig' })
        .eq('id', loadedDraftId);
      queryClient.invalidateQueries({ queryKey: ['innmelding-utkast'] });
    }
  }, [loadedDraftId, queryClient]);
  
  const progress = (currentStep / STEPS.length) * 100;
  
  const canGoNext = () => {
    switch (currentStep) {
      case 1:
        return data.org_nummer && data.navn;
      case 2:
        return data.kontaktpersoner.length > 0 && data.kontaktpersoner.some(k => k.er_hovedkontakt);
      case 3:
        return data.type_medlemskap && data.medlemsavgift > 0 && data.district_id;
      case 4:
        return true;
      case 5:
        return data.avtale_status === 'signert' || data.avtale_status === 'manuell';
      case 6:
        return true;
      default:
        return false;
    }
  };
  
  const handleNext = () => {
    if (currentStep < STEPS.length) {
      setCurrentStep(prev => prev + 1);
    }
  };
  
  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleComplete = async () => {
    await markDraftComplete();
    navigate('/innmeldinger');
  };
  
  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return <InnmeldingSteg1 data={data} updateData={updateData} />;
      case 2:
        return <InnmeldingSteg2 data={data} updateData={updateData} />;
      case 3:
        return <InnmeldingSteg3 data={data} updateData={updateData} />;
      case 4:
        return <InnmeldingSteg4 data={data} updateData={updateData} />;
      case 5:
        return <InnmeldingSteg5 data={data} updateData={updateData} />;
      case 6:
        return <InnmeldingSteg6 data={data} updateData={updateData} onComplete={handleComplete} />;
      default:
        return null;
    }
  };

  if (isDraftLoading) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      </AppLayout>
    );
  }
  
  return (
    <AppLayout>
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-serif font-semibold text-foreground">
              Innmelding av nytt medlem
            </h1>
            <p className="text-muted-foreground">
              {loadedDraftId 
                ? `Fortsetter: ${data.navn}` 
                : prospekt 
                  ? `Fra prospekt: ${prospekt.salongnavn}` 
                  : 'Registrer nytt medlem i Hår1'}
            </p>
          </div>
          <div className="flex items-center gap-3">
            {/* Autosave status indicator */}
            {data.org_nummer && data.navn && (
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                {autosaveStatus === 'saving' && (
                  <>
                    <Loader2 className="h-3 w-3 animate-spin" />
                    <span>Lagrer...</span>
                  </>
                )}
                {autosaveStatus === 'saved' && (
                  <>
                    <Cloud className="h-3 w-3 text-green-600" />
                    <span className="text-green-600">Lagret</span>
                  </>
                )}
                {autosaveStatus === 'error' && (
                  <>
                    <CloudOff className="h-3 w-3 text-destructive" />
                    <span className="text-destructive">Feil ved lagring</span>
                  </>
                )}
                {autosaveStatus === 'idle' && lastSavedAt && (
                  <>
                    <Cloud className="h-3 w-3" />
                    <span>Sist lagret {lastSavedAt.toLocaleTimeString('nb-NO', { hour: '2-digit', minute: '2-digit' })}</span>
                  </>
                )}
              </div>
            )}
            <Button 
              variant="outline" 
              onClick={() => saveDraft()}
              disabled={isSaving || !data.org_nummer}
            >
              {isSaving ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Save className="h-4 w-4 mr-2" />
              )}
              Lagre utkast
            </Button>
            <Button variant="outline" onClick={() => navigate('/innmeldinger')}>
              Tilbake til liste
            </Button>
          </div>
        </div>
        
        {/* Progress */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between mb-4">
              {STEPS.map((step, index) => (
                <div 
                  key={step.id} 
                  className={`flex flex-col items-center ${index < STEPS.length - 1 ? 'flex-1' : ''}`}
                >
                  <div 
                    className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-medium transition-colors ${
                      step.id < currentStep 
                        ? 'bg-primary text-primary-foreground' 
                        : step.id === currentStep 
                          ? 'bg-primary text-primary-foreground ring-4 ring-primary/20' 
                          : 'bg-muted text-muted-foreground'
                    }`}
                  >
                    {step.id < currentStep ? <Check className="h-5 w-5" /> : step.id}
                  </div>
                  <span className={`text-xs mt-2 text-center hidden sm:block ${
                    step.id === currentStep ? 'text-foreground font-medium' : 'text-muted-foreground'
                  }`}>
                    {step.title}
                  </span>
                </div>
              ))}
            </div>
            <Progress value={progress} className="h-2" />
          </CardContent>
        </Card>
        
        {/* Current Step */}
        <Card>
          <CardHeader>
            <CardTitle>{STEPS[currentStep - 1].title}</CardTitle>
            <CardDescription>{STEPS[currentStep - 1].description}</CardDescription>
          </CardHeader>
          <CardContent>
            {renderStep()}
          </CardContent>
        </Card>
        
        {/* Navigation */}
        <div className="flex justify-between">
          <Button 
            variant="outline" 
            onClick={handleBack}
            disabled={currentStep === 1}
          >
            <ChevronLeft className="h-4 w-4 mr-2" />
            Forrige
          </Button>
          
          {currentStep < STEPS.length ? (
            <Button 
              onClick={handleNext}
              disabled={!canGoNext()}
            >
              Neste
              <ChevronRight className="h-4 w-4 ml-2" />
            </Button>
          ) : null}
        </div>
      </div>
    </AppLayout>
  );
}
