import { useState, useMemo } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Edit, Monitor, Smartphone } from "lucide-react";
import EmailPreview from "@/components/email-templates/EmailPreview";
import { replaceTokens, type EmailStructure, type EmailModule } from "@/lib/emailHtmlGenerator";

// Example values for token replacement
const EXAMPLE_VALUES: Record<string, string> = {
  fornavn: "Ola",
  etternavn: "Nordmann",
  navn: "Ola Nordmann",
  salongnavn: "Salong Eksempel AS",
  orgnummer: "123 456 789",
  epost: "ola@eksempel.no",
  telefon: "+47 123 45 678",
  avtalenummer: "HF-2024-12345",
  oppstartsdato: "1. januar 2025",
  total_pris: "45 000",
  distriktssjef: "Kari Konsulent",
  otp_kode: "123456",
  tilbudslink: "https://har1portalen.no/tilbud/abc123",
  invitasjonslenke: "https://har1portalen.no/signup?token=abc123",
};

function replaceTokensInStructure(structure: EmailStructure): EmailStructure {
  const processContent = (content: Record<string, unknown>): Record<string, unknown> => {
    const result: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(content)) {
      if (typeof value === 'string') {
        result[key] = replaceTokens(value, EXAMPLE_VALUES);
      } else if (Array.isArray(value)) {
        result[key] = value.map(item => 
          typeof item === 'string' ? replaceTokens(item, EXAMPLE_VALUES) : 
          typeof item === 'object' && item !== null ? processContent(item as Record<string, unknown>) : item
        );
      } else if (typeof value === 'object' && value !== null) {
        result[key] = processContent(value as Record<string, unknown>);
      } else {
        result[key] = value;
      }
    }
    return result;
  };

  return {
    modules: structure.modules.map(module => ({
      ...module,
      content: processContent(module.content) as Record<string, any>,
      styles: module.styles, // Preserve styles explicitly
    })),
    globalStyles: structure.globalStyles,
  };
}

export default function EmailTemplatePreview() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [previewMode, setPreviewMode] = useState<'desktop' | 'mobile'>('desktop');

  const { data: template, isLoading } = useQuery({
    queryKey: ['email-template', id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('email_templates')
        .select('*')
        .eq('id', id)
        .single();
      
      if (error) throw error;
      return data;
    },
    enabled: !!id,
  });

  const processedStructure = useMemo(() => {
    if (!template?.structure) return null;
    const structure = template.structure as unknown as EmailStructure;
    return replaceTokensInStructure(structure);
  }, [template?.structure]);

  const processedSubject = useMemo(() => {
    if (!template?.subject_template) return '';
    return replaceTokens(template.subject_template, EXAMPLE_VALUES);
  }, [template?.subject_template]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-muted/30 flex items-center justify-center">
        <div className="text-muted-foreground">Laster forhåndsvisning...</div>
      </div>
    );
  }

  if (!template) {
    return (
      <div className="min-h-screen bg-muted/30 flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground mb-4">Malen ble ikke funnet</p>
          <Button onClick={() => navigate('/admin/email-templates')}>
            Tilbake til maler
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted/30">
      {/* Header */}
      <div className="bg-background border-b sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate('/admin/email-templates')}
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Tilbake
              </Button>
              <div>
                <h1 className="font-semibold">{template.name}</h1>
                <p className="text-sm text-muted-foreground">Forhåndsvisning</p>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              {/* Device toggle */}
              <div className="flex items-center bg-muted rounded-lg p-1">
                <Button
                  variant={previewMode === 'desktop' ? 'secondary' : 'ghost'}
                  size="sm"
                  onClick={() => setPreviewMode('desktop')}
                >
                  <Monitor className="h-4 w-4" />
                </Button>
                <Button
                  variant={previewMode === 'mobile' ? 'secondary' : 'ghost'}
                  size="sm"
                  onClick={() => setPreviewMode('mobile')}
                >
                  <Smartphone className="h-4 w-4" />
                </Button>
              </div>
              
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigate(`/admin/email-templates/${id}/edit`)}
              >
                <Edit className="h-4 w-4 mr-2" />
                Rediger
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Preview content */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Subject line */}
        <div className="mb-6 bg-background rounded-lg border p-4">
          <div className="flex items-center gap-2 text-sm">
            <span className="font-medium text-muted-foreground">Emne:</span>
            <span className="font-semibold">{processedSubject}</span>
          </div>
        </div>

        {/* Email preview */}
        <div className="flex justify-center">
          <div 
            className={`bg-background rounded-lg border shadow-sm overflow-hidden transition-all duration-300 ${
              previewMode === 'mobile' ? 'w-[375px]' : 'w-full max-w-[700px]'
            }`}
          >
            {processedStructure && (
              <EmailPreview 
                structure={processedStructure} 
                mode={previewMode} 
              />
            )}
          </div>
        </div>

        {/* Token info */}
        <div className="mt-8 bg-background rounded-lg border p-4">
          <h3 className="font-medium mb-2">Eksempelverdier brukt i forhåndsvisning:</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
            {Object.entries(EXAMPLE_VALUES).slice(0, 8).map(([key, value]) => (
              <div key={key} className="text-muted-foreground">
                <code className="text-xs bg-muted px-1 rounded">{`{${key}}`}</code>
                <span className="mx-1">→</span>
                <span>{value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
