import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { AppLayout } from "@/components/AppLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { 
  Plus, 
  Search, 
  Mail, 
  MoreVertical, 
  Edit, 
  Copy, 
  Trash2, 
  Archive, 
  Eye,
  FileText,
  Send,
  Layout,
  Clock,
  CheckCircle2,
  AlertCircle
} from "lucide-react";
import { format } from "date-fns";
import { nb } from "date-fns/locale";

interface EmailTemplate {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  category: string;
  status: string;
  is_system_template: boolean;
  tags: string[];
  created_at: string;
  updated_at: string;
  created_by: string | null;
}

const CATEGORIES = [
  { value: "all", label: "Alle kategorier" },
  { value: "forsikring", label: "Forsikring" },
  { value: "nyhetsbrev", label: "Nyhetsbrev" },
  { value: "system", label: "System" },
  { value: "medlemskap", label: "Medlemskap" },
  { value: "invitasjoner", label: "Invitasjoner" },
  { value: "varsler", label: "Varsler" },
  { value: "support", label: "Support" },
  { value: "general", label: "Generelt" },
];

const STATUS_OPTIONS = [
  { value: "all", label: "Alle statuser" },
  { value: "draft", label: "Utkast" },
  { value: "published", label: "Publisert" },
  { value: "archived", label: "Arkivert" },
];

export default function EmailTemplates() {
  const navigate = useNavigate();
  const { profile, loading: authLoading } = useAuth();
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [newTemplate, setNewTemplate] = useState({
    name: "",
    slug: "",
    description: "",
    category: "general",
  });

  // Redirect non-admin users
  if (!authLoading && profile?.role !== "admin") {
    navigate("/dashboard");
    return null;
  }

  const { data: templates, isLoading, refetch } = useQuery({
    queryKey: ["email-templates", categoryFilter, statusFilter],
    queryFn: async () => {
      let query = supabase
        .from("email_templates")
        .select("*")
        .order("updated_at", { ascending: false });

      if (categoryFilter !== "all") {
        query = query.eq("category", categoryFilter);
      }
      if (statusFilter !== "all") {
        query = query.eq("status", statusFilter);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data as EmailTemplate[];
    },
    enabled: profile?.role === "admin",
  });

  const { data: moduleCount } = useQuery({
    queryKey: ["email-modules-count"],
    queryFn: async () => {
      const { count, error } = await supabase
        .from("email_module_library")
        .select("*", { count: "exact", head: true });
      if (error) throw error;
      return count || 0;
    },
    enabled: profile?.role === "admin",
  });

  const filteredTemplates = templates?.filter((t) =>
    t.name.toLowerCase().includes(search.toLowerCase()) ||
    t.description?.toLowerCase().includes(search.toLowerCase())
  );

  const stats = {
    total: templates?.length || 0,
    published: templates?.filter((t) => t.status === "published").length || 0,
    draft: templates?.filter((t) => t.status === "draft").length || 0,
    archived: templates?.filter((t) => t.status === "archived").length || 0,
  };

  const handleCreateTemplate = async () => {
    if (!newTemplate.name || !newTemplate.slug) {
      toast.error("Navn og slug er påkrevd");
      return;
    }

    const { error } = await supabase.from("email_templates").insert({
      name: newTemplate.name,
      slug: newTemplate.slug,
      description: newTemplate.description || null,
      category: newTemplate.category,
      status: "draft",
      created_by: profile?.id,
    });

    if (error) {
      toast.error("Kunne ikke opprette mal: " + error.message);
      return;
    }

    toast.success("Mal opprettet");
    setShowCreateDialog(false);
    setNewTemplate({ name: "", slug: "", description: "", category: "general" });
    refetch();
  };

  const handleCloneTemplate = async (template: EmailTemplate) => {
    const { error } = await supabase.from("email_templates").insert({
      name: `${template.name} (kopi)`,
      slug: `${template.slug}-copy-${Date.now()}`,
      description: template.description,
      category: template.category,
      status: "draft",
      tags: template.tags,
      created_by: profile?.id,
    });

    if (error) {
      toast.error("Kunne ikke klone mal");
      return;
    }

    toast.success("Mal klonet");
    refetch();
  };

  const handleDeleteTemplate = async (template: EmailTemplate) => {
    if (template.is_system_template) {
      toast.error("Systemmaler kan ikke slettes");
      return;
    }

    const { error } = await supabase
      .from("email_templates")
      .delete()
      .eq("id", template.id);

    if (error) {
      toast.error("Kunne ikke slette mal");
      return;
    }

    toast.success("Mal slettet");
    refetch();
  };

  const handleArchiveTemplate = async (template: EmailTemplate) => {
    const { error } = await supabase
      .from("email_templates")
      .update({ status: "archived" })
      .eq("id", template.id);

    if (error) {
      toast.error("Kunne ikke arkivere mal");
      return;
    }

    toast.success("Mal arkivert");
    refetch();
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "published":
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100"><CheckCircle2 className="h-3 w-3 mr-1" />Publisert</Badge>;
      case "draft":
        return <Badge variant="secondary"><Clock className="h-3 w-3 mr-1" />Utkast</Badge>;
      case "archived":
        return <Badge variant="outline"><Archive className="h-3 w-3 mr-1" />Arkivert</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getCategoryLabel = (category: string) => {
    return CATEGORIES.find((c) => c.value === category)?.label || category;
  };

  if (authLoading || isLoading) {
    return (
      <AppLayout title="E-postmaler" subtitle="Laster...">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout 
      title="E-postmaler" 
      subtitle="Administrer og bygg e-postmaler for hele systemet"
    >
      <div className="space-y-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Totalt maler
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-primary" />
                <span className="text-2xl font-bold">{stats.total}</span>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Publiserte
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-5 w-5 text-green-600" />
                <span className="text-2xl font-bold">{stats.published}</span>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Utkast
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-amber-600" />
                <span className="text-2xl font-bold">{stats.draft}</span>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                Modulbibliotek
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                <Layout className="h-5 w-5 text-blue-600" />
                <span className="text-2xl font-bold">{moduleCount}</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters and Actions */}
        <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
          <div className="flex flex-col md:flex-row gap-3 flex-1">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Søk i maler..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Kategori" />
              </SelectTrigger>
              <SelectContent>
                {CATEGORIES.map((cat) => (
                  <SelectItem key={cat.value} value={cat.value}>
                    {cat.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[160px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                {STATUS_OPTIONS.map((status) => (
                  <SelectItem key={status.value} value={status.value}>
                    {status.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <Button onClick={() => setShowCreateDialog(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Ny mal
          </Button>
        </div>

        {/* Templates Grid */}
        {filteredTemplates?.length === 0 ? (
          <Card className="p-12 text-center">
            <Mail className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">Ingen maler funnet</h3>
            <p className="text-muted-foreground mb-4">
              {search || categoryFilter !== "all" || statusFilter !== "all"
                ? "Prøv å endre søk eller filtre"
                : "Opprett din første e-postmal for å komme i gang"}
            </p>
            {!search && categoryFilter === "all" && statusFilter === "all" && (
              <Button onClick={() => setShowCreateDialog(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Opprett mal
              </Button>
            )}
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredTemplates?.map((template) => (
              <Card key={template.id} className="group hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1 min-w-0">
                      <CardTitle className="text-base font-medium truncate">
                        {template.name}
                        {template.is_system_template && (
                          <Badge variant="outline" className="ml-2 text-xs">
                            System
                          </Badge>
                        )}
                      </CardTitle>
                      <p className="text-sm text-muted-foreground mt-1 truncate">
                        {template.description || "Ingen beskrivelse"}
                      </p>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => navigate(`/admin/email-templates/${template.id}/preview`)}>
                          <Eye className="h-4 w-4 mr-2" />
                          Forhåndsvis
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => navigate(`/admin/email-templates/${template.id}/edit`)}>
                          <Edit className="h-4 w-4 mr-2" />
                          Rediger
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleCloneTemplate(template)}>
                          <Copy className="h-4 w-4 mr-2" />
                          Klon
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={() => handleArchiveTemplate(template)}>
                          <Archive className="h-4 w-4 mr-2" />
                          Arkiver
                        </DropdownMenuItem>
                        {!template.is_system_template && (
                          <DropdownMenuItem 
                            className="text-destructive focus:text-destructive"
                            onClick={() => handleDeleteTemplate(template)}
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            Slett
                          </DropdownMenuItem>
                        )}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      {getStatusBadge(template.status)}
                      <Badge variant="outline" className="text-xs">
                        {getCategoryLabel(template.category)}
                      </Badge>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-3">
                    Oppdatert {format(new Date(template.updated_at), "d. MMM yyyy", { locale: nb })}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Create Template Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Opprett ny e-postmal</DialogTitle>
            <DialogDescription>
              Fyll ut grunnleggende informasjon for den nye malen.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="name">Navn</Label>
              <Input
                id="name"
                value={newTemplate.name}
                onChange={(e) => {
                  setNewTemplate({
                    ...newTemplate,
                    name: e.target.value,
                    slug: e.target.value
                      .toLowerCase()
                      .replace(/[^a-z0-9]+/g, "-")
                      .replace(/^-|-$/g, ""),
                  });
                }}
                placeholder="F.eks. Velkomst-e-post"
              />
            </div>
            <div>
              <Label htmlFor="slug">Slug (unik ID)</Label>
              <Input
                id="slug"
                value={newTemplate.slug}
                onChange={(e) => setNewTemplate({ ...newTemplate, slug: e.target.value })}
                placeholder="velkomst-epost"
              />
            </div>
            <div>
              <Label htmlFor="category">Kategori</Label>
              <Select
                value={newTemplate.category}
                onValueChange={(v) => setNewTemplate({ ...newTemplate, category: v })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIES.filter((c) => c.value !== "all").map((cat) => (
                    <SelectItem key={cat.value} value={cat.value}>
                      {cat.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="description">Beskrivelse</Label>
              <Textarea
                id="description"
                value={newTemplate.description}
                onChange={(e) => setNewTemplate({ ...newTemplate, description: e.target.value })}
                placeholder="Kort beskrivelse av malen..."
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreateDialog(false)}>
              Avbryt
            </Button>
            <Button onClick={handleCreateTemplate}>
              Opprett mal
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
}
