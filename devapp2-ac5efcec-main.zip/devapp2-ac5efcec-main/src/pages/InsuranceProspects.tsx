import { useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { AppLayout } from "@/components/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ArrowLeft, Search, Building2, MapPin, Users, Download, ExternalLink, Filter } from "lucide-react";
import * as XLSX from "xlsx";

interface SalonProspect {
  id: string;
  name: string;
  org_number: string | null;
  address: string | null;
  city: string | null;
  employee_count: number | null;
  medlemsstatus: string | null;
  hs_object_id: string | null;
  district_name: string | null;
  chain_name: string | null;
}

export default function InsuranceProspects() {
  const navigate = useNavigate();
  const { profile } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [districtFilter, setDistrictFilter] = useState<string>("all");
  const [chainFilter, setChainFilter] = useState<string>("all");
  const [membershipFilter, setMembershipFilter] = useState<string>("all");

  const isAdmin = profile?.role === "admin";
  const isDistrictManager = profile?.role === "district_manager";

  if (!isAdmin && !isDistrictManager) {
    navigate("/dashboard");
    return null;
  }

  // Fetch prospects (salons with HubSpot but no insurance)
  const { data: prospects, isLoading } = useQuery({
    queryKey: ["insurance-prospects"],
    queryFn: async () => {
      // Get salons with HubSpot connection
      const { data: allSalons, error: salonsError } = await supabase
        .from("salons")
        .select(`
          id,
          name,
          org_number,
          address,
          city,
          employee_count,
          medlemsstatus,
          hs_object_id,
          districts:district_id (name),
          chains:chain_id (name)
        `)
        .not("hs_object_id", "is", null);

      if (salonsError) throw salonsError;

      // Get existing insurance salon IDs
      const { data: existingInsurance, error: insuranceError } = await supabase
        .from("salon_insurance")
        .select("salon_id");

      if (insuranceError) throw insuranceError;

      const existingIds = new Set(existingInsurance?.map(i => i.salon_id) || []);

      // Filter and map
      return (allSalons?.filter(s => !existingIds.has(s.id)) || []).map(s => ({
        id: s.id,
        name: s.name,
        org_number: s.org_number,
        address: s.address,
        city: s.city,
        employee_count: s.employee_count,
        medlemsstatus: s.medlemsstatus,
        hs_object_id: s.hs_object_id,
        district_name: (s.districts as any)?.name || null,
        chain_name: (s.chains as any)?.name || null,
      })) as SalonProspect[];
    },
  });

  // Fetch districts for filter
  const { data: districts } = useQuery({
    queryKey: ["districts"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("districts")
        .select("id, name")
        .order("name");
      if (error) throw error;
      return data;
    },
  });

  // Fetch chains for filter
  const { data: chains } = useQuery({
    queryKey: ["chains"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("chains")
        .select("id, name")
        .order("name");
      if (error) throw error;
      return data;
    },
  });

  // Filter and search
  const filteredProspects = useMemo(() => {
    if (!prospects) return [];

    return prospects.filter(prospect => {
      const matchesSearch = searchQuery === "" || 
        prospect.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        prospect.org_number?.includes(searchQuery) ||
        prospect.city?.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesDistrict = districtFilter === "all" || 
        prospect.district_name === districtFilter;

      const matchesChain = chainFilter === "all" || 
        prospect.chain_name === chainFilter ||
        (chainFilter === "none" && !prospect.chain_name);

      const matchesMembership = membershipFilter === "all" || 
        prospect.medlemsstatus === membershipFilter;

      return matchesSearch && matchesDistrict && matchesChain && matchesMembership;
    });
  }, [prospects, searchQuery, districtFilter, chainFilter, membershipFilter]);

  // Statistics
  const stats = useMemo(() => {
    if (!prospects) return { total: 0, byDistrict: {}, byMembership: {} };

    const byDistrict: Record<string, number> = {};
    const byMembership: Record<string, number> = {};

    prospects.forEach(p => {
      const district = p.district_name || "Ukjent";
      byDistrict[district] = (byDistrict[district] || 0) + 1;

      const membership = p.medlemsstatus || "Ukjent";
      byMembership[membership] = (byMembership[membership] || 0) + 1;
    });

    return { total: prospects.length, byDistrict, byMembership };
  }, [prospects]);

  // Export to Excel
  const handleExport = () => {
    if (!filteredProspects.length) return;

    const exportData = filteredProspects.map(p => ({
      "Salongnavn": p.name,
      "Org.nummer": p.org_number || "",
      "Adresse": p.address || "",
      "By": p.city || "",
      "Distrikt": p.district_name || "",
      "Kjede": p.chain_name || "",
      "Medlemsstatus": p.medlemsstatus || "",
      "Antall ansatte": p.employee_count || "",
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Prospekter");
    XLSX.writeFile(wb, `forsikring-prospekter-${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  // Open HubSpot
  const openHubSpot = (hubspotId: string | null) => {
    if (hubspotId) {
      window.open(`https://app.hubspot.com/contacts/27027329/company/${hubspotId}`, "_blank");
    }
  };

  // Get unique membership statuses from data
  const membershipStatuses = useMemo(() => {
    if (!prospects) return [];
    const statuses = new Set(prospects.map(p => p.medlemsstatus).filter(Boolean));
    return Array.from(statuses).sort();
  }, [prospects]);

  // Get unique districts from data
  const uniqueDistricts = useMemo(() => {
    if (!prospects) return [];
    const districtNames = new Set(prospects.map(p => p.district_name).filter(Boolean));
    return Array.from(districtNames).sort();
  }, [prospects]);

  // Get unique chains from data
  const uniqueChains = useMemo(() => {
    if (!prospects) return [];
    const chainNames = new Set(prospects.map(p => p.chain_name).filter(Boolean));
    return Array.from(chainNames).sort();
  }, [prospects]);

  return (
    <AppLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate("/admin/insurance")}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-semibold">Salonger uten forsikring</h1>
              <p className="text-muted-foreground">
                Oversikt over salgsmuligheter - salonger med HubSpot-tilknytning uten forsikring
              </p>
            </div>
          </div>
          <Button onClick={handleExport} disabled={!filteredProspects.length}>
            <Download className="h-4 w-4 mr-2" />
            Eksporter til Excel
          </Button>
        </div>

        {/* Statistics */}
        <div className="grid gap-4 md:grid-cols-3">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Totalt prospekter</CardTitle>
              <Building2 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.total}</div>
              <p className="text-xs text-muted-foreground">
                salonger uten forsikring
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Per distrikt</CardTitle>
              <MapPin className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="flex gap-1 flex-wrap">
                {Object.entries(stats.byDistrict).slice(0, 4).map(([district, count]) => (
                  <Badge key={district} variant="outline" className="text-xs">
                    {district}: {count}
                  </Badge>
                ))}
                {Object.keys(stats.byDistrict).length > 4 && (
                  <Badge variant="outline" className="text-xs">
                    +{Object.keys(stats.byDistrict).length - 4} mer
                  </Badge>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Per medlemsstatus</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="flex gap-1 flex-wrap">
                {Object.entries(stats.byMembership).map(([status, count]) => (
                  <Badge key={status} variant="outline" className="text-xs">
                    {status}: {count}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Filter className="h-4 w-4" />
              Filtrer prospekter
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Søk på navn, org.nr. eller by..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9"
                />
              </div>
              <Select value={districtFilter} onValueChange={setDistrictFilter}>
                <SelectTrigger className="w-full sm:w-48">
                  <SelectValue placeholder="Alle distrikter" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Alle distrikter</SelectItem>
                  {uniqueDistricts.map((district) => (
                    <SelectItem key={district} value={district as string}>
                      {district}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={chainFilter} onValueChange={setChainFilter}>
                <SelectTrigger className="w-full sm:w-48">
                  <SelectValue placeholder="Alle kjeder" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Alle kjeder</SelectItem>
                  <SelectItem value="none">Ingen kjede</SelectItem>
                  {uniqueChains.map((chain) => (
                    <SelectItem key={chain} value={chain as string}>
                      {chain}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={membershipFilter} onValueChange={setMembershipFilter}>
                <SelectTrigger className="w-full sm:w-48">
                  <SelectValue placeholder="Alle statuser" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Alle statuser</SelectItem>
                  {membershipStatuses.map((status) => (
                    <SelectItem key={status} value={status as string}>
                      {status}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Results table */}
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base">
                Prospekter ({filteredProspects.length})
              </CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-3">
                {[...Array(5)].map((_, i) => (
                  <Skeleton key={i} className="h-12 w-full" />
                ))}
              </div>
            ) : filteredProspects.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                {searchQuery || districtFilter !== "all" || chainFilter !== "all" || membershipFilter !== "all"
                  ? "Ingen prospekter matcher filtreringen"
                  : "Ingen salonger uten forsikring funnet"}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Salongnavn</TableHead>
                      <TableHead>Org.nummer</TableHead>
                      <TableHead>By</TableHead>
                      <TableHead>Distrikt</TableHead>
                      <TableHead>Kjede</TableHead>
                      <TableHead>Medlemsstatus</TableHead>
                      <TableHead>Ansatte</TableHead>
                      <TableHead className="text-right">Handlinger</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredProspects.map((prospect) => (
                      <TableRow key={prospect.id} className="hover:bg-muted/50">
                        <TableCell className="font-medium">{prospect.name}</TableCell>
                        <TableCell className="text-muted-foreground">
                          {prospect.org_number || "-"}
                        </TableCell>
                        <TableCell>{prospect.city || "-"}</TableCell>
                        <TableCell>
                          {prospect.district_name ? (
                            <Badge variant="outline">{prospect.district_name}</Badge>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell>
                          {prospect.chain_name ? (
                            <Badge variant="secondary">{prospect.chain_name}</Badge>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell>
                          {prospect.medlemsstatus ? (
                            <Badge 
                              variant={prospect.medlemsstatus === "Medlem" ? "default" : "outline"}
                            >
                              {prospect.medlemsstatus}
                            </Badge>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell>{prospect.employee_count || "-"}</TableCell>
                        <TableCell className="text-right">
                          {prospect.hs_object_id && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => openHubSpot(prospect.hs_object_id)}
                            >
                              <ExternalLink className="h-4 w-4 mr-1" />
                              HubSpot
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
