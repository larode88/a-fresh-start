import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";
import { useAuth } from "@/hooks/useAuth";
import { AppLayout } from "@/components/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { 
  Send, 
  FileText, 
  Building2, 
  User, 
  Mail, 
  Phone, 
  ChevronsUpDown, 
  Check,
  Plus,
  Minus,
  Eye,
  Loader2,
  Shield,
  Users,
  AlertCircle
} from "lucide-react";
import { cn } from "@/lib/utils";

interface Salon {
  id: string;
  name: string;
  org_number: string | null;
  district_id: string | null;
  address: string | null;
  postal_code: string | null;
  city: string | null;
}

interface SalonEmployee {
  id: string;
  name: string;
  first_name: string | null;
  email: string | null;
  role: string | null;
}

interface SalonContact {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  role: string;
}

interface InsuranceProduct {
  id: string;
  name: string;
  description: string | null;
  base_price: number;
  price_model: string;
  product_type: string;
  requires_employee_selection: boolean;
  tiers?: {
    id: string;
    tier_name: string;
    price: number;
  }[];
}

interface SelectedEmployee {
  user_id: string;
  name: string;
}

interface SelectedProduct {
  product_id: string;
  product_name: string;
  price: number;
  quantity: number;
  tier_id?: string;
  tier_name?: string;
  arsverk?: number; // For YSF
  antall_ansatte?: number; // For YSF
  selected_employees?: SelectedEmployee[]; // For per_person products
  aarlig_omsetning?: number; // For Salongforsikring
}

export default function CreateQuote() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { profile } = useAuth();
  
  // Form state
  const [selectedSalon, setSelectedSalon] = useState<Salon | null>(null);
  const [salonSearchOpen, setSalonSearchOpen] = useState(false);
  const [selectedContactId, setSelectedContactId] = useState<string>("");
  const [contactName, setContactName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [notes, setNotes] = useState("");
  const [selectedProducts, setSelectedProducts] = useState<SelectedProduct[]>([]);
  
  // Employee selection dialog
  const [employeeDialogOpen, setEmployeeDialogOpen] = useState(false);
  const [currentProductForEmployees, setCurrentProductForEmployees] = useState<InsuranceProduct | null>(null);
  const [tempSelectedEmployees, setTempSelectedEmployees] = useState<SelectedEmployee[]>([]);
  
  // UI state
  const [showPreview, setShowPreview] = useState(false);
  const [isSending, setIsSending] = useState(false);

  const isDistrictManager = profile?.role === "district_manager";
  const isAdmin = profile?.role === "admin";

  // Redirect if not authorized
  useEffect(() => {
    if (profile && !isDistrictManager && !isAdmin) {
      navigate("/dashboard");
    }
  }, [profile, isDistrictManager, isAdmin, navigate]);

  // Fetch salons in district (or all for admin)
  const { data: salons, isLoading: salonsLoading } = useQuery({
    queryKey: ["district-salons-for-quote", profile?.district_id],
    queryFn: async () => {
      let query = supabase
        .from("salons")
        .select(`
          id, 
          name, 
          org_number, 
          district_id,
          address,
          postal_code,
          city
        `)
        .order("name");

      if (isDistrictManager && profile?.district_id) {
        query = query.eq("district_id", profile.district_id);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data as Salon[];
    },
    enabled: !!profile,
  });

  // Fetch employees for selected salon
  const { data: salonEmployees } = useQuery({
    queryKey: ["salon-employees-for-quote", selectedSalon?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("users")
        .select("id, name, first_name, email, role")
        .eq("salon_id", selectedSalon!.id)
        .order("name");

      if (error) throw error;
      return data as SalonEmployee[];
    },
    enabled: !!selectedSalon?.id,
  });

  // Fetch salon insurance data for business info
  const { data: salonInsurance } = useQuery({
    queryKey: ["salon-insurance-for-quote", selectedSalon?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("salon_insurance")
        .select("antall_ansatte, antall_arsverk, arlig_omsetning")
        .eq("salon_id", selectedSalon!.id)
        .single();

      if (error && error.code !== "PGRST116") throw error;
      return data;
    },
    enabled: !!selectedSalon?.id,
  });

  // Get contacts (owners, daglig_leder, avdelingsleder) for selected salon
  const salonContacts: SalonContact[] = salonEmployees
    ?.filter(e => ["salon_owner", "daglig_leder", "avdelingsleder"].includes(e.role || ""))
    .map(e => ({
      id: e.id,
      name: e.name || e.first_name || "Ukjent",
      email: e.email,
      phone: null, // We'd need to fetch this separately if needed
      role: e.role || ""
    })) || [];

  // Fetch insurance products
  const { data: products, isLoading: productsLoading } = useQuery({
    queryKey: ["insurance-products-for-quote"],
    queryFn: async () => {
      const { data: productData, error: productError } = await supabase
        .from("insurance_products")
        .select(`
          id,
          name,
          description,
          base_price,
          price_model,
          product_type,
          requires_employee_selection
        `)
        .eq("active", true)
        .order("sort_order");

      if (productError) throw productError;

      // Fetch tiers for products
      const { data: tierData, error: tierError } = await supabase
        .from("insurance_product_tiers")
        .select("id, product_id, tier_name, price")
        .order("sort_order");

      if (tierError) throw tierError;

      // Combine products with their tiers
      return (productData as any[]).map(p => ({
        ...p,
        tiers: tierData?.filter(t => t.product_id === p.id) || []
      })) as InsuranceProduct[];
    },
    enabled: !!profile,
  });

  // Auto-fill form when salon is selected
  useEffect(() => {
    if (selectedSalon) {
      setSelectedContactId("");
      setContactName("");
      setEmail("");
      setPhone("");
    }
  }, [selectedSalon]);

  // Sync årsverk, antall_ansatte and årlig omsetning when salonInsurance loads or changes
  useEffect(() => {
    if (salonInsurance) {
      setSelectedProducts(prev => prev.map(p => {
        // Update arsverk and antall_ansatte for YSF products
        if (p.arsverk !== undefined) {
          return { 
            ...p, 
            arsverk: salonInsurance.antall_arsverk || p.arsverk,
            antall_ansatte: salonInsurance.antall_ansatte || p.antall_ansatte
          };
        }
        // Update aarlig_omsetning for Salongforsikring products
        if (p.tier_id !== undefined && salonInsurance.arlig_omsetning) {
          return { ...p, aarlig_omsetning: salonInsurance.arlig_omsetning };
        }
        return p;
      }));
    }
  }, [salonInsurance?.antall_arsverk, salonInsurance?.antall_ansatte, salonInsurance?.arlig_omsetning]);

  // Update contact details when contact is selected
  useEffect(() => {
    if (selectedContactId && salonContacts.length > 0) {
      const contact = salonContacts.find(c => c.id === selectedContactId);
      if (contact) {
        setContactName(contact.name);
        setEmail(contact.email || "");
        // Fetch phone from users table if needed
        supabase
          .from("users")
          .select("phone")
          .eq("id", selectedContactId)
          .single()
          .then(({ data }) => {
            if (data?.phone) setPhone(data.phone);
          });
      }
    }
  }, [selectedContactId, salonContacts]);

  // Calculate total price
  const totalPrice = selectedProducts.reduce((sum, p) => {
    if (p.arsverk !== undefined) {
      return sum + (p.price * p.arsverk);
    }
    if (p.selected_employees) {
      return sum + (p.price * p.selected_employees.length);
    }
    return sum + (p.price * p.quantity);
  }, 0);

  // Handle product click based on type
  const handleProductClick = (product: InsuranceProduct, tier?: { id: string; tier_name: string; price: number }) => {
    if (product.price_model === "per_arsverk") {
      // YSF: Open arsverk input - pre-fill with salon's data if available
      const existing = selectedProducts.find(p => p.product_id === product.id);
      if (!existing) {
        const defaultArsverk = salonInsurance?.antall_arsverk || 1;
        const defaultAnsatte = salonInsurance?.antall_ansatte || undefined;
        setSelectedProducts(prev => [...prev, {
          product_id: product.id,
          product_name: product.name,
          price: product.base_price,
          quantity: 1,
          arsverk: defaultArsverk,
          antall_ansatte: defaultAnsatte,
        }]);
      }
    } else if (product.requires_employee_selection && product.product_type === "helse") {
      // Health insurance: Open employee selection dialog
      setCurrentProductForEmployees(product);
      const existing = selectedProducts.find(p => p.product_id === product.id);
      setTempSelectedEmployees(existing?.selected_employees || []);
      setEmployeeDialogOpen(true);
    } else if (product.tiers && product.tiers.length > 0 && tier) {
      // Tiered product (Salongforsikring)
      addTieredProduct(product, tier);
    } else {
      // Fixed or simple per_person product
      addSimpleProduct(product);
    }
  };

  // Add tiered product (Salongforsikring) - includes aarlig_omsetning
  const addTieredProduct = (product: InsuranceProduct, tier: { id: string; tier_name: string; price: number }) => {
    // Only allow one tier at a time
    setSelectedProducts(prev => {
      const filtered = prev.filter(p => p.product_id !== product.id);
      return [...filtered, {
        product_id: product.id,
        product_name: product.name,
        price: tier.price,
        quantity: 1,
        tier_id: tier.id,
        tier_name: tier.tier_name,
        aarlig_omsetning: salonInsurance?.arlig_omsetning || undefined,
      }];
    });
  };

  // Update aarlig_omsetning for Salongforsikring
  const updateAarligOmsetning = (productId: string, value: number) => {
    setSelectedProducts(prev => prev.map(p => 
      p.product_id === productId && p.tier_id !== undefined
        ? { ...p, aarlig_omsetning: value }
        : p
    ));
  };

  // Add simple product (fixed or per_person without employee selection)
  const addSimpleProduct = (product: InsuranceProduct) => {
    const existing = selectedProducts.find(p => p.product_id === product.id && !p.tier_id);

    if (existing) {
      setSelectedProducts(prev => prev.map(p => 
        p.product_id === product.id && !p.tier_id
          ? { ...p, quantity: p.quantity + 1 }
          : p
      ));
    } else {
      setSelectedProducts(prev => [...prev, {
        product_id: product.id,
        product_name: product.name,
        price: product.base_price,
        quantity: 1,
      }]);
    }
  };

  // Remove product from selection
  const removeProduct = (productId: string, tierId?: string) => {
    const existing = selectedProducts.find(p => 
      p.product_id === productId && 
      (tierId ? p.tier_id === tierId : !p.tier_id)
    );

    if (existing && existing.quantity > 1 && !existing.arsverk && !existing.selected_employees) {
      setSelectedProducts(prev => prev.map(p => 
        p.product_id === productId && (tierId ? p.tier_id === tierId : !p.tier_id)
          ? { ...p, quantity: p.quantity - 1 }
          : p
      ));
    } else {
      setSelectedProducts(prev => prev.filter(p => 
        !(p.product_id === productId && (tierId ? p.tier_id === tierId : !p.tier_id))
      ));
    }
  };

  // Update arsverk for YSF
  const updateArsverk = (productId: string, arsverk: number) => {
    setSelectedProducts(prev => prev.map(p => 
      p.product_id === productId
        ? { ...p, arsverk: Math.max(0.1, arsverk) }
        : p
    ));
  };

  // Update antall_ansatte for YSF
  const updateAntallAnsatte = (productId: string, value: number) => {
    setSelectedProducts(prev => prev.map(p => 
      p.product_id === productId && p.arsverk !== undefined
        ? { ...p, antall_ansatte: Math.max(1, value) }
        : p
    ));
  };

  // Confirm employee selection for health insurance
  const confirmEmployeeSelection = () => {
    if (!currentProductForEmployees) return;
    
    if (tempSelectedEmployees.length === 0) {
      // Remove product if no employees selected
      setSelectedProducts(prev => prev.filter(p => p.product_id !== currentProductForEmployees.id));
    } else {
      const existing = selectedProducts.find(p => p.product_id === currentProductForEmployees.id);
      if (existing) {
        setSelectedProducts(prev => prev.map(p => 
          p.product_id === currentProductForEmployees.id
            ? { ...p, selected_employees: tempSelectedEmployees, quantity: tempSelectedEmployees.length }
            : p
        ));
      } else {
        setSelectedProducts(prev => [...prev, {
          product_id: currentProductForEmployees.id,
          product_name: currentProductForEmployees.name,
          price: currentProductForEmployees.base_price,
          quantity: tempSelectedEmployees.length,
          selected_employees: tempSelectedEmployees,
        }]);
      }
    }
    
    setEmployeeDialogOpen(false);
    setCurrentProductForEmployees(null);
    setTempSelectedEmployees([]);
  };

  // Toggle employee in temp selection
  const toggleEmployee = (employee: SalonEmployee) => {
    const isSelected = tempSelectedEmployees.some(e => e.user_id === employee.id);
    if (isSelected) {
      setTempSelectedEmployees(prev => prev.filter(e => e.user_id !== employee.id));
    } else {
      setTempSelectedEmployees(prev => [...prev, {
        user_id: employee.id,
        name: employee.name || employee.first_name || "Ukjent"
      }]);
    }
  };

  // Get quantity for a product
  const getProductQuantity = (productId: string, tierId?: string) => {
    const product = selectedProducts.find(p => 
      p.product_id === productId && 
      (tierId ? p.tier_id === tierId : !p.tier_id)
    );
    return product?.quantity || 0;
  };

  // Check if product is selected
  const isProductSelected = (productId: string, tierId?: string) => {
    return selectedProducts.some(p => 
      p.product_id === productId && 
      (tierId ? p.tier_id === tierId : true)
    );
  };

  // Get selected product
  const getSelectedProduct = (productId: string) => {
    return selectedProducts.find(p => p.product_id === productId);
  };

  // Send quote mutation
  const sendQuoteMutation = useMutation({
    mutationFn: async () => {
      if (!selectedSalon || !contactName || !email || selectedProducts.length === 0) {
        throw new Error("Vennligst fyll ut alle obligatoriske felt");
      }

      // Generate unique token
      const token = crypto.randomUUID();
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + 30); // 30 days expiry

      // Create quote record with address fields and business info
      // Get aarlig_omsetning from selected products (user input) or fallback to salon data
      const salongforsikringProduct = selectedProducts.find(p => p.tier_id !== undefined);
      const aarligOmsetningFromProducts = salongforsikringProduct?.aarlig_omsetning;
      
      const insertData = {
        member_salon_id: selectedSalon.id,
        salon_name: selectedSalon.name,
        org_number: selectedSalon.org_number || "",
        contact_name: contactName,
        email: email,
        phone: phone || null,
        district_manager_id: profile?.id!,
        products: selectedProducts as unknown as any,
        total_price: totalPrice,
        notes: notes || null,
        status: "sent" as const,
        sent_at: new Date().toISOString(),
        expires_at: expiresAt.toISOString(),
        acceptance_token: token,
        salon_address: selectedSalon.address || null,
        salon_postal_code: selectedSalon.postal_code || null,
        salon_city: selectedSalon.city || null,
        antall_ansatte: salonInsurance?.antall_ansatte || null,
        antall_arsverk: salonInsurance?.antall_arsverk || null,
        aarlig_omsetning: aarligOmsetningFromProducts || salonInsurance?.arlig_omsetning || null,
      };

      const { data: quote, error: insertError } = await supabase
        .from("insurance_quotes")
        .insert(insertData)
        .select()
        .single();

      if (insertError) {
        console.error("Error creating quote:", insertError);
        throw new Error("Kunne ikke opprette tilbud");
      }

      // Send email
      const { error: emailError } = await supabase.functions.invoke("send-quote-email", {
        body: { quoteId: quote.id, action: "send_quote" }
      });

      if (emailError) {
        console.error("Error sending email:", emailError);
        // Don't fail - quote was created
      }

      return quote;
    },
    onSuccess: () => {
      toast.success("Tilbudet er sendt!");
      queryClient.invalidateQueries({ queryKey: ["insurance-quotes"] });
      navigate("/district/insurance");
    },
    onError: (error: Error) => {
      toast.error(error.message);
    },
  });

  const handleSend = async () => {
    setIsSending(true);
    try {
      await sendQuoteMutation.mutateAsync();
    } finally {
      setIsSending(false);
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("nb-NO", { maximumFractionDigits: 0 }).format(price);
  };

  const getRoleLabel = (role: string) => {
    const labels: Record<string, string> = {
      salon_owner: "Eier",
      daglig_leder: "Daglig leder",
      avdelingsleder: "Avdelingsleder"
    };
    return labels[role] || role;
  };

  if (!profile) {
    return (
      <AppLayout title="Lag forsikringstilbud">
        <div className="container mx-auto px-4 py-8">
          <Skeleton className="h-96 w-full" />
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout 
      title="Lag forsikringstilbud" 
      subtitle="Opprett et tilpasset forsikringstilbud til et medlem"
    >
      <div className="container mx-auto px-4 py-8 space-y-6 max-w-4xl">
        {/* Salon Selection */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5" />
              Velg medlem
            </CardTitle>
            <CardDescription>
              Velg salongen du vil sende tilbud til
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Popover open={salonSearchOpen} onOpenChange={setSalonSearchOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  role="combobox"
                  aria-expanded={salonSearchOpen}
                  className="w-full justify-between"
                >
                  {selectedSalon ? selectedSalon.name : "Søk etter salong..."}
                  <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-full p-0" align="start">
                <Command>
                  <CommandInput placeholder="Søk etter salong..." />
                  <CommandList>
                    <CommandEmpty>Ingen salonger funnet.</CommandEmpty>
                    <CommandGroup>
                      {salons?.map((salon) => (
                        <CommandItem
                          key={salon.id}
                          value={salon.name}
                          onSelect={() => {
                            setSelectedSalon(salon);
                            setSalonSearchOpen(false);
                          }}
                        >
                          <Check
                            className={cn(
                              "mr-2 h-4 w-4",
                              selectedSalon?.id === salon.id ? "opacity-100" : "opacity-0"
                            )}
                          />
                          <div>
                            <p className="font-medium">{salon.name}</p>
                            {salon.org_number && (
                              <p className="text-xs text-muted-foreground">Org: {salon.org_number}</p>
                            )}
                          </div>
                        </CommandItem>
                      ))}
                    </CommandGroup>
                  </CommandList>
                </Command>
              </PopoverContent>
            </Popover>

            {selectedSalon && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t">
                {/* Contact person selector */}
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="contact_select" className="flex items-center gap-2">
                    <User className="h-4 w-4" />
                    Kontaktperson *
                  </Label>
                  {salonContacts.length > 0 ? (
                    <Select value={selectedContactId} onValueChange={setSelectedContactId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Velg kontaktperson..." />
                      </SelectTrigger>
                      <SelectContent>
                        {salonContacts.map((contact) => (
                          <SelectItem key={contact.id} value={contact.id}>
                            {contact.name} ({getRoleLabel(contact.role)})
                          </SelectItem>
                        ))}
                        <SelectItem value="manual">Annet (fyll inn manuelt)</SelectItem>
                      </SelectContent>
                    </Select>
                  ) : (
                    <Input
                      id="contact_name"
                      placeholder="Fullt navn"
                      value={contactName}
                      onChange={(e) => setContactName(e.target.value)}
                    />
                  )}
                </div>

                {selectedContactId === "manual" && (
                  <div className="space-y-2">
                    <Label htmlFor="contact_name_manual">Navn *</Label>
                    <Input
                      id="contact_name_manual"
                      placeholder="Fullt navn"
                      value={contactName}
                      onChange={(e) => setContactName(e.target.value)}
                    />
                  </div>
                )}

                <div className="space-y-2">
                  <Label htmlFor="email" className="flex items-center gap-2">
                    <Mail className="h-4 w-4" />
                    E-post *
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="epost@salong.no"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone" className="flex items-center gap-2">
                    <Phone className="h-4 w-4" />
                    Telefon
                  </Label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="+47 xxx xx xxx"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                  />
                </div>

                <div className="flex items-end">
                  <Badge variant="secondary" className="text-xs">
                    Org: {selectedSalon.org_number || "Ikke oppgitt"}
                  </Badge>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Product Selection */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Velg forsikringsprodukter
            </CardTitle>
            <CardDescription>
              Velg hvilke forsikringer som skal inkluderes i tilbudet
            </CardDescription>
          </CardHeader>
          <CardContent>
            {/* Show salon info for reference */}
            {selectedSalon && salonInsurance && (
              <div className="mb-4 p-3 bg-muted/50 rounded-lg border">
                <div className="flex items-center gap-2 mb-2">
                  <Users className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm font-medium">Salonginformasjon</span>
                </div>
                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">Antall ansatte:</span>{" "}
                    <span className="font-medium">{salonInsurance.antall_ansatte ?? "Ikke oppgitt"}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Årsverk:</span>{" "}
                    <span className="font-medium">{salonInsurance.antall_arsverk ?? "Ikke oppgitt"}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Årlig omsetning:</span>{" "}
                    <span className="font-medium">
                      {salonInsurance.arlig_omsetning 
                        ? `${salonInsurance.arlig_omsetning.toLocaleString("nb-NO")} kr` 
                        : "Ikke oppgitt"}
                    </span>
                  </div>
                </div>
              </div>
            )}
            
            {productsLoading ? (
              <div className="space-y-4">
                {[1, 2, 3].map(i => (
                  <Skeleton key={i} className="h-20 w-full" />
                ))}
              </div>
            ) : (
              <div className="space-y-4">
                {products?.map((product) => (
                  <div key={product.id} className="border rounded-lg p-4">
                    <div className="flex items-start justify-between">
                      <div className="space-y-1">
                        <h4 className="font-medium">{product.name}</h4>
                        {product.description && (
                          <p className="text-sm text-muted-foreground">{product.description}</p>
                        )}
                        <div className="flex gap-2">
                          <Badge variant="outline" className="text-xs">
                            {product.price_model === "per_arsverk" ? "Per årsverk" : 
                             product.price_model === "per_person" ? "Per person" : "Fast pris"}
                          </Badge>
                          {product.requires_employee_selection && product.product_type === "helse" && (
                            <Badge variant="secondary" className="text-xs">
                              <Users className="h-3 w-3 mr-1" />
                              Velg ansatte
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Tiered products (Salongforsikring) */}
                    {product.tiers && product.tiers.length > 0 ? (
                      <div className="mt-4 space-y-4">
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                          {product.tiers.map((tier) => {
                            const isSelected = selectedProducts.some(
                              p => p.product_id === product.id && p.tier_id === tier.id
                            );
                            return (
                              <button 
                                key={tier.id}
                                type="button"
                                onClick={() => handleProductClick(product, tier)}
                                className={cn(
                                  "border rounded-lg p-3 transition-colors text-left",
                                  isSelected ? "border-primary bg-primary/5" : "border-border hover:border-primary/50"
                                )}
                              >
                                <div className="flex items-center justify-between mb-2">
                                  <span className="font-medium text-sm">{tier.tier_name}</span>
                                  {isSelected && <Check className="h-4 w-4 text-primary" />}
                                </div>
                                <span className="text-sm">{formatPrice(tier.price)} kr/år</span>
                              </button>
                            );
                          })}
                        </div>
                        {/* Show årlig omsetning input when a tier is selected */}
                        {isProductSelected(product.id) && (
                          <div className="p-3 bg-muted/50 rounded-lg border">
                            <div className="flex items-center gap-4">
                              <Label htmlFor={`omsetning-${product.id}`} className="text-sm whitespace-nowrap font-medium">
                                Årlig omsetning (påkrevd):
                              </Label>
                              <div className="flex items-center gap-2">
                                <Input
                                  id={`omsetning-${product.id}`}
                                  type="number"
                                  min="0"
                                  className="w-40"
                                  placeholder="f.eks. 2000000"
                                  value={getSelectedProduct(product.id)?.aarlig_omsetning || ""}
                                  onChange={(e) => updateAarligOmsetning(product.id, parseFloat(e.target.value) || 0)}
                                />
                                <span className="text-sm text-muted-foreground">kr</span>
                              </div>
                              {!getSelectedProduct(product.id)?.aarlig_omsetning && (
                                <span className="text-xs text-destructive">Må fylles ut</span>
                              )}
                            </div>
                          </div>
                        )}
                      </div>
                    ) : product.price_model === "per_arsverk" ? (
                      /* YSF: Arsverk and antall ansatte input */
                      <div className="mt-4">
                        {isProductSelected(product.id) ? (
                          <div className="space-y-3">
                            <div className="flex flex-wrap items-center gap-4">
                              <div className="flex items-center gap-2">
                                <Label htmlFor={`ansatte-${product.id}`} className="text-sm whitespace-nowrap">
                                  Antall ansatte:
                                </Label>
                                <Input
                                  id={`ansatte-${product.id}`}
                                  type="number"
                                  min="1"
                                  className="w-20"
                                  value={getSelectedProduct(product.id)?.antall_ansatte || ""}
                                  placeholder="0"
                                  onChange={(e) => updateAntallAnsatte(product.id, parseInt(e.target.value) || 0)}
                                />
                              </div>
                              <div className="flex items-center gap-2">
                                <Label htmlFor={`arsverk-${product.id}`} className="text-sm whitespace-nowrap">
                                  Årsverk:
                                </Label>
                                <Input
                                  id={`arsverk-${product.id}`}
                                  type="number"
                                  step="0.1"
                                  min="0.1"
                                  className="w-24"
                                  value={getSelectedProduct(product.id)?.arsverk || 1}
                                  onChange={(e) => updateArsverk(product.id, parseFloat(e.target.value) || 0.1)}
                                />
                              </div>
                              <span className="text-sm">
                                = {formatPrice((getSelectedProduct(product.id)?.arsverk || 1) * product.base_price)} kr/år
                              </span>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => removeProduct(product.id)}
                                className="ml-auto text-destructive"
                              >
                                Fjern
                              </Button>
                            </div>
                            {(salonInsurance?.antall_arsverk || salonInsurance?.antall_ansatte) && (
                              <p className="text-xs text-muted-foreground">
                                Registrert hos salongen: {salonInsurance.antall_ansatte ?? "ukjent"} ansatte, {salonInsurance.antall_arsverk ?? "ukjent"} årsverk
                              </p>
                            )}
                          </div>
                        ) : (
                          <div className="flex items-center justify-between">
                            <div className="flex flex-col">
                              <span className="text-sm font-medium">{formatPrice(product.base_price)} kr/årsverk</span>
                              {(salonInsurance?.antall_arsverk || salonInsurance?.antall_ansatte) && (
                                <span className="text-xs text-muted-foreground">
                                  Salongen: {salonInsurance.antall_ansatte ?? "?"} ansatte, {salonInsurance.antall_arsverk ?? "?"} årsverk
                                </span>
                              )}
                            </div>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleProductClick(product)}
                            >
                              <Plus className="h-4 w-4 mr-1" />
                              Legg til
                            </Button>
                          </div>
                        )}
                      </div>
                    ) : product.requires_employee_selection && product.product_type === "helse" ? (
                      /* Health insurance: Employee selection */
                      <div className="mt-4">
                        {isProductSelected(product.id) ? (
                          <div className="flex items-center gap-4">
                            <div className="flex flex-wrap gap-1">
                              {getSelectedProduct(product.id)?.selected_employees?.map(emp => (
                                <Badge key={emp.user_id} variant="secondary" className="text-xs">
                                  {emp.name}
                                </Badge>
                              ))}
                            </div>
                            <span className="text-sm whitespace-nowrap">
                              = {formatPrice((getSelectedProduct(product.id)?.selected_employees?.length || 0) * product.base_price)} kr/år
                            </span>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleProductClick(product)}
                              className="ml-auto"
                            >
                              Endre
                            </Button>
                          </div>
                        ) : (
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-medium">{formatPrice(product.base_price)} kr/person</span>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleProductClick(product)}
                              disabled={!selectedSalon}
                            >
                              <Users className="h-4 w-4 mr-1" />
                              Velg ansatte
                            </Button>
                          </div>
                        )}
                      </div>
                    ) : (
                      /* Simple quantity products */
                      <div className="flex items-center justify-between mt-4">
                        <span className="text-sm font-medium">{formatPrice(product.base_price)} kr/år</span>
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => removeProduct(product.id)}
                            disabled={getProductQuantity(product.id) === 0}
                          >
                            <Minus className="h-4 w-4" />
                          </Button>
                          <span className="w-8 text-center">{getProductQuantity(product.id)}</span>
                          <Button
                            variant="outline"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => addSimpleProduct(product)}
                          >
                            <Plus className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* Selected products summary */}
            {selectedProducts.length > 0 && (
              <div className="mt-6 pt-4 border-t">
                <h4 className="font-medium mb-3">Valgte produkter:</h4>
                <div className="space-y-2">
                  {selectedProducts.map((p, idx) => (
                    <div key={idx} className="flex justify-between text-sm">
                      <span>
                        {p.product_name}
                        {p.tier_name && ` (${p.tier_name})`}
                        {p.arsverk !== undefined && ` × ${p.arsverk} årsverk`}
                        {p.selected_employees && ` × ${p.selected_employees.length} ansatte`}
                        {!p.arsverk && !p.selected_employees && p.quantity > 1 && ` × ${p.quantity}`}
                      </span>
                      <span className="font-medium">
                        {formatPrice(
                          p.arsverk !== undefined 
                            ? p.price * p.arsverk 
                            : p.selected_employees 
                              ? p.price * p.selected_employees.length 
                              : p.price * p.quantity
                        )} kr
                      </span>
                    </div>
                  ))}
                  <div className="flex justify-between pt-2 border-t font-semibold">
                    <span>Totalt per år</span>
                    <span>{formatPrice(totalPrice)} kr</span>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Notes */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Notater
            </CardTitle>
            <CardDescription>
              Legg til eventuelle notater eller tilpasset informasjon
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Textarea
              placeholder="Skriv notater til medlemmet her..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={4}
            />
          </CardContent>
        </Card>

        {/* Actions */}
        {(() => {
          // Check if any Salongforsikring product is missing aarlig_omsetning
          const salongforsikringMissingOmsetning = selectedProducts.some(
            p => p.tier_id !== undefined && !p.aarlig_omsetning
          );
          const canSend = selectedSalon && contactName && email && selectedProducts.length > 0 && !salongforsikringMissingOmsetning;
          
          return (
            <div className="flex flex-col gap-4">
              {salongforsikringMissingOmsetning && (
                <div className="flex items-center gap-2 text-destructive text-sm">
                  <AlertCircle className="h-4 w-4" />
                  Årlig omsetning må fylles ut for Salongforsikring
                </div>
              )}
              <div className="flex flex-col sm:flex-row gap-4 justify-end">
                <Button
                  variant="outline"
                  onClick={() => setShowPreview(true)}
                  disabled={!canSend}
                >
                  <Eye className="mr-2 h-4 w-4" />
                  Forhåndsvis e-post
                </Button>
                <Button
                  onClick={handleSend}
                  disabled={!canSend || isSending}
                >
                  {isSending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Sender...
                    </>
                  ) : (
                    <>
                      <Send className="mr-2 h-4 w-4" />
                      Send tilbud
                    </>
                  )}
                </Button>
              </div>
            </div>
          );
        })()}

        {/* Employee Selection Dialog */}
        <Dialog open={employeeDialogOpen} onOpenChange={setEmployeeDialogOpen}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Velg ansatte for {currentProductForEmployees?.name}
              </DialogTitle>
              <DialogDescription>
                Velg hvilke ansatte som skal inkluderes i forsikringen
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-2 max-h-[300px] overflow-y-auto">
              {salonEmployees && salonEmployees.length > 0 ? (
                salonEmployees.map((employee) => {
                  const isSelected = tempSelectedEmployees.some(e => e.user_id === employee.id);
                  return (
                    <div
                      key={employee.id}
                      className={cn(
                        "flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors",
                        isSelected ? "border-primary bg-primary/5" : "border-border hover:border-primary/50"
                      )}
                      onClick={() => toggleEmployee(employee)}
                    >
                      <Checkbox checked={isSelected} />
                      <div className="flex-1">
                        <p className="font-medium">{employee.name || employee.first_name || "Ukjent"}</p>
                        {employee.email && (
                          <p className="text-xs text-muted-foreground">{employee.email}</p>
                        )}
                      </div>
                    </div>
                  );
                })
              ) : (
                <p className="text-sm text-muted-foreground text-center py-4">
                  Ingen ansatte funnet for denne salongen
                </p>
              )}
            </div>

            {tempSelectedEmployees.length > 0 && currentProductForEmployees && (
              <div className="pt-4 border-t">
                <div className="flex justify-between text-sm">
                  <span>{tempSelectedEmployees.length} ansatte valgt</span>
                  <span className="font-medium">
                    {formatPrice(tempSelectedEmployees.length * currentProductForEmployees.base_price)} kr/år
                  </span>
                </div>
              </div>
            )}

            <DialogFooter>
              <Button variant="outline" onClick={() => setEmployeeDialogOpen(false)}>
                Avbryt
              </Button>
              <Button onClick={confirmEmployeeSelection}>
                Bekreft valg
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Email Preview Dialog */}
        <Dialog open={showPreview} onOpenChange={setShowPreview}>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Forhåndsvisning av e-post</DialogTitle>
              <DialogDescription>
                Slik vil e-posten se ut for mottakeren
              </DialogDescription>
            </DialogHeader>
            
            <div className="border rounded-lg p-6 bg-white">
              <div className="text-center mb-6">
                <span className="text-2xl font-bold text-primary">Hår1</span>
              </div>
              
              <p>Hei {contactName},</p>
              <p className="mt-4">
                Basert på dialogen med din distriktsleder har vi satt opp et forslag til 
                forsikringsløsning for dere hos Hår1:
              </p>
              
              <h4 className="font-semibold mt-6 mb-3">Forsikringer inkludert:</h4>
              <table className="w-full border-collapse">
                <thead>
                  <tr className="bg-muted/50">
                    <th className="text-left p-2 border">Produkt</th>
                    <th className="text-center p-2 border">Detaljer</th>
                    <th className="text-right p-2 border">Pris/år</th>
                  </tr>
                </thead>
                <tbody>
                  {selectedProducts.map((p, idx) => (
                    <tr key={idx}>
                      <td className="p-2 border">
                        {p.product_name}
                        {p.tier_name && ` (${p.tier_name})`}
                      </td>
                      <td className="text-center p-2 border">
                        {p.arsverk !== undefined 
                          ? `${p.arsverk} årsverk` 
                          : p.selected_employees 
                            ? `${p.selected_employees.length} ansatte`
                            : p.quantity > 1 ? p.quantity : "-"
                        }
                      </td>
                      <td className="text-right p-2 border">
                        {formatPrice(
                          p.arsverk !== undefined 
                            ? p.price * p.arsverk 
                            : p.selected_employees 
                              ? p.price * p.selected_employees.length 
                              : p.price * p.quantity
                        )} kr
                      </td>
                    </tr>
                  ))}
                  <tr className="bg-muted/50 font-semibold">
                    <td colSpan={2} className="p-2 border">Totalpris per år</td>
                    <td className="text-right p-2 border">{formatPrice(totalPrice)} kr</td>
                  </tr>
                </tbody>
              </table>

              {notes && (
                <div className="mt-4 p-4 bg-muted/30 rounded-lg">
                  <strong>Notater fra din distriktsleder:</strong>
                  <p className="mt-2">{notes}</p>
                </div>
              )}

              <p className="mt-6">👉 For å godkjenne tilbudet, klikk på knappen under:</p>
              
              <div className="text-center my-6">
                <Button className="bg-primary">Aksepter tilbudet</Button>
              </div>

              <p className="text-sm text-muted-foreground">
                Når du godkjenner, blir du ført direkte til fullmaktskjemaet for signering.
              </p>

              <div className="mt-8 pt-4 border-t text-sm text-muted-foreground">
                <p>Varm hilsen<br/><strong>Hår1 Forsikringsteamet</strong></p>
                <p className="mt-2">📧 forsikring@har1.no<br/>📞 +47 4000 3345</p>
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setShowPreview(false)}>
                Lukk
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AppLayout>
  );
}
