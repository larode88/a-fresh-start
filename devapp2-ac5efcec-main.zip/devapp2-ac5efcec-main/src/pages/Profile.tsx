import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, User, Save, Mail, Phone, Shield, Bell, Camera, Briefcase, Calendar, Award, RefreshCw, Heart, Check, Smartphone, ExternalLink } from "lucide-react";
import { ImageUpload } from "@/components/ImageUpload";
import { GlobalMessageBadge } from "@/components/GlobalMessageBadge";
import { format } from "date-fns";
import { nb } from "date-fns/locale";
import haar1ForsikringLogo from "@/assets/haar1-forsikring-logo.png";
import ergoLogo from "@/assets/ergo-logo.png";

interface UserDetails {
  first_name: string | null;
  last_name: string | null;
  phone: string | null;
  avatar_url: string | null;
  frisorfunksjon: string | null;
  stillingsprosent: number | null;
  ansettelsesdato: string | null;
  fodselsdato: string | null;
  fagbrev: boolean | null;
  fagbrevdato: string | null;
  aktiv: boolean | null;
  hubspot_contact_id: string | null;
  hubspot_synced_at: string | null;
  // Health insurance fields
  helseforsikring_status: string | null;
  helseforsikring_oppstartsdato: string | null;
  helseforsikring_oppsigelsesdato: string | null;
  helseforsikring_pris: number | null;
  helseforsikring_avtalenummer: string | null;
}

const Profile = () => {
  const navigate = useNavigate();
  const { user, profile, loading } = useAuth();
  const { toast } = useToast();
  
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [phone, setPhone] = useState("");
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [salonName, setSalonName] = useState<string | null>(null);
  const [districtName, setDistrictName] = useState<string | null>(null);
  const [userDetails, setUserDetails] = useState<UserDetails | null>(null);
  const [healthInsuranceAvtalenummer, setHealthInsuranceAvtalenummer] = useState<string | null>(null);
  
  // Notification settings state
  const [emailOnNewMessage, setEmailOnNewMessage] = useState(true);
  const [savingPreferences, setSavingPreferences] = useState(false);
  const [preferencesLoaded, setPreferencesLoaded] = useState(false);

  useEffect(() => {
    if (!loading && !user) {
      navigate("/login");
    }
  }, [user, loading, navigate]);

  useEffect(() => {
    if (profile) {
      fetchUserDetails();
      fetchNotificationPreferences();
    }
  }, [profile]);

  const fetchUserDetails = async () => {
    if (!user) return;
    
    const { data, error } = await supabase
      .from("users")
      .select("first_name, last_name, phone, avatar_url, frisorfunksjon, stillingsprosent, ansettelsesdato, fodselsdato, fagbrev, fagbrevdato, aktiv, hubspot_contact_id, hubspot_synced_at, helseforsikring_status, helseforsikring_oppstartsdato, helseforsikring_oppsigelsesdato, helseforsikring_pris, helseforsikring_avtalenummer")
      .eq("id", user.id)
      .single();
    
    if (!error && data) {
      setFirstName((data as any).first_name || "");
      setLastName((data as any).last_name || "");
      setPhone(data.phone || "");
      setAvatarUrl(data.avatar_url || null);
      setUserDetails(data as UserDetails);
      // Use individual health insurance avtalenummer from user record
      if ((data as any).helseforsikring_avtalenummer) {
        setHealthInsuranceAvtalenummer((data as any).helseforsikring_avtalenummer);
      }
    }

    // Fetch salon name if user has salon_id
    if (profile?.salon_id) {
      const { data: salonData } = await supabase
        .from("salons")
        .select("name")
        .eq("id", profile.salon_id)
        .single();
      if (salonData) setSalonName(salonData.name);
    }

    // Fetch district name if user has district_id
    if (profile?.district_id) {
      const { data: districtData } = await supabase
        .from("districts")
        .select("name")
        .eq("id", profile.district_id)
        .single();
      if (districtData) setDistrictName(districtData.name);
    }
  };

  const fetchNotificationPreferences = async () => {
    if (!user) return;

    const { data, error } = await supabase
      .from("user_notification_preferences" as any)
      .select("*")
      .eq("user_id", user.id)
      .single();

    if (!error && data) {
      setEmailOnNewMessage((data as any).email_on_new_message ?? true);
    }
    setPreferencesLoaded(true);
  };

  const handleNotificationChange = async (value: boolean) => {
    if (!user) return;

    setEmailOnNewMessage(value);
    setSavingPreferences(true);

    try {
      const { error: updateError } = await supabase
        .from("user_notification_preferences" as any)
        .upsert({
          user_id: user.id,
          email_on_new_message: value,
          updated_at: new Date().toISOString(),
        }, { onConflict: "user_id" });

      if (updateError) throw updateError;

      toast({
        title: "Lagret",
        description: "Varslingsinnstillingene er oppdatert",
      });
    } catch (error) {
      console.error("Error saving preferences:", error);
      setEmailOnNewMessage(!value);
      toast({
        title: "Feil",
        description: "Kunne ikke lagre varslingsinnstillinger",
        variant: "destructive",
      });
    } finally {
      setSavingPreferences(false);
    }
  };

  const handleAvatarChange = (file: File | null, previewUrl: string | null) => {
    setAvatarFile(file);
    setAvatarPreview(previewUrl);
  };

  const uploadAvatar = async (): Promise<string | null> => {
    if (!avatarFile || !user) return avatarUrl;

    const fileExt = "jpg";
    const filePath = `${user.id}/avatar.${fileExt}`;

    const { error: uploadError } = await supabase.storage
      .from("avatars")
      .upload(filePath, avatarFile, { upsert: true });

    if (uploadError) throw uploadError;

    const { data: urlData } = supabase.storage
      .from("avatars")
      .getPublicUrl(filePath);

    return `${urlData.publicUrl}?t=${Date.now()}`;
  };

  const handleSave = async () => {
    if (!user) return;
    
    setSaving(true);
    try {
      let newAvatarUrl = avatarUrl;
      if (avatarFile) {
        newAvatarUrl = await uploadAvatar();
      }

      const { error } = await supabase
        .from("users")
        .update({ 
          phone: phone.trim() || null,
          avatar_url: newAvatarUrl
        })
        .eq("id", user.id);

      if (error) throw error;

      setAvatarUrl(newAvatarUrl);
      setAvatarFile(null);
      setAvatarPreview(null);

      toast({
        title: "Lagret",
        description: "Profilen din er oppdatert",
      });
    } catch (error) {
      console.error("Error updating profile:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke oppdatere profilen",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const getRoleLabel = (role: string) => {
    const labels: Record<string, string> = {
      admin: "Administrator",
      district_manager: "Distriktssjef",
      salon_owner: "Salongeier",
      daglig_leder: "Dagligleder",
      avdelingsleder: "Avdelingsleder",
      styreleder: "Styreleder",
      stylist: "Frisør",
      apprentice: "Lærling",
      supplier_admin: "Leverandør Admin",
      supplier_sales: "Leverandør Salg",
      supplier_business_dev: "Leverandør Business Dev",
    };
    return labels[role] || role;
  };

  const getFunctionLabel = (func: string | null) => {
    if (!func) return null;
    const labels: Record<string, string> = {
      frisor: "Frisør",
      hudpleier: "Hudpleier",
      negltekniker: "Negltekniker",
      fargeteknikker: "Fargeteknikker",
      kombinert: "Kombinert",
    };
    return labels[func] || func;
  };

  const formatDate = (dateStr: string | null) => {
    if (!dateStr) return null;
    try {
      return format(new Date(dateStr), "d. MMMM yyyy", { locale: nb });
    } catch {
      return dateStr;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  const displayAvatar = avatarPreview || avatarUrl;
  const isHubSpotSynced = !!userDetails?.hubspot_contact_id;

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-card border-b border-border px-4 py-4 sticky top-0 z-10">
        <div className="max-w-2xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => navigate("/dashboard")}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-xl font-semibold text-foreground">Min Profil</h1>
          </div>
          <GlobalMessageBadge showText={false} size="icon" variant="ghost" />
        </div>
      </header>

      <main className="max-w-2xl mx-auto p-4 space-y-6">
        {/* Profile Info Card */}
        <Card className="p-6">
          <div className="flex items-center gap-4 mb-6">
            <ImageUpload
              value={displayAvatar}
              onChange={handleAvatarChange}
              size="lg"
              shape="circle"
              placeholder={
                <div className="flex flex-col items-center">
                  <Camera className="h-6 w-6" />
                </div>
              }
              disabled={saving}
            />
            <div>
              <h2 className="text-lg font-semibold text-foreground">{`${firstName} ${lastName}`.trim() || profile?.name || "Bruker"}</h2>
              <p className="text-sm text-muted-foreground">{user?.email}</p>
              <div className="flex flex-wrap gap-1 mt-1">
                {profile?.role && (
                  <Badge variant="secondary" className="text-xs">
                    {getRoleLabel(profile.role)}
                  </Badge>
                )}
                {userDetails?.aktiv === false && (
                  <Badge variant="destructive" className="text-xs">
                    Inaktiv
                  </Badge>
                )}
              </div>
            </div>
          </div>

          <Separator className="mb-6" />

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="firstName">Fornavn</Label>
                <Input
                  id="firstName"
                  value={firstName}
                  disabled
                  className="bg-muted"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName">Etternavn</Label>
                <Input
                  id="lastName"
                  value={lastName}
                  disabled
                  className="bg-muted"
                />
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              Navn kan ikke endres her. Kontakt administrator ved behov.
            </p>

            <div className="space-y-2">
              <Label htmlFor="email" className="flex items-center gap-2">
                <Mail className="h-4 w-4" />
                E-post
              </Label>
              <Input
                id="email"
                value={user?.email || ""}
                disabled
                className="bg-muted"
              />
              <p className="text-xs text-muted-foreground">
                E-postadressen kan ikke endres
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone" className="flex items-center gap-2">
                <Phone className="h-4 w-4" />
                Mobil
              </Label>
              <Input
                id="phone"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+47 xxx xx xxx"
                type="tel"
              />
              {phone && !phone.startsWith("+") && (
                <p className="text-sm text-destructive">
                  Mobilnummer må starte med landskode (f.eks. +47)
                </p>
              )}
            </div>

            <Button onClick={handleSave} disabled={saving} className="w-full">
              <Save className="h-4 w-4 mr-2" />
              {saving ? "Lagrer..." : "Lagre endringer"}
            </Button>
          </div>
        </Card>

        {/* Employment Info Card */}
        <Card className="p-6">
          <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
            <Briefcase className="h-5 w-5" />
            Ansettelsesforhold
            {isHubSpotSynced && (
              <Badge variant="outline" className="ml-auto text-xs gap-1">
                <RefreshCw className="h-3 w-3" />
                Synket
              </Badge>
            )}
          </h3>
          
          <div className="space-y-3 text-sm">
            {userDetails?.frisorfunksjon && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Funksjon</span>
                <span className="font-medium text-foreground">{getFunctionLabel(userDetails.frisorfunksjon)}</span>
              </div>
            )}
            
            {userDetails?.stillingsprosent != null && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Stillingsprosent</span>
                <span className="font-medium text-foreground">{userDetails.stillingsprosent}%</span>
              </div>
            )}
            
            {userDetails?.ansettelsesdato && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Ansatt siden</span>
                <span className="font-medium text-foreground">{formatDate(userDetails.ansettelsesdato)}</span>
              </div>
            )}
            
            {userDetails?.fodselsdato && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Fødselsdato</span>
                <span className="font-medium text-foreground">{formatDate(userDetails.fodselsdato)}</span>
              </div>
            )}
            
            {userDetails?.fagbrev != null && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Fagbrev</span>
                <span className="font-medium text-foreground">
                  {userDetails.fagbrev ? (
                    <Badge variant="default" className="gap-1">
                      <Award className="h-3 w-3" />
                      Ja
                    </Badge>
                  ) : (
                    "Nei"
                  )}
                </span>
              </div>
            )}
            
            {userDetails?.fagbrevdato && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Fagbrevdato</span>
                <span className="font-medium text-foreground">{formatDate(userDetails.fagbrevdato)}</span>
              </div>
            )}

            {!userDetails?.frisorfunksjon && !userDetails?.stillingsprosent && !userDetails?.ansettelsesdato && (
              <p className="text-muted-foreground text-center py-2">
                Ingen ansettelsesdata registrert
              </p>
            )}
          </div>
          
          {isHubSpotSynced && userDetails?.hubspot_synced_at && (
            <p className="text-xs text-muted-foreground mt-4 flex items-center gap-1">
              <Calendar className="h-3 w-3" />
              Sist synkronisert: {formatDate(userDetails.hubspot_synced_at)}
            </p>
          )}
        </Card>

        {/* Health Insurance Card - Only show if user has health insurance */}
        {userDetails?.helseforsikring_status && userDetails.helseforsikring_status !== "Ingen" && (
          <Card className="overflow-hidden">
            {/* Logo header with gradient */}
            <div className="bg-gradient-to-r from-rose-50 to-red-50 dark:from-rose-950/30 dark:to-red-950/30 px-6 py-5 border-b">
              <div className="flex items-center justify-center gap-4">
                <img src={haar1ForsikringLogo} alt="Hår1 Forsikring" className="h-10 object-contain" />
                <div className="flex items-center gap-2">
                  <div className="h-px w-8 bg-border" />
                  <span className="text-muted-foreground text-xs uppercase tracking-wider">i samarbeid med</span>
                  <div className="h-px w-8 bg-border" />
                </div>
                <img src={ergoLogo} alt="ERGO" className="h-6 object-contain" />
              </div>
            </div>
            
            <div className="p-6 space-y-5">
              {/* Status section */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-red-500" />
                  <h3 className="font-semibold text-foreground">Din Helseforsikring</h3>
                </div>
                {userDetails.helseforsikring_status === "Aktiv" && (
                  <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">Aktiv</Badge>
                )}
                {userDetails.helseforsikring_status === "Ventende" && (
                  <Badge className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200">Ventende</Badge>
                )}
                {userDetails.helseforsikring_status === "Avsluttet" && (
                  <Badge className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200">Avsluttet</Badge>
                )}
              </div>

              {/* Insurance details grid */}
              <div className="grid grid-cols-2 gap-3 text-sm">
                {healthInsuranceAvtalenummer && (
                  <div className="bg-muted/30 rounded-lg p-3">
                    <p className="text-xs text-muted-foreground mb-1">Avtalenummer</p>
                    <p className="font-medium text-foreground">{healthInsuranceAvtalenummer}</p>
                  </div>
                )}
                {userDetails.helseforsikring_oppstartsdato && (
                  <div className="bg-muted/30 rounded-lg p-3">
                    <p className="text-xs text-muted-foreground mb-1">Oppstartsdato</p>
                    <p className="font-medium text-foreground">{formatDate(userDetails.helseforsikring_oppstartsdato)}</p>
                  </div>
                )}
                {userDetails.helseforsikring_oppsigelsesdato && (
                  <div className="bg-muted/30 rounded-lg p-3">
                    <p className="text-xs text-muted-foreground mb-1">Oppsigelsesdato</p>
                    <p className="font-medium text-foreground">{formatDate(userDetails.helseforsikring_oppsigelsesdato)}</p>
                  </div>
                )}
                {userDetails.helseforsikring_pris && (
                  <div className="bg-muted/30 rounded-lg p-3">
                    <p className="text-xs text-muted-foreground mb-1">Årlig premie</p>
                    <p className="font-medium text-foreground">
                      {new Intl.NumberFormat("nb-NO", { style: "currency", currency: "NOK", maximumFractionDigits: 0 }).format(userDetails.helseforsikring_pris)}
                    </p>
                  </div>
                )}
              </div>

              <Separator />

              {/* Coverage Details */}
              <div className="space-y-3">
                <h4 className="font-medium text-foreground text-sm flex items-center gap-2">
                  <Shield className="h-4 w-4 text-primary" />
                  Forsikringen din dekker blant annet
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {[
                    "Operasjoner og dagkirurgi",
                    "Sykehusinnleggelse",
                    "Behandling hos legespesialist",
                    "Kreftbehandling",
                    "Psykologisk førstehjelp (12 timer)",
                    "Fysikalsk behandling (12 timer)"
                  ].map((item, index) => (
                    <div key={index} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <div className="h-5 w-5 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center flex-shrink-0">
                        <Check className="h-3 w-3 text-green-600 dark:text-green-400" />
                      </div>
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
                <p className="text-xs text-muted-foreground italic">
                  * Fysikalsk behandling har egenandel på 250 kr per behandling
                </p>
              </div>

              <Separator />

              {/* How to use - App section */}
              <div className="space-y-3">
                <h4 className="font-medium text-foreground text-sm flex items-center gap-2">
                  <Smartphone className="h-4 w-4 text-primary" />
                  Slik bruker du forsikringen
                </h4>
                <div className="bg-gradient-to-br from-primary/5 to-primary/10 rounded-xl p-4 space-y-3 border border-primary/10">
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-foreground">BliFrisk-appen</p>
                    <p className="text-sm text-muted-foreground">
                      Last ned appen og få rask tilgang til helsetjenester, bestill behandling og hold oversikt over din forsikring.
                    </p>
                    <a 
                      href="https://www.blifrisk.no/app" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline"
                    >
                      Last ned appen her
                      <ExternalLink className="h-3.5 w-3.5" />
                    </a>
                  </div>
                  
                  {healthInsuranceAvtalenummer && (
                    <div className="bg-background rounded-lg p-3 border shadow-sm">
                      <p className="text-xs text-muted-foreground mb-1">Ditt avtalenummer for registrering:</p>
                      <p className="font-mono text-lg font-bold text-foreground tracking-wide">{healthInsuranceAvtalenummer}</p>
                    </div>
                  )}
                </div>
              </div>

              <Separator />

              {/* Contact Info */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-muted/30 rounded-lg p-4">
                <div>
                  <p className="text-sm font-medium text-foreground mb-1">Spørsmål?</p>
                  <p className="text-xs text-muted-foreground">Vi hjelper deg gjerne!</p>
                </div>
                <div className="flex flex-col sm:flex-row gap-3">
                  <a href="tel:80083313" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
                    <Phone className="h-4 w-4" />
                    <span>800 83 313</span>
                  </a>
                  <a href="mailto:infohelse@ergo.no" className="inline-flex items-center gap-2 text-sm text-primary hover:underline">
                    <Mail className="h-4 w-4" />
                    <span>infohelse@ergo.no</span>
                  </a>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="bg-muted/20 px-6 py-4 border-t text-center">
              <p className="text-sm font-medium text-foreground">Takk for at du valgte Hår1 Helseforsikring</p>
              <p className="text-xs text-muted-foreground mt-1">Vi er her for deg – din trygghet i frisørhverdagen</p>
            </div>
          </Card>
        )}

        {/* Role & Access Card */}
        <Card className="p-6">
          <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Rolle og tilgang
          </h3>
          
          <div className="space-y-3 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Rolle</span>
              <span className="font-medium text-foreground">{getRoleLabel(profile?.role || "")}</span>
            </div>
            {profile?.salon_id && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Salong</span>
                <span className="font-medium text-foreground">{salonName || "Laster..."}</span>
              </div>
            )}
            {profile?.district_id && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Distrikt</span>
                <span className="font-medium text-foreground">{districtName || "Laster..."}</span>
              </div>
            )}
          </div>
          
          <p className="text-xs text-muted-foreground mt-4">
            Kontakt administrator for å endre rolle eller tilknytning
          </p>
        </Card>

        {/* Notification Settings Card */}
        <Card className="p-6">
          <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
            <Bell className="h-5 w-5" />
            Varslingsinnstillinger
          </h3>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-foreground">E-post ved nye meldinger</p>
                <p className="text-sm text-muted-foreground">Motta e-post når du får nye meldinger</p>
              </div>
              <Switch
                checked={emailOnNewMessage}
                onCheckedChange={handleNotificationChange}
                disabled={!preferencesLoaded || savingPreferences}
              />
            </div>
          </div>
        </Card>
      </main>
    </div>
  );
};

export default Profile;
