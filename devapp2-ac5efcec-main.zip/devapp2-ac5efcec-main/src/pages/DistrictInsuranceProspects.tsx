import { useState, useMemo, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { AppLayout } from "@/components/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ArrowLeft, Search, Building2, MapPin, Users, Download, ExternalLink, Filter, TrendingUp, FileText } from "lucide-react";
import * as XLSX from "xlsx";

interface SalonProspect {
  id: string;
  name: string;
  org_number: string | null;
  address: string | null;
  city: string | null;
  employee_count: number | null;
  medlemsstatus: string | null;
  hs_object_id: string | null;
  district_id: string | null;
  district_name: string | null;
  chain_name: string | null;
}

export default function DistrictInsuranceProspects() {
  const navigate = useNavigate();
  const { profile } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [chainFilter, setChainFilter] = useState<string>("all");
  const [membershipFilter, setMembershipFilter] = useState<string>("all");

  const isAdmin = profile?.role === "admin";
  const isDistrictManager = profile?.role === "district_manager";

  if (!isAdmin && !isDistrictManager) {
    navigate("/dashboard");
    return null;
  }

  // Fetch all districts (for admin dropdown)
  const { data: districts } = useQuery({
    queryKey: ["districts"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("districts")
        .select("id, name")
        .order("name");
      if (error) throw error;
      return data;
    },
  });

  // For district manager, use their district_id
  const userDistrictId = profile?.district_id;
  const [selectedDistrictId, setSelectedDistrictId] = useState<string | null>(null);

  // Set default district when profile loads
  useEffect(() => {
    if (isDistrictManager && userDistrictId && !selectedDistrictId) {
      setSelectedDistrictId(userDistrictId);
    } else if (isAdmin && districts?.length && !selectedDistrictId) {
      setSelectedDistrictId(districts[0].id);
    }
  }, [userDistrictId, isDistrictManager, isAdmin, districts, selectedDistrictId]);

  const selectedDistrictName = districts?.find(d => d.id === selectedDistrictId)?.name;

  // Fetch prospects (salons without active insurance in selected district)
  const { data: prospects, isLoading } = useQuery({
    queryKey: ["district-insurance-prospects", selectedDistrictId],
    queryFn: async () => {
      if (!selectedDistrictId) return [];

      // Get salons in the district
      const { data: allSalons, error: salonsError } = await supabase
        .from("salons")
        .select(`
          id,
          name,
          org_number,
          address,
          city,
          employee_count,
          medlemsstatus,
          hs_object_id,
          district_id,
          districts:district_id (name),
          chains:chain_id (name)
        `)
        .eq("district_id", selectedDistrictId);

      if (salonsError) throw salonsError;

      // Get existing salon IDs with active insurance
      const { data: existingInsurance, error: insuranceError } = await supabase
        .from("salon_insurance")
        .select("salon_id")
        .or("salong_aktiv.eq.true,yrkesskadeforsikring_aktiv.eq.true,cyber_aktiv.eq.true,reise_aktiv.eq.true,fritidsulykke_aktiv.eq.true,helse_status.eq.true");

      if (insuranceError) throw insuranceError;

      const insuredIds = new Set(existingInsurance?.map(i => i.salon_id) || []);

      // Filter and map
      return (allSalons?.filter(s => !insuredIds.has(s.id)) || []).map(s => ({
        id: s.id,
        name: s.name,
        org_number: s.org_number,
        address: s.address,
        city: s.city,
        employee_count: s.employee_count,
        medlemsstatus: s.medlemsstatus,
        hs_object_id: s.hs_object_id,
        district_id: s.district_id,
        district_name: (s.districts as any)?.name || null,
        chain_name: (s.chains as any)?.name || null,
      })) as SalonProspect[];
    },
    enabled: !!selectedDistrictId,
  });

  // Filter and search
  const filteredProspects = useMemo(() => {
    if (!prospects) return [];

    return prospects.filter(prospect => {
      const matchesSearch = searchQuery === "" || 
        prospect.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        prospect.org_number?.includes(searchQuery) ||
        prospect.city?.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesChain = chainFilter === "all" || 
        prospect.chain_name === chainFilter ||
        (chainFilter === "none" && !prospect.chain_name);

      const matchesMembership = membershipFilter === "all" || 
        prospect.medlemsstatus === membershipFilter;

      return matchesSearch && matchesChain && matchesMembership;
    });
  }, [prospects, searchQuery, chainFilter, membershipFilter]);

  // Statistics
  const stats = useMemo(() => {
    if (!prospects) return { total: 0, byMembership: {}, byChain: {} };

    const byMembership: Record<string, number> = {};
    const byChain: Record<string, number> = {};

    prospects.forEach(p => {
      const membership = p.medlemsstatus || "Ukjent";
      byMembership[membership] = (byMembership[membership] || 0) + 1;

      const chain = p.chain_name || "Ingen kjede";
      byChain[chain] = (byChain[chain] || 0) + 1;
    });

    return { total: prospects.length, byMembership, byChain };
  }, [prospects]);

  // Export to Excel
  const handleExport = () => {
    if (!filteredProspects.length) return;

    const exportData = filteredProspects.map(p => ({
      "Salongnavn": p.name,
      "Org.nummer": p.org_number || "",
      "Adresse": p.address || "",
      "By": p.city || "",
      "Distrikt": p.district_name || "",
      "Kjede": p.chain_name || "",
      "Medlemsstatus": p.medlemsstatus || "",
      "Antall ansatte": p.employee_count || "",
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Prospekter");
    XLSX.writeFile(wb, `forsikring-prospekter-${selectedDistrictName || "distrikt"}-${new Date().toISOString().split('T')[0]}.xlsx`);
  };

  // Open HubSpot
  const openHubSpot = (hubspotId: string | null) => {
    if (hubspotId) {
      window.open(`https://app.hubspot.com/contacts/27027329/company/${hubspotId}`, "_blank");
    }
  };

  // Get unique membership statuses from data
  const membershipStatuses = useMemo(() => {
    if (!prospects) return [];
    const statuses = new Set(prospects.map(p => p.medlemsstatus).filter(Boolean));
    return Array.from(statuses).sort();
  }, [prospects]);

  // Get unique chains from data
  const uniqueChains = useMemo(() => {
    if (!prospects) return [];
    const chainNames = new Set(prospects.map(p => p.chain_name).filter(Boolean));
    return Array.from(chainNames).sort();
  }, [prospects]);

  return (
    <AppLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate("/district/insurance")}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-2xl font-semibold">Salonger uten forsikring</h1>
              <p className="text-muted-foreground">
                Salgsmuligheter i {selectedDistrictName || "ditt distrikt"}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {isAdmin && (
              <Select
                value={selectedDistrictId || ""}
                onValueChange={(value) => setSelectedDistrictId(value)}
              >
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder="Velg distrikt..." />
                </SelectTrigger>
                <SelectContent>
                  {districts?.map((district) => (
                    <SelectItem key={district.id} value={district.id}>
                      {district.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
            <Button onClick={handleExport} disabled={!filteredProspects.length}>
              <Download className="h-4 w-4 mr-2" />
              Eksporter
            </Button>
          </div>
        </div>

        {/* Statistics */}
        <div className="grid gap-4 md:grid-cols-3">
          <Card className="border-amber-200 bg-gradient-to-r from-amber-50/80 to-orange-50/50">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-amber-900">Salgsmuligheter</CardTitle>
              <TrendingUp className="h-4 w-4 text-amber-600" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-amber-900">{stats.total}</div>
              <p className="text-xs text-amber-700">
                salonger uten forsikring i distriktet
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Per medlemsstatus</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="flex gap-1 flex-wrap">
                {Object.entries(stats.byMembership).map(([status, count]) => (
                  <Badge key={status} variant="outline" className="text-xs">
                    {status}: {count}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Per kjede</CardTitle>
              <Building2 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="flex gap-1 flex-wrap">
                {Object.entries(stats.byChain).slice(0, 4).map(([chain, count]) => (
                  <Badge key={chain} variant="outline" className="text-xs">
                    {chain}: {count}
                  </Badge>
                ))}
                {Object.keys(stats.byChain).length > 4 && (
                  <Badge variant="outline" className="text-xs">
                    +{Object.keys(stats.byChain).length - 4} mer
                  </Badge>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Filter className="h-4 w-4" />
              Filtrer prospekter
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Søk på navn, org.nr. eller by..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9"
                />
              </div>
              <Select value={chainFilter} onValueChange={setChainFilter}>
                <SelectTrigger className="w-full sm:w-48">
                  <SelectValue placeholder="Alle kjeder" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Alle kjeder</SelectItem>
                  <SelectItem value="none">Ingen kjede</SelectItem>
                  {uniqueChains.map((chain) => (
                    <SelectItem key={chain} value={chain as string}>
                      {chain}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={membershipFilter} onValueChange={setMembershipFilter}>
                <SelectTrigger className="w-full sm:w-48">
                  <SelectValue placeholder="Alle statuser" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Alle statuser</SelectItem>
                  {membershipStatuses.map((status) => (
                    <SelectItem key={status} value={status as string}>
                      {status}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Results table */}
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base">
                Prospekter ({filteredProspects.length})
              </CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-3">
                {[...Array(5)].map((_, i) => (
                  <Skeleton key={i} className="h-12 w-full" />
                ))}
              </div>
            ) : filteredProspects.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                {searchQuery || chainFilter !== "all" || membershipFilter !== "all"
                  ? "Ingen prospekter matcher filtreringen"
                  : "Ingen salonger uten forsikring i dette distriktet"}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Salongnavn</TableHead>
                      <TableHead>Org.nummer</TableHead>
                      <TableHead>By</TableHead>
                      <TableHead>Kjede</TableHead>
                      <TableHead>Medlemsstatus</TableHead>
                      <TableHead>Ansatte</TableHead>
                      <TableHead className="text-right">Handlinger</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredProspects.map((prospect) => (
                      <TableRow key={prospect.id} className="hover:bg-muted/50">
                        <TableCell className="font-medium">{prospect.name}</TableCell>
                        <TableCell className="text-muted-foreground">
                          {prospect.org_number || "-"}
                        </TableCell>
                        <TableCell>{prospect.city || "-"}</TableCell>
                        <TableCell>
                          {prospect.chain_name ? (
                            <Badge variant="secondary">{prospect.chain_name}</Badge>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell>
                          {prospect.medlemsstatus ? (
                            <Badge 
                              variant={prospect.medlemsstatus === "Medlem" ? "default" : "outline"}
                            >
                              {prospect.medlemsstatus}
                            </Badge>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell>{prospect.employee_count || "-"}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => navigate(`/insurance/quote/create?salonId=${prospect.id}`)}
                            >
                              <FileText className="h-4 w-4 mr-1" />
                              Opprett tilbud
                            </Button>
                            {prospect.hs_object_id && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => openHubSpot(prospect.hs_object_id)}
                              >
                                <ExternalLink className="h-4 w-4" />
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
