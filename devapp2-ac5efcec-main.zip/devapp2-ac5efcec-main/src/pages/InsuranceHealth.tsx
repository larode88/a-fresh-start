import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { AppLayout } from "@/components/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Heart, FileText, Mail, Phone, Users, Check } from "lucide-react";

export default function InsuranceHealth() {
  const navigate = useNavigate();
  const { profile } = useAuth();

  const { data: healthProduct } = useQuery({
    queryKey: ["insurance-health-product"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("insurance_products")
        .select("*")
        .eq("product_type", "helse")
        .eq("active", true)
        .single();
      
      if (error && error.code !== "PGRST116") throw error;
      return data;
    },
  });

  const { data: healthDocument } = useQuery({
    queryKey: ["insurance-health-document"],
    queryFn: async () => {
      if (!healthProduct?.id) return null;
      const { data, error } = await supabase
        .from("insurance_product_documents")
        .select("*")
        .eq("product_id", healthProduct.id)
        .eq("document_type", "vilkar")
        .maybeSingle();
      
      if (error) throw error;
      return data;
    },
    enabled: !!healthProduct?.id,
  });

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("nb-NO", {
      style: "currency",
      currency: "NOK",
      maximumFractionDigits: 0,
    }).format(price);
  };

  const benefits = [
    "Rask tilgang til spesialisthelsetjenester",
    "Videokonsultasjon med lege",
    "Psykologhjelp inkludert",
    "Fysioterapi og kiropraktikk",
    "Medisinske undersøkelser",
    "Operasjoner og behandling",
  ];

  return (
    <AppLayout title="Helseforsikring" subtitle="Informasjon og bestilling">
      <div className="container mx-auto px-4 py-8 space-y-6">
        <Button variant="ghost" onClick={() => navigate("/insurance")} className="mb-2">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Tilbake til forsikringsoversikt
        </Button>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Main info card */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="p-3 rounded-lg bg-primary/10">
                    <Heart className="h-8 w-8 text-primary" />
                  </div>
                  <div>
                    <CardTitle className="text-2xl">Helseforsikring</CardTitle>
                    <CardDescription>
                      Gi dine ansatte trygghet med rask tilgang til helsehjelp
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <p className="text-muted-foreground">
                  Helseforsikringen gir dine ansatte rask tilgang til spesialisthelsetjenester, 
                  psykologhjelp og behandling. En god helseforsikring kan redusere sykefravær 
                  og øke trivselen på arbeidsplassen.
                </p>

                <div>
                  <h4 className="font-semibold mb-3">Hva er inkludert?</h4>
                  <div className="grid gap-2 sm:grid-cols-2">
                    {benefits.map((benefit, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-primary shrink-0" />
                        <span className="text-sm">{benefit}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-muted/50 p-4 rounded-lg">
                  <h4 className="font-semibold mb-2">Hvordan bestille?</h4>
                  <p className="text-sm text-muted-foreground mb-3">
                    Helseforsikring krever en individuell vurdering basert på antall ansatte 
                    og ønsket dekning. Ta kontakt med oss for et skreddersydd tilbud.
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Vi hjelper deg med å finne riktig løsning for din salong og dine ansatte.
                  </p>
                </div>
              </CardContent>
            </Card>

            {healthDocument && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    Dokumenter
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Button variant="outline" asChild>
                    <a href={healthDocument.file_url} target="_blank" rel="noopener noreferrer">
                      <FileText className="h-4 w-4 mr-2" />
                      {healthDocument.title || "Les vilkår"}
                    </a>
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Sidebar with price and contact */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Pris</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  <span className="text-4xl font-bold">
                    {healthProduct ? formatPrice(healthProduct.base_price) : "kr 5 050"}
                  </span>
                  <span className="text-muted-foreground">/person/år</span>
                </div>
                <p className="text-sm text-muted-foreground text-center">
                  Prisen er per ansatt som tegner helseforsikring
                </p>
                <Badge variant="outline" className="w-full justify-center">
                  <Users className="h-3 w-3 mr-1" />
                  Per person
                </Badge>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Kontakt oss</CardTitle>
                <CardDescription>
                  Ta kontakt for et tilbud tilpasset din salong
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button className="w-full" asChild>
                  <a href="mailto:forsikring@haar1.no?subject=Forespørsel om helseforsikring">
                    <Mail className="h-4 w-4 mr-2" />
                    Send e-post
                  </a>
                </Button>
                <Button variant="outline" className="w-full" asChild>
                  <a href="tel:+4722222222">
                    <Phone className="h-4 w-4 mr-2" />
                    Ring oss
                  </a>
                </Button>
                <p className="text-xs text-muted-foreground text-center">
                  forsikring@haar1.no
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
