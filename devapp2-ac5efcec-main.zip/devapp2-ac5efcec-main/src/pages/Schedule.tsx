import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useSalonContext } from "@/components/SalonSelector";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Calendar, Clock, Users, ChevronLeft, ChevronRight, BarChart3 } from "lucide-react";
import { OpeningHoursManager } from "@/components/schedule/OpeningHoursManager";
import { EmployeeScheduleList } from "@/components/schedule/EmployeeScheduleList";
import { TurnusTimeline } from "@/components/schedule/TurnusTimeline";
import { TurnusAarsOversikt } from "@/components/schedule/TurnusAarsOversikt";
import { AppLayout } from "@/components/AppLayout";

export default function Schedule() {
  const { profile, loading: authLoading } = useAuth();
  const role = profile?.role;
  const { salons, selectedSalonId, setSelectedSalonId, loading: salonLoading, canSelectSalon } = useSalonContext();

  const [selectedYear, setSelectedYear] = useState<number>(new Date().getFullYear());
  
  const canManage = ["admin", "salon_owner", "daglig_leder", "avdelingsleder"].includes(role || "");
  
  const currentYear = new Date().getFullYear();
  const years = [currentYear - 1, currentYear, currentYear + 1];

  if (authLoading || salonLoading) {
    return (
      <div className="container mx-auto p-6 space-y-6">
        <Skeleton className="h-10 w-48" />
        <Skeleton className="h-96" />
      </div>
    );
  }

  if (!canManage && role !== "stylist") {
    return (
      <div className="container mx-auto p-6">
        <Card>
          <CardContent className="pt-6">
            <p className="text-center text-muted-foreground">
              Du har ikke tilgang til denne siden.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <AppLayout title="Turnus & Arbeidsplan" subtitle="Administrer åpningstider og vaktplaner">
      <div className="container mx-auto p-6 space-y-6">
        {/* Year selector */}
        <div className="flex items-center gap-2">
          <Calendar className="h-4 w-4 text-muted-foreground" />
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={() => setSelectedYear(y => y - 1)}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Select value={selectedYear.toString()} onValueChange={(v) => setSelectedYear(parseInt(v))}>
            <SelectTrigger className="w-[100px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {years.map(year => (
                <SelectItem key={year} value={year.toString()}>
                  {year}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={() => setSelectedYear(y => y + 1)}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>

        {!selectedSalonId ? (
          <Card>
            <CardContent className="pt-6">
              <p className="text-center text-muted-foreground">Velg en salong for å se turnus.</p>
            </CardContent>
          </Card>
        ) : (
          <Tabs defaultValue="week" className="space-y-4">
            <TabsList>
              <TabsTrigger value="week" className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                Ukeoversikt
              </TabsTrigger>
              <TabsTrigger value="employees" className="flex items-center gap-2">
                <Users className="h-4 w-4" />
                Ansatte
              </TabsTrigger>
              <TabsTrigger value="annual" className="flex items-center gap-2">
                <BarChart3 className="h-4 w-4" />
                Årsplan
              </TabsTrigger>
              {canManage && (
                <TabsTrigger value="hours" className="flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  Åpningstider
                </TabsTrigger>
              )}
            </TabsList>

            <TabsContent value="week">
              <TurnusTimeline salonId={selectedSalonId} canManage={canManage} />
            </TabsContent>

            <TabsContent value="employees">
              <EmployeeScheduleList salonId={selectedSalonId} canManage={canManage} />
            </TabsContent>

            <TabsContent value="annual">
              <TurnusAarsOversikt salonId={selectedSalonId} year={selectedYear} />
            </TabsContent>

            {canManage && (
              <TabsContent value="hours">
                <OpeningHoursManager salonId={selectedSalonId} year={selectedYear} />
              </TabsContent>
            )}
          </Tabs>
        )}
      </div>
    </AppLayout>
  );
}
