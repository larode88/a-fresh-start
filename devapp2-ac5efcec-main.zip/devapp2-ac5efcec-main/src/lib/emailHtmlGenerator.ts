// Shared email HTML generation logic - used by both frontend (EmailPreview) and backend (render-email-template)
// This ensures consistency between preview and actual sent emails

export interface EmailModule {
  id: string;
  type: string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  content: Record<string, any>;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  styles?: Record<string, any>;
}

export interface EmailStructure {
  modules: EmailModule[];
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  globalStyles?: Record<string, any>;
}

const BASE_FONT = "'DM Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif";

// Helper to get background color with priority: content.backgroundColor > styles.backgroundColor > default
const getBgColor = (
  c: Record<string, unknown>,
  styles: Record<string, unknown>,
  defaultColor: string
): string => {
  if (c.backgroundColor && typeof c.backgroundColor === 'string' && c.backgroundColor !== '') {
    return c.backgroundColor;
  }
  if (styles.backgroundColor && typeof styles.backgroundColor === 'string' && styles.backgroundColor !== '') {
    return styles.backgroundColor as string;
  }
  return defaultColor;
};

// Generate HTML for a single module
export function generateModuleHtml(module: EmailModule, variables: Record<string, string> = {}): string {
  const { type, content, styles = {} } = module;

  // Replace tokens in content
  const processContent = (c: Record<string, unknown>): Record<string, unknown> => {
    const processed: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(c)) {
      if (typeof value === 'string') {
        processed[key] = replaceTokens(value, variables);
      } else if (Array.isArray(value)) {
        processed[key] = value.map(item => 
          typeof item === 'string' ? replaceTokens(item, variables) : item
        );
      } else if (typeof value === 'object' && value !== null) {
        processed[key] = processContent(value as Record<string, unknown>);
      } else {
        processed[key] = value;
      }
    }
    return processed;
  };

  const c = processContent(content);

  switch (type) {
    case "header-logo":
    case "header-portalen":
      return `
        <tr>
          <td style="background-color: ${getBgColor(c, styles, '#FAF8F5')}; padding: ${styles.padding || '32px'}; text-align: center;">
            <img src="${c.logoUrl}" alt="${c.logoAlt || 'Logo'}" style="max-height: 60px;" />
          </td>
        </tr>
      `;

    case "text":
      // Support both content.content and content.text for backward compatibility
      const textContent = (c.content || c.text || '') as string;
      const textColor = styles.color || '#3D3D3D';
      const textBgColor = getBgColor(c, styles, 'transparent');
      return `
        <tr>
          <td style="padding: ${styles.padding || '24px 32px'}; font-family: ${BASE_FONT}; font-size: 16px; line-height: 1.6; color: ${textColor}; text-align: ${styles.textAlign || 'left'}; background-color: ${textBgColor};">
            ${textContent}
          </td>
        </tr>
      `;

    case "heading":
      const headingSize = c.level === 'h1' ? '28px' : c.level === 'h3' ? '18px' : c.size === 'large' ? '24px' : c.size === 'small' ? '16px' : '22px';
      const headingColor = styles.color || c.color || '#8B7355';
      const headingBgColor = getBgColor(c, styles, 'transparent');
      return `
        <tr>
          <td style="padding: ${styles.padding || '24px 32px 8px 32px'}; font-family: ${BASE_FONT}; font-size: ${headingSize}; font-weight: 600; line-height: 1.4; color: ${headingColor}; text-align: ${styles.textAlign || 'left'}; background-color: ${headingBgColor};">
            ${c.text || ''}
          </td>
        </tr>
      `;

    case "cta-button":
      const ctaBgColor = getBgColor(c, styles, 'transparent');
      return `
        <tr>
          <td style="padding: ${styles.padding || '16px 32px'}; text-align: center; background-color: ${ctaBgColor};">
            <a href="${c.url || '#'}" style="display: inline-block; padding: 14px 32px; background: linear-gradient(135deg, #8B7355 0%, #6B5440 100%); color: #FFFFFF; text-decoration: none; border-radius: 8px; font-weight: 600; font-size: 16px; font-family: ${BASE_FONT};">
              ${c.text || 'Klikk her'}
            </a>
          </td>
        </tr>
      `;

    case "info-box":
      // Support both content.content and content.text for backward compatibility
      const infoBoxContent = (c.content || c.text || '') as string;
      return `
        <tr>
          <td style="padding: ${styles.margin || '16px 32px'};">
            <table width="100%" cellpadding="0" cellspacing="0" style="background: linear-gradient(135deg, #FAF7F2 0%, #F5EEE6 100%); border-radius: 12px;">
              <tr>
                <td style="padding: ${styles.padding || '24px'};">
                  ${c.title ? `<h3 style="margin: 0 0 12px 0; font-weight: 600; font-size: 18px; color: #3D3D3D; font-family: ${BASE_FONT};">${c.title}</h3>` : ''}
                  <div style="font-family: ${BASE_FONT}; font-size: 15px; line-height: 1.6; color: #3D3D3D;">
                    ${infoBoxContent}
                  </div>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      `;

    case "success-banner":
      return `
        <tr>
          <td style="padding: ${styles.margin || '16px 32px'};">
            <table width="100%" cellpadding="0" cellspacing="0" style="background: linear-gradient(135deg, #E8F5E9 0%, #C8E6C9 100%); border-radius: 12px;">
              <tr>
                <td style="padding: 24px; text-align: center;">
                  <div style="font-size: 48px; margin-bottom: 12px;">${c.emoji || '🎉'}</div>
                  <div style="font-family: ${BASE_FONT}; font-size: 20px; font-weight: 600; color: #2E7D32;">
                    ${c.text || 'Vellykket!'}
                  </div>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      `;

    case "warning-banner":
      return `
        <tr>
          <td style="padding: ${styles.margin || '16px 32px'};">
            <table width="100%" cellpadding="0" cellspacing="0" style="background: #FFF8E7; border: 1px solid #F0C36D; border-radius: 8px;">
              <tr>
                <td style="padding: 16px;">
                  <div style="font-family: ${BASE_FONT}; font-weight: 600; color: #8B6914;">
                    ⚠️ ${c.text || 'Obs!'}
                  </div>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      `;

    case "benefits-list":
      const items = (c.items as string[]) || [];
      const listItems = items.map((item: string) => `
        <tr>
          <td style="padding: 6px 0; font-family: ${BASE_FONT}; font-size: 16px; color: #5A5A5A;">
            <span style="color: #4CAF50; font-weight: bold; margin-right: 12px;">✓</span>
            ${item}
          </td>
        </tr>
      `).join('');
      return `
        <tr>
          <td style="padding: ${styles.margin || '16px 32px'};">
            <table width="100%" cellpadding="0" cellspacing="0" style="background: linear-gradient(135deg, #FAF7F2 0%, #F5EEE6 100%); border-radius: 12px;">
              <tr>
                <td style="padding: ${styles.padding || '24px'};">
                  ${c.title ? `<h3 style="margin: 0 0 16px 0; font-weight: 600; font-size: 18px; color: #8B7355; font-family: ${BASE_FONT};">${c.title}</h3>` : ''}
                  <table width="100%" cellpadding="0" cellspacing="0">
                    ${listItems}
                  </table>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      `;

    case "product-table":
      const headers = (c.headers as string[]) || ["Produkt", "Antall", "Pris"];
      const rows = (c.rows as string[][]) || [];
      const showTotal = c.showTotal !== false;
      const totalLabel = (c.totalLabel as string) || "Total";
      const totalValue = (c.totalValue as string) || "";

      const headerCells = headers.map((h: string, i: number) => `
        <th style="padding: 14px 16px; text-align: ${i === 0 ? 'left' : 'right'}; font-weight: 600; font-size: 14px; color: #FFFFFF; font-family: ${BASE_FONT}; ${i === 0 ? 'border-radius: 8px 0 0 0;' : ''} ${i === headers.length - 1 ? 'border-radius: 0 8px 0 0;' : ''}">
          ${h}
        </th>
      `).join('');
      
      const rowsHtml = rows.length === 0 
        ? `<tr><td colspan="${headers.length}" style="padding: 24px; text-align: center; color: #8B8B8B;">Ingen produkter</td></tr>`
        : rows.map((row: string[]) => `
            <tr>
              ${row.map((cell, i) => `
                <td style="padding: 14px 16px; text-align: ${i === 0 ? 'left' : 'right'}; border-bottom: 1px solid #E8E0D8; color: #4A4A4A; font-family: ${BASE_FONT};">
                  ${cell}
                </td>
              `).join('')}
            </tr>
          `).join('');

      const totalRow = showTotal && totalValue ? `
        <tr style="background: linear-gradient(135deg, #8B7355 0%, #6B5440 100%);">
          <td colspan="${headers.length - 1}" style="padding: 16px; color: #FFFFFF; font-weight: 600; border-radius: 0 0 0 8px; font-family: ${BASE_FONT};">${totalLabel}</td>
          <td style="padding: 16px; text-align: right; color: #FFFFFF; font-weight: 700; font-size: 18px; border-radius: 0 0 8px 0; font-family: ${BASE_FONT};">${totalValue}</td>
        </tr>
      ` : '';

      return `
        <tr>
          <td style="padding: ${styles.margin || '16px 32px'};">
            <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse: collapse;">
              <tr style="background: #8B7355;">${headerCells}</tr>
              ${rowsHtml}
              ${totalRow}
            </table>
          </td>
        </tr>
      `;

    case "note-box":
      return `
        <tr>
          <td style="padding: ${styles.margin || '16px 32px'};">
            <table width="100%" cellpadding="0" cellspacing="0" style="background: #F8F9FA; border-left: 4px solid #8B7355; border-radius: 0 8px 8px 0;">
              <tr>
                <td style="padding: 16px 20px;">
                  ${c.title ? `<p style="margin: 0 0 8px 0; font-weight: 600; color: #8B7355; font-size: 14px; font-family: ${BASE_FONT};">${c.icon || '💬'} ${c.title}</p>` : ''}
                  <p style="margin: 0; color: #5A5A5A; font-style: italic; font-family: ${BASE_FONT};">${c.content || ''}</p>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      `;

    case "footer-signature":
      const contact = c.contact as Record<string, string> | undefined;
      const footerBgColor = getBgColor(c, styles, '#FAF8F5');
      return `
        <tr>
          <td style="background-color: ${footerBgColor}; padding: ${styles.padding || '32px'}; text-align: center; border-top: 1px solid #E8E0D5;">
            <div style="font-family: ${BASE_FONT}; font-size: 16px; line-height: 1.6; color: #3D3D3D; margin-bottom: 16px;">
              ${c.signature || 'Med vennlig hilsen,<br><strong>Hår1-teamet</strong>'}
            </div>
            ${contact ? `
              <div style="font-size: 14px; color: #6B6B6B; font-family: ${BASE_FONT};">
                ${contact.phone ? `<p style="margin: 4px 0;">📞 ${contact.phone}</p>` : ''}
                ${contact.email ? `<p style="margin: 4px 0;">✉️ <a href="mailto:${contact.email}" style="color: #8B7355; text-decoration: none;">${contact.email}</a></p>` : ''}
                ${contact.website ? `<p style="margin: 4px 0;">🌐 ${contact.website}</p>` : ''}
              </div>
            ` : ''}
          </td>
        </tr>
      `;

    case "footer-disclaimer":
      return `
        <tr>
          <td style="font-size: 12px; color: #8B8B8B; padding: ${styles.padding || '16px 32px'}; text-align: center; font-family: ${BASE_FONT};">
            ${c.text || 'Denne e-posten er sendt fra Hår1.'}
          </td>
        </tr>
      `;

    case "separator":
      return `
        <tr>
          <td style="padding: ${styles.margin || '16px 32px'};">
            <hr style="border: none; border-top: 1px ${c.style || 'solid'} ${c.color || '#E8E0D5'}; margin: 0;" />
          </td>
        </tr>
      `;

    case "spacer":
      return `
        <tr>
          <td style="height: ${c.height || '24px'};"></td>
        </tr>
      `;

    case "image":
      const imageBgColor = getBgColor(c, styles, 'transparent');
      return `
        <tr>
          <td style="padding: ${styles.padding || '16px 32px'}; text-align: center; background-color: ${imageBgColor};">
            ${c.src 
              ? `<img src="${c.src}" alt="${c.alt || ''}" style="max-width: ${c.width || '100%'}; height: auto;" />`
              : ''
            }
          </td>
        </tr>
      `;

    case "two-columns":
      const left = c.left as Record<string, string> | undefined;
      const right = c.right as Record<string, string> | undefined;
      return `
        <tr>
          <td style="padding: ${styles.padding || '16px 32px'};">
            <table width="100%" cellpadding="0" cellspacing="0">
              <tr>
                <td width="50%" valign="top" style="padding-right: 8px; font-family: ${BASE_FONT};">
                  ${left?.content || ''}
                </td>
                <td width="50%" valign="top" style="padding-left: 8px; font-family: ${BASE_FONT};">
                  ${right?.content || ''}
                </td>
              </tr>
            </table>
          </td>
        </tr>
      `;

    case "three-columns":
      const colLeft = c.left as Record<string, string> | undefined;
      const colCenter = c.center as Record<string, string> | undefined;
      const colRight = c.right as Record<string, string> | undefined;
      return `
        <tr>
          <td style="padding: ${styles.padding || '16px 32px'};">
            <table width="100%" cellpadding="0" cellspacing="0">
              <tr>
                <td width="33.33%" valign="top" style="padding-right: 8px; font-family: ${BASE_FONT};">
                  ${colLeft?.content || ''}
                </td>
                <td width="33.33%" valign="top" style="padding: 0 8px; font-family: ${BASE_FONT};">
                  ${colCenter?.content || ''}
                </td>
                <td width="33.33%" valign="top" style="padding-left: 8px; font-family: ${BASE_FONT};">
                  ${colRight?.content || ''}
                </td>
              </tr>
            </table>
          </td>
        </tr>
      `;

    case "hero-image":
      return `
        <tr>
          <td style="text-align: center;">
            ${c.src 
              ? `<div style="position: relative;">
                  <img src="${c.src}" alt="${c.alt || ''}" style="width: 100%; height: auto; display: block;" />
                </div>`
              : `<div style="background: #8B7355; padding: 80px 32px; color: #FFFFFF; text-align: center;">
                  <h2 style="margin: 0 0 8px 0; font-size: 32px; font-weight: 700; font-family: ${BASE_FONT};">
                    ${c.overlayText || 'Din overskrift her'}
                  </h2>
                  ${c.overlaySubtext ? `<p style="margin: 0; font-size: 18px; font-family: ${BASE_FONT};">${c.overlaySubtext}</p>` : ''}
                </div>`
            }
          </td>
        </tr>
      `;

    case "salon-card":
      return `
        <tr>
          <td style="padding: ${styles.margin || '16px 32px'};">
            <table width="100%" cellpadding="0" cellspacing="0" style="background: linear-gradient(135deg, #FAF7F2 0%, #F5EEE6 100%); border-radius: 12px;">
              <tr>
                <td style="padding: 24px; text-align: center;">
                  ${c.showLogo ? `<div style="width: 80px; height: 80px; border-radius: 50%; background: #E8E0D8; margin: 0 auto 16px; line-height: 80px; font-size: 24px;">💇</div>` : ''}
                  ${c.showName !== false ? `<h3 style="margin: 0 0 8px 0; font-size: 20px; font-weight: 600; color: #8B7355; font-family: ${BASE_FONT};">${c.salonName || '{salongnavn}'}</h3>` : ''}
                  ${c.showHours ? `<p style="margin: 8px 0 0 0; font-size: 14px; color: #6B6B6B; font-family: ${BASE_FONT};">${c.hours || 'Man-Fre: 09:00 - 18:00'}</p>` : ''}
                  ${c.showAddress && c.address ? `<p style="margin: 8px 0 0 0; font-size: 14px; color: #6B6B6B; font-family: ${BASE_FONT};">${c.address}</p>` : ''}
                </td>
              </tr>
            </table>
          </td>
        </tr>
      `;

    case "campaign-price":
      return `
        <tr>
          <td style="padding: ${styles.margin || '16px 32px'};">
            <table width="100%" cellpadding="0" cellspacing="0" style="background: linear-gradient(135deg, #FEF3C7 0%, #FDE68A 100%); border-radius: 12px;">
              <tr>
                <td style="padding: 24px; text-align: center;">
                  <p style="margin: 0 0 12px 0; font-size: 18px; font-weight: 600; color: #78350F; font-family: ${BASE_FONT};">
                    ${c.productName || 'Behandling'}
                  </p>
                  <p style="margin: 0;">
                    <span style="font-size: 20px; color: #92400E; text-decoration: line-through; font-family: ${BASE_FONT};">kr ${c.originalPrice || '999'}</span>
                    <span style="margin-left: 16px; font-size: 32px; font-weight: 700; color: #78350F; font-family: ${BASE_FONT};">kr ${c.campaignPrice || '799'}</span>
                  </p>
                  ${c.savings ? `<p style="margin: 8px 0 0 0; font-size: 14px; color: #92400E; font-family: ${BASE_FONT};">Du sparer kr ${c.savings}!</p>` : ''}
                  ${c.validUntil ? `<p style="margin: 8px 0 0 0; font-size: 12px; color: #A16207; font-family: ${BASE_FONT};">Gyldig til ${c.validUntil}</p>` : ''}
                </td>
              </tr>
            </table>
          </td>
        </tr>
      `;

    case "treatment-list":
      const treatmentItems = (c.treatments as Array<{name: string; price: string}>) || [];
      const treatmentRows = treatmentItems.map(t => `
        <tr style="border-bottom: 1px solid #E8E0D8;">
          <td style="padding: 12px 0; font-family: ${BASE_FONT}; color: #3D3D3D;">${t.name}</td>
          <td style="padding: 12px 0; text-align: right; font-weight: 600; font-family: ${BASE_FONT}; color: #8B7355;">kr ${t.price}</td>
        </tr>
      `).join('');
      return `
        <tr>
          <td style="padding: ${styles.margin || '16px 32px'};">
            ${c.title ? `<h3 style="margin: 0 0 16px 0; font-size: 18px; font-weight: 600; color: #8B7355; font-family: ${BASE_FONT};">${c.title}</h3>` : ''}
            <table width="100%" cellpadding="0" cellspacing="0">
              ${treatmentRows}
            </table>
          </td>
        </tr>
      `;

    case "benefits-highlight":
      const benefitsItems = (c.benefits as Array<{icon: string; title: string; description: string}>) || [];
      const benefitsCells = benefitsItems.map(b => `
        <td style="padding: 16px; text-align: center; vertical-align: top;">
          <div style="font-size: 32px; margin-bottom: 8px;">${b.icon}</div>
          <h4 style="margin: 0 0 4px 0; font-size: 16px; font-weight: 600; color: #3D3D3D; font-family: ${BASE_FONT};">${b.title}</h4>
          <p style="margin: 0; font-size: 14px; color: #6B6B6B; font-family: ${BASE_FONT};">${b.description}</p>
        </td>
      `).join('');
      return `
        <tr>
          <td style="padding: ${styles.margin || '16px 32px'};">
            <table width="100%" cellpadding="0" cellspacing="0" style="background: linear-gradient(135deg, #FAF7F2 0%, #F5EEE6 100%); border-radius: 12px;">
              <tr>
                <td style="padding: 24px;">
                  ${c.title ? `<h3 style="margin: 0 0 20px 0; font-size: 18px; font-weight: 600; color: #8B7355; text-align: center; font-family: ${BASE_FONT};">${c.title}</h3>` : ''}
                  <table width="100%" cellpadding="0" cellspacing="0">
                    <tr>${benefitsCells}</tr>
                  </table>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      `;

    case "event-card":
      return `
        <tr>
          <td style="padding: ${styles.margin || '16px 32px'};">
            <table width="100%" cellpadding="0" cellspacing="0" style="background: #FFFFFF; border: 1px solid #E8E0D8; border-radius: 12px; overflow: hidden;">
              <tr>
                <td style="background: #8B7355; padding: 16px; color: #FFFFFF; text-align: center;">
                  <p style="margin: 0; font-size: 14px; font-weight: 500; font-family: ${BASE_FONT};">${c.title || 'Kommende kurs'}</p>
                </td>
              </tr>
              <tr>
                <td style="padding: 24px; text-align: center;">
                  <h3 style="margin: 0 0 16px 0; font-size: 22px; font-weight: 600; color: #3D3D3D; font-family: ${BASE_FONT};">${c.eventName || 'Arrangementnavn'}</h3>
                  <p style="margin: 0 0 8px 0; font-size: 16px; color: #8B7355; font-family: ${BASE_FONT};">📅 ${c.date || 'Dato'} • ⏰ ${c.time || 'Tid'}</p>
                  ${c.location ? `<p style="margin: 0 0 16px 0; font-size: 14px; color: #6B6B6B; font-family: ${BASE_FONT};">📍 ${c.location}</p>` : ''}
                  ${c.ctaText ? `<a href="${c.ctaUrl || '#'}" style="display: inline-block; padding: 12px 24px; background: linear-gradient(135deg, #8B7355 0%, #6B5440 100%); color: #FFFFFF; text-decoration: none; border-radius: 8px; font-weight: 600; font-size: 14px; font-family: ${BASE_FONT};">${c.ctaText}</a>` : ''}
                </td>
              </tr>
            </table>
          </td>
        </tr>
      `;

    case "campaign-banner":
      const cmpBgColor = c.backgroundColor || '#8B7355';
      const cmpTextColor = c.textColor || '#FFFFFF';
      return `
        <tr>
          <td style="padding: ${styles.margin || '16px 32px'};">
            <table width="100%" cellpadding="0" cellspacing="0" style="background: ${cmpBgColor}; border-radius: 12px;">
              <tr>
                <td style="padding: 32px; text-align: center;">
                  <h2 style="margin: 0 0 8px 0; font-size: 28px; font-weight: 700; color: ${cmpTextColor}; font-family: ${BASE_FONT};">${c.title || 'Kampanjetittel'}</h2>
                  ${c.subtitle ? `<p style="margin: 0 0 16px 0; font-size: 18px; color: ${cmpTextColor}; opacity: 0.9; font-family: ${BASE_FONT};">${c.subtitle}</p>` : ''}
                  ${c.ctaText ? `<a href="${c.ctaUrl || '#'}" style="display: inline-block; padding: 12px 28px; background: #FFFFFF; color: ${cmpBgColor}; text-decoration: none; border-radius: 8px; font-weight: 600; font-size: 16px; font-family: ${BASE_FONT};">${c.ctaText}</a>` : ''}
                </td>
              </tr>
            </table>
          </td>
        </tr>
      `;

    case "otp-box":
      return `
        <tr>
          <td style="padding: ${styles.padding || '24px 32px'}; text-align: center;">
            <table cellpadding="0" cellspacing="0" style="margin: 0 auto; background: linear-gradient(135deg, #FAF7F2 0%, #F5EEE6 100%); border-radius: 12px;">
              <tr>
                <td style="padding: 24px 32px;">
                  <p style="margin: 0 0 8px 0; font-size: 14px; color: #8B7355; text-transform: uppercase; letter-spacing: 0.5px; font-family: ${BASE_FONT};">
                    ${c.label || 'Din engangskode'}
                  </p>
                  <p style="margin: 0; font-size: 32px; font-weight: 700; letter-spacing: 8px; color: #3D3D3D; font-family: monospace;">
                    ${c.code || '123456'}
                  </p>
                  <p style="margin: 12px 0 0 0; font-size: 12px; color: #8B8B8B; font-family: ${BASE_FONT};">
                    Koden utløper om ${c.expiryMinutes || 10} minutter
                  </p>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      `;

    case "agreement-box":
      return `
        <tr>
          <td style="padding: ${styles.padding || '24px 32px'}; text-align: center;">
            <table cellpadding="0" cellspacing="0" style="margin: 0 auto; background-color: #FAFAFA; border-radius: 16px; border: 2px dashed #D1D5DB;">
              <tr>
                <td style="padding: 32px 48px;">
                  <p style="margin: 0 0 16px 0; font-size: 14px; color: #6B7280; text-transform: uppercase; letter-spacing: 0.5px; font-family: ${BASE_FONT};">
                    ${c.label || 'DITT AVTALENUMMER (BRUK VED REGISTRERING)'}
                  </p>
                  <p style="margin: 0; font-size: 42px; font-weight: 700; letter-spacing: 4px; color: #374151; font-family: monospace;">
                    ${c.value || ''}
                  </p>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      `;

    case "agreement-box":
      return `
        <tr>
          <td style="padding: ${styles.padding || '16px 32px'};">
            <table width="100%" cellpadding="0" cellspacing="0" style="background: #F8F9FA; border: 2px dashed #E5E7EB; border-radius: 12px;">
              <tr>
                <td style="padding: 24px; text-align: center;">
                  <p style="margin: 0 0 8px 0; font-size: 13px; color: #6B7280; text-transform: uppercase; letter-spacing: 1px; font-family: ${BASE_FONT};">${c.label || 'Avtalenummer'}</p>
                  <p style="margin: 0; font-size: 32px; font-weight: 700; color: #3D3D3D; font-family: monospace; letter-spacing: 2px;">${c.value || ''}</p>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      `;

    case "date-highlight":
      return `
        <tr>
          <td style="padding: ${styles.margin || '16px 32px'};">
            <table width="100%" cellpadding="0" cellspacing="0" style="background: linear-gradient(135deg, #FEF3C7 0%, #FDE68A 100%); border-radius: 12px;">
              <tr>
                <td style="padding: 20px; text-align: center;">
                  <p style="margin: 0 0 4px 0; font-size: 14px; color: #92400E; font-weight: 500; font-family: ${BASE_FONT};">${c.label || ''}</p>
                  <p style="margin: 0; font-size: 24px; font-weight: 700; color: #78350F; font-family: ${BASE_FONT};">${c.date || ''}</p>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      `;

    case "contact-box":
      return `
        <tr>
          <td style="padding: ${styles.padding || '24px 32px'};">
            <table width="100%" cellpadding="0" cellspacing="0" style="border-top: 1px solid #E5E7EB;">
              <tr>
                <td style="padding-top: 24px;">
                  <p style="margin: 0 0 8px 0; font-size: 16px; color: #8B7355; font-weight: 600; font-family: ${BASE_FONT};">
                    💬 ${c.title || 'Spørsmål om helseforsikringen?'}
                  </p>
                  <p style="margin: 0; font-size: 16px; color: #3D3D3D; font-family: ${BASE_FONT};">
                    ${c.description || 'Kontakt ERGO på'} <strong>${c.phone || '800 83 313'}</strong> eller <a href="mailto:${c.email || 'infohelse@ergo.no'}" style="color: #8B7355;">${c.email || 'infohelse@ergo.no'}</a>
                  </p>
                </td>
              </tr>
            </table>
          </td>
        </tr>
      `;

    case "salon-info":
      return `
        <tr>
          <td style="padding: ${styles.margin || '16px 32px'};">
            <table width="100%" cellpadding="0" cellspacing="0" style="background: #FAF7F2; border-radius: 8px;">
              <tr>
                <td style="padding: 20px;">
                  ${c.salonName ? `<p style="margin: 0 0 8px 0; font-family: ${BASE_FONT};"><strong>Salongnavn:</strong> ${c.salonName}</p>` : ''}
                  ${c.orgNumber ? `<p style="margin: 0 0 8px 0; font-family: ${BASE_FONT};"><strong>Org.nummer:</strong> ${c.orgNumber}</p>` : ''}
                  ${c.contactName ? `<p style="margin: 0 0 8px 0; font-family: ${BASE_FONT};"><strong>Kontaktperson:</strong> ${c.contactName}</p>` : ''}
                  ${c.email ? `<p style="margin: 0 0 8px 0; font-family: ${BASE_FONT};"><strong>E-post:</strong> ${c.email}</p>` : ''}
                  ${c.phone ? `<p style="margin: 0; font-family: ${BASE_FONT};"><strong>Telefon:</strong> ${c.phone}</p>` : ''}
                </td>
              </tr>
            </table>
          </td>
        </tr>
      `;

    default:
      return '';
  }
}

// Replace tokens in text with variable values
export function replaceTokens(text: string, variables: Record<string, string>): string {
  let result = text;
  for (const [key, value] of Object.entries(variables)) {
    const token = `{${key}}`;
    result = result.replace(new RegExp(token.replace(/[{}]/g, '\\$&'), 'g'), value || '');
  }
  return result;
}

// Generate full email HTML
export function generateEmailHtml(structure: EmailStructure, variables: Record<string, string> = {}): string {
  const modulesHtml = structure.modules.map(m => generateModuleHtml(m, variables)).join('');
  
  const globalStyles = structure.globalStyles || {};
  const bgColor = globalStyles.backgroundColor || '#FAF8F5';
  const contentBgColor = globalStyles.contentBackgroundColor || globalStyles.backgroundColor || '#FFFFFF';
  const fontFamily = globalStyles.fontFamily || "'DM Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif";
  
  // Determine if this is a dark theme based on background color
  const isDarkTheme = bgColor.toLowerCase().includes('1a1a1a') || bgColor.toLowerCase().includes('333') || bgColor.toLowerCase().includes('000');
  const shadowColor = isDarkTheme ? 'rgba(0, 0, 0, 0.3)' : 'rgba(139, 115, 85, 0.08)';
  
  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>E-post</title>
</head>
<body style="margin: 0; padding: 0; background-color: ${bgColor}; font-family: ${fontFamily};">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: ${bgColor};">
    <tr>
      <td align="center" style="padding: 20px;">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: ${contentBgColor}; max-width: 600px; border-radius: 16px; box-shadow: 0 4px 24px ${shadowColor};">
          ${modulesHtml || '<tr><td style="padding: 48px; text-align: center; color: #8B8B8B;">Ingen innhold</td></tr>'}
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
  `;
}
