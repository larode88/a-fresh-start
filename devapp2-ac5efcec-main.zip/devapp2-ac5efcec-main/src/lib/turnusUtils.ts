// Turnus Utilities
// Beregningsfunksjoner for turnusplanlegging i frisørsalonger

import { format, getISOWeek, startOfISOWeek, addWeeks, addDays } from 'date-fns';

// Importer sentraliserte types og funksjoner fra dateUtils
import { 
  beregnUkeType as beregnUkeTypeFraDateUtils, 
  UkeType, 
  TurnusType 
} from './dateUtils';

// Re-eksporter for bakoverkompatibilitet
export type { UkeType, TurnusType };
export const beregnUkeType = beregnUkeTypeFraDateUtils;
export type BemanningStatus = 'closed' | 'kritisk' | 'under' | 'ok' | 'over';

export interface ApningstidResult {
  stengt: boolean;
  apner?: string;
  stenger?: string;
  min_bemanning?: number;
  ideell_bemanning?: number;
}

export interface TurnusPreferanse {
  id: string;
  user_id: string;
  salon_id: string;
  ukedag: number;
  uke_type: UkeType | null;
  turnus_type: TurnusType | null;
  jobber: boolean;
  onsket_start_tid: string | null;
  onsket_slutt_tid: string | null;
  prioritet: number;
  gyldig_fra: string;
  gyldig_til: string | null;
  kommentar: string | null;
}

// SkiftData interface - støtter både legacy (ansatt_turnus) og ny (turnus_skift) struktur
export interface SkiftData {
  id: string;
  ansatt_id?: string | null;
  user_id?: string | null;
  salon_id: string;
  dato: string; // turnus_skift bruker dato
  start_tid: string | null;
  slutt_tid: string | null;
  timer_planlagt?: number | null;
  kilde?: 'turnus' | 'manuell' | 'bytte' | 'ferie' | 'fravaer' | null;
  notat?: string | null;
  // Legacy fields for backward compatibility
  ukedag?: number;
  pause_minutter?: number;
  fridag?: boolean;
  gyldig_fra?: string;
  gyldig_til?: string | null;
  laast?: boolean;
  helligdag_opplaast?: boolean;
  merknad?: string | null;
}

export interface BemanningForslag {
  type: 'kritisk' | 'undermanning' | 'overbemanning' | 'ok';
  prioritet: 'kritisk' | 'hoy' | 'medium' | 'lav';
  ukedag: number;
  time: number;
  bemanning: number;
  krav: number;
  melding: string;
  forslag?: string;
}

// ============================================
// UKE-TYPE BEREGNING (re-eksportert fra dateUtils.ts)
// ============================================

/**
 * Returnerer lesbar label for uke-type
 */
export function getUkeTypeLabel(ukeType: UkeType): string {
  const labels: Record<UkeType, string> = {
    alle: 'Alle uker',
    partall: 'Partallsuke',
    oddetall: 'Oddetallsuke',
    uke1: 'Uke 1',
    uke2: 'Uke 2',
    uke3: 'Uke 3',
  };
  return labels[ukeType];
}

/**
 * Returnerer lesbar label for turnus-type
 */
export function getTurnusTypeLabel(turnusType: TurnusType): string {
  const labels: Record<TurnusType, string> = {
    enkel: 'Enkel (samme hver uke)',
    touke: '2-ukers rotasjon',
    treuke: '3-ukers rotasjon',
  };
  return labels[turnusType];
}

// ============================================
// STILLINGSPROSENT-BEREGNING FRA TURNUS
// ============================================

export const FULL_STILLING_TIMER = 37.5;
export const ARSVERK_TIMER = 1695; // Norsk standard årsverk (52 uker - 5 ferie - ~10 helligdager)
export const ARBEIDSUKER_UTEN_FERIE = 47;
export const HELLIGDAGER_PER_AAR = 10;
export const DEFAULT_PAUSE_MINUTTER = 30;

export interface WeekPreference {
  ukedag: number;
  jobber: boolean;
  onsket_start_tid: string | null;
  onsket_slutt_tid: string | null;
}

export interface UkeDetalj {
  ukeType: string;
  timer: number;
  prosent: number;
}

export interface TurnusBeregningResultat {
  gjennomsnittTimer: number;
  stillingsprosent: number;
  ukerDetaljer: UkeDetalj[];
  turnusType: TurnusType;
}

/**
 * Beregner timer for én uke basert på preferanser
 * Trekker fra 30 min pause per arbeidsdag (Arbeidsmiljøloven)
 */
export function beregnTimerForUke(preferanser: WeekPreference[]): { timer: number; prosent: number } {
  let totalMinutter = 0;

  for (const pref of preferanser) {
    if (pref.jobber && pref.onsket_start_tid && pref.onsket_slutt_tid) {
      const [startH, startM] = pref.onsket_start_tid.split(':').map(Number);
      const [sluttH, sluttM] = pref.onsket_slutt_tid.split(':').map(Number);

      let minutter = (sluttH * 60 + sluttM) - (startH * 60 + startM);

      // Håndter nattskift (over midnatt)
      if (minutter < 0) {
        minutter += 24 * 60;
      }

      // Trekk fra 30 min pause for arbeidsdager over 5.5 timer
      if (minutter > 330) {
        minutter -= DEFAULT_PAUSE_MINUTTER;
      }

      totalMinutter += Math.max(0, minutter);
    }
  }

  const timer = totalMinutter / 60;
  const prosent = (timer / FULL_STILLING_TIMER) * 100;

  return { 
    timer: Math.round(timer * 10) / 10, 
    prosent: Math.round(prosent * 10) / 10 
  };
}

/**
 * Beregner gjennomsnittlig stillingsprosent for hele turnusrotasjonen
 */
export function beregnGjennomsnittTurnus(
  turnusType: TurnusType,
  preferanserPerUke: Record<string, WeekPreference[]>
): TurnusBeregningResultat {
  const ukerDetaljer: UkeDetalj[] = [];
  let totalTimer = 0;
  let antallUker = 0;

  if (turnusType === 'enkel') {
    const allePreferanser = preferanserPerUke['alle'] || [];
    const { timer, prosent } = beregnTimerForUke(allePreferanser);
    ukerDetaljer.push({ ukeType: 'alle', timer, prosent });
    totalTimer = timer;
    antallUker = 1;
  } else if (turnusType === 'touke') {
    const partallPref = preferanserPerUke['partall'] || [];
    const oddetallPref = preferanserPerUke['oddetall'] || [];
    
    const partall = beregnTimerForUke(partallPref);
    const oddetall = beregnTimerForUke(oddetallPref);
    
    ukerDetaljer.push({ ukeType: 'partall', timer: partall.timer, prosent: partall.prosent });
    ukerDetaljer.push({ ukeType: 'oddetall', timer: oddetall.timer, prosent: oddetall.prosent });
    
    totalTimer = partall.timer + oddetall.timer;
    antallUker = 2;
  } else if (turnusType === 'treuke') {
    const uke1Pref = preferanserPerUke['uke1'] || [];
    const uke2Pref = preferanserPerUke['uke2'] || [];
    const uke3Pref = preferanserPerUke['uke3'] || [];
    
    const uke1 = beregnTimerForUke(uke1Pref);
    const uke2 = beregnTimerForUke(uke2Pref);
    const uke3 = beregnTimerForUke(uke3Pref);
    
    ukerDetaljer.push({ ukeType: 'uke1', timer: uke1.timer, prosent: uke1.prosent });
    ukerDetaljer.push({ ukeType: 'uke2', timer: uke2.timer, prosent: uke2.prosent });
    ukerDetaljer.push({ ukeType: 'uke3', timer: uke3.timer, prosent: uke3.prosent });
    
    totalTimer = uke1.timer + uke2.timer + uke3.timer;
    antallUker = 3;
  }

  const gjennomsnittTimer = antallUker > 0 ? totalTimer / antallUker : 0;
  const stillingsprosent = (gjennomsnittTimer / FULL_STILLING_TIMER) * 100;

  return {
    gjennomsnittTimer: Math.round(gjennomsnittTimer * 10) / 10,
    stillingsprosent: Math.round(stillingsprosent * 10) / 10,
    ukerDetaljer,
    turnusType
  };
}

// ============================================
// TIMER-BEREGNING
// ============================================

/**
 * Beregner antall arbeidstimer fra start/slutt-tid minus pause
 */
export function beregnTimerFraTid(
  startTid: string | null,
  sluttTid: string | null,
  pauseMinutter: number = 30
): number {
  if (!startTid || !sluttTid) return 0;

  const [startH, startM] = startTid.split(':').map(Number);
  const [sluttH, sluttM] = sluttTid.split(':').map(Number);

  const startMinutter = startH * 60 + startM;
  const sluttMinutter = sluttH * 60 + sluttM;

  // Trekk fra pause for skift over 5.5 timer (Arbeidsmiljøloven)
  const bruttoMinutter = sluttMinutter - startMinutter;
  const effektivPause = bruttoMinutter > 330 ? pauseMinutter : 0;

  return Math.max(0, (bruttoMinutter - effektivPause) / 60);
}

/**
 * Formatterer timer til lesbar streng
 */
export function formaterTimer(timer: number): string {
  if (timer === 0) return '0t';
  const hele = Math.floor(timer);
  const minutter = Math.round((timer - hele) * 60);
  if (minutter === 0) return `${hele}t`;
  return `${hele}t ${minutter}m`;
}

// ============================================
// BEMANNING-ANALYSE
// ============================================

/**
 * Sjekker om en ansatt jobber på et gitt tidspunkt
 */
export function erPaaJobb(
  skift: SkiftData,
  time: number
): boolean {
  if (skift.fridag || !skift.start_tid || !skift.slutt_tid) return false;

  const [startH] = skift.start_tid.split(':').map(Number);
  const [sluttH] = skift.slutt_tid.split(':').map(Number);

  return time >= startH && time < sluttH;
}

/**
 * Teller antall ansatte på jobb for en gitt time
 */
export function tellBemanning(
  skiftListe: SkiftData[],
  ukedag: number,
  time: number
): number {
  return skiftListe.filter(skift => 
    skift.ukedag === ukedag && erPaaJobb(skift, time)
  ).length;
}

/**
 * Returnerer bemanning-status basert på antall vs. krav
 */
export function getBemanningStatus(
  bemanning: number,
  minBemanning: number,
  ideellBemanning: number,
  stengt: boolean
): BemanningStatus {
  if (stengt) return 'closed';
  if (bemanning === 0) return 'kritisk';
  if (bemanning < minBemanning) return 'under';
  if (bemanning > ideellBemanning) return 'over';
  return 'ok';
}

/**
 * Returnerer CSS-klasse for bemanning-status
 */
export function getBemanningStatusColor(status: BemanningStatus): string {
  const colors: Record<BemanningStatus, string> = {
    closed: 'bg-muted text-muted-foreground',
    kritisk: 'bg-destructive/20 text-destructive',
    under: 'bg-yellow-500/20 text-yellow-700 dark:text-yellow-400',
    ok: 'bg-green-500/20 text-green-700 dark:text-green-400',
    over: 'bg-blue-500/20 text-blue-700 dark:text-blue-400',
  };
  return colors[status];
}

/**
 * Analyserer bemanning for en hel uke og returnerer forslag
 */
export function analyserUkeBemanning(
  apningstider: Array<{ ukedag: number; stengt: boolean; apner?: string; stenger?: string; min_bemanning?: number; ideell_bemanning?: number }>,
  skiftListe: SkiftData[]
): BemanningForslag[] {
  const forslag: BemanningForslag[] = [];

  for (let ukedag = 1; ukedag <= 7; ukedag++) {
    const apning = apningstider.find(a => a.ukedag === ukedag);
    if (!apning || apning.stengt) continue;

    const apnerTime = parseInt(apning.apner?.split(':')[0] || '9');
    const stengerTime = parseInt(apning.stenger?.split(':')[0] || '17');
    const minBemanning = apning.min_bemanning ?? 2;
    const ideellBemanning = apning.ideell_bemanning ?? 3;

    for (let time = apnerTime; time < stengerTime; time++) {
      const bemanning = tellBemanning(skiftListe, ukedag, time);

      if (bemanning === 0) {
        forslag.push({
          type: 'kritisk',
          prioritet: 'kritisk',
          ukedag,
          time,
          bemanning,
          krav: minBemanning,
          melding: `Ingen ansatte kl. ${time}:00`,
          forslag: 'Juster starttid for en ansatt eller legg til nytt skift',
        });
      } else if (bemanning < minBemanning) {
        forslag.push({
          type: 'undermanning',
          prioritet: 'hoy',
          ukedag,
          time,
          bemanning,
          krav: minBemanning,
          melding: `Undermanning: ${bemanning}/${minBemanning} ansatte kl. ${time}:00`,
          forslag: 'Utvid skift eller legg til flere ansatte',
        });
      } else if (bemanning > ideellBemanning) {
        forslag.push({
          type: 'overbemanning',
          prioritet: 'lav',
          ukedag,
          time,
          bemanning,
          krav: ideellBemanning,
          melding: `Overbemanning: ${bemanning}/${ideellBemanning} ansatte kl. ${time}:00`,
          forslag: 'Vurder å korte ned skift eller gi fridager',
        });
      }
    }
  }

  // Sorter etter prioritet
  const prioritetRekkefolge = { kritisk: 0, hoy: 1, medium: 2, lav: 3 };
  return forslag.sort((a, b) => prioritetRekkefolge[a.prioritet] - prioritetRekkefolge[b.prioritet]);
}

// ============================================
// UKEDAG-HJELPERE
// ============================================

export const UKEDAGER = [
  { nummer: 1, kort: 'Man', lang: 'Mandag' },
  { nummer: 2, kort: 'Tir', lang: 'Tirsdag' },
  { nummer: 3, kort: 'Ons', lang: 'Onsdag' },
  { nummer: 4, kort: 'Tor', lang: 'Torsdag' },
  { nummer: 5, kort: 'Fre', lang: 'Fredag' },
  { nummer: 6, kort: 'Lør', lang: 'Lørdag' },
  { nummer: 7, kort: 'Søn', lang: 'Søndag' },
];

/**
 * Konverterer JS Date.getDay() (0=søndag) til ISO ukedag (1=mandag, 7=søndag)
 */
export function getISOUkedag(dato: Date): number {
  const jsDay = dato.getDay();
  return jsDay === 0 ? 7 : jsDay;
}

/**
 * Returnerer ukedag-navn fra nummer
 */
export function getUkedagNavn(ukedag: number, kort: boolean = false): string {
  const dag = UKEDAGER.find(d => d.nummer === ukedag);
  return kort ? dag?.kort || '' : dag?.lang || '';
}

// ============================================
// DATO-HJELPERE FOR UKE-NAVIGERING
// ============================================

/**
 * Henter start av ISO-uke for en dato
 */
export function getUkeStart(dato: Date): Date {
  return startOfISOWeek(dato);
}

/**
 * Henter alle datoer i en uke
 */
export function getUkeDatoer(ukeStart: Date): Date[] {
  return Array.from({ length: 7 }, (_, i) => addDays(ukeStart, i));
}

/**
 * Formatterer ukenummer og år
 */
export function formaterUke(dato: Date): string {
  const uke = getISOWeek(dato);
  const år = dato.getFullYear();
  return `Uke ${uke}, ${år}`;
}

// ============================================
// SKIFT-GENERERING
// ============================================

export interface GenererSkiftParams {
  userId: string;
  salonId: string;
  preferanser: TurnusPreferanse[];
  fraOgMedDato: Date;
  antallUkerFremover?: number;
  apningstider: Array<{ ukedag: number; stengt: boolean }>;
}

/**
 * Genererer skift-data fra turnusmaler for batch-insert
 */
export function genererSkiftFraMaler(params: GenererSkiftParams): Omit<SkiftData, 'id'>[] {
  const {
    userId,
    salonId,
    preferanser,
    fraOgMedDato,
    antallUkerFremover = 52,
    apningstider,
  } = params;

  if (!preferanser.length) return [];

  // Finn turnus-type fra første preferanse
  const turnusType = preferanser[0].turnus_type || 'touke';
  const gyldigFra = new Date(preferanser[0].gyldig_fra);

  const skiftListe: Omit<SkiftData, 'id'>[] = [];

  for (let ukeOffset = 0; ukeOffset < antallUkerFremover; ukeOffset++) {
    const ukeStart = startOfISOWeek(addWeeks(fraOgMedDato, ukeOffset));
    const ukeType = beregnUkeType(ukeStart, gyldigFra, turnusType);

    for (let dagOffset = 0; dagOffset < 7; dagOffset++) {
      const dagDato = addDays(ukeStart, dagOffset);
      const ukedag = dagOffset + 1; // 1=mandag

      // Sjekk om salongen er åpen
      const apning = apningstider.find(a => a.ukedag === ukedag);
      if (!apning || apning.stengt) continue;

      // Finn matching preferanse
      const preferanse = preferanser.find(p =>
        p.ukedag === ukedag && p.uke_type === ukeType
      );

      if (!preferanse || !preferanse.jobber) continue;

      const datoStr = format(dagDato, 'yyyy-MM-dd');
      skiftListe.push({
        user_id: userId,
        salon_id: salonId,
        dato: datoStr,
        ukedag,
        start_tid: preferanse.onsket_start_tid,
        slutt_tid: preferanse.onsket_slutt_tid,
        pause_minutter: 30,
        fridag: false,
        gyldig_fra: datoStr,
        gyldig_til: null,
        laast: false,
        helligdag_opplaast: false,
        merknad: null,
      });
    }
  }

  return skiftListe;
}
