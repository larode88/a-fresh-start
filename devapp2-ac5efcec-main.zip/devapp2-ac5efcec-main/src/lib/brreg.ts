export interface BrregResult {
  organisasjonsnummer: string;
  juridiskNavn: string;
  stiftelsesdato?: string;
  antallAnsatte?: number;
  adresse?: {
    gate: string;
    postnummer: string;
    poststed: string;
  };
}

export interface FinansiellResult {
  sumDriftsinntekter?: number;
  sumDriftskostnad?: number;
  driftsresultat?: number;
  regnskapsaar?: number;
}

interface BrregApiResponse {
  organisasjonsnummer: string;
  navn: string;
  stiftelsesdato?: string;
  antallAnsatte?: number;
  forretningsadresse?: {
    adresse?: string[];
    postnummer?: string;
    poststed?: string;
  };
}

interface RegnskapsregisteretResponse {
  regnskapsperiode?: {
    fraDato?: string;
    tilDato?: string;
  };
  resultatregnskapResultat?: {
    driftsinntekter?: {
      sumDriftsinntekter?: number;
      salgsinntekter?: number;
    };
    driftskostnad?: {
      loennskostnad?: number;
    };
    driftsresultat?: {
      driftsresultat?: number;
    };
  };
}

export async function lookupOrgNumber(orgNumber: string): Promise<BrregResult> {
  // Validate format
  const cleanedOrgNumber = orgNumber.replace(/\s/g, '');
  if (!/^\d{9}$/.test(cleanedOrgNumber)) {
    throw new Error('Org.nummer må være 9 siffer');
  }

  const response = await fetch(
    `https://data.brreg.no/enhetsregisteret/api/enheter/${cleanedOrgNumber}`
  );

  if (response.status === 404) {
    throw new Error('Org.nummer ikke funnet i Brønnøysundregistrene');
  }

  if (!response.ok) {
    throw new Error('Kunne ikke koble til Brønnøysundregistrene. Prøv igjen.');
  }

  const data: BrregApiResponse = await response.json();

  return {
    organisasjonsnummer: data.organisasjonsnummer,
    juridiskNavn: data.navn,
    stiftelsesdato: data.stiftelsesdato,
    antallAnsatte: data.antallAnsatte,
    adresse: data.forretningsadresse ? {
      gate: data.forretningsadresse.adresse?.[0] || '',
      postnummer: data.forretningsadresse.postnummer || '',
      poststed: data.forretningsadresse.poststed || '',
    } : undefined,
  };
}

export async function lookupFinancials(orgNumber: string): Promise<FinansiellResult | null> {
  const cleanedOrgNumber = orgNumber.replace(/\s/g, '');
  if (!/^\d{9}$/.test(cleanedOrgNumber)) {
    return null;
  }

  try {
    // Import supabase client dynamically to avoid circular dependencies
    const { supabase } = await import('@/integrations/supabase/client');
    
    const { data, error } = await supabase.functions.invoke('brreg-regnskapsdata', {
      body: { orgNumber: cleanedOrgNumber }
    });

    if (error) {
      console.error('Error calling brreg-regnskapsdata:', error);
      return null;
    }

    return data?.data || null;
  } catch (error) {
    console.error('Error fetching financials:', error);
    return null;
  }
}

export function formatCurrency(value: number | undefined | null): string {
  if (value === undefined || value === null) return '-';
  if (Math.abs(value) >= 1000000) {
    return `${(value / 1000000).toFixed(1)}M`;
  }
  if (Math.abs(value) >= 1000) {
    return `${(value / 1000).toFixed(0)}k`;
  }
  return value.toLocaleString('nb-NO');
}
