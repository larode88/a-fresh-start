// Pulsundersøkelse utilities og typer

export type PulsTema = 
  | 'trivsel' 
  | 'arbeidsbelastning' 
  | 'psykologisk_trygghet' 
  | 'ledelse' 
  | 'hms_sikkerhet' 
  | 'utvikling';

export type PulsType = 'hurtigpuls' | 'dyppuls';
export type SporsmalType = 'skala' | 'fritekst';

export interface PulsSporsmal {
  id: string;
  tema: PulsTema;
  sporsmal: string;
  sporsmal_type: SporsmalType;
  moduler: PulsType[];
  aktiv: boolean;
  sort_order: number;
}

export interface PulsSvar {
  id?: string;
  stemning: number;
  energi: number;
  mestring: number;
  dato: string;
  user_id: string;
  tema?: PulsTema;
  sporsmal_id?: string;
  puls_type?: PulsType;
  risiko_flagg?: boolean;
}

export interface PulsRisiko {
  id: string;
  salon_id: string;
  svar_id?: string;
  user_id?: string;
  tema: PulsTema;
  sporsmal_id?: string;
  score: number;
  foreslatte_tiltak: string[];
  status: 'ny' | 'under_behandling' | 'lukket';
  behandlet_av?: string;
  behandlet_dato?: string;
  kommentar?: string;
  created_at: string;
}

export interface TemaStats {
  tema: PulsTema;
  avg: number;
  trend: number;
  antallSvar: number;
  risikoCount: number;
}

// Tema-farger og ikoner
export const TEMA_CONFIG: Record<PulsTema, { 
  label: string; 
  icon: string; 
  color: string;
  bgColor: string;
}> = {
  trivsel: { 
    label: 'Trivsel', 
    icon: '😊', 
    color: 'text-green-600',
    bgColor: 'bg-green-50'
  },
  arbeidsbelastning: { 
    label: 'Arbeidsbelastning', 
    icon: '⚡', 
    color: 'text-amber-600',
    bgColor: 'bg-amber-50'
  },
  psykologisk_trygghet: { 
    label: 'Psykologisk trygghet', 
    icon: '🛡️', 
    color: 'text-blue-600',
    bgColor: 'bg-blue-50'
  },
  ledelse: { 
    label: 'Ledelse', 
    icon: '👔', 
    color: 'text-purple-600',
    bgColor: 'bg-purple-50'
  },
  hms_sikkerhet: { 
    label: 'HMS/Sikkerhet', 
    icon: '🦺', 
    color: 'text-red-600',
    bgColor: 'bg-red-50'
  },
  utvikling: { 
    label: 'Utvikling', 
    icon: '🎯', 
    color: 'text-teal-600',
    bgColor: 'bg-teal-50'
  },
};

// Fargekoding basert på score (1-5)
export function getScoreColor(score: number): string {
  if (score >= 4) return 'text-green-500';
  if (score >= 3) return 'text-yellow-500';
  return 'text-red-500';
}

export function getScoreBgColor(score: number): string {
  if (score >= 4) return 'bg-green-500/10';
  if (score >= 3) return 'bg-yellow-500/10';
  return 'bg-red-500/10';
}

export function getScoreLabel(score: number): string {
  if (score >= 4) return 'Bra';
  if (score >= 3) return 'Ok';
  return 'Lav';
}

// Sjekk om score utløser risikoflagg
export function isRiskScore(score: number): boolean {
  return score <= 2;
}

// Generer foreslåtte tiltak basert på tema
export function getForeslatteTiltak(tema: PulsTema): string[] {
  const tiltak: Record<PulsTema, string[]> = {
    arbeidsbelastning: [
      'Vurder avlastning eller omfordeling av oppgaver',
      'Gjennomgå prioriteringer med leder',
      'Vurder behov for ekstra bemanning',
      'Tilby fleksitid eller hjemmekontor'
    ],
    psykologisk_trygghet: [
      'Planlegg en-til-en samtale',
      'Avklar forventninger tydelig',
      'Tilby støtte og veiledning',
      'Skap trygge rom for tilbakemelding'
    ],
    hms_sikkerhet: [
      'Gjennomfør utstyrskontroll',
      'Vurder pausefrekvens og rutiner',
      'Gjennomgå ergonomiske tilpasninger',
      'Oppdater HMS-rutiner'
    ],
    ledelse: [
      'Planlegg regelmessig oppfølging',
      'Forbedre kommunikasjonsrutiner',
      'Gi mer anerkjennelse og tilbakemelding',
      'Vær mer tilgjengelig for teamet'
    ],
    utvikling: [
      'Kartlegg opplæringsbehov',
      'Tilby kurs eller sertifisering',
      'Etabler mentor/coaching-ordning',
      'Lag utviklingsplan sammen'
    ],
    trivsel: [
      'Arranger sosiale aktiviteter',
      'Styrk inkludering i teamet',
      'Anerkjenn individuelle bidrag',
      'Skap rom for tilbakemelding'
    ]
  };
  return tiltak[tema] || ['Gjennomfør oppfølgingssamtale'];
}

// Beregn temastatistikk fra svar
export function calculateTemaStats(
  svar: PulsSvar[], 
  tema: PulsTema
): { avg: number; trend: number; count: number } {
  // For eldre svar uten tema, bruk standard mapping
  const filteredSvar = svar.filter(s => s.tema === tema);
  
  if (filteredSvar.length === 0) {
    return { avg: 0, trend: 0, count: 0 };
  }

  // Beregn gjennomsnitt (for skala-svar, bruk et gjennomsnitt av de relevante feltene)
  const avg = filteredSvar.reduce((sum, s) => {
    // For standard svar, bruk stemning/energi/mestring basert på tema
    if (tema === 'trivsel') return sum + s.stemning;
    if (tema === 'utvikling') return sum + s.mestring;
    return sum + ((s.stemning + s.energi + s.mestring) / 3);
  }, 0) / filteredSvar.length;

  // Enkel trendberegning (sammenlign siste uke med forrige uke)
  const oneWeekAgo = new Date();
  oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
  const twoWeeksAgo = new Date();
  twoWeeksAgo.setDate(twoWeeksAgo.getDate() - 14);

  const lastWeek = filteredSvar.filter(s => new Date(s.dato) >= oneWeekAgo);
  const prevWeek = filteredSvar.filter(s => {
    const date = new Date(s.dato);
    return date >= twoWeeksAgo && date < oneWeekAgo;
  });

  let trend = 0;
  if (lastWeek.length > 0 && prevWeek.length > 0) {
    const lastAvg = lastWeek.reduce((sum, s) => sum + s.stemning, 0) / lastWeek.length;
    const prevAvg = prevWeek.reduce((sum, s) => sum + s.stemning, 0) / prevWeek.length;
    trend = lastAvg - prevAvg;
  }

  return { avg, trend, count: filteredSvar.length };
}

// Velg roterende spørsmål fra spørsmålsbanken
export function selectRotatingQuestions(
  sporsmalBank: PulsSporsmal[],
  pulsType: PulsType,
  excludeIds: string[] = []
): PulsSporsmal[] {
  const temaer: PulsTema[] = [
    'trivsel', 
    'arbeidsbelastning', 
    'psykologisk_trygghet', 
    'ledelse', 
    'hms_sikkerhet', 
    'utvikling'
  ];

  const selected: PulsSporsmal[] = [];

  for (const tema of temaer) {
    // Filtrer spørsmål for dette tema og pulstype
    const available = sporsmalBank.filter(s => 
      s.tema === tema && 
      s.aktiv && 
      s.moduler.includes(pulsType) &&
      !excludeIds.includes(s.id)
    );

    if (available.length === 0) continue;

    // Hvor mange spørsmål per tema?
    const count = pulsType === 'hurtigpuls' ? 1 : 2;
    
    // Tilfeldig utvalg
    const shuffled = [...available].sort(() => Math.random() - 0.5);
    selected.push(...shuffled.slice(0, count));
  }

  // For dyppuls, legg til noen fritekstspørsmål
  if (pulsType === 'dyppuls') {
    const fritekstSporsmal = sporsmalBank.filter(s => 
      s.sporsmal_type === 'fritekst' && 
      s.aktiv && 
      s.moduler.includes(pulsType) &&
      !selected.some(sel => sel.id === s.id)
    );
    
    const shuffledFritekst = [...fritekstSporsmal].sort(() => Math.random() - 0.5);
    selected.push(...shuffledFritekst.slice(0, 2));
  }

  return selected;
}

// AI-analyse datastruktur
export interface PulsAIAnalyse {
  positiveDrivere: string[];
  risikoFlagg: string[];
  tiltaksplan: {
    dag30: string[];
    dag60: string[];
    dag90: string[];
  };
  teamSentiment: 'positiv' | 'nøytral' | 'negativ';
  sammendrag: string;
}

// Forbered data for AI-analyse
export function prepareAIAnalysisData(
  svar: PulsSvar[],
  risikoer: PulsRisiko[]
): { temaData: Record<PulsTema, { avg: number; risikoCount: number }>; overallScore: number } {
  const temaer: PulsTema[] = [
    'trivsel', 
    'arbeidsbelastning', 
    'psykologisk_trygghet', 
    'ledelse', 
    'hms_sikkerhet', 
    'utvikling'
  ];

  const temaData: Record<PulsTema, { avg: number; risikoCount: number }> = {} as any;
  let totalScore = 0;
  let totalCount = 0;

  for (const tema of temaer) {
    const stats = calculateTemaStats(svar, tema);
    const risikoCount = risikoer.filter(r => r.tema === tema && r.status !== 'lukket').length;
    
    temaData[tema] = { avg: stats.avg, risikoCount };
    
    if (stats.avg > 0) {
      totalScore += stats.avg;
      totalCount++;
    }
  }

  const overallScore = totalCount > 0 ? totalScore / totalCount : 0;

  return { temaData, overallScore };
}
