// Tariff Utilities
// Provides functions for calculating recommended hourly rates based on tariff agreements

import { supabase } from '@/integrations/supabase/client';

export type FagbrevStatus = 'med_fagbrev' | 'uten_fagbrev' | 'mester';

/**
 * Calculate seniority in years from fagbrev date (if exists) or employment date
 */
export function calculateSeniority(
  fagbrevDato: string | Date | null,
  ansattDato: string | Date | null
): number {
  const startDate = fagbrevDato 
    ? new Date(fagbrevDato) 
    : ansattDato 
      ? new Date(ansattDato) 
      : null;
  
  if (!startDate) return 0;
  
  const now = new Date();
  const diffMs = now.getTime() - startDate.getTime();
  const years = diffMs / (365.25 * 24 * 60 * 60 * 1000);
  
  return Math.floor(years);
}

/**
 * Determine fagbrev status based on fagbrev date
 */
export function getFagbrevStatus(fagbrevDato: string | Date | null): FagbrevStatus {
  if (!fagbrevDato) return 'uten_fagbrev';
  
  const fagbrevDate = new Date(fagbrevDato);
  if (isNaN(fagbrevDate.getTime())) return 'uten_fagbrev';
  
  return 'med_fagbrev';
}

/**
 * Get fagbrev status label for display
 */
export function getFagbrevStatusLabel(status: FagbrevStatus): string {
  switch (status) {
    case 'med_fagbrev': return 'Med fagbrev';
    case 'uten_fagbrev': return 'Uten fagbrev';
    case 'mester': return 'Mester';
    default: return 'Ukjent';
  }
}

export interface TariffRecommendation {
  timesats: number;
  fagbrevStatus: FagbrevStatus;
  fagbrevStatusLabel: string;
  ansiennitetAar: number;
  kilde: 'salong' | 'sentral' | 'ingen';
  beskrivelse: string;
}

interface TariffSatsRow {
  timesats: number | null;
}

interface TariffMalRow {
  timesats: number | null;
  navn: string | null;
}

/**
 * Calculate recommended hourly rate based on tariff agreements
 * First checks salon-specific tariff_satser, then falls back to global tariff_maler
 */
export async function calculateRecommendedHourlyRate(
  salongId: string | null,
  fagbrevDato: string | Date | null,
  ansattDato: string | Date | null
): Promise<TariffRecommendation | null> {
  if (!salongId) return null;

  const currentYear = new Date().getFullYear();
  const DEFAULT_RATE = 179.5;

  // Fallback til "Uten fagbrev 0+ år" hvis ingen datoer er satt
  if (!fagbrevDato && !ansattDato) {
    try {
      // Prøv salong-spesifikk først
      const { data: salongDefault } = await supabase
        .from('tariff_satser')
        .select('timesats')
        .eq('salon_id', salongId)
        .eq('aar', currentYear)
        .eq('fagbrev_status', 'uten_fagbrev')
        .order('ansiennitet_min', { ascending: true })
        .limit(1) as { data: TariffSatsRow[] | null };

      if (salongDefault?.[0]?.timesats) {
        return {
          timesats: Number(salongDefault[0].timesats),
          fagbrevStatus: 'uten_fagbrev',
          fagbrevStatusLabel: 'Uten fagbrev',
          ansiennitetAar: 0,
          kilde: 'salong',
          beskrivelse: 'Uten fagbrev, 0+ år (standard)'
        };
      }

      // Fallback til global tariff_maler
      const { data: globalDefault } = await supabase
        .from('tariff_maler')
        .select('timesats, navn')
        .eq('aar', currentYear)
        .eq('fagbrev_status', 'uten_fagbrev')
        .order('ansiennitet_min', { ascending: true })
        .limit(1) as { data: TariffMalRow[] | null };

      return {
        timesats: globalDefault?.[0]?.timesats ? Number(globalDefault[0].timesats) : DEFAULT_RATE,
        fagbrevStatus: 'uten_fagbrev',
        fagbrevStatusLabel: 'Uten fagbrev',
        ansiennitetAar: 0,
        kilde: globalDefault?.[0]?.timesats ? 'sentral' : 'ingen',
        beskrivelse: 'Uten fagbrev, 0+ år (standard)'
      };
    } catch (error) {
      console.error('Error fetching default tariff:', error);
      return {
        timesats: DEFAULT_RATE,
        fagbrevStatus: 'uten_fagbrev',
        fagbrevStatusLabel: 'Uten fagbrev',
        ansiennitetAar: 0,
        kilde: 'ingen',
        beskrivelse: 'Uten fagbrev, 0+ år (standard)'
      };
    }
  }

  const ansiennitetAar = calculateSeniority(fagbrevDato, ansattDato);
  const fagbrevStatus = getFagbrevStatus(fagbrevDato);

  try {
    // First, try salon-specific tariff_satser
    const { data: salongData } = await supabase
      .from('tariff_satser')
      .select('timesats')
      .eq('salon_id', salongId)
      .eq('aar', currentYear)
      .eq('fagbrev_status', fagbrevStatus)
      .lte('ansiennitet_min', ansiennitetAar)
      .order('ansiennitet_min', { ascending: false })
      .limit(1) as { data: TariffSatsRow[] | null };

    const salongTariff = salongData?.[0];

    if (salongTariff?.timesats) {
      return {
        timesats: Number(salongTariff.timesats),
        fagbrevStatus,
        fagbrevStatusLabel: getFagbrevStatusLabel(fagbrevStatus),
        ansiennitetAar,
        kilde: 'salong',
        beskrivelse: `Salong-spesifikk tariff (${ansiennitetAar} års ansiennitet)`
      };
    }

    // Fallback to global tariff_maler
    const { data: sentralData } = await supabase
      .from('tariff_maler')
      .select('timesats, navn')
      .eq('aar', currentYear)
      .eq('fagbrev_status', fagbrevStatus)
      .lte('ansiennitet_min', ansiennitetAar)
      .order('ansiennitet_min', { ascending: false })
      .limit(1) as { data: TariffMalRow[] | null };

    const sentralTariff = sentralData?.[0];

    if (sentralTariff?.timesats) {
      return {
        timesats: Number(sentralTariff.timesats),
        fagbrevStatus,
        fagbrevStatusLabel: getFagbrevStatusLabel(fagbrevStatus),
        ansiennitetAar,
        kilde: 'sentral',
        beskrivelse: sentralTariff.navn || `Sentral tariff (${ansiennitetAar} års ansiennitet)`
      };
    }
  } catch (error) {
    console.error('Error fetching tariff:', error);
  }

  return {
    timesats: 0,
    fagbrevStatus,
    fagbrevStatusLabel: getFagbrevStatusLabel(fagbrevStatus),
    ansiennitetAar,
    kilde: 'ingen',
    beskrivelse: 'Ingen tariff funnet for dette året'
  };
}

/**
 * Check if an employee's hourly rate deviates significantly from tariff
 */
export function checkTariffDeviation(
  actualRate: number | null,
  recommendedRate: number | null,
  tolerancePercent: number = 5
): { hasDeviation: boolean; deviationPercent: number; message: string } {
  if (!actualRate || !recommendedRate || recommendedRate === 0) {
    return { hasDeviation: false, deviationPercent: 0, message: '' };
  }

  const deviation = ((actualRate - recommendedRate) / recommendedRate) * 100;
  const hasDeviation = Math.abs(deviation) > tolerancePercent;

  let message = '';
  if (hasDeviation) {
    if (deviation > 0) {
      message = `Timesats er ${deviation.toFixed(1)}% over tariff`;
    } else {
      message = `Timesats er ${Math.abs(deviation).toFixed(1)}% under tariff`;
    }
  }

  return { hasDeviation, deviationPercent: deviation, message };
}

/**
 * Calculate monthly salary from hourly rate
 */
export function calculateMonthlySalary(
  timesats: number,
  stillingsprosent: number = 100,
  timerPerUke: number = 37.5
): number {
  const ukerPerMaaned = 4.33; // Average weeks per month
  const timerPerMaaned = (timerPerUke * (stillingsprosent / 100)) * ukerPerMaaned;
  return Math.round(timesats * timerPerMaaned);
}
