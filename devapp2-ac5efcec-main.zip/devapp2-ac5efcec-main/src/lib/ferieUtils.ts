/**
 * Ferie Utility Functions
 * 
 * Beregningsfunksjoner for feriekrav, tilgode, overføringer og årsskifte-splitting.
 */

import { supabase } from "@/integrations/supabase/client";
import { format } from "date-fns";

export interface FeriePeriode {
  startdato: string;
  sluttdato: string;
  aar: number;
  timer: number;
}

export interface FerieBeregning {
  arbeidsdager: number;
  timer: number;
  perioder: FeriePeriode[];
  ekskluderteHelligdager: { dato: string; helligdag_navn: string | null }[];
}

export type FerieStatus = 'low' | 'medium' | 'high';

export interface FerieTilgodeResult {
  tilgode: number;
  utnyttelseProsent: number;
  status: FerieStatus;
}

export interface OverforingValidation {
  valid: boolean;
  warning?: string;
  error?: string;
}

/**
 * Beregn feriekrav justert for stillingsprosent
 * Formel: feriekrav = (feriekrav_timer_per_aar × stillingsprosent) / 100
 */
export function calculateFeriekrav(
  feriekravTimerPerAar: number,
  stillingsprosent: number
): number {
  return (feriekravTimerPerAar * stillingsprosent) / 100;
}

/**
 * Beregn hvor mange timer som er til gode og status-indikator
 * Status-logikk:
 * 🔴 low:    < 50% utnyttet
 * 🟡 medium: 50-90% utnyttet  
 * 🟢 high:   ≥ 90% utnyttet
 */
export function calculateFerieTilgode(
  feriekrav: number,
  avholdtTimer: number
): FerieTilgodeResult {
  const tilgode = Math.max(0, feriekrav - avholdtTimer);
  const utnyttelseProsent = feriekrav > 0 ? (avholdtTimer / feriekrav) * 100 : 0;
  
  let status: FerieStatus;
  if (utnyttelseProsent < 50) status = 'low';
  else if (utnyttelseProsent < 90) status = 'medium';
  else status = 'high';
  
  return { tilgode, utnyttelseProsent, status };
}

/**
 * Beregn totalt tilgjengelig ferie inkludert overføringer
 */
export function calculateTotalAvailableForYear(
  feriekrav: number,
  overfortInn: number,
  overfortUt: number
): number {
  return feriekrav + overfortInn - overfortUt;
}

/**
 * Valider om overføring er tillatt
 */
export function validateOverforing(
  tilgodeTimer: number,
  timerAOverfore: number,
  fraAar: number,
  tilAar: number,
  feriekravType: string
): OverforingValidation {
  // Kan ikke overføre mer enn du har til gode
  if (timerAOverfore > tilgodeTimer) {
    return { valid: false, error: "Kan ikke overføre mer enn til gode-timer" };
  }
  
  // Må overføre noe
  if (timerAOverfore <= 0) {
    return { valid: false, error: "Må overføre minst én time" };
  }
  
  // Kan kun overføre til NESTE år
  if (tilAar !== fraAar + 1) {
    return { valid: false, error: "Kan kun overføre til neste år" };
  }
  
  // Lovfestet ferie: Advarsel hvis etter 30. september
  const today = new Date();
  const deadline = new Date(tilAar, 8, 30); // 30. september
  if (feriekravType?.includes("Lovfestet") && today > deadline) {
    return { 
      valid: true, 
      warning: "OBS: Lovfestet ferie skulle vært brukt innen 30. september" 
    };
  }
  
  return { valid: true };
}

/**
 * Beregn arbeidsdager (ekskluderer helger) - SYNKRON versjon for bakoverkompatibilitet
 */
export function calculateWorkDays(startdato: Date, sluttdato: Date): number {
  let count = 0;
  const current = new Date(startdato);
  
  while (current <= sluttdato) {
    const dayOfWeek = current.getDay();
    // 0 = søndag, 6 = lørdag
    if (dayOfWeek !== 0 && dayOfWeek !== 6) {
      count++;
    }
    current.setDate(current.getDate() + 1);
  }
  
  return count;
}

/**
 * Beregn arbeidsdager som ekskluderer helger OG helligdager fra kalender-tabellen
 * ASYNKRON versjon som henter helligdager fra databasen
 */
export async function calculateWorkDaysExcludingHolidays(
  startdato: Date,
  sluttdato: Date
): Promise<{ workDays: number; helligdager: { dato: string; helligdag_navn: string | null }[] }> {
  const startStr = format(startdato, 'yyyy-MM-dd');
  const sluttStr = format(sluttdato, 'yyyy-MM-dd');
  
  // Hent helligdager fra kalender-tabellen
  const { data: helligdager } = await supabase
    .from('kalender')
    .select('dato, helligdag_navn')
    .eq('er_helligdag', true)
    .gte('dato', startStr)
    .lte('dato', sluttStr);
  
  // Lag Set med helligdagsdatoer for rask oppslag
  const helligdagerSet = new Set(helligdager?.map(h => h.dato) || []);
  
  // Tell arbeidsdager (ikke helg, ikke helligdag)
  let count = 0;
  const current = new Date(startdato);
  
  while (current <= sluttdato) {
    const dayOfWeek = current.getDay();
    const dateStr = format(current, 'yyyy-MM-dd');
    
    // Ikke helg OG ikke helligdag
    if (dayOfWeek !== 0 && dayOfWeek !== 6 && !helligdagerSet.has(dateStr)) {
      count++;
    }
    current.setDate(current.getDate() + 1);
  }
  
  return {
    workDays: count,
    helligdager: helligdager || []
  };
}

/**
 * Del opp ferieperiode som krysser årsskiftet i separate poster
 * VIKTIG: Sikrer korrekt ferieregnskap per år
 * SYNKRON versjon for bakoverkompatibilitet
 */
export function splitFeriePeriode(
  startdato: Date,
  sluttdato: Date,
  stillingsprosent: number
): FeriePeriode[] {
  const startYear = startdato.getFullYear();
  const endYear = sluttdato.getFullYear();

  // Samme år? Returner én post
  if (startYear === endYear) {
    const workDays = calculateWorkDays(startdato, sluttdato);
    const timer = workDays * 7.5 * (stillingsprosent / 100);
    
    return [{
      startdato: format(startdato, 'yyyy-MM-dd'),
      sluttdato: format(sluttdato, 'yyyy-MM-dd'),
      aar: startYear,
      timer: Math.round(timer * 10) / 10
    }];
  }

  // Krysser årsskiftet → Split i to perioder
  const perioder: FeriePeriode[] = [];

  // Periode 1: startdato → 31. desember (år 1)
  const endOfYear = new Date(startYear, 11, 31);
  const workDays1 = calculateWorkDays(startdato, endOfYear);
  const timer1 = workDays1 * 7.5 * (stillingsprosent / 100);
  perioder.push({
    startdato: format(startdato, 'yyyy-MM-dd'),
    sluttdato: format(endOfYear, 'yyyy-MM-dd'),
    aar: startYear,
    timer: Math.round(timer1 * 10) / 10
  });

  // Periode 2: 1. januar → sluttdato (år 2)
  const startOfYear = new Date(endYear, 0, 1);
  const workDays2 = calculateWorkDays(startOfYear, sluttdato);
  const timer2 = workDays2 * 7.5 * (stillingsprosent / 100);
  perioder.push({
    startdato: format(startOfYear, 'yyyy-MM-dd'),
    sluttdato: format(sluttdato, 'yyyy-MM-dd'),
    aar: endYear,
    timer: Math.round(timer2 * 10) / 10
  });

  return perioder;
}

/**
 * Beregn full ferieinfo inkludert helligdags-ekskludering
 * ASYNC versjon som henter helligdager fra databasen
 */
export async function calculateFerieBeregning(
  startdato: Date,
  sluttdato: Date,
  stillingsprosent: number
): Promise<FerieBeregning> {
  const { workDays, helligdager } = await calculateWorkDaysExcludingHolidays(startdato, sluttdato);
  const timer = workDays * 7.5 * (stillingsprosent / 100);
  
  // Beregn perioder (for årsskifte-splitting)
  const startYear = startdato.getFullYear();
  const endYear = sluttdato.getFullYear();
  
  let perioder: FeriePeriode[];
  
  if (startYear === endYear) {
    perioder = [{
      startdato: format(startdato, 'yyyy-MM-dd'),
      sluttdato: format(sluttdato, 'yyyy-MM-dd'),
      aar: startYear,
      timer: Math.round(timer * 10) / 10
    }];
  } else {
    // Split ved årsskifte - beregn timer per periode med helligdags-ekskludering
    const endOfYear = new Date(startYear, 11, 31);
    const startOfYear = new Date(endYear, 0, 1);
    
    const { workDays: workDays1 } = await calculateWorkDaysExcludingHolidays(startdato, endOfYear);
    const { workDays: workDays2 } = await calculateWorkDaysExcludingHolidays(startOfYear, sluttdato);
    
    perioder = [
      {
        startdato: format(startdato, 'yyyy-MM-dd'),
        sluttdato: format(endOfYear, 'yyyy-MM-dd'),
        aar: startYear,
        timer: Math.round(workDays1 * 7.5 * (stillingsprosent / 100) * 10) / 10
      },
      {
        startdato: format(startOfYear, 'yyyy-MM-dd'),
        sluttdato: format(sluttdato, 'yyyy-MM-dd'),
        aar: endYear,
        timer: Math.round(workDays2 * 7.5 * (stillingsprosent / 100) * 10) / 10
      }
    ];
  }
  
  return {
    arbeidsdager: workDays,
    timer: Math.round(timer * 10) / 10,
    perioder,
    ekskluderteHelligdager: helligdager
  };
}

/**
 * Formater timer til dager og timer
 */
export function formatHours(hours: number): string {
  if (hours === 0) return "0t";
  const days = Math.floor(hours / 7.5);
  const remainingHours = Math.round((hours % 7.5) * 10) / 10;
  
  if (days === 0) return `${remainingHours}t`;
  if (remainingHours === 0) return `${days}d`;
  return `${days}d ${remainingHours}t`;
}

/**
 * Hent status-farge basert på utnyttelsesprosent
 */
export function getStatusColor(prosent: number): string {
  if (prosent < 50) return "bg-red-500/10 text-red-600";
  if (prosent < 90) return "bg-yellow-500/10 text-yellow-600";
  return "bg-green-500/10 text-green-600";
}

/**
 * Hent status-badge variant basert på prosent
 */
export function getStatusVariant(prosent: number): "destructive" | "secondary" | "default" {
  if (prosent < 50) return "destructive";
  if (prosent < 90) return "secondary";
  return "default";
}
