/**
 * Ferie-Estimat Generator Utilities
 * 
 * Genererer ferie-estimater for budsjettering med:
 * - Fast 3 uker sommerferie (1. juli - 31. august) for alle
 * - Bemanningskrav: minimum 2 ansatte på jobb i sommerperioden
 * - Hele uker (5 arbeidsdager) for alle ferieperioder
 * - Normalfordeling av ansatte på tvers av perioder
 */

import { getISOWeek, addDays, startOfWeek, format } from "date-fns";
import { calculateWorkDaysExcludingHolidays } from "./ferieUtils";
import { supabase } from "@/integrations/supabase/client";

// ============= TYPES =============

export interface FerieEstimatPeriode {
  navn: string;
  type: string;
  startUke: number;
  sluttUke: number;
  fasteUker?: number;      // Fast antall uker (for sommerferie)
  erKrav?: boolean;        // Om dette er et krav (ikke andel)
  startDato?: string;      // Faktisk startdato hvis spesifisert (brukes i stedet for uke-beregning)
  sluttDato?: string;      // Faktisk sluttdato hvis spesifisert (brukes i stedet for uke-beregning)
}

export interface FerieEstimatConfig {
  aar: number;
  perioder: FerieEstimatPeriode[];
  minBemanning?: number;   // Minimum antall på jobb (default: 2)
  eksisterendeTimerPerAnsatt?: Map<string, number>; // Allerede brukte ferietimer per ansatt (ansattId -> timer)
}

export interface AnsattFerieEstimat {
  ansattId: string;
  ansattNavn: string;
  userId: string | null;
  stillingsprosent: number;
  totalFeriekrav: number;
  estimater: GenerertFerieEstimat[];
}

export interface GenerertFerieEstimat {
  type: string;
  startdato: string;
  sluttdato: string;
  arbeidsdager: number;
  timer: number;
  startUke: number;
}

export interface Ansatt {
  id: string;
  user_id?: string | null;
  fornavn: string;
  etternavn: string | null;
  stillingsprosent: number;
  feriekrav_timer_per_aar: number;
}

export interface BemanningPerUke {
  uke: number;
  antallPaaJobb: number;
  antallPaaFerie: number;
  erOk: boolean;
}

// ============= KONSTANTER =============

const SOMMER_START_UKE = 27;  // Ca. 1. juli
const SOMMER_SLUTT_UKE = 35;  // Ca. 31. august
const SOMMER_FERIE_UKER = 3;  // Fast 3 uker sommerferie
const MIN_BEMANNING_DEFAULT = 2;
const TIMER_PER_DAG = 7.5;
const DAGER_PER_UKE = 5;

// ============= PERIODE-KONFIGURASJON =============

/**
 * Henter standard ferieperioder for et gitt år
 * Sommerferie er et fast krav på 3 uker, resten fordeles prosentvis
 */
export function getStandardFerieperioder(aar: number): FerieEstimatPeriode[] {
  return [
    {
      navn: "Vinterferie",
      type: "Estimat - Vinterferie",
      startUke: 8,
      sluttUke: 9,
    },
    {
      navn: "Påskeferie",
      type: "Estimat - Påskeferie",
      startUke: getPaskeUke(aar),
      sluttUke: getPaskeUke(aar) + 1,
    },
    {
      navn: "Sommerferie",
      type: "Estimat - Sommerferie",
      startUke: SOMMER_START_UKE,
      sluttUke: SOMMER_SLUTT_UKE,
      fasteUker: SOMMER_FERIE_UKER,
      erKrav: true,
    },
    {
      navn: "Høstferie",
      type: "Estimat - Høstferie",
      startUke: 40,
      sluttUke: 41,
    },
    {
      navn: "Juleferie",
      type: "Estimat - Juleferie",
      startUke: 51,
      sluttUke: 52,
    }
  ];
}

/**
 * Beregner påskeuken for et gitt år (basert på Gauss algoritme)
 */
function getPaskeUke(aar: number): number {
  const a = aar % 19;
  const b = Math.floor(aar / 100);
  const c = aar % 100;
  const d = Math.floor(b / 4);
  const e = b % 4;
  const f = Math.floor((b + 8) / 25);
  const g = Math.floor((b - f + 1) / 3);
  const h = (19 * a + b - d - g + 15) % 30;
  const i = Math.floor(c / 4);
  const k = c % 4;
  const l = (32 + 2 * e + 2 * i - h - k) % 7;
  const m = Math.floor((a + 11 * h + 22 * l) / 451);
  const month = Math.floor((h + l - 7 * m + 114) / 31);
  const day = ((h + l - 7 * m + 114) % 31) + 1;
  
  const paskesondag = new Date(aar, month - 1, day);
  return getISOWeek(paskesondag);
}

// ============= DATO-HJELPEFUNKSJONER =============

/**
 * Henter mandagen i en gitt uke for et år
 */
export function getMondayOfWeek(aar: number, uke: number): Date {
  const jan4 = new Date(aar, 0, 4);
  const monday = startOfWeek(jan4, { weekStartsOn: 1 });
  return addDays(monday, (uke - 1) * 7);
}

/**
 * Henter fredagen i en gitt uke for et år
 */
export function getFridayOfWeek(aar: number, uke: number): Date {
  const monday = getMondayOfWeek(aar, uke);
  return addDays(monday, 4);
}

/**
 * Finner sluttdato etter N arbeidsdager fra startdato (ekskluderer helger OG helligdager)
 * Brukes for å justere sluttdato når vi ikke bruker hele perioden
 */
async function getDateAfterNWorkDays(startdato: Date, antallArbeidsdager: number): Promise<Date> {
  if (antallArbeidsdager <= 0) return startdato;
  
  // Hent helligdager for en rimelig periode fremover (30 dager burde dekke det meste)
  const sluttSok = addDays(startdato, 30);
  const startStr = format(startdato, 'yyyy-MM-dd');
  const sluttStr = format(sluttSok, 'yyyy-MM-dd');
  
  const { data: helligdager } = await supabase
    .from('kalender')
    .select('dato')
    .eq('er_helligdag', true)
    .gte('dato', startStr)
    .lte('dato', sluttStr);
  
  const helligdagerSet = new Set(helligdager?.map(h => h.dato) || []);
  
  let arbeidsdagerTelt = 0;
  let current = new Date(startdato);
  
  while (arbeidsdagerTelt < antallArbeidsdager) {
    const dayOfWeek = current.getDay();
    const dateStr = format(current, 'yyyy-MM-dd');
    
    // Ikke helg (lørdag=6, søndag=0) OG ikke helligdag
    if (dayOfWeek !== 0 && dayOfWeek !== 6 && !helligdagerSet.has(dateStr)) {
      arbeidsdagerTelt++;
    }
    if (arbeidsdagerTelt < antallArbeidsdager) {
      current = addDays(current, 1);
    }
  }
  
  return current;
}

// ============= BEMANNINGSKRAV-LOGIKK =============

/**
 * Beregner sommerferie-fordeling med bemanningskrav
 * Sikrer at minimum X ansatte er på jobb hver uke i sommerperioden
 */
function fordelSommerferieMedBemanningskrav(
  ansatte: Ansatt[],
  aar: number,
  minBemanning: number
): Map<string, number> {
  const antallAnsatte = ansatte.length;
  const fordeling = new Map<string, number>();
  
  // Spesialhåndtering for små salonger
  if (antallAnsatte <= minBemanning) {
    // Alle kan ikke ha ferie samtidig - del perioden i to
    ansatte.forEach((ansatt, index) => {
      if (index < Math.ceil(antallAnsatte / 2)) {
        fordeling.set(ansatt.id, SOMMER_START_UKE);
      } else {
        fordeling.set(ansatt.id, SOMMER_START_UKE + SOMMER_FERIE_UKER + 1);
      }
    });
    return fordeling;
  }
  
  // Beregn hvor mange som kan ha ferie samtidig
  const maxPaaFeriePerUke = Math.max(1, antallAnsatte - minBemanning);
  
  // Beregn antall "grupper" som må fordeles
  const antallGrupper = Math.ceil(antallAnsatte / maxPaaFeriePerUke);
  
  // Tilgjengelige startuker (uke 27-31 gir rom for 3 ukers ferie før uke 33)
  const tilgjengeligeStartUker = SOMMER_SLUTT_UKE - SOMMER_START_UKE - SOMMER_FERIE_UKER + 1;
  const ukerMellomGrupper = Math.max(1, Math.floor(tilgjengeligeStartUker / antallGrupper));
  
  // Shuffle ansatte for rettferdig fordeling
  const shuffledAnsatte = [...ansatte].sort(() => Math.random() - 0.5);
  
  shuffledAnsatte.forEach((ansatt, index) => {
    const gruppeIndex = Math.floor(index / maxPaaFeriePerUke);
    const startUke = Math.min(
      SOMMER_START_UKE + (gruppeIndex * ukerMellomGrupper),
      SOMMER_SLUTT_UKE - SOMMER_FERIE_UKER
    );
    fordeling.set(ansatt.id, startUke);
  });
  
  return fordeling;
}

/**
 * Fordeler en roterende ferieperiode med bemanningskrav
 * Sikrer at minimum X ansatte er på jobb i perioden
 * Returnerer hvilke ansatte som får ferie i denne perioden
 */
function fordelPeriodeMedBemanningskrav(
  ansatte: Ansatt[],
  periode: FerieEstimatPeriode,
  minBemanning: number,
  alleredeFordeltePerAnsatt: Map<string, Set<string>> // ansattId -> Set av periodetyper
): Set<string> {
  const antallAnsatte = ansatte.length;
  
  // Hvor mange kan ha ferie samtidig?
  const maxPaaFerie = Math.max(1, antallAnsatte - minBemanning);
  
  // Sorter ansatte etter hvor mange perioder de allerede har fått (færrest først)
  // Dette sikrer rettferdig fordeling
  const sortertEtterBehov = [...ansatte].sort((a, b) => {
    const aAntall = alleredeFordeltePerAnsatt.get(a.id)?.size ?? 0;
    const bAntall = alleredeFordeltePerAnsatt.get(b.id)?.size ?? 0;
    if (aAntall !== bAntall) return aAntall - bAntall;
    // Tilfeldig rekkefølge for de med samme antall
    return Math.random() - 0.5;
  });
  
  // Velg de første X ansatte som får ferie i denne perioden
  const faarFerie = new Set<string>();
  for (let i = 0; i < Math.min(maxPaaFerie, sortertEtterBehov.length); i++) {
    faarFerie.add(sortertEtterBehov[i].id);
  }
  
  return faarFerie;
}

/**
 * Beregner bemanning per uke basert på sommerferie-fordeling
 */
export function beregnBemanningPerUke(
  ansatte: Ansatt[],
  sommerFordeling: Map<string, number>,
  minBemanning: number
): BemanningPerUke[] {
  const bemanningPerUke: BemanningPerUke[] = [];
  
  for (let uke = SOMMER_START_UKE; uke <= SOMMER_SLUTT_UKE; uke++) {
    let antallPaaFerie = 0;
    
    sommerFordeling.forEach((startUke) => {
      const sluttUke = startUke + SOMMER_FERIE_UKER - 1;
      if (uke >= startUke && uke <= sluttUke) {
        antallPaaFerie++;
      }
    });
    
    const antallPaaJobb = ansatte.length - antallPaaFerie;
    
    bemanningPerUke.push({
      uke,
      antallPaaJobb,
      antallPaaFerie,
      erOk: antallPaaJobb >= minBemanning
    });
  }
  
  return bemanningPerUke;
}

// ============= HOVEDFUNKSJON =============

/**
 * Genererer ferie-estimater for alle ansatte med:
 * - Fast 3 uker sommerferie med bemanningskrav
 * - Hele uker for alle perioder
 * - Normalfordeling på tvers av ansatte
 */
export async function genererFerieEstimater(
  ansatte: Ansatt[],
  config: FerieEstimatConfig
): Promise<AnsattFerieEstimat[]> {
  const { aar, perioder, minBemanning = MIN_BEMANNING_DEFAULT } = config;
  const resultater: AnsattFerieEstimat[] = [];

  // Finn sommerferie-perioden
  const sommerPeriode = perioder.find(p => p.erKrav && p.fasteUker);
  
  // Beregn sommerferie-fordeling med bemanningskrav
  const sommerFordeling = sommerPeriode 
    ? fordelSommerferieMedBemanningskrav(ansatte, aar, minBemanning)
    : new Map<string, number>();

  // Filtrer ut perioder som ikke er sommerferie (for roterende fordeling)
  const andrePerioder = perioder.filter(p => !p.erKrav);
  
  // Beregn hvor mange timer per uke ved 100%
  const timerPerUke100 = DAGER_PER_UKE * TIMER_PER_DAG; // 37.5 timer per uke ved 100%
  
  // Fordel roterende perioder med bemanningskrav
  // For hver periode, bestem hvem som får ferie basert på bemanningskrav
  const periodeFordeling = new Map<string, Set<string>>(); // periodeType -> Set av ansattId
  const ansattTilPerioder = new Map<string, Set<string>>(); // ansattId -> Set av periodetyper
  
  // Initialiser ansatt til perioder map
  for (const ansatt of ansatte) {
    ansattTilPerioder.set(ansatt.id, new Set());
  }
  
  // Shuffle perioder for tilfeldig rekkefølge
  const shuffledAndrePerioder = [...andrePerioder].sort(() => Math.random() - 0.5);
  
  // Fordel hver periode med bemanningskrav
  for (const periode of shuffledAndrePerioder) {
    const faarFerie = fordelPeriodeMedBemanningskrav(
      ansatte,
      periode,
      minBemanning,
      ansattTilPerioder
    );
    
    periodeFordeling.set(periode.type, faarFerie);
    
    // Oppdater ansatt til perioder map
    for (const ansattId of faarFerie) {
      ansattTilPerioder.get(ansattId)?.add(periode.type);
    }
  }

  // Generer estimater for hver ansatt
  for (const ansatt of ansatte) {
    const feriekrav = (ansatt.feriekrav_timer_per_aar * ansatt.stillingsprosent) / 100;
    const timerPerUke = timerPerUke100 * ansatt.stillingsprosent / 100;
    
    const estimater: GenerertFerieEstimat[] = [];
    
    // STEG 1: Sommerferie først (fast 3 uker)
    if (sommerPeriode && sommerFordeling.has(ansatt.id)) {
      const startUke = sommerFordeling.get(ansatt.id)!;
      const sluttUke = startUke + SOMMER_FERIE_UKER - 1;
      
      const startdato = getMondayOfWeek(aar, startUke);
      const sluttdato = getFridayOfWeek(aar, sluttUke);
      
      const { workDays } = await calculateWorkDaysExcludingHolidays(startdato, sluttdato);
      const timer = Math.round((workDays * TIMER_PER_DAG * ansatt.stillingsprosent / 100) * 10) / 10;
      
      estimater.push({
        type: sommerPeriode.type,
        startdato: format(startdato, "yyyy-MM-dd"),
        sluttdato: format(sluttdato, "yyyy-MM-dd"),
        arbeidsdager: workDays,
        timer,
        startUke
      });
    }
    
    // STEG 2: Beregn gjenværende ferietimer (ta høyde for eksisterende estimater)
    const sommerTimer = estimater.length > 0 ? estimater[0].timer : 0;
    const eksisterendeTimer = config.eksisterendeTimerPerAnsatt?.get(ansatt.id) || 0;
    let gjenvarendeTimer = feriekrav - sommerTimer - eksisterendeTimer;
    
    // STEG 3: Hent periodene denne ansatte er tildelt (basert på bemanningsfordeling)
    const tildeltePeriodeTyper = ansattTilPerioder.get(ansatt.id) || new Set();
    let tildeltePerioder = andrePerioder.filter(p => tildeltePeriodeTyper.has(p.type));
    
    // Sorter kronologisk for bedre visning
    tildeltePerioder.sort((a, b) => a.startUke - b.startUke);
    
    // STEG 4: Generer estimater for tildelte perioder
    // Timer per dag justert for stillingsprosent
    const timerPerDag = TIMER_PER_DAG * ansatt.stillingsprosent / 100;
    
    // Beregn ønsket antall dager per periode (hele dager)
    const gjenvarendeDager = Math.floor(gjenvarendeTimer / timerPerDag);
    const dagerPerPeriode = tildeltePerioder.length > 0 
      ? Math.max(DAGER_PER_UKE, Math.floor(gjenvarendeDager / tildeltePerioder.length))
      : gjenvarendeDager;
    
    for (const periode of tildeltePerioder) {
      if (gjenvarendeTimer < timerPerDag) break; // Mindre enn én dag igjen
      
      // Beregn antall uker basert på ønsket antall dager
      const antallUker = Math.max(1, Math.ceil(dagerPerPeriode / DAGER_PER_UKE));
      
      // Startuke fra perioden
      const startUke = periode.startUke;
      const sluttUke = startUke + antallUker - 1;
      
      // Bruk faktiske datoer hvis tilgjengelig, ellers beregn fra ukenummer
      const startdato = periode.startDato 
        ? new Date(periode.startDato) 
        : getMondayOfWeek(aar, startUke);
      const sluttdato = periode.sluttDato 
        ? new Date(periode.sluttDato) 
        : getFridayOfWeek(aar, sluttUke);
      
      // Beregn faktiske arbeidsdager (ekskluderer helligdager og helger)
      const { workDays } = await calculateWorkDaysExcludingHolidays(startdato, sluttdato);
      
      // Timer = arbeidsdager × timer per dag (hele dager!)
      const timer = workDays * timerPerDag;
      
      if (workDays > 0 && timer > 0 && timer <= gjenvarendeTimer) {
        estimater.push({
          type: periode.type,
          startdato: format(startdato, "yyyy-MM-dd"),
          sluttdato: format(sluttdato, "yyyy-MM-dd"),
          arbeidsdager: workDays,
          timer,
          startUke
        });
        
        gjenvarendeTimer -= timer;
      }
    }

    // STEG 5: Fylle-opp logikk - legg til flere perioder hvis feriekravet ikke er dekket
    // Dette sikrer at alle ansatte får sine 25 dager selv om bemanningsfordeling 
    // ikke ga dem nok perioder
    const bruktePeriodeTyper = new Set(estimater.map(e => e.type));
    const timerPerDagFyllOpp = TIMER_PER_DAG * ansatt.stillingsprosent / 100;
    
    // Fortsett så lenge det er minst 1 dag igjen
    while (gjenvarendeTimer >= timerPerDagFyllOpp) {
      // Finn perioder som ikke er brukt ennå
      const ubruktePerioder = andrePerioder.filter(
        p => !bruktePeriodeTyper.has(p.type)
      );
      
      if (ubruktePerioder.length === 0) break; // Ingen flere definerte perioder tilgjengelig
      
      // Velg tilfeldig ubrukt periode
      const nestePeriode = ubruktePerioder[Math.floor(Math.random() * ubruktePerioder.length)];
      bruktePeriodeTyper.add(nestePeriode.type);
      
      // Beregn datoer for denne perioden
      const startUke = nestePeriode.startUke;
      const antallUker = Math.max(1, Math.round(gjenvarendeTimer / timerPerUke));
      const sluttUke = startUke + antallUker - 1;
      
      const startdato = nestePeriode.startDato 
        ? new Date(nestePeriode.startDato) 
        : getMondayOfWeek(aar, startUke);
      const originalSluttdato = nestePeriode.sluttDato 
        ? new Date(nestePeriode.sluttDato) 
        : getFridayOfWeek(aar, sluttUke);
      
      const { workDays } = await calculateWorkDaysExcludingHolidays(startdato, originalSluttdato);
      const maksArbeidsdager = Math.floor(gjenvarendeTimer / timerPerDagFyllOpp);
      const faktiskeArbeidsdager = Math.min(workDays, maksArbeidsdager);
      const timer = faktiskeArbeidsdager * timerPerDagFyllOpp;
      
      // Juster sluttdato hvis vi ikke bruker hele perioden
      const justerSluttdato = faktiskeArbeidsdager < workDays
        ? await getDateAfterNWorkDays(startdato, faktiskeArbeidsdager)
        : originalSluttdato;
      
      if (faktiskeArbeidsdager > 0 && timer > 0) {
        estimater.push({
          type: nestePeriode.type,
          startdato: format(startdato, "yyyy-MM-dd"),
          sluttdato: format(justerSluttdato, "yyyy-MM-dd"),
          arbeidsdager: faktiskeArbeidsdager,
          timer,
          startUke
        });
        
        gjenvarendeTimer -= timer;
      }
    }

    // STEG 6: "Annen ferie" for resterende timer som ikke ble dekket av definerte perioder
    // Hvis det fortsatt gjenstår timer (minst 1 dag), opprett "Annen ferie"-perioder
    const bruktStartUker = new Set(estimater.map(e => e.startUke));
    const muligeAnnenFerieUker = [45, 46, 47, 10, 11, 12, 5, 6, 7, 48, 49]; // November, mars, februar, desember
    
    let annenFerieIndex = 0;
    while (gjenvarendeTimer >= timerPerDagFyllOpp && annenFerieIndex < muligeAnnenFerieUker.length) {
      const ukeNr = muligeAnnenFerieUker[annenFerieIndex];
      annenFerieIndex++;
      
      // Sjekk om denne uken allerede er brukt
      if (bruktStartUker.has(ukeNr)) continue;
      
      const startdato = getMondayOfWeek(aar, ukeNr);
      const originalSluttdato = getFridayOfWeek(aar, ukeNr);
      
      const { workDays } = await calculateWorkDaysExcludingHolidays(startdato, originalSluttdato);
      const maksArbeidsdager = Math.floor(gjenvarendeTimer / timerPerDagFyllOpp);
      const faktiskeArbeidsdager = Math.min(workDays, maksArbeidsdager);
      const timer = faktiskeArbeidsdager * timerPerDagFyllOpp;
      
      // Juster sluttdato hvis vi ikke bruker hele uken
      const justerSluttdato = faktiskeArbeidsdager < workDays
        ? await getDateAfterNWorkDays(startdato, faktiskeArbeidsdager)
        : originalSluttdato;
      
      if (faktiskeArbeidsdager > 0 && timer > 0) {
        estimater.push({
          type: "Estimat - Annen ferie",
          startdato: format(startdato, "yyyy-MM-dd"),
          sluttdato: format(justerSluttdato, "yyyy-MM-dd"),
          arbeidsdager: faktiskeArbeidsdager,
          timer,
          startUke: ukeNr
        });
        
        bruktStartUker.add(ukeNr);
        gjenvarendeTimer -= timer;
      }
    }

    // Sorter estimater kronologisk
    estimater.sort((a, b) => a.startUke - b.startUke);

    resultater.push({
      ansattId: ansatt.id,
      ansattNavn: `${ansatt.fornavn} ${ansatt.etternavn || ""}`.trim(),
      userId: ansatt.user_id || null,
      stillingsprosent: ansatt.stillingsprosent,
      totalFeriekrav: Math.round(feriekrav * 10) / 10,
      estimater
    });
  }

  // Sorter tilbake etter navn
  resultater.sort((a, b) => a.ansattNavn.localeCompare(b.ansattNavn, "nb"));

  return resultater;
}

/**
 * Beregner sammendrag av estimater
 */
export function beregnEstimatSammendrag(estimater: AnsattFerieEstimat[]) {
  let totalTimer = 0;
  let antallPerioder = 0;

  for (const ansattEstimat of estimater) {
    for (const estimat of ansattEstimat.estimater) {
      totalTimer += estimat.timer;
      antallPerioder++;
    }
  }

  return {
    antallAnsatte: estimater.length,
    antallPerioder,
    totalTimer: Math.round(totalTimer * 10) / 10
  };
}
