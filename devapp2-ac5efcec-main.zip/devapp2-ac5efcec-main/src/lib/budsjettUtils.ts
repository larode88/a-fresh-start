/**
 * Budsjett-utilities for beregninger
 * 
 * Denne filen inneholder:
 * - Turnus-basert timer-beregning for budsjett
 * - Daglig budsjett-beregning
 * - Aggregering av budsjettdata
 * - Ferie/fravær-integrasjon
 */

import { supabase } from "@/integrations/supabase/client";
import { beregnUkeType, getISOWeekMonth, TurnusType, TurnusResult, UkeType } from "./dateUtils";
import { beregnTimerFraTid } from "./turnusUtils";

// Re-eksporter for enkel tilgang
export { getISOWeekMonth } from "./dateUtils";

// ============= TYPES =============

export type BudsjettArsak = 'arbeid' | 'turnus_fridag' | 'salong_stengt' | 'helligdag' | 'helg' | 'ferie' | 'permisjon' | 'annet';

export interface FravaerPeriode {
  ansatt_id?: string;
  user_id?: string;
  startdato: string;
  sluttdato: string;
  fravaerstype: string;
  status: string;
}

// Interface for ansatt_turnus (den faktiske datakilden)
export interface AnsattTurnusMal {
  id: string;
  ansatt_id: string;
  salon_id: string;
  ukedag: number;
  uke_type: string | null;
  start_tid: string | null;
  slutt_tid: string | null;
  fridag: boolean;
  gyldig_fra: string;
  gyldig_til: string | null;
  pause_minutter: number | null;
  turnus_type?: TurnusType;
}

export interface ApningstidData {
  ukedag: number;
  stengt: boolean;
  apner?: string | null;
  stenger?: string | null;
}

export interface KPIParams {
  effektivitet: number;       // Prosent (f.eks. 70)
  omsetningPerTime: number;   // Kr per time (f.eks. 1200)
  varesalgProsent: number;    // Prosent varesalg (f.eks. 15)
  timerPerDag: number;        // Basis-timer per dag (f.eks. 7.5)
}

export interface DagsBudsjett {
  planlagteTimer: number;
  kundetimer: number;
  behandlingBudsjett: number;
  vareBudsjett: number;
  totaltBudsjett: number;
}

// ============= TURNUS-TIMER BEREGNING =============

/**
 * Beregner timer for en ansatt på en gitt dato basert på turnus fra ansatt_turnus
 * 
 * Sjekker:
 * 1. Om salongen er åpen
 * 2. Om ansatt har turnus-mal for dagen
 * 3. Om ansatt jobber eller har fri
 * 
 * @param ansattId - ID til ansatt (ansatt_id fra ansatte-tabellen)
 * @param dato - Dato å beregne for
 * @param turnusMaler - Alle turnus-maler fra ansatt_turnus
 * @param apningstider - Åpningstider for salongen
 */
export function getTurnusTimerForDag(
  ansattId: string,
  dato: Date,
  turnusMaler: AnsattTurnusMal[],
  apningstider: ApningstidData[]
): TurnusResult {
  const ukedag = dato.getDay() === 0 ? 7 : dato.getDay();
  const datoStr = dato.toISOString().split('T')[0];

  // Sjekk om salongen er åpen
  const apning = apningstider.find(a => a.ukedag === ukedag);
  if (!apning || apning.stengt) {
    return { timer: 0, arsak: 'salong_stengt' };
  }

  // Finn gyldige turnus-maler for denne ansatte
  const gyldige = turnusMaler.filter(m =>
    m.ansatt_id === ansattId &&
    m.gyldig_fra <= datoStr &&
    (!m.gyldig_til || m.gyldig_til >= datoStr)
  );

  if (gyldige.length === 0) {
    return { timer: 0, arsak: 'annet' };
  }

  // Detekter turnus-type fra malene
  const hasUke1 = gyldige.some(m => m.uke_type === 'uke1');
  const hasUke2 = gyldige.some(m => m.uke_type === 'uke2');
  const hasUke3 = gyldige.some(m => m.uke_type === 'uke3');
  const hasPartall = gyldige.some(m => m.uke_type === 'partall');
  const hasOddetall = gyldige.some(m => m.uke_type === 'oddetall');

  let turnusType: TurnusType = 'enkel';
  if (hasUke1 || hasUke2 || hasUke3) {
    turnusType = 'treuke';
  } else if (hasPartall || hasOddetall) {
    turnusType = 'touke';
  }

  // Beregn uke-type basert på turnus-type
  const gyldigFra = new Date(gyldige[0].gyldig_fra);
  const ukeType = beregnUkeType(dato, gyldigFra, turnusType);

  // Finn mal som matcher ukedag og uke-type
  const mal = gyldige.find(m => 
    m.ukedag === ukedag && 
    (m.uke_type === ukeType || m.uke_type === 'alle' || m.uke_type === null)
  );

  if (!mal) {
    return { timer: 0, arsak: 'annet' };
  }

  // Sjekk om det er fridag
  if (mal.fridag) {
    return { timer: 0, arsak: 'turnus_fridag' };
  }

  // Beregn timer fra start/slutt-tid med faktisk pause fra data
  const timer = beregnTimerFraTid(
    mal.start_tid,
    mal.slutt_tid,
    mal.pause_minutter ?? 30
  );

  return { timer, arsak: 'arbeid' };
}

// ============= BUDSJETT-BEREGNING =============

/**
 * Beregner daglig budsjett basert på timer og KPI-parametere
 * 
 * Formler:
 * - kundetimer = planlagteTimer × (effektivitet / 100)
 * - totaltBudsjett = kundetimer × omsetningPerTime
 * - vareBudsjett = totaltBudsjett × (varesalgProsent / 100)
 * - behandlingBudsjett = totaltBudsjett - vareBudsjett
 */
export function beregnDagsBudsjett(
  planlagteTimer: number,
  params: KPIParams
): DagsBudsjett {
  const kundetimer = planlagteTimer * (params.effektivitet / 100);
  const totaltBudsjett = kundetimer * params.omsetningPerTime;
  const vareBudsjett = totaltBudsjett * (params.varesalgProsent / 100);
  const behandlingBudsjett = totaltBudsjett - vareBudsjett;

  return {
    planlagteTimer,
    kundetimer,
    behandlingBudsjett,
    vareBudsjett,
    totaltBudsjett
  };
}

/**
 * Beregner budsjett med turnus-integrasjon og ferie/fravær-sjekk
 * Bruker faktiske timer fra ansatt_turnus og setter 0 timer ved ferie
 */
export function beregnDagsBudsjettMedTurnus(
  ansattId: string,
  dato: Date,
  turnusMaler: AnsattTurnusMal[],
  apningstider: ApningstidData[],
  params: KPIParams,
  stillingsprosent: number = 100,
  fravaerPerioder: FravaerPeriode[] = []
): DagsBudsjett & { arsak: BudsjettArsak } {
  const datoStr = dato.toISOString().split('T')[0];
  
  // Sjekk ferie/fravær først - støtter både ansatt_id og user_id
  const fravaer = fravaerPerioder.find(f => {
    const matchId = (f.ansatt_id === ansattId) || (f.user_id === ansattId);
    return matchId &&
      f.startdato <= datoStr &&
      f.sluttdato >= datoStr &&
      ['godkjent', 'aktiv', 'planlagt', 'avviklet'].includes(f.status);
  });

  if (fravaer) {
    const arsak: BudsjettArsak = fravaer.fravaerstype === 'ferie' ? 'ferie' : 
                                  fravaer.fravaerstype === 'permisjon' ? 'permisjon' : 'annet';
    return {
      planlagteTimer: 0,
      kundetimer: 0,
      behandlingBudsjett: 0,
      vareBudsjett: 0,
      totaltBudsjett: 0,
      arsak
    };
  }

  // Hent timer fra turnus
  const turnusResult = getTurnusTimerForDag(
    ansattId,
    dato,
    turnusMaler,
    apningstider
  );

  // Fallback til standard timer hvis ingen turnus-mal
  const timer = turnusResult.arsak === 'annet'
    ? params.timerPerDag * (stillingsprosent / 100)
    : turnusResult.timer;

  const budsjett = beregnDagsBudsjett(timer, params);

  return {
    ...budsjett,
    arsak: turnusResult.arsak as BudsjettArsak
  };
}

/**
 * Henter ferie/fravær-perioder for en salong i et gitt år
 * Støtter både ansatt_id (primær) og user_id (legacy)
 */
export async function getFravaerForSalong(
  salonId: string,
  year: number
): Promise<FravaerPeriode[]> {
  const startOfYear = `${year}-01-01`;
  const endOfYear = `${year}-12-31`;

  // Hent ferie - inkluder alle relevante statuser
  const { data: ferieData, error: ferieError } = await supabase
    .from("ferie")
    .select("ansatt_id, user_id, startdato, sluttdato, status")
    .eq("salon_id", salonId)
    .gte("sluttdato", startOfYear)
    .lte("startdato", endOfYear)
    .in("status", ["godkjent", "planlagt", "avviklet"]);

  if (ferieError) {
    console.error("Feil ved henting av ferie:", ferieError);
  }

  // Hent fravær
  const { data: fravaerData, error: fravaerError } = await supabase
    .from("fravaer")
    .select("ansatt_id, user_id, startdato, sluttdato, fravaerstype, status")
    .eq("salon_id", salonId)
    .gte("sluttdato", startOfYear)
    .lte("startdato", endOfYear)
    .in("status", ["aktiv", "godkjent"]);

  if (fravaerError) {
    console.error("Feil ved henting av fravær:", fravaerError);
  }

  const result: FravaerPeriode[] = [];

  // Legg til ferie med type 'ferie'
  (ferieData || []).forEach(f => {
    result.push({
      ansatt_id: f.ansatt_id,
      user_id: f.user_id,
      startdato: f.startdato,
      sluttdato: f.sluttdato,
      fravaerstype: 'ferie',
      status: f.status || 'godkjent'
    });
  });

  // Legg til fravær
  (fravaerData || []).forEach(f => {
    result.push({
      ansatt_id: f.ansatt_id,
      user_id: f.user_id,
      startdato: f.startdato,
      sluttdato: f.sluttdato,
      fravaerstype: f.fravaerstype,
      status: f.status || 'aktiv'
    });
  });

  return result;
}

// ============= ÅPNINGSTIDER =============

/**
 * Henter åpningstider for en salong
 */
export async function getApningstider(salonId: string): Promise<ApningstidData[]> {
  const { data, error } = await supabase
    .from("salong_apningstider")
    .select("ukedag, stengt, apner, stenger")
    .eq("salon_id", salonId);

  if (error) {
    console.error("Feil ved henting av åpningstider:", error);
    // Returner standard åpningstider (man-fre åpen)
    return [
      { ukedag: 1, stengt: false },
      { ukedag: 2, stengt: false },
      { ukedag: 3, stengt: false },
      { ukedag: 4, stengt: false },
      { ukedag: 5, stengt: false },
      { ukedag: 6, stengt: true },
      { ukedag: 7, stengt: true },
    ];
  }

  return data || [];
}

/**
 * Henter turnus-maler fra ansatt_turnus for en salong
 * Dette er den faktiske datakilden for turnus (ikke turnus_preferanser som er tom)
 */
export async function getAnsattTurnusMaler(salonId: string): Promise<AnsattTurnusMal[]> {
  const { data, error } = await supabase
    .from("ansatt_turnus")
    .select("*")
    .eq("salon_id", salonId)
    .is("gyldig_til", null);

  if (error) {
    console.error("Feil ved henting av turnus-maler:", error);
    return [];
  }

  return (data || []) as AnsattTurnusMal[];
}

// ============= AGGREGERING =============

/**
 * Aggregerer daglige budsjetter til månedsbudsjett
 */
export function aggregerManedsbudsjett(dagsBudsjetter: DagsBudsjett[]): {
  sumPlanlagteTimer: number;
  sumKundetimer: number;
  sumBehandling: number;
  sumVare: number;
  sumTotal: number;
  antallDager: number;
} {
  return dagsBudsjetter.reduce(
    (acc, dag) => ({
      sumPlanlagteTimer: acc.sumPlanlagteTimer + dag.planlagteTimer,
      sumKundetimer: acc.sumKundetimer + dag.kundetimer,
      sumBehandling: acc.sumBehandling + dag.behandlingBudsjett,
      sumVare: acc.sumVare + dag.vareBudsjett,
      sumTotal: acc.sumTotal + dag.totaltBudsjett,
      antallDager: acc.antallDager + 1
    }),
    {
      sumPlanlagteTimer: 0,
      sumKundetimer: 0,
      sumBehandling: 0,
      sumVare: 0,
      sumTotal: 0,
      antallDager: 0
    }
  );
}

/**
 * Formaterer beløp i norsk format
 */
export function formatBelop(belop: number): string {
  return new Intl.NumberFormat('nb-NO', {
    style: 'currency',
    currency: 'NOK',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(belop);
}
