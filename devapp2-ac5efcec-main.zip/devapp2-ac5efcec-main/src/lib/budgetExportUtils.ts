/**
 * Budget Export Utilities
 * 
 * Provides Excel export functionality for budget data
 */

import * as XLSX from 'xlsx';
import { BudgetWithEmployee } from '@/integrations/supabase/budgetsService';

interface StylistBudgetSummary {
  ansatt_name: string;
  total_behandling: number;
  total_vare: number;
  total_budsjett: number;
  total_kundetimer: number;
}

interface MonthlyBudgetSummary {
  month: number;
  month_name: string;
  behandling: number;
  vare: number;
  total: number;
}

const monthNames = [
  "Januar", "Februar", "Mars", "April", "Mai", "Juni",
  "Juli", "August", "September", "Oktober", "November", "Desember"
];

/**
 * Export budget data to Excel file
 */
export function exportBudgetToExcel(
  budgetData: BudgetWithEmployee[],
  salonName: string,
  versionName: string,
  year: number
): void {
  if (!budgetData || budgetData.length === 0) {
    throw new Error("Ingen budsjettdata å eksportere");
  }

  // Create workbook
  const workbook = XLSX.utils.book_new();

  // === Sheet 1: Summary ===
  const summaryData = createSummaryData(budgetData);
  const summarySheet = XLSX.utils.json_to_sheet(summaryData.map(s => ({
    'Stylist': s.ansatt_name,
    'Behandling (kr)': Math.round(s.total_behandling),
    'Varesalg (kr)': Math.round(s.total_vare),
    'Totalt budsjett (kr)': Math.round(s.total_budsjett),
    'Kundetimer': Math.round(s.total_kundetimer * 10) / 10
  })));
  XLSX.utils.book_append_sheet(workbook, summarySheet, "Oversikt per stylist");

  // === Sheet 2: Monthly breakdown ===
  const monthlyData = createMonthlyData(budgetData);
  const monthlySheet = XLSX.utils.json_to_sheet(monthlyData.map(m => ({
    'Måned': m.month_name,
    'Behandling (kr)': Math.round(m.behandling),
    'Varesalg (kr)': Math.round(m.vare),
    'Totalt (kr)': Math.round(m.total)
  })));
  XLSX.utils.book_append_sheet(workbook, monthlySheet, "Månedlig oversikt");

  // === Sheet 3: Per stylist per month ===
  const detailedData = createDetailedMonthlyData(budgetData);
  const detailedSheet = XLSX.utils.json_to_sheet(detailedData);
  XLSX.utils.book_append_sheet(workbook, detailedSheet, "Detaljer per måned");

  // === Sheet 4: Daily data ===
  const dailyData = budgetData.map(entry => {
    const ansattName = entry.ansatte 
      ? `${entry.ansatte.fornavn}${entry.ansatte.etternavn ? ' ' + entry.ansatte.etternavn : ''}`
      : 'Ukjent';
    return {
      'Dato': entry.dato,
      'Stylist': ansattName,
      'Måned': entry.maned,
      'Uke': entry.uke,
      'Dag': entry.dag,
      'Planlagte timer': entry.planlagte_timer,
      'Kundetimer': entry.kundetimer,
      'Behandling (kr)': entry.behandling_budsjett,
      'Varesalg (kr)': entry.vare_budsjett,
      'Totalt (kr)': entry.totalt_budsjett,
      'Årsak null timer': entry.arsak_null_timer || ''
    };
  });
  const dailySheet = XLSX.utils.json_to_sheet(dailyData);
  XLSX.utils.book_append_sheet(workbook, dailySheet, "Daglig data");

  // Generate filename and download
  const filename = `Budsjett_${salonName.replace(/\s+/g, '_')}_${versionName.replace(/\s+/g, '_')}_${year}.xlsx`;
  XLSX.writeFile(workbook, filename);
}

function createSummaryData(data: BudgetWithEmployee[]): StylistBudgetSummary[] {
  const stylistMap = new Map<string, StylistBudgetSummary>();
  
  data.forEach(entry => {
    const ansattId = entry.ansatt_id;
    if (!ansattId) return;
    
    const ansattName = entry.ansatte 
      ? `${entry.ansatte.fornavn}${entry.ansatte.etternavn ? ' ' + entry.ansatte.etternavn : ''}`
      : 'Ukjent';
    
    if (!stylistMap.has(ansattId)) {
      stylistMap.set(ansattId, {
        ansatt_name: ansattName,
        total_behandling: 0,
        total_vare: 0,
        total_budsjett: 0,
        total_kundetimer: 0
      });
    }
    
    const current = stylistMap.get(ansattId)!;
    current.total_behandling += entry.behandling_budsjett || 0;
    current.total_vare += entry.vare_budsjett || 0;
    current.total_budsjett += entry.totalt_budsjett || 0;
    current.total_kundetimer += entry.kundetimer || 0;
  });

  return Array.from(stylistMap.values())
    .sort((a, b) => b.total_budsjett - a.total_budsjett);
}

function createMonthlyData(data: BudgetWithEmployee[]): MonthlyBudgetSummary[] {
  const monthMap = new Map<number, MonthlyBudgetSummary>();
  
  for (let m = 1; m <= 12; m++) {
    monthMap.set(m, {
      month: m,
      month_name: monthNames[m - 1],
      behandling: 0,
      vare: 0,
      total: 0
    });
  }
  
  data.forEach(entry => {
    const month = entry.maned;
    const current = monthMap.get(month)!;
    current.behandling += entry.behandling_budsjett || 0;
    current.vare += entry.vare_budsjett || 0;
    current.total += entry.totalt_budsjett || 0;
  });

  return Array.from(monthMap.values());
}

function createDetailedMonthlyData(data: BudgetWithEmployee[]): Record<string, any>[] {
  // Group by stylist and month
  const grouped = new Map<string, Map<number, {
    behandling: number;
    vare: number;
    total: number;
    kundetimer: number;
  }>>();

  data.forEach(entry => {
    const ansattName = entry.ansatte 
      ? `${entry.ansatte.fornavn}${entry.ansatte.etternavn ? ' ' + entry.ansatte.etternavn : ''}`
      : 'Ukjent';
    
    if (!grouped.has(ansattName)) {
      grouped.set(ansattName, new Map());
    }
    
    const userMonths = grouped.get(ansattName)!;
    if (!userMonths.has(entry.maned)) {
      userMonths.set(entry.maned, {
        behandling: 0,
        vare: 0,
        total: 0,
        kundetimer: 0
      });
    }
    
    const current = userMonths.get(entry.maned)!;
    current.behandling += entry.behandling_budsjett || 0;
    current.vare += entry.vare_budsjett || 0;
    current.total += entry.totalt_budsjett || 0;
    current.kundetimer += entry.kundetimer || 0;
  });

  // Flatten to array
  const result: Record<string, any>[] = [];
  
  grouped.forEach((months, userName) => {
    months.forEach((values, month) => {
      result.push({
        'Stylist': userName,
        'Måned': monthNames[month - 1],
        'Månedsnummer': month,
        'Behandling (kr)': Math.round(values.behandling),
        'Varesalg (kr)': Math.round(values.vare),
        'Totalt (kr)': Math.round(values.total),
        'Kundetimer': Math.round(values.kundetimer * 10) / 10
      });
    });
  });

  return result.sort((a, b) => {
    const nameCompare = a['Stylist'].localeCompare(b['Stylist']);
    if (nameCompare !== 0) return nameCompare;
    return a['Månedsnummer'] - b['Månedsnummer'];
  });
}