// Ansatt Utilities
// Helper functions for employee management

export type Frisorfunksjon = 'frisor' | 'senior_frisor' | 'laerling';
export type Lederstilling = 'daglig_leder' | 'avdelingsleder' | 'styreleder';
export type AnsattStatus = 'Aktiv' | 'Permisjon' | 'Arkivert';

/**
 * Convert frisorfunksjon enum to display label
 */
export const getFrisorfunksjonLabel = (funksjon: Frisorfunksjon | string | null): string | null => {
  if (!funksjon) return null;
  const map: Record<string, string> = {
    frisor: 'Frisør',
    senior_frisor: 'Senior Frisør',
    laerling: 'Lærling',
  };
  return map[funksjon] || null;
};

/**
 * Convert lederstilling enum to display label
 */
export const getLederstillingLabel = (stilling: Lederstilling | string | null): string | null => {
  if (!stilling) return null;
  const map: Record<string, string> = {
    daglig_leder: 'Daglig leder',
    avdelingsleder: 'Avdelingsleder',
    styreleder: 'Styreleder',
  };
  return map[stilling] || null;
};

/**
 * Get full role display combining frisorfunksjon and lederstilling
 * Example: "Senior Frisør + Avdelingsleder"
 */
export const getFullRolleDisplay = (
  frisorfunksjon: Frisorfunksjon | string | null,
  lederstilling: Lederstilling | string | null
): string => {
  const parts = [
    getFrisorfunksjonLabel(frisorfunksjon),
    getLederstillingLabel(lederstilling),
  ].filter(Boolean);
  return parts.join(' + ') || 'Ingen rolle';
};

/**
 * Get status color for badges and indicators
 */
export const getStatusColor = (status: AnsattStatus | string, provetidTil?: string | Date | null): string => {
  // Check if employee is in probation period (provetid_til is in the future)
  if (status === 'Aktiv' && provetidTil) {
    const provetidDate = new Date(provetidTil);
    if (provetidDate > new Date()) {
      return 'bg-blue-100 text-blue-800 border-blue-200';
    }
  }
  
  const colors: Record<string, string> = {
    Aktiv: 'bg-green-100 text-green-800 border-green-200',
    Permisjon: 'bg-amber-100 text-amber-800 border-amber-200',
    Arkivert: 'bg-gray-100 text-gray-600 border-gray-200',
  };
  return colors[status] || colors.Arkivert;
};

/**
 * Get status label for display
 */
export const getStatusLabel = (status: AnsattStatus | string, provetidTil?: string | Date | null): string => {
  // Check if employee is in probation period (provetid_til is in the future)
  if (status === 'Aktiv' && provetidTil) {
    const provetidDate = new Date(provetidTil);
    if (provetidDate > new Date()) {
      return 'Prøvetid';
    }
  }
  
  const labels: Record<string, string> = {
    Aktiv: 'Aktiv',
    Permisjon: 'Permisjon',
    Arkivert: 'Arkivert',
  };
  return labels[status] || status;
};

/**
 * Calculate ansiennitet as simple number (years)
 */
export const calculateAnsiennitetYears = (
  ansattDato: string | Date | null,
  fagbrevDato?: string | Date | null
): number => {
  const dateToUse = fagbrevDato || ansattDato;
  if (!dateToUse) return 0;
  
  const start = new Date(dateToUse);
  const now = new Date();
  
  let years = now.getFullYear() - start.getFullYear();
  const monthDiff = now.getMonth() - start.getMonth();
  
  if (monthDiff < 0 || (monthDiff === 0 && now.getDate() < start.getDate())) {
    years--;
  }
  
  return Math.max(0, years + (monthDiff >= 0 ? monthDiff / 12 : (12 + monthDiff) / 12));
};

/**
 * Get status badge variant
 */
export const getStatusVariant = (status: AnsattStatus | string, provetidTil?: string | Date | null): 'default' | 'secondary' | 'destructive' | 'outline' => {
  // Check if employee is in probation period (provetid_til is in the future)
  if (status === 'Aktiv' && provetidTil) {
    const provetidDate = new Date(provetidTil);
    if (provetidDate > new Date()) {
      return 'secondary';
    }
  }
  
  const variants: Record<string, 'default' | 'secondary' | 'destructive' | 'outline'> = {
    Aktiv: 'default',
    Permisjon: 'outline',
    Arkivert: 'destructive',
  };
  return variants[status] || 'outline';
};

/**
 * Calculate employment years from start date
 */
export const calculateAnsiennitet = (ansattDato: string | Date | null): {
  years: number;
  months: number;
  display: string;
} => {
  if (!ansattDato) return { years: 0, months: 0, display: '-' };
  
  const start = new Date(ansattDato);
  const now = new Date();
  
  let years = now.getFullYear() - start.getFullYear();
  let months = now.getMonth() - start.getMonth();
  
  if (months < 0) {
    years--;
    months += 12;
  }
  
  if (years === 0) {
    return { years, months, display: `${months} mnd` };
  } else if (months === 0) {
    return { years, months, display: `${years} år` };
  }
  return { years, months, display: `${years} år, ${months} mnd` };
};

/**
 * Calculate age from birth date
 */
export const calculateAge = (fodselsdato: string | Date | null): number | null => {
  if (!fodselsdato) return null;
  
  const birth = new Date(fodselsdato);
  const now = new Date();
  
  let age = now.getFullYear() - birth.getFullYear();
  const monthDiff = now.getMonth() - birth.getMonth();
  
  if (monthDiff < 0 || (monthDiff === 0 && now.getDate() < birth.getDate())) {
    age--;
  }
  
  return age;
};

/**
 * Check if birthday is today
 */
export const isBirthdayToday = (fodselsdato: string | Date | null): boolean => {
  if (!fodselsdato) return false;
  
  const birth = new Date(fodselsdato);
  const now = new Date();
  
  return birth.getMonth() === now.getMonth() && birth.getDate() === now.getDate();
};

/**
 * Check if birthday is tomorrow
 */
export const isBirthdayTomorrow = (fodselsdato: string | Date | null): boolean => {
  if (!fodselsdato) return false;
  
  const birth = new Date(fodselsdato);
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  
  return birth.getMonth() === tomorrow.getMonth() && birth.getDate() === tomorrow.getDate();
};

/**
 * Check if probation period expires within days
 */
export const isProvetidExpiringSoon = (provetidTil: string | Date | null, days: number = 30): boolean => {
  if (!provetidTil) return false;
  
  const provetid = new Date(provetidTil);
  const now = new Date();
  const limit = new Date();
  limit.setDate(limit.getDate() + days);
  
  return provetid > now && provetid <= limit;
};

/**
 * Calculate working hours per week based on stillingsprosent
 */
export const calculateArbeidstidPerUke = (stillingsprosent: number, fullTimeHours: number = 37.5): number => {
  return Number(((fullTimeHours * stillingsprosent) / 100).toFixed(1));
};

/**
 * Calculate annual vacation hours based on feriekrav type
 */
export const calculateFeriekravTimer = (
  feriekravType: 'lovfestet' | 'tariffavtale' | 'utvidet' | string,
  stillingsprosent: number = 100
): number => {
  const baseHours: Record<string, number> = {
    lovfestet: 157.5,    // 4 weeks + 1 day
    tariffavtale: 187.5, // 5 weeks
    utvidet: 225,        // 6 weeks
  };
  
  const base = baseHours[feriekravType] || 157.5;
  return Number(((base * stillingsprosent) / 100).toFixed(1));
};

/**
 * Format name as "Fornavn E." (abbreviated last name)
 */
export const formatShortName = (fornavn: string | null, etternavn: string | null): string => {
  if (!fornavn) return '-';
  if (!etternavn) return fornavn;
  return `${fornavn} ${etternavn.charAt(0)}.`;
};

/**
 * Check if employee is included in budget (has frisorfunksjon)
 */
export const isIncludedInBudget = (frisorfunksjon: Frisorfunksjon | string | null): boolean => {
  return frisorfunksjon !== null;
};

/**
 * Check if employee has manager role
 */
export const hasManagerRole = (lederstilling: Lederstilling | string | null): boolean => {
  return lederstilling !== null;
};
