// Data Quality Utilities
// Traffic light system for employee data completeness

export type DataQualityStatus = 'complete' | 'warning' | 'critical';

export interface DataQualityResult {
  status: DataQualityStatus;
  icon: '🟢' | '🟡' | '🔴';
  message: string;
  missingFields: string[];
  warnings: string[];
  score: number; // 0-100
}

export interface Ansatt {
  id: string;
  fornavn: string | null;
  etternavn: string | null;
  telefon: string | null;
  epost: string | null;
  fodselsdato: string | null;
  adresse: string | null;
  postnummer: string | null;
  poststed: string | null;
  salong_id: string | null;
  ansatt_dato: string | null;
  stillingsprosent: number | null;
  frisorfunksjon: string | null;
  lederstilling: string | null;
  provetid_til: string | null;
  lonnstype_enum: string | null;
  timesats: number | null;
  fastlonn: number | null;
  fagbrev_dato: string | null;
  [key: string]: unknown;
}

export interface Sertifisering {
  id: string;
  navn: string;
  utloper_dato: string | null;
  status: string | null;
}

export interface Dokument {
  id: string;
  dokument_type: string;
  signatur_status: string | null;
}

/**
 * Check personalia data quality
 */
export const checkPersonaliaQuality = (ansatt: Ansatt): DataQualityResult => {
  const missingFields: string[] = [];
  const warnings: string[] = [];
  
  // Critical fields
  if (!ansatt.fornavn) missingFields.push('Fornavn');
  if (!ansatt.telefon) missingFields.push('Telefon');
  if (!ansatt.epost) missingFields.push('E-post');
  
  // Important fields
  if (!ansatt.fodselsdato) warnings.push('Fødselsdato');
  if (!ansatt.adresse) warnings.push('Adresse');
  if (!ansatt.postnummer) warnings.push('Postnummer');
  if (!ansatt.poststed) warnings.push('Poststed');
  
  const totalFields = 7;
  const completedFields = totalFields - missingFields.length - warnings.length;
  const score = Math.round((completedFields / totalFields) * 100);
  
  if (missingFields.length > 0) {
    return {
      status: 'critical',
      icon: '🔴',
      message: `${missingFields.length} kritiske felt mangler`,
      missingFields,
      warnings,
      score,
    };
  }
  
  if (warnings.length > 0) {
    return {
      status: 'warning',
      icon: '🟡',
      message: `${warnings.length} felt mangler`,
      missingFields,
      warnings,
      score,
    };
  }
  
  return {
    status: 'complete',
    icon: '🟢',
    message: 'Alt komplett',
    missingFields,
    warnings,
    score: 100,
  };
};

/**
 * Check stilling (employment) data quality
 */
export const checkStillingQuality = (ansatt: Ansatt): DataQualityResult => {
  const missingFields: string[] = [];
  const warnings: string[] = [];
  
  // Critical fields
  if (!ansatt.salong_id) missingFields.push('Salong');
  if (!ansatt.ansatt_dato) missingFields.push('Ansettelsesdato');
  
  // Role check - at least one role should be set
  if (!ansatt.frisorfunksjon && !ansatt.lederstilling) {
    missingFields.push('Rolle (frisørfunksjon eller lederstilling)');
  }
  
  // Important fields
  if (ansatt.stillingsprosent === null || ansatt.stillingsprosent === undefined) {
    warnings.push('Stillingsprosent');
  }
  
  // Probation period warning
  if (ansatt.provetid_til) {
    const provetid = new Date(ansatt.provetid_til);
    const now = new Date();
    const thirtyDaysFromNow = new Date();
    thirtyDaysFromNow.setDate(thirtyDaysFromNow.getDate() + 30);
    
    if (provetid > now && provetid <= thirtyDaysFromNow) {
      warnings.push('Prøvetid utløper snart');
    }
  }
  
  const totalFields = 4;
  const completedFields = totalFields - missingFields.length - warnings.length;
  const score = Math.round((completedFields / totalFields) * 100);
  
  if (missingFields.length > 0) {
    return {
      status: 'critical',
      icon: '🔴',
      message: `${missingFields.length} kritiske felt mangler`,
      missingFields,
      warnings,
      score,
    };
  }
  
  if (warnings.length > 0) {
    return {
      status: 'warning',
      icon: '🟡',
      message: `${warnings.length} advarsler`,
      missingFields,
      warnings,
      score,
    };
  }
  
  return {
    status: 'complete',
    icon: '🟢',
    message: 'Alt komplett',
    missingFields,
    warnings,
    score: 100,
  };
};

/**
 * Check kompetanse (certifications) data quality
 */
export const checkKompetanseQuality = (
  ansatt: Ansatt,
  sertifiseringer: Sertifisering[] = []
): DataQualityResult => {
  const missingFields: string[] = [];
  const warnings: string[] = [];
  
  // Check for expired certifications
  const now = new Date();
  const thirtyDaysFromNow = new Date();
  thirtyDaysFromNow.setDate(thirtyDaysFromNow.getDate() + 30);
  
  sertifiseringer.forEach((sert) => {
    if (sert.utloper_dato) {
      const expiry = new Date(sert.utloper_dato);
      if (expiry < now) {
        missingFields.push(`${sert.navn} utløpt`);
      } else if (expiry <= thirtyDaysFromNow) {
        warnings.push(`${sert.navn} utløper snart`);
      }
    }
  });
  
  // Check fagbrev for frisører
  if (ansatt.frisorfunksjon && ansatt.frisorfunksjon !== 'laerling' && !ansatt.fagbrev_dato) {
    warnings.push('Fagbrevdato');
  }
  
  const totalChecks = sertifiseringer.length + 1;
  const issueCount = missingFields.length + warnings.length;
  const score = Math.max(0, Math.round(((totalChecks - issueCount) / Math.max(totalChecks, 1)) * 100));
  
  if (missingFields.length > 0) {
    return {
      status: 'critical',
      icon: '🔴',
      message: `${missingFields.length} sertifiseringer utløpt`,
      missingFields,
      warnings,
      score,
    };
  }
  
  if (warnings.length > 0) {
    return {
      status: 'warning',
      icon: '🟡',
      message: `${warnings.length} advarsler`,
      missingFields,
      warnings,
      score,
    };
  }
  
  return {
    status: 'complete',
    icon: '🟢',
    message: sertifiseringer.length > 0 ? 'Alt gyldig' : 'Ingen sertifiseringer',
    missingFields,
    warnings,
    score: 100,
  };
};

/**
 * Check lønn (salary) data quality - HR only
 */
export const checkLonnQuality = (ansatt: Ansatt): DataQualityResult => {
  const missingFields: string[] = [];
  const warnings: string[] = [];
  
  // Check lønnstype
  if (!ansatt.lonnstype_enum) {
    missingFields.push('Lønnstype');
  } else {
    // Check relevant salary fields based on type
    const type = ansatt.lonnstype_enum;
    if ((type === 'timelonn' || type === 'timelonn_provisjon') && !ansatt.timesats) {
      missingFields.push('Timesats');
    }
    if ((type === 'fastlonn' || type === 'provisjon') && !ansatt.fastlonn) {
      missingFields.push('Fastlønn');
    }
  }
  
  const totalFields = 2;
  const completedFields = totalFields - missingFields.length;
  const score = Math.round((completedFields / totalFields) * 100);
  
  if (missingFields.length > 0) {
    return {
      status: 'critical',
      icon: '🔴',
      message: `${missingFields.length} felt mangler`,
      missingFields,
      warnings,
      score,
    };
  }
  
  return {
    status: 'complete',
    icon: '🟢',
    message: 'Lønn konfigurert',
    missingFields,
    warnings,
    score: 100,
  };
};

/**
 * Check dokumenter (documents) data quality
 */
export const checkDokumenterQuality = (dokumenter: Dokument[] = []): DataQualityResult => {
  const missingFields: string[] = [];
  const warnings: string[] = [];
  
  // Check for required documents
  const hasArbeidskontrakt = dokumenter.some(d => d.dokument_type === 'arbeidskontrakt');
  if (!hasArbeidskontrakt) {
    missingFields.push('Arbeidskontrakt');
  }
  
  // Check for pending signatures
  const pendingSignatures = dokumenter.filter(d => d.signatur_status === 'venter_signatur');
  if (pendingSignatures.length > 0) {
    warnings.push(`${pendingSignatures.length} dokumenter venter signatur`);
  }
  
  // Check for rejected signatures
  const rejectedSignatures = dokumenter.filter(d => d.signatur_status === 'avvist');
  if (rejectedSignatures.length > 0) {
    missingFields.push(`${rejectedSignatures.length} signaturer avvist`);
  }
  
  const score = missingFields.length > 0 ? 50 : (warnings.length > 0 ? 75 : 100);
  
  if (missingFields.length > 0) {
    return {
      status: 'critical',
      icon: '🔴',
      message: missingFields[0],
      missingFields,
      warnings,
      score,
    };
  }
  
  if (warnings.length > 0) {
    return {
      status: 'warning',
      icon: '🟡',
      message: warnings[0],
      missingFields,
      warnings,
      score,
    };
  }
  
  return {
    status: 'complete',
    icon: '🟢',
    message: dokumenter.length > 0 ? 'Alle dokumenter i orden' : 'Ingen dokumenter',
    missingFields,
    warnings,
    score: 100,
  };
};

/**
 * Get overall data quality aggregating all checks
 */
export const getOverallDataQuality = (
  ansatt: Ansatt,
  sertifiseringer: Sertifisering[] = [],
  dokumenter: Dokument[] = [],
  includeLonn: boolean = false
): DataQualityResult => {
  const personalia = checkPersonaliaQuality(ansatt);
  const stilling = checkStillingQuality(ansatt);
  const kompetanse = checkKompetanseQuality(ansatt, sertifiseringer);
  const dokumenterQuality = checkDokumenterQuality(dokumenter);
  
  const checks = [personalia, stilling, kompetanse, dokumenterQuality];
  
  if (includeLonn) {
    checks.push(checkLonnQuality(ansatt));
  }
  
  const allMissingFields = checks.flatMap(c => c.missingFields);
  const allWarnings = checks.flatMap(c => c.warnings);
  const avgScore = Math.round(checks.reduce((sum, c) => sum + c.score, 0) / checks.length);
  
  const hasCritical = checks.some(c => c.status === 'critical');
  const hasWarning = checks.some(c => c.status === 'warning');
  
  if (hasCritical) {
    return {
      status: 'critical',
      icon: '🔴',
      message: `${allMissingFields.length} kritiske felt mangler`,
      missingFields: allMissingFields,
      warnings: allWarnings,
      score: avgScore,
    };
  }
  
  if (hasWarning) {
    return {
      status: 'warning',
      icon: '🟡',
      message: `${allWarnings.length} advarsler`,
      missingFields: allMissingFields,
      warnings: allWarnings,
      score: avgScore,
    };
  }
  
  return {
    status: 'complete',
    icon: '🟢',
    message: 'Alt komplett',
    missingFields: [],
    warnings: [],
    score: 100,
  };
};

/**
 * Get quality color classes for UI
 */
export const getQualityColorClasses = (status: DataQualityStatus): {
  bg: string;
  text: string;
  border: string;
  ring: string;
} => {
  const colors: Record<DataQualityStatus, { bg: string; text: string; border: string; ring: string }> = {
    complete: {
      bg: 'bg-green-50',
      text: 'text-green-700',
      border: 'border-green-200',
      ring: 'ring-green-500',
    },
    warning: {
      bg: 'bg-amber-50',
      text: 'text-amber-700',
      border: 'border-amber-200',
      ring: 'ring-amber-500',
    },
    critical: {
      bg: 'bg-red-50',
      text: 'text-red-700',
      border: 'border-red-200',
      ring: 'ring-red-500',
    },
  };
  return colors[status];
};
