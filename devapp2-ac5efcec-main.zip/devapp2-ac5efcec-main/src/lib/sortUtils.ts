/**
 * Standardiserte sorteringsfunksjoner for hele applikasjonen
 * 
 * SORTERINGSREGLER:
 * - Personer: Alfabetisk etter etternavn, deretter fornavn
 * - Steder (salonger, distrikter): Alfabetisk etter navn
 * - Tidsbaserte data: Kronologisk (nyeste først for logger, eldste først for planlegging)
 * - Prioritetsbaserte: Etter prioritet/alvorlighet
 * - Alle norske lister bruker locale "nb" for korrekt håndtering av Æ, Ø, Å
 */

/**
 * Sammenligner to strenger med norsk locale
 */
export const compareNorwegian = (a: string, b: string): number => {
  return (a || '').localeCompare(b || '', 'nb');
};

/**
 * Sorterer en liste etter etternavn, deretter fornavn
 */
export const sortByLastNameFirst = <T extends { etternavn?: string | null; fornavn?: string | null }>(
  list: T[]
): T[] => {
  return [...list].sort((a, b) => {
    const lastNameCompare = compareNorwegian(a.etternavn || '', b.etternavn || '');
    if (lastNameCompare !== 0) return lastNameCompare;
    return compareNorwegian(a.fornavn || '', b.fornavn || '');
  });
};

/**
 * Sorterer en liste etter fornavn, deretter etternavn
 */
export const sortByFirstNameFirst = <T extends { fornavn?: string | null; etternavn?: string | null }>(
  list: T[]
): T[] => {
  return [...list].sort((a, b) => {
    const firstNameCompare = compareNorwegian(a.fornavn || '', b.fornavn || '');
    if (firstNameCompare !== 0) return firstNameCompare;
    return compareNorwegian(a.etternavn || '', b.etternavn || '');
  });
};

/**
 * Sorterer en liste etter et navnefelt (for steder, kategorier osv.)
 */
export const sortByName = <T extends Record<string, any>>(
  list: T[],
  field: string = 'name'
): T[] => {
  return [...list].sort((a, b) => compareNorwegian(a[field] || '', b[field] || ''));
};

/**
 * Sorterer en liste etter dato
 * @param ascending - true for eldste først, false for nyeste først
 */
export const sortByDate = <T extends Record<string, any>>(
  list: T[],
  field: string,
  ascending: boolean = true
): T[] => {
  return [...list].sort((a, b) => {
    const dateA = new Date(a[field] || 0).getTime();
    const dateB = new Date(b[field] || 0).getTime();
    return ascending ? dateA - dateB : dateB - dateA;
  });
};

/**
 * Sorterer en liste etter prioritet (høyeste først)
 */
export const sortByPriority = <T extends Record<string, any>>(
  list: T[],
  field: string = 'priority'
): T[] => {
  return [...list].sort((a, b) => (b[field] || 0) - (a[field] || 0));
};

/**
 * Sorterer en liste etter flere felter i rekkefølge
 */
export const sortByMultiple = <T extends Record<string, any>>(
  list: T[],
  fields: Array<{ field: string; ascending?: boolean; type?: 'string' | 'number' | 'date' }>
): T[] => {
  return [...list].sort((a, b) => {
    for (const { field, ascending = true, type = 'string' } of fields) {
      let comparison = 0;
      
      if (type === 'date') {
        const dateA = new Date(a[field] || 0).getTime();
        const dateB = new Date(b[field] || 0).getTime();
        comparison = dateA - dateB;
      } else if (type === 'number') {
        comparison = (a[field] || 0) - (b[field] || 0);
      } else {
        comparison = compareNorwegian(a[field] || '', b[field] || '');
      }
      
      if (comparison !== 0) {
        return ascending ? comparison : -comparison;
      }
    }
    return 0;
  });
};

/**
 * Sorterer ansatte etter fullt navn (for brukere med 'name' felt)
 */
export const sortByFullName = <T extends { name?: string | null }>(list: T[]): T[] => {
  return [...list].sort((a, b) => compareNorwegian(a.name || '', b.name || ''));
};
