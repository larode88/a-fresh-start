/**
 * Sentraliserte dato-utilities for ISO 8601-beregninger
 * 
 * Denne filen er SINGLE SOURCE OF TRUTH for:
 * - ISO-ukenummer
 * - ISO-uke-måned beregning
 * - Uke-type beregning (partall/oddetall/uke1-4)
 */

import { getISOWeek, differenceInWeeks } from "date-fns";

// ============= TYPES =============

export type UkeType = 'alle' | 'partall' | 'oddetall' | 'uke1' | 'uke2' | 'uke3';
export type TurnusType = 'enkel' | 'touke' | 'treuke';

export interface TurnusResult {
  timer: number;
  arsak: 'salong_stengt' | 'turnus_fridag' | 'arbeid' | 'annet' | null;
}

// ============= ISO WEEK NUMBER =============

/**
 * Hent ISO 8601-ukenummer for en dato
 * Bruker date-fns for korrekt beregning
 * 
 * @param date - Dato å beregne ukenummer for
 * @returns ISO 8601 ukenummer (1-53)
 */
export function getISOWeekNumber(date: Date): number {
  return getISOWeek(date);
}

// ============= ISO UKE-MÅNED =============

/**
 * Beregn ISO-uke-måned (måned der torsdag er)
 * 
 * Ifølge ISO 8601 tilhører en uke den måneden der torsdagen faller.
 * Dette er viktig for korrekt månedlig aggregering av ukebaserte data.
 * 
 * @param date - Dato å beregne ISO-uke-måned for
 * @returns Måned (1-12) basert på torsdagen i uken
 */
export function getISOWeekMonth(date: Date): number {
  const dayOfWeek = date.getDay();
  const thursday = new Date(date);
  // Beregn dager til torsdag (4 = torsdag, 0 = søndag → 7)
  const daysToThursday = 4 - (dayOfWeek === 0 ? 7 : dayOfWeek);
  thursday.setDate(thursday.getDate() + daysToThursday);
  return thursday.getMonth() + 1;
}

// ============= UKE-TYPE BEREGNING =============

/**
 * Beregner hvilken uke-type en dato tilhører basert på turnus-type
 * 
 * For enkel: Returnerer alltid 'alle'
 * For touke: Partall/oddetall basert på ISO-ukenummer
 * For treuke: Uke1/2/3 basert på antall uker siden gyldig_fra
 * 
 * VIKTIG: Bruker date-fns getISOWeek for korrekt ISO 8601-beregning
 * 
 * @param dato - Dato å beregne uke-type for
 * @param gyldigFra - Startdato for turnusmalen (brukes for treuke)
 * @param turnusType - Type turnus ('enkel', 'touke', 'treuke')
 * @returns UkeType ('alle', 'partall', 'oddetall', 'uke1', 'uke2', 'uke3')
 */
export function beregnUkeType(
  dato: Date,
  gyldigFra: Date,
  turnusType: TurnusType
): UkeType {
  if (turnusType === 'enkel') {
    return 'alle';
  }
  
  if (turnusType === 'touke') {
    const isoWeek = getISOWeek(dato);
    // Invertert logikk - ISO-partall skal mappe til 'oddetall' og vice versa
    return isoWeek % 2 === 0 ? 'oddetall' : 'partall';
  }
  
  // treuke (default)
  const ukerSidenStart = Math.abs(differenceInWeeks(dato, gyldigFra));
  const rotasjonIndex = ukerSidenStart % 3;
  const ukeTyper: UkeType[] = ['uke1', 'uke2', 'uke3'];
  return ukeTyper[rotasjonIndex];
}

/**
 * Konverterer JS Date.getDay() (0=søndag) til ISO ukedag (1=mandag, 7=søndag)
 */
export function getISOUkedag(dato: Date): number {
  const jsDay = dato.getDay();
  return jsDay === 0 ? 7 : jsDay;
}
