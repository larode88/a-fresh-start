/**
 * Dynamic greeting utilities for Norwegian context
 * Handles time of day, cultural seasons, holidays, periods, and birthdays
 */

interface GreetingResult {
  text: string;
  emoji: string;
}

// Norwegian fixed holidays (day-month format)
const fixedHolidays: Record<string, GreetingResult> = {
  // Nyttår
  '1-1': { text: 'Godt nyttår', emoji: '🎉' },
  
  // Valentinsdag
  '14-2': { text: 'God dag', emoji: '💕' },
  
  // Arbeidernes dag
  '1-5': { text: 'God 1. mai', emoji: '🎈' },
  
  // Grunnlovsdag
  '17-5': { text: 'Gratulerer med dagen', emoji: '🇳🇴' },
  
  // Sankthansaften
  '23-6': { text: 'God sankthansaften', emoji: '🔥' },
  
  // Halloween
  '31-10': { text: 'God halloween', emoji: '🎃' },
  
  // Luciadagen
  '13-12': { text: 'God luciadag', emoji: '✨' },
  
  // Lille julaften
  '23-12': { text: 'God lille julaften', emoji: '🎁' },
  
  // Jul
  '24-12': { text: 'God jul', emoji: '🎄' },
  '25-12': { text: 'God jul', emoji: '🎄' },
  '26-12': { text: 'God jul', emoji: '🎄' },
  
  // Nyttårsaften
  '31-12': { text: 'Godt nytt år', emoji: '🎆' },
};

// Calculate Easter Sunday using Anonymous Gregorian algorithm
function getEasterDate(year: number): Date {
  const a = year % 19;
  const b = Math.floor(year / 100);
  const c = year % 100;
  const d = Math.floor(b / 4);
  const e = b % 4;
  const f = Math.floor((b + 8) / 25);
  const g = Math.floor((b - f + 1) / 3);
  const h = (19 * a + b - d - g + 15) % 30;
  const i = Math.floor(c / 4);
  const k = c % 4;
  const l = (32 + 2 * e + 2 * i - h - k) % 7;
  const m = Math.floor((a + 11 * h + 22 * l) / 451);
  const month = Math.floor((h + l - 7 * m + 114) / 31);
  const day = ((h + l - 7 * m + 114) % 31) + 1;
  return new Date(year, month - 1, day);
}

// Get Nth Sunday of a month
function getNthSundayOfMonth(year: number, month: number, n: number): Date {
  const firstDay = new Date(year, month - 1, 1);
  const dayOfWeek = firstDay.getDay();
  const daysUntilSunday = (7 - dayOfWeek) % 7;
  const firstSunday = 1 + daysUntilSunday;
  const nthSunday = firstSunday + (n - 1) * 7;
  return new Date(year, month - 1, nthSunday);
}

// Get Advent Sundays (4 Sundays before Christmas)
function getAdventSundays(year: number): Date[] {
  const christmas = new Date(year, 11, 25); // December 25
  const christmasDayOfWeek = christmas.getDay();
  
  // Find the Sunday before or on Christmas
  const daysToSubtract = christmasDayOfWeek === 0 ? 7 : christmasDayOfWeek;
  const fourthAdvent = new Date(year, 11, 25 - daysToSubtract);
  
  const advents: Date[] = [];
  for (let i = 3; i >= 0; i--) {
    const advent = new Date(fourthAdvent);
    advent.setDate(fourthAdvent.getDate() - (i * 7));
    advents.push(advent);
  }
  return advents;
}

// Get moving holidays based on Easter and other calculations
function getMovingHolidays(year: number): Map<string, GreetingResult> {
  const easter = getEasterDate(year);
  const holidays = new Map<string, GreetingResult>();
  
  // Fastelavn (49 days before Easter, Sunday)
  const fastelavn = new Date(easter);
  fastelavn.setDate(easter.getDate() - 49);
  holidays.set(`${fastelavn.getDate()}-${fastelavn.getMonth() + 1}`, { text: 'God fastelavn', emoji: '🥐' });
  
  // Palmesøndag (7 days before Easter)
  const palmSunday = new Date(easter);
  palmSunday.setDate(easter.getDate() - 7);
  holidays.set(`${palmSunday.getDate()}-${palmSunday.getMonth() + 1}`, { text: 'God palmesøndag', emoji: '🌿' });
  
  // Skjærtorsdag (3 days before Easter)
  const maundyThursday = new Date(easter);
  maundyThursday.setDate(easter.getDate() - 3);
  holidays.set(`${maundyThursday.getDate()}-${maundyThursday.getMonth() + 1}`, { text: 'God påske', emoji: '🐣' });
  
  // Langfredag (2 days before Easter)
  const goodFriday = new Date(easter);
  goodFriday.setDate(easter.getDate() - 2);
  holidays.set(`${goodFriday.getDate()}-${goodFriday.getMonth() + 1}`, { text: 'God påske', emoji: '🐣' });
  
  // Påskeaften (1 day before Easter)
  const easterSaturday = new Date(easter);
  easterSaturday.setDate(easter.getDate() - 1);
  holidays.set(`${easterSaturday.getDate()}-${easterSaturday.getMonth() + 1}`, { text: 'God påske', emoji: '🐣' });
  
  // Første påskedag
  holidays.set(`${easter.getDate()}-${easter.getMonth() + 1}`, { text: 'God påske', emoji: '🐣' });
  
  // Andre påskedag (1 day after Easter)
  const easterMonday = new Date(easter);
  easterMonday.setDate(easter.getDate() + 1);
  holidays.set(`${easterMonday.getDate()}-${easterMonday.getMonth() + 1}`, { text: 'God påske', emoji: '🐣' });
  
  // Kristi himmelfartsdag (39 days after Easter)
  const ascension = new Date(easter);
  ascension.setDate(easter.getDate() + 39);
  holidays.set(`${ascension.getDate()}-${ascension.getMonth() + 1}`, { text: 'God Kristi himmelfartsdag', emoji: '✨' });
  
  // Pinse (49-50 days after Easter)
  const pentecost = new Date(easter);
  pentecost.setDate(easter.getDate() + 49);
  holidays.set(`${pentecost.getDate()}-${pentecost.getMonth() + 1}`, { text: 'God pinse', emoji: '🌿' });
  
  const pentecostMonday = new Date(easter);
  pentecostMonday.setDate(easter.getDate() + 50);
  holidays.set(`${pentecostMonday.getDate()}-${pentecostMonday.getMonth() + 1}`, { text: 'God pinse', emoji: '🌿' });
  
  // Morsdag (2. søndag i februar)
  const mothersDay = getNthSundayOfMonth(year, 2, 2);
  holidays.set(`${mothersDay.getDate()}-${mothersDay.getMonth() + 1}`, { text: 'God morsdag', emoji: '💐' });
  
  // Farsdag (2. søndag i november)
  const fathersDay = getNthSundayOfMonth(year, 11, 2);
  holidays.set(`${fathersDay.getDate()}-${fathersDay.getMonth() + 1}`, { text: 'God farsdag', emoji: '👔' });
  
  // Adventssøndager
  const adventSundays = getAdventSundays(year);
  adventSundays.forEach((advent, index) => {
    const key = `${advent.getDate()}-${advent.getMonth() + 1}`;
    // Don't override if already a more specific holiday (like Luciadag on a Sunday)
    if (!holidays.has(key) && !fixedHolidays[key]) {
      holidays.set(key, { text: `God ${index + 1}. advent`, emoji: '🕯️' });
    }
  });
  
  return holidays;
}

// Get period-based greetings (førjulstid, romjul)
function getPeriodGreeting(day: number, month: number): GreetingResult | null {
  // Romjula: 27-30. desember
  if (month === 12 && day >= 27 && day <= 30) {
    return { text: 'God romjul', emoji: '⭐' };
  }
  
  // Førjulstid: 1-22. desember (not on specific holidays like Luciadag)
  if (month === 12 && day >= 1 && day <= 22) {
    return { text: 'God førjulstid', emoji: '🎄' };
  }
  
  return null;
}

function getSpecialDayGreeting(day: number, month: number, year: number): GreetingResult | null {
  const key = `${day}-${month}`;
  
  // Check fixed holidays first
  if (fixedHolidays[key]) {
    return fixedHolidays[key];
  }
  
  // Check moving holidays
  const movingHolidays = getMovingHolidays(year);
  if (movingHolidays.has(key)) {
    return movingHolidays.get(key)!;
  }
  
  // Check period-based greetings
  const periodGreeting = getPeriodGreeting(day, month);
  if (periodGreeting) {
    return periodGreeting;
  }
  
  return null;
}

function getTimeGreeting(hour: number): string {
  if (hour >= 5 && hour < 10) return 'God morgen';
  if (hour >= 10 && hour < 12) return 'God formiddag';
  if (hour >= 12 && hour < 18) return 'God dag';
  if (hour >= 18 && hour < 22) return 'God kveld';
  return 'God natt';
}

// Cultural season emoji (not astronomical)
function getCulturalSeasonEmoji(month: number): string {
  // Desember = Jul 🎄
  if (month === 12) return '🎄';
  // Januar-Februar = Vinter ❄️
  if (month === 1 || month === 2) return '❄️';
  // Mars-Mai = Vår 🌸
  if (month >= 3 && month <= 5) return '🌸';
  // Juni-August = Sommer ☀️
  if (month >= 6 && month <= 8) return '☀️';
  // September-November = Høst 🍂
  return '🍂';
}

function isBirthday(birthDate: string | null | undefined, today: Date): boolean {
  if (!birthDate) return false;
  
  const bday = new Date(birthDate);
  return bday.getDate() === today.getDate() && bday.getMonth() === today.getMonth();
}

export function getGreeting(firstName?: string | null, birthDate?: string | null): string {
  const now = new Date();
  const hour = now.getHours();
  const day = now.getDate();
  const month = now.getMonth() + 1;
  const year = now.getFullYear();
  
  const name = firstName || 'deg';
  
  // Priority 1: Birthday (highest priority)
  if (isBirthday(birthDate, now)) {
    return `Gratulerer med dagen, ${name}! 🎂🎉`;
  }
  
  // Priority 2: Special days/holidays (fixed, moving, and periods)
  const specialDay = getSpecialDayGreeting(day, month, year);
  if (specialDay) {
    return `${specialDay.text}, ${name}! ${specialDay.emoji}`;
  }
  
  // Priority 3: Time of day + cultural season
  const timeGreeting = getTimeGreeting(hour);
  const seasonEmoji = getCulturalSeasonEmoji(month);
  
  return `${timeGreeting}, ${name} ${seasonEmoji}`;
}
