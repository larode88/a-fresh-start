import type { BonusRule, NormalizedSale, Produkttype } from "@/integrations/supabase/bonusService";

// =============================================
// PERIOD UTILITIES
// =============================================

export function getCurrentPeriod(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
}

export function getPreviousPeriod(period: string): string {
  const [year, month] = period.split('-').map(Number);
  if (month === 1) {
    return `${year - 1}-12`;
  }
  return `${year}-${String(month - 1).padStart(2, '0')}`;
}

export function getQuarterFromPeriod(period: string): string {
  const [year, month] = period.split('-').map(Number);
  const quarter = Math.ceil(month / 3);
  return `${year}-Q${quarter}`;
}

export function getPeriodsInRange(startPeriod: string, endPeriod: string): string[] {
  const periods: string[] = [];
  let [year, month] = startPeriod.split('-').map(Number);
  const [endYear, endMonth] = endPeriod.split('-').map(Number);
  
  while (year < endYear || (year === endYear && month <= endMonth)) {
    periods.push(`${year}-${String(month).padStart(2, '0')}`);
    month++;
    if (month > 12) {
      month = 1;
      year++;
    }
  }
  
  return periods;
}

export function formatPeriodDisplay(period: string): string {
  const [year, month] = period.split('-');
  const monthNames = [
    'Januar', 'Februar', 'Mars', 'April', 'Mai', 'Juni',
    'Juli', 'August', 'September', 'Oktober', 'November', 'Desember'
  ];
  return `${monthNames[parseInt(month) - 1]} ${year}`;
}

// =============================================
// RULE MATCHING
// =============================================

export interface AppliedRule {
  rule: BonusRule;
  turnover: number;
  bonusAmount: number;
  type: 'loyalty' | 'return';
}

/**
 * Find the most applicable rule for a sale based on priority:
 * 1. Product Group + Brand + Supplier (highest specificity)
 * 2. Brand + Supplier
 * 3. Supplier only (lowest specificity)
 */
export function findApplicableRules(
  sale: NormalizedSale,
  rules: BonusRule[],
  saleDate: Date = new Date()
): BonusRule[] {
  // Filter to active, valid rules for this supplier
  const validRules = rules.filter(rule => {
    if (!rule.is_active) return false;
    if (rule.supplier_id !== sale.supplier_id) return false;
    
    const validFrom = new Date(rule.valid_from);
    const validTo = rule.valid_to ? new Date(rule.valid_to) : null;
    
    if (saleDate < validFrom) return false;
    if (validTo && saleDate > validTo) return false;
    
    // Check turnover thresholds
    const turnover = sale.delta_turnover ?? sale.turnover;
    if (rule.min_turnover && turnover < rule.min_turnover) return false;
    if (rule.max_turnover && turnover > rule.max_turnover) return false;
    
    // Check produkttype match
    if (rule.produkttype && sale.rapporteringstype) {
      const saleType = sale.rapporteringstype;
      if (rule.produkttype === 'kjemi' && saleType !== 'kjemi') return false;
      if (rule.produkttype === 'produkt' && saleType !== 'produkt') return false;
      // 'begge' matches everything
    }
    
    return true;
  });
  
  // Find best match
  const bestRule = findBestMatchingRule(sale, validRules);
  return bestRule ? [bestRule] : [];
}

function findBestMatchingRule(sale: NormalizedSale, rules: BonusRule[]): BonusRule | null {
  if (rules.length === 0) return null;
  
  // Score each rule by specificity
  const scoredRules = rules.map(rule => {
    let score = rule.priority * 1000; // Priority is primary
    
    // Produkttype match: +150 (highest specificity after priority)
    if (rule.produkttype) {
      const saleRapporteringstype = sale.rapporteringstype;
      if (rule.produkttype === saleRapporteringstype) {
        score += 150;
      } else if (rule.produkttype === 'begge') {
        score += 50; // Partial match
      }
    }
    
    // Product group match: +100
    if (rule.product_group && rule.product_group === sale.product_group) {
      score += 100;
    } else if (rule.product_group && rule.product_group !== sale.product_group) {
      return { rule, score: -1 }; // Doesn't match, exclude
    }
    
    // Brand match: +50
    if (rule.brand_id && rule.brand_id === sale.brand_id) {
      score += 50;
    } else if (rule.brand_id && rule.brand_id !== sale.brand_id) {
      return { rule, score: -1 }; // Doesn't match, exclude
    }
    
    return { rule, score };
  }).filter(r => r.score >= 0);
  
  if (scoredRules.length === 0) return null;
  
  // Sort by score descending and return best match
  scoredRules.sort((a, b) => b.score - a.score);
  return scoredRules[0].rule;
}

// =============================================
// BONUS CALCULATION
// =============================================

export interface CalculationResult {
  salon_id: string;
  supplier_id: string;
  period: string;
  totalTurnover: number;
  loyaltyBonus: number;
  returnCommission: number;
  totalBonus: number;
  appliedRules: AppliedRule[];
  details: SaleCalculation[];
}

export interface SaleCalculation {
  sale: NormalizedSale;
  turnover: number;
  appliedRules: AppliedRule[];
  loyaltyBonus: number;
  returnCommission: number;
}

export function calculateBonusForSalon(
  salonId: string,
  supplierId: string,
  period: string,
  sales: NormalizedSale[],
  rules: BonusRule[]
): CalculationResult {
  const salonSales = sales.filter(s => 
    s.salon_id === salonId && 
    s.supplier_id === supplierId &&
    s.period === period
  );
  
  let totalTurnover = 0;
  let loyaltyBonus = 0;
  let returnCommission = 0;
  const allAppliedRules: AppliedRule[] = [];
  const details: SaleCalculation[] = [];
  
  for (const sale of salonSales) {
    const turnover = sale.delta_turnover ?? sale.turnover;
    totalTurnover += turnover;
    
    const applicableRules = findApplicableRules(sale, rules);
    const saleAppliedRules: AppliedRule[] = [];
    let saleLoyalty = 0;
    let saleReturn = 0;
    
    for (const rule of applicableRules) {
      // Use new fields if available, fallback to legacy
      let loyaltyPct = 0;
      let returnPct = 0;
      
      if (rule.produkttype === 'begge') {
        // For 'begge', use the appropriate percentages based on sale type
        if (sale.rapporteringstype === 'kjemi') {
          loyaltyPct = rule.kjemi_lojalitet_prosent ?? 0;
          returnPct = rule.kjemi_retur_prosent ?? 0;
        } else {
          loyaltyPct = rule.produkt_lojalitet_prosent ?? 0;
          returnPct = rule.produkt_retur_prosent ?? 0;
        }
      } else {
        loyaltyPct = rule.lojalitetsbonus_prosent ?? rule.percentage ?? 0;
        returnPct = rule.returprovisjon_prosent ?? rule.percentage ?? 0;
      }
      
      const loyaltyAmount = turnover * (loyaltyPct / 100);
      const returnAmount = turnover * (returnPct / 100);
      
      if (loyaltyPct > 0) {
        saleLoyalty += loyaltyAmount;
        saleAppliedRules.push({ rule, turnover, bonusAmount: loyaltyAmount, type: 'loyalty' });
      }
      
      if (returnPct > 0) {
        saleReturn += returnAmount;
        saleAppliedRules.push({ rule, turnover, bonusAmount: returnAmount, type: 'return' });
      }
    }
    
    loyaltyBonus += saleLoyalty;
    returnCommission += saleReturn;
    allAppliedRules.push(...saleAppliedRules);
    
    details.push({
      sale,
      turnover,
      appliedRules: saleAppliedRules,
      loyaltyBonus: saleLoyalty,
      returnCommission: saleReturn
    });
  }
  
  return {
    salon_id: salonId,
    supplier_id: supplierId,
    period,
    totalTurnover,
    loyaltyBonus,
    returnCommission,
    totalBonus: loyaltyBonus + returnCommission,
    appliedRules: allAppliedRules,
    details
  };
}

// =============================================
// CUMULATIVE CALCULATION
// =============================================

export function calculateCumulativeDelta(
  currentCumulative: number,
  previousCumulative: number | null,
  isResetMonth: boolean
): number {
  if (isResetMonth || previousCumulative === null) {
    return currentCumulative;
  }
  return currentCumulative - previousCumulative;
}

// =============================================
// FORMATTING
// =============================================

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('nb-NO', {
    style: 'currency',
    currency: 'NOK',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
}

export function formatPercentage(value: number): string {
  return `${value.toFixed(2)}%`;
}

export function getRuleTypeLabel(type: string): string {
  switch (type) {
    case 'loyalty': return 'Lojalitetsbonus';
    case 'return': return 'Returprovisjon';
    case 'combined': return 'Kombinert';
    default: return type;
  }
}

export function getProdukttypeLabel(produkttype: Produkttype | undefined): string {
  switch (produkttype) {
    case 'kjemi': return 'Kjemi';
    case 'produkt': return 'Videre salg';
    case 'begge': return 'Begge';
    default: return '—';
  }
}

export function getMatchStatusLabel(status: string): string {
  switch (status) {
    case 'matched': return 'Matchet';
    case 'unmatched': return 'Ikke matchet';
    case 'error': return 'Feil';
    case 'manual_override': return 'Manuell overstyring';
    default: return status;
  }
}

export function getCalculationStatusLabel(status: string): string {
  switch (status) {
    case 'pending': return 'Venter';
    case 'calculated': return 'Beregnet';
    case 'approved': return 'Godkjent';
    case 'paid': return 'Utbetalt';
    case 'unmatched': return 'Ikke matchet';
    default: return status;
  }
}

export function getStatusColor(status: string): string {
  switch (status) {
    case 'matched':
    case 'calculated':
    case 'approved':
      return 'bg-green-500/10 text-green-700';
    case 'unmatched':
    case 'pending':
      return 'bg-amber-500/10 text-amber-700';
    case 'error':
      return 'bg-red-500/10 text-red-700';
    case 'paid':
      return 'bg-blue-500/10 text-blue-700';
    case 'manual_override':
      return 'bg-purple-500/10 text-purple-700';
    default:
      return 'bg-muted text-muted-foreground';
  }
}
