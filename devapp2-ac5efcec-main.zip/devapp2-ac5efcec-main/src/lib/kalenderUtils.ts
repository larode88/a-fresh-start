/**
 * Kalender-utilities for helligdager og arbeidsdager
 * 
 * Denne filen håndterer:
 * - Parsing av helligdag-strenger fra kalender-tabellen
 * - Sjekk av arbeidsdager
 * - Henting av arbeidsdager for perioder
 */

import { supabase } from "@/integrations/supabase/client";
import { eachDayOfInterval, format, getISOWeek } from "date-fns";
import { getISOUkedag } from "./dateUtils";

// ============= TYPES =============

export interface KalenderDag {
  dato: string;
  er_arbeidsdag: boolean;
  er_helligdag: boolean;
  helligdag_navn: string | null;
  aar: number;
  maned: number;
  uke: number;
  ukedag: number;
}

export interface WorkingDay {
  dato: string;
  er_arbeidsdag: boolean;
  maned: number;
  uke: number;
  ukedag: number;
}

// ============= HELLIGDAG-PARSING =============

/**
 * Parser helligdag-strenger fra kalender-tabellen
 * Støtter formater som:
 * - "Julaften (24. des)"
 * - "1. juledag (25. des 2025)"
 * - "Langfredag"
 * 
 * @param helligdagerStr - Kommaseparert streng med helligdager
 * @param startDate - Start av perioden å sjekke
 * @param endDate - Slutt av perioden å sjekke
 * @returns Array med Date-objekter for helligdager i perioden
 */
export function parseHolidays(
  helligdagerStr: string | null,
  startDate: Date,
  endDate: Date
): Date[] {
  if (!helligdagerStr) return [];

  const holidays: Date[] = [];
  const year = startDate.getFullYear();
  
  const monthMap: Record<string, number> = {
    'jan': 0, 'feb': 1, 'mar': 2, 'apr': 3, 'mai': 4, 'jun': 5,
    'jul': 6, 'aug': 7, 'sep': 8, 'okt': 9, 'nov': 10, 'des': 11
  };

  const parts = helligdagerStr.split(',');
  
  for (const part of parts) {
    const trimmed = part.trim();
    
    // Match format: "Navn (24. des)" eller "Navn (24. des 2025)"
    const match = trimmed.match(/\((\d+)\.\s*(\w+)(?:\s+(\d{4}))?\)/);
    
    if (match) {
      const day = parseInt(match[1]);
      const monthStr = match[2].toLowerCase().slice(0, 3);
      const parsedYear = match[3] ? parseInt(match[3]) : year;
      const month = monthMap[monthStr];
      
      if (month !== undefined && !isNaN(day)) {
        const holidayDate = new Date(parsedYear, month, day);
        
        // Sjekk om datoen er innenfor perioden
        if (holidayDate >= startDate && holidayDate <= endDate) {
          holidays.push(holidayDate);
        }
      }
    }
  }

  return holidays;
}

/**
 * Sjekker om en dato er en helligdag
 */
export function isHoliday(
  date: Date, 
  holidays: Date[]
): boolean {
  const dateStr = format(date, 'yyyy-MM-dd');
  return holidays.some(h => format(h, 'yyyy-MM-dd') === dateStr);
}

// ============= ARBEIDSDAGER =============

/**
 * Henter arbeidsdager fra kalender-tabellen for et år
 */
export async function getWorkingDaysFromCalendar(
  year: number,
  month?: number
): Promise<WorkingDay[]> {
  let query = supabase
    .from("kalender")
    .select("dato, er_arbeidsdag, maned, uke, ukedag")
    .eq("aar", year)
    .eq("er_arbeidsdag", true);

  if (month) {
    query = query.eq("maned", month);
  }

  const { data, error } = await query.order("dato");

  if (error) {
    console.error("Feil ved henting av kalenderdata:", error);
    return [];
  }

  return data || [];
}

/**
 * Genererer arbeidsdager som fallback når kalender-data ikke finnes
 * Antar at mandag-fredag er arbeidsdager
 */
export function generateWorkingDaysFallback(
  startDate: Date,
  endDate: Date,
  month?: number
): WorkingDay[] {
  const allDays = eachDayOfInterval({ start: startDate, end: endDate });
  
  return allDays
    .filter(d => {
      const dayOfWeek = d.getDay();
      const isWeekday = dayOfWeek !== 0 && dayOfWeek !== 6;
      
      if (month !== undefined) {
        return isWeekday && (d.getMonth() + 1) === month;
      }
      return isWeekday;
    })
    .map(d => ({
      dato: format(d, "yyyy-MM-dd"),
      er_arbeidsdag: true,
      maned: d.getMonth() + 1,
      uke: getISOWeek(d),
      ukedag: getISOUkedag(d)
    }));
}

/**
 * Henter eller genererer arbeidsdager for en periode
 */
export async function getWorkingDaysForPeriod(
  year: number,
  month?: number
): Promise<WorkingDay[]> {
  // Prøv å hente fra kalender først
  const calendarDays = await getWorkingDaysFromCalendar(year, month);
  
  if (calendarDays.length > 0) {
    return calendarDays;
  }

  // Fallback til genererte arbeidsdager
  const startDate = month 
    ? new Date(year, month - 1, 1)
    : new Date(year, 0, 1);
  const endDate = month
    ? new Date(year, month, 0) // Siste dag i måneden
    : new Date(year, 11, 31);

  return generateWorkingDaysFallback(startDate, endDate, month);
}

/**
 * Sjekker om en dato er en arbeidsdag
 */
export function isWorkingDay(date: Date): boolean {
  const dayOfWeek = date.getDay();
  return dayOfWeek !== 0 && dayOfWeek !== 6;
}

/**
 * Teller antall arbeidsdager i en periode
 */
export function countWorkingDays(startDate: Date, endDate: Date): number {
  const allDays = eachDayOfInterval({ start: startDate, end: endDate });
  return allDays.filter(isWorkingDay).length;
}
