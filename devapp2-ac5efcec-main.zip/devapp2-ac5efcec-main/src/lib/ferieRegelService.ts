/**
 * Ferie-regel service for å hente salong-spesifikke ferieregler
 */

import { supabase } from "@/integrations/supabase/client";
import { getISOWeek, format } from "date-fns";
import type { FerieEstimatPeriode } from "./ferieEstimatUtils";

/**
 * Justerer en dato til et gitt målår, beholder dag og måned.
 * Returnerer ISO-dato-streng (yyyy-MM-dd)
 */
function justerDatoTilAar(datoStr: string, maalAar: number): string {
  const d = new Date(datoStr);
  return format(new Date(maalAar, d.getMonth(), d.getDate()), "yyyy-MM-dd");
}

export interface SalongFerieRegler {
  id: string;
  salon_id: string;
  min_bemanning: number;
  sommer_start_uke: number;
  sommer_slutt_uke: number;
  sommer_antall_uker: number;
  sommer_bruk_dato: boolean;
  sommer_start_dato: string | null;
  sommer_slutt_dato: string | null;
  vinter_aktiv: boolean;
  vinter_start_uke: number;
  vinter_slutt_uke: number;
  vinter_bruk_dato: boolean;
  vinter_start_dato: string | null;
  vinter_slutt_dato: string | null;
  paske_aktiv: boolean;
  host_aktiv: boolean;
  host_start_uke: number;
  host_slutt_uke: number;
  host_bruk_dato: boolean;
  host_start_dato: string | null;
  host_slutt_dato: string | null;
  jul_aktiv: boolean;
  jul_start_uke: number;
  jul_slutt_uke: number;
  jul_bruk_dato: boolean;
  jul_start_dato: string | null;
  jul_slutt_dato: string | null;
}

const DEFAULT_REGLER: Omit<SalongFerieRegler, "id" | "salon_id"> = {
  min_bemanning: 2,
  sommer_start_uke: 27,
  sommer_slutt_uke: 35,
  sommer_antall_uker: 3,
  sommer_bruk_dato: false,
  sommer_start_dato: null,
  sommer_slutt_dato: null,
  vinter_aktiv: true,
  vinter_start_uke: 8,
  vinter_slutt_uke: 9,
  vinter_bruk_dato: false,
  vinter_start_dato: null,
  vinter_slutt_dato: null,
  paske_aktiv: true,
  host_aktiv: true,
  host_start_uke: 40,
  host_slutt_uke: 41,
  host_bruk_dato: false,
  host_start_dato: null,
  host_slutt_dato: null,
  jul_aktiv: true,
  jul_start_uke: 52,
  jul_slutt_uke: 52,
  jul_bruk_dato: false,
  jul_start_dato: null,
  jul_slutt_dato: null,
};

/**
 * Beregner påskeuken for et gitt år (basert på Gauss algoritme)
 */
function getPaskeUke(aar: number): number {
  const a = aar % 19;
  const b = Math.floor(aar / 100);
  const c = aar % 100;
  const d = Math.floor(b / 4);
  const e = b % 4;
  const f = Math.floor((b + 8) / 25);
  const g = Math.floor((b - f + 1) / 3);
  const h = (19 * a + b - d - g + 15) % 30;
  const i = Math.floor(c / 4);
  const k = c % 4;
  const l = (32 + 2 * e + 2 * i - h - k) % 7;
  const m = Math.floor((a + 11 * h + 22 * l) / 451);
  const month = Math.floor((h + l - 7 * m + 114) / 31);
  const day = ((h + l - 7 * m + 114) % 31) + 1;
  
  const paskesondag = new Date(aar, month - 1, day);
  return getISOWeek(paskesondag);
}

/**
 * Konverterer en dato-streng til ukenummer for et gitt målår.
 * Justerer datoen til målåret før konvertering slik at dag/måned beholdes.
 */
function datoTilUke(datoStr: string, maalAar: number): number {
  const opprinneligDato = new Date(datoStr);
  // Juster til målåret, behold dag og måned
  const justertDato = new Date(maalAar, opprinneligDato.getMonth(), opprinneligDato.getDate());
  return getISOWeek(justertDato);
}

/**
 * Henter ferieregler for en salong, med fallback til standardregler
 */
export async function hentSalongFerieRegler(salonId: string): Promise<SalongFerieRegler> {
  const { data, error } = await supabase
    .from("salong_ferie_regler")
    .select("*")
    .eq("salon_id", salonId)
    .maybeSingle();
  
  if (error) {
    console.error("Error fetching salon rules:", error);
  }
  
  if (data) {
    return {
      ...DEFAULT_REGLER,
      ...data
    } as SalongFerieRegler;
  }
  
  // Returner standardregler med dummy id og salon_id
  return {
    id: "",
    salon_id: salonId,
    ...DEFAULT_REGLER
  };
}

/**
 * Konverterer salong-regler til FerieEstimatPeriode-array
 */
export function konverterTilPerioder(regler: SalongFerieRegler, aar: number): FerieEstimatPeriode[] {
  const perioder: FerieEstimatPeriode[] = [];
  
  // Vinterferie
  if (regler.vinter_aktiv) {
    let startUke = regler.vinter_start_uke;
    let sluttUke = regler.vinter_slutt_uke;
    
    // Bruk datoer hvis aktivert og gyldige - juster til målåret
    if (regler.vinter_bruk_dato && regler.vinter_start_dato && regler.vinter_slutt_dato) {
      startUke = datoTilUke(regler.vinter_start_dato, aar);
      sluttUke = datoTilUke(regler.vinter_slutt_dato, aar);
    }
    
    perioder.push({
      navn: "Vinterferie",
      type: "Estimat - Vinterferie",
      startUke,
      sluttUke,
      // Bevar faktiske datoer hvis spesifisert
      ...(regler.vinter_bruk_dato && regler.vinter_start_dato && regler.vinter_slutt_dato && {
        startDato: justerDatoTilAar(regler.vinter_start_dato, aar),
        sluttDato: justerDatoTilAar(regler.vinter_slutt_dato, aar),
      }),
    });
  }
  
  // Påskeferie
  if (regler.paske_aktiv) {
    const paskeUke = getPaskeUke(aar);
    perioder.push({
      navn: "Påskeferie",
      type: "Estimat - Påskeferie",
      startUke: paskeUke,
      sluttUke: paskeUke + 1,
    });
  }
  
  // Sommerferie
  let sommerStartUke = regler.sommer_start_uke;
  let sommerSluttUke = regler.sommer_slutt_uke;
  
  // Bruk datoer hvis aktivert og gyldige - juster til målåret
  if (regler.sommer_bruk_dato && regler.sommer_start_dato && regler.sommer_slutt_dato) {
    sommerStartUke = datoTilUke(regler.sommer_start_dato, aar);
    sommerSluttUke = datoTilUke(regler.sommer_slutt_dato, aar);
  }
  
  perioder.push({
    navn: "Sommerferie",
    type: "Estimat - Sommerferie",
    startUke: sommerStartUke,
    sluttUke: sommerSluttUke,
    fasteUker: regler.sommer_antall_uker,
    erKrav: true,
    // Bevar faktiske datoer hvis spesifisert
    ...(regler.sommer_bruk_dato && regler.sommer_start_dato && regler.sommer_slutt_dato && {
      startDato: justerDatoTilAar(regler.sommer_start_dato, aar),
      sluttDato: justerDatoTilAar(regler.sommer_slutt_dato, aar),
    }),
  });
  
  // Høstferie
  if (regler.host_aktiv) {
    let startUke = regler.host_start_uke;
    let sluttUke = regler.host_slutt_uke;
    
    // Bruk datoer hvis aktivert og gyldige - juster til målåret
    if (regler.host_bruk_dato && regler.host_start_dato && regler.host_slutt_dato) {
      startUke = datoTilUke(regler.host_start_dato, aar);
      sluttUke = datoTilUke(regler.host_slutt_dato, aar);
    }
    
    perioder.push({
      navn: "Høstferie",
      type: "Estimat - Høstferie",
      startUke,
      sluttUke,
      // Bevar faktiske datoer hvis spesifisert
      ...(regler.host_bruk_dato && regler.host_start_dato && regler.host_slutt_dato && {
        startDato: justerDatoTilAar(regler.host_start_dato, aar),
        sluttDato: justerDatoTilAar(regler.host_slutt_dato, aar),
      }),
    });
  }
  
  // Juleferie
  if (regler.jul_aktiv) {
    let startUke = regler.jul_start_uke;
    let sluttUke = regler.jul_slutt_uke;
    
    // Bruk datoer hvis aktivert og gyldige - juster til målåret
    if (regler.jul_bruk_dato && regler.jul_start_dato && regler.jul_slutt_dato) {
      startUke = datoTilUke(regler.jul_start_dato, aar);
      sluttUke = datoTilUke(regler.jul_slutt_dato, aar);
    }
    
    perioder.push({
      navn: "Juleferie",
      type: "Estimat - Juleferie",
      startUke,
      sluttUke,
      // Bevar faktiske datoer hvis spesifisert
      ...(regler.jul_bruk_dato && regler.jul_start_dato && regler.jul_slutt_dato && {
        startDato: justerDatoTilAar(regler.jul_start_dato, aar),
        sluttDato: justerDatoTilAar(regler.jul_slutt_dato, aar),
      }),
    });
  }
  
  return perioder;
}

/**
 * Henter ferie-perioder for en salong med salong-spesifikke regler
 */
export async function getFerieperioderForSalong(
  salonId: string, 
  aar: number
): Promise<{ perioder: FerieEstimatPeriode[]; minBemanning: number }> {
  const regler = await hentSalongFerieRegler(salonId);
  const perioder = konverterTilPerioder(regler, aar);
  
  return {
    perioder,
    minBemanning: regler.min_bemanning
  };
}
