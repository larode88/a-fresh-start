// Goals Service
// Provides typed CRUD operations for employee goals management
// Note: This uses the ansatt_mal table created in the migration

import { supabase } from './supabaseClient';
import type { Database } from './types';

// Use database types directly
type EmployeeGoal = Database['public']['Tables']['ansatt_mal']['Row'];
type GoalInsert = Database['public']['Tables']['ansatt_mal']['Insert'];
type GoalUpdate = Database['public']['Tables']['ansatt_mal']['Update'];

export type { EmployeeGoal, GoalInsert, GoalUpdate };

export interface GoalWithEmployee extends EmployeeGoal {
  users?: {
    id: string;
    name: string;
  } | null;
}

/**
 * Get all goals for a salon
 */
export async function getGoalsBySalon(salonId: string): Promise<GoalWithEmployee[]> {
  const { data, error } = await supabase
    .from('ansatt_mal')
    .select(`
      *,
      users:user_id (
        id,
        name
      )
    `)
    .eq('salon_id', salonId)
    .order('created_at', { ascending: false });

  if (error) {
    throw new Error(`Failed to fetch goals: ${error.message}`);
  }

  return (data || []) as GoalWithEmployee[];
}

/**
 * Get goals for a specific employee
 */
export async function getGoalsByEmployee(
  userId: string,
  activeOnly: boolean = false
): Promise<EmployeeGoal[]> {
  let query = supabase
    .from('ansatt_mal')
    .select('*')
    .eq('user_id', userId);

  if (activeOnly) {
    query = query.eq('status', 'aktiv');
  }

  const { data, error } = await query.order('periode_start', { ascending: false });

  if (error) {
    throw new Error(`Failed to fetch employee goals: ${error.message}`);
  }

  return data || [];
}

/**
 * Create a new goal
 */
export async function createGoal(goal: GoalInsert): Promise<EmployeeGoal> {
  const { data, error } = await supabase
    .from('ansatt_mal')
    .insert(goal)
    .select()
    .single();

  if (error) {
    throw new Error(`Failed to create goal: ${error.message}`);
  }

  return data;
}

/**
 * Update an existing goal
 */
export async function updateGoal(
  goalId: string,
  updates: GoalUpdate
): Promise<EmployeeGoal> {
  const { data, error } = await supabase
    .from('ansatt_mal')
    .update(updates)
    .eq('id', goalId)
    .select()
    .single();

  if (error) {
    throw new Error(`Failed to update goal: ${error.message}`);
  }

  return data;
}

/**
 * Delete a goal
 */
export async function deleteGoal(goalId: string): Promise<void> {
  const { error } = await supabase
    .from('ansatt_mal')
    .delete()
    .eq('id', goalId);

  if (error) {
    throw new Error(`Failed to delete goal: ${error.message}`);
  }
}

/**
 * Link a goal to a budget
 */
export async function linkGoalToBudget(
  goalId: string,
  budgetId: string
): Promise<EmployeeGoal> {
  const { data, error } = await supabase
    .from('ansatt_mal')
    .update({ budsjett_id: budgetId })
    .eq('id', goalId)
    .select()
    .single();

  if (error) {
    throw new Error(`Failed to link goal to budget: ${error.message}`);
  }

  return data;
}

/**
 * Get goal progress using RPC function
 */
export async function getGoalProgress(
  userId: string,
  activeOnly: boolean = true
): Promise<{
  goal_id: string;
  goal_type: string;
  goal_description: string;
  target_value: number;
  current_value: number;
  progress_percent: number;
  status: string;
  periode_start: string;
  periode_slutt: string | null;
}[]> {
  const { data, error } = await supabase.rpc('get_goal_progress', {
    p_user_id: userId,
    p_active_only: activeOnly,
  });

  if (error) {
    throw new Error(`Failed to get goal progress: ${error.message}`);
  }

  return (data || []) as {
    goal_id: string;
    goal_type: string;
    goal_description: string;
    target_value: number;
    current_value: number;
    progress_percent: number;
    status: string;
    periode_start: string;
    periode_slutt: string | null;
  }[];
}

/**
 * Update goal progress value
 */
export async function updateGoalProgress(
  goalId: string,
  currentValue: number
): Promise<EmployeeGoal> {
  return updateGoal(goalId, { naavaerende_verdi: currentValue });
}

/**
 * Mark goal as completed
 */
export async function completeGoal(goalId: string): Promise<EmployeeGoal> {
  return updateGoal(goalId, { status: 'fullfort' });
}

/**
 * Get goals linked to a specific budget version
 */
export async function getGoalsByBudget(budgetId: string): Promise<EmployeeGoal[]> {
  const { data, error } = await supabase
    .from('ansatt_mal')
    .select('*')
    .eq('budsjett_id', budgetId)
    .order('created_at', { ascending: false });

  if (error) {
    throw new Error(`Failed to fetch budget goals: ${error.message}`);
  }

  return data || [];
}
