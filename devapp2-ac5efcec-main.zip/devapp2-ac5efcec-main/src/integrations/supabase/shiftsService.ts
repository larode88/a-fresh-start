// Shifts Service
// Provides typed CRUD operations for shift schedule management

import { supabase } from './supabaseClient';
import type { Database } from './types';

type Shift = Database['public']['Tables']['turnus_skift']['Row'];
type ShiftInsert = Database['public']['Tables']['turnus_skift']['Insert'];
type ShiftUpdate = Database['public']['Tables']['turnus_skift']['Update'];

export interface ShiftWithEmployee extends Shift {
  users?: {
    id: string;
    name: string;
    email: string;
  } | null;
}

/**
 * Get all shifts for a salon in a date range
 */
export async function getShiftsBySalonAndDateRange(
  salonId: string,
  startDate: string,
  endDate: string
): Promise<ShiftWithEmployee[]> {
  const { data, error } = await supabase
    .from('turnus_skift')
    .select(`
      *,
      users:user_id (
        id,
        name,
        email
      )
    `)
    .eq('salon_id', salonId)
    .gte('dato', startDate)
    .lte('dato', endDate)
    .order('dato')
    .order('start_tid');

  if (error) {
    throw new Error(`Failed to fetch shifts: ${error.message}`);
  }

  return data || [];
}

/**
 * Get shifts for a specific employee
 */
export async function getShiftsByEmployee(
  userId: string,
  startDate: string,
  endDate: string
): Promise<Shift[]> {
  const { data, error } = await supabase
    .from('turnus_skift')
    .select('*')
    .eq('user_id', userId)
    .gte('dato', startDate)
    .lte('dato', endDate)
    .order('dato');

  if (error) {
    throw new Error(`Failed to fetch employee shifts: ${error.message}`);
  }

  return data || [];
}

/**
 * Create a new shift
 */
export async function createShift(shift: ShiftInsert): Promise<Shift> {
  const { data, error } = await supabase
    .from('turnus_skift')
    .insert(shift)
    .select()
    .single();

  if (error) {
    throw new Error(`Failed to create shift: ${error.message}`);
  }

  return data;
}

/**
 * Update an existing shift
 */
export async function updateShift(
  shiftId: string,
  updates: ShiftUpdate
): Promise<Shift> {
  const { data, error } = await supabase
    .from('turnus_skift')
    .update(updates)
    .eq('id', shiftId)
    .select()
    .single();

  if (error) {
    throw new Error(`Failed to update shift: ${error.message}`);
  }

  return data;
}

/**
 * Delete a shift
 */
export async function deleteShift(shiftId: string): Promise<void> {
  const { error } = await supabase
    .from('turnus_skift')
    .delete()
    .eq('id', shiftId);

  if (error) {
    throw new Error(`Failed to delete shift: ${error.message}`);
  }
}

/**
 * Get shift summary for employee in a period
 */
export async function getShiftSummary(
  userId: string,
  startDate: string,
  endDate: string
): Promise<{
  total_shifts: number;
  total_planned_hours: number;
  avg_hours_per_shift: number;
  days_worked: number;
}> {
  const { data, error } = await supabase.rpc('get_shift_hours_summary', {
    p_user_id: userId,
    p_start_date: startDate,
    p_end_date: endDate,
  });

  if (error) {
    throw new Error(`Failed to get shift summary: ${error.message}`);
  }

  return data?.[0] || {
    total_shifts: 0,
    total_planned_hours: 0,
    avg_hours_per_shift: 0,
    days_worked: 0,
  };
}

/**
 * Get shifts for a specific week
 */
export async function getShiftsByWeek(
  salonId: string,
  year: number,
  week: number
): Promise<ShiftWithEmployee[]> {
  // Calculate date range for the week
  const startDate = getDateOfISOWeek(week, year);
  const endDate = new Date(startDate);
  endDate.setDate(endDate.getDate() + 6);

  return getShiftsBySalonAndDateRange(
    salonId,
    startDate.toISOString().split('T')[0],
    endDate.toISOString().split('T')[0]
  );
}

/**
 * Helper function to get the date of a specific ISO week
 */
function getDateOfISOWeek(week: number, year: number): Date {
  const simple = new Date(year, 0, 1 + (week - 1) * 7);
  const dow = simple.getDay();
  const ISOweekStart = simple;
  if (dow <= 4) {
    ISOweekStart.setDate(simple.getDate() - simple.getDay() + 1);
  } else {
    ISOweekStart.setDate(simple.getDate() + 8 - simple.getDay());
  }
  return ISOweekStart;
}

/**
 * Bulk create shifts
 */
export async function createBulkShifts(shifts: ShiftInsert[]): Promise<Shift[]> {
  const { data, error } = await supabase
    .from('turnus_skift')
    .insert(shifts)
    .select();

  if (error) {
    throw new Error(`Failed to create bulk shifts: ${error.message}`);
  }

  return data || [];
}
