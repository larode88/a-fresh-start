export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      announcement_notifications: {
        Row: {
          announcement_id: string
          created_at: string
          id: string
          read_at: string | null
          user_id: string
        }
        Insert: {
          announcement_id: string
          created_at?: string
          id?: string
          read_at?: string | null
          user_id: string
        }
        Update: {
          announcement_id?: string
          created_at?: string
          id?: string
          read_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "announcement_notifications_announcement_id_fkey"
            columns: ["announcement_id"]
            isOneToOne: false
            referencedRelation: "announcements"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "announcement_notifications_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "announcement_notifications_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "announcement_notifications_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      announcements: {
        Row: {
          content: string | null
          created_at: string
          created_by_user_id: string | null
          description: string | null
          display_order: number
          expires_at: string | null
          external_url: string | null
          id: string
          image_url: string | null
          link_type: string
          published: boolean
          published_at: string | null
          slug: string
          target_roles: string[] | null
          title: string
          updated_at: string
        }
        Insert: {
          content?: string | null
          created_at?: string
          created_by_user_id?: string | null
          description?: string | null
          display_order?: number
          expires_at?: string | null
          external_url?: string | null
          id?: string
          image_url?: string | null
          link_type?: string
          published?: boolean
          published_at?: string | null
          slug: string
          target_roles?: string[] | null
          title: string
          updated_at?: string
        }
        Update: {
          content?: string | null
          created_at?: string
          created_by_user_id?: string | null
          description?: string | null
          display_order?: number
          expires_at?: string | null
          external_url?: string | null
          id?: string
          image_url?: string | null
          link_type?: string
          published?: boolean
          published_at?: string | null
          slug?: string
          target_roles?: string[] | null
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "announcements_created_by_user_id_fkey"
            columns: ["created_by_user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "announcements_created_by_user_id_fkey"
            columns: ["created_by_user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "announcements_created_by_user_id_fkey"
            columns: ["created_by_user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      ansatt_dokumenter: {
        Row: {
          created_at: string | null
          dokument_navn: string
          dokument_type: string
          dokument_url: string
          id: string
          opprettet_av: string | null
          user_id: string
          utloper_dato: string | null
        }
        Insert: {
          created_at?: string | null
          dokument_navn: string
          dokument_type: string
          dokument_url: string
          id?: string
          opprettet_av?: string | null
          user_id: string
          utloper_dato?: string | null
        }
        Update: {
          created_at?: string | null
          dokument_navn?: string
          dokument_type?: string
          dokument_url?: string
          id?: string
          opprettet_av?: string | null
          user_id?: string
          utloper_dato?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "ansatt_dokumenter_opprettet_av_fkey"
            columns: ["opprettet_av"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_dokumenter_opprettet_av_fkey"
            columns: ["opprettet_av"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_dokumenter_opprettet_av_fkey"
            columns: ["opprettet_av"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_dokumenter_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_dokumenter_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_dokumenter_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      ansatt_dokumenter_v2: {
        Row: {
          ansatt_id: string
          created_at: string | null
          dokument_type: string
          dokument_url: string
          filnavn: string
          id: string
          opprettet_av: string | null
          signatur_status: Database["public"]["Enums"]["signatur_status"] | null
          signert_dato: string | null
          versjon: number | null
        }
        Insert: {
          ansatt_id: string
          created_at?: string | null
          dokument_type: string
          dokument_url: string
          filnavn: string
          id?: string
          opprettet_av?: string | null
          signatur_status?:
            | Database["public"]["Enums"]["signatur_status"]
            | null
          signert_dato?: string | null
          versjon?: number | null
        }
        Update: {
          ansatt_id?: string
          created_at?: string | null
          dokument_type?: string
          dokument_url?: string
          filnavn?: string
          id?: string
          opprettet_av?: string | null
          signatur_status?:
            | Database["public"]["Enums"]["signatur_status"]
            | null
          signert_dato?: string | null
          versjon?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "ansatt_dokumenter_v2_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_dokumenter_v2_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_dokumenter_v2_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_utvidet"
            referencedColumns: ["id"]
          },
        ]
      }
      ansatt_endringslogg: {
        Row: {
          ansatt_id: string
          endret_av: string | null
          endret_dato: string | null
          felt_navn: string
          hendelse_type: string
          id: string
          ny_verdi: string | null
          tabell_navn: string
          tidligere_verdi: string | null
        }
        Insert: {
          ansatt_id: string
          endret_av?: string | null
          endret_dato?: string | null
          felt_navn: string
          hendelse_type?: string
          id?: string
          ny_verdi?: string | null
          tabell_navn?: string
          tidligere_verdi?: string | null
        }
        Update: {
          ansatt_id?: string
          endret_av?: string | null
          endret_dato?: string | null
          felt_navn?: string
          hendelse_type?: string
          id?: string
          ny_verdi?: string | null
          tabell_navn?: string
          tidligere_verdi?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "ansatt_endringslogg_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_endringslogg_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_endringslogg_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_utvidet"
            referencedColumns: ["id"]
          },
        ]
      }
      ansatt_godtgjorelser: {
        Row: {
          belop: number
          beskrivelse: string | null
          created_at: string | null
          frekvens: string | null
          gyldig_fra: string
          gyldig_til: string | null
          id: string
          type: string
          user_id: string
        }
        Insert: {
          belop: number
          beskrivelse?: string | null
          created_at?: string | null
          frekvens?: string | null
          gyldig_fra?: string
          gyldig_til?: string | null
          id?: string
          type: string
          user_id: string
        }
        Update: {
          belop?: number
          beskrivelse?: string | null
          created_at?: string | null
          frekvens?: string | null
          gyldig_fra?: string
          gyldig_til?: string | null
          id?: string
          type?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ansatt_godtgjorelser_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_godtgjorelser_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_godtgjorelser_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      ansatt_godtgjorelser_v2: {
        Row: {
          ansatt_id: string
          belop: number
          beskrivelse: string | null
          created_at: string | null
          frekvens: string | null
          gyldig_fra: string
          gyldig_til: string | null
          id: string
          type: string
        }
        Insert: {
          ansatt_id: string
          belop: number
          beskrivelse?: string | null
          created_at?: string | null
          frekvens?: string | null
          gyldig_fra?: string
          gyldig_til?: string | null
          id?: string
          type: string
        }
        Update: {
          ansatt_id?: string
          belop?: number
          beskrivelse?: string | null
          created_at?: string | null
          frekvens?: string | null
          gyldig_fra?: string
          gyldig_til?: string | null
          id?: string
          type?: string
        }
        Relationships: [
          {
            foreignKeyName: "ansatt_godtgjorelser_v2_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_godtgjorelser_v2_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_godtgjorelser_v2_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_utvidet"
            referencedColumns: ["id"]
          },
        ]
      }
      ansatt_kompetanse_score: {
        Row: {
          created_at: string | null
          id: string
          kommentar: string | null
          kompetanse_id: string
          samtale_id: string
          score: number
        }
        Insert: {
          created_at?: string | null
          id?: string
          kommentar?: string | null
          kompetanse_id: string
          samtale_id: string
          score: number
        }
        Update: {
          created_at?: string | null
          id?: string
          kommentar?: string | null
          kompetanse_id?: string
          samtale_id?: string
          score?: number
        }
        Relationships: [
          {
            foreignKeyName: "ansatt_kompetanse_score_kompetanse_id_fkey"
            columns: ["kompetanse_id"]
            isOneToOne: false
            referencedRelation: "kompetanse_definisjoner"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_kompetanse_score_samtale_id_fkey"
            columns: ["samtale_id"]
            isOneToOne: false
            referencedRelation: "ansatt_samtaler"
            referencedColumns: ["id"]
          },
        ]
      }
      ansatt_kpi_maned: {
        Row: {
          aar: number
          ansatt_id: string
          created_at: string | null
          effektivitet_prosent: number | null
          id: string
          maned: number
          omsetning_per_time: number | null
          salon_id: string
          updated_at: string | null
          varesalg_prosent: number | null
          versjon_id: string
        }
        Insert: {
          aar: number
          ansatt_id: string
          created_at?: string | null
          effektivitet_prosent?: number | null
          id?: string
          maned: number
          omsetning_per_time?: number | null
          salon_id: string
          updated_at?: string | null
          varesalg_prosent?: number | null
          versjon_id: string
        }
        Update: {
          aar?: number
          ansatt_id?: string
          created_at?: string | null
          effektivitet_prosent?: number | null
          id?: string
          maned?: number
          omsetning_per_time?: number | null
          salon_id?: string
          updated_at?: string | null
          varesalg_prosent?: number | null
          versjon_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ansatt_kpi_maned_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_kpi_maned_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_kpi_maned_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_utvidet"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_kpi_maned_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_kpi_maned_versjon_id_fkey"
            columns: ["versjon_id"]
            isOneToOne: false
            referencedRelation: "budsjett_versjoner"
            referencedColumns: ["id"]
          },
        ]
      }
      ansatt_mal: {
        Row: {
          ansatt_id: string | null
          beskrivelse: string | null
          budsjett_id: string | null
          created_at: string | null
          id: string
          maalverdi: number
          mal_type: string
          naavaerende_verdi: number | null
          periode_slutt: string
          periode_start: string
          salon_id: string
          status: string | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          ansatt_id?: string | null
          beskrivelse?: string | null
          budsjett_id?: string | null
          created_at?: string | null
          id?: string
          maalverdi?: number
          mal_type: string
          naavaerende_verdi?: number | null
          periode_slutt: string
          periode_start: string
          salon_id: string
          status?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          ansatt_id?: string | null
          beskrivelse?: string | null
          budsjett_id?: string | null
          created_at?: string | null
          id?: string
          maalverdi?: number
          mal_type?: string
          naavaerende_verdi?: number | null
          periode_slutt?: string
          periode_start?: string
          salon_id?: string
          status?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "ansatt_mal_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_mal_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_mal_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_utvidet"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_mal_budsjett_id_fkey"
            columns: ["budsjett_id"]
            isOneToOne: false
            referencedRelation: "budsjett_versjoner"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_mal_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_mal_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_mal_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_mal_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      ansatt_prosesser: {
        Row: {
          ansatt_id: string
          created_at: string
          faktisk_slutt: string | null
          forventet_slutt: string | null
          id: string
          mal_id: string | null
          notater: string | null
          opprettet_av: string | null
          prosess_type: Database["public"]["Enums"]["ansatt_prosess_type"]
          salon_id: string
          start_dato: string
          status: string | null
          updated_at: string
        }
        Insert: {
          ansatt_id: string
          created_at?: string
          faktisk_slutt?: string | null
          forventet_slutt?: string | null
          id?: string
          mal_id?: string | null
          notater?: string | null
          opprettet_av?: string | null
          prosess_type: Database["public"]["Enums"]["ansatt_prosess_type"]
          salon_id: string
          start_dato?: string
          status?: string | null
          updated_at?: string
        }
        Update: {
          ansatt_id?: string
          created_at?: string
          faktisk_slutt?: string | null
          forventet_slutt?: string | null
          id?: string
          mal_id?: string | null
          notater?: string | null
          opprettet_av?: string | null
          prosess_type?: Database["public"]["Enums"]["ansatt_prosess_type"]
          salon_id?: string
          start_dato?: string
          status?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "ansatt_prosesser_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_prosesser_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_prosesser_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_utvidet"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_prosesser_mal_id_fkey"
            columns: ["mal_id"]
            isOneToOne: false
            referencedRelation: "sjekkliste_maler"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_prosesser_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
        ]
      }
      ansatt_samtaler: {
        Row: {
          ansatt_id: string | null
          arkivert: boolean | null
          created_at: string | null
          dato: string
          forberedelses_frist: string | null
          id: string
          konfidensielle_notater: string | null
          lønnsforslag_beløp: number | null
          lønnsforslag_kommentar: string | null
          mal_id: string | null
          mal_neste_periode: string | null
          med_deltakere: string[] | null
          neste_samtale: string | null
          notater: string | null
          salon_id: string
          sammendrag: string | null
          samtale_type: string
          signert_av_ansatt: boolean | null
          signert_dato: string | null
          status: string | null
          sted: string | null
          steg_notater: Json | null
          styrker: string | null
          updated_at: string | null
          user_id: string | null
          utfort_av: string
          utviklingsomrader: string | null
        }
        Insert: {
          ansatt_id?: string | null
          arkivert?: boolean | null
          created_at?: string | null
          dato: string
          forberedelses_frist?: string | null
          id?: string
          konfidensielle_notater?: string | null
          lønnsforslag_beløp?: number | null
          lønnsforslag_kommentar?: string | null
          mal_id?: string | null
          mal_neste_periode?: string | null
          med_deltakere?: string[] | null
          neste_samtale?: string | null
          notater?: string | null
          salon_id: string
          sammendrag?: string | null
          samtale_type: string
          signert_av_ansatt?: boolean | null
          signert_dato?: string | null
          status?: string | null
          sted?: string | null
          steg_notater?: Json | null
          styrker?: string | null
          updated_at?: string | null
          user_id?: string | null
          utfort_av: string
          utviklingsomrader?: string | null
        }
        Update: {
          ansatt_id?: string | null
          arkivert?: boolean | null
          created_at?: string | null
          dato?: string
          forberedelses_frist?: string | null
          id?: string
          konfidensielle_notater?: string | null
          lønnsforslag_beløp?: number | null
          lønnsforslag_kommentar?: string | null
          mal_id?: string | null
          mal_neste_periode?: string | null
          med_deltakere?: string[] | null
          neste_samtale?: string | null
          notater?: string | null
          salon_id?: string
          sammendrag?: string | null
          samtale_type?: string
          signert_av_ansatt?: boolean | null
          signert_dato?: string | null
          status?: string | null
          sted?: string | null
          steg_notater?: Json | null
          styrker?: string | null
          updated_at?: string | null
          user_id?: string | null
          utfort_av?: string
          utviklingsomrader?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "ansatt_samtaler_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_samtaler_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_samtaler_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_utvidet"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_samtaler_mal_id_fkey"
            columns: ["mal_id"]
            isOneToOne: false
            referencedRelation: "samtale_maler"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_samtaler_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_samtaler_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_samtaler_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_samtaler_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_samtaler_utfort_av_fkey"
            columns: ["utfort_av"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_samtaler_utfort_av_fkey"
            columns: ["utfort_av"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_samtaler_utfort_av_fkey"
            columns: ["utfort_av"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      ansatt_sertifiseringer: {
        Row: {
          created_at: string | null
          id: string
          kostnad: number | null
          kurs_leverandør: string | null
          navn: string
          sertifikat_url: string | null
          status: string | null
          tilknyttet_plan_id: string | null
          type: string | null
          user_id: string
          utloper_dato: string | null
          utsteder: string | null
          utstedt_dato: string | null
          varighet_timer: number | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          kostnad?: number | null
          kurs_leverandør?: string | null
          navn: string
          sertifikat_url?: string | null
          status?: string | null
          tilknyttet_plan_id?: string | null
          type?: string | null
          user_id: string
          utloper_dato?: string | null
          utsteder?: string | null
          utstedt_dato?: string | null
          varighet_timer?: number | null
        }
        Update: {
          created_at?: string | null
          id?: string
          kostnad?: number | null
          kurs_leverandør?: string | null
          navn?: string
          sertifikat_url?: string | null
          status?: string | null
          tilknyttet_plan_id?: string | null
          type?: string | null
          user_id?: string
          utloper_dato?: string | null
          utsteder?: string | null
          utstedt_dato?: string | null
          varighet_timer?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "ansatt_sertifiseringer_tilknyttet_plan_id_fkey"
            columns: ["tilknyttet_plan_id"]
            isOneToOne: false
            referencedRelation: "ansatt_utviklingsplan"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_sertifiseringer_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_sertifiseringer_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_sertifiseringer_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      ansatt_sertifiseringer_v2: {
        Row: {
          ansatt_id: string
          created_at: string | null
          id: string
          leverandor: string | null
          navn: string
          obligatorisk: boolean | null
          sertifikat_url: string | null
          status: string | null
          type: Database["public"]["Enums"]["sertifisering_type_v2"] | null
          utloper_dato: string | null
          utstedt_dato: string | null
        }
        Insert: {
          ansatt_id: string
          created_at?: string | null
          id?: string
          leverandor?: string | null
          navn: string
          obligatorisk?: boolean | null
          sertifikat_url?: string | null
          status?: string | null
          type?: Database["public"]["Enums"]["sertifisering_type_v2"] | null
          utloper_dato?: string | null
          utstedt_dato?: string | null
        }
        Update: {
          ansatt_id?: string
          created_at?: string | null
          id?: string
          leverandor?: string | null
          navn?: string
          obligatorisk?: boolean | null
          sertifikat_url?: string | null
          status?: string | null
          type?: Database["public"]["Enums"]["sertifisering_type_v2"] | null
          utloper_dato?: string | null
          utstedt_dato?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "ansatt_sertifiseringer_v2_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_sertifiseringer_v2_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_sertifiseringer_v2_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_utvidet"
            referencedColumns: ["id"]
          },
        ]
      }
      ansatt_turnus: {
        Row: {
          ansatt_id: string | null
          created_at: string | null
          created_by: string | null
          fridag: boolean | null
          gyldig_fra: string
          gyldig_til: string | null
          helligdag_opplaast: boolean | null
          id: string
          laast: boolean | null
          merknad: string | null
          pause_minutter: number | null
          salon_id: string
          slutt_tid: string | null
          start_tid: string | null
          uke_type: Database["public"]["Enums"]["turnus_uke_type"] | null
          ukedag: number
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          ansatt_id?: string | null
          created_at?: string | null
          created_by?: string | null
          fridag?: boolean | null
          gyldig_fra?: string
          gyldig_til?: string | null
          helligdag_opplaast?: boolean | null
          id?: string
          laast?: boolean | null
          merknad?: string | null
          pause_minutter?: number | null
          salon_id: string
          slutt_tid?: string | null
          start_tid?: string | null
          uke_type?: Database["public"]["Enums"]["turnus_uke_type"] | null
          ukedag: number
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          ansatt_id?: string | null
          created_at?: string | null
          created_by?: string | null
          fridag?: boolean | null
          gyldig_fra?: string
          gyldig_til?: string | null
          helligdag_opplaast?: boolean | null
          id?: string
          laast?: boolean | null
          merknad?: string | null
          pause_minutter?: number | null
          salon_id?: string
          slutt_tid?: string | null
          start_tid?: string | null
          uke_type?: Database["public"]["Enums"]["turnus_uke_type"] | null
          ukedag?: number
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "ansatt_turnus_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_turnus_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_turnus_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_utvidet"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_turnus_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_turnus_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_turnus_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_turnus_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      ansatt_utviklingsplan: {
        Row: {
          beskrivelse: string | null
          created_at: string | null
          dokumenter: Json | null
          eier_id: string | null
          estimert_kostnad: number | null
          fremgang: number | null
          frist: string | null
          godkjent_kostnad: boolean | null
          id: string
          kategori: string | null
          maal: string | null
          prioritet: number | null
          salon_id: string
          samtale_id: string | null
          status: string | null
          tiltak: string | null
          tittel: string
          type: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          beskrivelse?: string | null
          created_at?: string | null
          dokumenter?: Json | null
          eier_id?: string | null
          estimert_kostnad?: number | null
          fremgang?: number | null
          frist?: string | null
          godkjent_kostnad?: boolean | null
          id?: string
          kategori?: string | null
          maal?: string | null
          prioritet?: number | null
          salon_id: string
          samtale_id?: string | null
          status?: string | null
          tiltak?: string | null
          tittel: string
          type?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          beskrivelse?: string | null
          created_at?: string | null
          dokumenter?: Json | null
          eier_id?: string | null
          estimert_kostnad?: number | null
          fremgang?: number | null
          frist?: string | null
          godkjent_kostnad?: boolean | null
          id?: string
          kategori?: string | null
          maal?: string | null
          prioritet?: number | null
          salon_id?: string
          samtale_id?: string | null
          status?: string | null
          tiltak?: string | null
          tittel?: string
          type?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ansatt_utviklingsplan_eier_id_fkey"
            columns: ["eier_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_utviklingsplan_eier_id_fkey"
            columns: ["eier_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_utviklingsplan_eier_id_fkey"
            columns: ["eier_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_utviklingsplan_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_utviklingsplan_samtale_id_fkey"
            columns: ["samtale_id"]
            isOneToOne: false
            referencedRelation: "ansatt_samtaler"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_utviklingsplan_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_utviklingsplan_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ansatt_utviklingsplan_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      ansatte: {
        Row: {
          adresse: string | null
          ansatt_dato: string | null
          arbeidsdager_pr_uke: number | null
          arbeidstid_per_uke: number | null
          arkivert_arsak: string | null
          arkivert_av: string | null
          arkivert_dato: string | null
          bankkontonummer: string | null
          beste_del_av_arbeidsdagen: string | null
          budsjett_kilde: string | null
          created_at: string | null
          effektivitet_prosent: number | null
          epost: string | null
          etternavn: string | null
          fagbrev_dato: string | null
          fastlonn: number | null
          feriekrav_kommentar: string | null
          feriekrav_timer_per_aar: number
          feriekrav_type_enum:
            | Database["public"]["Enums"]["feriekrav_type"]
            | null
          fodselsdato: string | null
          foretrukket_feiring: string | null
          fornavn: string
          frisorfunksjon: Database["public"]["Enums"]["frisorfunksjon"] | null
          helseforsikring_avtalenummer: string | null
          helseforsikring_oppsigelsesdato: string | null
          helseforsikring_oppstartsdato: string | null
          helseforsikring_pris: number | null
          helseforsikring_status: string | null
          hubspot_contact_id: string | null
          hubspot_synced_at: string | null
          id: string
          inkluder_i_budsjett: boolean | null
          inkluder_i_turnus: boolean | null
          kjonn: string | null
          kurs_sertifiseringer: string | null
          lederstilling: Database["public"]["Enums"]["lederstilling"] | null
          lonn_sist_justert: string | null
          lonnstype_enum: Database["public"]["Enums"]["lonnstype"] | null
          mentor_id: string | null
          motivasjon_i_jobben: string | null
          nasjonalitet: string | null
          omsetning_per_time: number | null
          oppsigelsesdato: string | null
          personnummer: string | null
          postnummer: string | null
          poststed: string | null
          profilbilde_url: string | null
          provetid_til: string | null
          provisjon_behandling_hoy_prosent: number | null
          provisjon_behandling_prosent: number | null
          provisjon_terskel: number | null
          provisjon_vare_prosent: number | null
          rebooking_prosent: number | null
          salong_id: string | null
          siste_arbeidsdag: string | null
          status: Database["public"]["Enums"]["ansatt_status"]
          stillingsprosent: number
          telefon: string | null
          timesats: number | null
          updated_at: string | null
          user_id: string | null
          utdanning_fagbrev: string | null
          varesalg_prosent: number | null
          verdier: string | null
        }
        Insert: {
          adresse?: string | null
          ansatt_dato?: string | null
          arbeidsdager_pr_uke?: number | null
          arbeidstid_per_uke?: number | null
          arkivert_arsak?: string | null
          arkivert_av?: string | null
          arkivert_dato?: string | null
          bankkontonummer?: string | null
          beste_del_av_arbeidsdagen?: string | null
          budsjett_kilde?: string | null
          created_at?: string | null
          effektivitet_prosent?: number | null
          epost?: string | null
          etternavn?: string | null
          fagbrev_dato?: string | null
          fastlonn?: number | null
          feriekrav_kommentar?: string | null
          feriekrav_timer_per_aar?: number
          feriekrav_type_enum?:
            | Database["public"]["Enums"]["feriekrav_type"]
            | null
          fodselsdato?: string | null
          foretrukket_feiring?: string | null
          fornavn: string
          frisorfunksjon?: Database["public"]["Enums"]["frisorfunksjon"] | null
          helseforsikring_avtalenummer?: string | null
          helseforsikring_oppsigelsesdato?: string | null
          helseforsikring_oppstartsdato?: string | null
          helseforsikring_pris?: number | null
          helseforsikring_status?: string | null
          hubspot_contact_id?: string | null
          hubspot_synced_at?: string | null
          id?: string
          inkluder_i_budsjett?: boolean | null
          inkluder_i_turnus?: boolean | null
          kjonn?: string | null
          kurs_sertifiseringer?: string | null
          lederstilling?: Database["public"]["Enums"]["lederstilling"] | null
          lonn_sist_justert?: string | null
          lonnstype_enum?: Database["public"]["Enums"]["lonnstype"] | null
          mentor_id?: string | null
          motivasjon_i_jobben?: string | null
          nasjonalitet?: string | null
          omsetning_per_time?: number | null
          oppsigelsesdato?: string | null
          personnummer?: string | null
          postnummer?: string | null
          poststed?: string | null
          profilbilde_url?: string | null
          provetid_til?: string | null
          provisjon_behandling_hoy_prosent?: number | null
          provisjon_behandling_prosent?: number | null
          provisjon_terskel?: number | null
          provisjon_vare_prosent?: number | null
          rebooking_prosent?: number | null
          salong_id?: string | null
          siste_arbeidsdag?: string | null
          status?: Database["public"]["Enums"]["ansatt_status"]
          stillingsprosent?: number
          telefon?: string | null
          timesats?: number | null
          updated_at?: string | null
          user_id?: string | null
          utdanning_fagbrev?: string | null
          varesalg_prosent?: number | null
          verdier?: string | null
        }
        Update: {
          adresse?: string | null
          ansatt_dato?: string | null
          arbeidsdager_pr_uke?: number | null
          arbeidstid_per_uke?: number | null
          arkivert_arsak?: string | null
          arkivert_av?: string | null
          arkivert_dato?: string | null
          bankkontonummer?: string | null
          beste_del_av_arbeidsdagen?: string | null
          budsjett_kilde?: string | null
          created_at?: string | null
          effektivitet_prosent?: number | null
          epost?: string | null
          etternavn?: string | null
          fagbrev_dato?: string | null
          fastlonn?: number | null
          feriekrav_kommentar?: string | null
          feriekrav_timer_per_aar?: number
          feriekrav_type_enum?:
            | Database["public"]["Enums"]["feriekrav_type"]
            | null
          fodselsdato?: string | null
          foretrukket_feiring?: string | null
          fornavn?: string
          frisorfunksjon?: Database["public"]["Enums"]["frisorfunksjon"] | null
          helseforsikring_avtalenummer?: string | null
          helseforsikring_oppsigelsesdato?: string | null
          helseforsikring_oppstartsdato?: string | null
          helseforsikring_pris?: number | null
          helseforsikring_status?: string | null
          hubspot_contact_id?: string | null
          hubspot_synced_at?: string | null
          id?: string
          inkluder_i_budsjett?: boolean | null
          inkluder_i_turnus?: boolean | null
          kjonn?: string | null
          kurs_sertifiseringer?: string | null
          lederstilling?: Database["public"]["Enums"]["lederstilling"] | null
          lonn_sist_justert?: string | null
          lonnstype_enum?: Database["public"]["Enums"]["lonnstype"] | null
          mentor_id?: string | null
          motivasjon_i_jobben?: string | null
          nasjonalitet?: string | null
          omsetning_per_time?: number | null
          oppsigelsesdato?: string | null
          personnummer?: string | null
          postnummer?: string | null
          poststed?: string | null
          profilbilde_url?: string | null
          provetid_til?: string | null
          provisjon_behandling_hoy_prosent?: number | null
          provisjon_behandling_prosent?: number | null
          provisjon_terskel?: number | null
          provisjon_vare_prosent?: number | null
          rebooking_prosent?: number | null
          salong_id?: string | null
          siste_arbeidsdag?: string | null
          status?: Database["public"]["Enums"]["ansatt_status"]
          stillingsprosent?: number
          telefon?: string | null
          timesats?: number | null
          updated_at?: string | null
          user_id?: string | null
          utdanning_fagbrev?: string | null
          varesalg_prosent?: number | null
          verdier?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "ansatte_salong_id_fkey"
            columns: ["salong_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_ansatte_mentor"
            columns: ["mentor_id"]
            isOneToOne: false
            referencedRelation: "ansatte"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_ansatte_mentor"
            columns: ["mentor_id"]
            isOneToOne: false
            referencedRelation: "ansatte_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_ansatte_mentor"
            columns: ["mentor_id"]
            isOneToOne: false
            referencedRelation: "ansatte_utvidet"
            referencedColumns: ["id"]
          },
        ]
      }
      auth_otp: {
        Row: {
          attempts: number | null
          created_at: string | null
          email: string | null
          expires_at: string
          id: string
          otp_hash: string
          phone_number: string | null
          verified: boolean | null
        }
        Insert: {
          attempts?: number | null
          created_at?: string | null
          email?: string | null
          expires_at: string
          id?: string
          otp_hash: string
          phone_number?: string | null
          verified?: boolean | null
        }
        Update: {
          attempts?: number | null
          created_at?: string | null
          email?: string | null
          expires_at?: string
          id?: string
          otp_hash?: string
          phone_number?: string | null
          verified?: boolean | null
        }
        Relationships: []
      }
      avtale_logg: {
        Row: {
          avtale_id: string
          created_at: string | null
          detaljer: string | null
          hendelse: string
          id: string
          utfort_av: string | null
        }
        Insert: {
          avtale_id: string
          created_at?: string | null
          detaljer?: string | null
          hendelse: string
          id?: string
          utfort_av?: string | null
        }
        Update: {
          avtale_id?: string
          created_at?: string | null
          detaljer?: string | null
          hendelse?: string
          id?: string
          utfort_av?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "avtale_logg_avtale_id_fkey"
            columns: ["avtale_id"]
            isOneToOne: false
            referencedRelation: "avtaler"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "avtale_logg_utfort_av_fkey"
            columns: ["utfort_av"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "avtale_logg_utfort_av_fkey"
            columns: ["utfort_av"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "avtale_logg_utfort_av_fkey"
            columns: ["utfort_av"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      avtaler: {
        Row: {
          adobe_agreement_id: string | null
          avtale_type: string
          completed_at: string | null
          created_at: string | null
          created_by: string | null
          district_id: string | null
          hubspot_owner_id: string | null
          id: string
          innmelding_utkast_id: string | null
          kontaktperson_epost: string | null
          kontaktperson_navn: string | null
          medlemsniva: string | null
          org_nummer: string
          pdf_draft_url: string | null
          salon_id: string | null
          salongnavn: string
          sent_at: string | null
          signed_at: string | null
          signed_pdf_url: string | null
          signing_status: string | null
          startdato: string | null
          updated_at: string | null
          viewed_at: string | null
        }
        Insert: {
          adobe_agreement_id?: string | null
          avtale_type?: string
          completed_at?: string | null
          created_at?: string | null
          created_by?: string | null
          district_id?: string | null
          hubspot_owner_id?: string | null
          id?: string
          innmelding_utkast_id?: string | null
          kontaktperson_epost?: string | null
          kontaktperson_navn?: string | null
          medlemsniva?: string | null
          org_nummer: string
          pdf_draft_url?: string | null
          salon_id?: string | null
          salongnavn: string
          sent_at?: string | null
          signed_at?: string | null
          signed_pdf_url?: string | null
          signing_status?: string | null
          startdato?: string | null
          updated_at?: string | null
          viewed_at?: string | null
        }
        Update: {
          adobe_agreement_id?: string | null
          avtale_type?: string
          completed_at?: string | null
          created_at?: string | null
          created_by?: string | null
          district_id?: string | null
          hubspot_owner_id?: string | null
          id?: string
          innmelding_utkast_id?: string | null
          kontaktperson_epost?: string | null
          kontaktperson_navn?: string | null
          medlemsniva?: string | null
          org_nummer?: string
          pdf_draft_url?: string | null
          salon_id?: string | null
          salongnavn?: string
          sent_at?: string | null
          signed_at?: string | null
          signed_pdf_url?: string | null
          signing_status?: string | null
          startdato?: string | null
          updated_at?: string | null
          viewed_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "avtaler_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "avtaler_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "avtaler_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "avtaler_district_id_fkey"
            columns: ["district_id"]
            isOneToOne: false
            referencedRelation: "districts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "avtaler_innmelding_utkast_id_fkey"
            columns: ["innmelding_utkast_id"]
            isOneToOne: false
            referencedRelation: "innmelding_utkast"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "avtaler_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
        ]
      }
      badges: {
        Row: {
          created_at: string | null
          criteria_type: string
          criteria_value: number | null
          description: string | null
          icon_key: string
          id: string
          name: string
        }
        Insert: {
          created_at?: string | null
          criteria_type: string
          criteria_value?: number | null
          description?: string | null
          icon_key: string
          id?: string
          name: string
        }
        Update: {
          created_at?: string | null
          criteria_type?: string
          criteria_value?: number | null
          description?: string | null
          icon_key?: string
          id?: string
          name?: string
        }
        Relationships: []
      }
      bonus_baseline_overrides: {
        Row: {
          created_at: string | null
          created_by: string | null
          id: string
          override_turnover: number
          reason: string | null
          salon_id: string
          supplier_id: string
          updated_at: string | null
          year: number
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          id?: string
          override_turnover: number
          reason?: string | null
          salon_id: string
          supplier_id: string
          updated_at?: string | null
          year: number
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          id?: string
          override_turnover?: number
          reason?: string | null
          salon_id?: string
          supplier_id?: string
          updated_at?: string | null
          year?: number
        }
        Relationships: [
          {
            foreignKeyName: "bonus_baseline_overrides_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bonus_baseline_overrides_supplier_id_fkey"
            columns: ["supplier_id"]
            isOneToOne: false
            referencedRelation: "leverandorer"
            referencedColumns: ["id"]
          },
        ]
      }
      bonus_calculations: {
        Row: {
          applied_rule_ids: string[] | null
          approved_at: string | null
          approved_by: string | null
          calculated_at: string | null
          calculated_by: string | null
          calculation_details: Json | null
          created_at: string | null
          id: string
          loyalty_bonus_amount: number | null
          period: string
          return_commission_amount: number | null
          salon_id: string | null
          status: Database["public"]["Enums"]["bonus_calculation_status"] | null
          supplier_id: string
          total_bonus: number | null
          total_turnover: number | null
          updated_at: string | null
        }
        Insert: {
          applied_rule_ids?: string[] | null
          approved_at?: string | null
          approved_by?: string | null
          calculated_at?: string | null
          calculated_by?: string | null
          calculation_details?: Json | null
          created_at?: string | null
          id?: string
          loyalty_bonus_amount?: number | null
          period: string
          return_commission_amount?: number | null
          salon_id?: string | null
          status?:
            | Database["public"]["Enums"]["bonus_calculation_status"]
            | null
          supplier_id: string
          total_bonus?: number | null
          total_turnover?: number | null
          updated_at?: string | null
        }
        Update: {
          applied_rule_ids?: string[] | null
          approved_at?: string | null
          approved_by?: string | null
          calculated_at?: string | null
          calculated_by?: string | null
          calculation_details?: Json | null
          created_at?: string | null
          id?: string
          loyalty_bonus_amount?: number | null
          period?: string
          return_commission_amount?: number | null
          salon_id?: string | null
          status?:
            | Database["public"]["Enums"]["bonus_calculation_status"]
            | null
          supplier_id?: string
          total_bonus?: number | null
          total_turnover?: number | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "bonus_calculations_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bonus_calculations_supplier_id_fkey"
            columns: ["supplier_id"]
            isOneToOne: false
            referencedRelation: "leverandorer"
            referencedColumns: ["id"]
          },
        ]
      }
      bonus_cumulative_baselines: {
        Row: {
          created_at: string | null
          created_by: string | null
          cumulative_value: number
          id: string
          period: string
          reason: string | null
          salon_id: string
          supplier_id: string
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          cumulative_value?: number
          id?: string
          period: string
          reason?: string | null
          salon_id: string
          supplier_id: string
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          cumulative_value?: number
          id?: string
          period?: string
          reason?: string | null
          salon_id?: string
          supplier_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "bonus_cumulative_baselines_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bonus_cumulative_baselines_supplier_id_fkey"
            columns: ["supplier_id"]
            isOneToOne: false
            referencedRelation: "leverandorer"
            referencedColumns: ["id"]
          },
        ]
      }
      bonus_import_batches: {
        Row: {
          error_count: number | null
          file_name: string | null
          file_url: string | null
          id: string
          imported_at: string | null
          imported_by: string | null
          matched_count: number | null
          notes: string | null
          period: string
          processed_at: string | null
          row_count: number | null
          status: string | null
          supplier_id: string
        }
        Insert: {
          error_count?: number | null
          file_name?: string | null
          file_url?: string | null
          id?: string
          imported_at?: string | null
          imported_by?: string | null
          matched_count?: number | null
          notes?: string | null
          period: string
          processed_at?: string | null
          row_count?: number | null
          status?: string | null
          supplier_id: string
        }
        Update: {
          error_count?: number | null
          file_name?: string | null
          file_url?: string | null
          id?: string
          imported_at?: string | null
          imported_by?: string | null
          matched_count?: number | null
          notes?: string | null
          period?: string
          processed_at?: string | null
          row_count?: number | null
          status?: string | null
          supplier_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "bonus_import_batches_supplier_id_fkey"
            columns: ["supplier_id"]
            isOneToOne: false
            referencedRelation: "leverandorer"
            referencedColumns: ["id"]
          },
        ]
      }
      bonus_imported_sales: {
        Row: {
          batch_id: string
          brand: string | null
          created_at: string | null
          cumulative_value: number | null
          error_message: string | null
          id: string
          match_confidence: number | null
          match_method: string | null
          match_status:
            | Database["public"]["Enums"]["import_match_status"]
            | null
          matched_salon_id: string | null
          product_group: string | null
          raw_identifier: string | null
          raw_name: string | null
          reported_period: string
          reported_value: number
          supplier_id: string
        }
        Insert: {
          batch_id: string
          brand?: string | null
          created_at?: string | null
          cumulative_value?: number | null
          error_message?: string | null
          id?: string
          match_confidence?: number | null
          match_method?: string | null
          match_status?:
            | Database["public"]["Enums"]["import_match_status"]
            | null
          matched_salon_id?: string | null
          product_group?: string | null
          raw_identifier?: string | null
          raw_name?: string | null
          reported_period: string
          reported_value: number
          supplier_id: string
        }
        Update: {
          batch_id?: string
          brand?: string | null
          created_at?: string | null
          cumulative_value?: number | null
          error_message?: string | null
          id?: string
          match_confidence?: number | null
          match_method?: string | null
          match_status?:
            | Database["public"]["Enums"]["import_match_status"]
            | null
          matched_salon_id?: string | null
          product_group?: string | null
          raw_identifier?: string | null
          raw_name?: string | null
          reported_period?: string
          reported_value?: number
          supplier_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "bonus_imported_sales_batch_id_fkey"
            columns: ["batch_id"]
            isOneToOne: false
            referencedRelation: "bonus_import_batches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bonus_imported_sales_matched_salon_id_fkey"
            columns: ["matched_salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bonus_imported_sales_supplier_id_fkey"
            columns: ["supplier_id"]
            isOneToOne: false
            referencedRelation: "leverandorer"
            referencedColumns: ["id"]
          },
        ]
      }
      bonus_normalized_sales: {
        Row: {
          brand_id: string | null
          brand_name: string | null
          created_at: string | null
          delta_turnover: number | null
          id: string
          is_cumulative: boolean | null
          is_locked: boolean | null
          period: string
          product_group: string | null
          rapporteringstype:
            | Database["public"]["Enums"]["rapporteringstype"]
            | null
          salon_id: string
          source_batch_id: string | null
          supplier_id: string
          turnover: number
          updated_at: string | null
        }
        Insert: {
          brand_id?: string | null
          brand_name?: string | null
          created_at?: string | null
          delta_turnover?: number | null
          id?: string
          is_cumulative?: boolean | null
          is_locked?: boolean | null
          period: string
          product_group?: string | null
          rapporteringstype?:
            | Database["public"]["Enums"]["rapporteringstype"]
            | null
          salon_id: string
          source_batch_id?: string | null
          supplier_id: string
          turnover: number
          updated_at?: string | null
        }
        Update: {
          brand_id?: string | null
          brand_name?: string | null
          created_at?: string | null
          delta_turnover?: number | null
          id?: string
          is_cumulative?: boolean | null
          is_locked?: boolean | null
          period?: string
          product_group?: string | null
          rapporteringstype?:
            | Database["public"]["Enums"]["rapporteringstype"]
            | null
          salon_id?: string
          source_batch_id?: string | null
          supplier_id?: string
          turnover?: number
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "bonus_normalized_sales_brand_id_fkey"
            columns: ["brand_id"]
            isOneToOne: false
            referencedRelation: "leverandor_merker"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bonus_normalized_sales_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bonus_normalized_sales_source_batch_id_fkey"
            columns: ["source_batch_id"]
            isOneToOne: false
            referencedRelation: "bonus_import_batches"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bonus_normalized_sales_supplier_id_fkey"
            columns: ["supplier_id"]
            isOneToOne: false
            referencedRelation: "leverandorer"
            referencedColumns: ["id"]
          },
        ]
      }
      bonus_rules: {
        Row: {
          brand_id: string | null
          created_at: string | null
          created_by: string | null
          description: string | null
          id: string
          is_active: boolean | null
          kjemi_lojalitet_prosent: number | null
          kjemi_prosent: number | null
          kjemi_retur_prosent: number | null
          lojalitetsbonus_prosent: number | null
          max_turnover: number | null
          min_turnover: number | null
          percentage: number
          priority: number | null
          product_group: string | null
          produkt_lojalitet_prosent: number | null
          produkt_prosent: number | null
          produkt_retur_prosent: number | null
          produkttype: Database["public"]["Enums"]["produkttype"] | null
          rapporteringstype:
            | Database["public"]["Enums"]["rapporteringstype"]
            | null
          returprovisjon_prosent: number | null
          rule_type: Database["public"]["Enums"]["bonus_rule_type"]
          supplier_id: string
          updated_at: string | null
          valid_from: string
          valid_to: string | null
        }
        Insert: {
          brand_id?: string | null
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          id?: string
          is_active?: boolean | null
          kjemi_lojalitet_prosent?: number | null
          kjemi_prosent?: number | null
          kjemi_retur_prosent?: number | null
          lojalitetsbonus_prosent?: number | null
          max_turnover?: number | null
          min_turnover?: number | null
          percentage: number
          priority?: number | null
          product_group?: string | null
          produkt_lojalitet_prosent?: number | null
          produkt_prosent?: number | null
          produkt_retur_prosent?: number | null
          produkttype?: Database["public"]["Enums"]["produkttype"] | null
          rapporteringstype?:
            | Database["public"]["Enums"]["rapporteringstype"]
            | null
          returprovisjon_prosent?: number | null
          rule_type: Database["public"]["Enums"]["bonus_rule_type"]
          supplier_id: string
          updated_at?: string | null
          valid_from: string
          valid_to?: string | null
        }
        Update: {
          brand_id?: string | null
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          id?: string
          is_active?: boolean | null
          kjemi_lojalitet_prosent?: number | null
          kjemi_prosent?: number | null
          kjemi_retur_prosent?: number | null
          lojalitetsbonus_prosent?: number | null
          max_turnover?: number | null
          min_turnover?: number | null
          percentage?: number
          priority?: number | null
          product_group?: string | null
          produkt_lojalitet_prosent?: number | null
          produkt_prosent?: number | null
          produkt_retur_prosent?: number | null
          produkttype?: Database["public"]["Enums"]["produkttype"] | null
          rapporteringstype?:
            | Database["public"]["Enums"]["rapporteringstype"]
            | null
          returprovisjon_prosent?: number | null
          rule_type?: Database["public"]["Enums"]["bonus_rule_type"]
          supplier_id?: string
          updated_at?: string | null
          valid_from?: string
          valid_to?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "bonus_rules_brand_id_fkey"
            columns: ["brand_id"]
            isOneToOne: false
            referencedRelation: "leverandor_merker"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bonus_rules_supplier_id_fkey"
            columns: ["supplier_id"]
            isOneToOne: false
            referencedRelation: "leverandorer"
            referencedColumns: ["id"]
          },
        ]
      }
      budsjett: {
        Row: {
          aar: number
          ansatt_id: string | null
          arsak_null_timer:
            | Database["public"]["Enums"]["budsjett_arsak_null"]
            | null
          behandling_budsjett: number | null
          created_at: string | null
          dag: number
          dato: string
          id: string
          kundetimer: number | null
          maned: number
          planlagte_timer: number | null
          salon_id: string
          totalt_budsjett: number | null
          uke: number
          updated_at: string | null
          user_id: string | null
          vare_budsjett: number | null
          versjon_id: string
        }
        Insert: {
          aar: number
          ansatt_id?: string | null
          arsak_null_timer?:
            | Database["public"]["Enums"]["budsjett_arsak_null"]
            | null
          behandling_budsjett?: number | null
          created_at?: string | null
          dag: number
          dato: string
          id?: string
          kundetimer?: number | null
          maned: number
          planlagte_timer?: number | null
          salon_id: string
          totalt_budsjett?: number | null
          uke: number
          updated_at?: string | null
          user_id?: string | null
          vare_budsjett?: number | null
          versjon_id: string
        }
        Update: {
          aar?: number
          ansatt_id?: string | null
          arsak_null_timer?:
            | Database["public"]["Enums"]["budsjett_arsak_null"]
            | null
          behandling_budsjett?: number | null
          created_at?: string | null
          dag?: number
          dato?: string
          id?: string
          kundetimer?: number | null
          maned?: number
          planlagte_timer?: number | null
          salon_id?: string
          totalt_budsjett?: number | null
          uke?: number
          updated_at?: string | null
          user_id?: string | null
          vare_budsjett?: number | null
          versjon_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "budsjett_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "budsjett_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "budsjett_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_utvidet"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "budsjett_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "budsjett_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "budsjett_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "budsjett_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "budsjett_versjon_id_fkey"
            columns: ["versjon_id"]
            isOneToOne: false
            referencedRelation: "budsjett_versjoner"
            referencedColumns: ["id"]
          },
        ]
      }
      budsjett_fastsatt: {
        Row: {
          created_at: string | null
          fastsatt_arsbudsjett: number
          fastsatt_behandling: number
          fastsatt_timer: number | null
          fastsatt_vare: number
          godkjent_av: string | null
          godkjent_dato: string | null
          id: string
          salon_id: string
          updated_at: string | null
          user_id: string
          versjon_id: string
        }
        Insert: {
          created_at?: string | null
          fastsatt_arsbudsjett?: number
          fastsatt_behandling?: number
          fastsatt_timer?: number | null
          fastsatt_vare?: number
          godkjent_av?: string | null
          godkjent_dato?: string | null
          id?: string
          salon_id: string
          updated_at?: string | null
          user_id: string
          versjon_id: string
        }
        Update: {
          created_at?: string | null
          fastsatt_arsbudsjett?: number
          fastsatt_behandling?: number
          fastsatt_timer?: number | null
          fastsatt_vare?: number
          godkjent_av?: string | null
          godkjent_dato?: string | null
          id?: string
          salon_id?: string
          updated_at?: string | null
          user_id?: string
          versjon_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "budsjett_fastsatt_godkjent_av_fkey"
            columns: ["godkjent_av"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "budsjett_fastsatt_godkjent_av_fkey"
            columns: ["godkjent_av"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "budsjett_fastsatt_godkjent_av_fkey"
            columns: ["godkjent_av"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "budsjett_fastsatt_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "budsjett_fastsatt_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "budsjett_fastsatt_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "budsjett_fastsatt_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "budsjett_fastsatt_versjon_id_fkey"
            columns: ["versjon_id"]
            isOneToOne: false
            referencedRelation: "budsjett_versjoner"
            referencedColumns: ["id"]
          },
        ]
      }
      budsjett_manuelt: {
        Row: {
          ansatt_id: string
          behandling_budsjett: number | null
          beskrivelse: string | null
          created_at: string | null
          id: string
          maned: number
          salon_id: string
          updated_at: string | null
          vare_budsjett: number | null
          versjon_id: string
        }
        Insert: {
          ansatt_id: string
          behandling_budsjett?: number | null
          beskrivelse?: string | null
          created_at?: string | null
          id?: string
          maned: number
          salon_id: string
          updated_at?: string | null
          vare_budsjett?: number | null
          versjon_id: string
        }
        Update: {
          ansatt_id?: string
          behandling_budsjett?: number | null
          beskrivelse?: string | null
          created_at?: string | null
          id?: string
          maned?: number
          salon_id?: string
          updated_at?: string | null
          vare_budsjett?: number | null
          versjon_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "budsjett_manuelt_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "budsjett_manuelt_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "budsjett_manuelt_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_utvidet"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "budsjett_manuelt_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "budsjett_manuelt_versjon_id_fkey"
            columns: ["versjon_id"]
            isOneToOne: false
            referencedRelation: "budsjett_versjoner"
            referencedColumns: ["id"]
          },
        ]
      }
      budsjett_versjoner: {
        Row: {
          aar: number
          beskrivelse: string | null
          created_at: string | null
          er_aktiv: boolean | null
          godkjent_av: string | null
          godkjent_dato: string | null
          id: string
          opprettet_av: string | null
          salon_id: string
          updated_at: string | null
          versjon_navn: string
          versjon_nummer: number
        }
        Insert: {
          aar: number
          beskrivelse?: string | null
          created_at?: string | null
          er_aktiv?: boolean | null
          godkjent_av?: string | null
          godkjent_dato?: string | null
          id?: string
          opprettet_av?: string | null
          salon_id: string
          updated_at?: string | null
          versjon_navn?: string
          versjon_nummer?: number
        }
        Update: {
          aar?: number
          beskrivelse?: string | null
          created_at?: string | null
          er_aktiv?: boolean | null
          godkjent_av?: string | null
          godkjent_dato?: string | null
          id?: string
          opprettet_av?: string | null
          salon_id?: string
          updated_at?: string | null
          versjon_navn?: string
          versjon_nummer?: number
        }
        Relationships: [
          {
            foreignKeyName: "budsjett_versjoner_godkjent_av_fkey"
            columns: ["godkjent_av"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "budsjett_versjoner_godkjent_av_fkey"
            columns: ["godkjent_av"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "budsjett_versjoner_godkjent_av_fkey"
            columns: ["godkjent_av"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "budsjett_versjoner_opprettet_av_fkey"
            columns: ["opprettet_av"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "budsjett_versjoner_opprettet_av_fkey"
            columns: ["opprettet_av"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "budsjett_versjoner_opprettet_av_fkey"
            columns: ["opprettet_av"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "budsjett_versjoner_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
        ]
      }
      chains: {
        Row: {
          created_at: string | null
          hubspot_company_id: string | null
          hubspot_synced_at: string | null
          id: string
          logo_url: string | null
          name: string
          org_number: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          hubspot_company_id?: string | null
          hubspot_synced_at?: string | null
          id?: string
          logo_url?: string | null
          name: string
          org_number?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          hubspot_company_id?: string | null
          hubspot_synced_at?: string | null
          id?: string
          logo_url?: string | null
          name?: string
          org_number?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      challenge_progress: {
        Row: {
          achieved: boolean | null
          created_at: string | null
          id: string
          month: number
          period_type: string
          progress_value: number | null
          salon_id: string | null
          updated_at: string | null
          year: number
        }
        Insert: {
          achieved?: boolean | null
          created_at?: string | null
          id?: string
          month: number
          period_type?: string
          progress_value?: number | null
          salon_id?: string | null
          updated_at?: string | null
          year: number
        }
        Update: {
          achieved?: boolean | null
          created_at?: string | null
          id?: string
          month?: number
          period_type?: string
          progress_value?: number | null
          salon_id?: string | null
          updated_at?: string | null
          year?: number
        }
        Relationships: [
          {
            foreignKeyName: "challenge_progress_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
        ]
      }
      daily_kpi_inputs: {
        Row: {
          addon_count: number | null
          addon_revenue: number | null
          ansatt_id: string
          created_at: string | null
          date: string
          id: string
          is_draft: boolean | null
          rebooked_visits: number | null
          retail_revenue: number | null
          salon_id: string
          treatment_revenue: number | null
          updated_at: string | null
          visit_count: number | null
          visits_with_addon: number | null
        }
        Insert: {
          addon_count?: number | null
          addon_revenue?: number | null
          ansatt_id: string
          created_at?: string | null
          date: string
          id?: string
          is_draft?: boolean | null
          rebooked_visits?: number | null
          retail_revenue?: number | null
          salon_id: string
          treatment_revenue?: number | null
          updated_at?: string | null
          visit_count?: number | null
          visits_with_addon?: number | null
        }
        Update: {
          addon_count?: number | null
          addon_revenue?: number | null
          ansatt_id?: string
          created_at?: string | null
          date?: string
          id?: string
          is_draft?: boolean | null
          rebooked_visits?: number | null
          retail_revenue?: number | null
          salon_id?: string
          treatment_revenue?: number | null
          updated_at?: string | null
          visit_count?: number | null
          visits_with_addon?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "daily_kpi_inputs_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "daily_kpi_inputs_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "daily_kpi_inputs_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_utvidet"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "daily_kpi_inputs_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
        ]
      }
      daily_time_entries: {
        Row: {
          ansatt_id: string
          break_minutes: number | null
          created_at: string | null
          date: string
          end_time: string
          hours_with_client: number | null
          id: string
          salon_id: string
          start_time: string
          updated_at: string | null
        }
        Insert: {
          ansatt_id: string
          break_minutes?: number | null
          created_at?: string | null
          date: string
          end_time: string
          hours_with_client?: number | null
          id?: string
          salon_id: string
          start_time: string
          updated_at?: string | null
        }
        Update: {
          ansatt_id?: string
          break_minutes?: number | null
          created_at?: string | null
          date?: string
          end_time?: string
          hours_with_client?: number | null
          id?: string
          salon_id?: string
          start_time?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "daily_time_entries_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "daily_time_entries_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "daily_time_entries_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_utvidet"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "daily_time_entries_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
        ]
      }
      districts: {
        Row: {
          created_at: string | null
          id: string
          name: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          name: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          name?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      email_module_library: {
        Row: {
          created_at: string | null
          created_by: string | null
          default_content: Json
          default_styles: Json | null
          description: string | null
          id: string
          is_system_module: boolean | null
          name: string
          preview_image_url: string | null
          type: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          default_content?: Json
          default_styles?: Json | null
          description?: string | null
          id?: string
          is_system_module?: boolean | null
          name: string
          preview_image_url?: string | null
          type: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          default_content?: Json
          default_styles?: Json | null
          description?: string | null
          id?: string
          is_system_module?: boolean | null
          name?: string
          preview_image_url?: string | null
          type?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "email_module_library_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "email_module_library_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "email_module_library_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      email_template_versions: {
        Row: {
          change_notes: string | null
          created_at: string | null
          created_by: string | null
          id: string
          structure: Json
          subject_template: string | null
          template_id: string
          version_number: number
        }
        Insert: {
          change_notes?: string | null
          created_at?: string | null
          created_by?: string | null
          id?: string
          structure: Json
          subject_template?: string | null
          template_id: string
          version_number: number
        }
        Update: {
          change_notes?: string | null
          created_at?: string | null
          created_by?: string | null
          id?: string
          structure?: Json
          subject_template?: string | null
          template_id?: string
          version_number?: number
        }
        Relationships: [
          {
            foreignKeyName: "email_template_versions_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "email_template_versions_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "email_template_versions_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "email_template_versions_template_id_fkey"
            columns: ["template_id"]
            isOneToOne: false
            referencedRelation: "email_templates"
            referencedColumns: ["id"]
          },
        ]
      }
      email_templates: {
        Row: {
          category: string
          created_at: string | null
          created_by: string | null
          description: string | null
          id: string
          is_system_template: boolean | null
          name: string
          published_at: string | null
          slug: string
          status: string
          structure: Json
          subject_template: string | null
          tags: string[] | null
          updated_at: string | null
        }
        Insert: {
          category?: string
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          id?: string
          is_system_template?: boolean | null
          name: string
          published_at?: string | null
          slug: string
          status?: string
          structure?: Json
          subject_template?: string | null
          tags?: string[] | null
          updated_at?: string | null
        }
        Update: {
          category?: string
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          id?: string
          is_system_template?: boolean | null
          name?: string
          published_at?: string | null
          slug?: string
          status?: string
          structure?: Json
          subject_template?: string | null
          tags?: string[] | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "email_templates_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "email_templates_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "email_templates_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      ferie: {
        Row: {
          aar: number
          ansatt_id: string | null
          antall_dager: number | null
          created_at: string | null
          godkjent_av: string | null
          godkjent_dato: string | null
          id: string
          kommentar: string | null
          salon_id: string
          sluttdato: string
          startdato: string
          status: Database["public"]["Enums"]["ferie_status"] | null
          timer: number | null
          type: string | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          aar: number
          ansatt_id?: string | null
          antall_dager?: number | null
          created_at?: string | null
          godkjent_av?: string | null
          godkjent_dato?: string | null
          id?: string
          kommentar?: string | null
          salon_id: string
          sluttdato: string
          startdato: string
          status?: Database["public"]["Enums"]["ferie_status"] | null
          timer?: number | null
          type?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          aar?: number
          ansatt_id?: string | null
          antall_dager?: number | null
          created_at?: string | null
          godkjent_av?: string | null
          godkjent_dato?: string | null
          id?: string
          kommentar?: string | null
          salon_id?: string
          sluttdato?: string
          startdato?: string
          status?: Database["public"]["Enums"]["ferie_status"] | null
          timer?: number | null
          type?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "ferie_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ferie_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ferie_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_utvidet"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ferie_godkjent_av_fkey"
            columns: ["godkjent_av"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ferie_godkjent_av_fkey"
            columns: ["godkjent_av"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ferie_godkjent_av_fkey"
            columns: ["godkjent_av"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ferie_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ferie_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ferie_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ferie_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      ferie_overforing: {
        Row: {
          created_at: string | null
          fra_aar: number
          godkjent_av: string | null
          godkjent_dato: string | null
          id: string
          kommentar: string | null
          til_aar: number
          timer: number
          user_id: string
        }
        Insert: {
          created_at?: string | null
          fra_aar: number
          godkjent_av?: string | null
          godkjent_dato?: string | null
          id?: string
          kommentar?: string | null
          til_aar: number
          timer: number
          user_id: string
        }
        Update: {
          created_at?: string | null
          fra_aar?: number
          godkjent_av?: string | null
          godkjent_dato?: string | null
          id?: string
          kommentar?: string | null
          til_aar?: number
          timer?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "ferie_overforing_godkjent_av_fkey"
            columns: ["godkjent_av"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ferie_overforing_godkjent_av_fkey"
            columns: ["godkjent_av"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ferie_overforing_godkjent_av_fkey"
            columns: ["godkjent_av"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ferie_overforing_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ferie_overforing_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ferie_overforing_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      fravaer: {
        Row: {
          ansatt_id: string | null
          created_at: string | null
          dokumentasjon_url: string | null
          fravaerstype: Database["public"]["Enums"]["fravaerstype"]
          id: string
          kommentar: string | null
          prosent: number | null
          registrert_av: string | null
          salon_id: string
          sluttdato: string
          startdato: string
          status: string | null
          timer: number | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          ansatt_id?: string | null
          created_at?: string | null
          dokumentasjon_url?: string | null
          fravaerstype: Database["public"]["Enums"]["fravaerstype"]
          id?: string
          kommentar?: string | null
          prosent?: number | null
          registrert_av?: string | null
          salon_id: string
          sluttdato: string
          startdato: string
          status?: string | null
          timer?: number | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          ansatt_id?: string | null
          created_at?: string | null
          dokumentasjon_url?: string | null
          fravaerstype?: Database["public"]["Enums"]["fravaerstype"]
          id?: string
          kommentar?: string | null
          prosent?: number | null
          registrert_av?: string | null
          salon_id?: string
          sluttdato?: string
          startdato?: string
          status?: string | null
          timer?: number | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "fravaer_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fravaer_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fravaer_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_utvidet"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fravaer_registrert_av_fkey"
            columns: ["registrert_av"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fravaer_registrert_av_fkey"
            columns: ["registrert_av"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fravaer_registrert_av_fkey"
            columns: ["registrert_av"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fravaer_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fravaer_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fravaer_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fravaer_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      historical_imports: {
        Row: {
          error_message: string | null
          file_name: string
          id: string
          imported_at: string | null
          imported_by_user_id: string | null
          rows_imported: number | null
          salon_id: string | null
          status: string | null
        }
        Insert: {
          error_message?: string | null
          file_name: string
          id?: string
          imported_at?: string | null
          imported_by_user_id?: string | null
          rows_imported?: number | null
          salon_id?: string | null
          status?: string | null
        }
        Update: {
          error_message?: string | null
          file_name?: string
          id?: string
          imported_at?: string | null
          imported_by_user_id?: string | null
          rows_imported?: number | null
          salon_id?: string | null
          status?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "historical_imports_imported_by_user_id_fkey"
            columns: ["imported_by_user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "historical_imports_imported_by_user_id_fkey"
            columns: ["imported_by_user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "historical_imports_imported_by_user_id_fkey"
            columns: ["imported_by_user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "historical_imports_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
        ]
      }
      historiske_tall: {
        Row: {
          aar: number
          behandling_kr: number | null
          created_at: string | null
          dag: number | null
          dato: string | null
          id: string
          kilde: string | null
          kunder: number | null
          maned: number | null
          salon_id: string
          timer_jobbet: number | null
          total_kr: number | null
          uke: number | null
          user_id: string | null
          vare_kr: number | null
        }
        Insert: {
          aar: number
          behandling_kr?: number | null
          created_at?: string | null
          dag?: number | null
          dato?: string | null
          id?: string
          kilde?: string | null
          kunder?: number | null
          maned?: number | null
          salon_id: string
          timer_jobbet?: number | null
          total_kr?: number | null
          uke?: number | null
          user_id?: string | null
          vare_kr?: number | null
        }
        Update: {
          aar?: number
          behandling_kr?: number | null
          created_at?: string | null
          dag?: number | null
          dato?: string | null
          id?: string
          kilde?: string | null
          kunder?: number | null
          maned?: number | null
          salon_id?: string
          timer_jobbet?: number | null
          total_kr?: number | null
          uke?: number | null
          user_id?: string | null
          vare_kr?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "historiske_tall_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "historiske_tall_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "historiske_tall_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "historiske_tall_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      hubspot_oauth_tokens: {
        Row: {
          access_token: string
          created_at: string | null
          expires_at: string
          id: string
          refresh_token: string
          updated_at: string | null
        }
        Insert: {
          access_token: string
          created_at?: string | null
          expires_at: string
          id?: string
          refresh_token: string
          updated_at?: string | null
        }
        Update: {
          access_token?: string
          created_at?: string | null
          expires_at?: string
          id?: string
          refresh_token?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      hubspot_owner_district_mapping: {
        Row: {
          created_at: string | null
          district_id: string | null
          hubspot_owner_email: string | null
          hubspot_owner_id: string
          hubspot_owner_name: string | null
          id: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          district_id?: string | null
          hubspot_owner_email?: string | null
          hubspot_owner_id: string
          hubspot_owner_name?: string | null
          id?: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          district_id?: string | null
          hubspot_owner_email?: string | null
          hubspot_owner_id?: string
          hubspot_owner_name?: string | null
          id?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "hubspot_owner_district_mapping_district_id_fkey"
            columns: ["district_id"]
            isOneToOne: false
            referencedRelation: "districts"
            referencedColumns: ["id"]
          },
        ]
      }
      innmelding_utkast: {
        Row: {
          agreement_sent_at: string | null
          agreement_signed_at: string | null
          avtale_status: string | null
          created_at: string
          created_by: string
          current_step: number
          id: string
          member_activated_at: string | null
          org_nummer: string
          pdf_draft_url: string | null
          prospekt_id: string | null
          salongnavn: string
          signed_pdf_url: string | null
          status: string
          updated_at: string
          wizard_data: Json
        }
        Insert: {
          agreement_sent_at?: string | null
          agreement_signed_at?: string | null
          avtale_status?: string | null
          created_at?: string
          created_by: string
          current_step?: number
          id?: string
          member_activated_at?: string | null
          org_nummer: string
          pdf_draft_url?: string | null
          prospekt_id?: string | null
          salongnavn: string
          signed_pdf_url?: string | null
          status?: string
          updated_at?: string
          wizard_data?: Json
        }
        Update: {
          agreement_sent_at?: string | null
          agreement_signed_at?: string | null
          avtale_status?: string | null
          created_at?: string
          created_by?: string
          current_step?: number
          id?: string
          member_activated_at?: string | null
          org_nummer?: string
          pdf_draft_url?: string | null
          prospekt_id?: string | null
          salongnavn?: string
          signed_pdf_url?: string | null
          status?: string
          updated_at?: string
          wizard_data?: Json
        }
        Relationships: [
          {
            foreignKeyName: "innmelding_utkast_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "innmelding_utkast_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "innmelding_utkast_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "innmelding_utkast_prospekt_id_fkey"
            columns: ["prospekt_id"]
            isOneToOne: false
            referencedRelation: "prospekter"
            referencedColumns: ["id"]
          },
        ]
      }
      insurance_coverage_details: {
        Row: {
          coverage_type: string
          coverage_value: string
          created_at: string | null
          id: string
          sort_order: number | null
          tier_id: string
        }
        Insert: {
          coverage_type: string
          coverage_value: string
          created_at?: string | null
          id?: string
          sort_order?: number | null
          tier_id: string
        }
        Update: {
          coverage_type?: string
          coverage_value?: string
          created_at?: string | null
          id?: string
          sort_order?: number | null
          tier_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "insurance_coverage_details_tier_id_fkey"
            columns: ["tier_id"]
            isOneToOne: false
            referencedRelation: "insurance_product_tiers"
            referencedColumns: ["id"]
          },
        ]
      }
      insurance_order_employees: {
        Row: {
          created_at: string | null
          id: string
          order_item_id: string
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          order_item_id: string
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          order_item_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "insurance_order_employees_order_item_id_fkey"
            columns: ["order_item_id"]
            isOneToOne: false
            referencedRelation: "insurance_order_items"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "insurance_order_employees_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "insurance_order_employees_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "insurance_order_employees_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      insurance_order_items: {
        Row: {
          created_at: string | null
          id: string
          order_id: string
          product_id: string
          quantity: number | null
          tier_id: string | null
          total_price: number
          unit_price: number
        }
        Insert: {
          created_at?: string | null
          id?: string
          order_id: string
          product_id: string
          quantity?: number | null
          tier_id?: string | null
          total_price: number
          unit_price: number
        }
        Update: {
          created_at?: string | null
          id?: string
          order_id?: string
          product_id?: string
          quantity?: number | null
          tier_id?: string | null
          total_price?: number
          unit_price?: number
        }
        Relationships: [
          {
            foreignKeyName: "insurance_order_items_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "insurance_orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "insurance_order_items_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "insurance_products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "insurance_order_items_tier_id_fkey"
            columns: ["tier_id"]
            isOneToOne: false
            referencedRelation: "insurance_product_tiers"
            referencedColumns: ["id"]
          },
        ]
      }
      insurance_orders: {
        Row: {
          aarlig_omsetning: number | null
          admin_notes: string | null
          antall_ansatte: number | null
          antall_arsverk: number | null
          approved_at: string | null
          approved_by_user_id: string | null
          change_details: Json | null
          completed_at: string | null
          contact_email: string | null
          contact_name: string | null
          contact_phone: string | null
          created_at: string | null
          desired_start_date: string | null
          frende_reference: string | null
          frende_transfer_date: string | null
          id: string
          invoiced_at: string | null
          order_category: string | null
          order_type: Database["public"]["Enums"]["insurance_order_type"]
          ordered_by_user_id: string
          original_values: Json | null
          poa_signature_at: string | null
          poa_signature_name: string | null
          previous_insurances: Json | null
          rejection_reason: string | null
          salon_address: string | null
          salon_city: string | null
          salon_id: string
          salon_postal_code: string | null
          sent_to_frende_at: string | null
          source_quote_id: string | null
          status: Database["public"]["Enums"]["insurance_order_status"]
          switching_provider: boolean | null
          total_price: number | null
          updated_at: string | null
        }
        Insert: {
          aarlig_omsetning?: number | null
          admin_notes?: string | null
          antall_ansatte?: number | null
          antall_arsverk?: number | null
          approved_at?: string | null
          approved_by_user_id?: string | null
          change_details?: Json | null
          completed_at?: string | null
          contact_email?: string | null
          contact_name?: string | null
          contact_phone?: string | null
          created_at?: string | null
          desired_start_date?: string | null
          frende_reference?: string | null
          frende_transfer_date?: string | null
          id?: string
          invoiced_at?: string | null
          order_category?: string | null
          order_type?: Database["public"]["Enums"]["insurance_order_type"]
          ordered_by_user_id: string
          original_values?: Json | null
          poa_signature_at?: string | null
          poa_signature_name?: string | null
          previous_insurances?: Json | null
          rejection_reason?: string | null
          salon_address?: string | null
          salon_city?: string | null
          salon_id: string
          salon_postal_code?: string | null
          sent_to_frende_at?: string | null
          source_quote_id?: string | null
          status?: Database["public"]["Enums"]["insurance_order_status"]
          switching_provider?: boolean | null
          total_price?: number | null
          updated_at?: string | null
        }
        Update: {
          aarlig_omsetning?: number | null
          admin_notes?: string | null
          antall_ansatte?: number | null
          antall_arsverk?: number | null
          approved_at?: string | null
          approved_by_user_id?: string | null
          change_details?: Json | null
          completed_at?: string | null
          contact_email?: string | null
          contact_name?: string | null
          contact_phone?: string | null
          created_at?: string | null
          desired_start_date?: string | null
          frende_reference?: string | null
          frende_transfer_date?: string | null
          id?: string
          invoiced_at?: string | null
          order_category?: string | null
          order_type?: Database["public"]["Enums"]["insurance_order_type"]
          ordered_by_user_id?: string
          original_values?: Json | null
          poa_signature_at?: string | null
          poa_signature_name?: string | null
          previous_insurances?: Json | null
          rejection_reason?: string | null
          salon_address?: string | null
          salon_city?: string | null
          salon_id?: string
          salon_postal_code?: string | null
          sent_to_frende_at?: string | null
          source_quote_id?: string | null
          status?: Database["public"]["Enums"]["insurance_order_status"]
          switching_provider?: boolean | null
          total_price?: number | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "insurance_orders_approved_by_user_id_fkey"
            columns: ["approved_by_user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "insurance_orders_approved_by_user_id_fkey"
            columns: ["approved_by_user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "insurance_orders_approved_by_user_id_fkey"
            columns: ["approved_by_user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "insurance_orders_ordered_by_user_id_fkey"
            columns: ["ordered_by_user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "insurance_orders_ordered_by_user_id_fkey"
            columns: ["ordered_by_user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "insurance_orders_ordered_by_user_id_fkey"
            columns: ["ordered_by_user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "insurance_orders_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "insurance_orders_source_quote_id_fkey"
            columns: ["source_quote_id"]
            isOneToOne: false
            referencedRelation: "insurance_quotes"
            referencedColumns: ["id"]
          },
        ]
      }
      insurance_power_of_attorney: {
        Row: {
          admin_notified_at: string | null
          consent_privacy: boolean | null
          consent_transfer: boolean | null
          contact_name: string
          created_at: string | null
          email: string
          has_existing_insurance: boolean | null
          id: string
          ip_address: string | null
          org_number: string
          otp_attempts: number | null
          otp_code_hash: string
          otp_expires_at: string
          pdf_url: string | null
          phone: string | null
          previous_insurers: Json | null
          quote_id: string | null
          salon_id: string | null
          salon_name: string
          signed: boolean | null
          signed_at: string | null
          updated_at: string | null
          user_agent: string | null
        }
        Insert: {
          admin_notified_at?: string | null
          consent_privacy?: boolean | null
          consent_transfer?: boolean | null
          contact_name: string
          created_at?: string | null
          email: string
          has_existing_insurance?: boolean | null
          id?: string
          ip_address?: string | null
          org_number: string
          otp_attempts?: number | null
          otp_code_hash: string
          otp_expires_at: string
          pdf_url?: string | null
          phone?: string | null
          previous_insurers?: Json | null
          quote_id?: string | null
          salon_id?: string | null
          salon_name: string
          signed?: boolean | null
          signed_at?: string | null
          updated_at?: string | null
          user_agent?: string | null
        }
        Update: {
          admin_notified_at?: string | null
          consent_privacy?: boolean | null
          consent_transfer?: boolean | null
          contact_name?: string
          created_at?: string | null
          email?: string
          has_existing_insurance?: boolean | null
          id?: string
          ip_address?: string | null
          org_number?: string
          otp_attempts?: number | null
          otp_code_hash?: string
          otp_expires_at?: string
          pdf_url?: string | null
          phone?: string | null
          previous_insurers?: Json | null
          quote_id?: string | null
          salon_id?: string | null
          salon_name?: string
          signed?: boolean | null
          signed_at?: string | null
          updated_at?: string | null
          user_agent?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "insurance_power_of_attorney_quote_id_fkey"
            columns: ["quote_id"]
            isOneToOne: false
            referencedRelation: "insurance_quotes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "insurance_power_of_attorney_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
        ]
      }
      insurance_product_documents: {
        Row: {
          created_at: string | null
          document_type: string
          file_url: string
          id: string
          product_id: string
          tier_id: string | null
          title: string
          uploaded_by: string | null
          version: string | null
        }
        Insert: {
          created_at?: string | null
          document_type?: string
          file_url: string
          id?: string
          product_id: string
          tier_id?: string | null
          title: string
          uploaded_by?: string | null
          version?: string | null
        }
        Update: {
          created_at?: string | null
          document_type?: string
          file_url?: string
          id?: string
          product_id?: string
          tier_id?: string | null
          title?: string
          uploaded_by?: string | null
          version?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "insurance_product_documents_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "insurance_products"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "insurance_product_documents_tier_id_fkey"
            columns: ["tier_id"]
            isOneToOne: false
            referencedRelation: "insurance_product_tiers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "insurance_product_documents_uploaded_by_fkey"
            columns: ["uploaded_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "insurance_product_documents_uploaded_by_fkey"
            columns: ["uploaded_by"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "insurance_product_documents_uploaded_by_fkey"
            columns: ["uploaded_by"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      insurance_product_tiers: {
        Row: {
          created_at: string | null
          id: string
          price: number
          product_id: string
          sort_order: number | null
          tier_description: string | null
          tier_name: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          price: number
          product_id: string
          sort_order?: number | null
          tier_description?: string | null
          tier_name: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          price?: number
          product_id?: string
          sort_order?: number | null
          tier_description?: string | null
          tier_name?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "insurance_product_tiers_product_id_fkey"
            columns: ["product_id"]
            isOneToOne: false
            referencedRelation: "insurance_products"
            referencedColumns: ["id"]
          },
        ]
      }
      insurance_products: {
        Row: {
          active: boolean | null
          base_price: number
          created_at: string | null
          description: string | null
          icon_name: string | null
          id: string
          name: string
          price_model: Database["public"]["Enums"]["insurance_price_model"]
          product_type: Database["public"]["Enums"]["insurance_product_type"]
          requires_employee_selection: boolean | null
          sort_order: number | null
          updated_at: string | null
        }
        Insert: {
          active?: boolean | null
          base_price: number
          created_at?: string | null
          description?: string | null
          icon_name?: string | null
          id?: string
          name: string
          price_model: Database["public"]["Enums"]["insurance_price_model"]
          product_type: Database["public"]["Enums"]["insurance_product_type"]
          requires_employee_selection?: boolean | null
          sort_order?: number | null
          updated_at?: string | null
        }
        Update: {
          active?: boolean | null
          base_price?: number
          created_at?: string | null
          description?: string | null
          icon_name?: string | null
          id?: string
          name?: string
          price_model?: Database["public"]["Enums"]["insurance_price_model"]
          product_type?: Database["public"]["Enums"]["insurance_product_type"]
          requires_employee_selection?: boolean | null
          sort_order?: number | null
          updated_at?: string | null
        }
        Relationships: []
      }
      insurance_quotes: {
        Row: {
          aarlig_omsetning: number | null
          acceptance_ip: string | null
          acceptance_token: string | null
          acceptance_user_agent: string | null
          accepted_at: string | null
          antall_ansatte: number | null
          antall_arsverk: number | null
          completed_at: string | null
          contact_name: string
          created_at: string
          district_manager_id: string
          email: string
          expires_at: string | null
          id: string
          link_to_fullmakt: string | null
          member_salon_id: string | null
          notes: string | null
          org_number: string
          phone: string | null
          products: Json
          salon_address: string | null
          salon_city: string | null
          salon_name: string
          salon_postal_code: string | null
          sent_at: string | null
          status: Database["public"]["Enums"]["insurance_quote_status"]
          total_price: number
          updated_at: string
          withdrawn_at: string | null
        }
        Insert: {
          aarlig_omsetning?: number | null
          acceptance_ip?: string | null
          acceptance_token?: string | null
          acceptance_user_agent?: string | null
          accepted_at?: string | null
          antall_ansatte?: number | null
          antall_arsverk?: number | null
          completed_at?: string | null
          contact_name: string
          created_at?: string
          district_manager_id: string
          email: string
          expires_at?: string | null
          id?: string
          link_to_fullmakt?: string | null
          member_salon_id?: string | null
          notes?: string | null
          org_number: string
          phone?: string | null
          products?: Json
          salon_address?: string | null
          salon_city?: string | null
          salon_name: string
          salon_postal_code?: string | null
          sent_at?: string | null
          status?: Database["public"]["Enums"]["insurance_quote_status"]
          total_price?: number
          updated_at?: string
          withdrawn_at?: string | null
        }
        Update: {
          aarlig_omsetning?: number | null
          acceptance_ip?: string | null
          acceptance_token?: string | null
          acceptance_user_agent?: string | null
          accepted_at?: string | null
          antall_ansatte?: number | null
          antall_arsverk?: number | null
          completed_at?: string | null
          contact_name?: string
          created_at?: string
          district_manager_id?: string
          email?: string
          expires_at?: string | null
          id?: string
          link_to_fullmakt?: string | null
          member_salon_id?: string | null
          notes?: string | null
          org_number?: string
          phone?: string | null
          products?: Json
          salon_address?: string | null
          salon_city?: string | null
          salon_name?: string
          salon_postal_code?: string | null
          sent_at?: string | null
          status?: Database["public"]["Enums"]["insurance_quote_status"]
          total_price?: number
          updated_at?: string
          withdrawn_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "insurance_quotes_district_manager_id_fkey"
            columns: ["district_manager_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "insurance_quotes_district_manager_id_fkey"
            columns: ["district_manager_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "insurance_quotes_district_manager_id_fkey"
            columns: ["district_manager_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "insurance_quotes_link_to_fullmakt_fkey"
            columns: ["link_to_fullmakt"]
            isOneToOne: false
            referencedRelation: "insurance_power_of_attorney"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "insurance_quotes_member_salon_id_fkey"
            columns: ["member_salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
        ]
      }
      insurance_scheduled_cancellations: {
        Row: {
          cancellation_date: string
          created_at: string | null
          frende_notified: boolean | null
          frende_notified_at: string | null
          hubspot_synced: boolean | null
          hubspot_synced_at: string | null
          id: string
          insurance_type: string
          processed: boolean | null
          processed_at: string | null
          reason: string | null
          salon_id: string
          salon_notified: boolean | null
          salon_notified_at: string | null
          scheduled_at: string | null
          scheduled_by: string | null
          updated_at: string | null
          winback_contacted: boolean | null
          winback_contacted_at: string | null
          winback_contacted_by: string | null
          winback_outcome: string | null
        }
        Insert: {
          cancellation_date: string
          created_at?: string | null
          frende_notified?: boolean | null
          frende_notified_at?: string | null
          hubspot_synced?: boolean | null
          hubspot_synced_at?: string | null
          id?: string
          insurance_type: string
          processed?: boolean | null
          processed_at?: string | null
          reason?: string | null
          salon_id: string
          salon_notified?: boolean | null
          salon_notified_at?: string | null
          scheduled_at?: string | null
          scheduled_by?: string | null
          updated_at?: string | null
          winback_contacted?: boolean | null
          winback_contacted_at?: string | null
          winback_contacted_by?: string | null
          winback_outcome?: string | null
        }
        Update: {
          cancellation_date?: string
          created_at?: string | null
          frende_notified?: boolean | null
          frende_notified_at?: string | null
          hubspot_synced?: boolean | null
          hubspot_synced_at?: string | null
          id?: string
          insurance_type?: string
          processed?: boolean | null
          processed_at?: string | null
          reason?: string | null
          salon_id?: string
          salon_notified?: boolean | null
          salon_notified_at?: string | null
          scheduled_at?: string | null
          scheduled_by?: string | null
          updated_at?: string | null
          winback_contacted?: boolean | null
          winback_contacted_at?: string | null
          winback_contacted_by?: string | null
          winback_outcome?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "insurance_scheduled_cancellations_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "insurance_scheduled_cancellations_scheduled_by_fkey"
            columns: ["scheduled_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "insurance_scheduled_cancellations_scheduled_by_fkey"
            columns: ["scheduled_by"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "insurance_scheduled_cancellations_scheduled_by_fkey"
            columns: ["scheduled_by"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      invitations: {
        Row: {
          accepted: boolean | null
          accepted_at: string | null
          created_at: string | null
          created_by_user_id: string | null
          district_id: string | null
          email: string
          expires_at: string | null
          hubspot_contact_id: string | null
          id: string
          role: Database["public"]["Enums"]["app_role"]
          salon_id: string | null
          supplier_id: string | null
          token: string
        }
        Insert: {
          accepted?: boolean | null
          accepted_at?: string | null
          created_at?: string | null
          created_by_user_id?: string | null
          district_id?: string | null
          email: string
          expires_at?: string | null
          hubspot_contact_id?: string | null
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          salon_id?: string | null
          supplier_id?: string | null
          token: string
        }
        Update: {
          accepted?: boolean | null
          accepted_at?: string | null
          created_at?: string | null
          created_by_user_id?: string | null
          district_id?: string | null
          email?: string
          expires_at?: string | null
          hubspot_contact_id?: string | null
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          salon_id?: string | null
          supplier_id?: string | null
          token?: string
        }
        Relationships: [
          {
            foreignKeyName: "invitations_created_by_user_id_fkey"
            columns: ["created_by_user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invitations_created_by_user_id_fkey"
            columns: ["created_by_user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invitations_created_by_user_id_fkey"
            columns: ["created_by_user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invitations_district_id_fkey"
            columns: ["district_id"]
            isOneToOne: false
            referencedRelation: "districts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invitations_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invitations_supplier_id_fkey"
            columns: ["supplier_id"]
            isOneToOne: false
            referencedRelation: "suppliers"
            referencedColumns: ["id"]
          },
        ]
      }
      kalender: {
        Row: {
          aar: number
          created_at: string | null
          dato: string
          er_arbeidsdag: boolean | null
          er_helligdag: boolean | null
          er_juleferie: boolean | null
          er_sommerferie: boolean | null
          helligdag_navn: string | null
          id: string
          maned: number
          uke: number
          ukedag: number
        }
        Insert: {
          aar: number
          created_at?: string | null
          dato: string
          er_arbeidsdag?: boolean | null
          er_helligdag?: boolean | null
          er_juleferie?: boolean | null
          er_sommerferie?: boolean | null
          helligdag_navn?: string | null
          id?: string
          maned: number
          uke: number
          ukedag: number
        }
        Update: {
          aar?: number
          created_at?: string | null
          dato?: string
          er_arbeidsdag?: boolean | null
          er_helligdag?: boolean | null
          er_juleferie?: boolean | null
          er_sommerferie?: boolean | null
          helligdag_navn?: string | null
          id?: string
          maned?: number
          uke?: number
          ukedag?: number
        }
        Relationships: []
      }
      kompetanse_definisjoner: {
        Row: {
          aktiv: boolean | null
          beskrivelse: string | null
          created_at: string | null
          id: string
          kategori: string | null
          navn: string
          rekkefølge: number | null
          rubrikk: Json
          updated_at: string | null
        }
        Insert: {
          aktiv?: boolean | null
          beskrivelse?: string | null
          created_at?: string | null
          id?: string
          kategori?: string | null
          navn: string
          rekkefølge?: number | null
          rubrikk?: Json
          updated_at?: string | null
        }
        Update: {
          aktiv?: boolean | null
          beskrivelse?: string | null
          created_at?: string | null
          id?: string
          kategori?: string | null
          navn?: string
          rekkefølge?: number | null
          rubrikk?: Json
          updated_at?: string | null
        }
        Relationships: []
      }
      leverandor_merker: {
        Row: {
          aktiv: boolean | null
          created_at: string | null
          har_kjemi: boolean | null
          har_produkter: boolean | null
          id: string
          kategori: Database["public"]["Enums"]["merke_kategori"] | null
          leverandor_id: string
          navn: string
        }
        Insert: {
          aktiv?: boolean | null
          created_at?: string | null
          har_kjemi?: boolean | null
          har_produkter?: boolean | null
          id?: string
          kategori?: Database["public"]["Enums"]["merke_kategori"] | null
          leverandor_id: string
          navn: string
        }
        Update: {
          aktiv?: boolean | null
          created_at?: string | null
          har_kjemi?: boolean | null
          har_produkter?: boolean | null
          id?: string
          kategori?: Database["public"]["Enums"]["merke_kategori"] | null
          leverandor_id?: string
          navn?: string
        }
        Relationships: [
          {
            foreignKeyName: "leverandor_merker_leverandor_id_fkey"
            columns: ["leverandor_id"]
            isOneToOne: false
            referencedRelation: "leverandorer"
            referencedColumns: ["id"]
          },
        ]
      }
      leverandorer: {
        Row: {
          aktiv: boolean | null
          created_at: string | null
          cumulative_reporting: boolean | null
          hubspot_company_id: string | null
          id: string
          navn: string
          updated_at: string | null
        }
        Insert: {
          aktiv?: boolean | null
          created_at?: string | null
          cumulative_reporting?: boolean | null
          hubspot_company_id?: string | null
          id?: string
          navn: string
          updated_at?: string | null
        }
        Update: {
          aktiv?: boolean | null
          created_at?: string | null
          cumulative_reporting?: boolean | null
          hubspot_company_id?: string | null
          id?: string
          navn?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      lonn_historikk: {
        Row: {
          arsak: string | null
          created_at: string | null
          endret_av: string | null
          fastlonn: number | null
          gyldig_fra: string
          gyldig_til: string | null
          id: string
          timesats: number | null
          user_id: string
        }
        Insert: {
          arsak?: string | null
          created_at?: string | null
          endret_av?: string | null
          fastlonn?: number | null
          gyldig_fra: string
          gyldig_til?: string | null
          id?: string
          timesats?: number | null
          user_id: string
        }
        Update: {
          arsak?: string | null
          created_at?: string | null
          endret_av?: string | null
          fastlonn?: number | null
          gyldig_fra?: string
          gyldig_til?: string | null
          id?: string
          timesats?: number | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "lonn_historikk_endret_av_fkey"
            columns: ["endret_av"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lonn_historikk_endret_av_fkey"
            columns: ["endret_av"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lonn_historikk_endret_av_fkey"
            columns: ["endret_av"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lonn_historikk_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lonn_historikk_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lonn_historikk_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      medarbeidersamtale_forberedelse: {
        Row: {
          andre_tema: string | null
          andre_tema_leder: string | null
          arbeid_salong_kommentar: string | null
          arbeid_salong_score: number | null
          created_at: string | null
          egen_innsats_kommentar: string | null
          egen_innsats_score: number | null
          ferdig_utfylt: boolean | null
          ferdigheter_utvikle: string | null
          forbedringsomrader: string | null
          framtidige_mal: string | null
          hjelp_leder_kommentar: string | null
          hjelp_leder_score: number | null
          id: string
          kompetanse_kommentar: string | null
          kompetanse_score: number | null
          leder_hjelp_mal: string | null
          prestasjoner_kommentar: string | null
          prestasjoner_score: number | null
          samtale_id: string
          stotte_leder_kommentar: string | null
          stotte_leder_score: number | null
          styrker: string | null
          updated_at: string | null
          utfylt_av_type: string
        }
        Insert: {
          andre_tema?: string | null
          andre_tema_leder?: string | null
          arbeid_salong_kommentar?: string | null
          arbeid_salong_score?: number | null
          created_at?: string | null
          egen_innsats_kommentar?: string | null
          egen_innsats_score?: number | null
          ferdig_utfylt?: boolean | null
          ferdigheter_utvikle?: string | null
          forbedringsomrader?: string | null
          framtidige_mal?: string | null
          hjelp_leder_kommentar?: string | null
          hjelp_leder_score?: number | null
          id?: string
          kompetanse_kommentar?: string | null
          kompetanse_score?: number | null
          leder_hjelp_mal?: string | null
          prestasjoner_kommentar?: string | null
          prestasjoner_score?: number | null
          samtale_id: string
          stotte_leder_kommentar?: string | null
          stotte_leder_score?: number | null
          styrker?: string | null
          updated_at?: string | null
          utfylt_av_type: string
        }
        Update: {
          andre_tema?: string | null
          andre_tema_leder?: string | null
          arbeid_salong_kommentar?: string | null
          arbeid_salong_score?: number | null
          created_at?: string | null
          egen_innsats_kommentar?: string | null
          egen_innsats_score?: number | null
          ferdig_utfylt?: boolean | null
          ferdigheter_utvikle?: string | null
          forbedringsomrader?: string | null
          framtidige_mal?: string | null
          hjelp_leder_kommentar?: string | null
          hjelp_leder_score?: number | null
          id?: string
          kompetanse_kommentar?: string | null
          kompetanse_score?: number | null
          leder_hjelp_mal?: string | null
          prestasjoner_kommentar?: string | null
          prestasjoner_score?: number | null
          samtale_id?: string
          stotte_leder_kommentar?: string | null
          stotte_leder_score?: number | null
          styrker?: string | null
          updated_at?: string | null
          utfylt_av_type?: string
        }
        Relationships: [
          {
            foreignKeyName: "medarbeidersamtale_forberedelse_samtale_id_fkey"
            columns: ["samtale_id"]
            isOneToOne: false
            referencedRelation: "ansatt_samtaler"
            referencedColumns: ["id"]
          },
        ]
      }
      medarbeidersamtale_paminnelser: {
        Row: {
          ansatt_id: string
          created_at: string | null
          id: string
          leder_id: string
          lest: boolean | null
          lest_dato: string | null
          melding: string
          salon_id: string
          samtale_id: string | null
          type: string
        }
        Insert: {
          ansatt_id: string
          created_at?: string | null
          id?: string
          leder_id: string
          lest?: boolean | null
          lest_dato?: string | null
          melding: string
          salon_id: string
          samtale_id?: string | null
          type: string
        }
        Update: {
          ansatt_id?: string
          created_at?: string | null
          id?: string
          leder_id?: string
          lest?: boolean | null
          lest_dato?: string | null
          melding?: string
          salon_id?: string
          samtale_id?: string | null
          type?: string
        }
        Relationships: [
          {
            foreignKeyName: "medarbeidersamtale_paminnelser_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "medarbeidersamtale_paminnelser_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "medarbeidersamtale_paminnelser_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "medarbeidersamtale_paminnelser_leder_id_fkey"
            columns: ["leder_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "medarbeidersamtale_paminnelser_leder_id_fkey"
            columns: ["leder_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "medarbeidersamtale_paminnelser_leder_id_fkey"
            columns: ["leder_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "medarbeidersamtale_paminnelser_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "medarbeidersamtale_paminnelser_samtale_id_fkey"
            columns: ["samtale_id"]
            isOneToOne: false
            referencedRelation: "ansatt_samtaler"
            referencedColumns: ["id"]
          },
        ]
      }
      medlem_kontaktpersoner: {
        Row: {
          created_at: string
          epost: string | null
          er_primaer_kontakt: boolean | null
          hubspot_contact_id: string | null
          id: string
          navn: string
          rolle: string | null
          salon_id: string
          telefon: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          epost?: string | null
          er_primaer_kontakt?: boolean | null
          hubspot_contact_id?: string | null
          id?: string
          navn: string
          rolle?: string | null
          salon_id: string
          telefon?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          epost?: string | null
          er_primaer_kontakt?: boolean | null
          hubspot_contact_id?: string | null
          id?: string
          navn?: string
          rolle?: string | null
          salon_id?: string
          telefon?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "medlem_kontaktpersoner_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
        ]
      }
      medlem_oppfolginger: {
        Row: {
          beskrivelse: string
          created_at: string
          forfallsdato: string | null
          fullfort_at: string | null
          id: string
          salon_id: string
          tilordnet_til: string | null
          type: Database["public"]["Enums"]["crm_aktivitet_type"]
          utfort_av: string | null
        }
        Insert: {
          beskrivelse: string
          created_at?: string
          forfallsdato?: string | null
          fullfort_at?: string | null
          id?: string
          salon_id: string
          tilordnet_til?: string | null
          type: Database["public"]["Enums"]["crm_aktivitet_type"]
          utfort_av?: string | null
        }
        Update: {
          beskrivelse?: string
          created_at?: string
          forfallsdato?: string | null
          fullfort_at?: string | null
          id?: string
          salon_id?: string
          tilordnet_til?: string | null
          type?: Database["public"]["Enums"]["crm_aktivitet_type"]
          utfort_av?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "medlem_oppfolginger_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "medlem_oppfolginger_tilordnet_til_fkey"
            columns: ["tilordnet_til"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "medlem_oppfolginger_tilordnet_til_fkey"
            columns: ["tilordnet_til"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "medlem_oppfolginger_tilordnet_til_fkey"
            columns: ["tilordnet_til"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "medlem_oppfolginger_utfort_av_fkey"
            columns: ["utfort_av"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "medlem_oppfolginger_utfort_av_fkey"
            columns: ["utfort_av"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "medlem_oppfolginger_utfort_av_fkey"
            columns: ["utfort_av"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      medlemsavtaler: {
        Row: {
          apnet_at: string | null
          avtale_pdf_url: string | null
          avtale_type: string
          created_at: string
          docsign_dokument_id: string | null
          docsign_signerings_url: string | null
          generert_fra_wizard_data: Json | null
          id: string
          opprettet_av: string | null
          paaminnelse_sendt_at: string | null
          salon_id: string
          sendt_til_signering_at: string | null
          signerings_metode: string | null
          signerings_status: Database["public"]["Enums"]["avtale_signerings_status"]
          signert_at: string | null
          signert_av_navn: string | null
          signert_av_personnummer: string | null
          signert_pdf_url: string | null
          updated_at: string
          utloper_at: string | null
        }
        Insert: {
          apnet_at?: string | null
          avtale_pdf_url?: string | null
          avtale_type?: string
          created_at?: string
          docsign_dokument_id?: string | null
          docsign_signerings_url?: string | null
          generert_fra_wizard_data?: Json | null
          id?: string
          opprettet_av?: string | null
          paaminnelse_sendt_at?: string | null
          salon_id: string
          sendt_til_signering_at?: string | null
          signerings_metode?: string | null
          signerings_status?: Database["public"]["Enums"]["avtale_signerings_status"]
          signert_at?: string | null
          signert_av_navn?: string | null
          signert_av_personnummer?: string | null
          signert_pdf_url?: string | null
          updated_at?: string
          utloper_at?: string | null
        }
        Update: {
          apnet_at?: string | null
          avtale_pdf_url?: string | null
          avtale_type?: string
          created_at?: string
          docsign_dokument_id?: string | null
          docsign_signerings_url?: string | null
          generert_fra_wizard_data?: Json | null
          id?: string
          opprettet_av?: string | null
          paaminnelse_sendt_at?: string | null
          salon_id?: string
          sendt_til_signering_at?: string | null
          signerings_metode?: string | null
          signerings_status?: Database["public"]["Enums"]["avtale_signerings_status"]
          signert_at?: string | null
          signert_av_navn?: string | null
          signert_av_personnummer?: string | null
          signert_pdf_url?: string | null
          updated_at?: string
          utloper_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "medlemsavtaler_opprettet_av_fkey"
            columns: ["opprettet_av"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "medlemsavtaler_opprettet_av_fkey"
            columns: ["opprettet_av"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "medlemsavtaler_opprettet_av_fkey"
            columns: ["opprettet_av"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "medlemsavtaler_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
        ]
      }
      message_read_states: {
        Row: {
          message_id: string
          read_at: string | null
          user_id: string
        }
        Insert: {
          message_id: string
          read_at?: string | null
          user_id: string
        }
        Update: {
          message_id?: string
          read_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "message_read_states_message_id_fkey"
            columns: ["message_id"]
            isOneToOne: false
            referencedRelation: "messages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "message_read_states_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "message_read_states_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "message_read_states_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      message_threads: {
        Row: {
          created_at: string | null
          created_by_user_id: string | null
          district_id: string | null
          id: string
          salon_id: string | null
          subject: string
          supplier_id: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          created_by_user_id?: string | null
          district_id?: string | null
          id?: string
          salon_id?: string | null
          subject: string
          supplier_id?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          created_by_user_id?: string | null
          district_id?: string | null
          id?: string
          salon_id?: string | null
          subject?: string
          supplier_id?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "message_threads_created_by_user_id_fkey"
            columns: ["created_by_user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "message_threads_created_by_user_id_fkey"
            columns: ["created_by_user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "message_threads_created_by_user_id_fkey"
            columns: ["created_by_user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "message_threads_district_id_fkey"
            columns: ["district_id"]
            isOneToOne: false
            referencedRelation: "districts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "message_threads_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "message_threads_supplier_id_fkey"
            columns: ["supplier_id"]
            isOneToOne: false
            referencedRelation: "suppliers"
            referencedColumns: ["id"]
          },
        ]
      }
      messages: {
        Row: {
          attachment_name: string | null
          attachment_url: string | null
          created_at: string | null
          id: string
          message_text: string
          sender_user_id: string | null
          thread_id: string | null
        }
        Insert: {
          attachment_name?: string | null
          attachment_url?: string | null
          created_at?: string | null
          id?: string
          message_text: string
          sender_user_id?: string | null
          thread_id?: string | null
        }
        Update: {
          attachment_name?: string | null
          attachment_url?: string | null
          created_at?: string | null
          id?: string
          message_text?: string
          sender_user_id?: string | null
          thread_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "messages_sender_user_id_fkey"
            columns: ["sender_user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "messages_sender_user_id_fkey"
            columns: ["sender_user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "messages_sender_user_id_fkey"
            columns: ["sender_user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "messages_thread_id_fkey"
            columns: ["thread_id"]
            isOneToOne: false
            referencedRelation: "message_threads"
            referencedColumns: ["id"]
          },
        ]
      }
      monthly_challenges: {
        Row: {
          created_at: string | null
          description: string | null
          goal_description: string | null
          id: string
          kpi_focus: string
          month: number
          period_type: string
          target_value: number | null
          title: string
          updated_at: string | null
          year: number
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          goal_description?: string | null
          id?: string
          kpi_focus: string
          month: number
          period_type?: string
          target_value?: number | null
          title: string
          updated_at?: string | null
          year: number
        }
        Update: {
          created_at?: string | null
          description?: string | null
          goal_description?: string | null
          id?: string
          kpi_focus?: string
          month?: number
          period_type?: string
          target_value?: number | null
          title?: string
          updated_at?: string | null
          year?: number
        }
        Relationships: []
      }
      mote_oppgaver: {
        Row: {
          ansvarlig_id: string
          ansvarlig_type: string
          beskrivelse: string | null
          created_at: string | null
          frist: string | null
          id: string
          prioritet: string | null
          samtale_id: string
          status: string | null
          tittel: string
          updated_at: string | null
        }
        Insert: {
          ansvarlig_id: string
          ansvarlig_type: string
          beskrivelse?: string | null
          created_at?: string | null
          frist?: string | null
          id?: string
          prioritet?: string | null
          samtale_id: string
          status?: string | null
          tittel: string
          updated_at?: string | null
        }
        Update: {
          ansvarlig_id?: string
          ansvarlig_type?: string
          beskrivelse?: string | null
          created_at?: string | null
          frist?: string | null
          id?: string
          prioritet?: string | null
          samtale_id?: string
          status?: string | null
          tittel?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "mote_oppgaver_ansvarlig_id_fkey"
            columns: ["ansvarlig_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "mote_oppgaver_ansvarlig_id_fkey"
            columns: ["ansvarlig_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "mote_oppgaver_ansvarlig_id_fkey"
            columns: ["ansvarlig_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "mote_oppgaver_samtale_id_fkey"
            columns: ["samtale_id"]
            isOneToOne: false
            referencedRelation: "ansatt_samtaler"
            referencedColumns: ["id"]
          },
        ]
      }
      notification_preferences: {
        Row: {
          channel: string
          created_at: string | null
          id: string
          notification_type: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          channel?: string
          created_at?: string | null
          id?: string
          notification_type: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          channel?: string
          created_at?: string | null
          id?: string
          notification_type?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "notification_preferences_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "notification_preferences_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "notification_preferences_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      portal_moduler: {
        Row: {
          beskrivelse: string | null
          created_at: string
          er_aktiv: boolean | null
          id: string
          ikon: string | null
          navn: string
          rekkefolge: number | null
          updated_at: string
        }
        Insert: {
          beskrivelse?: string | null
          created_at?: string
          er_aktiv?: boolean | null
          id?: string
          ikon?: string | null
          navn: string
          rekkefolge?: number | null
          updated_at?: string
        }
        Update: {
          beskrivelse?: string | null
          created_at?: string
          er_aktiv?: boolean | null
          id?: string
          ikon?: string | null
          navn?: string
          rekkefolge?: number | null
          updated_at?: string
        }
        Relationships: []
      }
      prosess_oppgaver: {
        Row: {
          ansvarlig_bruker_id: string | null
          ansvarlig_rolle: string | null
          beskrivelse: string | null
          created_at: string
          frist: string | null
          fullfort_av: string | null
          fullfort_dato: string | null
          id: string
          kategori: string | null
          kommentar: string | null
          mal_oppgave_id: string | null
          obligatorisk: boolean | null
          prioritet: number | null
          prosess_id: string
          status:
            | Database["public"]["Enums"]["sjekkliste_oppgave_status"]
            | null
          tittel: string
          updated_at: string
        }
        Insert: {
          ansvarlig_bruker_id?: string | null
          ansvarlig_rolle?: string | null
          beskrivelse?: string | null
          created_at?: string
          frist?: string | null
          fullfort_av?: string | null
          fullfort_dato?: string | null
          id?: string
          kategori?: string | null
          kommentar?: string | null
          mal_oppgave_id?: string | null
          obligatorisk?: boolean | null
          prioritet?: number | null
          prosess_id: string
          status?:
            | Database["public"]["Enums"]["sjekkliste_oppgave_status"]
            | null
          tittel: string
          updated_at?: string
        }
        Update: {
          ansvarlig_bruker_id?: string | null
          ansvarlig_rolle?: string | null
          beskrivelse?: string | null
          created_at?: string
          frist?: string | null
          fullfort_av?: string | null
          fullfort_dato?: string | null
          id?: string
          kategori?: string | null
          kommentar?: string | null
          mal_oppgave_id?: string | null
          obligatorisk?: boolean | null
          prioritet?: number | null
          prosess_id?: string
          status?:
            | Database["public"]["Enums"]["sjekkliste_oppgave_status"]
            | null
          tittel?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "prosess_oppgaver_mal_oppgave_id_fkey"
            columns: ["mal_oppgave_id"]
            isOneToOne: false
            referencedRelation: "sjekkliste_oppgave_maler"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "prosess_oppgaver_prosess_id_fkey"
            columns: ["prosess_id"]
            isOneToOne: false
            referencedRelation: "ansatt_prosesser"
            referencedColumns: ["id"]
          },
        ]
      }
      prospekt_aktiviteter: {
        Row: {
          beskrivelse: string
          created_at: string
          forfallsdato: string | null
          fullfort_at: string | null
          id: string
          prospekt_id: string
          type: Database["public"]["Enums"]["crm_aktivitet_type"]
          utfort_av: string | null
        }
        Insert: {
          beskrivelse: string
          created_at?: string
          forfallsdato?: string | null
          fullfort_at?: string | null
          id?: string
          prospekt_id: string
          type: Database["public"]["Enums"]["crm_aktivitet_type"]
          utfort_av?: string | null
        }
        Update: {
          beskrivelse?: string
          created_at?: string
          forfallsdato?: string | null
          fullfort_at?: string | null
          id?: string
          prospekt_id?: string
          type?: Database["public"]["Enums"]["crm_aktivitet_type"]
          utfort_av?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "prospekt_aktiviteter_prospekt_id_fkey"
            columns: ["prospekt_id"]
            isOneToOne: false
            referencedRelation: "prospekter"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "prospekt_aktiviteter_utfort_av_fkey"
            columns: ["utfort_av"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "prospekt_aktiviteter_utfort_av_fkey"
            columns: ["utfort_av"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "prospekt_aktiviteter_utfort_av_fkey"
            columns: ["utfort_av"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      prospekter: {
        Row: {
          adresse: string | null
          antall_ansatte: number | null
          archived_at: string | null
          created_at: string
          district_id: string | null
          distriktssjef_id: string | null
          driftsresultat: number | null
          eksisterende_tjenester: string | null
          estimert_medlemsavgift: number | null
          forventet_innmeldingsdato: string | null
          id: string
          kilde: string | null
          kontaktperson_epost: string | null
          kontaktperson_navn: string | null
          kontaktperson_telefon: string | null
          konvertert_til_salon_id: string | null
          loennskostnad: number | null
          notater: string | null
          org_nummer: string | null
          pipeline_status: Database["public"]["Enums"]["prospekt_pipeline_status"]
          postnummer: string | null
          regnskapsaar: number | null
          salgsinntekter: number | null
          salongnavn: string
          sannsynlighet:
            | Database["public"]["Enums"]["prospekt_sannsynlighet"]
            | null
          sted: string | null
          sum_driftsinntekter: number | null
          sum_driftskostnad: number | null
          tapt_arsak: string | null
          type_medlemskap: Database["public"]["Enums"]["type_medlemskap"] | null
          updated_at: string
        }
        Insert: {
          adresse?: string | null
          antall_ansatte?: number | null
          archived_at?: string | null
          created_at?: string
          district_id?: string | null
          distriktssjef_id?: string | null
          driftsresultat?: number | null
          eksisterende_tjenester?: string | null
          estimert_medlemsavgift?: number | null
          forventet_innmeldingsdato?: string | null
          id?: string
          kilde?: string | null
          kontaktperson_epost?: string | null
          kontaktperson_navn?: string | null
          kontaktperson_telefon?: string | null
          konvertert_til_salon_id?: string | null
          loennskostnad?: number | null
          notater?: string | null
          org_nummer?: string | null
          pipeline_status?: Database["public"]["Enums"]["prospekt_pipeline_status"]
          postnummer?: string | null
          regnskapsaar?: number | null
          salgsinntekter?: number | null
          salongnavn: string
          sannsynlighet?:
            | Database["public"]["Enums"]["prospekt_sannsynlighet"]
            | null
          sted?: string | null
          sum_driftsinntekter?: number | null
          sum_driftskostnad?: number | null
          tapt_arsak?: string | null
          type_medlemskap?:
            | Database["public"]["Enums"]["type_medlemskap"]
            | null
          updated_at?: string
        }
        Update: {
          adresse?: string | null
          antall_ansatte?: number | null
          archived_at?: string | null
          created_at?: string
          district_id?: string | null
          distriktssjef_id?: string | null
          driftsresultat?: number | null
          eksisterende_tjenester?: string | null
          estimert_medlemsavgift?: number | null
          forventet_innmeldingsdato?: string | null
          id?: string
          kilde?: string | null
          kontaktperson_epost?: string | null
          kontaktperson_navn?: string | null
          kontaktperson_telefon?: string | null
          konvertert_til_salon_id?: string | null
          loennskostnad?: number | null
          notater?: string | null
          org_nummer?: string | null
          pipeline_status?: Database["public"]["Enums"]["prospekt_pipeline_status"]
          postnummer?: string | null
          regnskapsaar?: number | null
          salgsinntekter?: number | null
          salongnavn?: string
          sannsynlighet?:
            | Database["public"]["Enums"]["prospekt_sannsynlighet"]
            | null
          sted?: string | null
          sum_driftsinntekter?: number | null
          sum_driftskostnad?: number | null
          tapt_arsak?: string | null
          type_medlemskap?:
            | Database["public"]["Enums"]["type_medlemskap"]
            | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "prospekter_district_id_fkey"
            columns: ["district_id"]
            isOneToOne: false
            referencedRelation: "districts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "prospekter_distriktssjef_id_fkey"
            columns: ["distriktssjef_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "prospekter_distriktssjef_id_fkey"
            columns: ["distriktssjef_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "prospekter_distriktssjef_id_fkey"
            columns: ["distriktssjef_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "prospekter_konvertert_til_salon_id_fkey"
            columns: ["konvertert_til_salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
        ]
      }
      puls_automatisk_plan: {
        Row: {
          aktiv: boolean | null
          created_at: string | null
          frekvens: string
          id: string
          neste_utsendelse: string
          puls_type: Database["public"]["Enums"]["puls_type"]
          salon_id: string
          siste_sporsmal_ids: string[] | null
          updated_at: string | null
        }
        Insert: {
          aktiv?: boolean | null
          created_at?: string | null
          frekvens: string
          id?: string
          neste_utsendelse: string
          puls_type: Database["public"]["Enums"]["puls_type"]
          salon_id: string
          siste_sporsmal_ids?: string[] | null
          updated_at?: string | null
        }
        Update: {
          aktiv?: boolean | null
          created_at?: string | null
          frekvens?: string
          id?: string
          neste_utsendelse?: string
          puls_type?: Database["public"]["Enums"]["puls_type"]
          salon_id?: string
          siste_sporsmal_ids?: string[] | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "puls_automatisk_plan_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
        ]
      }
      puls_risikologg: {
        Row: {
          behandlet_av: string | null
          behandlet_dato: string | null
          created_at: string | null
          foreslatte_tiltak: string[] | null
          id: string
          kommentar: string | null
          salon_id: string
          score: number
          sporsmal_id: string | null
          status: string | null
          svar_id: string | null
          tema: Database["public"]["Enums"]["puls_tema"]
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          behandlet_av?: string | null
          behandlet_dato?: string | null
          created_at?: string | null
          foreslatte_tiltak?: string[] | null
          id?: string
          kommentar?: string | null
          salon_id: string
          score: number
          sporsmal_id?: string | null
          status?: string | null
          svar_id?: string | null
          tema: Database["public"]["Enums"]["puls_tema"]
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          behandlet_av?: string | null
          behandlet_dato?: string | null
          created_at?: string | null
          foreslatte_tiltak?: string[] | null
          id?: string
          kommentar?: string | null
          salon_id?: string
          score?: number
          sporsmal_id?: string | null
          status?: string | null
          svar_id?: string | null
          tema?: Database["public"]["Enums"]["puls_tema"]
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "puls_risikologg_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "puls_risikologg_sporsmal_id_fkey"
            columns: ["sporsmal_id"]
            isOneToOne: false
            referencedRelation: "puls_sporsmal_bank"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "puls_risikologg_svar_id_fkey"
            columns: ["svar_id"]
            isOneToOne: false
            referencedRelation: "pulsundersokelse_svar"
            referencedColumns: ["id"]
          },
        ]
      }
      puls_sporsmal_bank: {
        Row: {
          aktiv: boolean | null
          created_at: string | null
          id: string
          moduler: Database["public"]["Enums"]["puls_type"][]
          sort_order: number | null
          sporsmal: string
          sporsmal_type: Database["public"]["Enums"]["puls_sporsmal_type"]
          tema: Database["public"]["Enums"]["puls_tema"]
          updated_at: string | null
        }
        Insert: {
          aktiv?: boolean | null
          created_at?: string | null
          id?: string
          moduler?: Database["public"]["Enums"]["puls_type"][]
          sort_order?: number | null
          sporsmal: string
          sporsmal_type?: Database["public"]["Enums"]["puls_sporsmal_type"]
          tema: Database["public"]["Enums"]["puls_tema"]
          updated_at?: string | null
        }
        Update: {
          aktiv?: boolean | null
          created_at?: string | null
          id?: string
          moduler?: Database["public"]["Enums"]["puls_type"][]
          sort_order?: number | null
          sporsmal?: string
          sporsmal_type?: Database["public"]["Enums"]["puls_sporsmal_type"]
          tema?: Database["public"]["Enums"]["puls_tema"]
          updated_at?: string | null
        }
        Relationships: []
      }
      puls_sporsmal_rotasjon: {
        Row: {
          created_at: string | null
          id: string
          periode_slutt: string | null
          periode_start: string
          sporsmal_id: string
          undersokelse_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          periode_slutt?: string | null
          periode_start: string
          sporsmal_id: string
          undersokelse_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          periode_slutt?: string | null
          periode_start?: string
          sporsmal_id?: string
          undersokelse_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "puls_sporsmal_rotasjon_sporsmal_id_fkey"
            columns: ["sporsmal_id"]
            isOneToOne: false
            referencedRelation: "puls_sporsmal_bank"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "puls_sporsmal_rotasjon_undersokelse_id_fkey"
            columns: ["undersokelse_id"]
            isOneToOne: false
            referencedRelation: "pulsundersokelser"
            referencedColumns: ["id"]
          },
        ]
      }
      pulsundersokelse_svar: {
        Row: {
          ansatt_id: string | null
          created_at: string | null
          dato: string
          energi: number
          id: string
          kommentar: string | null
          mestring: number
          puls_type: Database["public"]["Enums"]["puls_type"] | null
          risiko_flagg: boolean | null
          sporsmal_id: string | null
          stemning: number
          tema: Database["public"]["Enums"]["puls_tema"] | null
          undersokelse_id: string
          user_id: string | null
        }
        Insert: {
          ansatt_id?: string | null
          created_at?: string | null
          dato?: string
          energi: number
          id?: string
          kommentar?: string | null
          mestring: number
          puls_type?: Database["public"]["Enums"]["puls_type"] | null
          risiko_flagg?: boolean | null
          sporsmal_id?: string | null
          stemning: number
          tema?: Database["public"]["Enums"]["puls_tema"] | null
          undersokelse_id: string
          user_id?: string | null
        }
        Update: {
          ansatt_id?: string | null
          created_at?: string | null
          dato?: string
          energi?: number
          id?: string
          kommentar?: string | null
          mestring?: number
          puls_type?: Database["public"]["Enums"]["puls_type"] | null
          risiko_flagg?: boolean | null
          sporsmal_id?: string | null
          stemning?: number
          tema?: Database["public"]["Enums"]["puls_tema"] | null
          undersokelse_id?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "pulsundersokelse_svar_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "pulsundersokelse_svar_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "pulsundersokelse_svar_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_utvidet"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "pulsundersokelse_svar_sporsmal_id_fkey"
            columns: ["sporsmal_id"]
            isOneToOne: false
            referencedRelation: "puls_sporsmal_bank"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "pulsundersokelse_svar_undersokelse_id_fkey"
            columns: ["undersokelse_id"]
            isOneToOne: false
            referencedRelation: "pulsundersokelser"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "pulsundersokelse_svar_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "pulsundersokelse_svar_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "pulsundersokelse_svar_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      pulsundersokelser: {
        Row: {
          aktiv: boolean | null
          beskrivelse: string | null
          bruk_rotasjon: boolean | null
          created_at: string | null
          frekvens: string
          id: string
          navn: string
          puls_type: Database["public"]["Enums"]["puls_type"] | null
          salon_id: string
          siste_sporsmal_ids: string[] | null
          slutt_dato: string | null
          start_dato: string
          updated_at: string | null
        }
        Insert: {
          aktiv?: boolean | null
          beskrivelse?: string | null
          bruk_rotasjon?: boolean | null
          created_at?: string | null
          frekvens: string
          id?: string
          navn: string
          puls_type?: Database["public"]["Enums"]["puls_type"] | null
          salon_id: string
          siste_sporsmal_ids?: string[] | null
          slutt_dato?: string | null
          start_dato: string
          updated_at?: string | null
        }
        Update: {
          aktiv?: boolean | null
          beskrivelse?: string | null
          bruk_rotasjon?: boolean | null
          created_at?: string | null
          frekvens?: string
          id?: string
          navn?: string
          puls_type?: Database["public"]["Enums"]["puls_type"] | null
          salon_id?: string
          siste_sporsmal_ids?: string[] | null
          slutt_dato?: string | null
          start_dato?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "pulsundersokelser_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
        ]
      }
      rapport_kommentarer: {
        Row: {
          aar: number
          created_at: string | null
          id: string
          kommentar: string | null
          kpi_type: string | null
          maned: number | null
          opprettet_av: string | null
          periode_type: string
          salon_id: string
          svar: string | null
          uke: number | null
          updated_at: string | null
        }
        Insert: {
          aar: number
          created_at?: string | null
          id?: string
          kommentar?: string | null
          kpi_type?: string | null
          maned?: number | null
          opprettet_av?: string | null
          periode_type?: string
          salon_id: string
          svar?: string | null
          uke?: number | null
          updated_at?: string | null
        }
        Update: {
          aar?: number
          created_at?: string | null
          id?: string
          kommentar?: string | null
          kpi_type?: string | null
          maned?: number | null
          opprettet_av?: string | null
          periode_type?: string
          salon_id?: string
          svar?: string | null
          uke?: number | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "rapport_kommentarer_opprettet_av_fkey"
            columns: ["opprettet_av"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "rapport_kommentarer_opprettet_av_fkey"
            columns: ["opprettet_av"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "rapport_kommentarer_opprettet_av_fkey"
            columns: ["opprettet_av"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "rapport_kommentarer_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
        ]
      }
      role_change_audit: {
        Row: {
          changed_at: string
          changed_by_name: string
          changed_by_user_id: string
          id: string
          new_role: string
          old_role: string
          user_email: string
          user_id: string
          user_name: string
        }
        Insert: {
          changed_at?: string
          changed_by_name: string
          changed_by_user_id: string
          id?: string
          new_role: string
          old_role: string
          user_email: string
          user_id: string
          user_name: string
        }
        Update: {
          changed_at?: string
          changed_by_name?: string
          changed_by_user_id?: string
          id?: string
          new_role?: string
          old_role?: string
          user_email?: string
          user_id?: string
          user_name?: string
        }
        Relationships: []
      }
      salon_goals: {
        Row: {
          created_at: string | null
          id: string
          salon_id: string | null
          target_addon_share_percent: number | null
          target_efficiency_percent: number | null
          target_rebooking_percent: number | null
          target_revenue_per_customer: number | null
          target_revenue_per_hour: number | null
          target_total_revenue: number | null
          target_varesalg_percent: number | null
          updated_at: string | null
          year: number
        }
        Insert: {
          created_at?: string | null
          id?: string
          salon_id?: string | null
          target_addon_share_percent?: number | null
          target_efficiency_percent?: number | null
          target_rebooking_percent?: number | null
          target_revenue_per_customer?: number | null
          target_revenue_per_hour?: number | null
          target_total_revenue?: number | null
          target_varesalg_percent?: number | null
          updated_at?: string | null
          year: number
        }
        Update: {
          created_at?: string | null
          id?: string
          salon_id?: string | null
          target_addon_share_percent?: number | null
          target_efficiency_percent?: number | null
          target_rebooking_percent?: number | null
          target_revenue_per_customer?: number | null
          target_revenue_per_hour?: number | null
          target_total_revenue?: number | null
          target_varesalg_percent?: number | null
          updated_at?: string | null
          year?: number
        }
        Relationships: [
          {
            foreignKeyName: "salon_goals_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
        ]
      }
      salon_insurance: {
        Row: {
          aktivering_dato: string | null
          antall_ansatte: number | null
          antall_arsverk: number | null
          antall_fritidsulykke: number | null
          antall_reiseforsikring: number | null
          arlig_omsetning: number | null
          avsluttede_forsikringer: boolean | null
          bestillingsdato: string | null
          bytter_selskap: boolean | null
          created_at: string | null
          cyber_aktiv: boolean | null
          fritidsulykke_aktiv: boolean | null
          helse_antall_aktive: number | null
          helse_status: boolean | null
          helseforsikring_avtalenummer: string | null
          helseforsikring_oppsigelsesdato: string | null
          helseforsikring_oppstartsdato: string | null
          helseforsikring_premie: number | null
          helseforsikring_status: string | null
          hubspot_company_id: string | null
          hubspot_synced_at: string | null
          id: string
          innmelding_dato: string | null
          kontaktperson_epost: string | null
          kontaktperson_navn: string | null
          oppsigelse_dato: string | null
          oppstartsdato: string | null
          pris_cyber: number | null
          pris_fritidsulykke: number | null
          pris_reise: number | null
          pris_salong: number | null
          pris_yrkesskadeforsikring: number | null
          reise_aktiv: boolean | null
          salon_id: string
          salong_aktiv: boolean | null
          salong_niva: string | null
          sum_fritidsulykke: number | null
          sum_mvil: string | null
          sum_reise: number | null
          sum_totalt: number | null
          sum_yrkesskadeforsikring: number | null
          tidligere_forsikringer: string | null
          updated_at: string | null
          yrkesskadeforsikring_aktiv: boolean | null
        }
        Insert: {
          aktivering_dato?: string | null
          antall_ansatte?: number | null
          antall_arsverk?: number | null
          antall_fritidsulykke?: number | null
          antall_reiseforsikring?: number | null
          arlig_omsetning?: number | null
          avsluttede_forsikringer?: boolean | null
          bestillingsdato?: string | null
          bytter_selskap?: boolean | null
          created_at?: string | null
          cyber_aktiv?: boolean | null
          fritidsulykke_aktiv?: boolean | null
          helse_antall_aktive?: number | null
          helse_status?: boolean | null
          helseforsikring_avtalenummer?: string | null
          helseforsikring_oppsigelsesdato?: string | null
          helseforsikring_oppstartsdato?: string | null
          helseforsikring_premie?: number | null
          helseforsikring_status?: string | null
          hubspot_company_id?: string | null
          hubspot_synced_at?: string | null
          id?: string
          innmelding_dato?: string | null
          kontaktperson_epost?: string | null
          kontaktperson_navn?: string | null
          oppsigelse_dato?: string | null
          oppstartsdato?: string | null
          pris_cyber?: number | null
          pris_fritidsulykke?: number | null
          pris_reise?: number | null
          pris_salong?: number | null
          pris_yrkesskadeforsikring?: number | null
          reise_aktiv?: boolean | null
          salon_id: string
          salong_aktiv?: boolean | null
          salong_niva?: string | null
          sum_fritidsulykke?: number | null
          sum_mvil?: string | null
          sum_reise?: number | null
          sum_totalt?: number | null
          sum_yrkesskadeforsikring?: number | null
          tidligere_forsikringer?: string | null
          updated_at?: string | null
          yrkesskadeforsikring_aktiv?: boolean | null
        }
        Update: {
          aktivering_dato?: string | null
          antall_ansatte?: number | null
          antall_arsverk?: number | null
          antall_fritidsulykke?: number | null
          antall_reiseforsikring?: number | null
          arlig_omsetning?: number | null
          avsluttede_forsikringer?: boolean | null
          bestillingsdato?: string | null
          bytter_selskap?: boolean | null
          created_at?: string | null
          cyber_aktiv?: boolean | null
          fritidsulykke_aktiv?: boolean | null
          helse_antall_aktive?: number | null
          helse_status?: boolean | null
          helseforsikring_avtalenummer?: string | null
          helseforsikring_oppsigelsesdato?: string | null
          helseforsikring_oppstartsdato?: string | null
          helseforsikring_premie?: number | null
          helseforsikring_status?: string | null
          hubspot_company_id?: string | null
          hubspot_synced_at?: string | null
          id?: string
          innmelding_dato?: string | null
          kontaktperson_epost?: string | null
          kontaktperson_navn?: string | null
          oppsigelse_dato?: string | null
          oppstartsdato?: string | null
          pris_cyber?: number | null
          pris_fritidsulykke?: number | null
          pris_reise?: number | null
          pris_salong?: number | null
          pris_yrkesskadeforsikring?: number | null
          reise_aktiv?: boolean | null
          salon_id?: string
          salong_aktiv?: boolean | null
          salong_niva?: string | null
          sum_fritidsulykke?: number | null
          sum_mvil?: string | null
          sum_reise?: number | null
          sum_totalt?: number | null
          sum_yrkesskadeforsikring?: number | null
          tidligere_forsikringer?: string | null
          updated_at?: string | null
          yrkesskadeforsikring_aktiv?: boolean | null
        }
        Relationships: [
          {
            foreignKeyName: "salon_insurance_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: true
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
        ]
      }
      salon_moduler: {
        Row: {
          aktivert_av: string | null
          aktivert_dato: string
          created_at: string
          deaktivert_dato: string | null
          id: string
          modul_id: string
          salon_id: string
        }
        Insert: {
          aktivert_av?: string | null
          aktivert_dato?: string
          created_at?: string
          deaktivert_dato?: string | null
          id?: string
          modul_id: string
          salon_id: string
        }
        Update: {
          aktivert_av?: string | null
          aktivert_dato?: string
          created_at?: string
          deaktivert_dato?: string | null
          id?: string
          modul_id?: string
          salon_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "salon_moduler_aktivert_av_fkey"
            columns: ["aktivert_av"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "salon_moduler_aktivert_av_fkey"
            columns: ["aktivert_av"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "salon_moduler_aktivert_av_fkey"
            columns: ["aktivert_av"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "salon_moduler_modul_id_fkey"
            columns: ["modul_id"]
            isOneToOne: false
            referencedRelation: "portal_moduler"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "salon_moduler_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
        ]
      }
      salon_suppliers: {
        Row: {
          avtale_sluttdato: string | null
          avtale_startdato: string | null
          bonusstruktur: string | null
          created_at: string | null
          id: string
          salon_id: string | null
          spesialavtale_detaljer: string | null
          supplier_id: string | null
        }
        Insert: {
          avtale_sluttdato?: string | null
          avtale_startdato?: string | null
          bonusstruktur?: string | null
          created_at?: string | null
          id?: string
          salon_id?: string | null
          spesialavtale_detaljer?: string | null
          supplier_id?: string | null
        }
        Update: {
          avtale_sluttdato?: string | null
          avtale_startdato?: string | null
          bonusstruktur?: string | null
          created_at?: string | null
          id?: string
          salon_id?: string | null
          spesialavtale_detaljer?: string | null
          supplier_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "salon_suppliers_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "salon_suppliers_supplier_id_fkey"
            columns: ["supplier_id"]
            isOneToOne: false
            referencedRelation: "suppliers"
            referencedColumns: ["id"]
          },
        ]
      }
      salong_apningstider: {
        Row: {
          apner: string | null
          created_at: string | null
          id: string
          ideell_bemanning: number | null
          merknad: string | null
          min_bemanning: number | null
          salon_id: string
          stenger: string | null
          stengt: boolean | null
          ukedag: number
          updated_at: string | null
        }
        Insert: {
          apner?: string | null
          created_at?: string | null
          id?: string
          ideell_bemanning?: number | null
          merknad?: string | null
          min_bemanning?: number | null
          salon_id: string
          stenger?: string | null
          stengt?: boolean | null
          ukedag: number
          updated_at?: string | null
        }
        Update: {
          apner?: string | null
          created_at?: string | null
          id?: string
          ideell_bemanning?: number | null
          merknad?: string | null
          min_bemanning?: number | null
          salon_id?: string
          stenger?: string | null
          stengt?: boolean | null
          ukedag?: number
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "salong_apningstider_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
        ]
      }
      salong_apningstider_unntak: {
        Row: {
          apner: string | null
          arsak: string | null
          created_at: string | null
          dato: string
          id: string
          ideell_bemanning: number | null
          kilde: string | null
          min_bemanning: number | null
          opprinnelig_helligdag: string | null
          salon_id: string
          stenger: string | null
          stengt: boolean | null
        }
        Insert: {
          apner?: string | null
          arsak?: string | null
          created_at?: string | null
          dato: string
          id?: string
          ideell_bemanning?: number | null
          kilde?: string | null
          min_bemanning?: number | null
          opprinnelig_helligdag?: string | null
          salon_id: string
          stenger?: string | null
          stengt?: boolean | null
        }
        Update: {
          apner?: string | null
          arsak?: string | null
          created_at?: string | null
          dato?: string
          id?: string
          ideell_bemanning?: number | null
          kilde?: string | null
          min_bemanning?: number | null
          opprinnelig_helligdag?: string | null
          salon_id?: string
          stenger?: string | null
          stengt?: boolean | null
        }
        Relationships: [
          {
            foreignKeyName: "salong_apningstider_unntak_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
        ]
      }
      salong_bemanning_per_time: {
        Row: {
          created_at: string | null
          id: string
          ideell_bemanning: number
          min_bemanning: number
          salon_id: string
          time_fra: string
          time_til: string
          ukedag: number
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          ideell_bemanning?: number
          min_bemanning?: number
          salon_id: string
          time_fra: string
          time_til: string
          ukedag: number
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          ideell_bemanning?: number
          min_bemanning?: number
          salon_id?: string
          time_fra?: string
          time_til?: string
          ukedag?: number
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "salong_bemanning_per_time_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
        ]
      }
      salong_ferie_regler: {
        Row: {
          created_at: string
          host_aktiv: boolean
          host_andel_prosent: number
          host_bruk_dato: boolean | null
          host_slutt_dato: string | null
          host_slutt_uke: number
          host_start_dato: string | null
          host_start_uke: number
          id: string
          jul_aktiv: boolean
          jul_andel_prosent: number
          jul_bruk_dato: boolean | null
          jul_slutt_dato: string | null
          jul_slutt_uke: number
          jul_start_dato: string | null
          jul_start_uke: number
          min_bemanning: number
          paske_aktiv: boolean
          paske_andel_prosent: number
          salon_id: string
          sommer_antall_uker: number
          sommer_bruk_dato: boolean | null
          sommer_slutt_dato: string | null
          sommer_slutt_uke: number
          sommer_start_dato: string | null
          sommer_start_uke: number
          updated_at: string
          vinter_aktiv: boolean
          vinter_andel_prosent: number
          vinter_bruk_dato: boolean | null
          vinter_slutt_dato: string | null
          vinter_slutt_uke: number
          vinter_start_dato: string | null
          vinter_start_uke: number
        }
        Insert: {
          created_at?: string
          host_aktiv?: boolean
          host_andel_prosent?: number
          host_bruk_dato?: boolean | null
          host_slutt_dato?: string | null
          host_slutt_uke?: number
          host_start_dato?: string | null
          host_start_uke?: number
          id?: string
          jul_aktiv?: boolean
          jul_andel_prosent?: number
          jul_bruk_dato?: boolean | null
          jul_slutt_dato?: string | null
          jul_slutt_uke?: number
          jul_start_dato?: string | null
          jul_start_uke?: number
          min_bemanning?: number
          paske_aktiv?: boolean
          paske_andel_prosent?: number
          salon_id: string
          sommer_antall_uker?: number
          sommer_bruk_dato?: boolean | null
          sommer_slutt_dato?: string | null
          sommer_slutt_uke?: number
          sommer_start_dato?: string | null
          sommer_start_uke?: number
          updated_at?: string
          vinter_aktiv?: boolean
          vinter_andel_prosent?: number
          vinter_bruk_dato?: boolean | null
          vinter_slutt_dato?: string | null
          vinter_slutt_uke?: number
          vinter_start_dato?: string | null
          vinter_start_uke?: number
        }
        Update: {
          created_at?: string
          host_aktiv?: boolean
          host_andel_prosent?: number
          host_bruk_dato?: boolean | null
          host_slutt_dato?: string | null
          host_slutt_uke?: number
          host_start_dato?: string | null
          host_start_uke?: number
          id?: string
          jul_aktiv?: boolean
          jul_andel_prosent?: number
          jul_bruk_dato?: boolean | null
          jul_slutt_dato?: string | null
          jul_slutt_uke?: number
          jul_start_dato?: string | null
          jul_start_uke?: number
          min_bemanning?: number
          paske_aktiv?: boolean
          paske_andel_prosent?: number
          salon_id?: string
          sommer_antall_uker?: number
          sommer_bruk_dato?: boolean | null
          sommer_slutt_dato?: string | null
          sommer_slutt_uke?: number
          sommer_start_dato?: string | null
          sommer_start_uke?: number
          updated_at?: string
          vinter_aktiv?: boolean
          vinter_andel_prosent?: number
          vinter_bruk_dato?: boolean | null
          vinter_slutt_dato?: string | null
          vinter_slutt_uke?: number
          vinter_start_dato?: string | null
          vinter_start_uke?: number
        }
        Relationships: [
          {
            foreignKeyName: "salong_ferie_regler_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: true
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
        ]
      }
      salong_leverandorer: {
        Row: {
          avtale_startdato: string | null
          bonusstruktur: string | null
          created_at: string | null
          har_kjemi: boolean | null
          har_produkter: boolean | null
          id: string
          leverandor_id: string
          salon_id: string
          spesialavtale_detaljer: string | null
          updated_at: string | null
        }
        Insert: {
          avtale_startdato?: string | null
          bonusstruktur?: string | null
          created_at?: string | null
          har_kjemi?: boolean | null
          har_produkter?: boolean | null
          id?: string
          leverandor_id: string
          salon_id: string
          spesialavtale_detaljer?: string | null
          updated_at?: string | null
        }
        Update: {
          avtale_startdato?: string | null
          bonusstruktur?: string | null
          created_at?: string | null
          har_kjemi?: boolean | null
          har_produkter?: boolean | null
          id?: string
          leverandor_id?: string
          salon_id?: string
          spesialavtale_detaljer?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "salong_leverandorer_leverandor_id_fkey"
            columns: ["leverandor_id"]
            isOneToOne: false
            referencedRelation: "leverandorer"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "salong_leverandorer_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
        ]
      }
      salong_merker: {
        Row: {
          created_at: string | null
          id: string
          merke_id: string
          rapporteringstype:
            | Database["public"]["Enums"]["rapporteringstype"]
            | null
          salon_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          merke_id: string
          rapporteringstype?:
            | Database["public"]["Enums"]["rapporteringstype"]
            | null
          salon_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          merke_id?: string
          rapporteringstype?:
            | Database["public"]["Enums"]["rapporteringstype"]
            | null
          salon_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "salong_merker_merke_id_fkey"
            columns: ["merke_id"]
            isOneToOne: false
            referencedRelation: "leverandor_merker"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "salong_merker_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
        ]
      }
      salons: {
        Row: {
          address: string | null
          ar_reg_omsetning: number | null
          avsluttet_medlemskap_dato: string | null
          bankkontonummer: string | null
          chain_id: string | null
          city: string | null
          created_at: string | null
          district_id: string | null
          domain: string | null
          employee_count: number | null
          founded_date: string | null
          hs_object_id: string | null
          hubspot_owner_id: string | null
          hubspot_synced_at: string | null
          id: string
          legal_name: string | null
          lifecyclestage: string | null
          logo_url: string | null
          medlemsavgift: number | null
          medlemsnummer: string | null
          medlemsstatus: string | null
          name: string
          neste_kontakt_dato: string | null
          onboarding_fullfort_at: string | null
          oppsigelse_arsak: string | null
          oppsigelsesdato_for_medlemskap: string | null
          org_number: string | null
          phone: string | null
          postal_code: string | null
          reg_omsetning: number | null
          reg_resultat: number | null
          registreringsdato: string | null
          siste_kontakt_dato: string | null
          start_medlemskap_dato: string | null
          trenger_oppfolging: boolean | null
          type_medlemskap: Database["public"]["Enums"]["type_medlemskap"] | null
          updated_at: string | null
          utlpsdato_for_medlemskap: string | null
        }
        Insert: {
          address?: string | null
          ar_reg_omsetning?: number | null
          avsluttet_medlemskap_dato?: string | null
          bankkontonummer?: string | null
          chain_id?: string | null
          city?: string | null
          created_at?: string | null
          district_id?: string | null
          domain?: string | null
          employee_count?: number | null
          founded_date?: string | null
          hs_object_id?: string | null
          hubspot_owner_id?: string | null
          hubspot_synced_at?: string | null
          id?: string
          legal_name?: string | null
          lifecyclestage?: string | null
          logo_url?: string | null
          medlemsavgift?: number | null
          medlemsnummer?: string | null
          medlemsstatus?: string | null
          name: string
          neste_kontakt_dato?: string | null
          onboarding_fullfort_at?: string | null
          oppsigelse_arsak?: string | null
          oppsigelsesdato_for_medlemskap?: string | null
          org_number?: string | null
          phone?: string | null
          postal_code?: string | null
          reg_omsetning?: number | null
          reg_resultat?: number | null
          registreringsdato?: string | null
          siste_kontakt_dato?: string | null
          start_medlemskap_dato?: string | null
          trenger_oppfolging?: boolean | null
          type_medlemskap?:
            | Database["public"]["Enums"]["type_medlemskap"]
            | null
          updated_at?: string | null
          utlpsdato_for_medlemskap?: string | null
        }
        Update: {
          address?: string | null
          ar_reg_omsetning?: number | null
          avsluttet_medlemskap_dato?: string | null
          bankkontonummer?: string | null
          chain_id?: string | null
          city?: string | null
          created_at?: string | null
          district_id?: string | null
          domain?: string | null
          employee_count?: number | null
          founded_date?: string | null
          hs_object_id?: string | null
          hubspot_owner_id?: string | null
          hubspot_synced_at?: string | null
          id?: string
          legal_name?: string | null
          lifecyclestage?: string | null
          logo_url?: string | null
          medlemsavgift?: number | null
          medlemsnummer?: string | null
          medlemsstatus?: string | null
          name?: string
          neste_kontakt_dato?: string | null
          onboarding_fullfort_at?: string | null
          oppsigelse_arsak?: string | null
          oppsigelsesdato_for_medlemskap?: string | null
          org_number?: string | null
          phone?: string | null
          postal_code?: string | null
          reg_omsetning?: number | null
          reg_resultat?: number | null
          registreringsdato?: string | null
          siste_kontakt_dato?: string | null
          start_medlemskap_dato?: string | null
          trenger_oppfolging?: boolean | null
          type_medlemskap?:
            | Database["public"]["Enums"]["type_medlemskap"]
            | null
          updated_at?: string | null
          utlpsdato_for_medlemskap?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "salons_chain_id_fkey"
            columns: ["chain_id"]
            isOneToOne: false
            referencedRelation: "chains"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "salons_district_id_fkey"
            columns: ["district_id"]
            isOneToOne: false
            referencedRelation: "districts"
            referencedColumns: ["id"]
          },
        ]
      }
      samtale_maler: {
        Row: {
          aktiv: boolean | null
          beskrivelse: string | null
          created_at: string | null
          id: string
          kompetanser: string[] | null
          navn: string
          opprettet_av: string | null
          seksjoner: Json
          type: string | null
          updated_at: string | null
        }
        Insert: {
          aktiv?: boolean | null
          beskrivelse?: string | null
          created_at?: string | null
          id?: string
          kompetanser?: string[] | null
          navn: string
          opprettet_av?: string | null
          seksjoner?: Json
          type?: string | null
          updated_at?: string | null
        }
        Update: {
          aktiv?: boolean | null
          beskrivelse?: string | null
          created_at?: string | null
          id?: string
          kompetanser?: string[] | null
          navn?: string
          opprettet_av?: string | null
          seksjoner?: Json
          type?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "samtale_maler_opprettet_av_fkey"
            columns: ["opprettet_av"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "samtale_maler_opprettet_av_fkey"
            columns: ["opprettet_av"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "samtale_maler_opprettet_av_fkey"
            columns: ["opprettet_av"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      samtale_smart_mal: {
        Row: {
          created_at: string | null
          fremgang: number | null
          frist: string | null
          id: string
          maalbart: string
          oppnaaelig: string
          relevant: string
          samtale_id: string
          spesifikt: string
          status: string | null
          tidsbestemt: string
          tittel: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          fremgang?: number | null
          frist?: string | null
          id?: string
          maalbart: string
          oppnaaelig: string
          relevant: string
          samtale_id: string
          spesifikt: string
          status?: string | null
          tidsbestemt: string
          tittel: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          fremgang?: number | null
          frist?: string | null
          id?: string
          maalbart?: string
          oppnaaelig?: string
          relevant?: string
          samtale_id?: string
          spesifikt?: string
          status?: string | null
          tidsbestemt?: string
          tittel?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "samtale_smart_mal_samtale_id_fkey"
            columns: ["samtale_id"]
            isOneToOne: false
            referencedRelation: "ansatt_samtaler"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "samtale_smart_mal_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "samtale_smart_mal_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "samtale_smart_mal_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      sjekkliste_maler: {
        Row: {
          beskrivelse: string | null
          created_at: string
          er_aktiv: boolean | null
          id: string
          navn: string
          opprettet_av: string | null
          prosess_type: Database["public"]["Enums"]["ansatt_prosess_type"]
          updated_at: string
        }
        Insert: {
          beskrivelse?: string | null
          created_at?: string
          er_aktiv?: boolean | null
          id?: string
          navn: string
          opprettet_av?: string | null
          prosess_type: Database["public"]["Enums"]["ansatt_prosess_type"]
          updated_at?: string
        }
        Update: {
          beskrivelse?: string | null
          created_at?: string
          er_aktiv?: boolean | null
          id?: string
          navn?: string
          opprettet_av?: string | null
          prosess_type?: Database["public"]["Enums"]["ansatt_prosess_type"]
          updated_at?: string
        }
        Relationships: []
      }
      sjekkliste_oppgave_maler: {
        Row: {
          ansvarlig_rolle: string | null
          beskrivelse: string | null
          created_at: string
          frist_dager: number | null
          id: string
          kategori: string | null
          mal_id: string
          obligatorisk: boolean | null
          prioritet: number | null
          tittel: string
        }
        Insert: {
          ansvarlig_rolle?: string | null
          beskrivelse?: string | null
          created_at?: string
          frist_dager?: number | null
          id?: string
          kategori?: string | null
          mal_id: string
          obligatorisk?: boolean | null
          prioritet?: number | null
          tittel: string
        }
        Update: {
          ansvarlig_rolle?: string | null
          beskrivelse?: string | null
          created_at?: string
          frist_dager?: number | null
          id?: string
          kategori?: string | null
          mal_id?: string
          obligatorisk?: boolean | null
          prioritet?: number | null
          tittel?: string
        }
        Relationships: [
          {
            foreignKeyName: "sjekkliste_oppgave_maler_mal_id_fkey"
            columns: ["mal_id"]
            isOneToOne: false
            referencedRelation: "sjekkliste_maler"
            referencedColumns: ["id"]
          },
        ]
      }
      sms_log: {
        Row: {
          error_message: string | null
          id: string
          message_preview: string | null
          message_type: string
          phone_number: string
          sakari_message_id: string | null
          sent_at: string | null
          status: string | null
          user_id: string | null
        }
        Insert: {
          error_message?: string | null
          id?: string
          message_preview?: string | null
          message_type: string
          phone_number: string
          sakari_message_id?: string | null
          sent_at?: string | null
          status?: string | null
          user_id?: string | null
        }
        Update: {
          error_message?: string | null
          id?: string
          message_preview?: string | null
          message_type?: string
          phone_number?: string
          sakari_message_id?: string | null
          sent_at?: string | null
          status?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "sms_log_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sms_log_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sms_log_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      sms_templates: {
        Row: {
          body_template: string
          created_at: string | null
          id: string
          name: string
          slug: string
          updated_at: string | null
        }
        Insert: {
          body_template: string
          created_at?: string | null
          id?: string
          name: string
          slug: string
          updated_at?: string | null
        }
        Update: {
          body_template?: string
          created_at?: string | null
          id?: string
          name?: string
          slug?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      stylist_kpi_config: {
        Row: {
          ansatt_id: string | null
          budsjett_stillingsprosent_kilde:
            | Database["public"]["Enums"]["budsjett_stillingsprosent_kilde"]
            | null
          created_at: string | null
          effektivitet_prosent_mal: number | null
          id: string
          omsetning_per_time_mal: number | null
          rebooking_prosent_mal: number | null
          salon_id: string
          updated_at: string | null
          user_id: string | null
          varesalg_prosent_mal: number | null
        }
        Insert: {
          ansatt_id?: string | null
          budsjett_stillingsprosent_kilde?:
            | Database["public"]["Enums"]["budsjett_stillingsprosent_kilde"]
            | null
          created_at?: string | null
          effektivitet_prosent_mal?: number | null
          id?: string
          omsetning_per_time_mal?: number | null
          rebooking_prosent_mal?: number | null
          salon_id: string
          updated_at?: string | null
          user_id?: string | null
          varesalg_prosent_mal?: number | null
        }
        Update: {
          ansatt_id?: string | null
          budsjett_stillingsprosent_kilde?:
            | Database["public"]["Enums"]["budsjett_stillingsprosent_kilde"]
            | null
          created_at?: string | null
          effektivitet_prosent_mal?: number | null
          id?: string
          omsetning_per_time_mal?: number | null
          rebooking_prosent_mal?: number | null
          salon_id?: string
          updated_at?: string | null
          user_id?: string | null
          varesalg_prosent_mal?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "stylist_kpi_config_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "stylist_kpi_config_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "stylist_kpi_config_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_utvidet"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "stylist_kpi_config_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "stylist_kpi_config_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "stylist_kpi_config_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "stylist_kpi_config_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      supplier_identifiers: {
        Row: {
          created_at: string | null
          id: string
          identifier_type: string | null
          notes: string | null
          salon_id: string
          supplier_customer_number: string
          supplier_id: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          identifier_type?: string | null
          notes?: string | null
          salon_id: string
          supplier_customer_number: string
          supplier_id: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          identifier_type?: string | null
          notes?: string | null
          salon_id?: string
          supplier_customer_number?: string
          supplier_id?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "supplier_identifiers_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "supplier_identifiers_supplier_id_fkey"
            columns: ["supplier_id"]
            isOneToOne: false
            referencedRelation: "leverandorer"
            referencedColumns: ["id"]
          },
        ]
      }
      supplier_team_users: {
        Row: {
          active: boolean | null
          created_at: string | null
          id: string
          role: Database["public"]["Enums"]["app_role"]
          supplier_id: string | null
          user_id: string | null
        }
        Insert: {
          active?: boolean | null
          created_at?: string | null
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          supplier_id?: string | null
          user_id?: string | null
        }
        Update: {
          active?: boolean | null
          created_at?: string | null
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          supplier_id?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "supplier_team_users_supplier_id_fkey"
            columns: ["supplier_id"]
            isOneToOne: false
            referencedRelation: "suppliers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "supplier_team_users_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "supplier_team_users_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "supplier_team_users_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      suppliers: {
        Row: {
          active: boolean | null
          contact_email: string | null
          contact_name: string | null
          created_at: string | null
          cumulative_reporting: boolean | null
          cumulative_reset_month: number | null
          hubspot_company_id: string | null
          hubspot_synced_at: string | null
          id: string
          name: string
          updated_at: string | null
        }
        Insert: {
          active?: boolean | null
          contact_email?: string | null
          contact_name?: string | null
          created_at?: string | null
          cumulative_reporting?: boolean | null
          cumulative_reset_month?: number | null
          hubspot_company_id?: string | null
          hubspot_synced_at?: string | null
          id?: string
          name: string
          updated_at?: string | null
        }
        Update: {
          active?: boolean | null
          contact_email?: string | null
          contact_name?: string | null
          created_at?: string | null
          cumulative_reporting?: boolean | null
          cumulative_reset_month?: number | null
          hubspot_company_id?: string | null
          hubspot_synced_at?: string | null
          id?: string
          name?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      sykefravear_oppfolging: {
        Row: {
          created_at: string | null
          dato: string
          fravaer_id: string
          id: string
          neste_oppfolging: string | null
          notater: string | null
          oppfolging_type: string
          salon_id: string
          updated_at: string | null
          user_id: string
          utfort_av: string | null
        }
        Insert: {
          created_at?: string | null
          dato?: string
          fravaer_id: string
          id?: string
          neste_oppfolging?: string | null
          notater?: string | null
          oppfolging_type: string
          salon_id: string
          updated_at?: string | null
          user_id: string
          utfort_av?: string | null
        }
        Update: {
          created_at?: string | null
          dato?: string
          fravaer_id?: string
          id?: string
          neste_oppfolging?: string | null
          notater?: string | null
          oppfolging_type?: string
          salon_id?: string
          updated_at?: string | null
          user_id?: string
          utfort_av?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "sykefravear_oppfolging_fravaer_id_fkey"
            columns: ["fravaer_id"]
            isOneToOne: false
            referencedRelation: "fravaer"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykefravear_oppfolging_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykefravear_oppfolging_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykefravear_oppfolging_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykefravear_oppfolging_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykefravear_oppfolging_utfort_av_fkey"
            columns: ["utfort_av"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykefravear_oppfolging_utfort_av_fkey"
            columns: ["utfort_av"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykefravear_oppfolging_utfort_av_fkey"
            columns: ["utfort_av"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      sykemeldinger: {
        Row: {
          avslutnings_oppsummering: string | null
          avslutningstype: string | null
          avsluttet_dato: string | null
          beskrivelse: string | null
          created_at: string
          dokument_url: string | null
          faktisk_sluttdato: string | null
          forventet_sluttdato: string | null
          fravar_id: string | null
          grad: number
          id: string
          oppfolgingslop_startet: boolean | null
          oppfolgingslop_startet_av: string | null
          oppfolgingslop_startet_dato: string | null
          salon_id: string
          startdato: string
          status: Database["public"]["Enums"]["sykmelding_status"]
          updated_at: string
          user_id: string
        }
        Insert: {
          avslutnings_oppsummering?: string | null
          avslutningstype?: string | null
          avsluttet_dato?: string | null
          beskrivelse?: string | null
          created_at?: string
          dokument_url?: string | null
          faktisk_sluttdato?: string | null
          forventet_sluttdato?: string | null
          fravar_id?: string | null
          grad?: number
          id?: string
          oppfolgingslop_startet?: boolean | null
          oppfolgingslop_startet_av?: string | null
          oppfolgingslop_startet_dato?: string | null
          salon_id: string
          startdato: string
          status?: Database["public"]["Enums"]["sykmelding_status"]
          updated_at?: string
          user_id: string
        }
        Update: {
          avslutnings_oppsummering?: string | null
          avslutningstype?: string | null
          avsluttet_dato?: string | null
          beskrivelse?: string | null
          created_at?: string
          dokument_url?: string | null
          faktisk_sluttdato?: string | null
          forventet_sluttdato?: string | null
          fravar_id?: string | null
          grad?: number
          id?: string
          oppfolgingslop_startet?: boolean | null
          oppfolgingslop_startet_av?: string | null
          oppfolgingslop_startet_dato?: string | null
          salon_id?: string
          startdato?: string
          status?: Database["public"]["Enums"]["sykmelding_status"]
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "sykemeldinger_fravar_id_fkey"
            columns: ["fravar_id"]
            isOneToOne: false
            referencedRelation: "fravaer"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykemeldinger_oppfolgingslop_startet_av_fkey"
            columns: ["oppfolgingslop_startet_av"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykemeldinger_oppfolgingslop_startet_av_fkey"
            columns: ["oppfolgingslop_startet_av"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykemeldinger_oppfolgingslop_startet_av_fkey"
            columns: ["oppfolgingslop_startet_av"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykemeldinger_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykemeldinger_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykemeldinger_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykemeldinger_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      sykmelding_aktivitetskrav: {
        Row: {
          aktivitetsmuligheter: string | null
          begrunnelse: string | null
          created_at: string
          dokumentasjon_url: string | null
          dokumentert: boolean | null
          id: string
          kan_utfore_aktivitet: boolean | null
          sykmelding_id: string
          updated_at: string
          vurdert_av: string | null
          vurdert_dato: string | null
        }
        Insert: {
          aktivitetsmuligheter?: string | null
          begrunnelse?: string | null
          created_at?: string
          dokumentasjon_url?: string | null
          dokumentert?: boolean | null
          id?: string
          kan_utfore_aktivitet?: boolean | null
          sykmelding_id: string
          updated_at?: string
          vurdert_av?: string | null
          vurdert_dato?: string | null
        }
        Update: {
          aktivitetsmuligheter?: string | null
          begrunnelse?: string | null
          created_at?: string
          dokumentasjon_url?: string | null
          dokumentert?: boolean | null
          id?: string
          kan_utfore_aktivitet?: boolean | null
          sykmelding_id?: string
          updated_at?: string
          vurdert_av?: string | null
          vurdert_dato?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "sykmelding_aktivitetskrav_sykmelding_id_fkey"
            columns: ["sykmelding_id"]
            isOneToOne: false
            referencedRelation: "sykemeldinger"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykmelding_aktivitetskrav_vurdert_av_fkey"
            columns: ["vurdert_av"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykmelding_aktivitetskrav_vurdert_av_fkey"
            columns: ["vurdert_av"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykmelding_aktivitetskrav_vurdert_av_fkey"
            columns: ["vurdert_av"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      sykmelding_dialogmoter: {
        Row: {
          agenda: string | null
          created_at: string
          deltakere: string[] | null
          forberedelse_ansatt: string | null
          forberedelse_leder: string | null
          gjennomfort_dato: string | null
          id: string
          motetype: Database["public"]["Enums"]["dialogmote_type"]
          nav_invitert: boolean | null
          neste_steg: string | null
          oppfolging_tiltak: string | null
          opprettet_av: string | null
          planlagt_dato: string | null
          referat: string | null
          sjekkliste: Json | null
          status: Database["public"]["Enums"]["dialogmote_status"]
          sykmelding_id: string
          updated_at: string
        }
        Insert: {
          agenda?: string | null
          created_at?: string
          deltakere?: string[] | null
          forberedelse_ansatt?: string | null
          forberedelse_leder?: string | null
          gjennomfort_dato?: string | null
          id?: string
          motetype: Database["public"]["Enums"]["dialogmote_type"]
          nav_invitert?: boolean | null
          neste_steg?: string | null
          oppfolging_tiltak?: string | null
          opprettet_av?: string | null
          planlagt_dato?: string | null
          referat?: string | null
          sjekkliste?: Json | null
          status?: Database["public"]["Enums"]["dialogmote_status"]
          sykmelding_id: string
          updated_at?: string
        }
        Update: {
          agenda?: string | null
          created_at?: string
          deltakere?: string[] | null
          forberedelse_ansatt?: string | null
          forberedelse_leder?: string | null
          gjennomfort_dato?: string | null
          id?: string
          motetype?: Database["public"]["Enums"]["dialogmote_type"]
          nav_invitert?: boolean | null
          neste_steg?: string | null
          oppfolging_tiltak?: string | null
          opprettet_av?: string | null
          planlagt_dato?: string | null
          referat?: string | null
          sjekkliste?: Json | null
          status?: Database["public"]["Enums"]["dialogmote_status"]
          sykmelding_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "sykmelding_dialogmoter_opprettet_av_fkey"
            columns: ["opprettet_av"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykmelding_dialogmoter_opprettet_av_fkey"
            columns: ["opprettet_av"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykmelding_dialogmoter_opprettet_av_fkey"
            columns: ["opprettet_av"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykmelding_dialogmoter_sykmelding_id_fkey"
            columns: ["sykmelding_id"]
            isOneToOne: false
            referencedRelation: "sykemeldinger"
            referencedColumns: ["id"]
          },
        ]
      }
      sykmelding_evalueringer: {
        Row: {
          created_at: string
          evaluert_av: string | null
          evaluert_dato: string
          forebyggende_tiltak: string | null
          hva_fungerte: string | null
          hva_kunne_vaert_bedre: string | null
          id: string
          laeringspunkter: string | null
          sykmelding_id: string
        }
        Insert: {
          created_at?: string
          evaluert_av?: string | null
          evaluert_dato?: string
          forebyggende_tiltak?: string | null
          hva_fungerte?: string | null
          hva_kunne_vaert_bedre?: string | null
          id?: string
          laeringspunkter?: string | null
          sykmelding_id: string
        }
        Update: {
          created_at?: string
          evaluert_av?: string | null
          evaluert_dato?: string
          forebyggende_tiltak?: string | null
          hva_fungerte?: string | null
          hva_kunne_vaert_bedre?: string | null
          id?: string
          laeringspunkter?: string | null
          sykmelding_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "sykmelding_evalueringer_evaluert_av_fkey"
            columns: ["evaluert_av"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykmelding_evalueringer_evaluert_av_fkey"
            columns: ["evaluert_av"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykmelding_evalueringer_evaluert_av_fkey"
            columns: ["evaluert_av"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykmelding_evalueringer_sykmelding_id_fkey"
            columns: ["sykmelding_id"]
            isOneToOne: false
            referencedRelation: "sykemeldinger"
            referencedColumns: ["id"]
          },
        ]
      }
      sykmelding_fasevurderinger: {
        Row: {
          created_at: string
          fase: Database["public"]["Enums"]["sykmelding_fase"]
          fremgang: string | null
          id: string
          neste_steg: string | null
          status_vurdering: string | null
          sykmelding_id: string
          utfordringer: string | null
          vurdert_av: string | null
          vurdert_dato: string
        }
        Insert: {
          created_at?: string
          fase: Database["public"]["Enums"]["sykmelding_fase"]
          fremgang?: string | null
          id?: string
          neste_steg?: string | null
          status_vurdering?: string | null
          sykmelding_id: string
          utfordringer?: string | null
          vurdert_av?: string | null
          vurdert_dato?: string
        }
        Update: {
          created_at?: string
          fase?: Database["public"]["Enums"]["sykmelding_fase"]
          fremgang?: string | null
          id?: string
          neste_steg?: string | null
          status_vurdering?: string | null
          sykmelding_id?: string
          utfordringer?: string | null
          vurdert_av?: string | null
          vurdert_dato?: string
        }
        Relationships: [
          {
            foreignKeyName: "sykmelding_fasevurderinger_sykmelding_id_fkey"
            columns: ["sykmelding_id"]
            isOneToOne: false
            referencedRelation: "sykemeldinger"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykmelding_fasevurderinger_vurdert_av_fkey"
            columns: ["vurdert_av"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykmelding_fasevurderinger_vurdert_av_fkey"
            columns: ["vurdert_av"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykmelding_fasevurderinger_vurdert_av_fkey"
            columns: ["vurdert_av"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      sykmelding_notifikasjoner: {
        Row: {
          created_at: string
          id: string
          lest: boolean | null
          lest_dato: string | null
          melding: string
          mottaker_id: string
          sykmelding_id: string
          type: string
          uke_nummer: number | null
        }
        Insert: {
          created_at?: string
          id?: string
          lest?: boolean | null
          lest_dato?: string | null
          melding: string
          mottaker_id: string
          sykmelding_id: string
          type: string
          uke_nummer?: number | null
        }
        Update: {
          created_at?: string
          id?: string
          lest?: boolean | null
          lest_dato?: string | null
          melding?: string
          mottaker_id?: string
          sykmelding_id?: string
          type?: string
          uke_nummer?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "sykmelding_notifikasjoner_mottaker_id_fkey"
            columns: ["mottaker_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykmelding_notifikasjoner_mottaker_id_fkey"
            columns: ["mottaker_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykmelding_notifikasjoner_mottaker_id_fkey"
            columns: ["mottaker_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykmelding_notifikasjoner_sykmelding_id_fkey"
            columns: ["sykmelding_id"]
            isOneToOne: false
            referencedRelation: "sykemeldinger"
            referencedColumns: ["id"]
          },
        ]
      }
      sykmelding_oppfolgingsplaner: {
        Row: {
          ansatt_gradert_onske: string | null
          ansatt_hindringer: string | null
          ansatt_kartlagt_dato: string | null
          ansatt_oppgaver_kan: string | null
          ansatt_oppgaver_kan_ikke: string | null
          ansatt_tilrettelegging_behov: string | null
          arbeid_kan_ikke_utfores: string | null
          arbeid_kan_utfores: string | null
          bekreftet_av_ansatt: boolean | null
          bekreftet_av_ansatt_dato: string | null
          created_at: string
          gradert_arbeid_plan: string | null
          id: string
          laast: boolean | null
          laast_av: string | null
          laast_dato: string | null
          leder_alternative_oppgaver: string | null
          leder_fysiske_tiltak: string | null
          leder_kartlagt_av: string | null
          leder_kartlagt_dato: string | null
          leder_organisatoriske_tiltak: string | null
          leder_returforventning: string | null
          leder_sosiale_tiltak: string | null
          leder_vurdering: string | null
          maal_kort_sikt: string | null
          maal_lang_sikt: string | null
          sykmelding_id: string
          updated_at: string
          versjon: number
        }
        Insert: {
          ansatt_gradert_onske?: string | null
          ansatt_hindringer?: string | null
          ansatt_kartlagt_dato?: string | null
          ansatt_oppgaver_kan?: string | null
          ansatt_oppgaver_kan_ikke?: string | null
          ansatt_tilrettelegging_behov?: string | null
          arbeid_kan_ikke_utfores?: string | null
          arbeid_kan_utfores?: string | null
          bekreftet_av_ansatt?: boolean | null
          bekreftet_av_ansatt_dato?: string | null
          created_at?: string
          gradert_arbeid_plan?: string | null
          id?: string
          laast?: boolean | null
          laast_av?: string | null
          laast_dato?: string | null
          leder_alternative_oppgaver?: string | null
          leder_fysiske_tiltak?: string | null
          leder_kartlagt_av?: string | null
          leder_kartlagt_dato?: string | null
          leder_organisatoriske_tiltak?: string | null
          leder_returforventning?: string | null
          leder_sosiale_tiltak?: string | null
          leder_vurdering?: string | null
          maal_kort_sikt?: string | null
          maal_lang_sikt?: string | null
          sykmelding_id: string
          updated_at?: string
          versjon?: number
        }
        Update: {
          ansatt_gradert_onske?: string | null
          ansatt_hindringer?: string | null
          ansatt_kartlagt_dato?: string | null
          ansatt_oppgaver_kan?: string | null
          ansatt_oppgaver_kan_ikke?: string | null
          ansatt_tilrettelegging_behov?: string | null
          arbeid_kan_ikke_utfores?: string | null
          arbeid_kan_utfores?: string | null
          bekreftet_av_ansatt?: boolean | null
          bekreftet_av_ansatt_dato?: string | null
          created_at?: string
          gradert_arbeid_plan?: string | null
          id?: string
          laast?: boolean | null
          laast_av?: string | null
          laast_dato?: string | null
          leder_alternative_oppgaver?: string | null
          leder_fysiske_tiltak?: string | null
          leder_kartlagt_av?: string | null
          leder_kartlagt_dato?: string | null
          leder_organisatoriske_tiltak?: string | null
          leder_returforventning?: string | null
          leder_sosiale_tiltak?: string | null
          leder_vurdering?: string | null
          maal_kort_sikt?: string | null
          maal_lang_sikt?: string | null
          sykmelding_id?: string
          updated_at?: string
          versjon?: number
        }
        Relationships: [
          {
            foreignKeyName: "sykmelding_oppfolgingsplaner_laast_av_fkey"
            columns: ["laast_av"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykmelding_oppfolgingsplaner_laast_av_fkey"
            columns: ["laast_av"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykmelding_oppfolgingsplaner_laast_av_fkey"
            columns: ["laast_av"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykmelding_oppfolgingsplaner_leder_kartlagt_av_fkey"
            columns: ["leder_kartlagt_av"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykmelding_oppfolgingsplaner_leder_kartlagt_av_fkey"
            columns: ["leder_kartlagt_av"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykmelding_oppfolgingsplaner_leder_kartlagt_av_fkey"
            columns: ["leder_kartlagt_av"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykmelding_oppfolgingsplaner_sykmelding_id_fkey"
            columns: ["sykmelding_id"]
            isOneToOne: false
            referencedRelation: "sykemeldinger"
            referencedColumns: ["id"]
          },
        ]
      }
      sykmelding_tiltak: {
        Row: {
          ansvarlig_id: string | null
          beskrivelse: string | null
          created_at: string
          frist: string | null
          fullfort_dato: string | null
          id: string
          kommentar: string | null
          oppfolgingsplan_id: string | null
          status: Database["public"]["Enums"]["tiltak_status"]
          sykmelding_id: string
          tittel: string
          type: Database["public"]["Enums"]["tilretteleggingstype"]
          updated_at: string
        }
        Insert: {
          ansvarlig_id?: string | null
          beskrivelse?: string | null
          created_at?: string
          frist?: string | null
          fullfort_dato?: string | null
          id?: string
          kommentar?: string | null
          oppfolgingsplan_id?: string | null
          status?: Database["public"]["Enums"]["tiltak_status"]
          sykmelding_id: string
          tittel: string
          type: Database["public"]["Enums"]["tilretteleggingstype"]
          updated_at?: string
        }
        Update: {
          ansvarlig_id?: string | null
          beskrivelse?: string | null
          created_at?: string
          frist?: string | null
          fullfort_dato?: string | null
          id?: string
          kommentar?: string | null
          oppfolgingsplan_id?: string | null
          status?: Database["public"]["Enums"]["tiltak_status"]
          sykmelding_id?: string
          tittel?: string
          type?: Database["public"]["Enums"]["tilretteleggingstype"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "sykmelding_tiltak_ansvarlig_id_fkey"
            columns: ["ansvarlig_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykmelding_tiltak_ansvarlig_id_fkey"
            columns: ["ansvarlig_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykmelding_tiltak_ansvarlig_id_fkey"
            columns: ["ansvarlig_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykmelding_tiltak_oppfolgingsplan_id_fkey"
            columns: ["oppfolgingsplan_id"]
            isOneToOne: false
            referencedRelation: "sykmelding_oppfolgingsplaner"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykmelding_tiltak_sykmelding_id_fkey"
            columns: ["sykmelding_id"]
            isOneToOne: false
            referencedRelation: "sykemeldinger"
            referencedColumns: ["id"]
          },
        ]
      }
      sykmelding_varsler: {
        Row: {
          created_at: string
          id: string
          lest: boolean | null
          lest_dato: string | null
          mottaker_id: string
          sykmelding_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          lest?: boolean | null
          lest_dato?: string | null
          mottaker_id: string
          sykmelding_id: string
        }
        Update: {
          created_at?: string
          id?: string
          lest?: boolean | null
          lest_dato?: string | null
          mottaker_id?: string
          sykmelding_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "sykmelding_varsler_mottaker_id_fkey"
            columns: ["mottaker_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykmelding_varsler_mottaker_id_fkey"
            columns: ["mottaker_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykmelding_varsler_mottaker_id_fkey"
            columns: ["mottaker_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "sykmelding_varsler_sykmelding_id_fkey"
            columns: ["sykmelding_id"]
            isOneToOne: false
            referencedRelation: "sykemeldinger"
            referencedColumns: ["id"]
          },
        ]
      }
      system_settings: {
        Row: {
          description: string | null
          id: string
          key: string
          updated_at: string | null
          updated_by: string | null
          value: Json
        }
        Insert: {
          description?: string | null
          id?: string
          key: string
          updated_at?: string | null
          updated_by?: string | null
          value: Json
        }
        Update: {
          description?: string | null
          id?: string
          key?: string
          updated_at?: string | null
          updated_by?: string | null
          value?: Json
        }
        Relationships: [
          {
            foreignKeyName: "system_settings_updated_by_fkey"
            columns: ["updated_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "system_settings_updated_by_fkey"
            columns: ["updated_by"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "system_settings_updated_by_fkey"
            columns: ["updated_by"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      tariff_implementeringer: {
        Row: {
          created_at: string | null
          id: string
          implementert_av: string | null
          implementert_dato: string
          mal_id: string
          salon_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          implementert_av?: string | null
          implementert_dato?: string
          mal_id: string
          salon_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          implementert_av?: string | null
          implementert_dato?: string
          mal_id?: string
          salon_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "tariff_implementeringer_implementert_av_fkey"
            columns: ["implementert_av"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tariff_implementeringer_implementert_av_fkey"
            columns: ["implementert_av"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tariff_implementeringer_implementert_av_fkey"
            columns: ["implementert_av"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tariff_implementeringer_mal_id_fkey"
            columns: ["mal_id"]
            isOneToOne: false
            referencedRelation: "tariff_maler"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tariff_implementeringer_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
        ]
      }
      tariff_maler: {
        Row: {
          aar: number
          ansiennitet_max: number | null
          ansiennitet_min: number
          beskrivelse: string | null
          created_at: string | null
          fagbrev_status: Database["public"]["Enums"]["fagbrev_status"]
          gyldig_fra: string
          gyldig_til: string | null
          id: string
          maanedslonn: number | null
          navn: string
          opprettet_av: string | null
          timesats: number
          updated_at: string | null
        }
        Insert: {
          aar: number
          ansiennitet_max?: number | null
          ansiennitet_min?: number
          beskrivelse?: string | null
          created_at?: string | null
          fagbrev_status: Database["public"]["Enums"]["fagbrev_status"]
          gyldig_fra?: string
          gyldig_til?: string | null
          id?: string
          maanedslonn?: number | null
          navn?: string
          opprettet_av?: string | null
          timesats: number
          updated_at?: string | null
        }
        Update: {
          aar?: number
          ansiennitet_max?: number | null
          ansiennitet_min?: number
          beskrivelse?: string | null
          created_at?: string | null
          fagbrev_status?: Database["public"]["Enums"]["fagbrev_status"]
          gyldig_fra?: string
          gyldig_til?: string | null
          id?: string
          maanedslonn?: number | null
          navn?: string
          opprettet_av?: string | null
          timesats?: number
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "tariff_maler_opprettet_av_fkey"
            columns: ["opprettet_av"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tariff_maler_opprettet_av_fkey"
            columns: ["opprettet_av"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tariff_maler_opprettet_av_fkey"
            columns: ["opprettet_av"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      tariff_satser: {
        Row: {
          aar: number
          ansiennitet_max: number | null
          ansiennitet_min: number
          avvik_fra_mal: number | null
          beskrivelse: string | null
          created_at: string | null
          fagbrev_status: Database["public"]["Enums"]["fagbrev_status"]
          gyldig_fra: string
          id: string
          kilde_mal_id: string | null
          maanedslonn: number | null
          opprettet_av: string | null
          salon_id: string
          timesats: number
          updated_at: string | null
        }
        Insert: {
          aar: number
          ansiennitet_max?: number | null
          ansiennitet_min?: number
          avvik_fra_mal?: number | null
          beskrivelse?: string | null
          created_at?: string | null
          fagbrev_status: Database["public"]["Enums"]["fagbrev_status"]
          gyldig_fra?: string
          id?: string
          kilde_mal_id?: string | null
          maanedslonn?: number | null
          opprettet_av?: string | null
          salon_id: string
          timesats: number
          updated_at?: string | null
        }
        Update: {
          aar?: number
          ansiennitet_max?: number | null
          ansiennitet_min?: number
          avvik_fra_mal?: number | null
          beskrivelse?: string | null
          created_at?: string | null
          fagbrev_status?: Database["public"]["Enums"]["fagbrev_status"]
          gyldig_fra?: string
          id?: string
          kilde_mal_id?: string | null
          maanedslonn?: number | null
          opprettet_av?: string | null
          salon_id?: string
          timesats?: number
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "tariff_satser_kilde_mal_id_fkey"
            columns: ["kilde_mal_id"]
            isOneToOne: false
            referencedRelation: "tariff_maler"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tariff_satser_opprettet_av_fkey"
            columns: ["opprettet_av"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tariff_satser_opprettet_av_fkey"
            columns: ["opprettet_av"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tariff_satser_opprettet_av_fkey"
            columns: ["opprettet_av"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "tariff_satser_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
        ]
      }
      thread_participants: {
        Row: {
          added_at: string | null
          archived_at: string | null
          id: string
          last_read_at: string | null
          thread_id: string
          user_id: string
        }
        Insert: {
          added_at?: string | null
          archived_at?: string | null
          id?: string
          last_read_at?: string | null
          thread_id: string
          user_id: string
        }
        Update: {
          added_at?: string | null
          archived_at?: string | null
          id?: string
          last_read_at?: string | null
          thread_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "thread_participants_thread_id_fkey"
            columns: ["thread_id"]
            isOneToOne: false
            referencedRelation: "message_threads"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "thread_participants_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "thread_participants_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "thread_participants_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      turnus_preferanser: {
        Row: {
          created_at: string | null
          gyldig_fra: string | null
          gyldig_til: string | null
          id: string
          jobber: boolean
          kan_ikke_jobbe: boolean | null
          kommentar: string | null
          onsket_slutt_tid: string | null
          onsket_start_tid: string | null
          prioritet: number | null
          salon_id: string
          turnus_type: string | null
          uke_type: string | null
          ukedag: number | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          gyldig_fra?: string | null
          gyldig_til?: string | null
          id?: string
          jobber?: boolean
          kan_ikke_jobbe?: boolean | null
          kommentar?: string | null
          onsket_slutt_tid?: string | null
          onsket_start_tid?: string | null
          prioritet?: number | null
          salon_id: string
          turnus_type?: string | null
          uke_type?: string | null
          ukedag?: number | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          gyldig_fra?: string | null
          gyldig_til?: string | null
          id?: string
          jobber?: boolean
          kan_ikke_jobbe?: boolean | null
          kommentar?: string | null
          onsket_slutt_tid?: string | null
          onsket_start_tid?: string | null
          prioritet?: number | null
          salon_id?: string
          turnus_type?: string | null
          uke_type?: string | null
          ukedag?: number | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "turnus_preferanser_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "turnus_preferanser_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "turnus_preferanser_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "turnus_preferanser_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      turnus_skift: {
        Row: {
          ansatt_id: string | null
          created_at: string | null
          dato: string
          id: string
          kilde: Database["public"]["Enums"]["skift_kilde"] | null
          notat: string | null
          salon_id: string
          slutt_tid: string | null
          start_tid: string | null
          timer_planlagt: number | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          ansatt_id?: string | null
          created_at?: string | null
          dato: string
          id?: string
          kilde?: Database["public"]["Enums"]["skift_kilde"] | null
          notat?: string | null
          salon_id: string
          slutt_tid?: string | null
          start_tid?: string | null
          timer_planlagt?: number | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          ansatt_id?: string | null
          created_at?: string | null
          dato?: string
          id?: string
          kilde?: Database["public"]["Enums"]["skift_kilde"] | null
          notat?: string | null
          salon_id?: string
          slutt_tid?: string | null
          start_tid?: string | null
          timer_planlagt?: number | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "turnus_skift_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "turnus_skift_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "turnus_skift_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_utvidet"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "turnus_skift_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "turnus_skift_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "turnus_skift_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "turnus_skift_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      user_badges: {
        Row: {
          badge_id: string | null
          earned_at: string | null
          id: string
          user_id: string | null
        }
        Insert: {
          badge_id?: string | null
          earned_at?: string | null
          id?: string
          user_id?: string | null
        }
        Update: {
          badge_id?: string | null
          earned_at?: string | null
          id?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "user_badges_badge_id_fkey"
            columns: ["badge_id"]
            isOneToOne: false
            referencedRelation: "badges"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_badges_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_badges_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_badges_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      user_chain_roles: {
        Row: {
          chain_id: string
          created_at: string | null
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          chain_id: string
          created_at?: string | null
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          chain_id?: string
          created_at?: string | null
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_chain_roles_chain_id_fkey"
            columns: ["chain_id"]
            isOneToOne: false
            referencedRelation: "chains"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_chain_roles_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_chain_roles_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_chain_roles_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      user_notification_preferences: {
        Row: {
          created_at: string | null
          email_on_new_message: boolean | null
          id: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          email_on_new_message?: boolean | null
          id?: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          email_on_new_message?: boolean | null
          id?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_notification_preferences_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_notification_preferences_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_notification_preferences_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string | null
          id: string
          role: Database["public"]["Enums"]["app_role"]
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_salon_roles: {
        Row: {
          created_at: string | null
          id: string
          role: Database["public"]["Enums"]["app_role"]
          salon_id: string
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          salon_id: string
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          salon_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_salon_roles_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_salon_roles_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_salon_roles_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "user_salon_roles_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      users: {
        Row: {
          aktiv: boolean | null
          ansettelsesdato: string | null
          avatar_url: string | null
          created_at: string | null
          district_id: string | null
          email: string
          fagbrev: boolean | null
          fagbrevdato: string | null
          fastlonn: number | null
          first_name: string | null
          fodselsdato: string | null
          frisorfunksjon: Database["public"]["Enums"]["frisorfunksjon"] | null
          gdpr_consent_given_at: string | null
          gdpr_consent_ip: string | null
          gdpr_consent_source: string | null
          helseforsikring_avtalenummer: string | null
          helseforsikring_oppsigelsesdato: string | null
          helseforsikring_oppstartsdato: string | null
          helseforsikring_personnummer: string | null
          helseforsikring_pris: number | null
          helseforsikring_status: string | null
          hubspot_contact_id: string | null
          hubspot_synced_at: string | null
          id: string
          last_login_at: string | null
          last_name: string | null
          name: string
          phone: string | null
          phone_number: string | null
          phone_verified: boolean | null
          role: Database["public"]["Enums"]["app_role"]
          salon_id: string | null
          stillingsprosent: number | null
          timesats: number | null
          updated_at: string | null
        }
        Insert: {
          aktiv?: boolean | null
          ansettelsesdato?: string | null
          avatar_url?: string | null
          created_at?: string | null
          district_id?: string | null
          email: string
          fagbrev?: boolean | null
          fagbrevdato?: string | null
          fastlonn?: number | null
          first_name?: string | null
          fodselsdato?: string | null
          frisorfunksjon?: Database["public"]["Enums"]["frisorfunksjon"] | null
          gdpr_consent_given_at?: string | null
          gdpr_consent_ip?: string | null
          gdpr_consent_source?: string | null
          helseforsikring_avtalenummer?: string | null
          helseforsikring_oppsigelsesdato?: string | null
          helseforsikring_oppstartsdato?: string | null
          helseforsikring_personnummer?: string | null
          helseforsikring_pris?: number | null
          helseforsikring_status?: string | null
          hubspot_contact_id?: string | null
          hubspot_synced_at?: string | null
          id: string
          last_login_at?: string | null
          last_name?: string | null
          name: string
          phone?: string | null
          phone_number?: string | null
          phone_verified?: boolean | null
          role: Database["public"]["Enums"]["app_role"]
          salon_id?: string | null
          stillingsprosent?: number | null
          timesats?: number | null
          updated_at?: string | null
        }
        Update: {
          aktiv?: boolean | null
          ansettelsesdato?: string | null
          avatar_url?: string | null
          created_at?: string | null
          district_id?: string | null
          email?: string
          fagbrev?: boolean | null
          fagbrevdato?: string | null
          fastlonn?: number | null
          first_name?: string | null
          fodselsdato?: string | null
          frisorfunksjon?: Database["public"]["Enums"]["frisorfunksjon"] | null
          gdpr_consent_given_at?: string | null
          gdpr_consent_ip?: string | null
          gdpr_consent_source?: string | null
          helseforsikring_avtalenummer?: string | null
          helseforsikring_oppsigelsesdato?: string | null
          helseforsikring_oppstartsdato?: string | null
          helseforsikring_personnummer?: string | null
          helseforsikring_pris?: number | null
          helseforsikring_status?: string | null
          hubspot_contact_id?: string | null
          hubspot_synced_at?: string | null
          id?: string
          last_login_at?: string | null
          last_name?: string | null
          name?: string
          phone?: string | null
          phone_number?: string | null
          phone_verified?: boolean | null
          role?: Database["public"]["Enums"]["app_role"]
          salon_id?: string | null
          stillingsprosent?: number | null
          timesats?: number | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "fk_users_salon"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "users_district_id_fkey"
            columns: ["district_id"]
            isOneToOne: false
            referencedRelation: "districts"
            referencedColumns: ["id"]
          },
        ]
      }
      weekly_kpi_inputs: {
        Row: {
          addon_count: number
          addon_revenue: number | null
          created_at: string | null
          hours_with_client: number
          hours_worked: number
          id: string
          rebooked_visits: number
          retail_revenue: number
          salon_id: string | null
          stylist_id: string | null
          submitted_at: string | null
          submitted_by_user_id: string | null
          treatment_revenue: number
          updated_at: string | null
          visit_count: number
          visits_with_addon: number
          week: number
          year: number
        }
        Insert: {
          addon_count?: number
          addon_revenue?: number | null
          created_at?: string | null
          hours_with_client?: number
          hours_worked?: number
          id?: string
          rebooked_visits?: number
          retail_revenue?: number
          salon_id?: string | null
          stylist_id?: string | null
          submitted_at?: string | null
          submitted_by_user_id?: string | null
          treatment_revenue?: number
          updated_at?: string | null
          visit_count?: number
          visits_with_addon?: number
          week: number
          year: number
        }
        Update: {
          addon_count?: number
          addon_revenue?: number | null
          created_at?: string | null
          hours_with_client?: number
          hours_worked?: number
          id?: string
          rebooked_visits?: number
          retail_revenue?: number
          salon_id?: string | null
          stylist_id?: string | null
          submitted_at?: string | null
          submitted_by_user_id?: string | null
          treatment_revenue?: number
          updated_at?: string | null
          visit_count?: number
          visits_with_addon?: number
          week?: number
          year?: number
        }
        Relationships: [
          {
            foreignKeyName: "weekly_kpi_inputs_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "weekly_kpi_inputs_stylist_id_fkey"
            columns: ["stylist_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "weekly_kpi_inputs_stylist_id_fkey"
            columns: ["stylist_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "weekly_kpi_inputs_stylist_id_fkey"
            columns: ["stylist_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "weekly_kpi_inputs_submitted_by_user_id_fkey"
            columns: ["submitted_by_user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "weekly_kpi_inputs_submitted_by_user_id_fkey"
            columns: ["submitted_by_user_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "weekly_kpi_inputs_submitted_by_user_id_fkey"
            columns: ["submitted_by_user_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
      weekly_kpis: {
        Row: {
          addon_share_percent: number
          ansatt_id: string | null
          created_at: string | null
          efficiency_percent: number
          id: string
          rebooking_percent: number
          revenue_per_customer: number
          revenue_per_hour: number
          salon_id: string | null
          stylist_id: string | null
          total_revenue: number
          updated_at: string | null
          week: number
          year: number
        }
        Insert: {
          addon_share_percent?: number
          ansatt_id?: string | null
          created_at?: string | null
          efficiency_percent?: number
          id?: string
          rebooking_percent?: number
          revenue_per_customer?: number
          revenue_per_hour?: number
          salon_id?: string | null
          stylist_id?: string | null
          total_revenue?: number
          updated_at?: string | null
          week: number
          year: number
        }
        Update: {
          addon_share_percent?: number
          ansatt_id?: string | null
          created_at?: string | null
          efficiency_percent?: number
          id?: string
          rebooking_percent?: number
          revenue_per_customer?: number
          revenue_per_hour?: number
          salon_id?: string | null
          stylist_id?: string | null
          total_revenue?: number
          updated_at?: string | null
          week?: number
          year?: number
        }
        Relationships: [
          {
            foreignKeyName: "weekly_kpis_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "weekly_kpis_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "weekly_kpis_ansatt_id_fkey"
            columns: ["ansatt_id"]
            isOneToOne: false
            referencedRelation: "ansatte_utvidet"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "weekly_kpis_salon_id_fkey"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "weekly_kpis_stylist_id_fkey"
            columns: ["stylist_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "weekly_kpis_stylist_id_fkey"
            columns: ["stylist_id"]
            isOneToOne: false
            referencedRelation: "users_minimal"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "weekly_kpis_stylist_id_fkey"
            columns: ["stylist_id"]
            isOneToOne: false
            referencedRelation: "users_safe"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      ansatte_safe: {
        Row: {
          adresse: string | null
          ansatt_dato: string | null
          arbeidsdager_pr_uke: number | null
          arbeidstid_per_uke: number | null
          arkivert_arsak: string | null
          arkivert_av: string | null
          arkivert_dato: string | null
          bankkontonummer: string | null
          beste_del_av_arbeidsdagen: string | null
          budsjett_kilde: string | null
          created_at: string | null
          effektivitet_prosent: number | null
          epost: string | null
          etternavn: string | null
          fagbrev_dato: string | null
          fastlonn: number | null
          feriekrav_kommentar: string | null
          feriekrav_timer_per_aar: number | null
          feriekrav_type_enum:
            | Database["public"]["Enums"]["feriekrav_type"]
            | null
          fodselsdato: string | null
          foretrukket_feiring: string | null
          fornavn: string | null
          frisorfunksjon: Database["public"]["Enums"]["frisorfunksjon"] | null
          helseforsikring_avtalenummer: string | null
          helseforsikring_oppsigelsesdato: string | null
          helseforsikring_oppstartsdato: string | null
          helseforsikring_pris: number | null
          helseforsikring_status: string | null
          hubspot_contact_id: string | null
          hubspot_synced_at: string | null
          id: string | null
          inkluder_i_budsjett: boolean | null
          inkluder_i_turnus: boolean | null
          kjonn: string | null
          kurs_sertifiseringer: string | null
          lederstilling: Database["public"]["Enums"]["lederstilling"] | null
          lonn_sist_justert: string | null
          lonnstype_enum: Database["public"]["Enums"]["lonnstype"] | null
          mentor_id: string | null
          motivasjon_i_jobben: string | null
          nasjonalitet: string | null
          omsetning_per_time: number | null
          oppsigelsesdato: string | null
          personnummer: string | null
          postnummer: string | null
          poststed: string | null
          profilbilde_url: string | null
          provetid_til: string | null
          provisjon_behandling_hoy_prosent: number | null
          provisjon_behandling_prosent: number | null
          provisjon_terskel: number | null
          provisjon_vare_prosent: number | null
          rebooking_prosent: number | null
          salong_id: string | null
          siste_arbeidsdag: string | null
          status: Database["public"]["Enums"]["ansatt_status"] | null
          stillingsprosent: number | null
          telefon: string | null
          timesats: number | null
          updated_at: string | null
          user_id: string | null
          utdanning_fagbrev: string | null
          varesalg_prosent: number | null
          verdier: string | null
        }
        Insert: {
          adresse?: never
          ansatt_dato?: string | null
          arbeidsdager_pr_uke?: number | null
          arbeidstid_per_uke?: number | null
          arkivert_arsak?: string | null
          arkivert_av?: string | null
          arkivert_dato?: string | null
          bankkontonummer?: never
          beste_del_av_arbeidsdagen?: string | null
          budsjett_kilde?: string | null
          created_at?: string | null
          effektivitet_prosent?: number | null
          epost?: never
          etternavn?: string | null
          fagbrev_dato?: string | null
          fastlonn?: never
          feriekrav_kommentar?: string | null
          feriekrav_timer_per_aar?: number | null
          feriekrav_type_enum?:
            | Database["public"]["Enums"]["feriekrav_type"]
            | null
          fodselsdato?: never
          foretrukket_feiring?: string | null
          fornavn?: string | null
          frisorfunksjon?: Database["public"]["Enums"]["frisorfunksjon"] | null
          helseforsikring_avtalenummer?: never
          helseforsikring_oppsigelsesdato?: never
          helseforsikring_oppstartsdato?: never
          helseforsikring_pris?: never
          helseforsikring_status?: never
          hubspot_contact_id?: string | null
          hubspot_synced_at?: string | null
          id?: string | null
          inkluder_i_budsjett?: boolean | null
          inkluder_i_turnus?: boolean | null
          kjonn?: string | null
          kurs_sertifiseringer?: string | null
          lederstilling?: Database["public"]["Enums"]["lederstilling"] | null
          lonn_sist_justert?: string | null
          lonnstype_enum?: never
          mentor_id?: string | null
          motivasjon_i_jobben?: string | null
          nasjonalitet?: string | null
          omsetning_per_time?: number | null
          oppsigelsesdato?: string | null
          personnummer?: never
          postnummer?: never
          poststed?: never
          profilbilde_url?: string | null
          provetid_til?: string | null
          provisjon_behandling_hoy_prosent?: never
          provisjon_behandling_prosent?: never
          provisjon_terskel?: never
          provisjon_vare_prosent?: never
          rebooking_prosent?: number | null
          salong_id?: string | null
          siste_arbeidsdag?: string | null
          status?: Database["public"]["Enums"]["ansatt_status"] | null
          stillingsprosent?: number | null
          telefon?: never
          timesats?: never
          updated_at?: string | null
          user_id?: string | null
          utdanning_fagbrev?: string | null
          varesalg_prosent?: number | null
          verdier?: string | null
        }
        Update: {
          adresse?: never
          ansatt_dato?: string | null
          arbeidsdager_pr_uke?: number | null
          arbeidstid_per_uke?: number | null
          arkivert_arsak?: string | null
          arkivert_av?: string | null
          arkivert_dato?: string | null
          bankkontonummer?: never
          beste_del_av_arbeidsdagen?: string | null
          budsjett_kilde?: string | null
          created_at?: string | null
          effektivitet_prosent?: number | null
          epost?: never
          etternavn?: string | null
          fagbrev_dato?: string | null
          fastlonn?: never
          feriekrav_kommentar?: string | null
          feriekrav_timer_per_aar?: number | null
          feriekrav_type_enum?:
            | Database["public"]["Enums"]["feriekrav_type"]
            | null
          fodselsdato?: never
          foretrukket_feiring?: string | null
          fornavn?: string | null
          frisorfunksjon?: Database["public"]["Enums"]["frisorfunksjon"] | null
          helseforsikring_avtalenummer?: never
          helseforsikring_oppsigelsesdato?: never
          helseforsikring_oppstartsdato?: never
          helseforsikring_pris?: never
          helseforsikring_status?: never
          hubspot_contact_id?: string | null
          hubspot_synced_at?: string | null
          id?: string | null
          inkluder_i_budsjett?: boolean | null
          inkluder_i_turnus?: boolean | null
          kjonn?: string | null
          kurs_sertifiseringer?: string | null
          lederstilling?: Database["public"]["Enums"]["lederstilling"] | null
          lonn_sist_justert?: string | null
          lonnstype_enum?: never
          mentor_id?: string | null
          motivasjon_i_jobben?: string | null
          nasjonalitet?: string | null
          omsetning_per_time?: number | null
          oppsigelsesdato?: string | null
          personnummer?: never
          postnummer?: never
          poststed?: never
          profilbilde_url?: string | null
          provetid_til?: string | null
          provisjon_behandling_hoy_prosent?: never
          provisjon_behandling_prosent?: never
          provisjon_terskel?: never
          provisjon_vare_prosent?: never
          rebooking_prosent?: number | null
          salong_id?: string | null
          siste_arbeidsdag?: string | null
          status?: Database["public"]["Enums"]["ansatt_status"] | null
          stillingsprosent?: number | null
          telefon?: never
          timesats?: never
          updated_at?: string | null
          user_id?: string | null
          utdanning_fagbrev?: string | null
          varesalg_prosent?: number | null
          verdier?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "ansatte_salong_id_fkey"
            columns: ["salong_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_ansatte_mentor"
            columns: ["mentor_id"]
            isOneToOne: false
            referencedRelation: "ansatte"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_ansatte_mentor"
            columns: ["mentor_id"]
            isOneToOne: false
            referencedRelation: "ansatte_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_ansatte_mentor"
            columns: ["mentor_id"]
            isOneToOne: false
            referencedRelation: "ansatte_utvidet"
            referencedColumns: ["id"]
          },
        ]
      }
      ansatte_utvidet: {
        Row: {
          adresse: string | null
          alder: number | null
          ansatt_dato: string | null
          ansiennitet_aar: number | null
          ansiennitet_maneder: number | null
          arbeidsdager_pr_uke: number | null
          arbeidstid_per_uke: number | null
          arkivert_arsak: string | null
          arkivert_av: string | null
          arkivert_dato: string | null
          bankkontonummer: string | null
          beste_del_av_arbeidsdagen: string | null
          budsjett_kilde: string | null
          bursdag_md: string | null
          created_at: string | null
          dager_til_provetid_slutt: number | null
          effektiv_inkluder_i_budsjett: boolean | null
          effektiv_inkluder_i_turnus: boolean | null
          effektivitet_prosent: number | null
          epost: string | null
          etternavn: string | null
          fagbrev_dato: string | null
          fastlonn: number | null
          feriekrav_kommentar: string | null
          feriekrav_timer_per_aar: number | null
          feriekrav_type_enum:
            | Database["public"]["Enums"]["feriekrav_type"]
            | null
          fodselsdato: string | null
          foretrukket_feiring: string | null
          fornavn: string | null
          frisorfunksjon: Database["public"]["Enums"]["frisorfunksjon"] | null
          frisorfunksjon_display: string | null
          helseforsikring_avtalenummer: string | null
          helseforsikring_oppsigelsesdato: string | null
          helseforsikring_oppstartsdato: string | null
          helseforsikring_pris: number | null
          helseforsikring_status: string | null
          hubspot_contact_id: string | null
          hubspot_synced_at: string | null
          i_provetid: boolean | null
          id: string | null
          inkluder_i_budsjett: boolean | null
          inkluder_i_turnus: boolean | null
          kjonn: string | null
          kurs_sertifiseringer: string | null
          lederstilling: Database["public"]["Enums"]["lederstilling"] | null
          lederstilling_display: string | null
          lonn_sist_justert: string | null
          lonnstype_enum: Database["public"]["Enums"]["lonnstype"] | null
          mentor_id: string | null
          motivasjon_i_jobben: string | null
          nasjonalitet: string | null
          navn: string | null
          omsetning_per_time: number | null
          oppsigelsesdato: string | null
          personnummer: string | null
          postnummer: string | null
          poststed: string | null
          profilbilde_url: string | null
          provetid_til: string | null
          provisjon_behandling_hoy_prosent: number | null
          provisjon_behandling_prosent: number | null
          provisjon_terskel: number | null
          provisjon_vare_prosent: number | null
          rebooking_prosent: number | null
          rolle_display: string | null
          salong_id: string | null
          salong_navn: string | null
          siste_arbeidsdag: string | null
          status: Database["public"]["Enums"]["ansatt_status"] | null
          status_display: string | null
          stillingsprosent: number | null
          telefon: string | null
          timesats: number | null
          updated_at: string | null
          user_id: string | null
          utdanning_fagbrev: string | null
          varesalg_prosent: number | null
          verdier: string | null
        }
        Relationships: [
          {
            foreignKeyName: "ansatte_salong_id_fkey"
            columns: ["salong_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_ansatte_mentor"
            columns: ["mentor_id"]
            isOneToOne: false
            referencedRelation: "ansatte"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_ansatte_mentor"
            columns: ["mentor_id"]
            isOneToOne: false
            referencedRelation: "ansatte_safe"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_ansatte_mentor"
            columns: ["mentor_id"]
            isOneToOne: false
            referencedRelation: "ansatte_utvidet"
            referencedColumns: ["id"]
          },
        ]
      }
      users_minimal: {
        Row: {
          aktiv: boolean | null
          avatar_url: string | null
          first_name: string | null
          id: string | null
          last_name: string | null
          name: string | null
          role: Database["public"]["Enums"]["app_role"] | null
          salon_id: string | null
        }
        Insert: {
          aktiv?: boolean | null
          avatar_url?: string | null
          first_name?: string | null
          id?: string | null
          last_name?: string | null
          name?: string | null
          role?: Database["public"]["Enums"]["app_role"] | null
          salon_id?: string | null
        }
        Update: {
          aktiv?: boolean | null
          avatar_url?: string | null
          first_name?: string | null
          id?: string | null
          last_name?: string | null
          name?: string | null
          role?: Database["public"]["Enums"]["app_role"] | null
          salon_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "fk_users_salon"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
        ]
      }
      users_safe: {
        Row: {
          aktiv: boolean | null
          ansettelsesdato: string | null
          avatar_url: string | null
          created_at: string | null
          district_id: string | null
          email: string | null
          fagbrev: boolean | null
          fagbrevdato: string | null
          fastlonn: number | null
          first_name: string | null
          fodselsdato: string | null
          frisorfunksjon: Database["public"]["Enums"]["frisorfunksjon"] | null
          helseforsikring_avtalenummer: string | null
          helseforsikring_oppsigelsesdato: string | null
          helseforsikring_oppstartsdato: string | null
          helseforsikring_personnummer: string | null
          helseforsikring_pris: number | null
          helseforsikring_status: string | null
          id: string | null
          last_name: string | null
          name: string | null
          phone: string | null
          role: Database["public"]["Enums"]["app_role"] | null
          salon_id: string | null
          stillingsprosent: number | null
          timesats: number | null
          updated_at: string | null
        }
        Insert: {
          aktiv?: boolean | null
          ansettelsesdato?: string | null
          avatar_url?: string | null
          created_at?: string | null
          district_id?: string | null
          email?: never
          fagbrev?: boolean | null
          fagbrevdato?: string | null
          fastlonn?: never
          first_name?: string | null
          fodselsdato?: never
          frisorfunksjon?: Database["public"]["Enums"]["frisorfunksjon"] | null
          helseforsikring_avtalenummer?: never
          helseforsikring_oppsigelsesdato?: never
          helseforsikring_oppstartsdato?: never
          helseforsikring_personnummer?: never
          helseforsikring_pris?: never
          helseforsikring_status?: never
          id?: string | null
          last_name?: string | null
          name?: string | null
          phone?: never
          role?: Database["public"]["Enums"]["app_role"] | null
          salon_id?: string | null
          stillingsprosent?: number | null
          timesats?: never
          updated_at?: string | null
        }
        Update: {
          aktiv?: boolean | null
          ansettelsesdato?: string | null
          avatar_url?: string | null
          created_at?: string | null
          district_id?: string | null
          email?: never
          fagbrev?: boolean | null
          fagbrevdato?: string | null
          fastlonn?: never
          first_name?: string | null
          fodselsdato?: never
          frisorfunksjon?: Database["public"]["Enums"]["frisorfunksjon"] | null
          helseforsikring_avtalenummer?: never
          helseforsikring_oppsigelsesdato?: never
          helseforsikring_oppstartsdato?: never
          helseforsikring_personnummer?: never
          helseforsikring_pris?: never
          helseforsikring_status?: never
          id?: string | null
          last_name?: string | null
          name?: string | null
          phone?: never
          role?: Database["public"]["Enums"]["app_role"] | null
          salon_id?: string | null
          stillingsprosent?: number | null
          timesats?: never
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "fk_users_salon"
            columns: ["salon_id"]
            isOneToOne: false
            referencedRelation: "salons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "users_district_id_fkey"
            columns: ["district_id"]
            isOneToOne: false
            referencedRelation: "districts"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Functions: {
      beregn_daglig_budsjett: {
        Args: {
          p_dato: string
          p_effektivitet: number
          p_omsetning_per_time: number
          p_user_id: string
          p_varesalg_prosent: number
        }
        Returns: {
          behandling: number
          kundetimer: number
          total: number
          vare: number
        }[]
      }
      beregn_ferietimer: {
        Args: { p_sluttdato: string; p_startdato: string; p_user_id: string }
        Returns: number
      }
      beregn_maanedslonn: {
        Args: { p_stillingsprosent?: number; p_timesats: number }
        Returns: number
      }
      beregn_uke_type: {
        Args: { p_dato: string; p_gyldig_fra: string; p_turnus_type: string }
        Returns: string
      }
      calculate_cumulative_delta: {
        Args: {
          p_cumulative_value: number
          p_period: string
          p_salon_id: string
          p_supplier_id: string
        }
        Returns: number
      }
      create_user_role_for_onboarding: {
        Args: {
          p_role: Database["public"]["Enums"]["app_role"]
          p_user_id: string
        }
        Returns: undefined
      }
      er_helligdag_dato: { Args: { p_dato: string }; Returns: boolean }
      er_salong_apen: {
        Args: { p_dato: string; p_salon_id: string }
        Returns: boolean
      }
      get_aggregated_bonus_calculations: {
        Args: {
          p_district_id?: string
          p_end_period: string
          p_start_period: string
          p_supplier_id?: string
        }
        Returns: {
          calculation_details: Json
          calculation_ids: string[]
          loyalty_bonus_amount: number
          periods: string[]
          return_commission_amount: number
          salon_district_id: string
          salon_id: string
          salon_medlemsnummer: string
          salon_name: string
          supplier_id: string
          supplier_name: string
          total_bonus: number
          total_turnover: number
          worst_status: string
        }[]
      }
      get_aktiv_budsjett_versjon: {
        Args: { p_aar: number; p_salon_id: string }
        Returns: string
      }
      get_alder: { Args: { p_user_id: string }; Returns: number }
      get_ansatt_id_for_user: { Args: { _user_id: string }; Returns: string }
      get_ansiennitet_aar: { Args: { p_user_id: string }; Returns: number }
      get_arbeidsdager_i_periode: {
        Args: { p_fra: string; p_til: string }
        Returns: number
      }
      get_arbeidsdager_i_uke: {
        Args: { p_aar: number; p_uke: number }
        Returns: number
      }
      get_bonus_by_brand_for_periods:
        | {
            Args: { period_list: string[] }
            Returns: {
              brand: string
              loyalty_bonus: number
              product_group: string
              return_commission: number
              total_bonus: number
              total_turnover: number
            }[]
          }
        | {
            Args: { filter_supplier_id?: string; period_list: string[] }
            Returns: {
              brand: string
              loyalty_bonus: number
              product_group: string
              return_commission: number
              supplier_id: string
              total_bonus: number
              total_turnover: number
            }[]
          }
      get_bonus_summary_for_periods: {
        Args: { filter_supplier_id?: string; period_list: string[] }
        Returns: {
          approved_count: number
          calculated_count: number
          loyalty_bonus: number
          paid_count: number
          pending_count: number
          return_commission: number
          total_bonus: number
          total_turnover: number
          unmatched_count: number
        }[]
      }
      get_budget_summary: {
        Args: {
          p_end_date?: string
          p_salon_id: string
          p_start_date?: string
          p_versjon_id: string
        }
        Returns: {
          antall_dager: number
          total_behandling: number
          total_budsjett: number
          total_kundetimer: number
          total_planlagte_timer: number
          total_vare: number
        }[]
      }
      get_budget_vs_actual: {
        Args: {
          p_month: number
          p_salon_id: string
          p_versjon_id: string
          p_year: number
        }
        Returns: {
          avvik_behandling: number
          avvik_total: number
          avvik_vare: number
          budsjett_behandling: number
          budsjett_total: number
          budsjett_vare: number
          faktisk_behandling: number
          faktisk_total: number
          faktisk_vare: number
          oppnaaelse_prosent: number
          user_id: string
          user_name: string
        }[]
      }
      get_district_id_from_owner: {
        Args: { p_hubspot_owner_id: string }
        Returns: string
      }
      get_district_manager_from_owner: {
        Args: { p_hubspot_owner_id: string }
        Returns: string
      }
      get_district_name_from_owner: {
        Args: { p_hubspot_owner_id: string }
        Returns: string
      }
      get_district_salon_ids: { Args: { _user_id: string }; Returns: string[] }
      get_foreslatte_tiltak: {
        Args: {
          p_score: number
          p_tema: Database["public"]["Enums"]["puls_tema"]
        }
        Returns: string[]
      }
      get_goal_progress: {
        Args: { p_active_only?: boolean; p_user_id: string }
        Returns: {
          current_value: number
          goal_description: string
          goal_id: string
          goal_type: string
          periode_slutt: string
          periode_start: string
          progress_percent: number
          status: string
          target_value: number
        }[]
      }
      get_helseforsikring_personnummer: {
        Args: { p_user_id: string }
        Returns: string
      }
      get_invitation_by_token: {
        Args: { _token: string }
        Returns: {
          accepted: boolean
          created_at: string
          district_id: string
          email: string
          expires_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          salon_id: string
          supplier_id: string
          token: string
        }[]
      }
      get_konfidensielle_notater: {
        Args: { p_samtale_id: string }
        Returns: string
      }
      get_salon_supplier_user_ids: {
        Args: { _salon_id: string }
        Returns: string[]
      }
      get_shift_hours_summary: {
        Args: { p_end_date: string; p_start_date: string; p_user_id: string }
        Returns: {
          avg_hours_per_shift: number
          days_worked: number
          total_planned_hours: number
          total_shifts: number
        }[]
      }
      get_supplier_salon_ids: { Args: { _user_id: string }; Returns: string[] }
      get_thread_participant_user_ids: {
        Args: { p_user_id: string }
        Returns: string[]
      }
      get_turnus_stillingsprosent: {
        Args: { p_salon_id: string; p_user_id: string }
        Returns: {
          gjennomsnittlig_timer: number
          stillingsprosent: number
          turnus_type: string
          uker_detaljer: Json
        }[]
      }
      get_turnus_timer_for_dag: {
        Args: { p_dato: string; p_user_id: string }
        Returns: number
      }
      get_user_accessible_salon_ids: {
        Args: { _user_id: string }
        Returns: string[]
      }
      get_user_chain_ids: { Args: { _user_id: string }; Returns: string[] }
      get_user_district_id: { Args: { _user_id: string }; Returns: string }
      get_user_role: {
        Args: { user_uuid: string }
        Returns: Database["public"]["Enums"]["app_role"]
      }
      get_user_role_from_users: {
        Args: { _user_id: string }
        Returns: Database["public"]["Enums"]["app_role"]
      }
      get_user_salon_id: { Args: { _user_id: string }; Returns: string }
      get_user_supplier_id: { Args: { _user_id: string }; Returns: string }
      get_user_with_masked_sensitive_data: {
        Args: { target_user_id: string }
        Returns: {
          aktiv: boolean
          ansettelsesdato: string
          avatar_url: string
          created_at: string
          district_id: string
          email: string
          fagbrev: boolean
          fagbrevdato: string
          fastlonn: number
          first_name: string
          fodselsdato: string
          frisorfunksjon: Database["public"]["Enums"]["frisorfunksjon"]
          helseforsikring_avtalenummer: string
          helseforsikring_oppsigelsesdato: string
          helseforsikring_oppstartsdato: string
          helseforsikring_personnummer: string
          helseforsikring_pris: number
          helseforsikring_status: string
          id: string
          last_name: string
          name: string
          phone: string
          role: Database["public"]["Enums"]["app_role"]
          salon_id: string
          stillingsprosent: number
          timesats: number
          updated_at: string
        }[]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      has_salon_access: {
        Args: { _salon_id: string; _user_id: string }
        Returns: boolean
      }
      has_salong_access: {
        Args: { _salong_id: string; _user_id: string }
        Returns: boolean
      }
      hent_bemanning_for_time: {
        Args: { p_dato: string; p_salon_id: string; p_time: number }
        Returns: number
      }
      is_admin_or_manager: { Args: { p_user_id: string }; Returns: boolean }
      is_chain_owner: {
        Args: { _chain_id: string; _user_id: string }
        Returns: boolean
      }
      is_salon_leader: { Args: { _user_id: string }; Returns: boolean }
      is_salon_owner: { Args: { _user_id: string }; Returns: boolean }
      is_salong_leder: {
        Args: { _salong_id: string; _user_id: string }
        Returns: boolean
      }
      is_supplier_admin: {
        Args: { _supplier_id: string; _user_id: string }
        Returns: boolean
      }
      is_thread_participant: {
        Args: { _thread_id: string; _user_id: string }
        Returns: boolean
      }
      valider_egenmelding: {
        Args: { p_sluttdato: string; p_startdato: string; p_user_id: string }
        Returns: boolean
      }
    }
    Enums: {
      ansatt_prosess_type: "onboarding" | "offboarding"
      ansatt_status: "Aktiv" | "Permisjon" | "Arkivert"
      app_role:
        | "admin"
        | "district_manager"
        | "salon_owner"
        | "stylist"
        | "apprentice"
        | "supplier_admin"
        | "supplier_sales"
        | "supplier_business_dev"
        | "daglig_leder"
        | "avdelingsleder"
        | "styreleder"
        | "chain_owner"
        | "seniorfrisor"
      avtale_signerings_status:
        | "utkast"
        | "sendt"
        | "apnet"
        | "signert"
        | "fullfort"
        | "avvist"
        | "utlopt"
      bonus_calculation_status:
        | "pending"
        | "calculated"
        | "approved"
        | "paid"
        | "unmatched"
      bonus_rule_type: "loyalty" | "return" | "combined"
      budsjett_arsak_null:
        | "helg"
        | "helligdag"
        | "ferie"
        | "salong_stengt"
        | "turnus_fridag"
        | "permisjon"
        | "annet"
        | "manuelt"
      budsjett_stillingsprosent_kilde: "ansatt" | "turnus"
      crm_aktivitet_type: "notat" | "oppgave" | "mote" | "telefon" | "epost"
      dialogmote_status: "planlagt" | "gjennomfort" | "utsatt" | "avlyst"
      dialogmote_type: "dialogmote_1" | "dialogmote_2" | "dialogmote_3"
      fagbrev_status: "uten_fagbrev" | "med_fagbrev" | "mester"
      ferie_status:
        | "estimat"
        | "søknad"
        | "planlagt"
        | "godkjent"
        | "avslatt"
        | "avviklet"
      feriekrav_type: "lovfestet" | "tariffavtale" | "utvidet"
      fravaerstype:
        | "egenmelding"
        | "sykmelding"
        | "lege_helse"
        | "velferdspermisjon"
        | "foreldrepermisjon"
        | "ulonnet_permisjon"
        | "annet"
      frisorfunksjon: "frisor" | "senior_frisor" | "laerling"
      import_match_status: "matched" | "unmatched" | "error" | "manual_override"
      insurance_order_status:
        | "draft"
        | "pending_approval"
        | "approved"
        | "rejected"
        | "sent_to_frende"
        | "completed"
        | "cancelled"
        | "invoiced"
        | "registered"
      insurance_order_type: "new" | "change" | "cancellation"
      insurance_price_model: "fast" | "per_arsverk" | "per_person"
      insurance_product_type:
        | "salong"
        | "yrkesskade"
        | "cyber"
        | "reise"
        | "fritidsulykke"
        | "helse"
      insurance_quote_status:
        | "draft"
        | "sent"
        | "accepted"
        | "expired"
        | "completed"
        | "withdrawn"
      lederstilling: "daglig_leder" | "avdelingsleder" | "styreleder"
      lonnstype: "timelonn" | "fastlonn" | "provisjon" | "timelonn_provisjon"
      medlemsstatus_enum:
        | "utkast"
        | "venter_signering"
        | "aktiv"
        | "pause"
        | "oppsigelse"
        | "avsluttet"
      merke_kategori: "kjemi" | "produkt" | "begge"
      produkttype: "kjemi" | "produkt" | "begge"
      prospekt_pipeline_status:
        | "identifisert"
        | "kontaktet"
        | "forste_mote"
        | "pagaende_dialog"
        | "forhandling"
        | "klar_for_innmelding"
        | "vunnet"
        | "tapt"
      prospekt_sannsynlighet: "lav" | "medium" | "stor"
      puls_sporsmal_type: "skala" | "fritekst"
      puls_tema:
        | "trivsel"
        | "arbeidsbelastning"
        | "psykologisk_trygghet"
        | "ledelse"
        | "hms_sikkerhet"
        | "utvikling"
      puls_type: "hurtigpuls" | "dyppuls"
      rapporteringstype: "kjemi" | "produkt" | "samlet" | "begge_separat"
      sertifisering_type_v2:
        | "fagbrev"
        | "kurs"
        | "sertifisering"
        | "godkjenning"
      signatur_status: "ikke_pakrevd" | "venter_signatur" | "signert" | "avvist"
      sjekkliste_oppgave_status:
        | "ikke_startet"
        | "pagar"
        | "fullfort"
        | "hoppet_over"
      skift_kilde: "turnus" | "manuell" | "bytte" | "ferie" | "fravaer"
      sykmelding_fase: "tidlig" | "aktiv" | "midt" | "sen"
      sykmelding_status: "aktiv" | "avsluttet" | "avbrutt"
      tilretteleggingstype: "fysisk" | "organisatorisk" | "sosial" | "teknisk"
      tiltak_status: "planlagt" | "igang" | "fullfort" | "avbrutt"
      turnus_uke_type:
        | "alle"
        | "partall"
        | "oddetall"
        | "uke1"
        | "uke2"
        | "uke3"
        | "uke4"
      type_medlemskap: "salong" | "skole" | "stol" | "hjemmesalong" | "barber"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      ansatt_prosess_type: ["onboarding", "offboarding"],
      ansatt_status: ["Aktiv", "Permisjon", "Arkivert"],
      app_role: [
        "admin",
        "district_manager",
        "salon_owner",
        "stylist",
        "apprentice",
        "supplier_admin",
        "supplier_sales",
        "supplier_business_dev",
        "daglig_leder",
        "avdelingsleder",
        "styreleder",
        "chain_owner",
        "seniorfrisor",
      ],
      avtale_signerings_status: [
        "utkast",
        "sendt",
        "apnet",
        "signert",
        "fullfort",
        "avvist",
        "utlopt",
      ],
      bonus_calculation_status: [
        "pending",
        "calculated",
        "approved",
        "paid",
        "unmatched",
      ],
      bonus_rule_type: ["loyalty", "return", "combined"],
      budsjett_arsak_null: [
        "helg",
        "helligdag",
        "ferie",
        "salong_stengt",
        "turnus_fridag",
        "permisjon",
        "annet",
        "manuelt",
      ],
      budsjett_stillingsprosent_kilde: ["ansatt", "turnus"],
      crm_aktivitet_type: ["notat", "oppgave", "mote", "telefon", "epost"],
      dialogmote_status: ["planlagt", "gjennomfort", "utsatt", "avlyst"],
      dialogmote_type: ["dialogmote_1", "dialogmote_2", "dialogmote_3"],
      fagbrev_status: ["uten_fagbrev", "med_fagbrev", "mester"],
      ferie_status: [
        "estimat",
        "søknad",
        "planlagt",
        "godkjent",
        "avslatt",
        "avviklet",
      ],
      feriekrav_type: ["lovfestet", "tariffavtale", "utvidet"],
      fravaerstype: [
        "egenmelding",
        "sykmelding",
        "lege_helse",
        "velferdspermisjon",
        "foreldrepermisjon",
        "ulonnet_permisjon",
        "annet",
      ],
      frisorfunksjon: ["frisor", "senior_frisor", "laerling"],
      import_match_status: ["matched", "unmatched", "error", "manual_override"],
      insurance_order_status: [
        "draft",
        "pending_approval",
        "approved",
        "rejected",
        "sent_to_frende",
        "completed",
        "cancelled",
        "invoiced",
        "registered",
      ],
      insurance_order_type: ["new", "change", "cancellation"],
      insurance_price_model: ["fast", "per_arsverk", "per_person"],
      insurance_product_type: [
        "salong",
        "yrkesskade",
        "cyber",
        "reise",
        "fritidsulykke",
        "helse",
      ],
      insurance_quote_status: [
        "draft",
        "sent",
        "accepted",
        "expired",
        "completed",
        "withdrawn",
      ],
      lederstilling: ["daglig_leder", "avdelingsleder", "styreleder"],
      lonnstype: ["timelonn", "fastlonn", "provisjon", "timelonn_provisjon"],
      medlemsstatus_enum: [
        "utkast",
        "venter_signering",
        "aktiv",
        "pause",
        "oppsigelse",
        "avsluttet",
      ],
      merke_kategori: ["kjemi", "produkt", "begge"],
      produkttype: ["kjemi", "produkt", "begge"],
      prospekt_pipeline_status: [
        "identifisert",
        "kontaktet",
        "forste_mote",
        "pagaende_dialog",
        "forhandling",
        "klar_for_innmelding",
        "vunnet",
        "tapt",
      ],
      prospekt_sannsynlighet: ["lav", "medium", "stor"],
      puls_sporsmal_type: ["skala", "fritekst"],
      puls_tema: [
        "trivsel",
        "arbeidsbelastning",
        "psykologisk_trygghet",
        "ledelse",
        "hms_sikkerhet",
        "utvikling",
      ],
      puls_type: ["hurtigpuls", "dyppuls"],
      rapporteringstype: ["kjemi", "produkt", "samlet", "begge_separat"],
      sertifisering_type_v2: [
        "fagbrev",
        "kurs",
        "sertifisering",
        "godkjenning",
      ],
      signatur_status: ["ikke_pakrevd", "venter_signatur", "signert", "avvist"],
      sjekkliste_oppgave_status: [
        "ikke_startet",
        "pagar",
        "fullfort",
        "hoppet_over",
      ],
      skift_kilde: ["turnus", "manuell", "bytte", "ferie", "fravaer"],
      sykmelding_fase: ["tidlig", "aktiv", "midt", "sen"],
      sykmelding_status: ["aktiv", "avsluttet", "avbrutt"],
      tilretteleggingstype: ["fysisk", "organisatorisk", "sosial", "teknisk"],
      tiltak_status: ["planlagt", "igang", "fullfort", "avbrutt"],
      turnus_uke_type: [
        "alle",
        "partall",
        "oddetall",
        "uke1",
        "uke2",
        "uke3",
        "uke4",
      ],
      type_medlemskap: ["salong", "skole", "stol", "hjemmesalong", "barber"],
    },
  },
} as const
