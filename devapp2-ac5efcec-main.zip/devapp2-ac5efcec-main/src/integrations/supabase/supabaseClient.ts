// Re-export the supabase client from the main client file
// This provides a named export that matches the problem statement requirements
// while maintaining compatibility with the existing client

export { supabase } from './client';
export type { Database } from './types';
