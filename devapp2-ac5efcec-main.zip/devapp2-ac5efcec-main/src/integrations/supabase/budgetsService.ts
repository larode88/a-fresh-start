// Budgets Service
// Provides typed CRUD operations for budget management

import { supabase } from './supabaseClient';
import type { Database } from './types';

type Budget = Database['public']['Tables']['budsjett']['Row'];
type BudgetInsert = Database['public']['Tables']['budsjett']['Insert'];
type BudgetUpdate = Database['public']['Tables']['budsjett']['Update'];
type BudgetVersion = Database['public']['Tables']['budsjett_versjoner']['Row'];

export interface BudgetWithEmployee extends Budget {
  ansatte?: {
    id: string;
    fornavn: string;
    etternavn: string | null;
  } | null;
}

/**
 * Get budgets for a salon and version
 * Uses pagination to bypass Supabase 1000-row default limit
 */
export async function getBudgetsBySalon(
  salonId: string,
  versionId: string
): Promise<BudgetWithEmployee[]> {
  const PAGE_SIZE = 1000;
  let allData: BudgetWithEmployee[] = [];
  let page = 0;
  let hasMore = true;

  while (hasMore) {
    const from = page * PAGE_SIZE;
    const to = from + PAGE_SIZE - 1;

    const { data, error } = await supabase
      .from('budsjett')
      .select(`
        *,
        ansatte:ansatt_id (
          id,
          fornavn,
          etternavn
        )
      `)
      .eq('salon_id', salonId)
      .eq('versjon_id', versionId)
      .order('dato')
      .range(from, to);

    if (error) {
      throw new Error(`Failed to fetch budgets: ${error.message}`);
    }

    if (data && data.length > 0) {
      allData = [...allData, ...data];
      hasMore = data.length === PAGE_SIZE;
      page++;
    } else {
      hasMore = false;
    }
  }

  console.log(`[budgetsService] getBudgetsBySalon: fetched ${allData.length} rows (paginated) for salon ${salonId}, version ${versionId}`);

  return allData;
}

/**
 * Get budgets for a specific employee
 */
export async function getBudgetsByEmployee(
  ansattId: string,
  versionId: string,
  startDate?: string,
  endDate?: string
): Promise<Budget[]> {
  let query = supabase
    .from('budsjett')
    .select('*')
    .eq('ansatt_id', ansattId)
    .eq('versjon_id', versionId);

  if (startDate) {
    query = query.gte('dato', startDate);
  }
  if (endDate) {
    query = query.lte('dato', endDate);
  }

  const { data, error } = await query.order('dato');

  if (error) {
    throw new Error(`Failed to fetch employee budgets: ${error.message}`);
  }

  return data || [];
}

/**
 * Create a new budget item
 */
export async function addBudgetItem(budget: BudgetInsert): Promise<Budget> {
  const { data, error } = await supabase
    .from('budsjett')
    .insert(budget)
    .select()
    .single();

  if (error) {
    throw new Error(`Failed to create budget item: ${error.message}`);
  }

  return data;
}

/**
 * Update an existing budget item
 */
export async function updateBudgetItem(
  budgetId: string,
  updates: BudgetUpdate
): Promise<Budget> {
  const { data, error } = await supabase
    .from('budsjett')
    .update(updates)
    .eq('id', budgetId)
    .select()
    .single();

  if (error) {
    throw new Error(`Failed to update budget item: ${error.message}`);
  }

  return data;
}

/**
 * Delete a budget item
 */
export async function deleteBudgetItem(budgetId: string): Promise<void> {
  const { error } = await supabase
    .from('budsjett')
    .delete()
    .eq('id', budgetId);

  if (error) {
    throw new Error(`Failed to delete budget item: ${error.message}`);
  }
}

/**
 * Get budget summary using RPC function
 */
export async function getBudgetSummary(
  salonId: string,
  versionId: string,
  startDate?: string,
  endDate?: string
): Promise<{
  total_behandling: number;
  total_vare: number;
  total_budsjett: number;
  total_kundetimer: number;
  total_planlagte_timer: number;
  antall_dager: number;
}> {
  const { data, error } = await supabase.rpc('get_budget_summary', {
    p_salon_id: salonId,
    p_versjon_id: versionId,
    p_start_date: startDate || null,
    p_end_date: endDate || null,
  });

  if (error) {
    throw new Error(`Failed to get budget summary: ${error.message}`);
  }

  const result = Array.isArray(data) ? data[0] : data;
  
  return result || {
    total_behandling: 0,
    total_vare: 0,
    total_budsjett: 0,
    total_kundetimer: 0,
    total_planlagte_timer: 0,
    antall_dager: 0,
  };
}

/**
 * Get budget versions for a salon
 */
export async function getBudgetVersions(
  salonId: string,
  year?: number
): Promise<BudgetVersion[]> {
  let query = supabase
    .from('budsjett_versjoner')
    .select('*')
    .eq('salon_id', salonId);

  if (year) {
    query = query.eq('aar', year);
  }

  const { data, error } = await query.order('versjon_nummer', { ascending: false });

  if (error) {
    throw new Error(`Failed to fetch budget versions: ${error.message}`);
  }

  return data || [];
}

/**
 * Get active budget version for a salon and year
 */
export async function getActiveBudgetVersion(
  salonId: string,
  year: number
): Promise<BudgetVersion | null> {
  const { data, error } = await supabase
    .from('budsjett_versjoner')
    .select('*')
    .eq('salon_id', salonId)
    .eq('aar', year)
    .eq('er_aktiv', true)
    .single();

  if (error && error.code !== 'PGRST116') {
    // PGRST116 is "no rows returned" which is ok
    throw new Error(`Failed to fetch active budget version: ${error.message}`);
  }

  return data;
}

/**
 * Get budget vs actual comparison using RPC
 */
export async function getBudgetVsActual(
  salonId: string,
  versionId: string,
  month: number,
  year: number
): Promise<{
  user_id: string;
  user_name: string;
  budsjett_behandling: number;
  budsjett_vare: number;
  budsjett_total: number;
  faktisk_behandling: number;
  faktisk_vare: number;
  faktisk_total: number;
  avvik_behandling: number;
  avvik_vare: number;
  avvik_total: number;
  oppnaaelse_prosent: number;
}[]> {
  const { data, error } = await supabase.rpc('get_budget_vs_actual', {
    p_salon_id: salonId,
    p_versjon_id: versionId,
    p_month: month,
    p_year: year,
  });

  if (error) {
    throw new Error(`Failed to get budget vs actual: ${error.message}`);
  }

  return (data || []) as {
    user_id: string;
    user_name: string;
    budsjett_behandling: number;
    budsjett_vare: number;
    budsjett_total: number;
    faktisk_behandling: number;
    faktisk_vare: number;
    faktisk_total: number;
    avvik_behandling: number;
    avvik_vare: number;
    avvik_total: number;
    oppnaaelse_prosent: number;
  }[];
}

// ============================================
// Manual Budget Functions (for employees without schedule)
// ============================================

export interface ManualBudget {
  id: string;
  versjon_id: string;
  salon_id: string;
  ansatt_id: string;
  maned: number;
  vare_budsjett: number;
  behandling_budsjett: number;
  beskrivelse: string | null;
  created_at: string;
  updated_at: string;
}

export interface ManualBudgetWithEmployee extends ManualBudget {
  ansatte?: {
    id: string;
    fornavn: string;
    etternavn: string | null;
  } | null;
}

/**
 * Get manual budgets for a salon and version
 */
export async function getManualBudgets(
  salonId: string,
  versionId: string
): Promise<ManualBudgetWithEmployee[]> {
  const { data, error } = await supabase
    .from('budsjett_manuelt')
    .select(`
      *,
      ansatte:ansatt_id (
        id,
        fornavn,
        etternavn
      )
    `)
    .eq('salon_id', salonId)
    .eq('versjon_id', versionId)
    .order('maned');

  if (error) {
    throw new Error(`Failed to fetch manual budgets: ${error.message}`);
  }

  return (data || []) as ManualBudgetWithEmployee[];
}

/**
 * Upsert a manual budget entry
 */
export async function upsertManualBudget(
  data: {
    versjon_id: string;
    salon_id: string;
    ansatt_id: string;
    maned: number;
    vare_budsjett: number;
    behandling_budsjett: number;
    beskrivelse?: string | null;
  }
): Promise<ManualBudget> {
  const { data: result, error } = await supabase
    .from('budsjett_manuelt')
    .upsert(data, {
      onConflict: 'versjon_id,ansatt_id,maned',
    })
    .select()
    .single();

  if (error) {
    throw new Error(`Failed to upsert manual budget: ${error.message}`);
  }

  return result as ManualBudget;
}

/**
 * Bulk upsert manual budgets for an employee (all 12 months)
 */
export async function bulkUpsertManualBudgets(
  entries: {
    versjon_id: string;
    salon_id: string;
    ansatt_id: string;
    maned: number;
    vare_budsjett: number;
    behandling_budsjett: number;
  }[]
): Promise<void> {
  if (entries.length === 0) return;

  const { error } = await supabase
    .from('budsjett_manuelt')
    .upsert(entries, {
      onConflict: 'versjon_id,ansatt_id,maned',
    });

  if (error) {
    throw new Error(`Failed to bulk upsert manual budgets: ${error.message}`);
  }
}

/**
 * Delete a manual budget entry
 */
export async function deleteManualBudget(id: string): Promise<void> {
  const { error } = await supabase
    .from('budsjett_manuelt')
    .delete()
    .eq('id', id);

  if (error) {
    throw new Error(`Failed to delete manual budget: ${error.message}`);
  }
}

/**
 * Delete all manual budgets for an employee in a version
 */
export async function deleteManualBudgetsForEmployee(
  versionId: string,
  ansattId: string
): Promise<void> {
  const { error } = await supabase
    .from('budsjett_manuelt')
    .delete()
    .eq('versjon_id', versionId)
    .eq('ansatt_id', ansattId);

  if (error) {
    throw new Error(`Failed to delete manual budgets: ${error.message}`);
  }
}

// ============================================
// Planned Hours from Shifts (turnus_skift)
// ============================================

export interface PlannedHoursPerMonth {
  ansatt_id: string;
  maned: number;
  timer: number;
}

/**
 * Get planned hours per employee per month from turnus_skift table
 * This is the authoritative source for actual planned hours
 */
export async function getPlannedHoursFromShifts(
  salonId: string,
  year: number
): Promise<PlannedHoursPerMonth[]> {
  const startDate = `${year}-01-01`;
  const endDate = `${year}-12-31`;

  // Pagination to handle > 1000 shifts (Supabase default limit)
  const PAGE_SIZE = 1000;
  let allData: { ansatt_id: string; dato: string; timer_planlagt: number | null }[] = [];
  let page = 0;
  let hasMore = true;

  while (hasMore) {
    const from = page * PAGE_SIZE;
    const to = from + PAGE_SIZE - 1;

    const { data, error } = await supabase
      .from('turnus_skift')
      .select('ansatt_id, dato, timer_planlagt')
      .eq('salon_id', salonId)
      .gte('dato', startDate)
      .lte('dato', endDate)
      .range(from, to);

    if (error) {
      throw new Error(`Failed to fetch planned hours from shifts: ${error.message}`);
    }

    if (data && data.length > 0) {
      allData = [...allData, ...data];
      hasMore = data.length === PAGE_SIZE;
      page++;
    } else {
      hasMore = false;
    }
  }

  // Aggregate hours per employee per month
  const aggregated = new Map<string, number>();
  
  allData.forEach(shift => {
    if (!shift.ansatt_id || shift.timer_planlagt === null) return;
    
    const date = new Date(shift.dato);
    const month = date.getMonth() + 1; // 1-12
    const key = `${shift.ansatt_id}-${month}`;
    
    const current = aggregated.get(key) || 0;
    aggregated.set(key, current + (shift.timer_planlagt || 0));
  });

  // Convert to array
  const result: PlannedHoursPerMonth[] = [];
  aggregated.forEach((timer, key) => {
    // Use lastIndexOf to correctly split UUID from month (UUID contains hyphens)
    const lastDash = key.lastIndexOf('-');
    const ansatt_id = key.substring(0, lastDash);
    const monthStr = key.substring(lastDash + 1);
    result.push({
      ansatt_id,
      maned: parseInt(monthStr),
      timer: Math.round(timer * 10) / 10, // Round to 1 decimal
    });
  });

  return result;
}

// ============================================
// Monthly KPI Functions (per employee per month)
// ============================================

export interface MonthlyKPI {
  id: string;
  salon_id: string;
  ansatt_id: string;
  versjon_id: string;
  aar: number;
  maned: number;
  effektivitet_prosent: number | null;
  omsetning_per_time: number | null;
  varesalg_prosent: number | null;
  created_at: string;
  updated_at: string;
}

export interface MonthlyKPIWithEmployee extends MonthlyKPI {
  ansatte?: {
    id: string;
    fornavn: string;
    etternavn: string | null;
  } | null;
}

/**
 * Get monthly KPIs for a salon and version
 */
export async function getMonthlyKPIs(
  salonId: string,
  versionId: string
): Promise<MonthlyKPIWithEmployee[]> {
  const { data, error } = await supabase
    .from('ansatt_kpi_maned')
    .select(`
      *,
      ansatte:ansatt_id (
        id,
        fornavn,
        etternavn
      )
    `)
    .eq('salon_id', salonId)
    .eq('versjon_id', versionId)
    .order('maned');

  if (error) {
    throw new Error(`Failed to fetch monthly KPIs: ${error.message}`);
  }

  return (data || []) as MonthlyKPIWithEmployee[];
}

/**
 * Upsert a monthly KPI entry
 */
export async function upsertMonthlyKPI(
  data: {
    salon_id: string;
    ansatt_id: string;
    versjon_id: string;
    aar: number;
    maned: number;
    effektivitet_prosent: number | null;
    omsetning_per_time: number | null;
    varesalg_prosent: number | null;
  }
): Promise<MonthlyKPI> {
  const { data: result, error } = await supabase
    .from('ansatt_kpi_maned')
    .upsert(data, {
      onConflict: 'ansatt_id,versjon_id,maned',
    })
    .select()
    .single();

  if (error) {
    throw new Error(`Failed to upsert monthly KPI: ${error.message}`);
  }

  return result as MonthlyKPI;
}

/**
 * Bulk upsert monthly KPIs for multiple employees
 */
export async function bulkUpsertMonthlyKPIs(
  entries: {
    salon_id: string;
    ansatt_id: string;
    versjon_id: string;
    aar: number;
    maned: number;
    effektivitet_prosent: number | null;
    omsetning_per_time: number | null;
    varesalg_prosent: number | null;
  }[]
): Promise<void> {
  if (entries.length === 0) return;

  const { error } = await supabase
    .from('ansatt_kpi_maned')
    .upsert(entries, {
      onConflict: 'ansatt_id,versjon_id,maned',
    });

  if (error) {
    throw new Error(`Failed to bulk upsert monthly KPIs: ${error.message}`);
  }
}

/**
 * Get monthly KPIs for a specific employee
 */
export async function getMonthlyKPIsByEmployee(
  ansattId: string,
  versionId: string
): Promise<MonthlyKPI[]> {
  const { data, error } = await supabase
    .from('ansatt_kpi_maned')
    .select('*')
    .eq('ansatt_id', ansattId)
    .eq('versjon_id', versionId)
    .order('maned');

  if (error) {
    throw new Error(`Failed to fetch employee monthly KPIs: ${error.message}`);
  }

  return (data || []) as MonthlyKPI[];
}

// ============================================
// Shifts for Budget Generation
// ============================================

export interface ShiftForBudget {
  ansatt_id: string;
  dato: string;
  timer_planlagt: number;
}

/**
 * Get all shifts for a salon for a given year
 * Used by BudgetGenerator to get authoritative planned hours from turnus_skift
 */
export async function getShiftsForBudget(
  salonId: string,
  year: number
): Promise<ShiftForBudget[]> {
  const startDate = `${year}-01-01`;
  const endDate = `${year}-12-31`;

  const PAGE_SIZE = 1000;
  let allData: ShiftForBudget[] = [];
  let page = 0;
  let hasMore = true;

  while (hasMore) {
    const from = page * PAGE_SIZE;
    const to = from + PAGE_SIZE - 1;

    const { data, error } = await supabase
      .from('turnus_skift')
      .select('ansatt_id, dato, timer_planlagt')
      .eq('salon_id', salonId)
      .gte('dato', startDate)
      .lte('dato', endDate)
      .range(from, to);

    if (error) {
      throw new Error(`Failed to fetch shifts for budget: ${error.message}`);
    }

    if (data && data.length > 0) {
      allData = [...allData, ...data.map(d => ({
        ansatt_id: d.ansatt_id,
        dato: d.dato,
        timer_planlagt: d.timer_planlagt || 0
      }))];
      hasMore = data.length === PAGE_SIZE;
      page++;
    } else {
      hasMore = false;
    }
  }

  console.log(`[budgetsService] getShiftsForBudget: fetched ${allData.length} shifts for year ${year}`);
  return allData;
}

// ============================================
// Vacation Hours per Employee per Month
// ============================================

export interface VacationHoursPerMonth {
  ansatt_id: string;
  maned: number;
  timer: number;
}

/**
 * Get vacation hours per employee per month from ferie table
 * Only counts approved/completed vacation (godkjent, planlagt, avviklet)
 */
export async function getVacationHoursFromFerie(
  salonId: string,
  year: number
): Promise<VacationHoursPerMonth[]> {
  const { data, error } = await supabase
    .from('ferie')
    .select('ansatt_id, startdato, sluttdato, timer, status')
    .eq('salon_id', salonId)
    .eq('aar', year)
    .in('status', ['godkjent', 'planlagt', 'avviklet', 'estimat']);

  if (error) {
    throw new Error(`Failed to fetch vacation hours: ${error.message}`);
  }

  // Aggregate vacation hours per employee per month
  // Each ferie record has total timer - distribute across months based on dates
  const aggregated = new Map<string, number>();

  (data || []).forEach(ferie => {
    if (!ferie.ansatt_id || !ferie.timer) return;

    const startDate = new Date(ferie.startdato);
    const endDate = new Date(ferie.sluttdato);
    
    // Simple distribution: assign all hours to start month
    // More accurate would require splitting across months if vacation spans multiple months
    const startMonth = startDate.getMonth() + 1;
    const endMonth = endDate.getMonth() + 1;
    
    if (startMonth === endMonth) {
      // Vacation is within single month
      const key = `${ferie.ansatt_id}-${startMonth}`;
      const current = aggregated.get(key) || 0;
      aggregated.set(key, current + ferie.timer);
    } else {
      // Vacation spans multiple months - distribute proportionally by days
      const totalDays = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)) + 1;
      const hoursPerDay = ferie.timer / totalDays;
      
      let currentDate = new Date(startDate);
      while (currentDate <= endDate) {
        const month = currentDate.getMonth() + 1;
        const key = `${ferie.ansatt_id}-${month}`;
        const current = aggregated.get(key) || 0;
        aggregated.set(key, current + hoursPerDay);
        currentDate.setDate(currentDate.getDate() + 1);
      }
    }
  });

  // Convert to array
  const result: VacationHoursPerMonth[] = [];
  aggregated.forEach((timer, key) => {
    const lastDash = key.lastIndexOf('-');
    const ansatt_id = key.substring(0, lastDash);
    const monthStr = key.substring(lastDash + 1);
    result.push({
      ansatt_id,
      maned: parseInt(monthStr),
      timer: Math.round(timer * 10) / 10, // Round to 1 decimal
    });
  });

  return result;
}

// ============================================
// Vacation Dates for Budget Generation
// ============================================

/**
 * Get vacation dates for budget generation
 * Returns a Map where each ansatt_id maps to a Set of vacation dates (YYYY-MM-DD)
 */
export async function getVacationDatesForBudget(
  salonId: string,
  year: number
): Promise<Map<string, Set<string>>> {
  const { data, error } = await supabase
    .from('ferie')
    .select('ansatt_id, startdato, sluttdato, status')
    .eq('salon_id', salonId)
    .eq('aar', year)
    .in('status', ['godkjent', 'planlagt', 'avviklet', 'estimat']);

  if (error) {
    throw new Error(`Failed to fetch vacation dates: ${error.message}`);
  }

  const result = new Map<string, Set<string>>();

  (data || []).forEach(ferie => {
    if (!ferie.ansatt_id || !ferie.startdato || !ferie.sluttdato) return;

    if (!result.has(ferie.ansatt_id)) {
      result.set(ferie.ansatt_id, new Set());
    }

    // Generate all dates between startdato and sluttdato
    const startDate = new Date(ferie.startdato);
    const endDate = new Date(ferie.sluttdato);
    const dateSet = result.get(ferie.ansatt_id)!;

    let currentDate = new Date(startDate);
    while (currentDate <= endDate) {
      dateSet.add(currentDate.toISOString().split('T')[0]);
      currentDate.setDate(currentDate.getDate() + 1);
    }
  });

  return result;
}

// ============================================
// Budget Regeneration for Employee Period
// ============================================

interface KPIParams {
  effektivitet: number;
  omsetningPerTime: number;
  varesalgProsent: number;
}

/**
 * Regenerate budget for a specific employee in a date range.
 * This is called when vacation changes to redistribute budget.
 * Uses shifts from turnus_skift (which now includes vacation as 0-hour shifts).
 */
export async function regenererBudsjettForAnsattPeriode(
  salonId: string,
  ansattId: string,
  startDate: Date,
  endDate: Date
): Promise<{ regenerated: number; deleted: number }> {
  const startStr = startDate.toISOString().split('T')[0];
  const endStr = endDate.toISOString().split('T')[0];
  const year = startDate.getFullYear();

  // 1. Find active budget version for this year
  const { data: activeVersion, error: versionError } = await supabase
    .from('budsjett_versjoner')
    .select('id')
    .eq('salon_id', salonId)
    .eq('aar', year)
    .eq('er_aktiv', true)
    .single();

  if (versionError || !activeVersion) {
    console.log('[budgetsService] No active budget version found for year', year);
    return { regenerated: 0, deleted: 0 };
  }

  const versionId = activeVersion.id;

  // 2. Get employee KPI data
  const { data: ansatt, error: ansattError } = await supabase
    .from('ansatte')
    .select('effektivitet_prosent, omsetning_per_time, varesalg_prosent')
    .eq('id', ansattId)
    .single();

  if (ansattError || !ansatt) {
    console.error('[budgetsService] Failed to fetch employee:', ansattError);
    return { regenerated: 0, deleted: 0 };
  }

  // Default KPI params (same as BudgetGenerator)
  const defaultParams: KPIParams = {
    effektivitet: 70,
    omsetningPerTime: 1200,
    varesalgProsent: 15
  };

  const params: KPIParams = {
    effektivitet: ansatt.effektivitet_prosent ?? defaultParams.effektivitet,
    omsetningPerTime: ansatt.omsetning_per_time ?? defaultParams.omsetningPerTime,
    varesalgProsent: ansatt.varesalg_prosent ?? defaultParams.varesalgProsent
  };

  // 3. Get monthly KPIs for this employee (for period months)
  const startMonth = startDate.getMonth() + 1;
  const endMonth = endDate.getMonth() + 1;
  
  const { data: monthlyKPIs } = await supabase
    .from('ansatt_kpi_maned')
    .select('maned, effektivitet_prosent, omsetning_per_time, varesalg_prosent')
    .eq('ansatt_id', ansattId)
    .eq('versjon_id', versionId)
    .gte('maned', startMonth)
    .lte('maned', endMonth);

  const monthlyKPIMap = new Map<number, KPIParams>();
  (monthlyKPIs || []).forEach(kpi => {
    monthlyKPIMap.set(kpi.maned, {
      effektivitet: kpi.effektivitet_prosent ?? params.effektivitet,
      omsetningPerTime: kpi.omsetning_per_time ?? params.omsetningPerTime,
      varesalgProsent: kpi.varesalg_prosent ?? params.varesalgProsent
    });
  });

  // 4. Delete existing budget entries for this employee in this period
  const { count: deletedCount, error: deleteError } = await supabase
    .from('budsjett')
    .delete({ count: 'exact' })
    .eq('versjon_id', versionId)
    .eq('ansatt_id', ansattId)
    .gte('dato', startStr)
    .lte('dato', endStr);

  if (deleteError) {
    console.error('[budgetsService] Failed to delete existing budgets:', deleteError);
    return { regenerated: 0, deleted: 0 };
  }

  // 5. Get shifts for this employee in this period
  const { data: shifts, error: shiftsError } = await supabase
    .from('turnus_skift')
    .select('dato, timer_planlagt, kilde')
    .eq('salon_id', salonId)
    .eq('ansatt_id', ansattId)
    .gte('dato', startStr)
    .lte('dato', endStr);

  if (shiftsError) {
    console.error('[budgetsService] Failed to fetch shifts:', shiftsError);
    return { regenerated: 0, deleted: deletedCount || 0 };
  }

  if (!shifts || shifts.length === 0) {
    console.log('[budgetsService] No shifts found for period');
    return { regenerated: 0, deleted: deletedCount || 0 };
  }

  // 6. Generate new budget entries from shifts
  const budgetEntries: any[] = [];

  for (const shift of shifts) {
    const date = new Date(shift.dato);
    const month = date.getMonth() + 1;
    const isoWeekday = date.getDay() === 0 ? 7 : date.getDay();
    const weekNum = Math.ceil((date.getDate() + new Date(date.getFullYear(), date.getMonth(), 1).getDay()) / 7);
    
    const planlagteTimer = shift.timer_planlagt || 0;
    
    // Use monthly KPIs if available, otherwise employee base params
    const kpiParams = monthlyKPIMap.get(month) || params;
    
    // Determine reason for zero hours
    let arsakNullTimer: string | null = null;
    if (planlagteTimer === 0) {
      if (shift.kilde === 'ferie') {
        arsakNullTimer = 'ferie';
      } else if (shift.kilde === 'fravaer') {
        arsakNullTimer = 'fravaer';
      } else {
        arsakNullTimer = 'turnus_fridag';
      }
    }
    
    // Calculate budget from planned hours
    const kundetimer = planlagteTimer * (kpiParams.effektivitet / 100);
    const totaltBudsjett = kundetimer * kpiParams.omsetningPerTime;
    const vareBudsjett = totaltBudsjett * (kpiParams.varesalgProsent / 100);
    const behandlingBudsjett = totaltBudsjett - vareBudsjett;

    budgetEntries.push({
      versjon_id: versionId,
      salon_id: salonId,
      ansatt_id: ansattId,
      aar: year,
      maned: month,
      uke: weekNum,
      dag: isoWeekday,
      dato: shift.dato,
      planlagte_timer: planlagteTimer,
      kundetimer,
      behandling_budsjett: behandlingBudsjett,
      vare_budsjett: vareBudsjett,
      totalt_budsjett: totaltBudsjett,
      arsak_null_timer: arsakNullTimer
    });
  }

  // 7. Insert new budget entries
  if (budgetEntries.length > 0) {
    const { error: insertError } = await supabase
      .from('budsjett')
      .insert(budgetEntries);

    if (insertError) {
      console.error('[budgetsService] Failed to insert budgets:', insertError);
      return { regenerated: 0, deleted: deletedCount || 0 };
    }
  }

  console.log(`[budgetsService] regenererBudsjettForAnsattPeriode: deleted ${deletedCount}, regenerated ${budgetEntries.length} for ${ansattId}`);
  return { regenerated: budgetEntries.length, deleted: deletedCount || 0 };
}
