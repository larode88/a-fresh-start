import { supabase } from "./client";
import type { Json } from "./types";

// =============================================
// TYPES
// =============================================

export type BonusRuleType = 'loyalty' | 'return' | 'combined';
export type ImportMatchStatus = 'matched' | 'unmatched' | 'error' | 'manual_override';
export type BonusCalculationStatus = 'pending' | 'calculated' | 'approved' | 'paid' | 'unmatched';
export type Produkttype = 'kjemi' | 'produkt' | 'begge';

export interface SupplierIdentifier {
  id: string;
  supplier_id: string;
  salon_id: string;
  supplier_customer_number: string;
  identifier_type: string;
  notes?: string;
  created_at: string;
  updated_at: string;
  suppliers?: { name: string };
  salons?: { name: string; medlemsnummer?: string };
}

export type Rapporteringstype = 'kjemi' | 'produkt' | 'samlet' | 'begge_separat';

export interface BonusRule {
  id: string;
  rule_type: BonusRuleType;
  supplier_id: string;
  brand_id?: string;
  product_group?: string;
  rapporteringstype?: Rapporteringstype;
  percentage: number;
  kjemi_prosent?: number;
  produkt_prosent?: number;
  // New fields
  produkttype?: Produkttype;
  lojalitetsbonus_prosent?: number;
  returprovisjon_prosent?: number;
  kjemi_lojalitet_prosent?: number;
  kjemi_retur_prosent?: number;
  produkt_lojalitet_prosent?: number;
  produkt_retur_prosent?: number;
  // End new fields
  valid_from: string;
  valid_to?: string;
  priority: number;
  min_turnover?: number;
  max_turnover?: number;
  description?: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  created_by?: string;
  suppliers?: { name: string };
  leverandor_merker?: { merkenavn: string };
}

export interface ImportBatch {
  id: string;
  supplier_id: string;
  period: string;
  file_name?: string;
  file_url?: string;
  status: string;
  row_count: number;
  matched_count: number;
  error_count: number;
  imported_at: string;
  imported_by?: string;
  processed_at?: string;
  notes?: string;
  suppliers?: { name: string };
}

export interface ImportedSale {
  id: string;
  batch_id: string;
  supplier_id: string;
  reported_period: string;
  reported_value: number;
  cumulative_value?: number;
  brand?: string;
  product_group?: string;
  raw_identifier?: string;
  raw_name?: string;
  matched_salon_id?: string;
  match_status: ImportMatchStatus;
  match_confidence: number;
  match_method?: string;
  error_message?: string;
  created_at: string;
  salons?: { name: string; medlemsnummer?: string };
}

export interface NormalizedSale {
  id: string;
  salon_id: string;
  supplier_id: string;
  brand_id?: string;
  brand_name?: string;
  product_group?: string;
  rapporteringstype?: Rapporteringstype;
  period: string;
  turnover: number;
  delta_turnover?: number;
  source_batch_id?: string;
  is_cumulative: boolean;
  is_locked: boolean;
  created_at: string;
  updated_at: string;
  salons?: { name: string };
  suppliers?: { name: string };
}

export interface BonusCalculation {
  id: string;
  salon_id: string | null;
  supplier_id: string;
  period: string;
  total_turnover: number;
  loyalty_bonus_amount: number;
  return_commission_amount: number;
  total_bonus: number;
  applied_rule_ids?: string[];
  calculation_details?: Record<string, unknown> & { unmatched_count?: number };
  status: BonusCalculationStatus;
  calculated_at?: string;
  calculated_by?: string;
  approved_at?: string;
  approved_by?: string;
  created_at: string;
  updated_at: string;
  salons?: { name: string; medlemsnummer?: string; district_id?: string } | null;
  suppliers?: { name: string };
}

// =============================================
// SUPPLIER IDENTIFIERS
// =============================================

export async function getSupplierIdentifiers(supplierId?: string) {
  let query = supabase
    .from('supplier_identifiers')
    .select(`
      *,
      leverandorer:supplier_id(navn),
      salons:salon_id(name, medlemsnummer)
    `)
    .order('created_at', { ascending: false });

  if (supplierId) {
    query = query.eq('supplier_id', supplierId);
  }

  const { data, error } = await query;
  if (error) throw error;
  
  // Map leverandorer.navn to suppliers.name for backward compatibility
  return (data || []).map(item => ({
    ...item,
    suppliers: item.leverandorer ? { name: (item.leverandorer as any).navn } : undefined
  })) as SupplierIdentifier[];
}

export async function upsertSupplierIdentifier(data: Partial<SupplierIdentifier>) {
  const { data: result, error } = await supabase
    .from('supplier_identifiers')
    .upsert({
      supplier_id: data.supplier_id,
      salon_id: data.salon_id,
      supplier_customer_number: data.supplier_customer_number,
      identifier_type: data.identifier_type || 'customer_number',
      notes: data.notes
    }, {
      onConflict: 'supplier_id,salon_id'
    })
    .select();

  if (error) throw error;
  return result?.[0] || null;
}

export async function deleteSupplierIdentifier(id: string) {
  const { error } = await supabase
    .from('supplier_identifiers')
    .delete()
    .eq('id', id);

  if (error) throw error;
}

// =============================================
// BONUS RULES
// =============================================

export async function getBonusRules(supplierId?: string) {
  let query = supabase
    .from('bonus_rules')
    .select(`
      *,
      leverandorer:supplier_id(navn),
      leverandor_merker:brand_id(merkenavn:navn)
    `)
    .order('priority', { ascending: false });

  if (supplierId) {
    query = query.eq('supplier_id', supplierId);
  }

  const { data, error } = await query;
  if (error) throw error;
  
  // Map leverandorer.navn to suppliers.name for backward compatibility
  return (data || []).map(rule => ({
    ...rule,
    suppliers: rule.leverandorer ? { name: (rule.leverandorer as any).navn } : undefined
  })) as BonusRule[];
}

export async function createBonusRule(data: Partial<BonusRule>) {
  const { data: result, error } = await supabase
    .from('bonus_rules')
    .insert({
      rule_type: data.rule_type,
      supplier_id: data.supplier_id,
      brand_id: data.brand_id,
      product_group: data.product_group,
      rapporteringstype: data.rapporteringstype,
      percentage: data.percentage || 0,
      kjemi_prosent: data.kjemi_prosent,
      produkt_prosent: data.produkt_prosent,
      produkttype: data.produkttype,
      lojalitetsbonus_prosent: data.lojalitetsbonus_prosent,
      returprovisjon_prosent: data.returprovisjon_prosent,
      kjemi_lojalitet_prosent: data.kjemi_lojalitet_prosent,
      kjemi_retur_prosent: data.kjemi_retur_prosent,
      produkt_lojalitet_prosent: data.produkt_lojalitet_prosent,
      produkt_retur_prosent: data.produkt_retur_prosent,
      valid_from: data.valid_from,
      valid_to: data.valid_to,
      priority: data.priority || 0,
      min_turnover: data.min_turnover,
      max_turnover: data.max_turnover,
      description: data.description,
      is_active: data.is_active ?? true
    })
    .select()
    .single();

  if (error) throw error;
  return result;
}

export async function updateBonusRule(id: string, data: Partial<BonusRule>) {
  const { data: result, error } = await supabase
    .from('bonus_rules')
    .update({
      rule_type: data.rule_type,
      supplier_id: data.supplier_id,
      brand_id: data.brand_id,
      product_group: data.product_group,
      rapporteringstype: data.rapporteringstype,
      percentage: data.percentage,
      kjemi_prosent: data.kjemi_prosent,
      produkt_prosent: data.produkt_prosent,
      produkttype: data.produkttype,
      lojalitetsbonus_prosent: data.lojalitetsbonus_prosent,
      returprovisjon_prosent: data.returprovisjon_prosent,
      kjemi_lojalitet_prosent: data.kjemi_lojalitet_prosent,
      kjemi_retur_prosent: data.kjemi_retur_prosent,
      produkt_lojalitet_prosent: data.produkt_lojalitet_prosent,
      produkt_retur_prosent: data.produkt_retur_prosent,
      valid_from: data.valid_from,
      valid_to: data.valid_to,
      priority: data.priority,
      min_turnover: data.min_turnover,
      max_turnover: data.max_turnover,
      description: data.description,
      is_active: data.is_active
    })
    .eq('id', id)
    .select()
    .single();

  if (error) throw error;
  return result;
}

export async function deleteBonusRule(id: string) {
  const { error } = await supabase
    .from('bonus_rules')
    .delete()
    .eq('id', id);

  if (error) throw error;
}

// =============================================
// IMPORT BATCHES
// =============================================

export async function getImportBatches(supplierId?: string) {
  let query = supabase
    .from('bonus_import_batches')
    .select(`
      *,
      leverandorer:supplier_id(navn)
    `)
    .order('imported_at', { ascending: false });

  if (supplierId) {
    query = query.eq('supplier_id', supplierId);
  }

  const { data, error } = await query;
  if (error) throw error;
  
  // Map leverandorer.navn to suppliers.name for backward compatibility
  return (data || []).map(item => ({
    ...item,
    suppliers: item.leverandorer ? { name: (item.leverandorer as any).navn } : undefined
  })) as ImportBatch[];
}

export async function createImportBatch(data: Partial<ImportBatch>) {
  const { data: result, error } = await supabase
    .from('bonus_import_batches')
    .insert({
      supplier_id: data.supplier_id,
      period: data.period,
      file_name: data.file_name,
      file_url: data.file_url,
      status: data.status || 'pending',
      row_count: data.row_count || 0,
      matched_count: data.matched_count || 0,
      error_count: data.error_count || 0,
      notes: data.notes
    })
    .select()
    .single();

  if (error) throw error;
  return result;
}

export async function updateImportBatch(id: string, data: Partial<ImportBatch>) {
  const { data: result, error } = await supabase
    .from('bonus_import_batches')
    .update(data)
    .eq('id', id)
    .select()
    .single();

  if (error) throw error;
  return result;
}

// =============================================
// IMPORTED SALES
// =============================================

export async function getImportedSales(batchId: string) {
  const { data, error } = await supabase
    .from('bonus_imported_sales')
    .select(`
      *,
      salons:matched_salon_id(name, medlemsnummer)
    `)
    .eq('batch_id', batchId)
    .order('raw_name');

  if (error) throw error;
  return data as ImportedSale[];
}

export async function createImportedSales(sales: Partial<ImportedSale>[]) {
  const { data, error } = await supabase
    .from('bonus_imported_sales')
    .insert(sales.map(s => ({
      batch_id: s.batch_id,
      supplier_id: s.supplier_id,
      reported_period: s.reported_period,
      reported_value: s.reported_value,
      cumulative_value: s.cumulative_value,
      brand: s.brand,
      product_group: s.product_group,
      raw_identifier: s.raw_identifier,
      raw_name: s.raw_name,
      matched_salon_id: s.matched_salon_id,
      match_status: s.match_status || 'unmatched',
      match_confidence: s.match_confidence || 0,
      match_method: s.match_method
    })))
    .select();

  if (error) throw error;
  return data;
}

export async function updateImportedSale(id: string, data: Partial<ImportedSale>) {
  const { data: result, error } = await supabase
    .from('bonus_imported_sales')
    .update(data)
    .eq('id', id)
    .select()
    .single();

  if (error) throw error;
  return result;
}

export async function matchImportedSale(saleId: string, salonId: string, matchMethod?: string) {
  const { data, error } = await supabase
    .from('bonus_imported_sales')
    .update({
      matched_salon_id: salonId,
      match_status: 'manual_override',
      match_method: matchMethod || 'manual'
    })
    .eq('id', saleId)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function unmatchImportedSale(saleId: string) {
  const { data, error } = await supabase
    .from('bonus_imported_sales')
    .update({
      matched_salon_id: null,
      match_status: 'unmatched',
      match_method: null,
      match_confidence: null
    })
    .eq('id', saleId)
    .select()
    .single();

  if (error) throw error;
  return data;
}

// =============================================
// NORMALIZED SALES
// =============================================

export async function getNormalizedSales(filters?: {
  salonId?: string;
  supplierId?: string;
  period?: string;
  startPeriod?: string;
  endPeriod?: string;
}) {
  let query = supabase
    .from('bonus_normalized_sales')
    .select(`
      *,
      salons:salon_id(name),
      leverandorer:supplier_id(navn)
    `)
    .order('period', { ascending: false });

  if (filters?.salonId) {
    query = query.eq('salon_id', filters.salonId);
  }
  if (filters?.supplierId) {
    query = query.eq('supplier_id', filters.supplierId);
  }
  if (filters?.period) {
    query = query.eq('period', filters.period);
  }
  if (filters?.startPeriod) {
    query = query.gte('period', filters.startPeriod);
  }
  if (filters?.endPeriod) {
    query = query.lte('period', filters.endPeriod);
  }

  const { data, error } = await query;
  if (error) throw error;
  
  // Map leverandorer.navn to suppliers.name for backward compatibility
  return (data || []).map(item => ({
    ...item,
    suppliers: item.leverandorer ? { name: (item.leverandorer as any).navn } : undefined
  })) as NormalizedSale[];
}

export async function upsertNormalizedSale(data: Partial<NormalizedSale>) {
  const { data: result, error } = await supabase
    .from('bonus_normalized_sales')
    .upsert({
      salon_id: data.salon_id,
      supplier_id: data.supplier_id,
      brand_id: data.brand_id,
      brand_name: data.brand_name,
      product_group: data.product_group,
      rapporteringstype: data.rapporteringstype,
      period: data.period,
      turnover: data.turnover,
      delta_turnover: data.delta_turnover,
      source_batch_id: data.source_batch_id,
      is_cumulative: data.is_cumulative ?? false,
      is_locked: data.is_locked ?? false
    }, {
      onConflict: 'salon_id,supplier_id,period,brand_id,product_group'
    })
    .select()
    .single();

  if (error) throw error;
  return result;
}

// =============================================
// BONUS CALCULATIONS
// =============================================

// Aggregated bonus calculations using RPC (bypasses 1000-row limit)
export interface AggregatedBonusCalculation {
  salon_id: string | null;
  salon_name: string | null;
  salon_medlemsnummer: string | null;
  salon_district_id: string | null;
  supplier_id: string;
  supplier_name: string | null;
  total_turnover: number;
  loyalty_bonus_amount: number;
  return_commission_amount: number;
  total_bonus: number;
  periods: string[];
  worst_status: string;
  calculation_ids: string[];
  calculation_details: Array<{
    period: string;
    turnover: number;
    loyalty: number;
    return: number;
    total: number;
    status: string;
    details: any;
  }>;
}

export async function getAggregatedBonusCalculations(filters: {
  startPeriod: string;
  endPeriod: string;
  supplierId?: string;
  districtId?: string;
}): Promise<AggregatedBonusCalculation[]> {
  const { data, error } = await supabase.rpc('get_aggregated_bonus_calculations', {
    p_start_period: filters.startPeriod,
    p_end_period: filters.endPeriod,
    p_supplier_id: filters.supplierId || null,
    p_district_id: filters.districtId || null
  });
  
  if (error) throw error;
  return (data || []) as AggregatedBonusCalculation[];
}

export async function getBonusCalculations(filters?: {
  salonId?: string;
  supplierId?: string;
  period?: string;
  periods?: string[];
  startPeriod?: string;
  endPeriod?: string;
  status?: BonusCalculationStatus;
}) {
  let query = supabase
    .from('bonus_calculations')
    .select(`
      *,
      salons:salon_id(name, medlemsnummer, district_id),
      leverandorer:supplier_id(navn)
    `)
    .order('period', { ascending: true });

  if (filters?.salonId) {
    query = query.eq('salon_id', filters.salonId);
  }
  if (filters?.supplierId) {
    query = query.eq('supplier_id', filters.supplierId);
  }
  // Range-based filtering (most efficient for date ranges)
  if (filters?.startPeriod && filters?.endPeriod) {
    query = query.gte('period', filters.startPeriod).lte('period', filters.endPeriod);
  }
  // Fallback to periods array or single period
  else if (filters?.periods && filters.periods.length > 0) {
    query = query.in('period', filters.periods);
  } else if (filters?.period) {
    query = query.eq('period', filters.period);
  }
  if (filters?.status) {
    query = query.eq('status', filters.status);
  }

  const { data, error } = await query;
  if (error) throw error;
  
  // Map leverandorer.navn to suppliers.name for backward compatibility
  return (data || []).map(item => ({
    ...item,
    suppliers: item.leverandorer ? { name: (item.leverandorer as any).navn } : undefined
  })) as BonusCalculation[];
}

export async function upsertBonusCalculation(data: Partial<BonusCalculation>) {
  // Handle unmatched calculations differently (salon_id is null)
  if (data.salon_id === null) {
    // Check if unmatched calculation already exists for this supplier/period
    const { data: existing } = await supabase
      .from('bonus_calculations')
      .select('id')
      .is('salon_id', null)
      .eq('supplier_id', data.supplier_id!)
      .eq('period', data.period!)
      .single();

    if (existing) {
      // Update existing unmatched calculation
      const { data: result, error } = await supabase
        .from('bonus_calculations')
        .update({
          total_turnover: data.total_turnover,
          loyalty_bonus_amount: data.loyalty_bonus_amount,
          return_commission_amount: data.return_commission_amount,
          applied_rule_ids: data.applied_rule_ids,
          calculation_details: data.calculation_details as Json,
          status: data.status || 'unmatched',
          calculated_at: data.calculated_at,
          calculated_by: data.calculated_by
        })
        .eq('id', existing.id)
        .select()
        .single();

      if (error) throw error;
      return result;
    } else {
      // Insert new unmatched calculation
      const { data: result, error } = await supabase
        .from('bonus_calculations')
        .insert({
          salon_id: null,
          supplier_id: data.supplier_id,
          period: data.period,
          total_turnover: data.total_turnover,
          loyalty_bonus_amount: data.loyalty_bonus_amount,
          return_commission_amount: data.return_commission_amount,
          applied_rule_ids: data.applied_rule_ids,
          calculation_details: data.calculation_details as Json,
          status: data.status || 'unmatched',
          calculated_at: data.calculated_at,
          calculated_by: data.calculated_by
        })
        .select()
        .single();

      if (error) throw error;
      return result;
    }
  }

  // Manual upsert for matched calculations (salon_id is not null)
  // Check if record exists
  const { data: existingMatched } = await supabase
    .from('bonus_calculations')
    .select('id')
    .eq('salon_id', data.salon_id)
    .eq('supplier_id', data.supplier_id)
    .eq('period', data.period)
    .maybeSingle();

  if (existingMatched) {
    // Update existing record
    const { data: result, error } = await supabase
      .from('bonus_calculations')
      .update({
        total_turnover: data.total_turnover,
        loyalty_bonus_amount: data.loyalty_bonus_amount,
        return_commission_amount: data.return_commission_amount,
        applied_rule_ids: data.applied_rule_ids,
        calculation_details: data.calculation_details as Json,
        status: data.status || 'calculated',
        calculated_at: data.calculated_at,
        calculated_by: data.calculated_by
      })
      .eq('id', existingMatched.id)
      .select()
      .single();

    if (error) throw error;
    return result;
  } else {
    // Insert new record
    const { data: result, error } = await supabase
      .from('bonus_calculations')
      .insert({
        salon_id: data.salon_id,
        supplier_id: data.supplier_id,
        period: data.period,
        total_turnover: data.total_turnover,
        loyalty_bonus_amount: data.loyalty_bonus_amount,
        return_commission_amount: data.return_commission_amount,
        applied_rule_ids: data.applied_rule_ids,
        calculation_details: data.calculation_details as Json,
        status: data.status || 'calculated',
        calculated_at: data.calculated_at,
        calculated_by: data.calculated_by
      })
      .select()
      .single();

    if (error) throw error;
    return result;
  }
}

export async function updateCalculationStatus(
  id: string,
  status: BonusCalculationStatus,
  userId?: string
) {
  const updateData: Record<string, unknown> = { status };

  if (status === 'approved' && userId) {
    updateData.approved_at = new Date().toISOString();
    updateData.approved_by = userId;
  }

  const { data, error } = await supabase
    .from('bonus_calculations')
    .update(updateData)
    .eq('id', id)
    .select()
    .single();

  if (error) throw error;
  return data;
}

// =============================================
// MATCHING HELPERS
// =============================================

export async function findSalonByIdentifier(
  supplierId: string,
  identifier: string
): Promise<string | null> {
  // Try supplier identifier first
  const { data: supplierMatch } = await supabase
    .from('supplier_identifiers')
    .select('salon_id')
    .eq('supplier_id', supplierId)
    .eq('supplier_customer_number', identifier)
    .single();

  if (supplierMatch) return supplierMatch.salon_id;

  // Try membership number
  const { data: memberMatch } = await supabase
    .from('salons')
    .select('id')
    .eq('medlemsnummer', identifier)
    .single();

  if (memberMatch) return memberMatch.id;

  // Try org number
  const { data: orgMatch } = await supabase
    .from('salons')
    .select('id')
    .eq('org_number', identifier)
    .single();

  if (orgMatch) return orgMatch.id;

  return null;
}

// =============================================
// RE-MATCHING
// =============================================

export async function rematchImportedSales(batchId: string): Promise<{ matched: number; failed: number }> {
  // Fetch all unmatched sales for this batch
  const { data: unmatchedSales, error: fetchError } = await supabase
    .from('bonus_imported_sales')
    .select('id, supplier_id, raw_identifier')
    .eq('batch_id', batchId)
    .eq('match_status', 'unmatched');

  if (fetchError) throw fetchError;
  if (!unmatchedSales || unmatchedSales.length === 0) {
    return { matched: 0, failed: 0 };
  }

  let matched = 0;
  let failed = 0;

  // Process each unmatched sale
  for (const sale of unmatchedSales) {
    if (!sale.raw_identifier) {
      failed++;
      continue;
    }

    const matchedSalonId = await findSalonByIdentifier(sale.supplier_id, sale.raw_identifier);

    if (matchedSalonId) {
      const { error: updateError } = await supabase
        .from('bonus_imported_sales')
        .update({
          matched_salon_id: matchedSalonId,
          match_status: 'matched',
          match_confidence: 100,
          match_method: 'identifier_rematch'
        })
        .eq('id', sale.id);

      if (!updateError) {
        matched++;
      } else {
        failed++;
      }
    } else {
      failed++;
    }
  }

  // Update batch statistics
  const { data: batchStats, error: statsError } = await supabase
    .from('bonus_imported_sales')
    .select('match_status')
    .eq('batch_id', batchId);

  if (!statsError && batchStats) {
    const newMatchedCount = batchStats.filter(s => s.match_status === 'matched' || s.match_status === 'manual_override').length;
    const errorCount = batchStats.filter(s => s.match_status === 'unmatched' || s.match_status === 'error').length;

    await supabase
      .from('bonus_import_batches')
      .update({
        matched_count: newMatchedCount,
        error_count: errorCount
      })
      .eq('id', batchId);
  }

  return { matched, failed };
}

// =============================================
// AGGREGATIONS
// =============================================

export async function getCalculationSummary(period: string) {
  const { data, error } = await supabase
    .from('bonus_calculations')
    .select('*')
    .eq('period', period);

  if (error) throw error;

  const summary = {
    totalTurnover: 0,
    totalBonus: 0,
    loyaltyBonus: 0,
    returnCommission: 0,
    pendingCount: 0,
    calculatedCount: 0,
    approvedCount: 0,
    paidCount: 0,
    unmatchedCount: 0
  };

  for (const calc of data || []) {
    summary.totalTurnover += calc.total_turnover || 0;
    summary.totalBonus += calc.total_bonus || 0;
    summary.loyaltyBonus += calc.loyalty_bonus_amount || 0;
    summary.returnCommission += calc.return_commission_amount || 0;

    switch (calc.status) {
      case 'pending': summary.pendingCount++; break;
      case 'calculated': summary.calculatedCount++; break;
      case 'approved': summary.approvedCount++; break;
      case 'paid': summary.paidCount++; break;
      case 'unmatched': summary.unmatchedCount++; break;
    }
  }

  return summary;
}

export async function getCalculationSummaryForPeriods(periods: string[], supplierId?: string) {
  const defaultSummary = {
    totalTurnover: 0,
    totalBonus: 0,
    loyaltyBonus: 0,
    returnCommission: 0,
    pendingCount: 0,
    calculatedCount: 0,
    approvedCount: 0,
    paidCount: 0,
    unmatchedCount: 0
  };

  if (periods.length === 0) {
    return defaultSummary;
  }

  // Use RPC function for server-side aggregation (avoids 1000-row limit)
  const { data, error } = await supabase
    .rpc('get_bonus_summary_for_periods', { 
      period_list: periods,
      filter_supplier_id: supplierId || null
    });

  if (error) {
    console.error('Error fetching bonus summary:', error);
    throw error;
  }

  if (!data || data.length === 0) {
    return defaultSummary;
  }

  const row = data[0];
  return {
    totalTurnover: Number(row.total_turnover) || 0,
    totalBonus: Number(row.total_bonus) || 0,
    loyaltyBonus: Number(row.loyalty_bonus) || 0,
    returnCommission: Number(row.return_commission) || 0,
    pendingCount: Number(row.pending_count) || 0,
    calculatedCount: Number(row.calculated_count) || 0,
    approvedCount: Number(row.approved_count) || 0,
    paidCount: Number(row.paid_count) || 0,
    unmatchedCount: Number(row.unmatched_count) || 0
  };
}

// Get brand-level aggregation for periods using RPC (avoids 1000-row limit)
export async function getBonusByBrandForPeriods(periods: string[], supplierId?: string) {
  if (periods.length === 0) {
    return [];
  }

  const { data, error } = await supabase
    .rpc('get_bonus_by_brand_for_periods', { 
      period_list: periods,
      filter_supplier_id: supplierId || null
    });

  if (error) {
    console.error('Error fetching bonus by brand:', error);
    throw error;
  }

  return (data || []).map(row => ({
    brand: row.brand || 'Ukjent',
    productGroup: row.product_group || 'Ukjent',
    totalTurnover: Number(row.total_turnover) || 0,
    loyaltyBonus: Number(row.loyalty_bonus) || 0,
    returnCommission: Number(row.return_commission) || 0,
    totalBonus: Number(row.total_bonus) || 0
  }));
}
