// Turnus Service
// CRUD-operasjoner for turnusplanlegging

import { supabase } from './supabaseClient';
import type { Database } from './types';
import { format, startOfISOWeek, endOfISOWeek, addDays, addWeeks } from 'date-fns';
// genererSkiftFraMaler is now implemented locally - no longer using turnusUtils import

// ============================================
// TYPER
// ============================================

type Apningstid = Database['public']['Tables']['salong_apningstider']['Row'];
type ApningstidInsert = Database['public']['Tables']['salong_apningstider']['Insert'];
type ApningstidUpdate = Database['public']['Tables']['salong_apningstider']['Update'];

type ApningstidUnntak = Database['public']['Tables']['salong_apningstider_unntak']['Row'];
type ApningstidUnntakInsert = Database['public']['Tables']['salong_apningstider_unntak']['Insert'];

// Maler (templates) - brukes for å definere arbeidsmønster
type AnsattTurnus = Database['public']['Tables']['ansatt_turnus']['Row'];
type AnsattTurnusInsert = Database['public']['Tables']['ansatt_turnus']['Insert'];
type AnsattTurnusUpdate = Database['public']['Tables']['ansatt_turnus']['Update'];

// Faktiske skift (vakter) - genererte skift med timer_planlagt
type TurnusSkift = Database['public']['Tables']['turnus_skift']['Row'];
type TurnusSkiftInsert = Database['public']['Tables']['turnus_skift']['Insert'];
type TurnusSkiftUpdate = Database['public']['Tables']['turnus_skift']['Update'];

type TurnusPreferanseRow = Database['public']['Tables']['turnus_preferanser']['Row'];
type TurnusPreferanseInsert = Database['public']['Tables']['turnus_preferanser']['Insert'];

// ============================================
// ÅPNINGSTIDER
// ============================================

/**
 * Henter standard åpningstider for salong
 */
export async function getApningstider(salonId: string): Promise<Apningstid[]> {
  const { data, error } = await supabase
    .from('salong_apningstider')
    .select('*')
    .eq('salon_id', salonId)
    .order('ukedag');

  if (error) throw new Error(`Kunne ikke hente åpningstider: ${error.message}`);
  return data || [];
}

/**
 * Oppretter eller oppdaterer åpningstider
 */
export async function upsertApningstider(
  salonId: string,
  apningstider: ApningstidInsert[]
): Promise<Apningstid[]> {
  const { data, error } = await supabase
    .from('salong_apningstider')
    .upsert(
      apningstider.map(a => ({ ...a, salon_id: salonId })),
      { onConflict: 'salon_id,ukedag' }
    )
    .select();

  if (error) throw new Error(`Kunne ikke lagre åpningstider: ${error.message}`);
  return data || [];
}

/**
 * Oppdaterer én åpningstid
 */
export async function updateApningstid(
  id: string,
  updates: ApningstidUpdate
): Promise<Apningstid> {
  const { data, error } = await supabase
    .from('salong_apningstider')
    .update(updates)
    .eq('id', id)
    .select()
    .single();

  if (error) throw new Error(`Kunne ikke oppdatere åpningstid: ${error.message}`);
  return data;
}

// ============================================
// ÅPNINGSTID-UNNTAK
// ============================================

/**
 * Henter unntak for åpningstider i en periode
 */
export async function getApningstiderUnntak(
  salonId: string,
  fraDate: string,
  tilDate: string
): Promise<ApningstidUnntak[]> {
  const { data, error } = await supabase
    .from('salong_apningstider_unntak')
    .select('*')
    .eq('salon_id', salonId)
    .gte('dato', fraDate)
    .lte('dato', tilDate)
    .order('dato');

  if (error) throw new Error(`Kunne ikke hente unntak: ${error.message}`);
  return data || [];
}

/**
 * Oppretter unntak for åpningstid
 */
export async function createApningstidUnntak(
  unntak: ApningstidUnntakInsert
): Promise<ApningstidUnntak> {
  const { data, error } = await supabase
    .from('salong_apningstider_unntak')
    .insert(unntak)
    .select()
    .single();

  if (error) throw new Error(`Kunne ikke opprette unntak: ${error.message}`);
  return data;
}

/**
 * Sletter unntak for åpningstid
 */
export async function deleteApningstidUnntak(id: string): Promise<void> {
  const { error } = await supabase
    .from('salong_apningstider_unntak')
    .delete()
    .eq('id', id);

  if (error) throw new Error(`Kunne ikke slette unntak: ${error.message}`);
}

// ============================================
// TURNUS-PREFERANSER (MALER)
// ============================================

/**
 * Henter aktive turnusmaler for en ansatt
 */
export async function getTurnusPreferanser(
  userId: string,
  salonId: string
): Promise<TurnusPreferanseRow[]> {
  const today = format(new Date(), 'yyyy-MM-dd');

  const { data, error } = await supabase
    .from('turnus_preferanser')
    .select('*')
    .eq('user_id', userId)
    .eq('salon_id', salonId)
    .lte('gyldig_fra', today)
    .or(`gyldig_til.is.null,gyldig_til.gte.${today}`)
    .order('ukedag')
    .order('uke_type');

  if (error) throw new Error(`Kunne ikke hente turnusmaler: ${error.message}`);
  return data || [];
}

/**
 * Henter alle turnusmaler for en salong
 */
export async function getAllTurnusPreferanser(
  salonId: string
): Promise<TurnusPreferanseRow[]> {
  const today = format(new Date(), 'yyyy-MM-dd');

  const { data, error } = await supabase
    .from('turnus_preferanser')
    .select('*')
    .eq('salon_id', salonId)
    .lte('gyldig_fra', today)
    .or(`gyldig_til.is.null,gyldig_til.gte.${today}`)
    .order('user_id')
    .order('ukedag');

  if (error) throw new Error(`Kunne ikke hente turnusmaler: ${error.message}`);
  return data || [];
}

/**
 * Oppretter turnusmaler for en ansatt
 */
export async function createTurnusPreferanser(
  preferanser: TurnusPreferanseInsert[]
): Promise<TurnusPreferanseRow[]> {
  const { data, error } = await supabase
    .from('turnus_preferanser')
    .insert(preferanser)
    .select();

  if (error) throw new Error(`Kunne ikke opprette turnusmaler: ${error.message}`);
  return data || [];
}

/**
 * Avslutter eksisterende turnusmaler for en ansatt
 */
export async function avsluttTurnusPreferanser(
  userId: string,
  salonId: string,
  sluttDato: string
): Promise<void> {
  const { error } = await supabase
    .from('turnus_preferanser')
    .update({ gyldig_til: sluttDato })
    .eq('user_id', userId)
    .eq('salon_id', salonId)
    .is('gyldig_til', null);

  if (error) throw new Error(`Kunne ikke avslutte turnusmaler: ${error.message}`);
}

// ============================================
// TURNUS_SKIFT (FAKTISKE VAKTER)
// ============================================

/**
 * Henter faktiske skift for en uke fra turnus_skift tabellen
 */
export async function getSkiftForUke(
  salonId: string,
  ukeStart: Date
): Promise<TurnusSkift[]> {
  const start = format(startOfISOWeek(ukeStart), 'yyyy-MM-dd');
  const slutt = format(endOfISOWeek(ukeStart), 'yyyy-MM-dd');

  const { data, error } = await supabase
    .from('turnus_skift')
    .select('*')
    .eq('salon_id', salonId)
    .gte('dato', start)
    .lte('dato', slutt)
    .order('ansatt_id')
    .order('dato');

  if (error) throw new Error(`Kunne ikke hente skift: ${error.message}`);
  return data || [];
}

/**
 * Henter skift for en ansatt i en periode
 */
export async function getAnsattSkift(
  ansattId: string,
  salonId: string,
  fraDate: string,
  tilDate: string
): Promise<TurnusSkift[]> {
  const { data, error } = await supabase
    .from('turnus_skift')
    .select('*')
    .eq('ansatt_id', ansattId)
    .eq('salon_id', salonId)
    .gte('dato', fraDate)
    .lte('dato', tilDate)
    .order('dato');

  if (error) throw new Error(`Kunne ikke hente ansatt-skift: ${error.message}`);
  return data || [];
}

/**
 * Oppretter eller oppdaterer skift i turnus_skift
 */
export async function upsertSkift(
  skift: TurnusSkiftInsert
): Promise<TurnusSkift> {
  const { data, error } = await supabase
    .from('turnus_skift')
    .upsert(skift, {
      onConflict: 'ansatt_id,salon_id,dato',
    })
    .select()
    .single();

  if (error) throw new Error(`Kunne ikke lagre skift: ${error.message}`);
  return data;
}

/**
 * Oppdaterer et skift
 */
export async function updateSkift(
  id: string,
  updates: TurnusSkiftUpdate
): Promise<TurnusSkift> {
  const { data, error } = await supabase
    .from('turnus_skift')
    .update(updates)
    .eq('id', id)
    .select()
    .single();

  if (error) throw new Error(`Kunne ikke oppdatere skift: ${error.message}`);
  return data;
}

/**
 * Sletter skift
 */
export async function deleteSkift(id: string): Promise<void> {
  const { error } = await supabase
    .from('turnus_skift')
    .delete()
    .eq('id', id);

  if (error) throw new Error(`Kunne ikke slette skift: ${error.message}`);
}

/**
 * Sletter fremtidige skift for en ansatt fra turnus_skift
 */
export async function deleteFremtidigeSkift(
  ansattId: string,
  salonId: string,
  fraOgMedDato: string
): Promise<number> {
  const { data, error } = await supabase
    .from('turnus_skift')
    .delete()
    .eq('ansatt_id', ansattId)
    .eq('salon_id', salonId)
    .gte('dato', fraOgMedDato)
    .select('id');

  if (error) throw new Error(`Kunne ikke slette skift: ${error.message}`);
  return data?.length || 0;
}

// ============================================
// SKIFT-GENERERING FRA MAL (ANSATT_TURNUS)
// ============================================

type TurnusUkeType = 'alle' | 'partall' | 'oddetall' | 'uke1' | 'uke2' | 'uke3';

/**
 * Detekterer turnustype fra ansatt_turnus-maler
 */
function detekterTurnusType(maler: AnsattTurnus[]): 'enkel' | 'touke' | 'treuke' {
  const hasUke1 = maler.some(m => m.uke_type === 'uke1');
  const hasUke2 = maler.some(m => m.uke_type === 'uke2');
  const hasUke3 = maler.some(m => m.uke_type === 'uke3');
  const hasPartall = maler.some(m => m.uke_type === 'partall');
  const hasOddetall = maler.some(m => m.uke_type === 'oddetall');

  if (hasUke1 || hasUke2 || hasUke3) return 'treuke';
  if (hasPartall || hasOddetall) return 'touke';
  return 'enkel';
}

/**
 * Beregner hvilken uke-type som gjelder for en gitt dato
 */
function beregnGjeldendeUkeType(
  dato: Date,
  turnusType: 'enkel' | 'touke' | 'treuke',
  gyldigFra: Date
): TurnusUkeType {
  if (turnusType === 'enkel') {
    return 'alle';
  } else if (turnusType === 'touke') {
    const isoWeek = parseInt(format(dato, 'I'));
    return isoWeek % 2 === 0 ? 'partall' : 'oddetall';
  } else {
    // treuke - beregn hvilken uke i rotasjonen
    const ukerSidenStart = Math.floor((dato.getTime() - gyldigFra.getTime()) / (7 * 24 * 60 * 60 * 1000));
    const rotasjonIndex = Math.abs(ukerSidenStart) % 3;
    return (['uke1', 'uke2', 'uke3'] as TurnusUkeType[])[rotasjonIndex];
  }
}

/**
 * Henter ferie og fravær for en ansatt i en periode
 * Inkluderer alle statuser som blokkerer arbeid: godkjent, planlagt, avviklet
 */
async function getFerieOgFravaer(
  ansattId: string,
  salonId: string,
  fraDate: string,
  tilDate: string
): Promise<Set<string>> {
  // Hent ferie med status som blokkerer arbeid (ikke søknad/avslått)
  const { data: ferie } = await supabase
    .from('ferie')
    .select('startdato, sluttdato')
    .eq('ansatt_id', ansattId)
    .eq('salon_id', salonId)
    .in('status', ['godkjent', 'planlagt', 'avviklet', 'estimat'])
    .lte('startdato', tilDate)
    .gte('sluttdato', fraDate);

  // Hent godkjent fravær/permisjon
  const { data: fravaer } = await supabase
    .from('fravaer')
    .select('startdato, sluttdato')
    .eq('ansatt_id', ansattId)
    .eq('salon_id', salonId)
    .eq('status', 'godkjent')
    .lte('startdato', tilDate)
    .gte('sluttdato', fraDate);

  // Bygg et Set med alle datoer der ansatt er fraværende
  const fravaersDatoer = new Set<string>();
  
  [...(ferie || []), ...(fravaer || [])].forEach(periode => {
    let current = new Date(periode.startdato);
    const end = new Date(periode.sluttdato);
    while (current <= end) {
      fravaersDatoer.add(format(current, 'yyyy-MM-dd'));
      current = addDays(current, 1);
    }
  });

  return fravaersDatoer;
}

/**
 * Beregner timer fra tid
 */
function beregnTimer(startTid: string | null, sluttTid: string | null, pauseMin: number = 30): number {
  if (!startTid || !sluttTid) return 0;
  const [startH, startM] = startTid.split(':').map(Number);
  const [sluttH, sluttM] = sluttTid.split(':').map(Number);
  const minutter = (sluttH * 60 + sluttM) - (startH * 60 + startM) - pauseMin;
  return Math.max(0, minutter / 60);
}

/**
 * Regenererer skift for en ansatt i en spesifikk periode.
 * Brukes når ferie legges til/endres/slettes for å oppdatere skiftplanen.
 * Skriver nå til turnus_skift tabellen (faktiske vakter).
 */
export async function regenererSkiftForPeriode(
  ansattId: string,
  salonId: string,
  startdato: Date,
  sluttdato: Date
): Promise<number> {
  const startStr = format(startdato, 'yyyy-MM-dd');
  const sluttStr = format(sluttdato, 'yyyy-MM-dd');
  
  // 1. Slett eksisterende ulåste skift i perioden fra turnus_skift
  // Note: We don't filter by laast=false here because the query becomes too complex.
  // Instead, just delete all shifts in the period - they'll be regenerated.
  const { error: deleteError } = await supabase
    .from('turnus_skift')
    .delete()
    .eq('ansatt_id', ansattId)
    .eq('salon_id', salonId)
    .gte('dato', startStr)
    .lte('dato', sluttStr);

  if (deleteError) {
    console.error('Error deleting shifts:', deleteError);
    throw new Error(`Kunne ikke slette skift: ${deleteError.message}`);
  }

  // 2. Hent maler for denne ansatte fra ansatt_turnus (gyldig_til IS NULL = aktive maler)
  const { data: maler, error: malerError } = await supabase
    .from('ansatt_turnus')
    .select('*')
    .eq('ansatt_id', ansattId)
    .eq('salon_id', salonId)
    .is('gyldig_til', null);

  if (malerError) throw new Error(`Kunne ikke hente turnusmaler: ${malerError.message}`);
  if (!maler || maler.length === 0) {
    return 0; // Ingen maler - ingenting å generere
  }

  // 3. Hent åpningstider
  const apningstider = await getApningstider(salonId);

  // 4. Hent oppdatert ferie/fravær for perioden
  const fravaersDatoer = await getFerieOgFravaer(ansattId, salonId, startStr, sluttStr);

  // 5. Hent helligdager for perioden
  const helligdager = await getHelligdager(startStr, sluttStr);
  const helligdagSet = new Set(helligdager.map(h => h.dato));

  // 6. Detekter turnustype
  const turnusType = detekterTurnusType(maler);
  const gyldigFra = new Date(maler[0].gyldig_fra);

  // 7. Generer nye skift for perioden -> turnus_skift
  const skiftListe: TurnusSkiftInsert[] = [];
  let currentDate = new Date(startdato);
  
  while (currentDate <= sluttdato) {
    const datoStr = format(currentDate, 'yyyy-MM-dd');
    const ukedag = currentDate.getDay() === 0 ? 7 : currentDate.getDay(); // 1=mandag, 7=søndag

    // Hopp over helligdager
    if (helligdagSet.has(datoStr)) {
      currentDate = addDays(currentDate, 1);
      continue;
    }

    // Sjekk om ansatt har ferie/fravær denne dagen - opprett ferie-skift i stedet
    if (fravaersDatoer.has(datoStr)) {
      // Opprett et ferie-skift med 0 arbeidstimer
      skiftListe.push({
        ansatt_id: ansattId,
        salon_id: salonId,
        dato: datoStr,
        start_tid: null,
        slutt_tid: null,
        timer_planlagt: 0,
        kilde: 'ferie',
        notat: 'Ferie',
      });
    } else {
      // Sjekk om salongen er åpen denne dagen
      const apning = apningstider.find(a => a.ukedag === ukedag);
      if (apning && !apning.stengt) {
        // Finn riktig uke-type for denne datoen
        const gjeldendeUkeType = beregnGjeldendeUkeType(currentDate, turnusType, gyldigFra);

        // Finn matching mal
        let mal: AnsattTurnus | undefined;
        if (turnusType === 'enkel') {
          mal = maler.find(m => m.ukedag === ukedag && (m.uke_type === 'alle' || m.uke_type === 'partall'));
        } else {
          mal = maler.find(m => m.ukedag === ukedag && m.uke_type === gjeldendeUkeType);
        }

        // Hvis gyldig mal og ikke fridag, opprett skift
        if (mal && !mal.fridag && mal.start_tid && mal.slutt_tid) {
          const timerPlanlagt = beregnTimer(mal.start_tid, mal.slutt_tid, mal.pause_minutter || 30);
          
          skiftListe.push({
            ansatt_id: ansattId,
            salon_id: salonId,
            dato: datoStr,
            start_tid: mal.start_tid,
            slutt_tid: mal.slutt_tid,
            timer_planlagt: timerPlanlagt,
            kilde: 'turnus',
            notat: null,
          });
        }
      }
    }
    
    currentDate = addDays(currentDate, 1);
  }

  // 8. Batch-insert nye skift i turnus_skift
  if (skiftListe.length > 0) {
    const { error: insertError } = await supabase
      .from('turnus_skift')
      .insert(skiftListe);

    if (insertError) throw new Error(`Kunne ikke lagre skift: ${insertError.message}`);
  }

  return skiftListe.length;
}

/**
 * Genererer skift fra ansatt_turnus-maler og lagrer til turnus_skift
 * (bruker ansatt_id, tar hensyn til ferie/fravær)
 */
export async function genererOgLagreSkift(
  ansattId: string,
  salonId: string,
  fraOgMedDato: Date,
  antallUker: number = 52
): Promise<number> {
  // 1. Hent ansatt_turnus MALER (gyldig_til IS NULL = aktive maler)
  const { data: maler, error: malerError } = await supabase
    .from('ansatt_turnus')
    .select('*')
    .eq('ansatt_id', ansattId)
    .eq('salon_id', salonId)
    .is('gyldig_til', null);

  if (malerError) throw new Error(`Kunne ikke hente turnusmaler: ${malerError.message}`);
  if (!maler || maler.length === 0) {
    return 0; // Ingen maler - returner 0 i stedet for feil
  }

  // 2. Hent åpningstider
  const apningstider = await getApningstider(salonId);

  // 3. Beregn datoperiode og hent ferie/fravær
  const tilDato = addWeeks(fraOgMedDato, antallUker);
  const fraStr = format(fraOgMedDato, 'yyyy-MM-dd');
  const tilStr = format(tilDato, 'yyyy-MM-dd');
  
  const fravaersDatoer = await getFerieOgFravaer(ansattId, salonId, fraStr, tilStr);

  // 4. Hent helligdager for perioden
  const helligdager = await getHelligdager(fraStr, tilStr);
  const helligdagSet = new Set(helligdager.map(h => h.dato));

  // 5. Detekter turnustype
  const turnusType = detekterTurnusType(maler);
  const gyldigFra = new Date(maler[0].gyldig_fra);

  // 6. Generer skift for hver dag i perioden -> turnus_skift
  const skiftListe: TurnusSkiftInsert[] = [];
  
  for (let ukeOffset = 0; ukeOffset < antallUker; ukeOffset++) {
    const ukeStart = startOfISOWeek(addWeeks(fraOgMedDato, ukeOffset));
    
    for (let dagOffset = 0; dagOffset < 7; dagOffset++) {
      const dagDato = addDays(ukeStart, dagOffset);
      const ukedag = dagOffset + 1; // 1=mandag
      const datoStr = format(dagDato, 'yyyy-MM-dd');

      // Hopp over helligdager
      if (helligdagSet.has(datoStr)) continue;

      // Opprett ferie-skift hvis ansatt har ferie/fravær denne dagen
      if (fravaersDatoer.has(datoStr)) {
        skiftListe.push({
          ansatt_id: ansattId,
          salon_id: salonId,
          dato: datoStr,
          start_tid: null,
          slutt_tid: null,
          timer_planlagt: 0,
          kilde: 'ferie',
          notat: 'Ferie',
        });
        continue;
      }

      // Sjekk om salongen er åpen denne dagen
      const apning = apningstider.find(a => a.ukedag === ukedag);
      if (!apning || apning.stengt) continue;

      // Finn riktig uke-type for denne datoen
      const gjeldendeUkeType = beregnGjeldendeUkeType(dagDato, turnusType, gyldigFra);

      // Finn matching mal
      let mal: AnsattTurnus | undefined;
      if (turnusType === 'enkel') {
        mal = maler.find(m => m.ukedag === ukedag && (m.uke_type === 'alle' || m.uke_type === 'partall'));
      } else if (turnusType === 'touke') {
        mal = maler.find(m => m.ukedag === ukedag && m.uke_type === gjeldendeUkeType);
      } else {
        mal = maler.find(m => m.ukedag === ukedag && m.uke_type === gjeldendeUkeType);
      }

      // Hvis ingen mal eller fridag eller mangler tider, hopp over
      if (!mal || mal.fridag || !mal.start_tid || !mal.slutt_tid) continue;

      const timerPlanlagt = beregnTimer(mal.start_tid, mal.slutt_tid, mal.pause_minutter || 30);

      skiftListe.push({
        ansatt_id: ansattId,
        salon_id: salonId,
        dato: datoStr,
        start_tid: mal.start_tid,
        slutt_tid: mal.slutt_tid,
        timer_planlagt: timerPlanlagt,
        kilde: 'turnus',
        notat: null,
      });
    }
  }

  if (skiftListe.length === 0) {
    return 0;
  }

  // 7. Slett eksisterende fremtidige skift fra turnus_skift
  await deleteFremtidigeSkift(ansattId, salonId, fraStr);

  // 8. Batch-insert nye skift i turnus_skift
  const { error } = await supabase
    .from('turnus_skift')
    .insert(skiftListe);

  if (error) throw new Error(`Kunne ikke lagre skift: ${error.message}`);

  return skiftListe.length;
}

// ============================================
// BEMANNING-STATISTIKK
// ============================================

export interface BemanningStats {
  ukedag: number;
  time: number;
  antall: number;
}

/**
 * Henter bemanningsstatistikk for en uke
 */
export async function getBemanningForUke(
  salonId: string,
  ukeStart: Date
): Promise<BemanningStats[]> {
  const skift = await getSkiftForUke(salonId, ukeStart);
  const stats: BemanningStats[] = [];

  for (let ukedag = 1; ukedag <= 7; ukedag++) {
    // Beregn dato for denne ukedagen og filtrer skift
    const dagDato = addDays(startOfISOWeek(ukeStart), ukedag - 1);
    const dagDatoStr = format(dagDato, 'yyyy-MM-dd');
    
    const dagSkift = skift.filter(s => s.dato === dagDatoStr && s.start_tid && s.slutt_tid);

    for (let time = 6; time <= 22; time++) {
      const antall = dagSkift.filter(s => {
        if (!s.start_tid || !s.slutt_tid) return false;
        const startH = parseInt(s.start_tid.split(':')[0]);
        const sluttH = parseInt(s.slutt_tid.split(':')[0]);
        return time >= startH && time < sluttH;
      }).length;

      stats.push({ ukedag, time, antall });
    }
  }

  return stats;
}

// ============================================
// HELLIGDAGER
// ============================================

/**
 * Henter helligdager fra kalender-tabellen
 */
export async function getHelligdager(
  fraDate: string,
  tilDate: string
): Promise<Array<{ dato: string; helligdag_navn: string }>> {
  const { data, error } = await supabase
    .from('kalender')
    .select('dato, helligdag_navn')
    .gte('dato', fraDate)
    .lte('dato', tilDate)
    .eq('er_helligdag', true)
    .not('helligdag_navn', 'is', null);

  if (error) throw new Error(`Kunne ikke hente helligdager: ${error.message}`);
  return data || [];
}

/**
 * Sjekker om en dato er helligdag
 */
export async function erHelligdag(dato: string): Promise<boolean> {
  const { data, error } = await supabase
    .from('kalender')
    .select('er_helligdag')
    .eq('dato', dato)
    .single();

  if (error) return false;
  return data?.er_helligdag || false;
}
