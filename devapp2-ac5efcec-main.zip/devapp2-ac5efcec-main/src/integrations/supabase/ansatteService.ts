// Ansatte Service
// Provides typed CRUD operations for employee management using the new ansatte table

import { supabase } from './client';

// Types based on ansatte table structure
export interface Ansatt {
  id: string;
  fornavn: string;
  etternavn: string | null;
  salong_id: string | null;
  user_id: string | null;
  status: 'Aktiv' | 'Permisjon' | 'Arkivert';
  frisorfunksjon: 'frisor' | 'senior_frisor' | 'laerling' | null;
  lederstilling: 'daglig_leder' | 'avdelingsleder' | 'styreleder' | null;
  ansatt_dato: string | null;
  stillingsprosent: number;
  arbeidstid_per_uke: number | null;
  arbeidsdager_pr_uke: number | null;
  provetid_til: string | null;
  oppsigelsesdato: string | null;
  siste_arbeidsdag: string | null;
  lonnstype_enum: 'timelonn' | 'fastlonn' | 'provisjon' | 'timelonn_provisjon' | null;
  timesats: number | null;
  fastlonn: number | null;
  provisjon_behandling_prosent: number | null;
  provisjon_vare_prosent: number | null;
  provisjon_behandling_hoy_prosent: number | null;
  provisjon_terskel: number | null;
  feriekrav_type_enum: 'lovfestet' | 'tariffavtale' | 'utvidet' | null;
  feriekrav_timer_per_aar: number;
  feriekrav_kommentar: string | null;
  fodselsdato: string | null;
  telefon: string | null;
  epost: string | null;
  adresse: string | null;
  postnummer: string | null;
  poststed: string | null;
  kjonn: string | null;
  nasjonalitet: string | null;
  personnummer: string | null;
  bankkontonummer: string | null;
  fagbrev_dato: string | null;
  utdanning_fagbrev: string | null;
  kurs_sertifiseringer: string | null;
  mentor_id: string | null;
  verdier: string | null;
  motivasjon_i_jobben: string | null;
  beste_del_av_arbeidsdagen: string | null;
  foretrukket_feiring: string | null;
  effektivitet_prosent: number | null;
  omsetning_per_time: number | null;
  varesalg_prosent: number | null;
  rebooking_prosent: number | null;
  budsjett_kilde: string | null;
  profilbilde_url: string | null;
  arkivert_dato: string | null;
  arkivert_av: string | null;
  arkivert_arsak: string | null;
  hubspot_contact_id: string | null;
  hubspot_synced_at: string | null;
  helseforsikring_status: string | null;
  helseforsikring_avtalenummer: string | null;
  helseforsikring_oppstartsdato: string | null;
  helseforsikring_oppsigelsesdato: string | null;
  helseforsikring_pris: number | null;
  inkluder_i_turnus: boolean;
  inkluder_i_budsjett: boolean;
  created_at: string;
  updated_at: string;
}

// Extended type with calculated fields from ansatte_utvidet view
export interface AnsattUtvidet extends Ansatt {
  navn: string;
  alder: number | null;
  ansiennitet_aar: number | null;
  ansiennitet_maneder: number | null;
  i_provetid: boolean;
  dager_til_provetid_slutt: number | null;
  status_display: string;
  rolle_display: string;
  frisorfunksjon_display: string | null;
  lederstilling_display: string | null;
  bursdag_md: string | null;
  salong_navn: string | null;
  inkluder_i_turnus: boolean;
  inkluder_i_budsjett: boolean;
  effektiv_inkluder_i_turnus: boolean;
  effektiv_inkluder_i_budsjett: boolean;
}

export type AnsattInsert = Omit<Ansatt, 'id' | 'created_at' | 'updated_at'>;
export type AnsattUpdate = Partial<AnsattInsert>;

/**
 * Get all employees for a specific salon (active only by default)
 */
export async function getAnsatteBySalong(
  salongId: string,
  includeArchived: boolean = false
): Promise<AnsattUtvidet[]> {
  let query = supabase
    .from('ansatte_utvidet')
    .select('*')
    .eq('salong_id', salongId);

  if (!includeArchived) {
    query = query.neq('status', 'Arkivert');
  }

  const { data, error } = await query;

  if (error) {
    throw new Error(`Failed to fetch employees: ${error.message}`);
  }

  return (data as AnsattUtvidet[]) || [];
}

/**
 * Get a single employee by ID
 */
export async function getAnsattById(ansattId: string): Promise<AnsattUtvidet | null> {
  const { data, error } = await supabase
    .from('ansatte_utvidet')
    .select('*')
    .eq('id', ansattId)
    .single();

  if (error) {
    if (error.code === 'PGRST116') return null;
    throw new Error(`Failed to fetch employee: ${error.message}`);
  }

  return data as AnsattUtvidet;
}

/**
 * Get employee by user_id (for current logged-in user)
 */
export async function getAnsattByUserId(userId: string): Promise<AnsattUtvidet | null> {
  const { data, error } = await supabase
    .from('ansatte_utvidet')
    .select('*')
    .eq('user_id', userId)
    .single();

  if (error) {
    if (error.code === 'PGRST116') return null;
    throw new Error(`Failed to fetch employee: ${error.message}`);
  }

  return data as AnsattUtvidet;
}

/**
 * Create a new employee
 */
export async function createAnsatt(ansatt: AnsattInsert): Promise<{ data: Ansatt | null; error: Error | null }> {
  try {
    const { data, error } = await supabase
      .from('ansatte')
      .insert(ansatt)
      .select()
      .single();

    if (error) {
      return { data: null, error: new Error(error.message) };
    }

    return { data: data as Ansatt, error: null };
  } catch (err) {
    return { data: null, error: err as Error };
  }
}

/**
 * Update an existing employee
 */
export async function updateAnsatt(
  ansattId: string,
  updates: AnsattUpdate
): Promise<{ data: Ansatt | null; error: Error | null }> {
  try {
    const { data, error } = await supabase
      .from('ansatte')
      .update(updates)
      .eq('id', ansattId)
      .select()
      .single();

    if (error) {
      return { data: null, error: new Error(error.message) };
    }

    return { data: data as Ansatt, error: null };
  } catch (err) {
    return { data: null, error: err as Error };
  }
}

/**
 * Archive an employee (soft delete)
 */
export async function archiveAnsatt(
  ansattId: string,
  arsak: string
): Promise<{ data: Ansatt | null; error: Error | null }> {
  try {
    const { data, error } = await supabase
      .from('ansatte')
      .update({
        status: 'Arkivert',
        arkivert_dato: new Date().toISOString().split('T')[0],
        arkivert_arsak: arsak,
      })
      .eq('id', ansattId)
      .select()
      .single();

    if (error) {
      return { data: null, error: new Error(error.message) };
    }

    return { data: data as Ansatt, error: null };
  } catch (err) {
    return { data: null, error: err as Error };
  }
}

/**
 * Restore an archived employee
 */
export async function restoreAnsatt(ansattId: string): Promise<{ data: Ansatt | null; error: Error | null }> {
  try {
    const { data, error } = await supabase
      .from('ansatte')
      .update({
        status: 'Aktiv',
        arkivert_dato: null,
        arkivert_av: null,
        arkivert_arsak: null,
      })
      .eq('id', ansattId)
      .select()
      .single();

    if (error) {
      return { data: null, error: new Error(error.message) };
    }

    return { data: data as Ansatt, error: null };
  } catch (err) {
    return { data: null, error: err as Error };
  }
}

/**
 * Get employees included in budget (those with frisorfunksjon OR manually included)
 */
export async function getBudgetAnsatte(salongId: string): Promise<AnsattUtvidet[]> {
  const { data, error } = await supabase
    .from('ansatte_utvidet')
    .select('*')
    .eq('salong_id', salongId)
    .eq('status', 'Aktiv')
    .eq('effektiv_inkluder_i_budsjett', true)
    .order('etternavn')
    .order('fornavn');

  if (error) {
    throw new Error(`Failed to fetch budget employees: ${error.message}`);
  }

  return (data as AnsattUtvidet[]) || [];
}

/**
 * Get employees included in schedule (those with frisorfunksjon OR manually included)
 */
export async function getTurnusAnsatte(salongId: string): Promise<AnsattUtvidet[]> {
  const { data, error } = await supabase
    .from('ansatte_utvidet')
    .select('*')
    .eq('salong_id', salongId)
    .eq('status', 'Aktiv')
    .eq('effektiv_inkluder_i_turnus', true)
    .order('etternavn')
    .order('fornavn');

  if (error) {
    throw new Error(`Failed to fetch schedule employees: ${error.message}`);
  }

  return (data as AnsattUtvidet[]) || [];
}

/**
 * Search employees by name or email
 */
export async function searchAnsatte(
  salongId: string,
  searchTerm: string
): Promise<AnsattUtvidet[]> {
  const { data, error } = await supabase
    .from('ansatte_utvidet')
    .select('*')
    .eq('salong_id', salongId)
    .or(`fornavn.ilike.%${searchTerm}%,etternavn.ilike.%${searchTerm}%,epost.ilike.%${searchTerm}%`)
    .order('etternavn')
    .order('fornavn');

  if (error) {
    throw new Error(`Failed to search employees: ${error.message}`);
  }

  return (data as AnsattUtvidet[]) || [];
}

/**
 * Get employees with birthdays in a date range
 */
export async function getAnsatteWithBirthdays(
  salongId: string,
  fromDate: string,
  toDate: string
): Promise<AnsattUtvidet[]> {
  const fromMD = fromDate.slice(5); // MM-DD
  const toMD = toDate.slice(5);
  
  const { data, error } = await supabase
    .from('ansatte_utvidet')
    .select('*')
    .eq('salong_id', salongId)
    .eq('status', 'Aktiv')
    .not('bursdag_md', 'is', null)
    .gte('bursdag_md', fromMD)
    .lte('bursdag_md', toMD);

  if (error) {
    throw new Error(`Failed to fetch birthdays: ${error.message}`);
  }

  return (data as AnsattUtvidet[]) || [];
}

/**
 * Get employees with probation ending soon
 */
export async function getAnsatteWithProvetidEnding(
  salongId: string,
  withinDays: number = 30
): Promise<AnsattUtvidet[]> {
  const today = new Date();
  const futureDate = new Date();
  futureDate.setDate(futureDate.getDate() + withinDays);

  const { data, error } = await supabase
    .from('ansatte_utvidet')
    .select('*')
    .eq('salong_id', salongId)
    .neq('status', 'Arkivert')
    .not('provetid_til', 'is', null)
    .gte('provetid_til', today.toISOString().split('T')[0])
    .lte('provetid_til', futureDate.toISOString().split('T')[0]);

  if (error) {
    throw new Error(`Failed to fetch probation endings: ${error.message}`);
  }

  return (data as AnsattUtvidet[]) || [];
}

/**
 * Get salon statistics
 */
export async function getSalongStats(salongId: string): Promise<{
  totalt: number;
  aktive: number;
  provetid: number;
  permisjon: number;
  arkivert: number;
  avgAnsiennitet: number;
  avgStillingsprosent: number;
}> {
  const { data, error } = await supabase
    .from('ansatte_utvidet')
    .select('status, status_display, ansiennitet_aar, stillingsprosent')
    .eq('salong_id', salongId);

  if (error) {
    throw new Error(`Failed to fetch stats: ${error.message}`);
  }

  const ansatte = data || [];
  const aktive = ansatte.filter(a => a.status === 'Aktiv' && a.status_display !== 'Prøvetid');
  const provetid = ansatte.filter(a => a.status_display === 'Prøvetid');
  const permisjon = ansatte.filter(a => a.status === 'Permisjon');
  const arkivert = ansatte.filter(a => a.status === 'Arkivert');
  
  const activeWithStats = ansatte.filter(a => a.status !== 'Arkivert');
  const avgAnsiennitet = activeWithStats.length > 0
    ? activeWithStats.reduce((sum, a) => sum + (a.ansiennitet_aar || 0), 0) / activeWithStats.length
    : 0;
  const avgStillingsprosent = activeWithStats.length > 0
    ? activeWithStats.reduce((sum, a) => sum + (a.stillingsprosent || 100), 0) / activeWithStats.length
    : 0;

  return {
    totalt: ansatte.length,
    aktive: aktive.length,
    provetid: provetid.length,
    permisjon: permisjon.length,
    arkivert: arkivert.length,
    avgAnsiennitet: Math.round(avgAnsiennitet * 10) / 10,
    avgStillingsprosent: Math.round(avgStillingsprosent),
  };
}
