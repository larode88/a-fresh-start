// Employee Service
// Provides typed CRUD operations for employee management

import { supabase } from './supabaseClient';
import type { Database } from './types';

type Employee = Database['public']['Tables']['users']['Row'];
type EmployeeInsert = Database['public']['Tables']['users']['Insert'];
type EmployeeUpdate = Database['public']['Tables']['users']['Update'];

export interface EmployeeWithSalon extends Employee {
  salons?: {
    id: string;
    name: string;
  } | null;
}

/**
 * Get all employees for a specific salon
 */
export async function getEmployeesBySalon(salonId: string): Promise<EmployeeWithSalon[]> {
  const { data, error } = await supabase
    .from('users')
    .select(`
      *,
      salons:salon_id (
        id,
        name
      )
    `)
    .eq('salon_id', salonId)
    .order('name', { ascending: true });

  if (error) {
    throw new Error(`Failed to fetch employees: ${error.message}`);
  }

  return data || [];
}

/**
 * Get a single employee by ID
 */
export async function getEmployeeById(employeeId: string): Promise<EmployeeWithSalon | null> {
  const { data, error } = await supabase
    .from('users')
    .select(`
      *,
      salons:salon_id (
        id,
        name
      )
    `)
    .eq('id', employeeId)
    .single();

  if (error) {
    throw new Error(`Failed to fetch employee: ${error.message}`);
  }

  return data;
}

/**
 * Create a new employee
 */
export async function createEmployee(employee: EmployeeInsert): Promise<Employee> {
  const { data, error } = await supabase
    .from('users')
    .insert(employee)
    .select()
    .single();

  if (error) {
    throw new Error(`Failed to create employee: ${error.message}`);
  }

  return data;
}

/**
 * Update an existing employee
 */
export async function updateEmployee(
  employeeId: string,
  updates: EmployeeUpdate
): Promise<Employee> {
  const { data, error } = await supabase
    .from('users')
    .update(updates)
    .eq('id', employeeId)
    .select()
    .single();

  if (error) {
    throw new Error(`Failed to update employee: ${error.message}`);
  }

  return data;
}

/**
 * Delete an employee (soft delete by setting aktiv to false)
 */
export async function deleteEmployee(employeeId: string): Promise<void> {
  const { error } = await supabase
    .from('users')
    .update({ aktiv: false })
    .eq('id', employeeId);

  if (error) {
    throw new Error(`Failed to delete employee: ${error.message}`);
  }
}

/**
 * Get active employees only
 */
export async function getActiveEmployees(salonId: string): Promise<EmployeeWithSalon[]> {
  const { data, error } = await supabase
    .from('users')
    .select(`
      *,
      salons:salon_id (
        id,
        name
      )
    `)
    .eq('salon_id', salonId)
    .eq('aktiv', true)
    .order('name', { ascending: true });

  if (error) {
    throw new Error(`Failed to fetch active employees: ${error.message}`);
  }

  return data || [];
}

/**
 * Search employees by name or email
 */
export async function searchEmployees(
  salonId: string,
  searchTerm: string
): Promise<EmployeeWithSalon[]> {
  const { data, error } = await supabase
    .from('users')
    .select(`
      *,
      salons:salon_id (
        id,
        name
      )
    `)
    .eq('salon_id', salonId)
    .or(`name.ilike.%${searchTerm}%,email.ilike.%${searchTerm}%`)
    .order('name', { ascending: true });

  if (error) {
    throw new Error(`Failed to search employees: ${error.message}`);
  }

  return data || [];
}

/**
 * Get active ansatte (employees) from ansatte table for budget generation
 * This is the primary source for employee data with KPI fields
 */
export interface AnsattForBudget {
  id: string;
  fornavn: string;
  etternavn: string | null;
  stillingsprosent: number;
  user_id: string | null;
  frisorfunksjon: 'frisor' | 'senior_frisor' | 'laerling' | null;
  lederstilling: 'daglig_leder' | 'avdelingsleder' | 'styreleder' | null;
  effektivitet_prosent: number | null;
  omsetning_per_time: number | null;
  varesalg_prosent: number | null;
  rebooking_prosent: number | null;
}

export async function getActiveAnsatte(salonId: string): Promise<AnsattForBudget[]> {
  const { data, error } = await supabase
    .from('ansatte')
    .select(`
      id,
      fornavn,
      etternavn,
      stillingsprosent,
      user_id,
      frisorfunksjon,
      lederstilling,
      effektivitet_prosent,
      omsetning_per_time,
      varesalg_prosent,
      rebooking_prosent
    `)
    .eq('salong_id', salonId)
    .eq('status', 'Aktiv')
    .eq('inkluder_i_budsjett', true)
    .order('fornavn', { ascending: true });

  if (error) {
    throw new Error(`Failed to fetch active ansatte: ${error.message}`);
  }

  return data || [];
}

/**
 * Update KPI fields for an employee
 */
export async function updateAnsattKPIs(
  ansattId: string,
  kpis: {
    effektivitet_prosent?: number;
    omsetning_per_time?: number;
    varesalg_prosent?: number;
    rebooking_prosent?: number;
  }
): Promise<void> {
  const { error } = await supabase
    .from('ansatte')
    .update(kpis)
    .eq('id', ansattId);

  if (error) {
    throw new Error(`Failed to update KPIs: ${error.message}`);
  }
}
