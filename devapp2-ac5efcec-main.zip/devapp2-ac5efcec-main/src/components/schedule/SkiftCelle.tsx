import { useState } from "react";
import { format, isSunday } from "date-fns";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { beregnTimerFraTid, formaterTimer, type SkiftData } from "@/lib/turnusUtils";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Loader2, Lock, Unlock, Sun, Coffee, Palmtree } from "lucide-react";

interface SkiftCelleProps {
  ansattId: string;
  userId: string;
  salonId: string;
  dato: Date;
  skift?: SkiftData;
  erHelligdag: boolean;
  helligdagNavn?: string;
  erStengt: boolean;
  erFerie?: boolean;
  ferieType?: string;
  canManage: boolean;
  onUpdate: () => void;
}

export function SkiftCelle({
  ansattId,
  userId,
  salonId,
  dato,
  skift,
  erHelligdag,
  helligdagNavn,
  erStengt,
  erFerie,
  ferieType,
  canManage,
  onUpdate,
}: SkiftCelleProps) {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  
  const [startTid, setStartTid] = useState(skift?.start_tid || "09:00");
  const [sluttTid, setSluttTid] = useState(skift?.slutt_tid || "17:00");
  const [fridag, setFridag] = useState(skift?.fridag ?? false);
  const [laast, setLaast] = useState(skift?.laast ?? false);

  const dateStr = format(dato, "yyyy-MM-dd");
  const erSondag = isSunday(dato);
  const erLaastDag = erSondag || erHelligdag;
  const kanRedigeres = canManage && (!erLaastDag || skift?.helligdag_opplaast);

  // Calculate hours - bruk timer_planlagt fra turnus_skift, eller beregn fra tider
  const timer = skift?.timer_planlagt || 
    (skift && skift.start_tid && skift.slutt_tid
      ? beregnTimerFraTid(skift.start_tid, skift.slutt_tid, 30)
      : 0);

  const handleSave = async () => {
    setSaving(true);
    try {
      // Beregn timer planlagt
      const timerPlanlagt = !fridag ? beregnTimerFraTid(startTid, sluttTid, 30) : 0;
      
      const payload = {
        ansatt_id: ansattId,
        user_id: userId || null,
        salon_id: salonId,
        dato: dateStr,
        start_tid: fridag ? null : startTid,
        slutt_tid: fridag ? null : sluttTid,
        timer_planlagt: timerPlanlagt,
        kilde: 'manuell' as const,
        notat: null,
      };

      if (skift?.id) {
        const { error } = await supabase
          .from("turnus_skift")
          .update(payload)
          .eq("id", skift.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("turnus_skift")
          .insert(payload);
        if (error) throw error;
      }

      toast({ title: "Lagret", description: "Skiftet er oppdatert" });
      setOpen(false);
      onUpdate();
    } catch (error: any) {
      console.error("Error saving shift:", error);
      toast({
        title: "Feil",
        description: error.message || "Kunne ikke lagre skift",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!skift?.id) return;
    setSaving(true);
    try {
      const { error } = await supabase
        .from("turnus_skift")
        .delete()
        .eq("id", skift.id);
      if (error) throw error;

      toast({ title: "Slettet", description: "Skiftet er fjernet" });
      setOpen(false);
      onUpdate();
    } catch (error: any) {
      toast({
        title: "Feil",
        description: error.message || "Kunne ikke slette skift",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  // Render closed/holiday state
  if (erStengt && !skift) {
    return (
      <div className="h-14 flex items-center justify-center bg-muted/30 rounded text-xs text-muted-foreground">
        Stengt
      </div>
    );
  }

  // Render vacation day
  if (erFerie) {
    return (
      <div className="h-14 flex flex-col items-center justify-center bg-sky-500/10 border border-sky-500/20 rounded text-xs">
        <Palmtree className="h-4 w-4 text-sky-600 mb-0.5" />
        <span className="text-sky-700 dark:text-sky-400 truncate px-1 text-center max-w-full">
          {ferieType || 'Ferie'}
        </span>
      </div>
    );
  }

  // Render locked day (Sunday/holiday)
  if (erLaastDag && !skift?.helligdag_opplaast) {
    return (
      <Popover open={open && canManage} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <button
            className="w-full h-14 flex flex-col items-center justify-center bg-muted/50 rounded text-xs text-muted-foreground hover:bg-muted/70 transition-colors"
            disabled={!canManage}
          >
            <Lock className="h-3 w-3 mb-1" />
            <span className="truncate max-w-full px-1">
              {erSondag ? "Søndag" : helligdagNavn?.split(" ")[0]}
            </span>
          </button>
        </PopoverTrigger>
        <PopoverContent className="w-64">
          <div className="space-y-3">
            <h4 className="font-medium">Låst dag</h4>
            <p className="text-sm text-muted-foreground">
              {erSondag ? "Søndager" : "Helligdager"} er låst som standard. 
              Vil du åpne for arbeid denne dagen?
            </p>
            <Button
              size="sm"
              className="w-full"
              onClick={() => {
                setOpen(false);
                // Create new shift with work schedule for this day
                const timerPlanlagt = beregnTimerFraTid("10:00", "16:00", 30);
                const payload = {
                  ansatt_id: ansattId,
                  user_id: userId || null,
                  salon_id: salonId,
                  dato: dateStr,
                  start_tid: "10:00",
                  slutt_tid: "16:00",
                  timer_planlagt: timerPlanlagt,
                  kilde: 'manuell' as const,
                  notat: erSondag ? 'Søndag - manuelt lagt til' : (helligdagNavn || 'Helligdag - manuelt lagt til'),
                };
                supabase.from("turnus_skift").insert(payload).then(({ error }) => {
                  if (error) {
                    toast({ title: "Feil", description: error.message, variant: "destructive" });
                  } else {
                    toast({ title: "Opplåst", description: "Du kan nå planlegge denne dagen" });
                    onUpdate();
                  }
                });
              }}
            >
              <Unlock className="h-4 w-4 mr-2" />
              Lås opp dag
            </Button>
          </div>
        </PopoverContent>
      </Popover>
    );
  }

  // Render off day (ingen skift = fridag)
  if (!skift || (!skift.start_tid && !skift.slutt_tid)) {
    return (
      <Popover open={open && canManage} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <button
            className="w-full h-14 flex flex-col items-center justify-center bg-green-500/10 hover:bg-green-500/20 rounded text-xs transition-colors border border-transparent hover:border-green-500/30"
            disabled={!canManage}
          >
            <Coffee className="h-3 w-3 mb-1 text-green-600" />
            <span className="text-green-700 dark:text-green-400">Fri</span>
          </button>
        </PopoverTrigger>
        <PopoverContent className="w-72">
          <SkiftEditor
            startTid={startTid}
            sluttTid={sluttTid}
            fridag={true}
            laast={laast}
            onStartTidChange={setStartTid}
            onSluttTidChange={setSluttTid}
            onFridagChange={setFridag}
            onLaastChange={setLaast}
            onSave={handleSave}
            onDelete={skift?.id ? handleDelete : undefined}
            saving={saving}
          />
        </PopoverContent>
      </Popover>
    );
  }

  // Render work shift
  return (
    <Popover open={open && canManage} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          className={`w-full h-14 flex flex-col items-center justify-center rounded text-xs transition-colors border ${
            laast 
              ? 'bg-blue-500/10 border-blue-500/30' 
              : 'bg-card hover:bg-accent border-border hover:border-primary/30'
          }`}
          disabled={!canManage}
        >
          <div className="font-medium">
            {skift?.start_tid?.slice(0, 5)} - {skift?.slutt_tid?.slice(0, 5)}
          </div>
          <div className="text-muted-foreground flex items-center gap-1">
            {formaterTimer(timer)}
            {laast && <Lock className="h-2.5 w-2.5" />}
          </div>
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-72">
        <SkiftEditor
          startTid={startTid}
          sluttTid={sluttTid}
          fridag={fridag}
          laast={laast}
          onStartTidChange={setStartTid}
          onSluttTidChange={setSluttTid}
          onFridagChange={setFridag}
          onLaastChange={setLaast}
          onSave={handleSave}
          onDelete={skift?.id ? handleDelete : undefined}
          saving={saving}
        />
      </PopoverContent>
    </Popover>
  );
}

// Inner editor component
interface SkiftEditorProps {
  startTid: string;
  sluttTid: string;
  fridag: boolean;
  laast: boolean;
  onStartTidChange: (v: string) => void;
  onSluttTidChange: (v: string) => void;
  onFridagChange: (v: boolean) => void;
  onLaastChange: (v: boolean) => void;
  onSave: () => void;
  onDelete?: () => void;
  saving: boolean;
}

function SkiftEditor({
  startTid,
  sluttTid,
  fridag,
  laast,
  onStartTidChange,
  onSluttTidChange,
  onFridagChange,
  onLaastChange,
  onSave,
  onDelete,
  saving,
}: SkiftEditorProps) {
  const timer = !fridag ? beregnTimerFraTid(startTid, sluttTid, 30) : 0;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h4 className="font-medium">Rediger skift</h4>
        {!fridag && (
          <Badge variant="secondary">{formaterTimer(timer)}</Badge>
        )}
      </div>

      <div className="flex items-center gap-2">
        <Switch checked={fridag} onCheckedChange={onFridagChange} />
        <Label>Fridag</Label>
      </div>

      {!fridag && (
        <>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label className="text-xs">Start</Label>
              <Input
                type="time"
                value={startTid}
                onChange={(e) => onStartTidChange(e.target.value)}
              />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Slutt</Label>
              <Input
                type="time"
                value={sluttTid}
                onChange={(e) => onSluttTidChange(e.target.value)}
              />
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Switch checked={laast} onCheckedChange={onLaastChange} />
            <Label className="text-sm">Lås skift</Label>
          </div>
        </>
      )}

      <div className="flex gap-2">
        <Button onClick={onSave} disabled={saving} className="flex-1">
          {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
          Lagre
        </Button>
        {onDelete && (
          <Button variant="destructive" onClick={onDelete} disabled={saving}>
            Slett
          </Button>
        )}
      </div>
    </div>
  );
}
