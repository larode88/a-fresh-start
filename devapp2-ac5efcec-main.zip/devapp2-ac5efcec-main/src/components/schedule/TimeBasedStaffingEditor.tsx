import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Save, Loader2, Clock, Users, ChevronDown, Plus, Trash2, Info } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface TimeBasedStaffingEditorProps {
  salonId: string;
}

interface TimeBlock {
  id?: string;
  ukedag: number;
  time_fra: string;
  time_til: string;
  min_bemanning: number;
  ideell_bemanning: number;
}

const WEEKDAYS = [
  { value: 1, label: "Mandag", short: "Man" },
  { value: 2, label: "Tirsdag", short: "Tir" },
  { value: 3, label: "Onsdag", short: "Ons" },
  { value: 4, label: "Torsdag", short: "Tor" },
  { value: 5, label: "Fredag", short: "Fre" },
  { value: 6, label: "Lørdag", short: "Lør" },
  { value: 7, label: "Søndag", short: "Søn" },
];

const DEFAULT_TIME_BLOCKS = [
  { label: "Morgen", time_fra: "09:00", time_til: "11:00" },
  { label: "Midt på dagen", time_fra: "11:00", time_til: "15:00" },
  { label: "Ettermiddag", time_fra: "15:00", time_til: "18:00" },
];

export function TimeBasedStaffingEditor({ salonId }: TimeBasedStaffingEditorProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [staffingData, setStaffingData] = useState<Map<number, TimeBlock[]>>(new Map());
  const [expandedDays, setExpandedDays] = useState<Set<number>>(new Set([1])); // Monday open by default
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [newBlock, setNewBlock] = useState<{
    ukedag: number;
    time_fra: string;
    time_til: string;
    min_bemanning: number;
    ideell_bemanning: number;
  }>({
    ukedag: 1,
    time_fra: "09:00",
    time_til: "12:00",
    min_bemanning: 2,
    ideell_bemanning: 3,
  });

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const { data, error } = await supabase
          .from("salong_bemanning_per_time")
          .select("*")
          .eq("salon_id", salonId)
          .order("ukedag")
          .order("time_fra");

        if (error) throw error;

        // Group by weekday
        const grouped = new Map<number, TimeBlock[]>();
        WEEKDAYS.forEach(day => grouped.set(day.value, []));
        
        data?.forEach(item => {
          const dayBlocks = grouped.get(item.ukedag) || [];
          dayBlocks.push({
            id: item.id,
            ukedag: item.ukedag,
            time_fra: item.time_fra,
            time_til: item.time_til,
            min_bemanning: item.min_bemanning,
            ideell_bemanning: item.ideell_bemanning,
          });
          grouped.set(item.ukedag, dayBlocks);
        });

        setStaffingData(grouped);
      } catch (error) {
        console.error("Error fetching staffing data:", error);
        toast({
          title: "Feil",
          description: "Kunne ikke hente bemanningsdata",
          variant: "destructive"
        });
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [salonId]);

  const toggleDay = (ukedag: number) => {
    setExpandedDays(prev => {
      const next = new Set(prev);
      if (next.has(ukedag)) {
        next.delete(ukedag);
      } else {
        next.add(ukedag);
      }
      return next;
    });
  };

  const updateBlock = (ukedag: number, blockIndex: number, field: keyof TimeBlock, value: string | number) => {
    setStaffingData(prev => {
      const next = new Map(prev);
      const dayBlocks = [...(next.get(ukedag) || [])];
      dayBlocks[blockIndex] = { ...dayBlocks[blockIndex], [field]: value };
      next.set(ukedag, dayBlocks);
      return next;
    });
  };

  const addBlock = async () => {
    try {
      const { data, error } = await supabase
        .from("salong_bemanning_per_time")
        .insert({
          salon_id: salonId,
          ukedag: newBlock.ukedag,
          time_fra: newBlock.time_fra,
          time_til: newBlock.time_til,
          min_bemanning: newBlock.min_bemanning,
          ideell_bemanning: newBlock.ideell_bemanning,
        })
        .select()
        .single();

      if (error) throw error;

      setStaffingData(prev => {
        const next = new Map(prev);
        const dayBlocks = [...(next.get(newBlock.ukedag) || [])];
        dayBlocks.push({
          id: data.id,
          ukedag: data.ukedag,
          time_fra: data.time_fra,
          time_til: data.time_til,
          min_bemanning: data.min_bemanning,
          ideell_bemanning: data.ideell_bemanning,
        });
        // Sort by time
        dayBlocks.sort((a, b) => a.time_fra.localeCompare(b.time_fra));
        next.set(newBlock.ukedag, dayBlocks);
        return next;
      });

      setShowAddDialog(false);
      setExpandedDays(prev => new Set([...prev, newBlock.ukedag]));
      toast({ title: "Tidsblokk lagt til" });
    } catch (error) {
      console.error("Error adding block:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke legge til tidsblokk",
        variant: "destructive"
      });
    }
  };

  const deleteBlock = async (ukedag: number, blockIndex: number) => {
    const block = staffingData.get(ukedag)?.[blockIndex];
    if (!block?.id) return;

    try {
      const { error } = await supabase
        .from("salong_bemanning_per_time")
        .delete()
        .eq("id", block.id);

      if (error) throw error;

      setStaffingData(prev => {
        const next = new Map(prev);
        const dayBlocks = [...(next.get(ukedag) || [])];
        dayBlocks.splice(blockIndex, 1);
        next.set(ukedag, dayBlocks);
        return next;
      });

      toast({ title: "Tidsblokk slettet" });
    } catch (error) {
      console.error("Error deleting block:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke slette tidsblokk",
        variant: "destructive"
      });
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      // Update all blocks
      for (const [ukedag, blocks] of staffingData.entries()) {
        for (const block of blocks) {
          if (block.id) {
            await supabase
              .from("salong_bemanning_per_time")
              .update({
                time_fra: block.time_fra,
                time_til: block.time_til,
                min_bemanning: block.min_bemanning,
                ideell_bemanning: block.ideell_bemanning,
              })
              .eq("id", block.id);
          }
        }
      }

      toast({
        title: "Lagret",
        description: "Bemanningskrav per time er oppdatert"
      });
    } catch (error) {
      console.error("Error saving:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke lagre bemanningskrav",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const applyDefaultBlocks = async (ukedag: number) => {
    try {
      const inserts = DEFAULT_TIME_BLOCKS.map(block => ({
        salon_id: salonId,
        ukedag,
        time_fra: block.time_fra,
        time_til: block.time_til,
        min_bemanning: 2,
        ideell_bemanning: 3,
      }));

      const { data, error } = await supabase
        .from("salong_bemanning_per_time")
        .insert(inserts)
        .select();

      if (error) throw error;

      setStaffingData(prev => {
        const next = new Map(prev);
        const dayBlocks = data.map(item => ({
          id: item.id,
          ukedag: item.ukedag,
          time_fra: item.time_fra,
          time_til: item.time_til,
          min_bemanning: item.min_bemanning,
          ideell_bemanning: item.ideell_bemanning,
        }));
        next.set(ukedag, dayBlocks);
        return next;
      });

      setExpandedDays(prev => new Set([...prev, ukedag]));
      toast({ title: "Standard tidsblokker lagt til" });
    } catch (error) {
      console.error("Error applying defaults:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke legge til standard blokker",
        variant: "destructive"
      });
    }
  };

  if (loading) {
    return <Skeleton className="h-64" />;
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Bemanningskrav per time
            </CardTitle>
            <CardDescription>
              Definer ulike bemanningskrav for forskjellige tidspunkt på dagen
            </CardDescription>
          </div>
          <Button onClick={() => setShowAddDialog(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Legg til tidsblokk
          </Button>
        </div>
      </CardHeader>

      <CardContent className="space-y-2">
        {WEEKDAYS.slice(0, 6).map(day => {
          const blocks = staffingData.get(day.value) || [];
          const isExpanded = expandedDays.has(day.value);
          
          return (
            <Collapsible key={day.value} open={isExpanded} onOpenChange={() => toggleDay(day.value)}>
              <CollapsibleTrigger asChild>
                <div className="flex items-center justify-between p-3 rounded-lg border hover:bg-muted/50 cursor-pointer transition-colors">
                  <div className="flex items-center gap-3">
                    <span className="font-medium w-20">{day.label}</span>
                    {blocks.length > 0 ? (
                      <Badge variant="secondary" className="text-xs">
                        {blocks.length} tidsblokk{blocks.length !== 1 ? "er" : ""}
                      </Badge>
                    ) : (
                      <span className="text-sm text-muted-foreground">Ingen tidsblokker definert</span>
                    )}
                  </div>
                  <ChevronDown className={`h-4 w-4 text-muted-foreground transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
                </div>
              </CollapsibleTrigger>
              
              <CollapsibleContent className="pt-2">
                {blocks.length === 0 ? (
                  <div className="p-4 border rounded-lg bg-muted/20 text-center">
                    <p className="text-sm text-muted-foreground mb-3">
                      Ingen tidsblokker for {day.label.toLowerCase()}
                    </p>
                    <Button variant="outline" size="sm" onClick={() => applyDefaultBlocks(day.value)}>
                      Bruk standard tidsblokker
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-2 pl-4">
                    {/* Header */}
                    <div className="flex items-center gap-2 text-xs text-muted-foreground font-medium px-2">
                      <div className="w-20">Fra</div>
                      <div className="w-20">Til</div>
                      <div className="w-16 text-center">Min</div>
                      <div className="w-16 text-center">Ideell</div>
                    </div>
                    
                    {blocks.map((block, idx) => (
                      <div key={block.id || idx} className="flex items-center gap-2 p-2 rounded bg-background border">
                        <Input
                          type="time"
                          value={block.time_fra}
                          onChange={(e) => updateBlock(day.value, idx, "time_fra", e.target.value)}
                          className="w-20 h-8 text-sm"
                        />
                        <Input
                          type="time"
                          value={block.time_til}
                          onChange={(e) => updateBlock(day.value, idx, "time_til", e.target.value)}
                          className="w-20 h-8 text-sm"
                        />
                        <Input
                          type="number"
                          min={0}
                          max={10}
                          value={block.min_bemanning}
                          onChange={(e) => updateBlock(day.value, idx, "min_bemanning", parseInt(e.target.value) || 0)}
                          className="w-16 h-8 text-sm text-center"
                        />
                        <Input
                          type="number"
                          min={0}
                          max={15}
                          value={block.ideell_bemanning}
                          onChange={(e) => updateBlock(day.value, idx, "ideell_bemanning", parseInt(e.target.value) || 0)}
                          className="w-16 h-8 text-sm text-center"
                        />
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => deleteBlock(day.value, idx)}
                        >
                          <Trash2 className="h-4 w-4 text-muted-foreground hover:text-destructive" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </CollapsibleContent>
            </Collapsible>
          );
        })}

        <div className="flex justify-end pt-4">
          <Button onClick={handleSave} disabled={saving}>
            {saving ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Save className="h-4 w-4 mr-2" />
            )}
            Lagre bemanningskrav
          </Button>
        </div>

        <div className="bg-muted/50 rounded-lg p-4 text-sm text-muted-foreground">
          <p className="flex items-start gap-2">
            <Info className="h-4 w-4 mt-0.5 shrink-0" />
            <span>
              Definer ulike bemanningskrav for forskjellige tidspunkt på dagen. 
              F.eks. høyere bemanning midt på dagen når det er mest trafikk.
            </span>
          </p>
        </div>
      </CardContent>

      {/* Add Block Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Legg til tidsblokk</DialogTitle>
            <DialogDescription>
              Definer bemanningskrav for en spesifikk tidsperiode
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Ukedag</Label>
              <Select 
                value={newBlock.ukedag.toString()} 
                onValueChange={(v) => setNewBlock(prev => ({ ...prev, ukedag: parseInt(v) }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {WEEKDAYS.slice(0, 6).map(day => (
                    <SelectItem key={day.value} value={day.value.toString()}>
                      {day.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Fra</Label>
                <Input
                  type="time"
                  value={newBlock.time_fra}
                  onChange={(e) => setNewBlock(prev => ({ ...prev, time_fra: e.target.value }))}
                />
              </div>
              <div className="space-y-2">
                <Label>Til</Label>
                <Input
                  type="time"
                  value={newBlock.time_til}
                  onChange={(e) => setNewBlock(prev => ({ ...prev, time_til: e.target.value }))}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="flex items-center gap-1">
                  <Users className="h-3 w-3" />
                  Min. bemanning
                </Label>
                <Input
                  type="number"
                  min={0}
                  max={10}
                  value={newBlock.min_bemanning}
                  onChange={(e) => setNewBlock(prev => ({ ...prev, min_bemanning: parseInt(e.target.value) || 0 }))}
                />
              </div>
              <div className="space-y-2">
                <Label className="flex items-center gap-1">
                  <Users className="h-3 w-3" />
                  Ideell bemanning
                </Label>
                <Input
                  type="number"
                  min={0}
                  max={15}
                  value={newBlock.ideell_bemanning}
                  onChange={(e) => setNewBlock(prev => ({ ...prev, ideell_bemanning: parseInt(e.target.value) || 0 }))}
                />
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddDialog(false)}>
              Avbryt
            </Button>
            <Button onClick={addBlock}>
              Legg til
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
