import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { getActiveAnsatte, AnsattForBudget } from "@/integrations/supabase/employeesService";
import { getShiftsBySalonAndDateRange, getShiftSummary, ShiftWithEmployee } from "@/integrations/supabase/shiftsService";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { ChevronLeft, ChevronRight, Calendar, Clock, TrendingUp } from "lucide-react";
import { format, startOfWeek, addDays, addWeeks, subWeeks, getISOWeek, getYear } from "date-fns";
import { nb } from "date-fns/locale";

interface WeeklyScheduleViewProps {
  salonId: string;
  canManage: boolean;
}

interface EmployeeSchedule {
  userId: string;
  userName: string;
  stillingsprosent: number;
  expectedHours: number;
  days: {
    date: Date;
    shiftId?: string;
    start_tid: string | null;
    slutt_tid: string | null;
    fridag: boolean;
    hours: number;
  }[];
  summary?: {
    total_shifts: number;
    total_planned_hours: number;
    avg_hours_per_shift: number;
    days_worked: number;
  };
}

const WEEKDAYS = ["Man", "Tir", "Ons", "Tor", "Fre", "Lør", "Søn"];
const WEEKLY_FULL_TIME_HOURS = 37.5;

export function WeeklyScheduleView({ salonId, canManage }: WeeklyScheduleViewProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [currentWeekStart, setCurrentWeekStart] = useState(() => 
    startOfWeek(new Date(), { weekStartsOn: 1 })
  );
  const [schedules, setSchedules] = useState<EmployeeSchedule[]>([]);
  const [totalHours, setTotalHours] = useState({ planned: 0, expected: 0 });

  const weekNumber = getISOWeek(currentWeekStart);
  const year = getYear(currentWeekStart);
  const weekDates = Array.from({ length: 7 }, (_, i) => addDays(currentWeekStart, i));
  
  const startDateStr = format(currentWeekStart, "yyyy-MM-dd");
  const endDateStr = format(addDays(currentWeekStart, 6), "yyyy-MM-dd");

  useEffect(() => {
    const fetchSchedules = async () => {
      setLoading(true);
      try {
        // Fetch active ansatte and shifts in parallel
        const [ansatte, shifts] = await Promise.all([
          getActiveAnsatte(salonId),
          getShiftsBySalonAndDateRange(salonId, startDateStr, endDateStr)
        ]);

        // Fetch turnus templates as fallback (using ansatt_id)
        const ansattIds = ansatte.map(a => a.id);
        const { data: turnus, error: turnusError } = await supabase
          .from("ansatt_turnus")
          .select("*")
          .eq("salon_id", salonId)
          .is("gyldig_til", null);

        if (turnusError) throw turnusError;

        // Build shift map (actual scheduled shifts) - keyed by ansatt_id
        const shiftMap = new Map<string, Map<string, ShiftWithEmployee>>();
        shifts.forEach(shift => {
          // Try to match by ansatt_id first, then user_id
          const key = shift.ansatt_id || shift.user_id;
          if (!shiftMap.has(key)) {
            shiftMap.set(key, new Map());
          }
          shiftMap.get(key)!.set(shift.dato, shift);
        });

        // Build turnus template map (fallback for days without shifts)
        const turnusMap = new Map<string, Map<number, typeof turnus[0]>>();
        turnus?.forEach(t => {
          const key = t.ansatt_id || t.user_id;
          if (key) {
            if (!turnusMap.has(key)) {
              turnusMap.set(key, new Map());
            }
            turnusMap.get(key)!.set(t.ukedag, t);
          }
        });

        // Fetch summaries for each employee
        const employeeSchedules: EmployeeSchedule[] = await Promise.all(
          ansatte.map(async (ansatt) => {
            const name = ansatt.etternavn 
              ? `${ansatt.fornavn} ${ansatt.etternavn}` 
              : ansatt.fornavn;
            
            // Look for shifts by ansatt_id or user_id
            const ansattShifts = shiftMap.get(ansatt.id) || (ansatt.user_id ? shiftMap.get(ansatt.user_id) : undefined) || new Map();
            const ansattTurnus = turnusMap.get(ansatt.id) || (ansatt.user_id ? turnusMap.get(ansatt.user_id) : undefined) || new Map();
            const stillingsprosent = ansatt.stillingsprosent || 100;
            const expectedHours = (WEEKLY_FULL_TIME_HOURS * stillingsprosent) / 100;

            // Get shift summary from service (using user_id if available for backward compat)
            let summary;
            if (ansatt.user_id) {
              try {
                summary = await getShiftSummary(ansatt.user_id, startDateStr, endDateStr);
              } catch (e) {
                console.warn("Could not fetch shift summary:", e);
              }
            }

            const days = weekDates.map((date, idx) => {
              const dateStr = format(date, "yyyy-MM-dd");
              const shift = ansattShifts.get(dateStr);
              
              // If we have an actual shift, use it
              if (shift) {
                const startParts = shift.start_tid?.split(":").map(Number) || [0, 0];
                const endParts = shift.slutt_tid?.split(":").map(Number) || [0, 0];
                const hours = (endParts[0] + endParts[1] / 60) - (startParts[0] + startParts[1] / 60);
                
                return {
                  date,
                  shiftId: shift.id,
                  start_tid: shift.start_tid,
                  slutt_tid: shift.slutt_tid,
                  fridag: false,
                  hours: Math.max(0, hours)
                };
              }

              // Fall back to turnus template
              const dayOfWeek = idx + 1;
              const turnusDay = ansattTurnus.get(dayOfWeek);
              
              const isEvenWeek = weekNumber % 2 === 0;
              const ukeType = turnusDay?.uke_type || "alle";
              const applies = ukeType === "alle" || 
                (ukeType === "partall" && isEvenWeek) ||
                (ukeType === "oddetall" && !isEvenWeek);

              if (!turnusDay || turnusDay.fridag || !applies) {
                return { date, start_tid: null, slutt_tid: null, fridag: true, hours: 0 };
              }

              const startParts = turnusDay.start_tid?.split(":").map(Number) || [9, 0];
              const endParts = turnusDay.slutt_tid?.split(":").map(Number) || [17, 0];
              const hours = (endParts[0] + endParts[1] / 60) - (startParts[0] + startParts[1] / 60);

              return {
                date,
                start_tid: turnusDay.start_tid,
                slutt_tid: turnusDay.slutt_tid,
                fridag: false,
                hours: Math.max(0, hours)
              };
            });

            return {
              userId: ansatt.id,
              userName: name,
              stillingsprosent,
              expectedHours,
              days,
              summary
            };
          })
        );

        // Calculate totals
        const plannedTotal = employeeSchedules.reduce(
          (sum, s) => sum + s.days.reduce((d, day) => d + day.hours, 0), 0
        );
        const expectedTotal = employeeSchedules.reduce((sum, s) => sum + s.expectedHours, 0);

        setSchedules(employeeSchedules);
        setTotalHours({ planned: plannedTotal, expected: expectedTotal });
      } catch (error) {
        console.error("Error fetching schedules:", error);
        toast({
          title: "Feil",
          description: "Kunne ikke hente ukeoversikt",
          variant: "destructive"
        });
      } finally {
        setLoading(false);
      }
    };

    fetchSchedules();
  }, [salonId, currentWeekStart, startDateStr, endDateStr, weekNumber]);

  const calculateTotalHours = (schedule: EmployeeSchedule) => {
    return schedule.days.reduce((sum, day) => sum + day.hours, 0);
  };

  const getHoursVariance = (schedule: EmployeeSchedule) => {
    const actual = calculateTotalHours(schedule);
    const expected = schedule.expectedHours;
    return actual - expected;
  };

  if (loading) {
    return <Skeleton className="h-96" />;
  }

  return (
    <div className="space-y-4">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Planlagte timer</p>
                <p className="text-2xl font-bold">{totalHours.planned.toFixed(1)}t</p>
              </div>
              <Clock className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Forventet (stilling)</p>
                <p className="text-2xl font-bold">{totalHours.expected.toFixed(1)}t</p>
              </div>
              <TrendingUp className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avvik</p>
                <p className={`text-2xl font-bold ${totalHours.planned - totalHours.expected >= 0 ? 'text-success' : 'text-warning'}`}>
                  {totalHours.planned - totalHours.expected >= 0 ? '+' : ''}{(totalHours.planned - totalHours.expected).toFixed(1)}t
                </p>
              </div>
              <Calendar className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Schedule Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Uke {weekNumber}, {year}
              </CardTitle>
              <CardDescription>
                {format(currentWeekStart, "d. MMMM", { locale: nb })} - {format(addDays(currentWeekStart, 6), "d. MMMM yyyy", { locale: nb })}
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="icon"
                onClick={() => setCurrentWeekStart(prev => subWeeks(prev, 1))}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                onClick={() => setCurrentWeekStart(startOfWeek(new Date(), { weekStartsOn: 1 }))}
              >
                I dag
              </Button>
              <Button
                variant="outline"
                size="icon"
                onClick={() => setCurrentWeekStart(prev => addWeeks(prev, 1))}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {schedules.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">
              Ingen ansatte funnet.
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 px-2 font-medium">Ansatt</th>
                    {weekDates.map((date, idx) => (
                      <th key={idx} className="text-center py-3 px-2 font-medium min-w-20">
                        <div>{WEEKDAYS[idx]}</div>
                        <div className="text-xs text-muted-foreground font-normal">
                          {format(date, "d/M")}
                        </div>
                      </th>
                    ))}
                    <th className="text-center py-3 px-2 font-medium min-w-28">Timer</th>
                  </tr>
                </thead>
                <tbody>
                  {schedules.map(schedule => {
                    const actualHours = calculateTotalHours(schedule);
                    const variance = getHoursVariance(schedule);
                    const fillPercent = Math.min(100, (actualHours / schedule.expectedHours) * 100);
                    
                    return (
                      <tr key={schedule.userId} className="border-b hover:bg-muted/50">
                        <td className="py-3 px-2">
                          <div className="font-medium">{schedule.userName}</div>
                          <div className="text-xs text-muted-foreground">
                            {schedule.stillingsprosent}% stilling
                          </div>
                        </td>
                        {schedule.days.map((day, idx) => (
                          <td key={idx} className="text-center py-3 px-2">
                            {day.fridag ? (
                              <Badge variant="secondary" className="text-xs">Fri</Badge>
                            ) : (
                              <div className="text-xs">
                                <div className="font-medium">
                                  {day.start_tid?.slice(0, 5)} - {day.slutt_tid?.slice(0, 5)}
                                </div>
                                <div className="text-muted-foreground">
                                  {day.hours.toFixed(1)}t
                                </div>
                              </div>
                            )}
                          </td>
                        ))}
                        <td className="py-3 px-2">
                          <div className="space-y-1">
                            <div className="flex items-center justify-between text-xs">
                              <span>{actualHours.toFixed(1)}t</span>
                              <span className={`font-medium ${variance >= 0 ? 'text-success' : 'text-warning'}`}>
                                {variance >= 0 ? '+' : ''}{variance.toFixed(1)}
                              </span>
                            </div>
                            <Progress value={fillPercent} className="h-1.5" />
                            <div className="text-xs text-muted-foreground text-center">
                              av {schedule.expectedHours.toFixed(1)}t
                            </div>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
