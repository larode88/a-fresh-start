import { useState, useEffect, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { getAnsatteBySalong, type AnsattUtvidet } from "@/integrations/supabase/ansatteService";
import { sortByFirstNameFirst } from "@/lib/sortUtils";
import { getApningstider, getSkiftForUke, getHelligdager, genererOgLagreSkift } from "@/integrations/supabase/turnusService";
import { 
  tellBemanning, 
  getBemanningStatus, 
  getBemanningStatusColor,
  analyserUkeBemanning,
  beregnTimerFraTid,
  formaterTimer,
  UKEDAGER,
  type SkiftData,
  type BemanningForslag 
} from "@/lib/turnusUtils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Calendar,
  ChevronsLeft,
  ChevronsRight,
  Clock, 
  TrendingUp, 
  AlertTriangle,
  Users,
  Lightbulb,
  Wand2,
  Loader2
} from "lucide-react";
import { WeekSelector } from "@/components/WeekSelector";
import { 
  format, 
  startOfWeek, 
  addDays, 
  addWeeks, 
  subWeeks, 
  getISOWeek, 
  getYear,
  isSameDay,
  isSunday 
} from "date-fns";
import { nb } from "date-fns/locale";
import { SkiftCelle } from "./SkiftCelle";
import { BemanningsPanel } from "./BemanningsPanel";

interface TurnusTimelineProps {
  salonId: string;
  canManage: boolean;
}

interface AnsattSkiftData {
  ansatt: AnsattUtvidet;
  skift: Map<string, SkiftData>;
  ukeTimer: number;
  forventetTimer: number;
}

const WEEKLY_FULL_TIME_HOURS = 37.5;

export function TurnusTimeline({ salonId, canManage }: TurnusTimelineProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [currentWeekStart, setCurrentWeekStart] = useState(() => 
    startOfWeek(new Date(), { weekStartsOn: 1 })
  );
  
  const [ansatte, setAnsatte] = useState<AnsattUtvidet[]>([]);
  const [apningstider, setApningstider] = useState<any[]>([]);
  const [skiftMap, setSkiftMap] = useState<Map<string, Map<string, SkiftData>>>(new Map());
  const [helligdager, setHelligdager] = useState<Map<string, string>>(new Map());
  const [ferieMap, setFerieMap] = useState<Map<string, Map<string, string>>>(new Map()); // ansatt_id -> dateStr -> ferieType
  const [showBemanningsPanel, setShowBemanningsPanel] = useState(false);
  
  // Generate shifts dialog
  const [showGenererDialog, setShowGenererDialog] = useState(false);
  const [genererUker, setGenererUker] = useState(4);
  const [generating, setGenerating] = useState(false);

  const weekNumber = getISOWeek(currentWeekStart);
  const year = getYear(currentWeekStart);
  const weekDates = Array.from({ length: 7 }, (_, i) => addDays(currentWeekStart, i));
  
  const startDateStr = format(currentWeekStart, "yyyy-MM-dd");
  const endDateStr = format(addDays(currentWeekStart, 6), "yyyy-MM-dd");

  // Fetch all data
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const [ansatteData, apningstiderData, skiftData, helligdagerData, ferieData] = await Promise.all([
          getAnsatteBySalong(salonId, false), // Only active
          getApningstider(salonId),
          getSkiftForUke(salonId, currentWeekStart),
          getHelligdager(startDateStr, endDateStr),
          // Fetch vacation data for the week
          supabase
            .from('ferie')
            .select('ansatt_id, startdato, sluttdato, type')
            .eq('salon_id', salonId)
            .in('status', ['godkjent', 'planlagt', 'avviklet'])
            .lte('startdato', endDateStr)
            .gte('sluttdato', startDateStr)
            .then(res => res.data || []),
        ]);

        // Filter only employees with frisorfunksjon (budget-relevant) and sort by first name
        const aktiveFrisorer = ansatteData.filter(a => a.frisorfunksjon);
        setAnsatte(sortByFirstNameFirst(aktiveFrisorer));
        setApningstider(apningstiderData);

        // Build shift map: ansatt_id -> dateStr -> shift (bruker dato fra turnus_skift)
        const newSkiftMap = new Map<string, Map<string, SkiftData>>();
        skiftData.forEach(skift => {
          const key = skift.ansatt_id || skift.user_id || '';
          if (!key) return;
          if (!newSkiftMap.has(key)) {
            newSkiftMap.set(key, new Map());
          }
          // Konverter turnus_skift til SkiftData format
          const skiftMapped: SkiftData = {
            ...skift,
            dato: skift.dato,
          };
          newSkiftMap.get(key)!.set(skift.dato, skiftMapped);
        });
        setSkiftMap(newSkiftMap);

        // Build holiday map
        const newHelligdager = new Map<string, string>();
        helligdagerData.forEach(h => {
          newHelligdager.set(h.dato, h.helligdag_navn);
        });
        setHelligdager(newHelligdager);

        // Build vacation map: ansatt_id -> dateStr -> ferieType
        const newFerieMap = new Map<string, Map<string, string>>();
        ferieData.forEach((ferie: { ansatt_id: string; startdato: string; sluttdato: string; type: string }) => {
          if (!ferie.ansatt_id) return;
          if (!newFerieMap.has(ferie.ansatt_id)) {
            newFerieMap.set(ferie.ansatt_id, new Map());
          }
          // Add each date in the vacation period
          const start = new Date(ferie.startdato);
          const end = new Date(ferie.sluttdato);
          for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
            const dateStr = format(d, 'yyyy-MM-dd');
            newFerieMap.get(ferie.ansatt_id)!.set(dateStr, ferie.type || 'Ferie');
          }
        });
        setFerieMap(newFerieMap);

      } catch (error) {
        console.error("Error fetching turnus data:", error);
        toast({
          title: "Feil",
          description: "Kunne ikke hente turnusdata",
          variant: "destructive"
        });
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [salonId, currentWeekStart, startDateStr, endDateStr]);

  // Calculate employee data with shifts (bruker ansatt.id)
  const ansattData = useMemo<AnsattSkiftData[]>(() => {
    return ansatte.map(ansatt => {
      // Prioriter ansatt.id, fallback til user_id for bakoverkompatibilitet
      const ansattSkift = skiftMap.get(ansatt.id) || skiftMap.get(ansatt.user_id || '') || new Map();
      let ukeTimer = 0;

      weekDates.forEach(date => {
        const dateStr = format(date, 'yyyy-MM-dd');
        const skift = ansattSkift.get(dateStr);
        // turnus_skift bruker timer_planlagt - ingen fridag-felt
        if (skift && skift.start_tid && skift.slutt_tid && skift.timer_planlagt) {
          ukeTimer += skift.timer_planlagt;
        }
      });

      const forventetTimer = (WEEKLY_FULL_TIME_HOURS * (ansatt.stillingsprosent || 100)) / 100;

      return { ansatt, skift: ansattSkift, ukeTimer, forventetTimer };
    });
  }, [ansatte, skiftMap, weekDates]);

  // Calculate totals
  const totals = useMemo(() => {
    const planned = ansattData.reduce((sum, a) => sum + a.ukeTimer, 0);
    const expected = ansattData.reduce((sum, a) => sum + a.forventetTimer, 0);
    return { planned, expected, variance: planned - expected };
  }, [ansattData]);

  // Build shift list for analysis
  const allSkift = useMemo<SkiftData[]>(() => {
    const list: SkiftData[] = [];
    skiftMap.forEach(userMap => {
      userMap.forEach(skift => list.push(skift));
    });
    return list;
  }, [skiftMap]);

  // Analyze staffing
  const bemanningsForslag = useMemo(() => {
    return analyserUkeBemanning(
      apningstider.map(a => ({
        ukedag: a.ukedag,
        stengt: a.stengt,
        apner: a.apner,
        stenger: a.stenger,
        min_bemanning: a.min_bemanning,
        ideell_bemanning: a.ideell_bemanning,
      })),
      allSkift
    );
  }, [apningstider, allSkift]);

  const kritiskeForslag = bemanningsForslag.filter(f => f.type === 'kritisk' || f.type === 'undermanning');

  // Handle shift update
  const handleSkiftUpdate = () => {
    // Refetch data
    setLoading(true);
    // This triggers the useEffect
    setCurrentWeekStart(prev => new Date(prev.getTime()));
  };

  // Generate shifts from templates (bruker ansatt.id, tar hensyn til ferie)
  const handleGenererSkift = async () => {
    setGenerating(true);
    try {
      let totalGenerated = 0;
      let ansatteMedMaler = 0;
      
      for (const ansatt of ansatte) {
        // Bruker ansatt.id direkte - ikke avhengig av user_id
        const count = await genererOgLagreSkift(
          ansatt.id,
          salonId,
          currentWeekStart,
          genererUker
        );
        if (count > 0) ansatteMedMaler++;
        totalGenerated += count;
      }

      if (totalGenerated === 0) {
        toast({
          title: "Ingen skift generert",
          description: "Ingen ansatte har aktive turnusmaler. Opprett maler først.",
          variant: "destructive"
        });
      } else {
        toast({
          title: "Skift generert",
          description: `${totalGenerated} skift ble opprettet for ${ansatteMedMaler} ansatte (${genererUker} uker). Ferie/fravær er inkludert som egne skift.`,
        });
      }
      
      setShowGenererDialog(false);
      handleSkiftUpdate();
    } catch (error: any) {
      console.error("Error generating shifts:", error);
      toast({
        title: "Feil",
        description: error.message || "Kunne ikke generere skift",
        variant: "destructive"
      });
    } finally {
      setGenerating(false);
    }
  };

  if (loading) {
    return <Skeleton className="h-[600px]" />;
  }

  return (
    <div className="space-y-4">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Planlagte timer</p>
                <p className="text-2xl font-bold">{formaterTimer(totals.planned)}</p>
              </div>
              <Clock className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Forventet (stilling)</p>
                <p className="text-2xl font-bold">{formaterTimer(totals.expected)}</p>
              </div>
              <TrendingUp className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avvik</p>
                <p className={`text-2xl font-bold ${totals.variance >= 0 ? 'text-green-600' : 'text-amber-600'}`}>
                  {totals.variance >= 0 ? '+' : ''}{formaterTimer(totals.variance)}
                </p>
              </div>
              <Calendar className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
        <Card className={kritiskeForslag.length > 0 ? 'border-destructive/50' : ''}>
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Bemanningshull</p>
                <p className={`text-2xl font-bold ${kritiskeForslag.length > 0 ? 'text-destructive' : 'text-green-600'}`}>
                  {kritiskeForslag.length}
                </p>
              </div>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    {kritiskeForslag.length > 0 ? (
                      <AlertTriangle className="h-8 w-8 text-destructive" />
                    ) : (
                      <Users className="h-8 w-8 text-muted-foreground" />
                    )}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-80">
                  <div className="space-y-2">
                    <h4 className="font-medium">Bemanningsanalyse</h4>
                    {kritiskeForslag.length === 0 ? (
                      <p className="text-sm text-muted-foreground">Ingen kritiske hull denne uken!</p>
                    ) : (
                      <div className="space-y-1 max-h-48 overflow-y-auto">
                        {kritiskeForslag.slice(0, 5).map((f, i) => (
                          <div key={i} className="text-sm p-2 rounded bg-destructive/10">
                            <strong>{UKEDAGER[f.ukedag - 1]?.lang}</strong> kl. {f.time}:00 - {f.melding}
                          </div>
                        ))}
                        {kritiskeForslag.length > 5 && (
                          <p className="text-xs text-muted-foreground">
                            +{kritiskeForslag.length - 5} flere...
                          </p>
                        )}
                      </div>
                    )}
                  </div>
                </PopoverContent>
              </Popover>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Schedule Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Uke {weekNumber}, {year}
              </CardTitle>
              <CardDescription>
                {format(currentWeekStart, "d. MMMM", { locale: nb })} - {format(addDays(currentWeekStart, 6), "d. MMMM yyyy", { locale: nb })}
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              {canManage && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowGenererDialog(true)}
                >
                  <Wand2 className="h-4 w-4 mr-1" />
                  Generer skift
                </Button>
              )}
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowBemanningsPanel(!showBemanningsPanel)}
                className={showBemanningsPanel ? 'bg-primary/10' : ''}
              >
                <Lightbulb className="h-4 w-4 mr-1" />
                Analyse
              </Button>
              <div className="border-l pl-2 flex items-center gap-1">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setCurrentWeekStart(prev => subWeeks(prev, 4))}
                  title="4 uker tilbake"
                  className="h-9 w-9"
                >
                  <ChevronsLeft className="h-4 w-4" />
                </Button>
                <WeekSelector
                  selectedDate={currentWeekStart}
                  onDateChange={(date) => setCurrentWeekStart(startOfWeek(date, { weekStartsOn: 1 }))}
                />
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setCurrentWeekStart(prev => addWeeks(prev, 4))}
                  title="4 uker frem"
                  className="h-9 w-9"
                >
                  <ChevronsRight className="h-4 w-4" />
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentWeekStart(startOfWeek(new Date(), { weekStartsOn: 1 }))}
                >
                  I dag
                </Button>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4">
            {/* Main schedule grid */}
            <div className={`flex-1 ${showBemanningsPanel ? 'w-2/3' : 'w-full'}`}>
              {ansattData.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">
                  Ingen aktive ansatte med frisørfunksjon funnet.
                </p>
              ) : (
                <ScrollArea className="w-full">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left py-3 px-2 font-medium sticky left-0 bg-background z-10 min-w-[140px]">
                          Ansatt
                        </th>
                        {weekDates.map((date, idx) => {
                          const dateStr = format(date, 'yyyy-MM-dd');
                          const helligdag = helligdager.get(dateStr);
                          const erSondag = isSunday(date);
                          const apning = apningstider.find(a => a.ukedag === idx + 1);
                          const erStengt = apning?.stengt || false;

                          return (
                            <th 
                              key={idx} 
                              className={`text-center py-3 px-2 font-medium min-w-[100px] ${
                                erSondag || helligdag ? 'bg-muted/50' : ''
                              }`}
                            >
                              <div>{UKEDAGER[idx]?.kort}</div>
                              <div className="text-xs text-muted-foreground font-normal">
                                {format(date, "d/M")}
                              </div>
                              {helligdag && (
                                <Badge variant="secondary" className="text-xs mt-1 truncate max-w-[80px]">
                                  {helligdag}
                                </Badge>
                              )}
                              {erStengt && !helligdag && (
                                <Badge variant="outline" className="text-xs mt-1">Stengt</Badge>
                              )}
                            </th>
                          );
                        })}
                        <th className="text-center py-3 px-2 font-medium min-w-[100px]">Timer</th>
                      </tr>
                    </thead>
                    <tbody>
                      {ansattData.map(({ ansatt, skift, ukeTimer, forventetTimer }) => {
                        const variance = ukeTimer - forventetTimer;
                        const fillPercent = Math.min(100, (ukeTimer / forventetTimer) * 100);

                        return (
                          <tr key={ansatt.id} className="border-b hover:bg-muted/30">
                            <td className="py-2 px-2 sticky left-0 bg-background z-10">
                              <div className="font-medium truncate max-w-[130px]">
                                {ansatt.fornavn} {ansatt.etternavn?.charAt(0)}.
                              </div>
                              <div className="text-xs text-muted-foreground">
                                {ansatt.stillingsprosent || 100}%
                              </div>
                            </td>
                            {weekDates.map((date, idx) => {
                              const dateStr = format(date, 'yyyy-MM-dd');
                              const dagSkift = skift.get(dateStr);
                              const helligdag = helligdager.get(dateStr);
                              const apning = apningstider.find(a => a.ukedag === idx + 1);
                              const ansattFerie = ferieMap.get(ansatt.id);
                              const legacyFerieType = ansattFerie?.get(dateStr);
                              // Check if shift is a vacation shift (kilde='ferie') OR legacy ferie data
                              const erFerieSkift = dagSkift?.kilde === 'ferie' || dagSkift?.kilde === 'fravaer';
                              const ferieType = erFerieSkift ? (dagSkift?.notat || 'Ferie') : legacyFerieType;

                              return (
                                <td key={idx} className="p-1">
                                  <SkiftCelle
                                    ansattId={ansatt.id}
                                    userId={ansatt.user_id || ''}
                                    salonId={salonId}
                                    dato={date}
                                    skift={dagSkift}
                                    erHelligdag={!!helligdag}
                                    helligdagNavn={helligdag}
                                    erStengt={apning?.stengt || false}
                                    erFerie={!!ferieType || erFerieSkift}
                                    ferieType={ferieType}
                                    canManage={canManage}
                                    onUpdate={handleSkiftUpdate}
                                  />
                                </td>
                              );
                            })}
                            <td className="py-2 px-2">
                              <div className="space-y-1">
                                <div className="flex items-center justify-between text-xs">
                                  <span>{formaterTimer(ukeTimer)}</span>
                                  <span className={`font-medium ${variance >= 0 ? 'text-green-600' : 'text-amber-600'}`}>
                                    {variance >= 0 ? '+' : ''}{variance.toFixed(1)}
                                  </span>
                                </div>
                                <Progress value={fillPercent} className="h-1.5" />
                                <div className="text-xs text-muted-foreground text-center">
                                  av {formaterTimer(forventetTimer)}
                                </div>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                  <ScrollBar orientation="horizontal" />
                </ScrollArea>
              )}
            </div>

            {/* Staffing analysis panel */}
            {showBemanningsPanel && (
              <div className="w-1/3 min-w-[280px]">
                <BemanningsPanel
                  forslag={bemanningsForslag}
                  apningstider={apningstider}
                  onClose={() => setShowBemanningsPanel(false)}
                />
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Generate Shifts Dialog */}
      <Dialog open={showGenererDialog} onOpenChange={setShowGenererDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Wand2 className="h-5 w-5" />
              Generer skift fra turnus
            </DialogTitle>
            <DialogDescription>
              Opprett skift for alle ansatte basert på deres turnusmaler (satt under "Ansatte"-fanen).
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Startuke</Label>
              <p className="text-sm text-muted-foreground">
                Uke {weekNumber}, {year} ({format(currentWeekStart, "d. MMM", { locale: nb })})
              </p>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="antall-uker">Antall uker fremover</Label>
              <Input
                id="antall-uker"
                type="number"
                min="1"
                max="52"
                value={genererUker}
                onChange={(e) => setGenererUker(parseInt(e.target.value) || 4)}
              />
              <p className="text-xs text-muted-foreground">
                Skift genereres for {genererUker} uke{genererUker > 1 ? 'r' : ''} fra og med uke {weekNumber}.
              </p>
            </div>

            <div className="rounded-lg bg-muted/50 p-3 text-sm">
              <p className="font-medium mb-1">OBS!</p>
              <p className="text-muted-foreground">
                Eksisterende skift i perioden vil bli slettet og erstattet med nye basert på turnusmaler.
              </p>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowGenererDialog(false)}>
              Avbryt
            </Button>
            <Button onClick={handleGenererSkift} disabled={generating}>
              {generating && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Generer skift
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
