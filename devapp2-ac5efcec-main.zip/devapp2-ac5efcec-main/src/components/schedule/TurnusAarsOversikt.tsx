// TurnusAarsOversikt - Viser turnus-basert stillingsoversikt for alle ansatte
import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { 
  Users, 
  ChevronDown, 
  CheckCircle2, 
  AlertTriangle, 
  Info,
  Clock,
  Calendar
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { getTurnusAnsatte, type AnsattUtvidet } from "@/integrations/supabase/ansatteService";
import { 
  beregnGjennomsnittTurnus, 
  getTurnusTypeLabel,
  FULL_STILLING_TIMER,
  ARSVERK_TIMER,
  type TurnusType,
  type WeekPreference 
} from "@/lib/turnusUtils";

interface TurnusAarsOversiktProps {
  salonId: string;
  year: number;
}

interface AnsattTurnusBeregning {
  ansatt: AnsattUtvidet;
  turnusType: TurnusType;
  gjennomsnittTimer: number;
  beregnetStillingsprosent: number;
  avtaltStillingsprosent: number;
  avvik: number;
  arbeidsdagerPerUke: number;
  ukerDetaljer: Array<{
    ukeType: string;
    timer: number;
    prosent: number;
    arbeidsdager: number;
  }>;
}

export function TurnusAarsOversikt({ salonId, year }: TurnusAarsOversiktProps) {
  const [expandedRows, setExpandedRows] = useState<Set<string>>(new Set());

  // Hent ansatte med turnus-inkludering
  const { data: ansatte, isLoading: ansatteLoading } = useQuery({
    queryKey: ['turnus-ansatte', salonId],
    queryFn: () => getTurnusAnsatte(salonId),
    enabled: !!salonId
  });

  // Hent alle turnusmaler for salongen
  const { data: turnusData, isLoading: turnusLoading } = useQuery({
    queryKey: ['turnus-maler', salonId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("ansatt_turnus")
        .select("*")
        .eq("salon_id", salonId)
        .is("gyldig_til", null);

      if (error) throw error;
      return data;
    },
    enabled: !!salonId
  });

  // Beregn turnus-data per ansatt
  const beregninger = useMemo<AnsattTurnusBeregning[]>(() => {
    if (!ansatte?.length || !turnusData) return [];

    return ansatte.map(ansatt => {
      // Hent unike turnusmaler for denne ansatten (basert på ansatt_id)
      const ansattTurnus = turnusData.filter(t => t.ansatt_id === ansatt.id);
      
      if (ansattTurnus.length === 0) {
        return {
          ansatt,
          turnusType: 'enkel' as TurnusType,
          gjennomsnittTimer: 0,
          beregnetStillingsprosent: 0,
          avtaltStillingsprosent: ansatt.stillingsprosent,
          avvik: -ansatt.stillingsprosent,
          arbeidsdagerPerUke: 0,
          ukerDetaljer: []
        };
      }

      // Finn unike maler per uke_type + ukedag kombinasjon
      const uniqueTemplates = new Map<string, typeof ansattTurnus[0]>();
      ansattTurnus.forEach(t => {
        const key = `${t.uke_type || 'alle'}-${t.ukedag}`;
        // Behold kun den første (nyeste) for hver kombinasjon
        if (!uniqueTemplates.has(key)) {
          uniqueTemplates.set(key, t);
        }
      });

      const uniqueTurnusList = Array.from(uniqueTemplates.values());

      // Detekter turnustype fra unike maler
      const hasUke1 = uniqueTurnusList.some(t => t.uke_type === 'uke1');
      const hasUke2 = uniqueTurnusList.some(t => t.uke_type === 'uke2');
      const hasUke3 = uniqueTurnusList.some(t => t.uke_type === 'uke3');
      const hasPartall = uniqueTurnusList.some(t => t.uke_type === 'partall');
      const hasOddetall = uniqueTurnusList.some(t => t.uke_type === 'oddetall');

      let turnusType: TurnusType = 'enkel';
      if (hasUke1 || hasUke2 || hasUke3) {
        turnusType = 'treuke';
      } else if (hasPartall || hasOddetall) {
        turnusType = 'touke';
      }

      // Grupper preferanser per uketype
      const preferanserPerUke: Record<string, WeekPreference[]> = {};
      
      for (const turnus of uniqueTurnusList) {
        const ukeType = turnus.uke_type || 'alle';
        if (!preferanserPerUke[ukeType]) {
          preferanserPerUke[ukeType] = [];
        }
        preferanserPerUke[ukeType].push({
          ukedag: turnus.ukedag,
          jobber: !turnus.fridag,
          onsket_start_tid: turnus.start_tid,
          onsket_slutt_tid: turnus.slutt_tid
        });
      }

      // Beregn gjennomsnitt
      const beregning = beregnGjennomsnittTurnus(turnusType, preferanserPerUke);

      // Beregn arbeidsdager per uketype
      const ukerDetaljer = beregning.ukerDetaljer.map(uke => ({
        ...uke,
        arbeidsdager: (preferanserPerUke[uke.ukeType] || []).filter(p => p.jobber).length
      }));

      // Beregn gjennomsnittlig arbeidsdager per uke
      const totalArbeidsdager = ukerDetaljer.reduce((sum, u) => sum + u.arbeidsdager, 0);
      const antallUker = ukerDetaljer.length || 1;
      const arbeidsdagerPerUke = Math.round((totalArbeidsdager / antallUker) * 10) / 10;

      return {
        ansatt,
        turnusType,
        gjennomsnittTimer: beregning.gjennomsnittTimer,
        beregnetStillingsprosent: beregning.stillingsprosent,
        avtaltStillingsprosent: ansatt.stillingsprosent,
        avvik: beregning.stillingsprosent - ansatt.stillingsprosent,
        arbeidsdagerPerUke,
        ukerDetaljer
      };
    }).sort((a, b) => {
      const nameA = `${a.ansatt.fornavn} ${a.ansatt.etternavn || ''}`.toLowerCase();
      const nameB = `${b.ansatt.fornavn} ${b.ansatt.etternavn || ''}`.toLowerCase();
      return nameA.localeCompare(nameB, 'nb');
    });
  }, [ansatte, turnusData]);

  const toggleExpanded = (id: string) => {
    const newExpanded = new Set(expandedRows);
    if (newExpanded.has(id)) {
      newExpanded.delete(id);
    } else {
      newExpanded.add(id);
    }
    setExpandedRows(newExpanded);
  };

  const getStatusBadge = (avvik: number, harTurnus: boolean) => {
    if (!harTurnus) {
      return (
        <Badge variant="outline" className="text-muted-foreground">
          <Info className="h-3 w-3 mr-1" />
          Ingen turnus
        </Badge>
      );
    }
    
    const absAvvik = Math.abs(avvik);
    if (absAvvik <= 2) {
      return (
        <Badge variant="default" className="bg-green-500/10 text-green-700 border-green-200">
          <CheckCircle2 className="h-3 w-3 mr-1" />
          OK
        </Badge>
      );
    }
    if (absAvvik <= 5) {
      return (
        <Badge variant="secondary" className="bg-amber-500/10 text-amber-700 border-amber-200">
          <Info className="h-3 w-3 mr-1" />
          Lite avvik
        </Badge>
      );
    }
    return (
      <Badge variant="destructive" className="bg-destructive/10">
        <AlertTriangle className="h-3 w-3 mr-1" />
        Stort avvik
      </Badge>
    );
  };

  const getUkeTypeLabel = (ukeType: string) => {
    switch (ukeType) {
      case 'partall': return 'Partallsuke';
      case 'oddetall': return 'Oddetallsuke';
      case 'uke1': return 'Uke 1';
      case 'uke2': return 'Uke 2';
      case 'uke3': return 'Uke 3';
      case 'alle': return 'Hver uke';
      default: return ukeType;
    }
  };

  // Statistikk
  const stats = useMemo(() => {
    const medTurnus = beregninger.filter(b => b.gjennomsnittTimer > 0);
    const stortAvvik = beregninger.filter(b => Math.abs(b.avvik) > 5 && b.gjennomsnittTimer > 0);
    const utenTurnus = beregninger.filter(b => b.gjennomsnittTimer === 0);
    
    return {
      totalt: beregninger.length,
      medTurnus: medTurnus.length,
      stortAvvik: stortAvvik.length,
      utenTurnus: utenTurnus.length
    };
  }, [beregninger]);

  if (ansatteLoading || turnusLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-48" />
          <Skeleton className="h-4 w-72 mt-2" />
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[1, 2, 3].map(i => (
              <Skeleton key={i} className="h-16 w-full" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Turnusbasert stillingsoversikt – {year}
            </CardTitle>
            <CardDescription>
              Sammenligning mellom avtalt stilling og faktisk turnus
            </CardDescription>
          </div>
        </div>
        
        {/* Statistikk-badges */}
        <div className="flex flex-wrap gap-2 mt-4">
          <Badge variant="outline">
            {stats.totalt} ansatte
          </Badge>
          <Badge variant="outline" className="bg-green-500/10 text-green-700 border-green-200">
            {stats.medTurnus} med turnus
          </Badge>
          {stats.stortAvvik > 0 && (
            <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20">
              {stats.stortAvvik} med stort avvik
            </Badge>
          )}
          {stats.utenTurnus > 0 && (
            <Badge variant="outline" className="text-muted-foreground">
              {stats.utenTurnus} uten turnus
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {beregninger.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Users className="h-12 w-12 mx-auto mb-3 opacity-50" />
            <p>Ingen ansatte funnet for denne salongen</p>
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[200px]">Ansatt</TableHead>
                <TableHead>Turnus</TableHead>
                <TableHead className="text-right">Timer/uke</TableHead>
                <TableHead className="text-right">Dager/uke</TableHead>
                <TableHead className="text-right">Beregnet %</TableHead>
                <TableHead className="text-right">Avtalt %</TableHead>
                <TableHead className="text-center">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {beregninger.map((b) => {
                const isExpanded = expandedRows.has(b.ansatt.id);
                const fullName = `${b.ansatt.fornavn} ${b.ansatt.etternavn || ''}`.trim();
                const harTurnus = b.gjennomsnittTimer > 0;
                
                return (
                  <Collapsible key={b.ansatt.id} asChild open={isExpanded}>
                    <>
                      <CollapsibleTrigger asChild>
                        <TableRow 
                          className="cursor-pointer hover:bg-muted/50"
                          onClick={() => toggleExpanded(b.ansatt.id)}
                        >
                          <TableCell className="font-medium">
                            <div className="flex items-center gap-2">
                              <ChevronDown 
                                className={`h-4 w-4 text-muted-foreground transition-transform ${
                                  isExpanded ? 'rotate-180' : ''
                                }`}
                              />
                              {fullName}
                            </div>
                          </TableCell>
                          <TableCell>
                            {harTurnus ? (
                              <Badge variant="secondary" className="text-xs">
                                {getTurnusTypeLabel(b.turnusType)}
                              </Badge>
                            ) : (
                              <span className="text-muted-foreground text-sm">–</span>
                            )}
                          </TableCell>
                          <TableCell className="text-right font-mono">
                            {harTurnus ? `${b.gjennomsnittTimer}t` : '–'}
                          </TableCell>
                          <TableCell className="text-right font-mono">
                            {harTurnus ? b.arbeidsdagerPerUke : '–'}
                          </TableCell>
                          <TableCell className="text-right font-mono">
                            {harTurnus ? `${b.beregnetStillingsprosent}%` : '–'}
                          </TableCell>
                          <TableCell className="text-right font-mono">
                            {b.avtaltStillingsprosent}%
                          </TableCell>
                          <TableCell className="text-center">
                            {getStatusBadge(b.avvik, harTurnus)}
                          </TableCell>
                        </TableRow>
                      </CollapsibleTrigger>
                      <CollapsibleContent asChild>
                        <TableRow className="bg-muted/30 hover:bg-muted/30">
                          <TableCell colSpan={7} className="p-0">
                            <div className="p-4 space-y-4">
                              {/* Avvik-varsel */}
                              {harTurnus && Math.abs(b.avvik) > 2 && (
                                <div className={`p-3 rounded-lg ${
                                  Math.abs(b.avvik) > 5 
                                    ? 'bg-destructive/10 text-destructive' 
                                    : 'bg-amber-500/10 text-amber-700'
                                }`}>
                                  <p className="text-sm font-medium">
                                    {b.avvik > 0
                                      ? `⚠️ Turnus er ${Math.abs(b.avvik).toFixed(1)}% høyere enn avtalt stilling`
                                      : `⚠️ Turnus er ${Math.abs(b.avvik).toFixed(1)}% lavere enn avtalt stilling`
                                    }
                                  </p>
                                </div>
                              )}

                              {/* Uketype-detaljer */}
                              {harTurnus && b.ukerDetaljer.length > 0 && (
                                <div className="grid gap-2 max-w-md">
                                  <p className="text-sm font-medium text-muted-foreground">
                                    Turnus-detaljer
                                  </p>
                                  {b.ukerDetaljer.map((uke) => (
                                    <div
                                      key={uke.ukeType}
                                      className="flex items-center justify-between text-sm p-2 bg-background rounded border"
                                    >
                                      <span className="flex items-center gap-2">
                                        <Calendar className="h-3 w-3 text-muted-foreground" />
                                        {getUkeTypeLabel(uke.ukeType)}
                                      </span>
                                      <span className="flex items-center gap-4 font-mono">
                                        <span className="text-muted-foreground">
                                          {uke.arbeidsdager} dager
                                        </span>
                                        <span>
                                          {uke.timer.toFixed(1)}t ({uke.prosent.toFixed(0)}%)
                                        </span>
                                      </span>
                                    </div>
                                  ))}
                                </div>
                              )}

                              {/* Årsberegning */}
                              {harTurnus && (
                                <div className="grid gap-2 max-w-md">
                                  <p className="text-sm font-medium text-muted-foreground">
                                    Årsberegning (estimat)
                                  </p>
                                  <div className="p-3 bg-background rounded border space-y-2">
                                    <div className="flex justify-between text-sm">
                                      <span>Forventet årstimer fra turnus</span>
                                      <span className="font-mono">
                                        {Math.round(b.gjennomsnittTimer * (ARSVERK_TIMER / FULL_STILLING_TIMER))}t
                                      </span>
                                    </div>
                                    <div className="flex justify-between text-sm border-t pt-2 mt-2">
                                      <span className="text-muted-foreground">100% stilling (norsk standard)</span>
                                      <span className="font-mono text-muted-foreground">
                                        {ARSVERK_TIMER}t
                                      </span>
                                    </div>
                                    <p className="text-xs text-muted-foreground">
                                      52 uker − 5 ferie − ~10 helligdager = {ARSVERK_TIMER}t
                                    </p>
                                  </div>
                                </div>
                              )}

                              {!harTurnus && (
                                <div className="text-sm text-muted-foreground">
                                  Ingen aktiv turnusmal registrert for denne ansatten.
                                </div>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      </CollapsibleContent>
                    </>
                  </Collapsible>
                );
              })}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}
