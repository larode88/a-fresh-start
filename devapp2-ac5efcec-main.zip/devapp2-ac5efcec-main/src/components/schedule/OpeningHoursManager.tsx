import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Save, Loader2, Clock, Users, ChevronDown, Info, CalendarDays, Plus, Trash2, CalendarOff, Timer, TreePine, Pencil } from "lucide-react";
import { TimeBasedStaffingEditor } from "./TimeBasedStaffingEditor";
import { format, startOfYear, endOfYear, addYears } from "date-fns";
import { nb } from "date-fns/locale";

interface Holiday {
  dato: string;
  helligdag_navn: string;
}

interface OpeningHoursManagerProps {
  salonId: string;
  year: number;
}

interface DayHours {
  id?: string;
  ukedag: number;
  apner: string;
  stenger: string;
  stengt: boolean;
  merknad: string;
}

interface Exception {
  id: string;
  dato: string;
  stengt: boolean;
  apner: string | null;
  stenger: string | null;
  arsak: string | null;
  min_bemanning: number | null;
  ideell_bemanning: number | null;
}

const WEEKDAYS = [
  { value: 1, label: "Mandag", short: "Man" },
  { value: 2, label: "Tirsdag", short: "Tir" },
  { value: 3, label: "Onsdag", short: "Ons" },
  { value: 4, label: "Torsdag", short: "Tor" },
  { value: 5, label: "Fredag", short: "Fre" },
  { value: 6, label: "Lørdag", short: "Lør" },
  { value: 7, label: "Søndag", short: "Søn" },
];

export function OpeningHoursManager({ salonId, year }: OpeningHoursManagerProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [hours, setHours] = useState<DayHours[]>([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  
  // Holidays from calendar
  const [holidays, setHolidays] = useState<Holiday[]>([]);
  
  // Exceptions state
  const [exceptions, setExceptions] = useState<Exception[]>([]);
  const [showExceptionDialog, setShowExceptionDialog] = useState(false);
  const [editingException, setEditingException] = useState<Exception | null>(null);
  const [newException, setNewException] = useState<{
    dato: Date | undefined;
    stengt: boolean;
    apner: string;
    stenger: string;
    arsak: string;
    min_bemanning: number;
    ideell_bemanning: number;
  }>({
    dato: undefined,
    stengt: true,
    apner: "09:00",
    stenger: "17:00",
    arsak: "",
    min_bemanning: 2,
    ideell_bemanning: 3
  });

  const resetExceptionForm = () => {
    setNewException({
      dato: undefined,
      stengt: true,
      apner: "09:00",
      stenger: "17:00",
      arsak: "",
      min_bemanning: 2,
      ideell_bemanning: 3
    });
    setEditingException(null);
  };

  const openEditDialog = (exc: Exception) => {
    setEditingException(exc);
    setNewException({
      dato: new Date(exc.dato),
      stengt: exc.stengt,
      apner: exc.apner || "09:00",
      stenger: exc.stenger || "17:00",
      arsak: exc.arsak || "",
      min_bemanning: exc.min_bemanning ?? 2,
      ideell_bemanning: exc.ideell_bemanning ?? 3
    });
    setShowExceptionDialog(true);
  };

  const openHolidayDialog = (holiday: Holiday) => {
    // Check if there's already an exception for this holiday
    const existingException = exceptions.find(e => e.dato === holiday.dato);
    
    if (existingException) {
      openEditDialog(existingException);
    } else {
      // Create new exception for holiday - default to open with modified hours
      setEditingException(null);
      setNewException({
        dato: new Date(holiday.dato),
        stengt: false,
        apner: "10:00",
        stenger: "16:00",
        arsak: `Åpent på ${holiday.helligdag_navn}`,
        min_bemanning: 1,
        ideell_bemanning: 2
      });
      setShowExceptionDialog(true);
    }
  };

  // Helper to check if a holiday has an override exception
  const getHolidayException = (holidayDate: string): Exception | undefined => {
    return exceptions.find(e => e.dato === holidayDate);
  };

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        // Fetch opening hours
        const { data: hoursData, error: hoursError } = await supabase
          .from("salong_apningstider")
          .select("*")
          .eq("salon_id", salonId)
          .order("ukedag");

        if (hoursError) throw hoursError;

        // Fetch exceptions for selected year
        const yearStart = `${year}-01-01`;
        const yearEnd = `${year}-12-31`;
        
        const { data: exceptionsData, error: exceptionsError } = await supabase
          .from("salong_apningstider_unntak")
          .select("*")
          .eq("salon_id", salonId)
          .gte("dato", yearStart)
          .lte("dato", yearEnd)
          .order("dato");

        if (exceptionsError) throw exceptionsError;

        // Fetch holidays from kalender table for selected year
        const { data: holidaysData, error: holidaysError } = await supabase
          .from("kalender")
          .select("dato, helligdag_navn")
          .gte("dato", yearStart)
          .lte("dato", yearEnd)
          .eq("er_helligdag", true)
          .not("helligdag_navn", "is", null)
          .order("dato");

        if (holidaysError) throw holidaysError;

        // Initialize all days with defaults if not exist
        const existingDays = new Map(hoursData?.map(d => [d.ukedag, d]) || []);
        const allDays: DayHours[] = WEEKDAYS.map(day => {
          const existing = existingDays.get(day.value);
          if (existing) {
            return {
              id: existing.id,
              ukedag: existing.ukedag,
              apner: existing.apner || "09:00",
              stenger: existing.stenger || "17:00",
              stengt: existing.stengt || false,
              merknad: existing.merknad || "",
            };
          }
          const isSunday = day.value === 7;
          const isSaturday = day.value === 6;
          return {
            ukedag: day.value,
            apner: isSaturday ? "10:00" : "09:00",
            stenger: isSaturday ? "16:00" : "17:00",
            stengt: isSunday,
            merknad: "",
          };
        });

        setHours(allDays);
        setExceptions(exceptionsData || []);
        setHolidays((holidaysData || []).map(h => ({ dato: h.dato, helligdag_navn: h.helligdag_navn || '' })));
      } catch (error) {
        console.error("Error fetching data:", error);
        toast({
          title: "Feil",
          description: "Kunne ikke hente data",
          variant: "destructive"
        });
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [salonId, year]);

  const updateHours = (ukedag: number, field: keyof DayHours, value: string | boolean | number) => {
    setHours(prev => prev.map(h => 
      h.ukedag === ukedag ? { ...h, [field]: value } : h
    ));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      for (const day of hours) {
        const payload = {
          apner: day.apner,
          stenger: day.stenger,
          stengt: day.stengt,
          merknad: day.merknad || null,
        };

        if (day.id) {
          await supabase
            .from("salong_apningstider")
            .update(payload)
            .eq("id", day.id);
        } else {
          const { data } = await supabase
            .from("salong_apningstider")
            .insert({ salon_id: salonId, ukedag: day.ukedag, ...payload })
            .select()
            .single();

          if (data) {
            setHours(prev => prev.map(h => 
              h.ukedag === day.ukedag ? { ...h, id: data.id } : h
            ));
          }
        }
      }

      toast({
        title: "Lagret",
        description: "Åpningstider er oppdatert"
      });
    } catch (error) {
      console.error("Error saving hours:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke lagre åpningstider",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const handleSaveException = async () => {
    if (!newException.dato) return;

    const payload = {
      salon_id: salonId,
      dato: format(newException.dato, "yyyy-MM-dd"),
      stengt: newException.stengt,
      apner: newException.stengt ? null : newException.apner,
      stenger: newException.stengt ? null : newException.stenger,
      arsak: newException.arsak || null,
      min_bemanning: newException.stengt ? null : newException.min_bemanning,
      ideell_bemanning: newException.stengt ? null : newException.ideell_bemanning
    };

    try {
      if (editingException) {
        // Update existing exception
        const { data, error } = await supabase
          .from("salong_apningstider_unntak")
          .update(payload)
          .eq("id", editingException.id)
          .select()
          .single();

        if (error) throw error;

        setExceptions(prev => 
          prev.map(e => e.id === editingException.id ? data : e).sort((a, b) => a.dato.localeCompare(b.dato))
        );
        toast({ title: "Unntak oppdatert" });
      } else {
        // Create new exception
        const { data, error } = await supabase
          .from("salong_apningstider_unntak")
          .insert(payload)
          .select()
          .single();

        if (error) throw error;

        setExceptions(prev => [...prev, data].sort((a, b) => a.dato.localeCompare(b.dato)));
        toast({ title: "Unntak lagt til" });
      }

      setShowExceptionDialog(false);
      resetExceptionForm();
    } catch (error) {
      console.error("Error saving exception:", error);
      toast({
        title: "Feil",
        description: editingException ? "Kunne ikke oppdatere unntak" : "Kunne ikke legge til unntak",
        variant: "destructive"
      });
    }
  };

  const handleDeleteException = async (id: string) => {
    try {
      const { error } = await supabase
        .from("salong_apningstider_unntak")
        .delete()
        .eq("id", id);

      if (error) throw error;

      setExceptions(prev => prev.filter(e => e.id !== id));
      toast({ title: "Unntak slettet" });
    } catch (error) {
      console.error("Error deleting exception:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke slette unntak",
        variant: "destructive"
      });
    }
  };

  // Calculate weekly totals
  const totalOpenHours = hours
    .filter(h => !h.stengt)
    .reduce((sum, h) => {
      const [startH, startM] = h.apner.split(':').map(Number);
      const [endH, endM] = h.stenger.split(':').map(Number);
      return sum + (endH + endM / 60) - (startH + startM / 60);
    }, 0);

  if (loading) {
    return <Skeleton className="h-96" />;
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Åpningstider & Unntak
            </CardTitle>
            <CardDescription>
              Sett standard åpningstider og unntak for helligdager
            </CardDescription>
          </div>
        </div>
        
        <div className="flex gap-2 pt-2">
          <Badge variant="secondary" className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            {totalOpenHours.toFixed(0)} åpningstimer/uke
          </Badge>
          {exceptions.length > 0 && (
            <Badge variant="outline" className="flex items-center gap-1">
              <CalendarOff className="h-3 w-3" />
              {exceptions.length} unntak
            </Badge>
          )}
        </div>
      </CardHeader>

      <CardContent>
        <Tabs defaultValue="hours" className="space-y-4">
          <TabsList>
            <TabsTrigger value="hours">Åpningstider</TabsTrigger>
            <TabsTrigger value="staffing">Bemanningskrav per time</TabsTrigger>
            <TabsTrigger value="exceptions">Unntak & Helligdager</TabsTrigger>
          </TabsList>

          <TabsContent value="hours" className="space-y-4">
            {/* Main schedule grid */}
            <div className="space-y-2">
              {hours.map(day => {
                const weekday = WEEKDAYS.find(w => w.value === day.ukedag);
                const [startH] = day.apner.split(':').map(Number);
                const [endH] = day.stenger.split(':').map(Number);
                const dayHours = day.stengt ? 0 : endH - startH;

                return (
                  <div
                    key={day.ukedag}
                    className={`flex flex-wrap items-center gap-4 p-4 rounded-lg border ${
                      day.stengt ? 'bg-muted/30 border-muted' : 'bg-card border-border'
                    }`}
                  >
                    <div className="w-24 font-medium flex items-center gap-2">
                      <span>{weekday?.label}</span>
                      {!day.stengt && (
                        <Badge variant="outline" className="text-xs">
                          {dayHours}t
                        </Badge>
                      )}
                    </div>
                    
                    <div className="flex items-center gap-2 min-w-28">
                      <Switch
                        checked={!day.stengt}
                        onCheckedChange={(checked) => updateHours(day.ukedag, "stengt", !checked)}
                      />
                      <span className={`text-sm ${day.stengt ? 'text-muted-foreground' : 'text-foreground'}`}>
                        {day.stengt ? "Stengt" : "Åpent"}
                      </span>
                    </div>

                    {!day.stengt && (
                      <>
                        <div className="flex items-center gap-2">
                          <Label className="text-sm text-muted-foreground">Fra:</Label>
                          <Input
                            type="time"
                            value={day.apner}
                            onChange={(e) => updateHours(day.ukedag, "apner", e.target.value)}
                            className="w-28"
                          />
                        </div>
                        <div className="flex items-center gap-2">
                          <Label className="text-sm text-muted-foreground">Til:</Label>
                          <Input
                            type="time"
                            value={day.stenger}
                            onChange={(e) => updateHours(day.ukedag, "stenger", e.target.value)}
                            className="w-28"
                          />
                        </div>
                      </>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Notes per day */}
            <Collapsible open={showAdvanced} onOpenChange={setShowAdvanced}>
              <CollapsibleTrigger asChild>
                <Button variant="ghost" className="w-full justify-between">
                  <span className="flex items-center gap-2">
                    <Info className="h-4 w-4" />
                    Merknader per dag
                  </span>
                  <ChevronDown className={`h-4 w-4 transition-transform ${showAdvanced ? 'rotate-180' : ''}`} />
                </Button>
              </CollapsibleTrigger>
              <CollapsibleContent className="pt-4 space-y-3">
                {hours.filter(h => !h.stengt).map(day => {
                  const weekday = WEEKDAYS.find(w => w.value === day.ukedag);
                  return (
                    <div key={day.ukedag} className="flex items-start gap-3">
                      <Label className="w-24 pt-2">{weekday?.label}</Label>
                      <Textarea
                        placeholder="F.eks. 'Ekstra travel dag', 'Lærling trenger veileder'"
                        value={day.merknad}
                        onChange={(e) => updateHours(day.ukedag, "merknad", e.target.value)}
                        className="flex-1 min-h-[60px]"
                      />
                    </div>
                  );
                })}
              </CollapsibleContent>
            </Collapsible>

            <div className="flex justify-end">
              <Button onClick={handleSave} disabled={saving}>
                {saving ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Save className="h-4 w-4 mr-2" />
                )}
                Lagre åpningstider
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="staffing" className="space-y-4">
            <TimeBasedStaffingEditor salonId={salonId} />
          </TabsContent>

          <TabsContent value="exceptions" className="space-y-6">
            {/* Helligdager section */}
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <TreePine className="h-5 w-5 text-primary" />
                <h3 className="font-medium">Helligdager</h3>
                <Badge variant="secondary" className="text-xs">{holidays.length} dager</Badge>
              </div>
              <p className="text-sm text-muted-foreground">
                Norske helligdager hentes automatisk. Skift genereres ikke på disse dagene.
              </p>
              {holidays.length === 0 ? (
                <div className="text-center py-4 border rounded-lg bg-muted/20">
                  <p className="text-sm text-muted-foreground">Ingen helligdager i perioden</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
                  {holidays.map(holiday => {
                    const override = getHolidayException(holiday.dato);
                    const isOpen = override && !override.stengt;
                    
                    return (
                      <div
                        key={holiday.dato}
                        className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-shadow hover:shadow-md ${
                          isOpen 
                            ? 'bg-green-500/10 border-green-500/30' 
                            : 'bg-primary/5 border-primary/20'
                        }`}
                        onClick={() => openHolidayDialog(holiday)}
                      >
                        <div className="text-center min-w-[40px]">
                          <div className="text-lg font-bold">
                            {format(new Date(holiday.dato), "d")}
                          </div>
                          <div className="text-[10px] text-muted-foreground uppercase">
                            {format(new Date(holiday.dato), "MMM", { locale: nb })}
                          </div>
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium truncate">{holiday.helligdag_navn}</p>
                          <p className="text-xs text-muted-foreground">
                            {format(new Date(holiday.dato), "EEEE yyyy", { locale: nb })}
                          </p>
                          {isOpen && override && (
                            <p className="text-xs text-green-600 mt-0.5">
                              {override.apner} - {override.stenger}
                            </p>
                          )}
                        </div>
                        {isOpen ? (
                          <Badge variant="default" className="text-xs shrink-0 bg-green-600">
                            Åpent
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="text-xs shrink-0">
                            Stengt
                          </Badge>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Custom exceptions section */}
            <div className="space-y-3 pt-4 border-t">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CalendarOff className="h-5 w-5 text-muted-foreground" />
                  <h3 className="font-medium">Egne unntak</h3>
                  {exceptions.filter(e => !holidays.some(h => h.dato === e.dato)).length > 0 && (
                    <Badge variant="secondary" className="text-xs">
                      {exceptions.filter(e => !holidays.some(h => h.dato === e.dato)).length}
                    </Badge>
                  )}
                </div>
                <Button onClick={() => {
                  resetExceptionForm();
                  setShowExceptionDialog(true);
                }}>
                  <Plus className="h-4 w-4 mr-2" />
                  Legg til unntak
                </Button>
              </div>
              <p className="text-sm text-muted-foreground">
                Klikk på en helligdag for å endre status. Legg til egne unntak for feriestengning, kurs-dager eller endrede åpningstider.
              </p>

              {exceptions.filter(e => !holidays.some(h => h.dato === e.dato)).length === 0 ? (
                <div className="text-center py-6 border rounded-lg bg-muted/20">
                  <CalendarOff className="h-10 w-10 text-muted-foreground mx-auto mb-2" />
                  <p className="text-muted-foreground text-sm">Ingen egne unntak registrert</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {exceptions.filter(e => !holidays.some(h => h.dato === e.dato)).map(exc => (
                    <div
                      key={exc.id}
                      className={`flex items-center justify-between p-4 rounded-lg border cursor-pointer transition-shadow hover:shadow-md ${
                        exc.stengt ? 'bg-destructive/5 border-destructive/20' : 'bg-primary/5 border-primary/20'
                      }`}
                      onClick={() => openEditDialog(exc)}
                    >
                      <div className="flex items-center gap-4">
                        <div className="text-center">
                          <div className="text-2xl font-bold">
                            {format(new Date(exc.dato), "d")}
                          </div>
                          <div className="text-xs text-muted-foreground uppercase">
                            {format(new Date(exc.dato), "MMM", { locale: nb })}
                          </div>
                        </div>
                        <div>
                          <p className="font-medium">
                            {format(new Date(exc.dato), "EEEE", { locale: nb })}
                            {exc.stengt ? (
                              <Badge variant="destructive" className="ml-2 text-xs">Stengt</Badge>
                            ) : (
                              <Badge variant="default" className="ml-2 text-xs">
                                {exc.apner} - {exc.stenger}
                              </Badge>
                            )}
                          </p>
                          {exc.arsak && (
                            <p className="text-sm text-muted-foreground">{exc.arsak}</p>
                          )}
                          {!exc.stengt && exc.min_bemanning && (
                            <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                              <Users className="h-3 w-3" />
                              Min: {exc.min_bemanning} / Ideell: {exc.ideell_bemanning}
                            </p>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={(e) => {
                            e.stopPropagation();
                            openEditDialog(exc);
                          }}
                        >
                          <Pencil className="h-4 w-4 text-muted-foreground hover:text-foreground" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteException(exc.id);
                          }}
                        >
                          <Trash2 className="h-4 w-4 text-muted-foreground hover:text-destructive" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>

      {/* Add/Edit Exception Dialog */}
      <Dialog open={showExceptionDialog} onOpenChange={(open) => {
        setShowExceptionDialog(open);
        if (!open) resetExceptionForm();
      }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingException ? "Rediger unntak" : "Legg til unntak"}</DialogTitle>
            <DialogDescription>
              {editingException 
                ? "Endre åpningstid eller stenging for denne datoen" 
                : "Sett endret åpningstid eller stenging for en spesifikk dato"}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Dato</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start">
                    <CalendarDays className="h-4 w-4 mr-2" />
                    {newException.dato 
                      ? format(newException.dato, "PPP", { locale: nb })
                      : "Velg dato"
                    }
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={newException.dato}
                    onSelect={(date) => setNewException(prev => ({ ...prev, dato: date }))}
                    locale={nb}
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="flex items-center gap-2">
              <Switch
                checked={!newException.stengt}
                onCheckedChange={(checked) => setNewException(prev => ({ ...prev, stengt: !checked }))}
              />
              <Label>{newException.stengt ? "Stengt hele dagen" : "Endret åpningstid"}</Label>
            </div>

            {!newException.stengt && (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Åpner</Label>
                    <Input
                      type="time"
                      value={newException.apner}
                      onChange={(e) => setNewException(prev => ({ ...prev, apner: e.target.value }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Stenger</Label>
                    <Input
                      type="time"
                      value={newException.stenger}
                      onChange={(e) => setNewException(prev => ({ ...prev, stenger: e.target.value }))}
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="flex items-center gap-1">
                      <Users className="h-3 w-3" />
                      Min. bemanning
                    </Label>
                    <Input
                      type="number"
                      min={1}
                      max={10}
                      value={newException.min_bemanning}
                      onChange={(e) => setNewException(prev => ({ ...prev, min_bemanning: parseInt(e.target.value) || 1 }))}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="flex items-center gap-1">
                      <Users className="h-3 w-3" />
                      Ideell bemanning
                    </Label>
                    <Input
                      type="number"
                      min={1}
                      max={15}
                      value={newException.ideell_bemanning}
                      onChange={(e) => setNewException(prev => ({ ...prev, ideell_bemanning: parseInt(e.target.value) || 2 }))}
                    />
                  </div>
                </div>
              </div>
            )}

            <div className="space-y-2">
              <Label>Årsak (valgfri)</Label>
              <Input
                placeholder="F.eks. 'Julaften', 'Sommerferie'"
                value={newException.arsak}
                onChange={(e) => setNewException(prev => ({ ...prev, arsak: e.target.value }))}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setShowExceptionDialog(false);
              resetExceptionForm();
            }}>
              Avbryt
            </Button>
            <Button onClick={handleSaveException} disabled={!newException.dato}>
              {editingException ? "Lagre endringer" : "Legg til"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
