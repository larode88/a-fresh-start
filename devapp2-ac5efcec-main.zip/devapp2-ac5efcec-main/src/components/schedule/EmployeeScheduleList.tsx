import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Users, Edit, Clock, CalendarDays, AlertCircle } from "lucide-react";
import { EmployeeScheduleEditor } from "./EmployeeScheduleEditor";
import { format } from "date-fns";
import { nb } from "date-fns/locale";
import { getTurnusTypeLabel, getUkedagNavn } from "@/lib/turnusUtils";
import { getTurnusAnsatte, type AnsattUtvidet } from "@/integrations/supabase/ansatteService";
import { supabase } from "@/integrations/supabase/client";

interface EmployeeScheduleListProps {
  salonId: string;
  canManage: boolean;
}

interface TurnusPlan {
  id: string;
  ukedag: number;
  start_tid: string | null;
  slutt_tid: string | null;
  fridag: boolean;
  uke_type: string | null;
  gyldig_fra: string;
  pause_minutter: number | null;
}

interface Employee {
  id: string;
  user_id: string | null;
  fornavn: string;
  etternavn: string | null;
  stillingsprosent: number;
  frisorfunksjon: string | null;
  lederstilling: string | null;
  inkluder_i_turnus: boolean;
  effektiv_inkluder_i_turnus: boolean;
  turnusPlaner: TurnusPlan[];
  turnusType: string | null;
}

export function EmployeeScheduleList({ salonId, canManage }: EmployeeScheduleListProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  const fetchEmployees = async () => {
    setLoading(true);
    try {
      // Fetch employees that should be included in schedule
      const ansatte = await getTurnusAnsatte(salonId);

      if (!ansatte.length) {
        setEmployees([]);
        setLoading(false);
        return;
      }

      // Get turnus from ansatt_turnus table (same table the editor saves to)
      const { data: turnusData, error: turnusError } = await supabase
        .from("ansatt_turnus")
        .select("*")
        .eq("salon_id", salonId)
        .is("gyldig_til", null);

      if (turnusError) throw turnusError;

      // Group turnus by ansatt_id
      const turnusMap = new Map<string, TurnusPlan[]>();
      const turnusTypeMap = new Map<string, string>();
      
      turnusData?.forEach(t => {
        const existing = turnusMap.get(t.ansatt_id) || [];
        existing.push({
          id: t.id,
          ukedag: t.ukedag,
          start_tid: t.start_tid,
          slutt_tid: t.slutt_tid,
          fridag: t.fridag || false,
          uke_type: t.uke_type,
          gyldig_fra: t.gyldig_fra,
          pause_minutter: t.pause_minutter
        });
        turnusMap.set(t.ansatt_id, existing);
        
        // Determine turnus type from uke_type values
        const ukeTypes = new Set(existing.map(e => e.uke_type).filter(Boolean));
        if (ukeTypes.has('uke3')) {
          turnusTypeMap.set(t.ansatt_id, 'treuke');
        } else if (ukeTypes.has('oddetall') || ukeTypes.has('partall')) {
          turnusTypeMap.set(t.ansatt_id, 'touke');
        } else {
          turnusTypeMap.set(t.ansatt_id, 'enkel');
        }
      });

      const employeesWithSchedule: Employee[] = (ansatte || [])
        .map(a => ({
          id: a.id,
          user_id: a.user_id,
          fornavn: a.fornavn,
          etternavn: a.etternavn || null,
          stillingsprosent: a.stillingsprosent,
          frisorfunksjon: a.frisorfunksjon,
          lederstilling: a.lederstilling,
          inkluder_i_turnus: a.inkluder_i_turnus,
          effektiv_inkluder_i_turnus: a.effektiv_inkluder_i_turnus,
          turnusPlaner: turnusMap.get(a.id) || [],
          turnusType: turnusTypeMap.get(a.id) || null
        }))
        .sort((a, b) => {
          const nameA = [a.fornavn, a.etternavn].filter(Boolean).join(" ").toLowerCase();
          const nameB = [b.fornavn, b.etternavn].filter(Boolean).join(" ").toLowerCase();
          return nameA.localeCompare(nameB, 'nb');
        });

      setEmployees(employeesWithSchedule);
    } catch (error) {
      console.error("Error fetching employees:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke hente ansatte",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEmployees();
  }, [salonId]);

  const getRoleLabel = (frisorfunksjon: string | null, lederstilling: string | null) => {
    const labels: Record<string, string> = {
      frisor: "Frisør",
      senior_frisor: "Seniorfrisør",
      laerling: "Lærling",
      daglig_leder: "Daglig leder",
      avdelingsleder: "Avdelingsleder",
      styreleder: "Styreleder"
    };
    
    const parts: string[] = [];
    if (frisorfunksjon) parts.push(labels[frisorfunksjon] || frisorfunksjon);
    if (lederstilling) parts.push(labels[lederstilling] || lederstilling);
    return parts.join(" / ") || "Ukjent rolle";
  };

  const getScheduleSummary = (employee: Employee) => {
    if (employee.turnusPlaner.length === 0) {
      return null;
    }

    // Grupper unike maler per uke_type + ukedag (fjern duplikater fra genererte skift)
    const uniqueTemplates = new Map<string, TurnusPlan>();
    employee.turnusPlaner.forEach(t => {
      const key = `${t.uke_type || 'alle'}-${t.ukedag}`;
      if (!uniqueTemplates.has(key)) {
        uniqueTemplates.set(key, t);
      }
    });

    const uniqueList = Array.from(uniqueTemplates.values());
    const workDays = uniqueList.filter(t => !t.fridag && t.start_tid);
    const offDays = uniqueList.filter(t => t.fridag);

    // Grupper timer per uketype for korrekt gjennomsnitt
    const timerPerUkeType = new Map<string, { timer: number; arbeidsdager: number }>();
    
    workDays.forEach(day => {
      if (day.start_tid && day.slutt_tid) {
        const [startH, startM] = day.start_tid.split(':').map(Number);
        const [endH, endM] = day.slutt_tid.split(':').map(Number);
        const pauseMinutes = day.pause_minutter || 30;
        // Trekk fra pause for skift over 5.5 timer
        const bruttoTimer = (endH + endM / 60) - (startH + startM / 60);
        const pause = bruttoTimer > 5.5 ? pauseMinutes / 60 : 0;
        const hours = Math.max(0, bruttoTimer - pause);
        
        const ukeType = day.uke_type || 'alle';
        const existing = timerPerUkeType.get(ukeType) || { timer: 0, arbeidsdager: 0 };
        timerPerUkeType.set(ukeType, {
          timer: existing.timer + hours,
          arbeidsdager: existing.arbeidsdager + 1
        });
      }
    });

    // Beregn gjennomsnittlig timer og arbeidsdager per uke
    const antallUkeTyper = timerPerUkeType.size || 1;
    let totalTimer = 0;
    let totalArbeidsdager = 0;
    
    timerPerUkeType.forEach(({ timer, arbeidsdager }) => {
      totalTimer += timer;
      totalArbeidsdager += arbeidsdager;
    });

    const gjennomsnittTimer = totalTimer / antallUkeTyper;
    const gjennomsnittArbeidsdager = totalArbeidsdager / antallUkeTyper;

    return {
      workDays: Math.round(gjennomsnittArbeidsdager * 10) / 10,
      offDays: offDays.length / antallUkeTyper,
      totalHours: Math.round(gjennomsnittTimer * 10) / 10,
      turnusType: employee.turnusType,
      gyldigFra: workDays[0]?.gyldig_fra
    };
  };

  if (loading) {
    return (
      <div className="space-y-3">
        {[1, 2, 3].map(i => (
          <Skeleton key={i} className="h-24 w-full" />
        ))}
      </div>
    );
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Ansattes turnus
          </CardTitle>
          <CardDescription>
            Administrer turnusplaner og arbeidstider for ansatte
          </CardDescription>
        </CardHeader>
        <CardContent>
          {employees.length === 0 ? (
            <div className="text-center py-8">
              <AlertCircle className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
              <p className="text-muted-foreground">
                Ingen aktive ansatte funnet for denne salongen.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {employees.map(employee => {
                const summary = getScheduleSummary(employee);
                const fullName = [employee.fornavn, employee.etternavn].filter(Boolean).join(" ");
                
                return (
                  <div
                    key={employee.id}
                    className="flex items-center justify-between p-4 rounded-lg border bg-card hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{fullName}</p>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                        <span>{getRoleLabel(employee.frisorfunksjon, employee.lederstilling)}</span>
                        <span>•</span>
                        <span>{employee.stillingsprosent}%</span>
                      </div>
                      
                      {summary && (
                        <div className="flex flex-wrap items-center gap-2 mt-2">
                          <Badge variant="outline" className="text-xs">
                            <CalendarDays className="h-3 w-3 mr-1" />
                            {summary.workDays} arbeidsdager
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            <Clock className="h-3 w-3 mr-1" />
                            {summary.totalHours}t/uke
                          </Badge>
                          {summary.turnusType && (
                            <Badge variant="secondary" className="text-xs">
                              {getTurnusTypeLabel(summary.turnusType as any)}
                            </Badge>
                          )}
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-3 ml-4">
                      {!summary ? (
                        <Badge variant="destructive" className="text-xs">
                          <AlertCircle className="h-3 w-3 mr-1" />
                          Ingen turnus
                        </Badge>
                      ) : summary.gyldigFra ? (
                        <Badge variant="default" className="text-xs">
                          Fra {format(new Date(summary.gyldigFra), "d. MMM", { locale: nb })}
                        </Badge>
                      ) : null}

                      {canManage && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setSelectedEmployee(employee);
                            setDialogOpen(true);
                          }}
                        >
                          <Edit className="h-4 w-4 mr-1" />
                          Rediger
                        </Button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              Rediger turnus - {selectedEmployee ? [selectedEmployee.fornavn, selectedEmployee.etternavn].filter(Boolean).join(" ") : ""}
            </DialogTitle>
            <DialogDescription>
              Sett arbeidstider, pauser og merknader for hver ukedag
            </DialogDescription>
          </DialogHeader>
          {selectedEmployee && (
            <EmployeeScheduleEditor
              salonId={salonId}
              employeeId={selectedEmployee.id}
              userId={selectedEmployee.user_id}
              employeeName={[selectedEmployee.fornavn, selectedEmployee.etternavn].filter(Boolean).join(" ")}
              onSaved={() => {
                setDialogOpen(false);
                fetchEmployees();
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
