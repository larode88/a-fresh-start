import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { X, AlertTriangle, AlertCircle, CheckCircle, TrendingUp, Lightbulb } from "lucide-react";
import { UKEDAGER, type BemanningForslag } from "@/lib/turnusUtils";

interface BemanningsPanelProps {
  forslag: BemanningForslag[];
  apningstider: Array<{
    ukedag: number;
    stengt: boolean;
    apner?: string;
    stenger?: string;
    min_bemanning?: number;
    ideell_bemanning?: number;
  }>;
  onClose: () => void;
}

export function BemanningsPanel({ forslag, apningstider, onClose }: BemanningsPanelProps) {
  const kritiske = forslag.filter(f => f.type === 'kritisk');
  const undermanning = forslag.filter(f => f.type === 'undermanning');
  const overbemanning = forslag.filter(f => f.type === 'overbemanning');

  const harProblemer = kritiske.length > 0 || undermanning.length > 0;

  return (
    <Card className="h-full border-l">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <Lightbulb className="h-4 w-4" />
            Bemanningsanalyse
          </CardTitle>
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[500px] px-4 pb-4">
          {/* Summary */}
          <div className="grid grid-cols-3 gap-2 mb-4">
            <div className={`p-2 rounded text-center ${kritiske.length > 0 ? 'bg-destructive/10' : 'bg-muted'}`}>
              <div className={`text-lg font-bold ${kritiske.length > 0 ? 'text-destructive' : ''}`}>
                {kritiske.length}
              </div>
              <div className="text-xs text-muted-foreground">Kritisk</div>
            </div>
            <div className={`p-2 rounded text-center ${undermanning.length > 0 ? 'bg-amber-500/10' : 'bg-muted'}`}>
              <div className={`text-lg font-bold ${undermanning.length > 0 ? 'text-amber-600' : ''}`}>
                {undermanning.length}
              </div>
              <div className="text-xs text-muted-foreground">Undermanning</div>
            </div>
            <div className={`p-2 rounded text-center ${overbemanning.length > 0 ? 'bg-blue-500/10' : 'bg-muted'}`}>
              <div className={`text-lg font-bold ${overbemanning.length > 0 ? 'text-blue-600' : ''}`}>
                {overbemanning.length}
              </div>
              <div className="text-xs text-muted-foreground">Over</div>
            </div>
          </div>

          {/* Status message */}
          {!harProblemer ? (
            <div className="flex items-center gap-2 p-3 rounded-lg bg-green-500/10 text-green-700 dark:text-green-400 mb-4">
              <CheckCircle className="h-4 w-4" />
              <span className="text-sm">Bemanningen ser bra ut denne uken!</span>
            </div>
          ) : (
            <div className="flex items-center gap-2 p-3 rounded-lg bg-amber-500/10 text-amber-700 dark:text-amber-400 mb-4">
              <AlertCircle className="h-4 w-4" />
              <span className="text-sm">Det er {kritiske.length + undermanning.length} bemanningshull å håndtere</span>
            </div>
          )}

          {/* Critical issues */}
          {kritiske.length > 0 && (
            <div className="space-y-2 mb-4">
              <h4 className="text-sm font-medium flex items-center gap-1 text-destructive">
                <AlertTriangle className="h-3.5 w-3.5" />
                Kritisk - Ingen ansatte
              </h4>
              {kritiske.map((f, i) => (
                <ForslagKort key={`kritisk-${i}`} forslag={f} variant="kritisk" />
              ))}
            </div>
          )}

          {/* Understaffing */}
          {undermanning.length > 0 && (
            <div className="space-y-2 mb-4">
              <h4 className="text-sm font-medium flex items-center gap-1 text-amber-600">
                <AlertCircle className="h-3.5 w-3.5" />
                Undermanning
              </h4>
              {undermanning.map((f, i) => (
                <ForslagKort key={`under-${i}`} forslag={f} variant="under" />
              ))}
            </div>
          )}

          {/* Overstaffing */}
          {overbemanning.length > 0 && (
            <div className="space-y-2 mb-4">
              <h4 className="text-sm font-medium flex items-center gap-1 text-blue-600">
                <TrendingUp className="h-3.5 w-3.5" />
                Overbemanning
              </h4>
              {overbemanning.slice(0, 5).map((f, i) => (
                <ForslagKort key={`over-${i}`} forslag={f} variant="over" />
              ))}
              {overbemanning.length > 5 && (
                <p className="text-xs text-muted-foreground pl-2">
                  +{overbemanning.length - 5} flere timer med overbemanning
                </p>
              )}
            </div>
          )}

          {/* Quick tips */}
          <div className="mt-6 p-3 rounded-lg bg-muted/50 space-y-2">
            <h4 className="text-sm font-medium">Tips for optimal bemanning</h4>
            <ul className="text-xs text-muted-foreground space-y-1">
              <li>• Rush-tid (10-12, 15-18): Planlegg +1 ansatt</li>
              <li>• Lunsj (12-13): Kan ha lavere bemanning</li>
              <li>• Lærlinger: Alltid med veileder</li>
              <li>• Senior frisører: Prioriter peak-timer</li>
            </ul>
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}

interface ForslagKortProps {
  forslag: BemanningForslag;
  variant: 'kritisk' | 'under' | 'over';
}

function ForslagKort({ forslag, variant }: ForslagKortProps) {
  const bgColor = {
    kritisk: 'bg-destructive/5 border-destructive/20',
    under: 'bg-amber-500/5 border-amber-500/20',
    over: 'bg-blue-500/5 border-blue-500/20',
  }[variant];

  return (
    <div className={`p-2 rounded border ${bgColor}`}>
      <div className="flex items-center justify-between mb-1">
        <span className="text-sm font-medium">
          {UKEDAGER[forslag.ukedag - 1]?.lang}
        </span>
        <Badge variant="outline" className="text-xs">
          {forslag.time}:00
        </Badge>
      </div>
      <p className="text-xs text-muted-foreground">{forslag.melding}</p>
      {forslag.forslag && (
        <p className="text-xs text-primary mt-1">💡 {forslag.forslag}</p>
      )}
    </div>
  );
}
