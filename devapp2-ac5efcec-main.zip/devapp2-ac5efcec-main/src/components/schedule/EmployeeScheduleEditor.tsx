import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Save, Loader2, MessageSquare, Calendar, Clock } from "lucide-react";
import { format } from "date-fns";
import type { Database } from "@/integrations/supabase/types";

type TurnusUkeType = Database["public"]["Enums"]["turnus_uke_type"];
type TurnusType = "enkel" | "toUkers" | "treUkers";

interface EmployeeScheduleEditorProps {
  salonId: string;
  employeeId: string;
  userId: string | null;
  employeeName: string;
  onSaved: () => void;
}

interface DaySchedule {
  id?: string;
  ukedag: number;
  start_tid: string;
  slutt_tid: string;
  fridag: boolean;
  uke_type: TurnusUkeType;
  pause_minutter: number;
  merknad: string | null;
}

const WEEKDAYS = [
  { value: 1, label: "Mandag" },
  { value: 2, label: "Tirsdag" },
  { value: 3, label: "Onsdag" },
  { value: 4, label: "Torsdag" },
  { value: 5, label: "Fredag" },
  { value: 6, label: "Lørdag" },
  { value: 7, label: "Søndag" },
];

const TURNUS_TYPES: { value: TurnusType; label: string; description: string }[] = [
  { value: "enkel", label: "Enkel turnus", description: "Samme arbeidstider hver uke" },
  { value: "toUkers", label: "2-ukers turnus", description: "Ulike arbeidstider partall/oddetall uker" },
  { value: "treUkers", label: "3-ukers turnus", description: "Rotasjon over 3 uker" },
];

export function EmployeeScheduleEditor({ 
  salonId, 
  employeeId, 
  userId,
  employeeName, 
  onSaved 
}: EmployeeScheduleEditorProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [turnusType, setTurnusType] = useState<TurnusType>("enkel");
  const [schedulesPartall, setSchedulesPartall] = useState<DaySchedule[]>([]);
  const [schedulesOddetall, setSchedulesOddetall] = useState<DaySchedule[]>([]);
  const [schedulesUke3, setSchedulesUke3] = useState<DaySchedule[]>([]);
  const [gyldigFra, setGyldigFra] = useState(format(new Date(), "yyyy-MM-dd"));
  const [activeWeekTab, setActiveWeekTab] = useState<"partall" | "oddetall" | "uke3">("partall");

  const createDefaultSchedule = (ukeType: TurnusUkeType): DaySchedule[] => {
    return WEEKDAYS.map(day => ({
      ukedag: day.value,
      start_tid: "09:00",
      slutt_tid: "17:00",
      fridag: day.value >= 6,
      uke_type: ukeType,
      pause_minutter: 30,
      merknad: null
    }));
  };

  useEffect(() => {
    const fetchSchedule = async () => {
      setLoading(true);
      try {
        const { data, error } = await supabase
          .from("ansatt_turnus")
          .select("*")
          .eq("salon_id", salonId)
          .eq("ansatt_id", employeeId)
          .is("gyldig_til", null)
          .order("ukedag");

        if (error) throw error;

        // Check turnus type from data
        const hasPartall = data?.some(d => d.uke_type === "partall");
        const hasOddetall = data?.some(d => d.uke_type === "oddetall");
        const hasUke1 = data?.some(d => d.uke_type === "uke1");
        const hasUke2 = data?.some(d => d.uke_type === "uke2");
        const hasUke3 = data?.some(d => d.uke_type === "uke3");
        
        // Determine turnus type
        let detectedType: TurnusType = "enkel";
        if (hasUke1 || hasUke2 || hasUke3) {
          detectedType = "treUkers";
        } else if (hasPartall || hasOddetall) {
          detectedType = "toUkers";
        }
        
        setTurnusType(detectedType);

        // Build schedule maps based on detected type
        const buildSchedule = (existingMap: Map<number, any>, ukeType: TurnusUkeType): DaySchedule[] => {
          return WEEKDAYS.map(day => {
            const existing = existingMap.get(day.value);
            if (existing) {
              return {
                id: existing.id,
                ukedag: existing.ukedag,
                start_tid: existing.start_tid || "09:00",
                slutt_tid: existing.slutt_tid || "17:00",
                fridag: existing.fridag || false,
                uke_type: ukeType,
                pause_minutter: existing.pause_minutter || 30,
                merknad: existing.merknad || null
              };
            }
            return {
              ukedag: day.value,
              start_tid: "09:00",
              slutt_tid: "17:00",
              fridag: day.value >= 6,
              uke_type: ukeType,
              pause_minutter: 30,
              merknad: null
            };
          });
        };

        if (detectedType === "treUkers") {
          const uke1Days = new Map(data?.filter(d => d.uke_type === "uke1").map(d => [d.ukedag, d]) || []);
          const uke2Days = new Map(data?.filter(d => d.uke_type === "uke2").map(d => [d.ukedag, d]) || []);
          const uke3Days = new Map(data?.filter(d => d.uke_type === "uke3").map(d => [d.ukedag, d]) || []);
          
          setSchedulesPartall(buildSchedule(uke1Days, "uke1"));
          setSchedulesOddetall(buildSchedule(uke2Days, "uke2"));
          setSchedulesUke3(buildSchedule(uke3Days, "uke3"));
        } else if (detectedType === "toUkers") {
          const partallDays = new Map(data?.filter(d => d.uke_type === "partall" || d.uke_type === "alle").map(d => [d.ukedag, d]) || []);
          const oddetallDays = new Map(data?.filter(d => d.uke_type === "oddetall").map(d => [d.ukedag, d]) || []);
          
          setSchedulesPartall(buildSchedule(partallDays, "partall"));
          setSchedulesOddetall(buildSchedule(oddetallDays, "oddetall"));
          setSchedulesUke3(createDefaultSchedule("uke3"));
        } else {
          const allDays = new Map(data?.map(d => [d.ukedag, d]) || []);
          setSchedulesPartall(buildSchedule(allDays, "alle"));
          setSchedulesOddetall(createDefaultSchedule("oddetall"));
          setSchedulesUke3(createDefaultSchedule("uke3"));
        }
        
        if (data && data.length > 0 && data[0].gyldig_fra) {
          setGyldigFra(data[0].gyldig_fra);
        }
      } catch (error) {
        console.error("Error fetching schedule:", error);
        toast({
          title: "Feil",
          description: "Kunne ikke hente turnus",
          variant: "destructive"
        });
      } finally {
        setLoading(false);
      }
    };

    fetchSchedule();
  }, [salonId, employeeId]);

  const updateSchedule = (
    weekType: "partall" | "oddetall" | "uke3",
    ukedag: number, 
    field: keyof DaySchedule, 
    value: string | boolean | number | null
  ) => {
    const setter = weekType === "partall" 
      ? setSchedulesPartall 
      : weekType === "oddetall" 
        ? setSchedulesOddetall 
        : setSchedulesUke3;
    setter(prev => prev.map(s => 
      s.ukedag === ukedag ? { ...s, [field]: value } : s
    ));
  };

  const handleTurnusTypeChange = (newType: TurnusType) => {
    setTurnusType(newType);
    if (newType === "enkel") {
      // Convert to "alle" week type
      setSchedulesPartall(prev => prev.map(s => ({ ...s, uke_type: "alle" as TurnusUkeType })));
    } else if (newType === "toUkers") {
      // Split into partall/oddetall
      setSchedulesPartall(prev => prev.map(s => ({ ...s, uke_type: "partall" as TurnusUkeType })));
      // Copy partall to oddetall if oddetall is same as defaults
      setSchedulesOddetall(schedulesPartall.map(s => ({ ...s, uke_type: "oddetall" as TurnusUkeType })));
    } else if (newType === "treUkers") {
      // Split into uke1/uke2/uke3
      setSchedulesPartall(prev => prev.map(s => ({ ...s, uke_type: "uke1" as TurnusUkeType })));
      setSchedulesOddetall(schedulesPartall.map(s => ({ ...s, uke_type: "uke2" as TurnusUkeType })));
      setSchedulesUke3(schedulesPartall.map(s => ({ ...s, uke_type: "uke3" as TurnusUkeType })));
    }
  };

  const calculateWeeklyHours = (schedules: DaySchedule[]): number => {
    return schedules.reduce((total, day) => {
      if (day.fridag) return total;
      const [startH, startM] = day.start_tid.split(':').map(Number);
      const [endH, endM] = day.slutt_tid.split(':').map(Number);
      const hours = (endH + endM / 60) - (startH + startM / 60) - (day.pause_minutter / 60);
      return total + Math.max(0, hours);
    }, 0);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      // First, end any existing turnus entries
      await supabase
        .from("ansatt_turnus")
        .update({ gyldig_til: gyldigFra })
        .eq("ansatt_id", employeeId)
        .eq("salon_id", salonId)
        .is("gyldig_til", null);

      // Build entries based on turnus type
      let allSchedules: DaySchedule[] = [];
      if (turnusType === "enkel") {
        allSchedules = schedulesPartall;
      } else if (turnusType === "toUkers") {
        allSchedules = [...schedulesPartall, ...schedulesOddetall];
      } else if (turnusType === "treUkers") {
        allSchedules = [...schedulesPartall, ...schedulesOddetall, ...schedulesUke3];
      }

      const newEntries = allSchedules.map(day => ({
        salon_id: salonId,
        user_id: userId,
        ansatt_id: employeeId,
        ukedag: day.ukedag,
        start_tid: day.fridag ? null : day.start_tid,
        slutt_tid: day.fridag ? null : day.slutt_tid,
        fridag: day.fridag,
        uke_type: day.uke_type,
        pause_minutter: day.fridag ? 0 : day.pause_minutter,
        merknad: day.merknad,
        gyldig_fra: gyldigFra
      }));

      const { error: insertError } = await supabase
        .from("ansatt_turnus")
        .insert(newEntries as any);

      if (insertError) throw insertError;

      toast({
        title: "Lagret",
        description: `Turnus for ${employeeName} er oppdatert`
      });
      onSaved();
    } catch (error) {
      console.error("Error saving schedule:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke lagre turnus",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const renderHeader = () => (
    <div className="flex items-center gap-3 px-3 py-2 border-b text-xs text-muted-foreground font-medium">
      <div className="w-20">Dag</div>
      <div className="w-[70px]">Status</div>
      <div className="w-[110px] text-center">Start</div>
      <div className="w-4"></div>
      <div className="w-[110px] text-center">Slutt</div>
      <div className="w-20 text-center">Pause</div>
      <div className="w-8"></div>
    </div>
  );

  const renderDayRow = (day: DaySchedule, weekType: "partall" | "oddetall" | "uke3") => {
    const weekday = WEEKDAYS.find(w => w.value === day.ukedag);
    return (
      <div key={`${weekType}-${day.ukedag}`} className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-muted/50 transition-colors">
        <div className="w-20 font-medium text-sm">{weekday?.label}</div>
        
        <div className="flex items-center gap-1 w-[70px]">
          <Switch
            checked={!day.fridag}
            onCheckedChange={(checked) => updateSchedule(weekType, day.ukedag, "fridag", !checked)}
          />
          <span className="text-xs text-muted-foreground">
            {day.fridag ? "Fri" : ""}
          </span>
        </div>

        {!day.fridag ? (
          <>
            <Input
              type="time"
              value={day.start_tid}
              onChange={(e) => updateSchedule(weekType, day.ukedag, "start_tid", e.target.value)}
              className="w-[110px] h-8 text-sm"
            />
            <span className="text-muted-foreground text-sm w-4 text-center">–</span>
            <Input
              type="time"
              value={day.slutt_tid}
              onChange={(e) => updateSchedule(weekType, day.ukedag, "slutt_tid", e.target.value)}
              className="w-[110px] h-8 text-sm"
            />

            <div className="flex items-center gap-1.5 w-24">
              <Input
                type="number"
                min="0"
                max="120"
                value={day.pause_minutter}
                onChange={(e) => updateSchedule(weekType, day.ukedag, "pause_minutter", parseInt(e.target.value) || 0)}
                className="w-16 h-8 text-sm text-center px-2"
              />
              <span className="text-xs text-muted-foreground">min</span>
            </div>

            <Popover>
              <PopoverTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="sm"
                  className={`w-8 ${day.merknad ? "text-primary" : "text-muted-foreground"}`}
                >
                  <MessageSquare className="h-4 w-4" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-64">
                <div className="space-y-2">
                  <Label className="text-sm">Merknad</Label>
                  <Textarea
                    value={day.merknad || ""}
                    onChange={(e) => updateSchedule(weekType, day.ukedag, "merknad", e.target.value || null)}
                    placeholder="Evt. merknad for denne dagen..."
                    className="text-sm"
                    rows={3}
                  />
                </div>
              </PopoverContent>
            </Popover>
          </>
        ) : (
          <div className="flex-1 text-sm text-muted-foreground italic">Fridag</div>
        )}
      </div>
    );
  };

  if (loading) {
    return <Skeleton className="h-64" />;
  }

  const partallHours = calculateWeeklyHours(schedulesPartall);
  const oddetallHours = calculateWeeklyHours(schedulesOddetall);
  const uke3Hours = calculateWeeklyHours(schedulesUke3);
  const averageHours = turnusType === "treUkers" 
    ? (partallHours + oddetallHours + uke3Hours) / 3 
    : turnusType === "toUkers" 
      ? (partallHours + oddetallHours) / 2 
      : partallHours;

  return (
    <div className="space-y-4">
      {/* Header with date and turnus type */}
      <div className="flex flex-wrap items-center gap-4 pb-4 border-b">
        <div className="flex items-center gap-2">
          <Calendar className="h-4 w-4 text-muted-foreground" />
          <div className="space-y-1">
            <Label className="text-sm">Gyldig fra</Label>
            <Input
              type="date"
              value={gyldigFra}
              onChange={(e) => setGyldigFra(e.target.value)}
              className="w-40"
            />
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Label className="text-sm">Turnustype</Label>
          <Select value={turnusType} onValueChange={(v) => handleTurnusTypeChange(v as TurnusType)}>
            <SelectTrigger className="w-44">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {TURNUS_TYPES.map(t => (
                <SelectItem key={t.value} value={t.value}>
                  <div className="flex flex-col">
                    <span>{t.label}</span>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {turnusType === "enkel" ? (
        <>
          <div className="flex items-center justify-between mb-2">
            <Label className="text-sm text-muted-foreground">Arbeidstider (gjelder alle uker)</Label>
            <Badge variant="outline" className="text-xs">
              <Clock className="h-3 w-3 mr-1" />
              {partallHours.toFixed(1)}t/uke
            </Badge>
          </div>
          <div className="border rounded-lg overflow-hidden">
            {renderHeader()}
            <div className="divide-y">
              {schedulesPartall.map(day => renderDayRow(day, "partall"))}
            </div>
          </div>
        </>
      ) : turnusType === "toUkers" ? (
        <Tabs value={activeWeekTab} onValueChange={(v) => setActiveWeekTab(v as "partall" | "oddetall" | "uke3")}>
          <div className="flex items-center justify-between mb-2">
            <TabsList>
              <TabsTrigger value="partall" className="gap-2">
                Uke A (partall)
                <Badge variant="secondary" className="text-xs ml-1">
                  {partallHours.toFixed(1)}t
                </Badge>
              </TabsTrigger>
              <TabsTrigger value="oddetall" className="gap-2">
                Uke B (oddetall)
                <Badge variant="secondary" className="text-xs ml-1">
                  {oddetallHours.toFixed(1)}t
                </Badge>
              </TabsTrigger>
            </TabsList>
            <Badge variant="outline" className="text-xs">
              <Clock className="h-3 w-3 mr-1" />
              Snitt: {averageHours.toFixed(1)}t/uke
            </Badge>
          </div>
          
          <div className="border rounded-lg overflow-hidden">
            {renderHeader()}
            <TabsContent value="partall" className="divide-y mt-0">
              {schedulesPartall.map(day => renderDayRow(day, "partall"))}
            </TabsContent>
            
            <TabsContent value="oddetall" className="divide-y mt-0">
              {schedulesOddetall.map(day => renderDayRow(day, "oddetall"))}
            </TabsContent>
          </div>
        </Tabs>
      ) : (
        <Tabs value={activeWeekTab} onValueChange={(v) => setActiveWeekTab(v as "partall" | "oddetall" | "uke3")}>
          <div className="flex items-center justify-between mb-2">
            <TabsList>
              <TabsTrigger value="partall" className="gap-2">
                Uke 1
                <Badge variant="secondary" className="text-xs ml-1">
                  {partallHours.toFixed(1)}t
                </Badge>
              </TabsTrigger>
              <TabsTrigger value="oddetall" className="gap-2">
                Uke 2
                <Badge variant="secondary" className="text-xs ml-1">
                  {oddetallHours.toFixed(1)}t
                </Badge>
              </TabsTrigger>
              <TabsTrigger value="uke3" className="gap-2">
                Uke 3
                <Badge variant="secondary" className="text-xs ml-1">
                  {uke3Hours.toFixed(1)}t
                </Badge>
              </TabsTrigger>
            </TabsList>
            <Badge variant="outline" className="text-xs">
              <Clock className="h-3 w-3 mr-1" />
              Snitt: {averageHours.toFixed(1)}t/uke
            </Badge>
          </div>
          
          <div className="border rounded-lg overflow-hidden">
            {renderHeader()}
            <TabsContent value="partall" className="divide-y mt-0">
              {schedulesPartall.map(day => renderDayRow(day, "partall"))}
            </TabsContent>
            
            <TabsContent value="oddetall" className="divide-y mt-0">
              {schedulesOddetall.map(day => renderDayRow(day, "oddetall"))}
            </TabsContent>
            
            <TabsContent value="uke3" className="divide-y mt-0">
              {schedulesUke3.map(day => renderDayRow(day, "uke3"))}
            </TabsContent>
          </div>
        </Tabs>
      )}

      <div className="flex justify-end pt-4 border-t">
        <Button onClick={handleSave} disabled={saving}>
          {saving ? (
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <Save className="h-4 w-4 mr-2" />
          )}
          Lagre turnus
        </Button>
      </div>
    </div>
  );
}
