import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Target, TrendingUp, Clock, ShoppingBag, Save, RefreshCw } from "lucide-react";
import { toast } from "@/hooks/use-toast";

interface KPIConfig {
  id?: string;
  omsetning_per_time_mal: number | null;
  varesalg_prosent_mal: number | null;
  rebooking_prosent_mal: number | null;
  effektivitet_prosent_mal: number | null;
}

interface EmployeeKPIConfigProps {
  employeeId?: string; // user_id (optional)
  ansattId?: string;   // ansatt_id (optional, used if no user_id)
  salonId: string;
}

export const EmployeeKPIConfig = ({ employeeId, ansattId, salonId }: EmployeeKPIConfigProps) => {
  const [config, setConfig] = useState<KPIConfig>({
    omsetning_per_time_mal: null,
    varesalg_prosent_mal: null,
    rebooking_prosent_mal: null,
    effektivitet_prosent_mal: null,
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const fetchConfig = async () => {
      try {
        setLoading(true);
        
        let query = supabase
          .from("stylist_kpi_config")
          .select("*")
          .eq("salon_id", salonId);
        
        // Prefer user_id if available, otherwise use ansatt_id
        if (employeeId) {
          query = query.eq("user_id", employeeId);
        } else if (ansattId) {
          query = query.eq("ansatt_id", ansattId);
        } else {
          setLoading(false);
          return;
        }

        const { data, error } = await query.maybeSingle();

        if (error) throw error;

        if (data) {
          setConfig({
            id: data.id,
            omsetning_per_time_mal: data.omsetning_per_time_mal,
            varesalg_prosent_mal: data.varesalg_prosent_mal,
            rebooking_prosent_mal: data.rebooking_prosent_mal,
            effektivitet_prosent_mal: data.effektivitet_prosent_mal,
          });
        }
      } catch (error) {
        console.error("Error fetching KPI config:", error);
        toast({
          title: "Feil",
          description: "Kunne ikke laste KPI-konfigurasjon",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    if (salonId && (employeeId || ansattId)) {
      fetchConfig();
    }
  }, [employeeId, ansattId, salonId]);

  const handleSave = async () => {
    try {
      setSaving(true);

      const configData: Record<string, unknown> = {
        salon_id: salonId,
        omsetning_per_time_mal: config.omsetning_per_time_mal,
        varesalg_prosent_mal: config.varesalg_prosent_mal,
        rebooking_prosent_mal: config.rebooking_prosent_mal,
        effektivitet_prosent_mal: config.effektivitet_prosent_mal,
      };

      // Use user_id if available, otherwise use ansatt_id
      if (employeeId) {
        configData.user_id = employeeId;
      } else if (ansattId) {
        configData.ansatt_id = ansattId;
      }

      if (config.id) {
        const { error } = await supabase
          .from("stylist_kpi_config")
          .update(configData as any)
          .eq("id", config.id);

        if (error) throw error;
      } else {
        const { data, error } = await supabase
          .from("stylist_kpi_config")
          .insert(configData as any)
          .select()
          .single();

        if (error) throw error;
        setConfig({ ...config, id: data.id });
      }

      toast({
        title: "Lagret",
        description: "KPI-mål er oppdatert",
      });
    } catch (error) {
      console.error("Error saving KPI config:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke lagre KPI-konfigurasjon",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const handleReset = () => {
    setConfig({
      id: config.id,
      omsetning_per_time_mal: null,
      varesalg_prosent_mal: null,
      rebooking_prosent_mal: null,
      effektivitet_prosent_mal: null,
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Target className="w-4 h-4" />
            Individuelle KPI-mål
          </CardTitle>
          <CardDescription>
            Sett individuelle mål for denne ansatte. Tomme felter bruker salongstandard.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Revenue per hour */}
          <div className="space-y-2">
            <Label htmlFor="omsetning" className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-info" />
              Omsetning per time (kr)
            </Label>
            <Input
              id="omsetning"
              type="number"
              min="0"
              value={config.omsetning_per_time_mal ?? ""}
              onChange={(e) => setConfig({
                ...config,
                omsetning_per_time_mal: e.target.value ? Number(e.target.value) : null
              })}
              placeholder="Bruk salongstandard"
            />
            <p className="text-xs text-muted-foreground">
              Forventet omsetning per time med kunder
            </p>
          </div>

          {/* Retail percentage */}
          <div className="space-y-2">
            <Label htmlFor="varesalg" className="flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-warning" />
              Varesalg-mål (%)
            </Label>
            <Input
              id="varesalg"
              type="number"
              min="0"
              max="100"
              value={config.varesalg_prosent_mal ?? ""}
              onChange={(e) => setConfig({
                ...config,
                varesalg_prosent_mal: e.target.value ? Number(e.target.value) : null
              })}
              placeholder="Bruk salongstandard"
            />
            <p className="text-xs text-muted-foreground">
              Mål for andel varesalg av total omsetning
            </p>
          </div>

          {/* Rebooking percentage */}
          <div className="space-y-2">
            <Label htmlFor="rebooking" className="flex items-center gap-2">
              <RefreshCw className="w-4 h-4 text-success" />
              Rebooking-mål (%)
            </Label>
            <Input
              id="rebooking"
              type="number"
              min="0"
              max="100"
              value={config.rebooking_prosent_mal ?? ""}
              onChange={(e) => setConfig({
                ...config,
                rebooking_prosent_mal: e.target.value ? Number(e.target.value) : null
              })}
              placeholder="Bruk salongstandard"
            />
            <p className="text-xs text-muted-foreground">
              Mål for andel kunder som rebooker
            </p>
          </div>

          {/* Efficiency percentage */}
          <div className="space-y-2">
            <Label htmlFor="effektivitet" className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-accent" />
              Effektivitet-mål (%)
            </Label>
            <Input
              id="effektivitet"
              type="number"
              min="0"
              max="100"
              value={config.effektivitet_prosent_mal ?? ""}
              onChange={(e) => setConfig({
                ...config,
                effektivitet_prosent_mal: e.target.value ? Number(e.target.value) : null
              })}
              placeholder="Bruk salongstandard"
            />
            <p className="text-xs text-muted-foreground">
              Mål for tid brukt med kunder vs. planlagt tid
            </p>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-between">
        <Button variant="outline" onClick={handleReset}>
          Nullstill
        </Button>
        <Button onClick={handleSave} disabled={saving}>
          <Save className="w-4 h-4 mr-2" />
          {saving ? "Lagrer..." : "Lagre KPI-mål"}
        </Button>
      </div>
    </div>
  );
};