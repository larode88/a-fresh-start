import { useEffect, useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Target, Plus, Trash2, Calendar, TrendingUp } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import {
  getGoalsByEmployee,
  createGoal,
  updateGoal,
  deleteGoal,
  getGoalProgress,
  type EmployeeGoal,
  type GoalInsert,
} from "@/integrations/supabase/goalsService";

interface EmployeeGoalsProps {
  employeeId: string;
  salonId: string;
}

const goalTypeLabels: Record<string, string> = {
  omsetning: "Omsetning",
  effektivitet: "Effektivitet",
  varesalg: "Varesalg",
  rebooking: "Rebooking",
  kunder: "Antall kunder",
  annet: "Annet",
};

const statusLabels: Record<string, { label: string; variant: "default" | "secondary" | "outline" }> = {
  aktiv: { label: "Aktiv", variant: "default" },
  fullfort: { label: "Fullført", variant: "secondary" },
  kansellert: { label: "Kansellert", variant: "outline" },
};

export const EmployeeGoals = ({ employeeId, salonId }: EmployeeGoalsProps) => {
  const [goals, setGoals] = useState<EmployeeGoal[]>([]);
  const [progress, setProgress] = useState<{
    goal_id: string;
    progress_percent: number;
    current_value: number;
  }[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [newGoal, setNewGoal] = useState<Partial<GoalInsert>>({
    mal_type: "omsetning",
    maalverdi: 0,
    periode_start: new Date().toISOString().split("T")[0],
    periode_slutt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
    beskrivelse: "",
  });

  const fetchData = async () => {
    try {
      setLoading(true);
      const [goalsData, progressData] = await Promise.all([
        getGoalsByEmployee(employeeId),
        getGoalProgress(employeeId, true),
      ]);
      setGoals(goalsData);
      setProgress(progressData);
    } catch (error) {
      console.error("Error fetching goals:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke laste mål",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (employeeId) {
      fetchData();
    }
  }, [employeeId]);

  const handleCreateGoal = async () => {
    if (!newGoal.maalverdi || !newGoal.periode_start || !newGoal.periode_slutt) {
      toast({
        title: "Mangler data",
        description: "Fyll ut alle obligatoriske felt",
        variant: "destructive",
      });
      return;
    }

    try {
      await createGoal({
        user_id: employeeId,
        salon_id: salonId,
        mal_type: newGoal.mal_type || "omsetning",
        maalverdi: newGoal.maalverdi,
        periode_start: newGoal.periode_start,
        periode_slutt: newGoal.periode_slutt,
        beskrivelse: newGoal.beskrivelse || null,
      });

      toast({ title: "Mål opprettet" });
      setDialogOpen(false);
      setNewGoal({
        mal_type: "omsetning",
        maalverdi: 0,
        periode_start: new Date().toISOString().split("T")[0],
        periode_slutt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
        beskrivelse: "",
      });
      fetchData();
    } catch (error) {
      console.error("Error creating goal:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke opprette mål",
        variant: "destructive",
      });
    }
  };

  const handleDeleteGoal = async (goalId: string) => {
    try {
      await deleteGoal(goalId);
      toast({ title: "Mål slettet" });
      fetchData();
    } catch (error) {
      console.error("Error deleting goal:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke slette mål",
        variant: "destructive",
      });
    }
  };

  const handleCompleteGoal = async (goalId: string) => {
    try {
      await updateGoal(goalId, { status: "fullfort" });
      toast({ title: "Mål markert som fullført" });
      fetchData();
    } catch (error) {
      console.error("Error completing goal:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke fullføre mål",
        variant: "destructive",
      });
    }
  };

  const getProgressForGoal = (goalId: string) => {
    return progress.find((p) => p.goal_id === goalId);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  const activeGoals = goals.filter((g) => g.status === "aktiv");
  const completedGoals = goals.filter((g) => g.status === "fullfort");

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <Target className="w-5 h-5" />
            Mål og progresjon
          </h3>
          <p className="text-sm text-muted-foreground">
            {activeGoals.length} aktive mål
          </p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm">
              <Plus className="w-4 h-4 mr-2" />
              Nytt mål
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Opprett nytt mål</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 mt-4">
              <div>
                <Label>Måltype</Label>
                <Select
                  value={newGoal.mal_type}
                  onValueChange={(value) => setNewGoal({ ...newGoal, mal_type: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(goalTypeLabels).map(([key, label]) => (
                      <SelectItem key={key} value={key}>
                        {label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Målverdi</Label>
                <Input
                  type="number"
                  value={newGoal.maalverdi || ""}
                  onChange={(e) => setNewGoal({ ...newGoal, maalverdi: Number(e.target.value) })}
                  placeholder="F.eks. 500000 for omsetning"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Startdato</Label>
                  <Input
                    type="date"
                    value={newGoal.periode_start}
                    onChange={(e) => setNewGoal({ ...newGoal, periode_start: e.target.value })}
                  />
                </div>
                <div>
                  <Label>Sluttdato</Label>
                  <Input
                    type="date"
                    value={newGoal.periode_slutt}
                    onChange={(e) => setNewGoal({ ...newGoal, periode_slutt: e.target.value })}
                  />
                </div>
              </div>
              <div>
                <Label>Beskrivelse (valgfritt)</Label>
                <Input
                  value={newGoal.beskrivelse || ""}
                  onChange={(e) => setNewGoal({ ...newGoal, beskrivelse: e.target.value })}
                  placeholder="Kort beskrivelse av målet"
                />
              </div>
              <Button onClick={handleCreateGoal} className="w-full">
                Opprett mål
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {activeGoals.length === 0 && completedGoals.length === 0 ? (
        <Card>
          <CardContent className="py-8 text-center">
            <Target className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground">Ingen mål definert ennå</p>
            <p className="text-sm text-muted-foreground mt-1">
              Klikk "Nytt mål" for å opprette et mål
            </p>
          </CardContent>
        </Card>
      ) : (
        <>
          {activeGoals.length > 0 && (
            <div className="space-y-3">
              <h4 className="text-sm font-medium text-muted-foreground">Aktive mål</h4>
              {activeGoals.map((goal) => {
                const goalProgress = getProgressForGoal(goal.id);
                const progressPercent = goalProgress?.progress_percent || 0;
                const currentValue = goalProgress?.current_value || goal.naavaerende_verdi || 0;

                return (
                  <Card key={goal.id}>
                    <CardHeader className="pb-2">
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="text-base flex items-center gap-2">
                            <TrendingUp className="w-4 h-4" />
                            {goalTypeLabels[goal.mal_type] || goal.mal_type}
                          </CardTitle>
                          {goal.beskrivelse && (
                            <CardDescription>{goal.beskrivelse}</CardDescription>
                          )}
                        </div>
                        <Badge variant={statusLabels[goal.status || "aktiv"].variant}>
                          {statusLabels[goal.status || "aktiv"].label}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>{currentValue.toLocaleString("nb-NO")} av {goal.maalverdi.toLocaleString("nb-NO")}</span>
                          <span className="font-medium">{progressPercent.toFixed(0)}%</span>
                        </div>
                        <Progress value={Math.min(progressPercent, 100)} className="h-2" />
                      </div>
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {new Date(goal.periode_start).toLocaleDateString("nb-NO")} - {new Date(goal.periode_slutt).toLocaleDateString("nb-NO")}
                        </span>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleCompleteGoal(goal.id)}
                          >
                            Fullfør
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleDeleteGoal(goal.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}

          {completedGoals.length > 0 && (
            <div className="space-y-3">
              <h4 className="text-sm font-medium text-muted-foreground">Fullførte mål</h4>
              {completedGoals.map((goal) => (
                <Card key={goal.id} className="opacity-75">
                  <CardHeader className="pb-2">
                    <div className="flex items-start justify-between">
                      <CardTitle className="text-base">
                        {goalTypeLabels[goal.mal_type] || goal.mal_type}
                      </CardTitle>
                      <Badge variant="secondary">Fullført</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">
                      Mål: {goal.maalverdi.toLocaleString("nb-NO")}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
};
