import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { 
  FileText, 
  Plus, 
  Trash2, 
  Download, 
  Calendar,
  AlertTriangle,
  Upload
} from "lucide-react";
import { format, differenceInDays, parseISO } from "date-fns";
import { nb } from "date-fns/locale";

interface Document {
  id: string;
  user_id: string;
  dokument_type: string;
  dokument_navn: string;
  dokument_url: string;
  utloper_dato: string | null;
  opprettet_av: string | null;
  created_at: string | null;
}

interface EmployeeDocumentsProps {
  employeeId: string;
}

const documentTypes = [
  { value: "kontrakt", label: "Arbeidskontrakt" },
  { value: "lonnslipp", label: "Lønnsslipp" },
  { value: "id", label: "ID-dokument" },
  { value: "fagbrev", label: "Fagbrev" },
  { value: "attest", label: "Attest" },
  { value: "annet", label: "Annet" },
];

export const EmployeeDocuments = ({ employeeId }: EmployeeDocumentsProps) => {
  const [documents, setDocuments] = useState<Document[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [newDoc, setNewDoc] = useState({
    dokument_type: "",
    dokument_navn: "",
    utloper_dato: "",
  });
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const fetchDocuments = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from("ansatt_dokumenter")
        .select("*")
        .eq("user_id", employeeId)
        .order("created_at", { ascending: false });

      if (error) throw error;
      setDocuments(data || []);
    } catch (error) {
      console.error("Error fetching documents:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke laste dokumenter",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (employeeId) {
      fetchDocuments();
    }
  }, [employeeId]);

  const handleUpload = async () => {
    if (!selectedFile || !newDoc.dokument_type || !newDoc.dokument_navn) {
      toast({
        title: "Mangler informasjon",
        description: "Velg fil, dokumenttype og navn",
        variant: "destructive",
      });
      return;
    }

    try {
      setUploading(true);

      // Upload file to storage
      const fileExt = selectedFile.name.split(".").pop();
      const fileName = `${employeeId}/${Date.now()}.${fileExt}`;
      
      const { error: uploadError } = await supabase.storage
        .from("ansatt-dokumenter")
        .upload(fileName, selectedFile);

      if (uploadError) throw uploadError;

      // Get public URL
      const { data: urlData } = supabase.storage
        .from("ansatt-dokumenter")
        .getPublicUrl(fileName);

      // Get current user for opprettet_av
      const { data: { user } } = await supabase.auth.getUser();

      // Insert document record
      const { error: insertError } = await supabase
        .from("ansatt_dokumenter")
        .insert({
          user_id: employeeId,
          dokument_type: newDoc.dokument_type,
          dokument_navn: newDoc.dokument_navn,
          dokument_url: urlData.publicUrl,
          utloper_dato: newDoc.utloper_dato || null,
          opprettet_av: user?.id || null,
        });

      if (insertError) throw insertError;

      toast({
        title: "Lastet opp",
        description: "Dokumentet er lastet opp",
      });

      setDialogOpen(false);
      setNewDoc({ dokument_type: "", dokument_navn: "", utloper_dato: "" });
      setSelectedFile(null);
      fetchDocuments();
    } catch (error) {
      console.error("Error uploading document:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke laste opp dokument",
        variant: "destructive",
      });
    } finally {
      setUploading(false);
    }
  };

  const handleDelete = async (docId: string, docUrl: string) => {
    try {
      // Delete from database
      const { error } = await supabase
        .from("ansatt_dokumenter")
        .delete()
        .eq("id", docId);

      if (error) throw error;

      // Try to delete from storage
      const urlPath = docUrl.split("/ansatt-dokumenter/").pop();
      if (urlPath) {
        await supabase.storage.from("ansatt-dokumenter").remove([urlPath]);
      }

      toast({
        title: "Slettet",
        description: "Dokumentet er slettet",
      });
      fetchDocuments();
    } catch (error) {
      console.error("Error deleting document:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke slette dokument",
        variant: "destructive",
      });
    }
  };

  const getExpiryStatus = (expiryDate: string | null) => {
    if (!expiryDate) return null;
    const daysUntilExpiry = differenceInDays(parseISO(expiryDate), new Date());
    
    if (daysUntilExpiry < 0) {
      return { label: "Utløpt", variant: "destructive" as const };
    } else if (daysUntilExpiry <= 30) {
      return { label: `Utløper om ${daysUntilExpiry} dager`, variant: "warning" as const };
    }
    return null;
  };

  const getTypeLabel = (type: string) => {
    return documentTypes.find(t => t.value === type)?.label || type;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="font-medium">Dokumenter ({documents.length})</h3>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm">
              <Plus className="w-4 h-4 mr-2" />
              Last opp
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Last opp dokument</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div>
                <Label htmlFor="file">Fil</Label>
                <Input
                  id="file"
                  type="file"
                  onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="type">Dokumenttype</Label>
                <Select
                  value={newDoc.dokument_type}
                  onValueChange={(value) => setNewDoc({ ...newDoc, dokument_type: value })}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Velg type" />
                  </SelectTrigger>
                  <SelectContent>
                    {documentTypes.map(type => (
                      <SelectItem key={type.value} value={type.value}>
                        {type.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="name">Dokumentnavn</Label>
                <Input
                  id="name"
                  value={newDoc.dokument_navn}
                  onChange={(e) => setNewDoc({ ...newDoc, dokument_navn: e.target.value })}
                  placeholder="F.eks. Arbeidskontrakt 2024"
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="expiry">Utløpsdato (valgfritt)</Label>
                <Input
                  id="expiry"
                  type="date"
                  value={newDoc.utloper_dato}
                  onChange={(e) => setNewDoc({ ...newDoc, utloper_dato: e.target.value })}
                  className="mt-1"
                />
              </div>
              <Button 
                onClick={handleUpload} 
                disabled={uploading} 
                className="w-full"
              >
                <Upload className="w-4 h-4 mr-2" />
                {uploading ? "Laster opp..." : "Last opp"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {documents.length === 0 ? (
        <Card>
          <CardContent className="py-8 text-center">
            <FileText className="w-12 h-12 mx-auto text-muted-foreground mb-2" />
            <p className="text-muted-foreground">Ingen dokumenter lastet opp</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2">
          {documents.map((doc) => {
            const expiryStatus = getExpiryStatus(doc.utloper_dato);
            return (
              <Card key={doc.id}>
                <CardContent className="flex items-center justify-between py-3">
                  <div className="flex items-center gap-3">
                    <FileText className="w-8 h-8 text-muted-foreground" />
                    <div>
                      <p className="font-medium">{doc.dokument_navn}</p>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Badge variant="outline" className="text-xs">
                          {getTypeLabel(doc.dokument_type)}
                        </Badge>
                        {doc.utloper_dato && (
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            {format(parseISO(doc.utloper_dato), "d. MMM yyyy", { locale: nb })}
                          </span>
                        )}
                        {expiryStatus && (
                          <Badge 
                            variant={expiryStatus.variant === "destructive" ? "destructive" : "secondary"}
                            className={expiryStatus.variant === "warning" ? "bg-warning/10 text-warning border-warning/20" : ""}
                          >
                            <AlertTriangle className="w-3 h-3 mr-1" />
                            {expiryStatus.label}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => window.open(doc.dokument_url, "_blank")}
                    >
                      <Download className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDelete(doc.id, doc.dokument_url)}
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
};
