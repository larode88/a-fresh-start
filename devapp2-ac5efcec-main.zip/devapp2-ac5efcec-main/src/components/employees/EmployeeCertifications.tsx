import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { 
  Award, 
  Plus, 
  Trash2, 
  Edit2,
  Calendar,
  AlertTriangle,
  Building,
  ExternalLink
} from "lucide-react";
import { format, differenceInDays, parseISO } from "date-fns";
import { nb } from "date-fns/locale";

interface Certification {
  id: string;
  user_id: string;
  navn: string;
  type: string | null;
  utsteder: string | null;
  utstedt_dato: string | null;
  utloper_dato: string | null;
  sertifikat_url: string | null;
  created_at: string | null;
}

interface EmployeeCertificationsProps {
  employeeId: string;
}

const certificationTypes = [
  { value: "fagbrev", label: "Fagbrev" },
  { value: "kurs", label: "Kurs" },
  { value: "sertifisering", label: "Sertifisering" },
  { value: "opplaering", label: "Opplæring" },
  { value: "lisens", label: "Lisens" },
  { value: "annet", label: "Annet" },
];

export const EmployeeCertifications = ({ employeeId }: EmployeeCertificationsProps) => {
  const [certifications, setCertifications] = useState<Certification[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    navn: "",
    type: "",
    utsteder: "",
    utstedt_dato: "",
    utloper_dato: "",
    sertifikat_url: "",
  });

  const fetchCertifications = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from("ansatt_sertifiseringer")
        .select("*")
        .eq("user_id", employeeId)
        .order("utstedt_dato", { ascending: false });

      if (error) throw error;
      setCertifications(data || []);
    } catch (error) {
      console.error("Error fetching certifications:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke laste sertifiseringer",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (employeeId) {
      fetchCertifications();
    }
  }, [employeeId]);

  const resetForm = () => {
    setFormData({
      navn: "",
      type: "",
      utsteder: "",
      utstedt_dato: "",
      utloper_dato: "",
      sertifikat_url: "",
    });
    setEditingId(null);
  };

  const handleEdit = (cert: Certification) => {
    setFormData({
      navn: cert.navn,
      type: cert.type || "",
      utsteder: cert.utsteder || "",
      utstedt_dato: cert.utstedt_dato || "",
      utloper_dato: cert.utloper_dato || "",
      sertifikat_url: cert.sertifikat_url || "",
    });
    setEditingId(cert.id);
    setDialogOpen(true);
  };

  const handleSave = async () => {
    if (!formData.navn) {
      toast({
        title: "Mangler informasjon",
        description: "Navn er påkrevd",
        variant: "destructive",
      });
      return;
    }

    try {
      setSaving(true);

      const certData = {
        user_id: employeeId,
        navn: formData.navn,
        type: formData.type || null,
        utsteder: formData.utsteder || null,
        utstedt_dato: formData.utstedt_dato || null,
        utloper_dato: formData.utloper_dato || null,
        sertifikat_url: formData.sertifikat_url || null,
      };

      if (editingId) {
        const { error } = await supabase
          .from("ansatt_sertifiseringer")
          .update(certData)
          .eq("id", editingId);

        if (error) throw error;
        toast({ title: "Oppdatert", description: "Sertifisering er oppdatert" });
      } else {
        const { error } = await supabase
          .from("ansatt_sertifiseringer")
          .insert(certData);

        if (error) throw error;
        toast({ title: "Lagret", description: "Sertifisering er lagt til" });
      }

      setDialogOpen(false);
      resetForm();
      fetchCertifications();
    } catch (error) {
      console.error("Error saving certification:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke lagre sertifisering",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const { error } = await supabase
        .from("ansatt_sertifiseringer")
        .delete()
        .eq("id", id);

      if (error) throw error;
      toast({ title: "Slettet", description: "Sertifisering er slettet" });
      fetchCertifications();
    } catch (error) {
      console.error("Error deleting certification:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke slette sertifisering",
        variant: "destructive",
      });
    }
  };

  const getExpiryStatus = (expiryDate: string | null) => {
    if (!expiryDate) return null;
    const daysUntilExpiry = differenceInDays(parseISO(expiryDate), new Date());
    
    if (daysUntilExpiry < 0) {
      return { label: "Utløpt", variant: "destructive" as const };
    } else if (daysUntilExpiry <= 30) {
      return { label: `Utløper om ${daysUntilExpiry} dager`, variant: "warning" as const };
    } else if (daysUntilExpiry <= 90) {
      return { label: `Utløper om ${daysUntilExpiry} dager`, variant: "secondary" as const };
    }
    return null;
  };

  const getTypeLabel = (type: string | null) => {
    if (!type) return null;
    return certificationTypes.find(t => t.value === type)?.label || type;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="font-medium">Sertifiseringer & Kompetanse ({certifications.length})</h3>
        <Dialog open={dialogOpen} onOpenChange={(open) => {
          setDialogOpen(open);
          if (!open) resetForm();
        }}>
          <DialogTrigger asChild>
            <Button size="sm">
              <Plus className="w-4 h-4 mr-2" />
              Legg til
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editingId ? "Rediger sertifisering" : "Legg til sertifisering"}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div>
                <Label htmlFor="navn">Navn *</Label>
                <Input
                  id="navn"
                  value={formData.navn}
                  onChange={(e) => setFormData({ ...formData, navn: e.target.value })}
                  placeholder="F.eks. Frisørsvennebrev"
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="type">Type</Label>
                <Select
                  value={formData.type}
                  onValueChange={(value) => setFormData({ ...formData, type: value })}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Velg type" />
                  </SelectTrigger>
                  <SelectContent>
                    {certificationTypes.map(type => (
                      <SelectItem key={type.value} value={type.value}>
                        {type.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="utsteder">Utsteder</Label>
                <Input
                  id="utsteder"
                  value={formData.utsteder}
                  onChange={(e) => setFormData({ ...formData, utsteder: e.target.value })}
                  placeholder="F.eks. Utdanningsdirektoratet"
                  className="mt-1"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="utstedt">Utstedt dato</Label>
                  <Input
                    id="utstedt"
                    type="date"
                    value={formData.utstedt_dato}
                    onChange={(e) => setFormData({ ...formData, utstedt_dato: e.target.value })}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="utloper">Utløpsdato</Label>
                  <Input
                    id="utloper"
                    type="date"
                    value={formData.utloper_dato}
                    onChange={(e) => setFormData({ ...formData, utloper_dato: e.target.value })}
                    className="mt-1"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="url">Dokumentlenke (valgfritt)</Label>
                <Input
                  id="url"
                  type="url"
                  value={formData.sertifikat_url}
                  onChange={(e) => setFormData({ ...formData, sertifikat_url: e.target.value })}
                  placeholder="https://..."
                  className="mt-1"
                />
              </div>
              <Button 
                onClick={handleSave} 
                disabled={saving} 
                className="w-full"
              >
                {saving ? "Lagrer..." : editingId ? "Oppdater" : "Legg til"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {certifications.length === 0 ? (
        <Card>
          <CardContent className="py-8 text-center">
            <Award className="w-12 h-12 mx-auto text-muted-foreground mb-2" />
            <p className="text-muted-foreground">Ingen sertifiseringer registrert</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2">
          {certifications.map((cert) => {
            const expiryStatus = getExpiryStatus(cert.utloper_dato);
            const typeLabel = getTypeLabel(cert.type);
            return (
              <Card key={cert.id}>
                <CardContent className="flex items-center justify-between py-3">
                  <div className="flex items-center gap-3">
                    <Award className="w-8 h-8 text-primary" />
                    <div>
                      <p className="font-medium">{cert.navn}</p>
                      <div className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
                        {typeLabel && (
                          <Badge variant="outline" className="text-xs">
                            {typeLabel}
                          </Badge>
                        )}
                        {cert.utsteder && (
                          <span className="flex items-center gap-1">
                            <Building className="w-3 h-3" />
                            {cert.utsteder}
                          </span>
                        )}
                        {cert.utstedt_dato && (
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            {format(parseISO(cert.utstedt_dato), "d. MMM yyyy", { locale: nb })}
                          </span>
                        )}
                        {expiryStatus && (
                          <Badge 
                            variant={expiryStatus.variant === "destructive" ? "destructive" : "secondary"}
                            className={expiryStatus.variant === "warning" ? "bg-warning/10 text-warning border-warning/20" : ""}
                          >
                            <AlertTriangle className="w-3 h-3 mr-1" />
                            {expiryStatus.label}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    {cert.sertifikat_url && (
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => window.open(cert.sertifikat_url!, "_blank")}
                      >
                        <ExternalLink className="w-4 h-4" />
                      </Button>
                    )}
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleEdit(cert)}
                    >
                      <Edit2 className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDelete(cert.id)}
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
};
