import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "@/hooks/use-toast";
import { 
  Wallet, 
  Plus, 
  Trash2, 
  Edit2,
  Calendar,
  ArrowRight
} from "lucide-react";
import { format, parseISO, isAfter } from "date-fns";
import { nb } from "date-fns/locale";

interface Allowance {
  id: string;
  user_id: string;
  type: string;
  belop: number;
  beskrivelse: string | null;
  frekvens: string | null;
  gyldig_fra: string;
  gyldig_til: string | null;
  created_at: string | null;
}

interface EmployeeAllowancesProps {
  employeeId: string;
}

const allowanceTypes = [
  { value: "bonus", label: "Bonus" },
  { value: "tillegg", label: "Fast tillegg" },
  { value: "provisjon", label: "Provisjon" },
  { value: "kveldstillegg", label: "Kveldstillegg" },
  { value: "helgetillegg", label: "Helgetillegg" },
  { value: "ansiennitetstillegg", label: "Ansiennitetstillegg" },
  { value: "annet", label: "Annet" },
];

const frequencyOptions = [
  { value: "engang", label: "Engangsutbetaling" },
  { value: "maaned", label: "Månedlig" },
  { value: "aar", label: "Årlig" },
  { value: "time", label: "Per time" },
];

export const EmployeeAllowances = ({ employeeId }: EmployeeAllowancesProps) => {
  const [allowances, setAllowances] = useState<Allowance[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    type: "",
    belop: "",
    beskrivelse: "",
    frekvens: "maaned",
    gyldig_fra: "",
    gyldig_til: "",
  });

  const fetchAllowances = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from("ansatt_godtgjorelser")
        .select("*")
        .eq("user_id", employeeId)
        .order("gyldig_fra", { ascending: false });

      if (error) throw error;
      setAllowances(data || []);
    } catch (error) {
      console.error("Error fetching allowances:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke laste godtgjørelser",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (employeeId) {
      fetchAllowances();
    }
  }, [employeeId]);

  const resetForm = () => {
    setFormData({
      type: "",
      belop: "",
      beskrivelse: "",
      frekvens: "maaned",
      gyldig_fra: "",
      gyldig_til: "",
    });
    setEditingId(null);
  };

  const handleEdit = (allowance: Allowance) => {
    setFormData({
      type: allowance.type,
      belop: allowance.belop.toString(),
      beskrivelse: allowance.beskrivelse || "",
      frekvens: allowance.frekvens || "maaned",
      gyldig_fra: allowance.gyldig_fra,
      gyldig_til: allowance.gyldig_til || "",
    });
    setEditingId(allowance.id);
    setDialogOpen(true);
  };

  const handleSave = async () => {
    if (!formData.type || !formData.belop || !formData.gyldig_fra) {
      toast({
        title: "Mangler informasjon",
        description: "Type, beløp og gyldig fra er påkrevd",
        variant: "destructive",
      });
      return;
    }

    try {
      setSaving(true);

      const allowanceData = {
        user_id: employeeId,
        type: formData.type,
        belop: parseFloat(formData.belop),
        beskrivelse: formData.beskrivelse || null,
        frekvens: formData.frekvens || null,
        gyldig_fra: formData.gyldig_fra,
        gyldig_til: formData.gyldig_til || null,
      };

      if (editingId) {
        const { error } = await supabase
          .from("ansatt_godtgjorelser")
          .update(allowanceData)
          .eq("id", editingId);

        if (error) throw error;
        toast({ title: "Oppdatert", description: "Godtgjørelse er oppdatert" });
      } else {
        const { error } = await supabase
          .from("ansatt_godtgjorelser")
          .insert(allowanceData);

        if (error) throw error;
        toast({ title: "Lagret", description: "Godtgjørelse er lagt til" });
      }

      setDialogOpen(false);
      resetForm();
      fetchAllowances();
    } catch (error) {
      console.error("Error saving allowance:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke lagre godtgjørelse",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const { error } = await supabase
        .from("ansatt_godtgjorelser")
        .delete()
        .eq("id", id);

      if (error) throw error;
      toast({ title: "Slettet", description: "Godtgjørelse er slettet" });
      fetchAllowances();
    } catch (error) {
      console.error("Error deleting allowance:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke slette godtgjørelse",
        variant: "destructive",
      });
    }
  };

  const getTypeLabel = (type: string) => {
    return allowanceTypes.find(t => t.value === type)?.label || type;
  };

  const getFrequencyLabel = (freq: string | null) => {
    if (!freq) return null;
    return frequencyOptions.find(f => f.value === freq)?.label || freq;
  };

  const isActive = (allowance: Allowance) => {
    const now = new Date();
    const fromDate = parseISO(allowance.gyldig_fra);
    if (!isAfter(now, fromDate) && now.toDateString() !== fromDate.toDateString()) return false;
    if (allowance.gyldig_til && isAfter(now, parseISO(allowance.gyldig_til))) return false;
    return true;
  };

  const formatAmount = (amount: number, freq: string | null) => {
    const formatted = new Intl.NumberFormat("nb-NO", {
      style: "currency",
      currency: "NOK",
      maximumFractionDigits: 0,
    }).format(amount);
    
    const suffix = freq === "time" ? "/time" : freq === "maaned" ? "/mnd" : freq === "aar" ? "/år" : "";
    return formatted + suffix;
  };

  // Calculate total monthly allowances
  const totalMonthly = allowances
    .filter(a => isActive(a))
    .reduce((sum, a) => {
      if (a.frekvens === "maaned") return sum + a.belop;
      if (a.frekvens === "aar") return sum + (a.belop / 12);
      return sum;
    }, 0);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="font-medium">Godtgjørelser ({allowances.length})</h3>
          {totalMonthly > 0 && (
            <p className="text-sm text-muted-foreground">
              Aktive tillegg: {formatAmount(totalMonthly, "maaned")}
            </p>
          )}
        </div>
        <Dialog open={dialogOpen} onOpenChange={(open) => {
          setDialogOpen(open);
          if (!open) resetForm();
        }}>
          <DialogTrigger asChild>
            <Button size="sm">
              <Plus className="w-4 h-4 mr-2" />
              Legg til
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editingId ? "Rediger godtgjørelse" : "Legg til godtgjørelse"}
              </DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div>
                <Label htmlFor="type">Type *</Label>
                <Select
                  value={formData.type}
                  onValueChange={(value) => setFormData({ ...formData, type: value })}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Velg type" />
                  </SelectTrigger>
                  <SelectContent>
                    {allowanceTypes.map(type => (
                      <SelectItem key={type.value} value={type.value}>
                        {type.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="belop">Beløp (kr) *</Label>
                  <Input
                    id="belop"
                    type="number"
                    min="0"
                    step="0.01"
                    value={formData.belop}
                    onChange={(e) => setFormData({ ...formData, belop: e.target.value })}
                    placeholder="0"
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="frekvens">Frekvens</Label>
                  <Select
                    value={formData.frekvens}
                    onValueChange={(value) => setFormData({ ...formData, frekvens: value })}
                  >
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Velg frekvens" />
                    </SelectTrigger>
                    <SelectContent>
                      {frequencyOptions.map(freq => (
                        <SelectItem key={freq.value} value={freq.value}>
                          {freq.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="gyldig_fra">Gyldig fra *</Label>
                  <Input
                    id="gyldig_fra"
                    type="date"
                    value={formData.gyldig_fra}
                    onChange={(e) => setFormData({ ...formData, gyldig_fra: e.target.value })}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label htmlFor="gyldig_til">Gyldig til</Label>
                  <Input
                    id="gyldig_til"
                    type="date"
                    value={formData.gyldig_til}
                    onChange={(e) => setFormData({ ...formData, gyldig_til: e.target.value })}
                    className="mt-1"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="beskrivelse">Beskrivelse</Label>
                <Textarea
                  id="beskrivelse"
                  value={formData.beskrivelse}
                  onChange={(e) => setFormData({ ...formData, beskrivelse: e.target.value })}
                  placeholder="Valgfri beskrivelse..."
                  className="mt-1"
                  rows={2}
                />
              </div>
              <Button 
                onClick={handleSave} 
                disabled={saving} 
                className="w-full"
              >
                {saving ? "Lagrer..." : editingId ? "Oppdater" : "Legg til"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {allowances.length === 0 ? (
        <Card>
          <CardContent className="py-8 text-center">
            <Wallet className="w-12 h-12 mx-auto text-muted-foreground mb-2" />
            <p className="text-muted-foreground">Ingen godtgjørelser registrert</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-2">
          {allowances.map((allowance) => {
            const active = isActive(allowance);
            return (
              <Card key={allowance.id} className={!active ? "opacity-60" : ""}>
                <CardContent className="flex items-center justify-between py-3">
                  <div className="flex items-center gap-3">
                    <Wallet className={`w-8 h-8 ${active ? "text-primary" : "text-muted-foreground"}`} />
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-medium">{getTypeLabel(allowance.type)}</p>
                        <span className="font-semibold text-primary">
                          {formatAmount(allowance.belop, allowance.frekvens)}
                        </span>
                        {!active && <Badge variant="secondary">Inaktiv</Badge>}
                      </div>
                      <div className="flex flex-wrap items-center gap-2 text-sm text-muted-foreground">
                        {getFrequencyLabel(allowance.frekvens) && (
                          <Badge variant="outline" className="text-xs">
                            {getFrequencyLabel(allowance.frekvens)}
                          </Badge>
                        )}
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {format(parseISO(allowance.gyldig_fra), "d. MMM yyyy", { locale: nb })}
                          {allowance.gyldig_til && (
                            <>
                              <ArrowRight className="w-3 h-3" />
                              {format(parseISO(allowance.gyldig_til), "d. MMM yyyy", { locale: nb })}
                            </>
                          )}
                        </span>
                      </div>
                      {allowance.beskrivelse && (
                        <p className="text-sm text-muted-foreground mt-1">
                          {allowance.beskrivelse}
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleEdit(allowance)}
                    >
                      <Edit2 className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDelete(allowance.id)}
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
};
