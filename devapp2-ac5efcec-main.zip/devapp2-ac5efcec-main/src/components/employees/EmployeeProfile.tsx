import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { 
  User, 
  Mail, 
  Phone, 
  Calendar, 
  Briefcase, 
  GraduationCap,
  Target,
  Save,
  FileText,
  Award,
  Wallet,
  Banknote
} from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { EmployeeKPIConfig } from "./EmployeeKPIConfig";
import { EmployeeGoals } from "./EmployeeGoals";
import { EmployeeDocuments } from "./EmployeeDocuments";
import { EmployeeCertifications } from "./EmployeeCertifications";
import { EmployeeAllowances } from "./EmployeeAllowances";
import { EmployeeSalaryCard } from "./EmployeeSalaryCard";
import { Database } from "@/integrations/supabase/types";

type AppRole = Database["public"]["Enums"]["app_role"];

interface Employee {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  avatar_url: string | null;
  role: AppRole;
  stillingsprosent: number | null;
  fagbrev: boolean | null;
  fagbrevdato: string | null;
  ansettelsesdato: string | null;
  fodselsdato: string | null;
  aktiv: boolean | null;
  timesats: number | null;
  fastlonn: number | null;
  hubspot_contact_id: string | null;
}

interface EmployeeProfileProps {
  employeeId: string | null;
  salonId: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const roleLabels: Record<AppRole, string> = {
  admin: "Administrator",
  district_manager: "Distriktssjef",
  salon_owner: "Salongeier",
  daglig_leder: "Daglig leder",
  avdelingsleder: "Avdelingsleder",
  stylist: "Frisør",
  seniorfrisor: "Seniorfrisør",
  apprentice: "Lærling",
  chain_owner: "Kjedeeier",
  styreleder: "Styreleder",
  supplier_admin: "Leverandør Admin",
  supplier_sales: "Leverandør Salg",
  supplier_business_dev: "Leverandør Utvikling",
};

export const EmployeeProfile = ({
  employeeId,
  salonId,
  open,
  onOpenChange,
}: EmployeeProfileProps) => {
  const [employee, setEmployee] = useState<Employee | null>(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editForm, setEditForm] = useState({
    phone: "",
    stillingsprosent: "",
    fagbrev: false,
    fagbrevdato: "",
    ansettelsesdato: "",
    fodselsdato: "",
    aktiv: true,
    timesats: "",
    fastlonn: "",
  });

  useEffect(() => {
    const fetchEmployee = async () => {
      if (!employeeId) return;

      try {
        setLoading(true);
        const { data, error } = await supabase
          .from("users")
          .select("*")
          .eq("id", employeeId)
          .single();

        if (error) throw error;
        setEmployee(data);
        setEditForm({
          phone: data.phone || "",
          stillingsprosent: data.stillingsprosent?.toString() || "",
          fagbrev: data.fagbrev || false,
          fagbrevdato: data.fagbrevdato || "",
          ansettelsesdato: data.ansettelsesdato || "",
          fodselsdato: data.fodselsdato || "",
          aktiv: data.aktiv !== false,
          timesats: data.timesats?.toString() || "",
          fastlonn: data.fastlonn?.toString() || "",
        });
      } catch (error) {
        console.error("Error fetching employee:", error);
        toast({
          title: "Feil",
          description: "Kunne ikke laste ansattinformasjon",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    if (open && employeeId) {
      fetchEmployee();
    }
  }, [employeeId, open]);

  const handleSave = async () => {
    if (!employeeId) return;

    try {
      setSaving(true);
      const { error } = await supabase
        .from("users")
        .update({
          phone: editForm.phone || null,
          stillingsprosent: editForm.stillingsprosent ? Number(editForm.stillingsprosent) : null,
          fagbrev: editForm.fagbrev,
          fagbrevdato: editForm.fagbrevdato || null,
          ansettelsesdato: editForm.ansettelsesdato || null,
          fodselsdato: editForm.fodselsdato || null,
          aktiv: editForm.aktiv,
          timesats: editForm.timesats ? Number(editForm.timesats) : null,
          fastlonn: editForm.fastlonn ? Number(editForm.fastlonn) : null,
        })
        .eq("id", employeeId);

      if (error) throw error;

      // Sync to HubSpot if contact is linked
      if (employee?.hubspot_contact_id) {
        try {
          const { data: session } = await supabase.auth.getSession();
          if (session?.session?.access_token) {
            const response = await supabase.functions.invoke("hubspot-api", {
              body: {
                action: "update_contact",
                contactId: employee.hubspot_contact_id,
                properties: {
                  fagbrevdato: editForm.fagbrevdato || "",
                  mobilephone: editForm.phone || "",
                },
              },
            });
            
            if (response.error) {
              console.warn("HubSpot sync failed:", response.error);
              // Don't fail the save, just warn
            } else {
              console.log("HubSpot contact updated successfully");
            }
          }
        } catch (hubspotError) {
          console.warn("HubSpot sync error:", hubspotError);
          // Don't fail the save if HubSpot sync fails
        }
      }

      toast({
        title: "Lagret",
        description: employee?.hubspot_contact_id 
          ? "Ansattinformasjon er oppdatert og synkronisert til HubSpot"
          : "Ansattinformasjon er oppdatert",
      });
    } catch (error) {
      console.error("Error saving employee:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke lagre endringer",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  if (!employee && loading) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-3xl">
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  if (!employee) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-4">
            <Avatar className="h-16 w-16">
              <AvatarImage src={employee.avatar_url || undefined} />
              <AvatarFallback className="bg-primary/10 text-primary text-xl">
                {employee.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
              </AvatarFallback>
            </Avatar>
            <div>
              <DialogTitle className="text-xl">{employee.name}</DialogTitle>
              <div className="flex items-center gap-2 mt-1">
                <Badge variant="outline">
                  {roleLabels[employee.role] || employee.role}
                </Badge>
                {editForm.aktiv ? (
                  <Badge className="bg-success/10 text-success border-0">Aktiv</Badge>
                ) : (
                  <Badge variant="secondary">Inaktiv</Badge>
                )}
              </div>
            </div>
          </div>
        </DialogHeader>

        <Tabs defaultValue="info" className="mt-4">
          <TabsList className="grid w-full grid-cols-7">
            <TabsTrigger value="info">
              <User className="w-4 h-4 mr-2 hidden sm:inline" />
              Info
            </TabsTrigger>
            <TabsTrigger value="salary">
              <Banknote className="w-4 h-4 mr-2 hidden sm:inline" />
              Lønn
            </TabsTrigger>
            <TabsTrigger value="docs">
              <FileText className="w-4 h-4 mr-2 hidden sm:inline" />
              Dok
            </TabsTrigger>
            <TabsTrigger value="certs">
              <Award className="w-4 h-4 mr-2 hidden sm:inline" />
              Sert
            </TabsTrigger>
            <TabsTrigger value="allowances">
              <Wallet className="w-4 h-4 mr-2 hidden sm:inline" />
              Tillegg
            </TabsTrigger>
            <TabsTrigger value="goals">
              <Target className="w-4 h-4 mr-2 hidden sm:inline" />
              Mål
            </TabsTrigger>
            <TabsTrigger value="kpi">
              <Target className="w-4 h-4 mr-2 hidden sm:inline" />
              KPI
            </TabsTrigger>
          </TabsList>

          <TabsContent value="info" className="mt-4 space-y-4">
            {/* Contact Info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  Kontaktinformasjon
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-muted-foreground text-sm">E-post</Label>
                  <p className="font-medium">{employee.email}</p>
                </div>
                <div>
                  <Label htmlFor="phone">Mobil</Label>
                  <Input
                    id="phone"
                    value={editForm.phone}
                    onChange={(e) => setEditForm({ ...editForm, phone: e.target.value })}
                    placeholder="+47 xxx xx xxx"
                  />
                  {editForm.phone && !editForm.phone.startsWith("+") && (
                    <p className="text-sm text-destructive mt-1">
                      Mobilnummer må starte med landskode (f.eks. +47)
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Employment Info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <Briefcase className="w-4 h-4" />
                  Ansettelsesforhold
                </CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="ansettelsesdato">Ansettelsesdato</Label>
                  <Input
                    id="ansettelsesdato"
                    type="date"
                    value={editForm.ansettelsesdato}
                    onChange={(e) => setEditForm({ ...editForm, ansettelsesdato: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="fodselsdato">Fødselsdato</Label>
                  <Input
                    id="fodselsdato"
                    type="date"
                    value={editForm.fodselsdato}
                    onChange={(e) => setEditForm({ ...editForm, fodselsdato: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="stillingsprosent">Stillingsprosent</Label>
                  <Input
                    id="stillingsprosent"
                    type="number"
                    min="0"
                    max="100"
                    value={editForm.stillingsprosent}
                    onChange={(e) => setEditForm({ ...editForm, stillingsprosent: e.target.value })}
                    placeholder="100"
                  />
                </div>
                <div className="flex items-center justify-between rounded-lg border p-3">
                  <div className="space-y-0.5">
                    <Label>Aktiv ansatt</Label>
                    <p className="text-sm text-muted-foreground">
                      Markerer om ansatt er aktiv
                    </p>
                  </div>
                  <Switch
                    checked={editForm.aktiv}
                    onCheckedChange={(checked) => setEditForm({ ...editForm, aktiv: checked })}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Qualifications & Salary */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base flex items-center gap-2">
                  <GraduationCap className="w-4 h-4" />
                  Kompetanse & Lønn
                </CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center justify-between rounded-lg border p-3">
                  <div className="space-y-0.5">
                    <Label>Fagbrev</Label>
                    <p className="text-sm text-muted-foreground">
                      Har ansatt fagbrev
                    </p>
                  </div>
                  <Switch
                    checked={editForm.fagbrev}
                    onCheckedChange={(checked) => setEditForm({ ...editForm, fagbrev: checked })}
                  />
                </div>
                <div>
                  <Label htmlFor="fagbrevdato">Fagbrevdato</Label>
                  <Input
                    id="fagbrevdato"
                    type="date"
                    value={editForm.fagbrevdato}
                    onChange={(e) => setEditForm({ ...editForm, fagbrevdato: e.target.value })}
                  />
                  {(() => {
                    const baseDate = editForm.fagbrevdato || editForm.ansettelsesdato;
                    if (!baseDate) return null;
                    const years = Math.floor((Date.now() - new Date(baseDate).getTime()) / (365.25 * 24 * 60 * 60 * 1000));
                    const source = editForm.fagbrevdato ? "fagbrev" : "ansettelse";
                    return (
                      <p className="text-sm text-muted-foreground mt-1">
                        Ansiennitet: {years} år (basert på {source})
                      </p>
                    );
                  })()}
                </div>
                <div>
                  <Label htmlFor="timesats">Timesats (kr)</Label>
                  <Input
                    id="timesats"
                    type="number"
                    min="0"
                    value={editForm.timesats}
                    onChange={(e) => setEditForm({ ...editForm, timesats: e.target.value })}
                    placeholder="0"
                  />
                </div>
                <div>
                  <Label htmlFor="fastlonn">Fastlønn (kr/mnd)</Label>
                  <Input
                    id="fastlonn"
                    type="number"
                    min="0"
                    value={editForm.fastlonn}
                    onChange={(e) => setEditForm({ ...editForm, fastlonn: e.target.value })}
                    placeholder="0"
                  />
                </div>
              </CardContent>
            </Card>

            <div className="flex justify-end">
              <Button onClick={handleSave} disabled={saving}>
                <Save className="w-4 h-4 mr-2" />
                {saving ? "Lagrer..." : "Lagre endringer"}
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="salary" className="mt-4">
            <EmployeeSalaryCard employeeId={employeeId!} salonId={salonId} />
          </TabsContent>

          <TabsContent value="docs" className="mt-4">
            <EmployeeDocuments employeeId={employeeId!} />
          </TabsContent>

          <TabsContent value="certs" className="mt-4">
            <EmployeeCertifications employeeId={employeeId!} />
          </TabsContent>

          <TabsContent value="allowances" className="mt-4">
            <EmployeeAllowances employeeId={employeeId!} />
          </TabsContent>

          <TabsContent value="goals" className="mt-4">
            <EmployeeGoals employeeId={employeeId!} salonId={salonId} />
          </TabsContent>

          <TabsContent value="kpi" className="mt-4">
            <EmployeeKPIConfig employeeId={employeeId!} salonId={salonId} />
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};
