import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Banknote, Clock, Percent, AlertTriangle, CheckCircle } from "lucide-react";

interface EmployeeSalaryCardProps {
  employeeId: string;
  salonId: string;
}

interface TariffInfo {
  id: string;
  navn: string;
  timesats: number;
  maanedslonn: number | null;
  fagbrev_status: string;
  ansiennitet_min: number;
  ansiennitet_max: number | null;
  source: "mal" | "salong";
}

interface AllowanceSummary {
  total: number;
  items: Array<{
    type: string;
    belop: number;
    frekvens: string;
  }>;
}

interface EmployeeData {
  fagbrev: boolean | null;
  fagbrevdato: string | null;
  ansettelsesdato: string | null;
  stillingsprosent: number | null;
  timesats: number | null;
  fastlonn: number | null;
}

export const EmployeeSalaryCard = ({ employeeId, salonId }: EmployeeSalaryCardProps) => {
  const [employee, setEmployee] = useState<EmployeeData | null>(null);
  const [tariff, setTariff] = useState<TariffInfo | null>(null);
  const [allowances, setAllowances] = useState<AllowanceSummary>({ total: 0, items: [] });
  const [loading, setLoading] = useState(true);
  const [ansiennitet, setAnsiennitet] = useState<number | null>(null);

  useEffect(() => {
    fetchData();
  }, [employeeId, salonId]);

  const fetchData = async () => {
    try {
      setLoading(true);

      // Fetch employee data
      const { data: empData, error: empError } = await supabase
        .from("users")
        .select("fagbrev, fagbrevdato, ansettelsesdato, stillingsprosent, timesats, fastlonn")
        .eq("id", employeeId)
        .single();

      if (empError) throw empError;
      setEmployee(empData);

      // Calculate ansiennitet
      const baseDate = empData.fagbrevdato || empData.ansettelsesdato;
      if (baseDate) {
        const years = Math.floor(
          (Date.now() - new Date(baseDate).getTime()) / (365.25 * 24 * 60 * 60 * 1000)
        );
        setAnsiennitet(years);

        // Determine fagbrev_status
        const fagbrevStatus = empData.fagbrev 
          ? "med_fagbrev" 
          : (empData.fagbrevdato ? "med_fagbrev" : "uten_fagbrev");

        const currentYear = new Date().getFullYear();

        // First check salon-specific tariff
        const { data: salonTariff } = await supabase
          .from("tariff_satser")
          .select("*")
          .eq("salon_id", salonId)
          .eq("aar", currentYear)
          .eq("fagbrev_status", fagbrevStatus)
          .lte("ansiennitet_min", years)
          .or(`ansiennitet_max.is.null,ansiennitet_max.gte.${years}`)
          .order("ansiennitet_min", { ascending: false })
          .limit(1)
          .single();

        if (salonTariff) {
          setTariff({
            id: salonTariff.id,
            navn: `Salong-sats (${salonTariff.ansiennitet_min}${salonTariff.ansiennitet_max ? `-${salonTariff.ansiennitet_max}` : "+"} år)`,
            timesats: salonTariff.timesats,
            maanedslonn: salonTariff.maanedslonn,
            fagbrev_status: salonTariff.fagbrev_status,
            ansiennitet_min: salonTariff.ansiennitet_min,
            ansiennitet_max: salonTariff.ansiennitet_max,
            source: "salong",
          });
        } else {
          // Fallback to central tariff
          const { data: centralTariff } = await supabase
            .from("tariff_maler")
            .select("*")
            .eq("aar", currentYear)
            .eq("fagbrev_status", fagbrevStatus)
            .lte("ansiennitet_min", years)
            .or(`ansiennitet_max.is.null,ansiennitet_max.gte.${years}`)
            .order("ansiennitet_min", { ascending: false })
            .limit(1)
            .single();

          if (centralTariff) {
            setTariff({
              id: centralTariff.id,
              navn: centralTariff.navn,
              timesats: centralTariff.timesats,
              maanedslonn: centralTariff.maanedslonn,
              fagbrev_status: centralTariff.fagbrev_status,
              ansiennitet_min: centralTariff.ansiennitet_min,
              ansiennitet_max: centralTariff.ansiennitet_max,
              source: "mal",
            });
          }
        }
      }

      // Fetch active allowances
      const today = new Date().toISOString().split("T")[0];
      const { data: allowanceData } = await supabase
        .from("ansatt_godtgjorelser")
        .select("type, belop, frekvens")
        .eq("user_id", employeeId)
        .lte("gyldig_fra", today)
        .or(`gyldig_til.is.null,gyldig_til.gte.${today}`);

      if (allowanceData) {
        const monthlyTotal = allowanceData.reduce((sum, a) => {
          if (a.frekvens === "aar") return sum + a.belop / 12;
          if (a.frekvens === "uke") return sum + a.belop * 4.33;
          return sum + a.belop;
        }, 0);
        setAllowances({ total: Math.round(monthlyTotal), items: allowanceData });
      }
    } catch (error) {
      console.error("Error fetching salary data:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="py-8">
          <div className="flex justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!employee) return null;

  const hasManualOverride = employee.timesats !== null || employee.fastlonn !== null;
  const effectiveTimesats = employee.timesats || tariff?.timesats || 0;
  const stillingsprosent = employee.stillingsprosent || 100;
  
  // Calculate monthly salary: timesats × 162.5 × (stillingsprosent / 100)
  const calculatedMaanedslonn = employee.fastlonn 
    || Math.round(effectiveTimesats * 162.5 * (stillingsprosent / 100));
  
  const totalMonthly = calculatedMaanedslonn + allowances.total;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base flex items-center gap-2">
          <Banknote className="w-4 h-4" />
          Lønnsoversikt
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Tariff Info */}
        <div className="rounded-lg border p-3 bg-muted/30">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-muted-foreground">Gjeldende tariff</span>
            {tariff ? (
              <Badge variant={tariff.source === "salong" ? "secondary" : "outline"}>
                {tariff.source === "salong" ? "Salong-sats" : "Sentral tariff"}
              </Badge>
            ) : (
              <Badge variant="destructive">Ingen tariff funnet</Badge>
            )}
          </div>
          {tariff ? (
            <p className="font-medium">{tariff.navn}</p>
          ) : (
            <p className="text-sm text-muted-foreground">
              Opprett tariffer i Admin → Tariff
            </p>
          )}
          {ansiennitet !== null && (
            <p className="text-sm text-muted-foreground mt-1">
              Ansiennitet: {ansiennitet} år
              {employee.fagbrev ? " (med fagbrev)" : " (uten fagbrev)"}
            </p>
          )}
        </div>

        {/* Override Warning */}
        {hasManualOverride && (
          <div className="rounded-lg border p-3 bg-warning/10 border-warning/20">
            <div className="flex items-center gap-2 text-warning">
              <AlertTriangle className="w-4 h-4" />
              <span className="text-sm font-medium">Manuell overstyring aktiv</span>
            </div>
            <p className="text-sm text-muted-foreground mt-1">
              Ansatt har manuelt satt lønn som overstyrer tariff
            </p>
          </div>
        )}

        <Separator />

        {/* Salary Breakdown */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm">Timesats</span>
            </div>
            <span className="font-medium">
              {effectiveTimesats.toLocaleString("nb-NO")} kr
            </span>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Percent className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm">Stillingsprosent</span>
            </div>
            <span className="font-medium">{stillingsprosent}%</span>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Banknote className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm">Beregnet månedslønn</span>
            </div>
            <span className="font-medium">
              {calculatedMaanedslonn.toLocaleString("nb-NO")} kr
            </span>
          </div>

          {allowances.total > 0 && (
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-success" />
                <span className="text-sm">Faste tillegg</span>
              </div>
              <span className="font-medium text-success">
                +{allowances.total.toLocaleString("nb-NO")} kr
              </span>
            </div>
          )}
        </div>

        <Separator />

        {/* Total */}
        <div className="flex items-center justify-between py-2">
          <span className="font-semibold">Total estimert månedlig</span>
          <span className="text-lg font-bold text-primary">
            {totalMonthly.toLocaleString("nb-NO")} kr
          </span>
        </div>

        {/* Calculation Note */}
        <p className="text-xs text-muted-foreground">
          Beregnet som: timesats × 162.5 × (stillingsprosent / 100) + tillegg
        </p>
      </CardContent>
    </Card>
  );
};
