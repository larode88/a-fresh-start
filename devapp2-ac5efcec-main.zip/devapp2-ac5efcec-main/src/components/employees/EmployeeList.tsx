import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Search, UserCircle, Phone, Mail, Briefcase } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { Database } from "@/integrations/supabase/types";

type AppRole = Database["public"]["Enums"]["app_role"];

interface Employee {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  avatar_url: string | null;
  role: AppRole;
  stillingsprosent: number | null;
  fagbrev: boolean | null;
  ansettelsesdato: string | null;
  aktiv: boolean | null;
}

interface EmployeeListProps {
  salonId: string;
  onSelectEmployee: (id: string) => void;
}

const roleLabels: Record<AppRole, string> = {
  admin: "Administrator",
  district_manager: "Distriktssjef",
  salon_owner: "Salongeier",
  daglig_leder: "Daglig leder",
  avdelingsleder: "Avdelingsleder",
  stylist: "Frisør",
  seniorfrisor: "Seniorfrisør",
  apprentice: "Lærling",
  chain_owner: "Kjedeeier",
  styreleder: "Styreleder",
  supplier_admin: "Leverandør Admin",
  supplier_sales: "Leverandør Salg",
  supplier_business_dev: "Leverandør Utvikling",
};

export const EmployeeList = ({ salonId, onSelectEmployee }: EmployeeListProps) => {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    const fetchEmployees = async () => {
      if (!salonId) return;

      try {
        setLoading(true);
        const { data, error } = await supabase
          .from("users")
          .select("id, name, email, phone, avatar_url, role, stillingsprosent, fagbrev, ansettelsesdato, aktiv")
          .eq("salon_id", salonId)
          .order("name");

        if (error) throw error;
        setEmployees(data || []);
      } catch (error) {
        console.error("Error fetching employees:", error);
        toast({
          title: "Feil",
          description: "Kunne ikke laste ansatte",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    fetchEmployees();
  }, [salonId]);

  const filteredEmployees = employees.filter((emp) =>
    emp.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    emp.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const activeCount = employees.filter(e => e.aktiv !== false).length;
  const inactiveCount = employees.filter(e => e.aktiv === false).length;

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-xl bg-primary/10">
                <UserCircle className="w-6 h-6 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Totalt ansatte</p>
                <p className="text-2xl font-bold">{employees.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-xl bg-success/10">
                <Briefcase className="w-6 h-6 text-success" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Aktive</p>
                <p className="text-2xl font-bold">{activeCount}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="p-3 rounded-xl bg-muted">
                <UserCircle className="w-6 h-6 text-muted-foreground" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Inaktive</p>
                <p className="text-2xl font-bold">{inactiveCount}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Table */}
      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <CardTitle>Ansattliste</CardTitle>
            <div className="relative w-full sm:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Søk etter ansatt..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {filteredEmployees.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              {searchTerm ? "Ingen ansatte funnet" : "Ingen ansatte registrert"}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Ansatt</TableHead>
                    <TableHead>Rolle</TableHead>
                    <TableHead className="hidden md:table-cell">Stilling</TableHead>
                    <TableHead className="hidden md:table-cell">Fagbrev</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredEmployees.map((employee) => (
                    <TableRow key={employee.id} className="cursor-pointer hover:bg-muted/50">
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar className="h-10 w-10">
                            <AvatarImage src={employee.avatar_url || undefined} />
                            <AvatarFallback className="bg-primary/10 text-primary">
                              {employee.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{employee.name}</p>
                            <div className="flex items-center gap-2 text-sm text-muted-foreground">
                              <Mail className="w-3 h-3" />
                              {employee.email}
                            </div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          {roleLabels[employee.role] || employee.role}
                        </Badge>
                      </TableCell>
                      <TableCell className="hidden md:table-cell">
                        {employee.stillingsprosent ? `${employee.stillingsprosent}%` : "-"}
                      </TableCell>
                      <TableCell className="hidden md:table-cell">
                        {employee.fagbrev ? (
                          <Badge variant="secondary" className="bg-success/10 text-success">Ja</Badge>
                        ) : (
                          <Badge variant="secondary">Nei</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        {employee.aktiv !== false ? (
                          <Badge className="bg-success/10 text-success border-0">Aktiv</Badge>
                        ) : (
                          <Badge variant="secondary">Inaktiv</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => onSelectEmployee(employee.id)}
                        >
                          Se profil
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};
