import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { Plus, Pencil, Trash2, Calculator, ArrowRight } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";

interface TariffSats {
  id: string;
  aar: number;
  fagbrev_status: "med_fagbrev" | "uten_fagbrev" | "mester";
  ansiennitet_min: number;
  ansiennitet_max: number | null;
  timesats: number;
  maanedslonn: number | null;
  kilde_mal_id: string | null;
  avvik_fra_mal: number | null;
}

interface TariffMal {
  id: string;
  navn: string;
  fagbrev_status: string;
  ansiennitet_min: number;
  ansiennitet_max: number | null;
  timesats: number;
  maanedslonn: number | null;
}

interface SalonTariffSettingsProps {
  salonId: string;
}

const fagbrevLabels: Record<string, string> = {
  med_fagbrev: "Med fagbrev",
  uten_fagbrev: "Uten fagbrev",
  mester: "Mester",
};

export const SalonTariffSettings = ({ salonId }: SalonTariffSettingsProps) => {
  const { user } = useAuth();
  const [salonTariffer, setSalonTariffer] = useState<TariffSats[]>([]);
  const [centralMaler, setCentralMaler] = useState<TariffMal[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedYear, setSelectedYear] = useState<number>(new Date().getFullYear());
  const [showDialog, setShowDialog] = useState(false);
  const [editingSats, setEditingSats] = useState<TariffSats | null>(null);
  const [selectedMal, setSelectedMal] = useState<string | null>(null);
  const [avvikProsent, setAvvikProsent] = useState<string>("0");

  const availableYears = Array.from(
    { length: 3 },
    (_, i) => new Date().getFullYear() - 1 + i
  );

  useEffect(() => {
    fetchData();
  }, [salonId, selectedYear]);

  const fetchData = async () => {
    try {
      setLoading(true);

      // Fetch salon-specific tariffs
      const { data: salonData, error: salonError } = await supabase
        .from("tariff_satser")
        .select("*")
        .eq("salon_id", salonId)
        .eq("aar", selectedYear)
        .order("fagbrev_status")
        .order("ansiennitet_min");

      if (salonError) throw salonError;
      setSalonTariffer(salonData || []);

      // Fetch central tariff templates
      const { data: malData, error: malError } = await supabase
        .from("tariff_maler")
        .select("*")
        .eq("aar", selectedYear)
        .order("fagbrev_status")
        .order("ansiennitet_min");

      if (malError) throw malError;
      setCentralMaler(malData || []);
    } catch (error) {
      console.error("Error fetching tariff data:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke laste tariffdata",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleOpenDialog = (sats?: TariffSats) => {
    if (sats) {
      setEditingSats(sats);
      setSelectedMal(sats.kilde_mal_id || null);
      setAvvikProsent(sats.avvik_fra_mal?.toString() || "0");
    } else {
      setEditingSats(null);
      setSelectedMal(null);
      setAvvikProsent("0");
    }
    setShowDialog(true);
  };

  const handleCreateFromMal = async () => {
    if (!selectedMal) {
      toast({
        title: "Velg mal",
        description: "Du må velge en sentral tariffmal",
        variant: "destructive",
      });
      return;
    }

    const mal = centralMaler.find((m) => m.id === selectedMal);
    if (!mal) return;

    const avvik = parseFloat(avvikProsent) || 0;
    const adjustedTimesats = Math.round(mal.timesats * (1 + avvik / 100) * 100) / 100;
    const adjustedMaanedslonn = mal.maanedslonn
      ? Math.round(mal.maanedslonn * (1 + avvik / 100))
      : Math.round(adjustedTimesats * 162.5);

    try {
      if (editingSats) {
        const { error } = await supabase
          .from("tariff_satser")
          .update({
            kilde_mal_id: selectedMal,
            avvik_fra_mal: avvik,
            fagbrev_status: mal.fagbrev_status as "med_fagbrev" | "uten_fagbrev" | "mester",
            ansiennitet_min: mal.ansiennitet_min,
            ansiennitet_max: mal.ansiennitet_max,
            timesats: adjustedTimesats,
            maanedslonn: adjustedMaanedslonn,
          })
          .eq("id", editingSats.id);

        if (error) throw error;
      } else {
        const { error } = await supabase.from("tariff_satser").insert([{
          salon_id: salonId,
          aar: selectedYear,
          kilde_mal_id: selectedMal,
          avvik_fra_mal: avvik,
          fagbrev_status: mal.fagbrev_status as "med_fagbrev" | "uten_fagbrev" | "mester",
          ansiennitet_min: mal.ansiennitet_min,
          ansiennitet_max: mal.ansiennitet_max,
          timesats: adjustedTimesats,
          maanedslonn: adjustedMaanedslonn,
          gyldig_fra: `${selectedYear}-01-01`,
          opprettet_av: user?.id || null,
        }]);

        if (error) throw error;
      }

      toast({
        title: "Lagret",
        description: editingSats
          ? "Salong-tariff oppdatert"
          : "Ny salong-tariff opprettet",
      });
      setShowDialog(false);
      fetchData();
    } catch (error) {
      console.error("Error saving salon tariff:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke lagre tariff",
        variant: "destructive",
      });
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Er du sikker på at du vil slette denne salong-tariffen?")) return;

    try {
      const { error } = await supabase.from("tariff_satser").delete().eq("id", id);
      if (error) throw error;
      toast({ title: "Slettet", description: "Salong-tariff ble slettet" });
      fetchData();
    } catch (error) {
      console.error("Error deleting tariff:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke slette tariff",
        variant: "destructive",
      });
    }
  };

  const formatSeniority = (min: number, max: number | null) => {
    if (max === null) return `${min}+ år`;
    if (min === max) return `${min} år`;
    return `${min}-${max} år`;
  };

  const getSelectedMalPreview = () => {
    if (!selectedMal) return null;
    const mal = centralMaler.find((m) => m.id === selectedMal);
    if (!mal) return null;

    const avvik = parseFloat(avvikProsent) || 0;
    const adjustedTimesats = Math.round(mal.timesats * (1 + avvik / 100) * 100) / 100;

    return {
      original: mal.timesats,
      adjusted: adjustedTimesats,
      diff: adjustedTimesats - mal.timesats,
    };
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Salong-spesifikke tariffer</CardTitle>
            <CardDescription>
              Overstyr sentrale tariffer med egne satser
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Select
              value={selectedYear.toString()}
              onValueChange={(v) => setSelectedYear(parseInt(v))}
            >
              <SelectTrigger className="w-28">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {availableYears.map((year) => (
                  <SelectItem key={year} value={year.toString()}>
                    {year}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button onClick={() => handleOpenDialog()}>
              <Plus className="w-4 h-4 mr-2" />
              Legg til
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : salonTariffer.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Calculator className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>Ingen salong-spesifikke tariffer</p>
              <p className="text-sm mt-1">
                Sentrale tariffer brukes som standard
              </p>
              {centralMaler.length > 0 && (
                <Button
                  variant="outline"
                  className="mt-4"
                  onClick={() => handleOpenDialog()}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Opprett avvik fra sentral tariff
                </Button>
              )}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Fagbrevstatus</TableHead>
                  <TableHead>Ansiennitet</TableHead>
                  <TableHead className="text-right">Timesats</TableHead>
                  <TableHead className="text-right">Avvik</TableHead>
                  <TableHead className="text-right">Handlinger</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {salonTariffer.map((sats) => (
                  <TableRow key={sats.id}>
                    <TableCell>
                      <Badge variant="outline">
                        {fagbrevLabels[sats.fagbrev_status]}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {formatSeniority(sats.ansiennitet_min, sats.ansiennitet_max)}
                    </TableCell>
                    <TableCell className="text-right font-medium">
                      {sats.timesats.toLocaleString("nb-NO")} kr
                    </TableCell>
                    <TableCell className="text-right">
                      {sats.avvik_fra_mal !== null && (
                        <Badge
                          variant={sats.avvik_fra_mal >= 0 ? "default" : "secondary"}
                        >
                          {sats.avvik_fra_mal >= 0 ? "+" : ""}
                          {sats.avvik_fra_mal}%
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleOpenDialog(sats)}
                        >
                          <Pencil className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleDelete(sats.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Central Tariffs Reference */}
      {centralMaler.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Sentrale tariffer (referanse)</CardTitle>
            <CardDescription>
              Disse brukes dersom ingen salong-spesifikk sats er definert
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Navn</TableHead>
                  <TableHead>Fagbrevstatus</TableHead>
                  <TableHead>Ansiennitet</TableHead>
                  <TableHead className="text-right">Timesats</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {centralMaler.map((mal) => (
                  <TableRow key={mal.id} className="text-muted-foreground">
                    <TableCell>{mal.navn}</TableCell>
                    <TableCell>
                      <Badge variant="outline">
                        {fagbrevLabels[mal.fagbrev_status]}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {formatSeniority(mal.ansiennitet_min, mal.ansiennitet_max)}
                    </TableCell>
                    <TableCell className="text-right">
                      {mal.timesats.toLocaleString("nb-NO")} kr
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* Create/Edit Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>
              {editingSats ? "Rediger salong-tariff" : "Opprett salong-tariff"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Basert på sentral tariffmal</Label>
              <Select value={selectedMal || ""} onValueChange={setSelectedMal}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Velg mal..." />
                </SelectTrigger>
                <SelectContent className="max-w-[400px]">
                  {centralMaler.map((mal) => (
                    <SelectItem key={mal.id} value={mal.id} className="whitespace-nowrap">
                      <span className="truncate">{mal.navn}</span>
                      <span className="text-muted-foreground ml-1">({mal.timesats.toLocaleString("nb-NO")} kr)</span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="avvik">Avvik fra mal (%)</Label>
              <div className="flex items-center gap-2">
                <Input
                  id="avvik"
                  type="number"
                  step="0.1"
                  value={avvikProsent}
                  onChange={(e) => setAvvikProsent(e.target.value)}
                  className="w-24"
                />
                <span className="text-muted-foreground">%</span>
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                Positivt tall = høyere sats, negativt = lavere
              </p>
            </div>

            {getSelectedMalPreview() && (
              <div className="rounded-lg border p-3 bg-muted/30">
                <Label className="text-sm text-muted-foreground">Forhåndsvisning</Label>
                <div className="flex items-center gap-2 mt-2">
                  <span>{getSelectedMalPreview()!.original.toLocaleString("nb-NO")} kr</span>
                  <ArrowRight className="w-4 h-4" />
                  <span className="font-bold">
                    {getSelectedMalPreview()!.adjusted.toLocaleString("nb-NO")} kr
                  </span>
                  <Badge variant={getSelectedMalPreview()!.diff >= 0 ? "default" : "secondary"}>
                    {getSelectedMalPreview()!.diff >= 0 ? "+" : ""}
                    {getSelectedMalPreview()!.diff.toLocaleString("nb-NO")} kr
                  </Badge>
                </div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDialog(false)}>
              Avbryt
            </Button>
            <Button onClick={handleCreateFromMal} disabled={!selectedMal}>
              {editingSats ? "Oppdater" : "Opprett"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
