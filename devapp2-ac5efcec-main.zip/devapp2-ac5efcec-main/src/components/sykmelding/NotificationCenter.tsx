import { useMutation } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bell, Check, User, Calendar, ArrowRight } from "lucide-react";
import { format, formatDistanceToNow } from "date-fns";
import { nb } from "date-fns/locale";
import { Link } from "react-router-dom";
import { toast } from "sonner";

interface NotificationCenterProps {
  varsler: any[];
  onRefresh: () => void;
}

export function NotificationCenter({ varsler, onRefresh }: NotificationCenterProps) {
  const markAsRead = useMutation({
    mutationFn: async (varselId: string) => {
      const { error } = await supabase
        .from("sykmelding_varsler")
        .update({ lest: true, lest_dato: new Date().toISOString() })
        .eq("id", varselId);

      if (error) throw error;
    },
    onSuccess: () => {
      onRefresh();
    },
    onError: () => {
      toast.error("Kunne ikke markere som lest");
    },
  });

  const markAllAsRead = useMutation({
    mutationFn: async () => {
      const varselIds = varsler.map(v => v.id);
      const { error } = await supabase
        .from("sykmelding_varsler")
        .update({ lest: true, lest_dato: new Date().toISOString() })
        .in("id", varselIds);

      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Alle varsler markert som lest");
      onRefresh();
    },
    onError: () => {
      toast.error("Kunne ikke markere alle som lest");
    },
  });

  if (varsler.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <Bell className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
          <h3 className="text-lg font-semibold">Ingen uleste varsler</h3>
          <p className="text-muted-foreground mt-1">
            Du har ingen nye varsler om sykmeldinger.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <Bell className="h-5 w-5" />
          Nye varsler ({varsler.length})
        </h2>
        <Button
          variant="outline"
          size="sm"
          onClick={() => markAllAsRead.mutate()}
          disabled={markAllAsRead.isPending}
        >
          <Check className="h-4 w-4 mr-2" />
          Merk alle som lest
        </Button>
      </div>

      <div className="space-y-3">
        {varsler.map((varsel) => {
          const sykmelding = varsel.sykemeldinger;
          const ansattNavn = sykmelding?.users?.name || 'En ansatt';

          return (
            <Card key={varsel.id} className="border-primary/20 bg-primary/5">
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <User className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-base">
                        Ny sykmelding registrert
                      </CardTitle>
                      <CardDescription>
                        {ansattNavn} har registrert sykmelding
                      </CardDescription>
                    </div>
                  </div>
                  <Badge variant="secondary">
                    {formatDistanceToNow(new Date(varsel.created_at), { 
                      addSuffix: true, 
                      locale: nb 
                    })}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {sykmelding && (
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      Fra {format(new Date(sykmelding.startdato), 'dd. MMM', { locale: nb })}
                    </span>
                    <Badge variant="outline">{sykmelding.grad}% sykmeldt</Badge>
                  </div>
                )}

                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => markAsRead.mutate(varsel.id)}
                    disabled={markAsRead.isPending}
                  >
                    <Check className="h-4 w-4 mr-1" />
                    Merk som lest
                  </Button>
                  {sykmelding && (
                    <Link to={`/sykmelding/${sykmelding.id}`}>
                      <Button size="sm" className="gap-1">
                        Se sykmelding
                        <ArrowRight className="h-4 w-4" />
                      </Button>
                    </Link>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
