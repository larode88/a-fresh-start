import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useSalonContext } from "@/components/SalonSelector";
import { format, addWeeks } from "date-fns";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon, Upload } from "lucide-react";
import { cn } from "@/lib/utils";
import { nb } from "date-fns/locale";

const formSchema = z.object({
  startdato: z.date({ required_error: "Startdato er påkrevd" }),
  grad: z.string({ required_error: "Velg sykmeldingsgrad" }),
  forventet_varighet: z.string().optional(),
  beskrivelse: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

interface SykmeldingRegistreringDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
}

export function SykmeldingRegistreringDialog({
  open,
  onOpenChange,
  onSuccess,
}: SykmeldingRegistreringDialogProps) {
  const { user, profile } = useAuth();
  const { selectedSalonId } = useSalonContext();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      grad: "100",
      beskrivelse: "",
    },
  });

  const createSykmelding = useMutation({
    mutationFn: async (values: FormValues) => {
      if (!user?.id || !selectedSalonId) {
        throw new Error("Mangler bruker eller salong");
      }

      const forventetSluttdato = values.forventet_varighet
        ? addWeeks(values.startdato, parseInt(values.forventet_varighet))
        : null;

      // Opprett fravær-post først
      const { data: fravarData, error: fravarError } = await supabase
        .from("fravaer")
        .insert({
          user_id: user.id,
          salon_id: selectedSalonId,
          fravaerstype: "sykmelding",
          startdato: format(values.startdato, "yyyy-MM-dd"),
          sluttdato: forventetSluttdato 
            ? format(forventetSluttdato, "yyyy-MM-dd")
            : format(addWeeks(values.startdato, 52), "yyyy-MM-dd"),
          status: "aktiv",
          kommentar: values.beskrivelse,
        } as any)
        .select()
        .single();

      if (fravarError) throw fravarError;

      // Opprett sykmelding-post
      const { data: sykmeldingData, error: sykmeldingError } = await supabase
        .from("sykemeldinger")
        .insert({
          user_id: user.id,
          salon_id: selectedSalonId,
          fravar_id: fravarData.id,
          startdato: format(values.startdato, "yyyy-MM-dd"),
          forventet_sluttdato: forventetSluttdato 
            ? format(forventetSluttdato, "yyyy-MM-dd") 
            : null,
          grad: parseInt(values.grad),
          beskrivelse: values.beskrivelse,
          status: "aktiv",
        })
        .select()
        .single();

      if (sykmeldingError) throw sykmeldingError;

      // Send varsler til ledere i salongen
      const { data: ledere } = await supabase
        .from("users")
        .select("id")
        .eq("salon_id", selectedSalonId)
        .in("role", ["salon_owner", "daglig_leder", "avdelingsleder"]);

      if (ledere && ledere.length > 0) {
        const varsler = ledere.map((leder) => ({
          sykmelding_id: sykmeldingData.id,
          mottaker_id: leder.id,
        }));

        await supabase.from("sykmelding_varsler").insert(varsler);
      }

      return sykmeldingData;
    },
    onSuccess: () => {
      toast.success("Sykmelding registrert", {
        description: "Din leder vil bli varslet.",
      });
      form.reset();
      onSuccess();
    },
    onError: (error) => {
      console.error("Feil ved registrering:", error);
      toast.error("Kunne ikke registrere sykmelding");
    },
  });

  const onSubmit = async (values: FormValues) => {
    setIsSubmitting(true);
    try {
      await createSykmelding.mutateAsync(values);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Registrer sykmelding</DialogTitle>
          <DialogDescription>
            Fyll ut informasjon om sykmeldingen. Din leder vil bli varslet automatisk.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="startdato"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>Første sykmeldingsdag</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full pl-3 text-left font-normal",
                            !field.value && "text-muted-foreground"
                          )}
                        >
                          {field.value ? (
                            format(field.value, "PPP", { locale: nb })
                          ) : (
                            <span>Velg dato</span>
                          )}
                          <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={field.value}
                        onSelect={field.onChange}
                        disabled={(date) => date > new Date()}
                        initialFocus
                        locale={nb}
                      />
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="grad"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Sykmeldingsgrad</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Velg grad" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="20">20% - Jobber 80%</SelectItem>
                      <SelectItem value="40">40% - Jobber 60%</SelectItem>
                      <SelectItem value="50">50% - Jobber 50%</SelectItem>
                      <SelectItem value="60">60% - Jobber 40%</SelectItem>
                      <SelectItem value="80">80% - Jobber 20%</SelectItem>
                      <SelectItem value="100">100% - Helt sykmeldt</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="forventet_varighet"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Forventet varighet (valgfritt)</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Velg varighet" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="1">1 uke</SelectItem>
                      <SelectItem value="2">2 uker</SelectItem>
                      <SelectItem value="4">4 uker</SelectItem>
                      <SelectItem value="8">8 uker</SelectItem>
                      <SelectItem value="12">12 uker</SelectItem>
                      <SelectItem value="26">26 uker</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormDescription>
                    Anslått varighet basert på sykmelding
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="beskrivelse"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Arbeidsmessige begrensninger (valgfritt)</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Beskriv eventuelle begrensninger eller behov for tilrettelegging..."
                      className="resize-none"
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>
                    Informasjon som kan hjelpe med tilrettelegging
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex justify-end gap-3 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
              >
                Avbryt
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? "Registrerer..." : "Registrer sykmelding"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
