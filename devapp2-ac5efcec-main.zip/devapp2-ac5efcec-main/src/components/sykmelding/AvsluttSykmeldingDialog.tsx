import { useState } from "react";
import { useForm } from "react-hook-form";
import { useMutation } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon } from "lucide-react";
import { format } from "date-fns";
import { nb } from "date-fns/locale";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface AvsluttSykmeldingDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  sykmelding: any;
  onSuccess: () => void;
}

const AVSLUTNINGSTYPER = {
  friskmeldt: "Friskmeldt - tilbake i full jobb",
  gradert_retur: "Gradert retur til arbeid",
  aap: "Overgang til arbeidsavklaringspenger (AAP)",
  annet: "Annet",
};

export function AvsluttSykmeldingDialog({
  open,
  onOpenChange,
  sykmelding,
  onSuccess,
}: AvsluttSykmeldingDialogProps) {
  const { user } = useAuth();
  const [sluttdato, setSluttdato] = useState<Date>();
  const [avslutningstype, setAvslutningstype] = useState<string>("");

  const form = useForm({
    defaultValues: {
      oppsummering: "",
    },
  });

  const avsluttSykmelding = useMutation({
    mutationFn: async (data: any) => {
      // Oppdater sykmelding
      const { error: sykmeldingError } = await supabase
        .from("sykemeldinger")
        .update({
          status: "avsluttet",
          faktisk_sluttdato: sluttdato ? format(sluttdato, "yyyy-MM-dd") : format(new Date(), "yyyy-MM-dd"),
          avsluttet_dato: new Date().toISOString(),
          avslutningstype: avslutningstype,
          avslutnings_oppsummering: data.oppsummering,
        })
        .eq("id", sykmelding.id);

      if (sykmeldingError) throw sykmeldingError;

      // Oppdater fravaer
      if (sykmelding.fravar_id) {
        const { error: fravarError } = await supabase
          .from("fravaer")
          .update({
            sluttdato: sluttdato ? format(sluttdato, "yyyy-MM-dd") : format(new Date(), "yyyy-MM-dd"),
            status: "avsluttet",
          })
          .eq("id", sykmelding.fravar_id);

        if (fravarError) console.error("Kunne ikke oppdatere fravær:", fravarError);
      }
    },
    onSuccess: () => {
      toast.success("Sykmelding avsluttet");
      onOpenChange(false);
      onSuccess();
    },
    onError: () => {
      toast.error("Kunne ikke avslutte sykmelding");
    },
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Avslutt sykmelding</DialogTitle>
          <DialogDescription>
            Registrer avslutning av sykmeldingsperioden
          </DialogDescription>
        </DialogHeader>

        <form 
          onSubmit={form.handleSubmit((data) => avsluttSykmelding.mutate(data))}
          className="space-y-4"
        >
          <div className="space-y-2">
            <Label>Sluttdato</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !sluttdato && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {sluttdato ? format(sluttdato, "PPP", { locale: nb }) : "Velg sluttdato"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={sluttdato}
                  onSelect={setSluttdato}
                  disabled={(date) => date < new Date(sykmelding.startdato)}
                  initialFocus
                  locale={nb}
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="space-y-2">
            <Label>Avslutningstype</Label>
            <Select onValueChange={setAvslutningstype} value={avslutningstype}>
              <SelectTrigger>
                <SelectValue placeholder="Velg type avslutning" />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(AVSLUTNINGSTYPER).map(([value, label]) => (
                  <SelectItem key={value} value={value}>
                    {label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Oppsummering (valgfritt)</Label>
            <Textarea
              {...form.register("oppsummering")}
              placeholder="Kort oppsummering av sykmeldingsperioden..."
              rows={4}
            />
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              Avbryt
            </Button>
            <Button 
              type="submit" 
              disabled={avsluttSykmelding.isPending || !avslutningstype}
            >
              {avsluttSykmelding.isPending ? "Avslutter..." : "Avslutt sykmelding"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
