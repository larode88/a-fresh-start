import { useState } from "react";
import { useForm } from "react-hook-form";
import { useMutation } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, Settings, User, Users, Laptop, CheckCircle } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";
import { nb } from "date-fns/locale";

interface TiltakOversiktProps {
  sykmelding: any;
  isLeader: boolean;
  onRefresh: () => void;
}

const TILTAK_TYPER = {
  fysisk: { label: "Fysisk", icon: Settings, color: "bg-blue-100 text-blue-700" },
  organisatorisk: { label: "Organisatorisk", icon: Users, color: "bg-purple-100 text-purple-700" },
  sosial: { label: "Sosial", icon: User, color: "bg-green-100 text-green-700" },
  teknisk: { label: "Teknisk", icon: Laptop, color: "bg-orange-100 text-orange-700" },
};

const STATUS_FARGER = {
  planlagt: "secondary",
  igang: "default",
  fullfort: "outline",
  avbrutt: "destructive",
};

export function TiltakOversikt({ sykmelding, isLeader, onRefresh }: TiltakOversiktProps) {
  const { user } = useAuth();
  const [showNyttTiltakDialog, setShowNyttTiltakDialog] = useState(false);

  const tiltak = sykmelding.sykmelding_tiltak || [];

  const form = useForm({
    defaultValues: {
      tittel: "",
      beskrivelse: "",
      type: "fysisk",
      frist: "",
    },
  });

  const createTiltak = useMutation({
    mutationFn: async (data: any) => {
      const { error } = await supabase
        .from("sykmelding_tiltak")
        .insert({
          sykmelding_id: sykmelding.id,
          tittel: data.tittel,
          beskrivelse: data.beskrivelse,
          type: data.type,
          frist: data.frist || null,
          ansvarlig_id: user?.id,
          status: "planlagt",
        });

      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Tiltak opprettet");
      setShowNyttTiltakDialog(false);
      form.reset();
      onRefresh();
    },
    onError: () => {
      toast.error("Kunne ikke opprette tiltak");
    },
  });

  const updateTiltakStatus = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const updates: any = { status };
      if (status === "fullfort") {
        updates.fullfort_dato = new Date().toISOString().split("T")[0];
      }

      const { error } = await supabase
        .from("sykmelding_tiltak")
        .update(updates)
        .eq("id", id);

      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Status oppdatert");
      onRefresh();
    },
    onError: () => {
      toast.error("Kunne ikke oppdatere status");
    },
  });

  // Grupper tiltak etter type
  const tiltakByType = Object.keys(TILTAK_TYPER).reduce((acc, type) => {
    acc[type] = tiltak.filter((t: any) => t.type === type);
    return acc;
  }, {} as Record<string, any[]>);

  return (
    <div className="space-y-6">
      {/* Header med legg til-knapp */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">Tilretteleggingstiltak</h2>
          <p className="text-sm text-muted-foreground">
            {tiltak.length} tiltak registrert
          </p>
        </div>
        {isLeader && (
          <Button onClick={() => setShowNyttTiltakDialog(true)} className="gap-2">
            <Plus className="h-4 w-4" />
            Nytt tiltak
          </Button>
        )}
      </div>

      {/* Tiltak gruppert etter type */}
      <div className="grid gap-4 md:grid-cols-2">
        {Object.entries(TILTAK_TYPER).map(([type, config]) => {
          const typeTiltak = tiltakByType[type] || [];
          const Icon = config.icon;

          return (
            <Card key={type}>
              <CardHeader className="pb-3">
                <div className="flex items-center gap-2">
                  <div className={`h-8 w-8 rounded-lg ${config.color} flex items-center justify-center`}>
                    <Icon className="h-4 w-4" />
                  </div>
                  <div>
                    <CardTitle className="text-base">{config.label} tilrettelegging</CardTitle>
                    <CardDescription>{typeTiltak.length} tiltak</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {typeTiltak.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    Ingen tiltak registrert
                  </p>
                ) : (
                  <div className="space-y-3">
                    {typeTiltak.map((t: any) => (
                      <div 
                        key={t.id}
                        className="p-3 border rounded-lg space-y-2"
                      >
                        <div className="flex items-start justify-between">
                          <p className="font-medium">{t.tittel}</p>
                          <Badge variant={STATUS_FARGER[t.status as keyof typeof STATUS_FARGER] as any}>
                            {t.status === 'planlagt' ? 'Planlagt' :
                             t.status === 'igang' ? 'I gang' :
                             t.status === 'fullfort' ? 'Fullført' : 'Avbrutt'}
                          </Badge>
                        </div>
                        {t.beskrivelse && (
                          <p className="text-sm text-muted-foreground">{t.beskrivelse}</p>
                        )}
                        {t.frist && (
                          <p className="text-xs text-muted-foreground">
                            Frist: {format(new Date(t.frist), 'dd. MMM yyyy', { locale: nb })}
                          </p>
                        )}
                        
                        {isLeader && t.status !== 'fullfort' && t.status !== 'avbrutt' && (
                          <div className="flex gap-2 pt-2">
                            {t.status === 'planlagt' && (
                              <Button 
                                size="sm" 
                                variant="outline"
                                onClick={() => updateTiltakStatus.mutate({ id: t.id, status: 'igang' })}
                              >
                                Start
                              </Button>
                            )}
                            <Button 
                              size="sm" 
                              variant="outline"
                              className="gap-1"
                              onClick={() => updateTiltakStatus.mutate({ id: t.id, status: 'fullfort' })}
                            >
                              <CheckCircle className="h-3 w-3" />
                              Fullfør
                            </Button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Nytt tiltak dialog */}
      <Dialog open={showNyttTiltakDialog} onOpenChange={setShowNyttTiltakDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Opprett nytt tiltak</DialogTitle>
            <DialogDescription>
              Legg til et tilretteleggingstiltak
            </DialogDescription>
          </DialogHeader>

          <form 
            onSubmit={form.handleSubmit((data) => createTiltak.mutate(data))}
            className="space-y-4"
          >
            <div className="space-y-2">
              <Label>Tittel</Label>
              <Input
                {...form.register("tittel", { required: true })}
                placeholder="Kort beskrivende tittel..."
              />
            </div>

            <div className="space-y-2">
              <Label>Type</Label>
              <Select 
                onValueChange={(value) => form.setValue("type", value)}
                defaultValue="fysisk"
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(TILTAK_TYPER).map(([type, config]) => (
                    <SelectItem key={type} value={type}>
                      {config.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Beskrivelse</Label>
              <Textarea
                {...form.register("beskrivelse")}
                placeholder="Detaljert beskrivelse av tiltaket..."
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label>Frist (valgfritt)</Label>
              <Input
                type="date"
                {...form.register("frist")}
              />
            </div>

            <div className="flex justify-end gap-3">
              <Button 
                type="button" 
                variant="outline"
                onClick={() => setShowNyttTiltakDialog(false)}
              >
                Avbryt
              </Button>
              <Button type="submit" disabled={createTiltak.isPending}>
                {createTiltak.isPending ? "Oppretter..." : "Opprett tiltak"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
