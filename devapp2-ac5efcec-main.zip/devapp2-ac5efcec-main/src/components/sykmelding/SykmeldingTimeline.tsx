import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Clock, AlertTriangle, Circle } from "lucide-react";
import { differenceInWeeks, addWeeks, format } from "date-fns";
import { nb } from "date-fns/locale";

interface SykmeldingTimelineProps {
  sykmelding: any;
}

const MILEPELER = [
  { uke: 0, label: "Sykmelding startet", type: "start" },
  { uke: 4, label: "Oppfølgingsplan", type: "deadline", check: "plan" },
  { uke: 7, label: "Dialogmøte 1", type: "deadline", check: "dialogmote1" },
  { uke: 8, label: "Aktivitetskrav", type: "deadline", check: "aktivitetskrav" },
  { uke: 26, label: "Dialogmøte 2", type: "milestone", check: "dialogmote2" },
  { uke: 39, label: "Senfase", type: "milestone" },
  { uke: 52, label: "Maksimal varighet", type: "end" },
];

export function SykmeldingTimeline({ sykmelding }: SykmeldingTimelineProps) {
  const startDato = new Date(sykmelding.startdato);
  const ukerNa = differenceInWeeks(new Date(), startDato);

  // Sjekk status for hver milepæl
  const getStatus = (milepel: typeof MILEPELER[0]) => {
    if (milepel.check === "plan") {
      return sykmelding.sykmelding_oppfolgingsplaner?.some((p: any) => p.laast);
    }
    if (milepel.check === "dialogmote1") {
      return sykmelding.sykmelding_dialogmoter?.some(
        (m: any) => m.motetype === 'dialogmote_1' && m.status === 'gjennomfort'
      );
    }
    if (milepel.check === "dialogmote2") {
      return sykmelding.sykmelding_dialogmoter?.some(
        (m: any) => m.motetype === 'dialogmote_2' && m.status === 'gjennomfort'
      );
    }
    if (milepel.check === "aktivitetskrav") {
      return sykmelding.sykmelding_aktivitetskrav?.length > 0;
    }
    return null;
  };

  const getMilepelIcon = (milepel: typeof MILEPELER[0]) => {
    const status = getStatus(milepel);
    const erPassert = ukerNa >= milepel.uke;
    const erAktuell = ukerNa >= milepel.uke - 1 && ukerNa < milepel.uke + 1;

    if (milepel.type === "start") {
      return <CheckCircle className="h-5 w-5 text-green-500" />;
    }

    if (status === true) {
      return <CheckCircle className="h-5 w-5 text-green-500" />;
    }

    if (status === false && erPassert) {
      return <AlertTriangle className="h-5 w-5 text-destructive" />;
    }

    if (erAktuell) {
      return <Clock className="h-5 w-5 text-primary animate-pulse" />;
    }

    if (erPassert) {
      return <Clock className="h-5 w-5 text-yellow-500" />;
    }

    return <Circle className="h-5 w-5 text-muted-foreground" />;
  };

  const getMilepelBadge = (milepel: typeof MILEPELER[0]) => {
    const status = getStatus(milepel);
    const erPassert = ukerNa >= milepel.uke;

    if (milepel.type === "start") {
      return <Badge variant="default">Fullført</Badge>;
    }

    if (status === true) {
      return <Badge variant="default">Fullført</Badge>;
    }

    if (status === false && erPassert) {
      return <Badge variant="destructive">Forfalt</Badge>;
    }

    if (ukerNa >= milepel.uke - 1 && ukerNa < milepel.uke + 1) {
      return <Badge variant="secondary">Pågår</Badge>;
    }

    return <Badge variant="outline">Kommende</Badge>;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Oppfølgingstidslinje</CardTitle>
        <CardDescription>
          NAV-kompatibelt 0-52 ukers løp · Nå: Uke {ukerNa}
        </CardDescription>
      </CardHeader>
      <CardContent>
        {/* Visuell progress-bar */}
        <div className="mb-8">
          <div className="relative h-2 bg-muted rounded-full overflow-hidden">
            <div 
              className="absolute left-0 top-0 h-full bg-primary rounded-full transition-all duration-500"
              style={{ width: `${Math.min((ukerNa / 52) * 100, 100)}%` }}
            />
          </div>
          <div className="flex justify-between mt-2 text-xs text-muted-foreground">
            <span>Uke 0</span>
            <span>Uke 26</span>
            <span>Uke 52</span>
          </div>
        </div>

        {/* Tidslinje */}
        <div className="relative">
          {/* Vertikal linje */}
          <div className="absolute left-5 top-0 bottom-0 w-0.5 bg-muted" />

          <div className="space-y-6">
            {MILEPELER.map((milepel, index) => {
              const dato = addWeeks(startDato, milepel.uke);
              const erAktuell = ukerNa >= milepel.uke - 1 && ukerNa < milepel.uke + 1;

              return (
                <div 
                  key={index}
                  className={`relative flex items-start gap-4 ${erAktuell ? 'scale-[1.02]' : ''} transition-transform`}
                >
                  {/* Ikon */}
                  <div className="relative z-10 h-10 w-10 rounded-full bg-background border-2 flex items-center justify-center">
                    {getMilepelIcon(milepel)}
                  </div>

                  {/* Innhold */}
                  <div className="flex-1 pb-6">
                    <div className="flex items-center gap-3 flex-wrap">
                      <h4 className="font-semibold">{milepel.label}</h4>
                      {getMilepelBadge(milepel)}
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">
                      Uke {milepel.uke} · {format(dato, 'dd. MMMM yyyy', { locale: nb })}
                    </p>
                    
                    {/* Ekstra info for spesifikke milepæler */}
                    {milepel.check === "plan" && getStatus(milepel) && (
                      <p className="text-sm text-green-600 mt-1">
                        ✓ Oppfølgingsplan godkjent
                      </p>
                    )}
                    {milepel.check === "dialogmote1" && getStatus(milepel) && (
                      <p className="text-sm text-green-600 mt-1">
                        ✓ Dialogmøte 1 gjennomført
                      </p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Nåværende posisjon-indikator */}
        <div className="mt-6 p-4 bg-primary/10 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium">Nåværende posisjon</p>
              <p className="text-sm text-muted-foreground">
                Uke {ukerNa} av 52 ({Math.round((ukerNa / 52) * 100)}% av løpet)
              </p>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold">{52 - ukerNa}</p>
              <p className="text-sm text-muted-foreground">uker gjenstår</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
