import { useState } from "react";
import { useForm } from "react-hook-form";
import { useMutation } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { TrendingUp, Plus, CheckCircle } from "lucide-react";
import { toast } from "sonner";
import { format, differenceInWeeks } from "date-fns";
import { nb } from "date-fns/locale";

interface FasevurderingDialogProps {
  sykmelding: any;
  isLeader: boolean;
  onRefresh: () => void;
}

const FASER = {
  tidlig: { label: "Tidlig fase", uker: "0-4", beskrivelse: "Første uker med fokus på kartlegging" },
  aktiv: { label: "Aktiv fase", uker: "4-8", beskrivelse: "Oppfølgingsplan og dialogmøte 1" },
  midt: { label: "Midtfase", uker: "8-26", beskrivelse: "Aktivitetskrav og gradert retur" },
  sen: { label: "Senfase", uker: "26-52", beskrivelse: "Dialogmøte 2 og langsiktig plan" },
};

export function FasevurderingDialog({ sykmelding, isLeader, onRefresh }: FasevurderingDialogProps) {
  const { user } = useAuth();
  const [showNyVurderingDialog, setShowNyVurderingDialog] = useState(false);
  const [selectedFase, setSelectedFase] = useState<string | null>(null);

  const uker = differenceInWeeks(new Date(), new Date(sykmelding.startdato));
  const fasevurderinger = sykmelding.sykmelding_fasevurderinger || [];

  const getCurrentFase = () => {
    if (uker < 4) return "tidlig";
    if (uker < 8) return "aktiv";
    if (uker < 26) return "midt";
    return "sen";
  };

  const currentFase = getCurrentFase();

  const form = useForm({
    defaultValues: {
      status_vurdering: "",
      fremgang: "",
      utfordringer: "",
      neste_steg: "",
    },
  });

  const createVurdering = useMutation({
    mutationFn: async (data: any) => {
      const { error } = await supabase
        .from("sykmelding_fasevurderinger")
        .insert({
          sykmelding_id: sykmelding.id,
          fase: selectedFase,
          status_vurdering: data.status_vurdering,
          fremgang: data.fremgang,
          utfordringer: data.utfordringer,
          neste_steg: data.neste_steg,
          vurdert_av: user?.id,
        } as any);

      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Fasevurdering lagret");
      setShowNyVurderingDialog(false);
      form.reset();
      onRefresh();
    },
    onError: () => {
      toast.error("Kunne ikke lagre vurdering");
    },
  });

  const getVurderingForFase = (fase: string) => {
    return fasevurderinger.find((v: any) => v.fase === fase);
  };

  const handleNyVurdering = (fase: string) => {
    setSelectedFase(fase);
    setShowNyVurderingDialog(true);
  };

  return (
    <div className="space-y-6">
      {/* Fase-indikator */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Nåværende fase
          </CardTitle>
          <CardDescription>
            Uke {uker} av sykmeldingsløpet
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            {Object.entries(FASER).map(([fase, info], index) => {
              const erAktiv = fase === currentFase;
              const erPassert = Object.keys(FASER).indexOf(fase) < Object.keys(FASER).indexOf(currentFase);
              const harVurdering = !!getVurderingForFase(fase);

              return (
                <div key={fase} className="flex items-center gap-2">
                  <div 
                    className={`h-10 w-10 rounded-full flex items-center justify-center text-sm font-medium ${
                      erAktiv ? 'bg-primary text-primary-foreground' :
                      erPassert ? 'bg-green-100 text-green-700' :
                      'bg-muted text-muted-foreground'
                    }`}
                  >
                    {harVurdering ? <CheckCircle className="h-5 w-5" /> : index + 1}
                  </div>
                  {index < Object.keys(FASER).length - 1 && (
                    <div className={`h-0.5 w-8 ${erPassert || erAktiv ? 'bg-primary' : 'bg-muted'}`} />
                  )}
                </div>
              );
            })}
          </div>
          <div className="mt-4">
            <Badge variant="default" className="text-sm">
              {FASER[currentFase as keyof typeof FASER].label} ({FASER[currentFase as keyof typeof FASER].uker} uker)
            </Badge>
            <p className="text-sm text-muted-foreground mt-2">
              {FASER[currentFase as keyof typeof FASER].beskrivelse}
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Fasevurderinger */}
      <div className="grid gap-4 md:grid-cols-2">
        {Object.entries(FASER).map(([fase, info]) => {
          const vurdering = getVurderingForFase(fase);
          const erAktuell = fase === currentFase || 
            Object.keys(FASER).indexOf(fase) < Object.keys(FASER).indexOf(currentFase);

          return (
            <Card key={fase} className={!erAktuell ? "opacity-50" : ""}>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-base">{info.label}</CardTitle>
                    <CardDescription>Uke {info.uker}</CardDescription>
                  </div>
                  {vurdering ? (
                    <Badge variant="default" className="gap-1">
                      <CheckCircle className="h-3 w-3" />
                      Vurdert
                    </Badge>
                  ) : erAktuell ? (
                    <Badge variant="secondary">Ikke vurdert</Badge>
                  ) : null}
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {vurdering ? (
                  <div className="space-y-2 text-sm">
                    <p className="text-muted-foreground">
                      Vurdert {format(new Date(vurdering.vurdert_dato), 'dd. MMM yyyy', { locale: nb })}
                    </p>
                    {vurdering.status_vurdering && (
                      <div>
                        <span className="font-medium">Status: </span>
                        <span className="text-muted-foreground">{vurdering.status_vurdering}</span>
                      </div>
                    )}
                    {vurdering.fremgang && (
                      <div>
                        <span className="font-medium">Fremgang: </span>
                        <span className="text-muted-foreground">{vurdering.fremgang}</span>
                      </div>
                    )}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground">{info.beskrivelse}</p>
                )}

                {isLeader && erAktuell && !vurdering && (
                  <Button 
                    variant="outline" 
                    size="sm"
                    className="w-full gap-2"
                    onClick={() => handleNyVurdering(fase)}
                  >
                    <Plus className="h-4 w-4" />
                    Legg til vurdering
                  </Button>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Ny vurdering dialog */}
      <Dialog open={showNyVurderingDialog} onOpenChange={setShowNyVurderingDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>
              Fasevurdering: {selectedFase && FASER[selectedFase as keyof typeof FASER]?.label}
            </DialogTitle>
            <DialogDescription>
              Vurder status og fremgang i denne fasen
            </DialogDescription>
          </DialogHeader>

          <form 
            onSubmit={form.handleSubmit((data) => createVurdering.mutate(data))}
            className="space-y-4"
          >
            <div className="space-y-2">
              <Label>Status-vurdering</Label>
              <Textarea
                {...form.register("status_vurdering")}
                placeholder="Hvordan er situasjonen nå..."
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label>Fremgang</Label>
              <Textarea
                {...form.register("fremgang")}
                placeholder="Hva har gått bra siden sist..."
                rows={2}
              />
            </div>

            <div className="space-y-2">
              <Label>Utfordringer</Label>
              <Textarea
                {...form.register("utfordringer")}
                placeholder="Eventuelle utfordringer eller hindringer..."
                rows={2}
              />
            </div>

            <div className="space-y-2">
              <Label>Neste steg</Label>
              <Textarea
                {...form.register("neste_steg")}
                placeholder="Hva er de neste stegene..."
                rows={2}
              />
            </div>

            <div className="flex justify-end gap-3">
              <Button 
                type="button" 
                variant="outline"
                onClick={() => setShowNyVurderingDialog(false)}
              >
                Avbryt
              </Button>
              <Button type="submit" disabled={createVurdering.isPending}>
                {createVurdering.isPending ? "Lagrer..." : "Lagre vurdering"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
