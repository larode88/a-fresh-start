import { useState } from "react";
import { useForm } from "react-hook-form";
import { useMutation } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Users, CalendarIcon, CheckCircle, Clock, Plus } from "lucide-react";
import { toast } from "sonner";
import { format, differenceInWeeks } from "date-fns";
import { nb } from "date-fns/locale";
import { cn } from "@/lib/utils";

interface DialogmoteDialogProps {
  sykmelding: any;
  isLeader: boolean;
  onRefresh: () => void;
}

const DIALOGMOTE_INFO = {
  dialogmote_1: {
    title: "Dialogmøte 1",
    description: "Første statusmøte mellom leder og ansatt",
    frist: "Innen uke 7",
    ukeNr: 7,
  },
  dialogmote_2: {
    title: "Dialogmøte 2",
    description: "Halvårsstatus - NAV kan inviteres",
    frist: "Innen uke 26",
    ukeNr: 26,
  },
  dialogmote_3: {
    title: "Dialogmøte 3",
    description: "Ekstra møte ved behov i senfase",
    frist: "Ved behov",
    ukeNr: 39,
  },
};

export function DialogmoteDialog({ sykmelding, isLeader, onRefresh }: DialogmoteDialogProps) {
  const { user } = useAuth();
  const [showPlanleggDialog, setShowPlanleggDialog] = useState(false);
  const [selectedMoteType, setSelectedMoteType] = useState<string | null>(null);
  const [planlagtDato, setPlanlagtDato] = useState<Date>();

  const uker = differenceInWeeks(new Date(), new Date(sykmelding.startdato));
  const dialogmoter = sykmelding.sykmelding_dialogmoter || [];

  const form = useForm({
    defaultValues: {
      agenda: "",
      forberedelse_leder: "",
    },
  });

  const getMoteStatus = (type: string) => {
    const mote = dialogmoter.find((m: any) => m.motetype === type);
    if (!mote) return null;
    return mote;
  };

  const createDialogmote = useMutation({
    mutationFn: async (data: any) => {
      const { error } = await supabase
        .from("sykmelding_dialogmoter")
        .insert({
          sykmelding_id: sykmelding.id,
          motetype: selectedMoteType,
          status: "planlagt",
          planlagt_dato: planlagtDato?.toISOString(),
          agenda: data.agenda,
          forberedelse_leder: data.forberedelse_leder,
          opprettet_av: user?.id,
        } as any);

      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Dialogmøte planlagt");
      setShowPlanleggDialog(false);
      form.reset();
      setPlanlagtDato(undefined);
      onRefresh();
    },
    onError: () => {
      toast.error("Kunne ikke opprette dialogmøte");
    },
  });

  const markAsCompleted = useMutation({
    mutationFn: async (moteId: string) => {
      const { error } = await supabase
        .from("sykmelding_dialogmoter")
        .update({
          status: "gjennomfort",
          gjennomfort_dato: new Date().toISOString(),
        })
        .eq("id", moteId);

      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Dialogmøte markert som gjennomført");
      onRefresh();
    },
    onError: () => {
      toast.error("Kunne ikke oppdatere status");
    },
  });

  const handlePlanlegg = (type: string) => {
    setSelectedMoteType(type);
    setShowPlanleggDialog(true);
  };

  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-3">
        {Object.entries(DIALOGMOTE_INFO).map(([type, info]) => {
          const mote = getMoteStatus(type);
          const erGjennomfort = mote?.status === "gjennomfort";
          const erPlanlagt = mote?.status === "planlagt";
          const erForfallt = !mote && uker >= info.ukeNr;
          const erAktuell = uker >= (info.ukeNr - 1) && !erGjennomfort;

          return (
            <Card 
              key={type}
              className={cn(
                erForfallt && "border-destructive/50 bg-destructive/5",
                erGjennomfort && "border-green-500/50 bg-green-50/50"
              )}
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-base">{info.title}</CardTitle>
                    <CardDescription>{info.frist}</CardDescription>
                  </div>
                  {erGjennomfort ? (
                    <CheckCircle className="h-5 w-5 text-green-500" />
                  ) : erPlanlagt ? (
                    <Clock className="h-5 w-5 text-yellow-500" />
                  ) : erForfallt ? (
                    <Badge variant="destructive">Forfalt</Badge>
                  ) : null}
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm text-muted-foreground">{info.description}</p>

                {erPlanlagt && mote.planlagt_dato && (
                  <div className="flex items-center gap-2 text-sm">
                    <CalendarIcon className="h-4 w-4 text-muted-foreground" />
                    <span>
                      Planlagt: {format(new Date(mote.planlagt_dato), 'dd. MMM yyyy', { locale: nb })}
                    </span>
                  </div>
                )}

                {erGjennomfort && mote.gjennomfort_dato && (
                  <div className="flex items-center gap-2 text-sm text-green-600">
                    <CheckCircle className="h-4 w-4" />
                    <span>
                      Gjennomført: {format(new Date(mote.gjennomfort_dato), 'dd. MMM yyyy', { locale: nb })}
                    </span>
                  </div>
                )}

                {isLeader && (
                  <div className="pt-2">
                    {!mote && erAktuell && (
                      <Button 
                        size="sm" 
                        className="w-full gap-2"
                        onClick={() => handlePlanlegg(type)}
                      >
                        <Plus className="h-4 w-4" />
                        Planlegg møte
                      </Button>
                    )}

                    {erPlanlagt && (
                      <Button 
                        size="sm" 
                        variant="outline"
                        className="w-full gap-2"
                        onClick={() => markAsCompleted.mutate(mote.id)}
                        disabled={markAsCompleted.isPending}
                      >
                        <CheckCircle className="h-4 w-4" />
                        Merk som gjennomført
                      </Button>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Møtehistorikk */}
      {dialogmoter.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Møtehistorikk
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {dialogmoter.map((mote: any) => (
                <div 
                  key={mote.id}
                  className="flex items-center justify-between p-3 border rounded-lg"
                >
                  <div>
                    <p className="font-medium">
                      {DIALOGMOTE_INFO[mote.motetype as keyof typeof DIALOGMOTE_INFO]?.title || mote.motetype}
                    </p>
                    {mote.agenda && (
                      <p className="text-sm text-muted-foreground line-clamp-1">{mote.agenda}</p>
                    )}
                  </div>
                  <div className="text-right">
                    <Badge variant={mote.status === 'gjennomfort' ? 'default' : 'secondary'}>
                      {mote.status === 'gjennomfort' ? 'Gjennomført' : 
                       mote.status === 'planlagt' ? 'Planlagt' : mote.status}
                    </Badge>
                    {mote.planlagt_dato && (
                      <p className="text-xs text-muted-foreground mt-1">
                        {format(new Date(mote.planlagt_dato), 'dd. MMM yyyy', { locale: nb })}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Planlegg dialog */}
      <Dialog open={showPlanleggDialog} onOpenChange={setShowPlanleggDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>
              Planlegg {selectedMoteType && DIALOGMOTE_INFO[selectedMoteType as keyof typeof DIALOGMOTE_INFO]?.title}
            </DialogTitle>
            <DialogDescription>
              Sett opp dato og agenda for dialogmøtet
            </DialogDescription>
          </DialogHeader>

          <form 
            onSubmit={form.handleSubmit((data) => createDialogmote.mutate(data))}
            className="space-y-4"
          >
            <div className="space-y-2">
              <Label>Dato for møtet</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !planlagtDato && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {planlagtDato ? format(planlagtDato, "PPP", { locale: nb }) : "Velg dato"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={planlagtDato}
                    onSelect={setPlanlagtDato}
                    disabled={(date) => date < new Date()}
                    initialFocus
                    locale={nb}
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label>Agenda</Label>
              <Textarea
                {...form.register("agenda")}
                placeholder="Hva skal diskuteres i møtet..."
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label>Forberedelse fra leder</Label>
              <Textarea
                {...form.register("forberedelse_leder")}
                placeholder="Notater og forberedelser til møtet..."
                rows={3}
              />
            </div>

            <div className="flex justify-end gap-3">
              <Button 
                type="button" 
                variant="outline"
                onClick={() => setShowPlanleggDialog(false)}
              >
                Avbryt
              </Button>
              <Button 
                type="submit" 
                disabled={createDialogmote.isPending || !planlagtDato}
              >
                {createDialogmote.isPending ? "Lagrer..." : "Planlegg møte"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
