import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { AlertTriangle, CheckCircle, Clock, ArrowRight, User } from "lucide-react";
import { differenceInWeeks, format } from "date-fns";
import { nb } from "date-fns/locale";
import { Link } from "react-router-dom";

interface TrafficLight {
  color: "red" | "yellow" | "green";
  text: string;
  priority: number;
}

interface SykmeldingDashboardProps {
  sykmeldinger: any[];
  isLoading: boolean;
}

export function SykmeldingDashboard({ sykmeldinger, isLoading }: SykmeldingDashboardProps) {
  const getTrafficLight = (sykmelding: any): TrafficLight => {
    const uker = differenceInWeeks(new Date(), new Date(sykmelding.startdato));
    const harPlan = sykmelding.sykmelding_oppfolgingsplaner?.some((p: any) => p.laast);
    const harDialogmote1 = sykmelding.sykmelding_dialogmoter?.some(
      (m: any) => m.motetype === 'dialogmote_1' && m.status === 'gjennomfort'
    );

    // 🔴 KRITISK
    if (uker >= 7 && !harDialogmote1) {
      return { color: "red", text: "Dialogmøte 1 er forsinket", priority: 3 };
    }
    if (uker >= 4 && !harPlan) {
      return { color: "red", text: "Oppfølgingsplan mangler", priority: 3 };
    }

    // 🟡 ADVARSEL
    if (uker >= 6 && !harDialogmote1) {
      return { color: "yellow", text: "Dialogmøte 1 må planlegges nå", priority: 2 };
    }
    if (uker >= 3 && !harPlan) {
      return { color: "yellow", text: "Oppfølgingsplan må lages", priority: 2 };
    }

    // 🟢 OK
    return { color: "green", text: "Alt i rute", priority: 0 };
  };

  const getTrafficLightIcon = (color: string) => {
    switch (color) {
      case "red":
        return <AlertTriangle className="h-5 w-5 text-destructive" />;
      case "yellow":
        return <Clock className="h-5 w-5 text-yellow-500" />;
      default:
        return <CheckCircle className="h-5 w-5 text-green-500" />;
    }
  };

  const getTrafficLightBadge = (color: string) => {
    switch (color) {
      case "red":
        return "destructive";
      case "yellow":
        return "secondary";
      default:
        return "outline";
    }
  };

  // Sorter etter prioritet (kritisk først)
  const sortedSykmeldinger = [...sykmeldinger].sort((a, b) => {
    const aLight = getTrafficLight(a);
    const bLight = getTrafficLight(b);
    return bLight.priority - aLight.priority;
  });

  if (isLoading) {
    return (
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {[1, 2, 3].map((i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader className="pb-3">
              <div className="h-4 w-32 bg-muted rounded" />
              <div className="h-3 w-24 bg-muted rounded mt-2" />
            </CardHeader>
            <CardContent>
              <div className="h-20 bg-muted rounded" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (sykmeldinger.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
          <h3 className="text-lg font-semibold">Ingen aktive sykmeldinger</h3>
          <p className="text-muted-foreground mt-1">
            Det er ingen aktive sykmeldinger å følge opp for øyeblikket.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      {sortedSykmeldinger.map((sykmelding) => {
        const trafficLight = getTrafficLight(sykmelding);
        const uker = differenceInWeeks(new Date(), new Date(sykmelding.startdato));
        const ansatt = sykmelding.users;

        return (
          <Card 
            key={sykmelding.id} 
            className={`transition-all hover:shadow-md ${
              trafficLight.color === 'red' ? 'border-destructive/50 bg-destructive/5' :
              trafficLight.color === 'yellow' ? 'border-yellow-500/50 bg-yellow-50/50' :
              ''
            }`}
          >
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <Avatar className="h-10 w-10">
                    <AvatarImage src={ansatt?.avatar_url} />
                    <AvatarFallback>
                      <User className="h-5 w-5" />
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <CardTitle className="text-base">
                      {ansatt?.name || 'Ukjent ansatt'}
                    </CardTitle>
                    <CardDescription>
                      {sykmelding.grad}% sykmeldt · Uke {uker}
                    </CardDescription>
                  </div>
                </div>
                {getTrafficLightIcon(trafficLight.color)}
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-sm">
                <span className="text-muted-foreground">Fra: </span>
                {format(new Date(sykmelding.startdato), 'dd. MMM yyyy', { locale: nb })}
              </div>

              <Badge variant={getTrafficLightBadge(trafficLight.color) as any}>
                {trafficLight.text}
              </Badge>

              <div className="flex flex-wrap gap-1.5">
                {sykmelding.oppfolgingslop_startet ? (
                  <Badge variant="outline" className="text-xs">Oppfølging startet</Badge>
                ) : (
                  <Badge variant="secondary" className="text-xs">Venter på oppfølging</Badge>
                )}
                
                {sykmelding.sykmelding_oppfolgingsplaner?.some((p: any) => p.laast) && (
                  <Badge variant="outline" className="text-xs">Plan godkjent</Badge>
                )}
              </div>

              <Link to={`/sykmelding/${sykmelding.id}`}>
                <Button variant="outline" className="w-full gap-2">
                  Se detaljer
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
