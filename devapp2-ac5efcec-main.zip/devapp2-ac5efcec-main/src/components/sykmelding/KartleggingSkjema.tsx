import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { useMutation } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { User, Briefcase, CheckCircle } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";
import { nb } from "date-fns/locale";

interface KartleggingSkjemaProps {
  sykmelding: any;
  isLeader: boolean;
  onRefresh: () => void;
}

export function KartleggingSkjema({ sykmelding, isLeader, onRefresh }: KartleggingSkjemaProps) {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState(isLeader ? "leder" : "ansatt");

  const oppfolgingsplan = sykmelding.sykmelding_oppfolgingsplaner?.[0];

  // Ansatt-skjema
  const ansattForm = useForm({
    defaultValues: {
      oppgaver_kan: oppfolgingsplan?.ansatt_oppgaver_kan || "",
      oppgaver_kan_ikke: oppfolgingsplan?.ansatt_oppgaver_kan_ikke || "",
      hindringer: oppfolgingsplan?.ansatt_hindringer || "",
      gradert_onske: oppfolgingsplan?.ansatt_gradert_onske || "",
      tilrettelegging_behov: oppfolgingsplan?.ansatt_tilrettelegging_behov || "",
    },
  });

  // Leder-skjema
  const lederForm = useForm({
    defaultValues: {
      vurdering: oppfolgingsplan?.leder_vurdering || "",
      fysiske_tiltak: oppfolgingsplan?.leder_fysiske_tiltak || "",
      organisatoriske_tiltak: oppfolgingsplan?.leder_organisatoriske_tiltak || "",
      sosiale_tiltak: oppfolgingsplan?.leder_sosiale_tiltak || "",
      alternative_oppgaver: oppfolgingsplan?.leder_alternative_oppgaver || "",
      returforventning: oppfolgingsplan?.leder_returforventning || "",
    },
  });

  const saveAnsattKartlegging = useMutation({
    mutationFn: async (data: any) => {
      if (!oppfolgingsplan) {
        throw new Error("Ingen oppfølgingsplan funnet");
      }

      const { error } = await supabase
        .from("sykmelding_oppfolgingsplaner")
        .update({
          ansatt_oppgaver_kan: data.oppgaver_kan,
          ansatt_oppgaver_kan_ikke: data.oppgaver_kan_ikke,
          ansatt_hindringer: data.hindringer,
          ansatt_gradert_onske: data.gradert_onske,
          ansatt_tilrettelegging_behov: data.tilrettelegging_behov,
          ansatt_kartlagt_dato: new Date().toISOString(),
        })
        .eq("id", oppfolgingsplan.id);

      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Kartlegging lagret");
      onRefresh();
    },
    onError: () => {
      toast.error("Kunne ikke lagre kartlegging");
    },
  });

  const saveLederKartlegging = useMutation({
    mutationFn: async (data: any) => {
      if (!oppfolgingsplan) {
        throw new Error("Ingen oppfølgingsplan funnet");
      }

      const { error } = await supabase
        .from("sykmelding_oppfolgingsplaner")
        .update({
          leder_vurdering: data.vurdering,
          leder_fysiske_tiltak: data.fysiske_tiltak,
          leder_organisatoriske_tiltak: data.organisatoriske_tiltak,
          leder_sosiale_tiltak: data.sosiale_tiltak,
          leder_alternative_oppgaver: data.alternative_oppgaver,
          leder_returforventning: data.returforventning,
          leder_kartlagt_dato: new Date().toISOString(),
          leder_kartlagt_av: user?.id,
        })
        .eq("id", oppfolgingsplan.id);

      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Leder-kartlegging lagret");
      onRefresh();
    },
    onError: () => {
      toast.error("Kunne ikke lagre kartlegging");
    },
  });

  if (!oppfolgingsplan) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <p className="text-muted-foreground">
            Oppfølgingsløpet må startes før kartlegging kan gjennomføres.
          </p>
        </CardContent>
      </Card>
    );
  }

  const ansattKartlagt = !!oppfolgingsplan.ansatt_kartlagt_dato;
  const lederKartlagt = !!oppfolgingsplan.leder_kartlagt_dato;

  return (
    <div className="space-y-6">
      {/* Status-oversikt */}
      <div className="flex gap-4">
        <Badge variant={ansattKartlagt ? "default" : "secondary"} className="gap-1">
          <User className="h-3 w-3" />
          Ansatt: {ansattKartlagt ? 'Kartlagt' : 'Ikke kartlagt'}
        </Badge>
        <Badge variant={lederKartlagt ? "default" : "secondary"} className="gap-1">
          <Briefcase className="h-3 w-3" />
          Leder: {lederKartlagt ? 'Kartlagt' : 'Ikke kartlagt'}
        </Badge>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="ansatt" className="gap-2">
            <User className="h-4 w-4" />
            Ansattkartlegging
          </TabsTrigger>
          <TabsTrigger value="leder" className="gap-2" disabled={!isLeader}>
            <Briefcase className="h-4 w-4" />
            Lederkartlegging
          </TabsTrigger>
        </TabsList>

        <TabsContent value="ansatt" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Ansattens kartlegging</CardTitle>
              <CardDescription>
                Beskriv din arbeidssituasjon og behov for tilrettelegging
              </CardDescription>
              {ansattKartlagt && (
                <Badge variant="outline" className="w-fit gap-1">
                  <CheckCircle className="h-3 w-3" />
                  Kartlagt {format(new Date(oppfolgingsplan.ansatt_kartlagt_dato), 'dd. MMM yyyy', { locale: nb })}
                </Badge>
              )}
            </CardHeader>
            <CardContent>
              <form 
                onSubmit={ansattForm.handleSubmit((data) => saveAnsattKartlegging.mutate(data))}
                className="space-y-6"
              >
                <div className="space-y-2">
                  <Label>Arbeidsoppgaver jeg KAN gjøre</Label>
                  <Textarea
                    {...ansattForm.register("oppgaver_kan")}
                    placeholder="Beskriv hvilke oppgaver du kan utføre helt eller delvis..."
                    rows={3}
                    disabled={isLeader}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Arbeidsoppgaver jeg IKKE kan gjøre</Label>
                  <Textarea
                    {...ansattForm.register("oppgaver_kan_ikke")}
                    placeholder="Beskriv hvilke oppgaver du ikke kan utføre nå..."
                    rows={3}
                    disabled={isLeader}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Hva hindrer retur til arbeid?</Label>
                  <Textarea
                    {...ansattForm.register("hindringer")}
                    placeholder="Beskriv hva som gjør at du ikke kan jobbe som normalt..."
                    rows={3}
                    disabled={isLeader}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Ønsker om gradert arbeid</Label>
                  <Textarea
                    {...ansattForm.register("gradert_onske")}
                    placeholder="Beskriv eventuelle ønsker om gradert arbeid eller arbeidstid..."
                    rows={3}
                    disabled={isLeader}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Behov for tilrettelegging</Label>
                  <Textarea
                    {...ansattForm.register("tilrettelegging_behov")}
                    placeholder="Beskriv eventuelle behov for tilrettelegging på arbeidsplassen..."
                    rows={3}
                    disabled={isLeader}
                  />
                </div>

                {!isLeader && (
                  <Button type="submit" disabled={saveAnsattKartlegging.isPending}>
                    {saveAnsattKartlegging.isPending ? "Lagrer..." : "Lagre kartlegging"}
                  </Button>
                )}
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="leder" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Leders kartlegging</CardTitle>
              <CardDescription>
                Vurder tilretteleggingsmuligheter og alternative oppgaver
              </CardDescription>
              {lederKartlagt && (
                <Badge variant="outline" className="w-fit gap-1">
                  <CheckCircle className="h-3 w-3" />
                  Kartlagt {format(new Date(oppfolgingsplan.leder_kartlagt_dato), 'dd. MMM yyyy', { locale: nb })}
                </Badge>
              )}
            </CardHeader>
            <CardContent>
              <form 
                onSubmit={lederForm.handleSubmit((data) => saveLederKartlegging.mutate(data))}
                className="space-y-6"
              >
                <div className="space-y-2">
                  <Label>Arbeidsgivers vurdering</Label>
                  <Textarea
                    {...lederForm.register("vurdering")}
                    placeholder="Vurder den ansattes arbeidsevne og situasjon..."
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Fysiske tilretteleggingstiltak</Label>
                  <Textarea
                    {...lederForm.register("fysiske_tiltak")}
                    placeholder="F.eks. ergonomiske hjelpemidler, justering av arbeidsplass..."
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Organisatoriske tilretteleggingstiltak</Label>
                  <Textarea
                    {...lederForm.register("organisatoriske_tiltak")}
                    placeholder="F.eks. endret arbeidstid, fleksibel arbeidstid, reduserte oppgaver..."
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Sosiale tilretteleggingstiltak</Label>
                  <Textarea
                    {...lederForm.register("sosiale_tiltak")}
                    placeholder="F.eks. støtte fra kollegaer, mentor, jevnlige samtaler..."
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Alternative arbeidsoppgaver tilgjengelige</Label>
                  <Textarea
                    {...lederForm.register("alternative_oppgaver")}
                    placeholder="Beskriv eventuelle alternative oppgaver som kan tilbys..."
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <Label>Forventning om retur</Label>
                  <Textarea
                    {...lederForm.register("returforventning")}
                    placeholder="Vurdering av når og hvordan den ansatte kan returnere..."
                    rows={3}
                  />
                </div>

                <Button type="submit" disabled={saveLederKartlegging.isPending}>
                  {saveLederKartlegging.isPending ? "Lagrer..." : "Lagre kartlegging"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
