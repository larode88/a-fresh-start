import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  Play, 
  FileText, 
  Users,
  Calendar,
  Target,
  TrendingUp
} from "lucide-react";
import { differenceInWeeks, format } from "date-fns";
import { nb } from "date-fns/locale";
import { toast } from "sonner";
import { AvsluttSykmeldingDialog } from "./AvsluttSykmeldingDialog";

interface SykmeldingSummaryProps {
  sykmelding: any;
  isLeader: boolean;
  onRefresh: () => void;
}

export function SykmeldingSummary({ sykmelding, isLeader, onRefresh }: SykmeldingSummaryProps) {
  const { user } = useAuth();
  const [showAvsluttDialog, setShowAvsluttDialog] = useState(false);

  const uker = differenceInWeeks(new Date(), new Date(sykmelding.startdato));
  const progress = Math.min((uker / 52) * 100, 100);

  const harPlan = sykmelding.sykmelding_oppfolgingsplaner?.some((p: any) => p.laast);
  const harDialogmote1 = sykmelding.sykmelding_dialogmoter?.some(
    (m: any) => m.motetype === 'dialogmote_1' && m.status === 'gjennomfort'
  );
  const harDialogmote2 = sykmelding.sykmelding_dialogmoter?.some(
    (m: any) => m.motetype === 'dialogmote_2' && m.status === 'gjennomfort'
  );
  const harAktivitetskrav = sykmelding.sykmelding_aktivitetskrav?.length > 0;

  const startOppfolging = useMutation({
    mutationFn: async () => {
      const { error } = await supabase
        .from("sykemeldinger")
        .update({
          oppfolgingslop_startet: true,
          oppfolgingslop_startet_dato: new Date().toISOString(),
          oppfolgingslop_startet_av: user?.id,
        })
        .eq("id", sykmelding.id);

      if (error) throw error;

      // Opprett første oppfølgingsplan-versjon
      const { error: planError } = await supabase
        .from("sykmelding_oppfolgingsplaner")
        .insert({
          sykmelding_id: sykmelding.id,
          versjon: 1,
        });

      if (planError) throw planError;
    },
    onSuccess: () => {
      toast.success("Oppfølgingsløp startet");
      onRefresh();
    },
    onError: () => {
      toast.error("Kunne ikke starte oppfølging");
    },
  });

  const getNesteHandling = () => {
    if (!sykmelding.oppfolgingslop_startet) {
      return { tekst: "Start oppfølgingsløp", type: "start" };
    }
    if (uker >= 3 && !harPlan) {
      return { tekst: "Lag oppfølgingsplan", type: "plan" };
    }
    if (uker >= 6 && !harDialogmote1) {
      return { tekst: "Planlegg Dialogmøte 1", type: "dialogmote" };
    }
    if (uker >= 7 && !harAktivitetskrav) {
      return { tekst: "Vurder aktivitetskrav", type: "aktivitet" };
    }
    if (uker >= 24 && !harDialogmote2) {
      return { tekst: "Planlegg Dialogmøte 2", type: "dialogmote" };
    }
    return { tekst: "Følg opp tiltak", type: "tiltak" };
  };

  const nesteHandling = getNesteHandling();

  return (
    <div className="space-y-6">
      {/* Status-kort */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Sykmeldingsgrad
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{sykmelding.grad}%</div>
            <p className="text-sm text-muted-foreground mt-1">
              {sykmelding.grad === 100 ? 'Helt sykmeldt' : `Jobber ${100 - sykmelding.grad}%`}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Varighet
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">Uke {uker}</div>
            <p className="text-sm text-muted-foreground mt-1">
              av maks 52 uker
            </p>
            <Progress value={progress} className="mt-2 h-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              Neste handling
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <Target className="h-5 w-5 text-primary" />
              <span className="font-medium">{nesteHandling.tekst}</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Start oppfølging knapp for ledere */}
      {isLeader && !sykmelding.oppfolgingslop_startet && (
        <Card className="border-primary/50 bg-primary/5">
          <CardContent className="py-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                  <Play className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold">Start oppfølgingsløpet</h3>
                  <p className="text-sm text-muted-foreground">
                    Begynn NAV-kompatibel oppfølging av denne sykmeldingen
                  </p>
                </div>
              </div>
              <Button 
                onClick={() => startOppfolging.mutate()}
                disabled={startOppfolging.isPending}
              >
                {startOppfolging.isPending ? "Starter..." : "Start oppfølging"}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Sjekkliste over milepæler */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Fremdrift
          </CardTitle>
          <CardDescription>
            Oversikt over gjennomførte milepæler
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Uke 0: Start */}
            <div className="flex items-center gap-3">
              <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center">
                <CheckCircle className="h-4 w-4 text-green-600" />
              </div>
              <div className="flex-1">
                <p className="font-medium">Sykmelding registrert</p>
                <p className="text-sm text-muted-foreground">
                  {format(new Date(sykmelding.startdato), 'dd. MMMM yyyy', { locale: nb })}
                </p>
              </div>
            </div>

            {/* Uke 4: Oppfølgingsplan */}
            <div className="flex items-center gap-3">
              <div className={`h-8 w-8 rounded-full flex items-center justify-center ${
                harPlan ? 'bg-green-100' : uker >= 4 ? 'bg-red-100' : 'bg-muted'
              }`}>
                {harPlan ? (
                  <CheckCircle className="h-4 w-4 text-green-600" />
                ) : uker >= 4 ? (
                  <AlertTriangle className="h-4 w-4 text-red-600" />
                ) : (
                  <Clock className="h-4 w-4 text-muted-foreground" />
                )}
              </div>
              <div className="flex-1">
                <p className="font-medium">Oppfølgingsplan (uke 4)</p>
                <p className="text-sm text-muted-foreground">
                  {harPlan ? 'Godkjent' : uker >= 4 ? 'Forfalt' : 'Kommende'}
                </p>
              </div>
            </div>

            {/* Uke 7: Dialogmøte 1 */}
            <div className="flex items-center gap-3">
              <div className={`h-8 w-8 rounded-full flex items-center justify-center ${
                harDialogmote1 ? 'bg-green-100' : uker >= 7 ? 'bg-red-100' : 'bg-muted'
              }`}>
                {harDialogmote1 ? (
                  <CheckCircle className="h-4 w-4 text-green-600" />
                ) : uker >= 7 ? (
                  <AlertTriangle className="h-4 w-4 text-red-600" />
                ) : (
                  <Clock className="h-4 w-4 text-muted-foreground" />
                )}
              </div>
              <div className="flex-1">
                <p className="font-medium">Dialogmøte 1 (uke 7)</p>
                <p className="text-sm text-muted-foreground">
                  {harDialogmote1 ? 'Gjennomført' : uker >= 7 ? 'Forfalt' : 'Kommende'}
                </p>
              </div>
            </div>

            {/* Uke 8: Aktivitetskrav */}
            <div className="flex items-center gap-3">
              <div className={`h-8 w-8 rounded-full flex items-center justify-center ${
                harAktivitetskrav ? 'bg-green-100' : uker >= 8 ? 'bg-yellow-100' : 'bg-muted'
              }`}>
                {harAktivitetskrav ? (
                  <CheckCircle className="h-4 w-4 text-green-600" />
                ) : uker >= 8 ? (
                  <Clock className="h-4 w-4 text-yellow-600" />
                ) : (
                  <Clock className="h-4 w-4 text-muted-foreground" />
                )}
              </div>
              <div className="flex-1">
                <p className="font-medium">Aktivitetskrav (uke 8)</p>
                <p className="text-sm text-muted-foreground">
                  {harAktivitetskrav ? 'Vurdert' : uker >= 8 ? 'Venter' : 'Kommende'}
                </p>
              </div>
            </div>

            {/* Uke 26: Dialogmøte 2 */}
            <div className="flex items-center gap-3">
              <div className={`h-8 w-8 rounded-full flex items-center justify-center ${
                harDialogmote2 ? 'bg-green-100' : uker >= 26 ? 'bg-yellow-100' : 'bg-muted'
              }`}>
                {harDialogmote2 ? (
                  <CheckCircle className="h-4 w-4 text-green-600" />
                ) : uker >= 26 ? (
                  <Clock className="h-4 w-4 text-yellow-600" />
                ) : (
                  <Clock className="h-4 w-4 text-muted-foreground" />
                )}
              </div>
              <div className="flex-1">
                <p className="font-medium">Dialogmøte 2 (uke 26)</p>
                <p className="text-sm text-muted-foreground">
                  {harDialogmote2 ? 'Gjennomført' : uker >= 26 ? 'Venter' : 'Kommende'}
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Avslutt sykmelding */}
      {isLeader && sykmelding.status === 'aktiv' && (
        <Card>
          <CardContent className="py-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium">Avslutt sykmelding</h3>
                <p className="text-sm text-muted-foreground">
                  Når den ansatte er friskmeldt eller sykmeldingen avsluttes
                </p>
              </div>
              <Button variant="outline" onClick={() => setShowAvsluttDialog(true)}>
                Avslutt
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <AvsluttSykmeldingDialog
        open={showAvsluttDialog}
        onOpenChange={setShowAvsluttDialog}
        sykmelding={sykmelding}
        onSuccess={onRefresh}
      />
    </div>
  );
}
