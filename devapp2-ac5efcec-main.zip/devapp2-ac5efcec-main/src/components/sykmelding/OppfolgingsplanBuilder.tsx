import { useState } from "react";
import { useForm } from "react-hook-form";
import { useMutation } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Lock, Unlock, FileText, CheckCircle, Plus } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";
import { nb } from "date-fns/locale";

interface OppfolgingsplanBuilderProps {
  sykmelding: any;
  isLeader: boolean;
  onRefresh: () => void;
}

export function OppfolgingsplanBuilder({ sykmelding, isLeader, onRefresh }: OppfolgingsplanBuilderProps) {
  const { user } = useAuth();
  const oppfolgingsplan = sykmelding.sykmelding_oppfolgingsplaner?.[0];

  const form = useForm({
    defaultValues: {
      maal_kort_sikt: oppfolgingsplan?.maal_kort_sikt || "",
      maal_lang_sikt: oppfolgingsplan?.maal_lang_sikt || "",
      arbeid_kan_utfores: oppfolgingsplan?.arbeid_kan_utfores || "",
      arbeid_kan_ikke_utfores: oppfolgingsplan?.arbeid_kan_ikke_utfores || "",
      gradert_arbeid_plan: oppfolgingsplan?.gradert_arbeid_plan || "",
    },
  });

  const savePlan = useMutation({
    mutationFn: async (data: any) => {
      if (!oppfolgingsplan) {
        throw new Error("Ingen oppfølgingsplan funnet");
      }

      const { error } = await supabase
        .from("sykmelding_oppfolgingsplaner")
        .update({
          maal_kort_sikt: data.maal_kort_sikt,
          maal_lang_sikt: data.maal_lang_sikt,
          arbeid_kan_utfores: data.arbeid_kan_utfores,
          arbeid_kan_ikke_utfores: data.arbeid_kan_ikke_utfores,
          gradert_arbeid_plan: data.gradert_arbeid_plan,
        })
        .eq("id", oppfolgingsplan.id);

      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Oppfølgingsplan lagret");
      onRefresh();
    },
    onError: () => {
      toast.error("Kunne ikke lagre planen");
    },
  });

  const lockPlan = useMutation({
    mutationFn: async () => {
      if (!oppfolgingsplan) {
        throw new Error("Ingen oppfølgingsplan funnet");
      }

      const { error } = await supabase
        .from("sykmelding_oppfolgingsplaner")
        .update({
          laast: true,
          laast_dato: new Date().toISOString(),
          laast_av: user?.id,
        })
        .eq("id", oppfolgingsplan.id);

      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Oppfølgingsplan godkjent og låst");
      onRefresh();
    },
    onError: () => {
      toast.error("Kunne ikke låse planen");
    },
  });

  const confirmAsEmployee = useMutation({
    mutationFn: async () => {
      if (!oppfolgingsplan) {
        throw new Error("Ingen oppfølgingsplan funnet");
      }

      const { error } = await supabase
        .from("sykmelding_oppfolgingsplaner")
        .update({
          bekreftet_av_ansatt: true,
          bekreftet_av_ansatt_dato: new Date().toISOString(),
        })
        .eq("id", oppfolgingsplan.id);

      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Oppfølgingsplan bekreftet");
      onRefresh();
    },
    onError: () => {
      toast.error("Kunne ikke bekrefte planen");
    },
  });

  if (!oppfolgingsplan) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <FileText className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
          <p className="text-muted-foreground">
            Oppfølgingsløpet må startes før oppfølgingsplan kan opprettes.
          </p>
        </CardContent>
      </Card>
    );
  }

  const erLaast = oppfolgingsplan.laast;
  const erBekreftet = oppfolgingsplan.bekreftet_av_ansatt;

  return (
    <div className="space-y-6">
      {/* Status */}
      <div className="flex flex-wrap gap-2">
        <Badge variant="outline">
          Versjon {oppfolgingsplan.versjon}
        </Badge>
        {erLaast ? (
          <Badge variant="default" className="gap-1">
            <Lock className="h-3 w-3" />
            Godkjent {format(new Date(oppfolgingsplan.laast_dato), 'dd. MMM', { locale: nb })}
          </Badge>
        ) : (
          <Badge variant="secondary" className="gap-1">
            <Unlock className="h-3 w-3" />
            Under arbeid
          </Badge>
        )}
        {erBekreftet && (
          <Badge variant="default" className="gap-1">
            <CheckCircle className="h-3 w-3" />
            Bekreftet av ansatt
          </Badge>
        )}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Oppfølgingsplan
          </CardTitle>
          <CardDescription>
            NAV-kompatibel oppfølgingsplan med mål og tiltak
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form 
            onSubmit={form.handleSubmit((data) => savePlan.mutate(data))}
            className="space-y-6"
          >
            <div className="grid gap-6 md:grid-cols-2">
              <div className="space-y-2">
                <Label>Mål for perioden (kort sikt: 1-4 uker)</Label>
                <Textarea
                  {...form.register("maal_kort_sikt")}
                  placeholder="Hva skal oppnås de neste 1-4 ukene..."
                  rows={4}
                  disabled={erLaast && !isLeader}
                />
              </div>

              <div className="space-y-2">
                <Label>Mål for perioden (lang sikt: 1-6 måneder)</Label>
                <Textarea
                  {...form.register("maal_lang_sikt")}
                  placeholder="Hva skal oppnås de neste 1-6 månedene..."
                  rows={4}
                  disabled={erLaast && !isLeader}
                />
              </div>
            </div>

            <Separator />

            <div className="space-y-2">
              <Label>Arbeid som KAN utføres</Label>
              <Textarea
                {...form.register("arbeid_kan_utfores")}
                placeholder="Beskriv arbeidsoppgaver som kan utføres helt eller delvis..."
                rows={3}
                disabled={erLaast && !isLeader}
              />
            </div>

            <div className="space-y-2">
              <Label>Arbeid som IKKE kan utføres</Label>
              <Textarea
                {...form.register("arbeid_kan_ikke_utfores")}
                placeholder="Beskriv arbeidsoppgaver som ikke kan utføres..."
                rows={3}
                disabled={erLaast && !isLeader}
              />
            </div>

            <div className="space-y-2">
              <Label>Plan for gradert arbeid</Label>
              <Textarea
                {...form.register("gradert_arbeid_plan")}
                placeholder="Beskriv plan for eventuelt gradert arbeid..."
                rows={3}
                disabled={erLaast && !isLeader}
              />
            </div>

            <div className="flex flex-wrap gap-3">
              {(!erLaast || isLeader) && (
                <Button type="submit" disabled={savePlan.isPending}>
                  {savePlan.isPending ? "Lagrer..." : "Lagre plan"}
                </Button>
              )}

              {isLeader && !erLaast && (
                <Button 
                  type="button" 
                  variant="secondary"
                  onClick={() => lockPlan.mutate()}
                  disabled={lockPlan.isPending}
                  className="gap-2"
                >
                  <Lock className="h-4 w-4" />
                  Godkjenn og lås plan
                </Button>
              )}

              {!isLeader && erLaast && !erBekreftet && (
                <Button 
                  type="button" 
                  onClick={() => confirmAsEmployee.mutate()}
                  disabled={confirmAsEmployee.isPending}
                  className="gap-2"
                >
                  <CheckCircle className="h-4 w-4" />
                  Bekreft planen
                </Button>
              )}
            </div>
          </form>
        </CardContent>
      </Card>

      {/* Tiltak-seksjon */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Tiltak</CardTitle>
              <CardDescription>
                Konkrete tiltak for tilrettelegging
              </CardDescription>
            </div>
            {isLeader && (
              <Button variant="outline" size="sm" className="gap-2">
                <Plus className="h-4 w-4" />
                Legg til tiltak
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {sykmelding.sykmelding_tiltak?.length > 0 ? (
            <div className="space-y-3">
              {sykmelding.sykmelding_tiltak.map((tiltak: any) => (
                <div 
                  key={tiltak.id} 
                  className="flex items-center justify-between p-3 border rounded-lg"
                >
                  <div>
                    <p className="font-medium">{tiltak.tittel}</p>
                    <p className="text-sm text-muted-foreground">{tiltak.beskrivelse}</p>
                  </div>
                  <Badge variant="outline">{tiltak.status}</Badge>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground text-center py-4">
              Ingen tiltak registrert ennå. Bruk Tiltak-fanen for å legge til.
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
