import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Calendar, User, Loader2, MessageSquare, Star, Lock, Eye, EyeOff, FileCheck, Send, Bell } from "lucide-react";
import { format, parseISO, isBefore, addDays } from "date-fns";
import { nb } from "date-fns/locale";
import { CompetencyScoring } from "./CompetencyScoring";

interface PerformanceReviewsProps {
  salonId: string;
  userId?: string;
  canManage: boolean;
}

interface ReviewRecord {
  id: string;
  user_id: string;
  user_name: string;
  samtale_type: string;
  dato: string;
  utfort_av_name: string;
  notater: string | null;
  styrker: string | null;
  utviklingsomrader: string | null;
  mal_neste_periode: string | null;
  neste_samtale: string | null;
  status: string;
  sammendrag: string | null;
  sted: string | null;
  signert_av_ansatt: boolean;
  signert_dato: string | null;
  lønnsforslag_beløp: number | null;
  mal_id: string | null;
  scores: { kompetanse_id: string; score: number; kommentar: string }[];
}

interface Employee {
  id: string;
  name: string;
}

interface CompetencyDefinition {
  id: string;
  navn: string;
  beskrivelse: string | null;
  kategori: string;
  rubrikk: { nivaa: number; tittel: string; beskrivelse: string }[];
}

interface SamtaleMal {
  id: string;
  navn: string;
  type: string;
  beskrivelse: string | null;
}

const REVIEW_TYPES = [
  { value: "medarbeidersamtale", label: "Medarbeidersamtale" },
  { value: "oppfolging", label: "Oppfølgingssamtale" },
  { value: "utviklingssamtale", label: "Utviklingssamtale" },
  { value: "lonnssamtale", label: "Lønnssamtale" },
  { value: "annet", label: "Annet" }
];

const STATUS_OPTIONS = [
  { value: "planlagt", label: "Planlagt", color: "secondary" },
  { value: "gjennomfort", label: "Gjennomført", color: "default" },
  { value: "avlyst", label: "Avlyst", color: "destructive" }
];

const LOCATION_OPTIONS = [
  { value: "fysisk", label: "Fysisk møte" },
  { value: "teams", label: "Microsoft Teams" },
  { value: "zoom", label: "Zoom" },
  { value: "telefon", label: "Telefon" }
];

export function PerformanceReviews({ salonId, userId, canManage }: PerformanceReviewsProps) {
  const { user, profile } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [reviews, setReviews] = useState<ReviewRecord[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [competencies, setCompetencies] = useState<CompetencyDefinition[]>([]);
  const [templates, setTemplates] = useState<SamtaleMal[]>([]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [selectedReview, setSelectedReview] = useState<ReviewRecord | null>(null);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [showConfidential, setShowConfidential] = useState(false);

  // Form state
  const [formUserId, setFormUserId] = useState("");
  const [formType, setFormType] = useState("medarbeidersamtale");
  const [formDato, setFormDato] = useState(format(new Date(), "yyyy-MM-dd"));
  const [formStatus, setFormStatus] = useState("planlagt");
  const [formSted, setFormSted] = useState("fysisk");
  const [formMalId, setFormMalId] = useState("");
  const [formNotater, setFormNotater] = useState("");
  const [formKonfidensielleNotater, setFormKonfidensielleNotater] = useState("");
  const [formStyrker, setFormStyrker] = useState("");
  const [formUtviklingsomrader, setFormUtviklingsomrader] = useState("");
  const [formMal, setFormMal] = useState("");
  const [formNesteSamtale, setFormNesteSamtale] = useState("");
  const [formSammendrag, setFormSammendrag] = useState("");
  const [formLonnsforslag, setFormLonnsforslag] = useState("");
  const [formScores, setFormScores] = useState<{ kompetanse_id: string; score: number; kommentar: string }[]>([]);

  const isAdmin = profile?.role === "admin";
  const canSeeConfidential = isAdmin || canManage;

  const fetchData = async () => {
    setLoading(true);
    try {
      // Fetch employees
      const { data: empData } = await supabase
        .from("users")
        .select("id, name")
        .eq("salon_id", salonId)
        .eq("aktiv", true)
        .order("name");
      
      setEmployees(empData || []);

      // Fetch competencies
      const { data: compData } = await supabase
        .from("kompetanse_definisjoner")
        .select("*")
        .eq("aktiv", true)
        .order("rekkefølge");
      
      setCompetencies((compData || []).map(c => ({
        ...c,
        rubrikk: Array.isArray(c.rubrikk) ? c.rubrikk as any : []
      })));

      // Fetch templates
      const { data: templateData } = await supabase
        .from("samtale_maler")
        .select("id, navn, type, beskrivelse")
        .eq("aktiv", true);
      
      setTemplates(templateData || []);

      // Fetch reviews
      let query = supabase
        .from("ansatt_samtaler")
        .select("*")
        .eq("salon_id", salonId)
        .order("dato", { ascending: false });

      if (userId) {
        query = query.eq("user_id", userId);
      }

      const { data, error } = await query;
      if (error) throw error;

      // Fetch employee names
      const userIds = [...new Set((data || []).map(r => r.user_id).concat((data || []).map(r => r.utfort_av)))];
      const { data: usersData } = await supabase
        .from("users")
        .select("id, name")
        .in("id", userIds);
      
      const userMap: Record<string, string> = {};
      (usersData || []).forEach(u => { userMap[u.id] = u.name; });

      // Fetch competency scores for all reviews
      const reviewIds = (data || []).map(r => r.id);
      const scoresMap: Record<string, { kompetanse_id: string; score: number; kommentar: string }[]> = {};
      
      if (reviewIds.length > 0) {
        const { data: scoresData } = await supabase
          .from("ansatt_kompetanse_score")
          .select("samtale_id, kompetanse_id, score, kommentar")
          .in("samtale_id", reviewIds);
        
        (scoresData || []).forEach(s => {
          if (!scoresMap[s.samtale_id]) scoresMap[s.samtale_id] = [];
          scoresMap[s.samtale_id].push({
            kompetanse_id: s.kompetanse_id,
            score: s.score,
            kommentar: s.kommentar || ""
          });
        });
      }

      const formatted: ReviewRecord[] = (data || []).map(r => ({
        id: r.id,
        user_id: r.user_id,
        user_name: userMap[r.user_id] || "Ukjent",
        samtale_type: r.samtale_type,
        dato: r.dato,
        utfort_av_name: userMap[r.utfort_av] || "Ukjent",
        notater: r.notater,
        styrker: r.styrker,
        utviklingsomrader: r.utviklingsomrader,
        mal_neste_periode: r.mal_neste_periode,
        neste_samtale: r.neste_samtale,
        status: r.status || "planlagt",
        sammendrag: r.sammendrag,
        sted: r.sted,
        signert_av_ansatt: r.signert_av_ansatt || false,
        signert_dato: r.signert_dato,
        lønnsforslag_beløp: r.lønnsforslag_beløp,
        mal_id: r.mal_id,
        scores: scoresMap[r.id] || []
      }));

      setReviews(formatted);
    } catch (error) {
      console.error("Error fetching reviews:", error);
      toast({ title: "Feil", description: "Kunne ikke hente samtaler", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [salonId, userId]);

  const handleSave = async () => {
    if (!user || !formUserId) return;

    setSaving(true);
    try {
      // Create review
      const { data: reviewData, error: reviewError } = await supabase
        .from("ansatt_samtaler")
        .insert({
          user_id: formUserId,
          salon_id: salonId,
          samtale_type: formType,
          dato: formDato,
          status: formStatus,
          sted: formSted,
          mal_id: formMalId || null,
          utfort_av: user.id,
          notater: formNotater || null,
          konfidensielle_notater: formKonfidensielleNotater || null,
          styrker: formStyrker || null,
          utviklingsomrader: formUtviklingsomrader || null,
          mal_neste_periode: formMal || null,
          neste_samtale: formNesteSamtale || null,
          sammendrag: formSammendrag || null,
          lønnsforslag_beløp: formLonnsforslag ? parseFloat(formLonnsforslag) : null
        })
        .select()
        .single();

      if (reviewError) throw reviewError;

      // Save competency scores
      if (formScores.length > 0 && reviewData) {
        const scoresToInsert = formScores
          .filter(s => s.score > 0)
          .map(s => ({
            samtale_id: reviewData.id,
            kompetanse_id: s.kompetanse_id,
            score: s.score,
            kommentar: s.kommentar || null
          }));

        if (scoresToInsert.length > 0) {
          const { error: scoresError } = await supabase
            .from("ansatt_kompetanse_score")
            .insert(scoresToInsert);

          if (scoresError) console.error("Error saving scores:", scoresError);
        }
      }

      // Send invitation email if status is planlagt
      if (formStatus === "planlagt" && reviewData) {
        try {
          await supabase.functions.invoke("send-review-notification", {
            body: { action: "invitation", review_id: reviewData.id }
          });
          console.log("Invitation email sent");
        } catch (emailError) {
          console.error("Failed to send invitation email:", emailError);
        }
      }

      // Send summary email if status is gjennomfort
      if (formStatus === "gjennomfort" && reviewData) {
        try {
          await supabase.functions.invoke("send-review-notification", {
            body: { action: "summary", review_id: reviewData.id }
          });
          console.log("Summary email sent");
        } catch (emailError) {
          console.error("Failed to send summary email:", emailError);
        }
      }

      toast({ title: "Lagret", description: "Samtalen er registrert" });
      setDialogOpen(false);
      resetForm();
      fetchData();
    } catch (error) {
      console.error("Error saving review:", error);
      toast({ title: "Feil", description: "Kunne ikke lagre samtale", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const resetForm = () => {
    setFormUserId("");
    setFormType("medarbeidersamtale");
    setFormDato(format(new Date(), "yyyy-MM-dd"));
    setFormStatus("planlagt");
    setFormSted("fysisk");
    setFormMalId("");
    setFormNotater("");
    setFormKonfidensielleNotater("");
    setFormStyrker("");
    setFormUtviklingsomrader("");
    setFormMal("");
    setFormNesteSamtale("");
    setFormSammendrag("");
    setFormLonnsforslag("");
    setFormScores([]);
  };

  const sendNotification = async (reviewId: string, action: "invitation" | "reminder" | "summary") => {
    try {
      const { error } = await supabase.functions.invoke("send-review-notification", {
        body: { action, review_id: reviewId }
      });
      
      if (error) throw error;
      
      const actionLabels = { invitation: "Invitasjon", reminder: "Påminnelse", summary: "Sammendrag" };
      toast({ title: "Sendt", description: `${actionLabels[action]} sendt til ansatt` });
    } catch (error) {
      console.error("Error sending notification:", error);
      toast({ title: "Feil", description: "Kunne ikke sende e-post", variant: "destructive" });
    }
  };

  const getUpcomingReviews = () => {
    return reviews.filter(r => 
      r.status === "planlagt" && 
      isBefore(new Date(), addDays(parseISO(r.dato), 1))
    );
  };

  const getAverageScore = (scores: { score: number }[]) => {
    if (scores.length === 0) return null;
    return (scores.reduce((sum, s) => sum + s.score, 0) / scores.length).toFixed(1);
  };

  if (loading) {
    return <Skeleton className="h-64" />;
  }

  const upcomingReviews = getUpcomingReviews();

  return (
    <div className="space-y-6">
      {upcomingReviews.length > 0 && (
        <Card className="border-primary/30 bg-primary/5">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-primary">
              <Calendar className="h-5 w-5" />
              Kommende samtaler ({upcomingReviews.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {upcomingReviews.map(review => (
                <div key={review.id} className="flex items-center justify-between p-3 rounded-lg bg-background border">
                  <div className="flex items-center gap-3">
                    <User className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">{review.user_name}</span>
                    <Badge variant="outline">
                      {REVIEW_TYPES.find(t => t.value === review.samtale_type)?.label}
                    </Badge>
                    {review.sted && (
                      <Badge variant="secondary" className="text-xs">
                        {LOCATION_OPTIONS.find(l => l.value === review.sted)?.label}
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    {canManage && (
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => sendNotification(review.id, "reminder")}
                        title="Send påminnelse"
                      >
                        <Bell className="h-4 w-4" />
                      </Button>
                    )}
                    <span className="text-sm text-muted-foreground">
                      {format(parseISO(review.dato), "d. MMM yyyy", { locale: nb })}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="h-5 w-5" />
                Medarbeidersamtaler
              </CardTitle>
              <CardDescription>Samtalehistorikk og planlagte samtaler</CardDescription>
            </div>
            {canManage && (
              <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                <DialogTrigger asChild>
                  <Button><Plus className="h-4 w-4 mr-2" />Ny samtale</Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Registrer samtale</DialogTitle>
                    <DialogDescription>Planlegg eller registrer en medarbeidersamtale</DialogDescription>
                  </DialogHeader>
                  
                  <Tabs defaultValue="info" className="w-full">
                    <TabsList className="grid w-full grid-cols-3">
                      <TabsTrigger value="info">Grunninfo</TabsTrigger>
                      <TabsTrigger value="scores">Kompetanser</TabsTrigger>
                      <TabsTrigger value="notes">Notater & Mål</TabsTrigger>
                    </TabsList>

                    <TabsContent value="info" className="space-y-4 mt-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>Ansatt *</Label>
                          <Select value={formUserId} onValueChange={setFormUserId}>
                            <SelectTrigger><SelectValue placeholder="Velg ansatt" /></SelectTrigger>
                            <SelectContent>
                              {employees.map(emp => (
                                <SelectItem key={emp.id} value={emp.id}>{emp.name}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label>Type samtale</Label>
                          <Select value={formType} onValueChange={setFormType}>
                            <SelectTrigger><SelectValue /></SelectTrigger>
                            <SelectContent>
                              {REVIEW_TYPES.map(t => (
                                <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <Label>Dato</Label>
                          <Input type="date" value={formDato} onChange={e => setFormDato(e.target.value)} />
                        </div>
                        <div className="space-y-2">
                          <Label>Status</Label>
                          <Select value={formStatus} onValueChange={setFormStatus}>
                            <SelectTrigger><SelectValue /></SelectTrigger>
                            <SelectContent>
                              {STATUS_OPTIONS.map(s => (
                                <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label>Sted</Label>
                          <Select value={formSted} onValueChange={setFormSted}>
                            <SelectTrigger><SelectValue /></SelectTrigger>
                            <SelectContent>
                              {LOCATION_OPTIONS.map(l => (
                                <SelectItem key={l.value} value={l.value}>{l.label}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      {templates.length > 0 && (
                        <div className="space-y-2">
                          <Label>Samtalemal (valgfritt)</Label>
                          <Select value={formMalId} onValueChange={setFormMalId}>
                            <SelectTrigger><SelectValue placeholder="Velg mal" /></SelectTrigger>
                            <SelectContent>
                              {templates.map(t => (
                                <SelectItem key={t.id} value={t.id}>{t.navn}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      )}

                      <div className="space-y-2">
                        <Label>Sammendrag</Label>
                        <Textarea 
                          value={formSammendrag} 
                          onChange={e => setFormSammendrag(e.target.value)} 
                          placeholder="Kort oppsummering av samtalen" 
                          rows={3} 
                        />
                      </div>
                    </TabsContent>

                    <TabsContent value="scores" className="mt-4">
                      {competencies.length > 0 ? (
                        <CompetencyScoring
                          competencies={competencies}
                          scores={formScores}
                          onChange={setFormScores}
                        />
                      ) : (
                        <p className="text-center text-muted-foreground py-8">
                          Ingen kompetanser definert. Legg til kompetanser i admin-panelet.
                        </p>
                      )}
                    </TabsContent>

                    <TabsContent value="notes" className="space-y-4 mt-4">
                      <div className="space-y-2">
                        <Label>Styrker</Label>
                        <Textarea 
                          value={formStyrker} 
                          onChange={e => setFormStyrker(e.target.value)} 
                          placeholder="Hva gjør den ansatte bra?" 
                          rows={2} 
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Utviklingsområder</Label>
                        <Textarea 
                          value={formUtviklingsomrader} 
                          onChange={e => setFormUtviklingsomrader(e.target.value)} 
                          placeholder="Områder med forbedringspotensial" 
                          rows={2} 
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Mål for neste periode</Label>
                        <Textarea 
                          value={formMal} 
                          onChange={e => setFormMal(e.target.value)} 
                          placeholder="Konkrete mål å jobbe mot" 
                          rows={2} 
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>Generelle notater</Label>
                        <Textarea 
                          value={formNotater} 
                          onChange={e => setFormNotater(e.target.value)} 
                          placeholder="Andre notater fra samtalen" 
                          rows={2} 
                        />
                      </div>
                      
                      {canSeeConfidential && (
                        <div className="space-y-2 p-4 rounded-lg border border-dashed border-destructive/50 bg-destructive/5">
                          <Label className="flex items-center gap-2 text-destructive">
                            <Lock className="h-4 w-4" />
                            Konfidensielle notater (kun synlig for ledelse)
                          </Label>
                          <Textarea 
                            value={formKonfidensielleNotater} 
                            onChange={e => setFormKonfidensielleNotater(e.target.value)} 
                            placeholder="Sensitiv informasjon..." 
                            rows={2} 
                          />
                        </div>
                      )}

                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>Lønnsforslag (valgfritt)</Label>
                          <Input 
                            type="number" 
                            value={formLonnsforslag} 
                            onChange={e => setFormLonnsforslag(e.target.value)} 
                            placeholder="Foreslått timesats eller månedslønn" 
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Neste samtale (valgfritt)</Label>
                          <Input 
                            type="date" 
                            value={formNesteSamtale} 
                            onChange={e => setFormNesteSamtale(e.target.value)} 
                          />
                        </div>
                      </div>
                    </TabsContent>
                  </Tabs>

                  <DialogFooter className="mt-6">
                    <Button variant="outline" onClick={() => setDialogOpen(false)}>Avbryt</Button>
                    <Button onClick={handleSave} disabled={saving || !formUserId}>
                      {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                      Lagre samtale
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {reviews.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">Ingen samtaler registrert.</p>
          ) : (
            <div className="space-y-4">
              {reviews.map(review => {
                const statusInfo = STATUS_OPTIONS.find(s => s.value === review.status);
                const avgScore = getAverageScore(review.scores);
                
                return (
                  <div 
                    key={review.id} 
                    className="p-4 rounded-lg border bg-card hover:shadow-sm transition-shadow cursor-pointer"
                    onClick={() => {
                      setSelectedReview(review);
                      setViewDialogOpen(true);
                    }}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-medium">{review.user_name}</span>
                        <Badge variant="outline">
                          {REVIEW_TYPES.find(t => t.value === review.samtale_type)?.label}
                        </Badge>
                        <Badge variant={statusInfo?.color as any || "secondary"}>
                          {statusInfo?.label}
                        </Badge>
                        {avgScore && (
                          <Badge className="bg-primary/10 text-primary">
                            <Star className="h-3 w-3 mr-1 fill-current" />
                            {avgScore}
                          </Badge>
                        )}
                        {review.signert_av_ansatt && (
                          <Badge variant="outline" className="text-emerald-600">
                            <FileCheck className="h-3 w-3 mr-1" />
                            Signert
                          </Badge>
                        )}
                      </div>
                      <span className="text-sm text-muted-foreground">
                        {format(parseISO(review.dato), "d. MMM yyyy", { locale: nb })}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">Utført av {review.utfort_av_name}</p>
                    
                    {review.sammendrag && (
                      <p className="text-sm bg-muted/50 p-2 rounded">{review.sammendrag}</p>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      {/* View Dialog */}
      <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          {selectedReview && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  Samtale med {selectedReview.user_name}
                  <Badge variant="outline">
                    {REVIEW_TYPES.find(t => t.value === selectedReview.samtale_type)?.label}
                  </Badge>
                </DialogTitle>
                <DialogDescription>
                  {format(parseISO(selectedReview.dato), "d. MMMM yyyy", { locale: nb })} • Utført av {selectedReview.utfort_av_name}
                </DialogDescription>
              </DialogHeader>

              <div className="space-y-6">
                {selectedReview.sammendrag && (
                  <div>
                    <h4 className="font-medium mb-2">Sammendrag</h4>
                    <p className="text-sm bg-muted/50 p-3 rounded-lg">{selectedReview.sammendrag}</p>
                  </div>
                )}

                {selectedReview.scores.length > 0 && (
                  <div>
                    <h4 className="font-medium mb-2">Kompetansevurdering</h4>
                    <CompetencyScoring
                      competencies={competencies}
                      scores={selectedReview.scores}
                      onChange={() => {}}
                      readOnly
                    />
                  </div>
                )}

                {(selectedReview.styrker || selectedReview.utviklingsomrader || selectedReview.mal_neste_periode) && (
                  <div className="grid md:grid-cols-3 gap-4">
                    {selectedReview.styrker && (
                      <div className="p-3 rounded-lg bg-emerald-50 dark:bg-emerald-900/20">
                        <p className="text-xs font-medium text-emerald-700 dark:text-emerald-400 mb-1">Styrker</p>
                        <p className="text-sm">{selectedReview.styrker}</p>
                      </div>
                    )}
                    {selectedReview.utviklingsomrader && (
                      <div className="p-3 rounded-lg bg-amber-50 dark:bg-amber-900/20">
                        <p className="text-xs font-medium text-amber-700 dark:text-amber-400 mb-1">Utviklingsområder</p>
                        <p className="text-sm">{selectedReview.utviklingsomrader}</p>
                      </div>
                    )}
                    {selectedReview.mal_neste_periode && (
                      <div className="p-3 rounded-lg bg-blue-50 dark:bg-blue-900/20">
                        <p className="text-xs font-medium text-blue-700 dark:text-blue-400 mb-1">Mål neste periode</p>
                        <p className="text-sm">{selectedReview.mal_neste_periode}</p>
                      </div>
                    )}
                  </div>
                )}

                {selectedReview.notater && (
                  <div>
                    <h4 className="font-medium mb-2">Notater</h4>
                    <p className="text-sm text-muted-foreground">{selectedReview.notater}</p>
                  </div>
                )}

                {selectedReview.lønnsforslag_beløp && canSeeConfidential && (
                  <div className="p-3 rounded-lg border border-primary/30 bg-primary/5">
                    <p className="text-sm font-medium">Lønnsforslag: {selectedReview.lønnsforslag_beløp.toLocaleString("nb-NO")} kr</p>
                  </div>
                )}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
