import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Calendar, User, Coins, GripVertical } from "lucide-react";
import { format, parseISO, isBefore } from "date-fns";
import { nb } from "date-fns/locale";
import { cn } from "@/lib/utils";

interface PlanRecord {
  id: string;
  user_name: string;
  tittel: string;
  beskrivelse: string | null;
  kategori: string | null;
  type: string | null;
  frist: string | null;
  status: string;
  fremgang: number;
  estimert_kostnad: number | null;
}

interface DevelopmentKanbanProps {
  plans: PlanRecord[];
  onStatusChange: (planId: string, newStatus: string) => void;
  onPlanClick?: (plan: PlanRecord) => void;
  canManage?: boolean;
}

const COLUMNS = [
  { id: "ikke_startet", label: "Ikke startet", color: "bg-muted" },
  { id: "pagar", label: "Pågår", color: "bg-blue-100 dark:bg-blue-900/30" },
  { id: "fullfort", label: "Fullført", color: "bg-emerald-100 dark:bg-emerald-900/30" }
];

const TYPE_LABELS: Record<string, string> = {
  kurs: "Kurs",
  mentor: "Mentor",
  "on-the-job": "On-the-job",
  sertifisering: "Sertifisering",
  andre: "Annet"
};

const PRIORITY_COLORS: Record<number, string> = {
  1: "border-l-destructive",
  2: "border-l-yellow-500",
  3: "border-l-muted-foreground"
};

export function DevelopmentKanban({ plans, onStatusChange, onPlanClick, canManage }: DevelopmentKanbanProps) {
  const [draggedPlan, setDraggedPlan] = useState<string | null>(null);

  const getPlansByStatus = (status: string) => {
    return plans.filter(p => p.status === status);
  };

  const handleDragStart = (e: React.DragEvent, planId: string) => {
    if (!canManage) return;
    setDraggedPlan(planId);
    e.dataTransfer.effectAllowed = "move";
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
  };

  const handleDrop = (e: React.DragEvent, newStatus: string) => {
    e.preventDefault();
    if (draggedPlan) {
      onStatusChange(draggedPlan, newStatus);
      setDraggedPlan(null);
    }
  };

  const isOverdue = (frist: string | null) => {
    if (!frist) return false;
    return isBefore(parseISO(frist), new Date());
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      {COLUMNS.map(column => {
        const columnPlans = getPlansByStatus(column.id);
        
        return (
          <div
            key={column.id}
            className={cn("rounded-lg p-3 min-h-[400px]", column.color)}
            onDragOver={handleDragOver}
            onDrop={(e) => handleDrop(e, column.id)}
          >
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-sm">{column.label}</h3>
              <Badge variant="secondary" className="text-xs">
                {columnPlans.length}
              </Badge>
            </div>

            <div className="space-y-3">
              {columnPlans.map(plan => (
                <Card
                  key={plan.id}
                  draggable={canManage}
                  onDragStart={(e) => handleDragStart(e, plan.id)}
                  onClick={() => onPlanClick?.(plan)}
                  className={cn(
                    "border-l-4 hover:shadow-md transition-shadow",
                    canManage && "cursor-grab active:cursor-grabbing",
                    "border-l-primary/50",
                    draggedPlan === plan.id && "opacity-50"
                  )}
                >
                  <CardContent className="p-3 space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate">{plan.tittel}</p>
                        {plan.type && (
                          <Badge variant="outline" className="text-xs mt-1">
                            {TYPE_LABELS[plan.type] || plan.type}
                          </Badge>
                        )}
                      </div>
                      <GripVertical className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                    </div>

                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Avatar className="h-5 w-5">
                        <AvatarFallback className="text-[10px]">
                          {plan.user_name.split(" ").map(n => n[0]).join("").slice(0, 2)}
                        </AvatarFallback>
                      </Avatar>
                      <span className="truncate">{plan.user_name}</span>
                    </div>

                    {plan.frist && (
                      <div className={cn(
                        "flex items-center gap-1 text-xs",
                        isOverdue(plan.frist) ? "text-destructive font-medium" : "text-muted-foreground"
                      )}>
                        <Calendar className="h-3 w-3" />
                        {format(parseISO(plan.frist), "d. MMM", { locale: nb })}
                        {isOverdue(plan.frist) && " (forsinket)"}
                      </div>
                    )}

                    {plan.estimert_kostnad && plan.estimert_kostnad > 0 && (
                      <div className="flex items-center gap-1 text-xs text-muted-foreground">
                        <Coins className="h-3 w-3" />
                        {plan.estimert_kostnad.toLocaleString("nb-NO")} kr
                      </div>
                    )}

                    {column.id === "pagar" && (
                      <div className="pt-1">
                        <div className="flex items-center justify-between text-xs mb-1">
                          <span>Fremgang</span>
                          <span>{plan.fremgang}%</span>
                        </div>
                        <Progress value={plan.fremgang} className="h-1.5" />
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}

              {columnPlans.length === 0 && (
                <p className="text-center text-sm text-muted-foreground py-8">
                  Ingen tiltak
                </p>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
