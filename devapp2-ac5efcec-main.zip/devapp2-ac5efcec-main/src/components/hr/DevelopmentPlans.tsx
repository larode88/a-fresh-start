import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Target, Loader2, Calendar, TrendingUp, LayoutGrid, List, DollarSign } from "lucide-react";
import { format, parseISO, isBefore } from "date-fns";
import { nb } from "date-fns/locale";
import { DevelopmentKanban } from "./DevelopmentKanban";

interface DevelopmentPlansProps {
  salonId: string;
  userId?: string;
  canManage: boolean;
}

interface PlanRecord {
  id: string;
  user_id: string;
  user_name: string;
  tittel: string;
  beskrivelse: string | null;
  kategori: string | null;
  type: string | null;
  maal: string | null;
  tiltak: string | null;
  frist: string | null;
  status: string;
  fremgang: number;
  estimert_kostnad: number | null;
  godkjent_kostnad: boolean;
}

interface Employee {
  id: string;
  name: string;
}

const CATEGORIES = [
  { value: "faglig", label: "Faglig utvikling" },
  { value: "lederskap", label: "Lederskap" },
  { value: "salg", label: "Salg" },
  { value: "kundeservice", label: "Kundeservice" },
  { value: "personlig", label: "Personlig utvikling" },
  { value: "annet", label: "Annet" }
];

const PLAN_TYPES = [
  { value: "kurs", label: "Kurs" },
  { value: "sertifisering", label: "Sertifisering" },
  { value: "mentor", label: "Mentoring" },
  { value: "on_the_job", label: "On-the-job training" },
  { value: "annet", label: "Annet" }
];

const STATUS_OPTIONS = [
  { value: "ikke_startet", label: "Ikke startet", color: "secondary" },
  { value: "pagar", label: "Pågår", color: "default" },
  { value: "fullfort", label: "Fullført", color: "outline" },
  { value: "avbrutt", label: "Avbrutt", color: "destructive" }
];

export function DevelopmentPlans({ salonId, userId, canManage }: DevelopmentPlansProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [plans, setPlans] = useState<PlanRecord[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [saving, setSaving] = useState(false);

  // Form state
  const [formUserId, setFormUserId] = useState("");
  const [formTittel, setFormTittel] = useState("");
  const [formBeskrivelse, setFormBeskrivelse] = useState("");
  const [formKategori, setFormKategori] = useState("faglig");
  const [formType, setFormType] = useState("kurs");
  const [formMaal, setFormMaal] = useState("");
  const [formTiltak, setFormTiltak] = useState("");
  const [formFrist, setFormFrist] = useState("");
  const [formStatus, setFormStatus] = useState("ikke_startet");
  const [formKostnad, setFormKostnad] = useState("");
  const [viewMode, setViewMode] = useState<"list" | "kanban">("kanban");

  const fetchData = async () => {
    setLoading(true);
    try {
      const { data: empData } = await supabase
        .from("users")
        .select("id, name")
        .eq("salon_id", salonId)
        .eq("aktiv", true)
        .order("name");
      
      setEmployees(empData || []);

      let query = supabase
        .from("ansatt_utviklingsplan")
        .select(`
          id, user_id, tittel, beskrivelse, kategori, type, maal, tiltak, frist, status, fremgang, estimert_kostnad, godkjent_kostnad,
          users!ansatt_utviklingsplan_user_id_fkey(name)
        `)
        .eq("salon_id", salonId)
        .order("created_at", { ascending: false });

      if (userId) {
        query = query.eq("user_id", userId);
      }

      const { data, error } = await query;
      if (error) throw error;

      const formatted: PlanRecord[] = (data || []).map(p => ({
        id: p.id,
        user_id: p.user_id,
        user_name: (p.users as any)?.name || "Ukjent",
        tittel: p.tittel,
        beskrivelse: p.beskrivelse,
        kategori: p.kategori,
        type: p.type,
        maal: p.maal,
        tiltak: p.tiltak,
        frist: p.frist,
        status: p.status || "ikke_startet",
        fremgang: p.fremgang || 0,
        estimert_kostnad: p.estimert_kostnad,
        godkjent_kostnad: p.godkjent_kostnad || false
      }));

      setPlans(formatted);
    } catch (error) {
      console.error("Error fetching plans:", error);
      toast({ title: "Feil", description: "Kunne ikke hente utviklingsplaner", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [salonId, userId]);

  const handleSave = async () => {
    if (!user || !formUserId || !formTittel) return;

    setSaving(true);
    try {
      const { error } = await supabase.from("ansatt_utviklingsplan").insert({
        user_id: formUserId,
        salon_id: salonId,
        tittel: formTittel,
        beskrivelse: formBeskrivelse || null,
        kategori: formKategori,
        type: formType,
        maal: formMaal || null,
        tiltak: formTiltak || null,
        frist: formFrist || null,
        status: formStatus,
        fremgang: 0,
        estimert_kostnad: formKostnad ? parseFloat(formKostnad) : null
      });

      if (error) throw error;

      toast({ title: "Lagret", description: "Utviklingsplan opprettet" });
      setDialogOpen(false);
      resetForm();
      fetchData();
    } catch (error) {
      console.error("Error saving plan:", error);
      toast({ title: "Feil", description: "Kunne ikke lagre plan", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const updateProgress = async (planId: string, newProgress: number) => {
    try {
      const newStatus = newProgress === 100 ? "fullfort" : newProgress > 0 ? "pagar" : "ikke_startet";
      
      const { error } = await supabase
        .from("ansatt_utviklingsplan")
        .update({ fremgang: newProgress, status: newStatus })
        .eq("id", planId);

      if (error) throw error;
      
      setPlans(prev => prev.map(p => 
        p.id === planId ? { ...p, fremgang: newProgress, status: newStatus } : p
      ));
    } catch (error) {
      console.error("Error updating progress:", error);
      toast({ title: "Feil", description: "Kunne ikke oppdatere fremgang", variant: "destructive" });
    }
  };

  const resetForm = () => {
    setFormUserId("");
    setFormTittel("");
    setFormBeskrivelse("");
    setFormKategori("faglig");
    setFormType("kurs");
    setFormMaal("");
    setFormTiltak("");
    setFormFrist("");
    setFormStatus("ikke_startet");
    setFormKostnad("");
  };

  const handleStatusChange = async (planId: string, newStatus: string) => {
    try {
      const newProgress = newStatus === "fullfort" ? 100 : newStatus === "pagar" ? 50 : 0;
      const { error } = await supabase
        .from("ansatt_utviklingsplan")
        .update({ status: newStatus, fremgang: newProgress })
        .eq("id", planId);
      if (error) throw error;
      fetchData();
    } catch (error) {
      console.error("Error updating status:", error);
      toast({ title: "Feil", description: "Kunne ikke oppdatere status", variant: "destructive" });
    }
  };

  if (loading) {
    return <Skeleton className="h-64" />;
  }

  const activePlans = plans.filter(p => p.status !== "fullfort" && p.status !== "avbrutt");
  const overduePlans = activePlans.filter(p => p.frist && isBefore(parseISO(p.frist), new Date()));

  return (
    <div className="space-y-6">
      {overduePlans.length > 0 && (
        <Card className="border-destructive/30 bg-destructive/5">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-destructive">
              <Calendar className="h-5 w-5" />
              Forsinket ({overduePlans.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {overduePlans.map(plan => (
                <div key={plan.id} className="flex items-center justify-between p-3 rounded-lg bg-background border">
                  <div>
                    <span className="font-medium">{plan.user_name}</span>
                    <span className="text-muted-foreground ml-2">- {plan.tittel}</span>
                  </div>
                  <Badge variant="destructive">
                    Frist: {format(parseISO(plan.frist!), "d. MMM", { locale: nb })}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Utviklingsplaner
              </CardTitle>
              <CardDescription>Personlige utviklingsmål og handlingsplaner</CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex rounded-lg border overflow-hidden">
                <Button 
                  variant={viewMode === "kanban" ? "default" : "ghost"} 
                  size="sm" 
                  onClick={() => setViewMode("kanban")}
                  className="rounded-none"
                >
                  <LayoutGrid className="h-4 w-4" />
                </Button>
                <Button 
                  variant={viewMode === "list" ? "default" : "ghost"} 
                  size="sm" 
                  onClick={() => setViewMode("list")}
                  className="rounded-none"
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
              {canManage && (
                <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
                  <DialogTrigger asChild>
                    <Button><Plus className="h-4 w-4 mr-2" />Ny plan</Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Opprett utviklingsplan</DialogTitle>
                    <DialogDescription>Definer utviklingsmål og tiltak</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Ansatt</Label>
                        <Select value={formUserId} onValueChange={setFormUserId}>
                          <SelectTrigger><SelectValue placeholder="Velg ansatt" /></SelectTrigger>
                          <SelectContent>
                            {employees.map(emp => (
                              <SelectItem key={emp.id} value={emp.id}>{emp.name}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Type tiltak</Label>
                        <Select value={formType} onValueChange={setFormType}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {PLAN_TYPES.map(t => (
                              <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Kategori</Label>
                        <Select value={formKategori} onValueChange={setFormKategori}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {CATEGORIES.map(c => (
                              <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label>Tittel</Label>
                      <Input value={formTittel} onChange={e => setFormTittel(e.target.value)} placeholder="Kort beskrivende tittel" />
                    </div>
                    <div className="space-y-2">
                      <Label>Beskrivelse</Label>
                      <Textarea value={formBeskrivelse} onChange={e => setFormBeskrivelse(e.target.value)} placeholder="Utdypende beskrivelse av utviklingsområdet" rows={2} />
                    </div>
                    <div className="space-y-2">
                      <Label>Mål</Label>
                      <Textarea value={formMaal} onChange={e => setFormMaal(e.target.value)} placeholder="Hva skal oppnås?" rows={2} />
                    </div>
                    <div className="space-y-2">
                      <Label>Tiltak</Label>
                      <Textarea value={formTiltak} onChange={e => setFormTiltak(e.target.value)} placeholder="Konkrete handlinger for å nå målet" rows={2} />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label>Frist (valgfritt)</Label>
                        <Input type="date" value={formFrist} onChange={e => setFormFrist(e.target.value)} />
                      </div>
                      <div className="space-y-2">
                        <Label>Status</Label>
                        <Select value={formStatus} onValueChange={setFormStatus}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {STATUS_OPTIONS.map(s => (
                              <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <Button onClick={handleSave} className="w-full" disabled={saving || !formUserId || !formTittel}>
                      {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                      Opprett plan
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            )}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {plans.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">Ingen utviklingsplaner opprettet.</p>
          ) : viewMode === "kanban" ? (
            <DevelopmentKanban
              plans={plans.map(p => ({
                id: p.id,
                tittel: p.tittel,
                beskrivelse: p.beskrivelse,
                status: p.status,
                frist: p.frist,
                fremgang: p.fremgang,
                user_name: p.user_name,
                kategori: p.kategori,
                type: p.type,
                estimert_kostnad: p.estimert_kostnad
              }))}
              onStatusChange={handleStatusChange}
              canManage={canManage}
            />
          ) : (
            <div className="space-y-4">
              {plans.map(plan => {
                const statusInfo = STATUS_OPTIONS.find(s => s.value === plan.status);
                const categoryInfo = CATEGORIES.find(c => c.value === plan.kategori);
                const typeInfo = PLAN_TYPES.find(t => t.value === plan.type);
                const canUpdateProgress = plan.user_id === user?.id || canManage;
                
                return (
                  <div key={plan.id} className="p-4 rounded-lg border bg-card">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium">{plan.tittel}</span>
                          {typeInfo && <Badge variant="outline">{typeInfo.label}</Badge>}
                          {categoryInfo && <Badge variant="secondary">{categoryInfo.label}</Badge>}
                          <Badge variant={statusInfo?.color as any || "secondary"}>{statusInfo?.label}</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">{plan.user_name}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        {plan.estimert_kostnad && (
                          <Badge variant="outline" className="flex items-center gap-1">
                            <DollarSign className="h-3 w-3" />
                            {plan.estimert_kostnad.toLocaleString("nb-NO")} kr
                          </Badge>
                        )}
                        {plan.frist && (
                          <span className="text-sm text-muted-foreground">
                            Frist: {format(parseISO(plan.frist), "d. MMM yyyy", { locale: nb })}
                          </span>
                        )}
                      </div>
                    </div>

                    {plan.beskrivelse && <p className="text-sm mb-3">{plan.beskrivelse}</p>}

                    <div className="grid md:grid-cols-2 gap-3 mb-4">
                      {plan.maal && (
                        <div>
                          <p className="text-xs font-medium text-muted-foreground mb-1">Mål</p>
                          <p className="text-sm">{plan.maal}</p>
                        </div>
                      )}
                      {plan.tiltak && (
                        <div>
                          <p className="text-xs font-medium text-muted-foreground mb-1">Tiltak</p>
                          <p className="text-sm">{plan.tiltak}</p>
                        </div>
                      )}
                    </div>

                    <div className="pt-3 border-t">
                      <div className="flex items-center gap-3">
                        <TrendingUp className="h-4 w-4 text-muted-foreground" />
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-sm">Fremgang</span>
                            <span className="text-sm font-medium">{plan.fremgang}%</span>
                          </div>
                          {canUpdateProgress && plan.status !== "fullfort" && plan.status !== "avbrutt" ? (
                            <Slider
                              value={[plan.fremgang]}
                              max={100}
                              step={10}
                              onValueCommit={(value) => updateProgress(plan.id, value[0])}
                              className="cursor-pointer"
                            />
                          ) : (
                            <Progress value={plan.fremgang} className="h-2" />
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}