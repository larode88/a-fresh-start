import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Star, Info } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";

interface CompetencyDefinition {
  id: string;
  navn: string;
  beskrivelse: string | null;
  kategori: string;
  rubrikk: {
    nivaa: number;
    tittel: string;
    beskrivelse: string;
  }[];
}

interface CompetencyScore {
  kompetanse_id: string;
  score: number;
  kommentar: string;
}

interface CompetencyScoringProps {
  competencies: CompetencyDefinition[];
  scores: CompetencyScore[];
  onChange: (scores: CompetencyScore[]) => void;
  readOnly?: boolean;
}

export function CompetencyScoring({ competencies, scores, onChange, readOnly = false }: CompetencyScoringProps) {
  const getScore = (kompetanseId: string) => {
    return scores.find(s => s.kompetanse_id === kompetanseId);
  };

  const updateScore = (kompetanseId: string, score: number) => {
    if (readOnly) return;
    const existing = scores.find(s => s.kompetanse_id === kompetanseId);
    if (existing) {
      onChange(scores.map(s => s.kompetanse_id === kompetanseId ? { ...s, score } : s));
    } else {
      onChange([...scores, { kompetanse_id: kompetanseId, score, kommentar: "" }]);
    }
  };

  const updateComment = (kompetanseId: string, kommentar: string) => {
    if (readOnly) return;
    const existing = scores.find(s => s.kompetanse_id === kompetanseId);
    if (existing) {
      onChange(scores.map(s => s.kompetanse_id === kompetanseId ? { ...s, kommentar } : s));
    } else {
      onChange([...scores, { kompetanse_id: kompetanseId, score: 0, kommentar }]);
    }
  };

  const getScoreColor = (score: number) => {
    if (score <= 1) return "bg-destructive/20 text-destructive";
    if (score <= 2) return "bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400";
    if (score === 3) return "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400";
    if (score === 4) return "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400";
    return "bg-primary/20 text-primary";
  };

  const averageScore = scores.length > 0 
    ? (scores.reduce((sum, s) => sum + s.score, 0) / scores.length).toFixed(1)
    : null;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold">Kompetansevurdering</h3>
        {averageScore && (
          <Badge className={getScoreColor(parseFloat(averageScore))}>
            Gjennomsnitt: {averageScore}
          </Badge>
        )}
      </div>

      <TooltipProvider>
        <div className="space-y-4">
          {competencies.map(comp => {
            const currentScore = getScore(comp.id);
            const rubrikk = comp.rubrikk || [];
            const selectedRubrik = rubrikk.find(r => r.nivaa === currentScore?.score);

            return (
              <Card key={comp.id} className="overflow-hidden">
                <CardHeader className="pb-3 bg-muted/30">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <CardTitle className="text-base">{comp.navn}</CardTitle>
                      {comp.beskrivelse && (
                        <Tooltip>
                          <TooltipTrigger>
                            <Info className="h-4 w-4 text-muted-foreground" />
                          </TooltipTrigger>
                          <TooltipContent className="max-w-xs">
                            <p>{comp.beskrivelse}</p>
                          </TooltipContent>
                        </Tooltip>
                      )}
                    </div>
                    <Badge variant="outline" className="text-xs">{comp.kategori}</Badge>
                  </div>
                </CardHeader>
                <CardContent className="pt-4 space-y-4">
                  {/* Score buttons */}
                  <div className="flex gap-2">
                    {[1, 2, 3, 4, 5].map(level => {
                      const rubrik = rubrikk.find(r => r.nivaa === level);
                      const isSelected = currentScore?.score === level;
                      
                      return (
                        <Tooltip key={level}>
                          <TooltipTrigger asChild>
                            <button
                              type="button"
                              onClick={() => updateScore(comp.id, level)}
                              disabled={readOnly}
                              className={cn(
                                "flex-1 py-3 px-2 rounded-lg border-2 transition-all flex flex-col items-center gap-1",
                                isSelected 
                                  ? "border-primary bg-primary/10 shadow-sm" 
                                  : "border-border hover:border-primary/50 hover:bg-muted/50",
                                readOnly && "cursor-default opacity-75"
                              )}
                            >
                              <div className="flex">
                                {Array.from({ length: level }).map((_, i) => (
                                  <Star 
                                    key={i} 
                                    className={cn(
                                      "h-4 w-4",
                                      isSelected ? "text-primary fill-primary" : "text-muted-foreground"
                                    )} 
                                  />
                                ))}
                              </div>
                              <span className={cn(
                                "text-xs font-medium",
                                isSelected ? "text-primary" : "text-muted-foreground"
                              )}>
                                {level}
                              </span>
                            </button>
                          </TooltipTrigger>
                          <TooltipContent side="bottom" className="max-w-xs">
                            <p className="font-medium">{rubrik?.tittel || `Nivå ${level}`}</p>
                            {rubrik?.beskrivelse && <p className="text-xs mt-1">{rubrik.beskrivelse}</p>}
                          </TooltipContent>
                        </Tooltip>
                      );
                    })}
                  </div>

                  {/* Selected rubric description */}
                  {selectedRubrik && (
                    <div className={cn("p-3 rounded-lg text-sm", getScoreColor(currentScore?.score || 0))}>
                      <span className="font-medium">{selectedRubrik.tittel}:</span>{" "}
                      {selectedRubrik.beskrivelse}
                    </div>
                  )}

                  {/* Comment field */}
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">Kommentar (valgfritt)</Label>
                    <Textarea
                      value={currentScore?.kommentar || ""}
                      onChange={e => updateComment(comp.id, e.target.value)}
                      placeholder="Utdypende kommentar..."
                      rows={2}
                      disabled={readOnly}
                      className="resize-none"
                    />
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </TooltipProvider>
    </div>
  );
}
