// EmployeeList - Component for displaying list of employees
// This is a minimal compilable React component

import { useEffect, useState } from "react";
import { Users, UserPlus, Mail, Phone, Briefcase } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "@/hooks/use-toast";
import { getEmployeesBySalon, type EmployeeWithSalon } from "@/integrations/supabase/employeesService";

interface EmployeeListProps {
  salonId: string;
}

export function EmployeeList({ salonId }: EmployeeListProps) {
  const [employees, setEmployees] = useState<EmployeeWithSalon[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!salonId) return;

    const fetchEmployees = async () => {
      setLoading(true);
      try {
        const data = await getEmployeesBySalon(salonId);
        setEmployees(data);
      } catch (error) {
        console.error("Error fetching employees:", error);
        toast({
          title: "Feil",
          description: "Kunne ikke laste ansatte",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };

    fetchEmployees();
  }, [salonId]);

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-24 w-full" />
        <Skeleton className="h-24 w-full" />
        <Skeleton className="h-24 w-full" />
      </div>
    );
  }

  if (employees.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <Users className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
          <h3 className="text-lg font-semibold mb-2">Ingen ansatte funnet</h3>
          <p className="text-muted-foreground mb-4">
            Det er ingen registrerte ansatte for denne salongen
          </p>
          <Button>
            <UserPlus className="w-4 h-4 mr-2" />
            Legg til ansatt
          </Button>
        </CardContent>
      </Card>
    );
  }

  const getRoleBadgeVariant = (role: string) => {
    switch (role) {
      case 'salon_owner':
      case 'daglig_leder':
        return 'default';
      case 'stylist':
      case 'seniorfrisor':
        return 'secondary';
      case 'apprentice':
        return 'outline';
      default:
        return 'outline';
    }
  };

  const getRoleLabel = (role: string) => {
    const labels: Record<string, string> = {
      salon_owner: 'Eier',
      daglig_leder: 'Daglig leder',
      avdelingsleder: 'Avdelingsleder',
      stylist: 'Frisør',
      seniorfrisor: 'Senior frisør',
      apprentice: 'Lærling',
    };
    return labels[role] || role;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Ansatte</h2>
          <p className="text-muted-foreground">
            {employees.length} ansatt{employees.length !== 1 ? 'e' : ''}
          </p>
        </div>
        <Button>
          <UserPlus className="w-4 h-4 mr-2" />
          Legg til ansatt
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {employees.map((employee) => (
          <Card key={employee.id} className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-lg">{employee.name}</CardTitle>
                  <CardDescription className="mt-1">
                    <Badge variant={getRoleBadgeVariant(employee.role)}>
                      {getRoleLabel(employee.role)}
                    </Badge>
                  </CardDescription>
                </div>
                {!employee.aktiv && (
                  <Badge variant="destructive">Inaktiv</Badge>
                )}
              </div>
            </CardHeader>
            <CardContent className="space-y-2">
              {employee.email && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Mail className="w-4 h-4" />
                  <span className="truncate">{employee.email}</span>
                </div>
              )}
              {employee.phone && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Phone className="w-4 h-4" />
                  <span>{employee.phone}</span>
                </div>
              )}
              {employee.stillingsprosent != null && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Briefcase className="w-4 h-4" />
                  <span>{employee.stillingsprosent}% stilling</span>
                </div>
              )}
              {employee.ansettelsesdato && (
                <div className="text-sm text-muted-foreground">
                  Ansatt siden: {new Date(employee.ansettelsesdato).toLocaleDateString('nb-NO')}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
