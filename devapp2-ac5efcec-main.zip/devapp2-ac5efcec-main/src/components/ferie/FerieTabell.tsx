import { useMemo, useState } from "react";
import { format } from "date-fns";
import { nb } from "date-fns/locale";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Calendar, MoreHorizontal, Pencil, Trash2, Filter, Check, X, Loader2 } from "lucide-react";
import { formatHours } from "@/lib/ferieUtils";

interface Ferie {
  id: string;
  user_id: string | null;
  ansatt_id: string | null;
  startdato: string;
  sluttdato: string;
  timer: number;
  status: string;
  type?: string;
  kommentar?: string;
  users?: {
    name: string;
  };
  ansatte?: {
    id: string;
    fornavn: string;
    etternavn: string | null;
  };
}

interface Ansatt {
  id: string;
  fornavn: string;
  etternavn: string | null;
}

interface FerieTabellProps {
  ferie: Ferie[];
  isLoading: boolean;
  onEdit: (ferie: Ferie) => void;
  onDelete: (ferieId: string) => void;
  onApprove?: (ferie: Ferie) => Promise<void>;
  onReject?: (ferie: Ferie) => Promise<void>;
  canManage: boolean;
  ansatte?: Ansatt[];
  selectedAnsattId: string | null;
  onAnsattChange: (ansattId: string | null) => void;
}

const getStatusBadge = (status: string) => {
  switch (status?.toLowerCase()) {
    case "estimat":
      return <Badge variant="outline" className="border-purple-500 text-purple-600 bg-purple-50 dark:bg-purple-900/20 border-dashed">📊 Estimat</Badge>;
    case "søknad":
      return <Badge variant="outline" className="border-amber-500 text-amber-600">Søknad</Badge>;
    case "planlagt":
      return <Badge variant="secondary">Planlagt</Badge>;
    case "godkjent":
      return <Badge variant="outline" className="border-green-500 text-green-600">Godkjent</Badge>;
    case "avviklet":
      return <Badge variant="default" className="bg-green-600">Avviklet</Badge>;
    case "avslatt":
      return <Badge variant="destructive">Avslått</Badge>;
    default:
      return <Badge variant="outline">{status}</Badge>;
  }
};

export function FerieTabell({
  ferie,
  isLoading,
  onEdit,
  onDelete,
  onApprove,
  onReject,
  canManage,
  ansatte = [],
  selectedAnsattId,
  onAnsattChange
}: FerieTabellProps) {
  const [processingId, setProcessingId] = useState<string | null>(null);

  // Filter ferie based on selected ansatt
  const filteredFerie = selectedAnsattId
    ? ferie.filter(f => f.ansatt_id === selectedAnsattId)
    : ferie;

  // Sort by closest date first
  const sortedFerie = useMemo(() => {
    const today = new Date();
    return [...filteredFerie].sort((a, b) => {
      const dateA = new Date(a.startdato);
      const dateB = new Date(b.startdato);
      const distA = Math.abs(dateA.getTime() - today.getTime());
      const distB = Math.abs(dateB.getTime() - today.getTime());
      return distA - distB;
    });
  }, [filteredFerie]);

  // Check for duplicate first names to determine if we need to show last name
  const fornavnCount = useMemo(() => {
    const counts: Record<string, number> = {};
    ferie.forEach(f => {
      const fornavn = f.ansatte?.fornavn || f.users?.name?.split(' ')[0] || '';
      counts[fornavn] = (counts[fornavn] || 0) + 1;
    });
    return counts;
  }, [ferie]);

  const getDisplayName = (f: Ferie) => {
    if (f.ansatte) {
      const fornavn = f.ansatte.fornavn;
      // Only add last name if there are duplicates
      if (fornavnCount[fornavn] > 1 && f.ansatte.etternavn) {
        return `${fornavn} ${f.ansatte.etternavn}`;
      }
      return fornavn;
    }
    return f.users?.name || "Ukjent";
  };

  const handleApprove = async (f: Ferie) => {
    if (!onApprove) return;
    setProcessingId(f.id);
    try {
      await onApprove(f);
    } finally {
      setProcessingId(null);
    }
  };

  const handleReject = async (f: Ferie) => {
    if (!onReject) return;
    setProcessingId(f.id);
    try {
      await onReject(f);
    } finally {
      setProcessingId(null);
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-48" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-64" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Ferieregistreringer
            </CardTitle>
            <CardDescription>
              {filteredFerie.length} registrering{filteredFerie.length !== 1 ? "er" : ""}
              {selectedAnsattId && ` (filtrert)`}
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <Select 
              value={selectedAnsattId || "all"} 
              onValueChange={(val) => onAnsattChange(val === "all" ? null : val)}
            >
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Alle ansatte" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Alle ansatte</SelectItem>
                {ansatte.map(a => (
                  <SelectItem key={a.id} value={a.id}>
                    {a.fornavn} {a.etternavn || ''}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {filteredFerie.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <Calendar className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-muted-foreground">
              {selectedAnsattId 
                ? "Ingen ferieregistreringer funnet for valgt ansatt." 
                : "Ingen ferieregistreringer funnet."}
            </p>
          </div>
        ) : (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Ansatt</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Periode</TableHead>
                <TableHead className="text-right">Timer</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Kommentar</TableHead>
                {canManage && <TableHead className="w-24"></TableHead>}
              </TableRow>
            </TableHeader>
            <TableBody>
              {sortedFerie.map((f) => {
                const isSoknad = f.status?.toLowerCase() === "søknad";
                const isProcessing = processingId === f.id;
                
                return (
                  <TableRow key={f.id}>
                    <TableCell className="font-medium">
                      {getDisplayName(f)}
                    </TableCell>
                    <TableCell className="text-sm">
                      {f.type || "Ferie"}
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        {format(new Date(f.startdato), "d. MMM", { locale: nb })} - {format(new Date(f.sluttdato), "d. MMM yyyy", { locale: nb })}
                      </div>
                    </TableCell>
                    <TableCell className="text-right font-medium">
                      {f.timer || 0}t
                    </TableCell>
                    <TableCell>{getStatusBadge(f.status)}</TableCell>
                    <TableCell className="text-muted-foreground text-sm max-w-48 truncate">
                      {f.kommentar || "-"}
                    </TableCell>
                    {canManage && (
                      <TableCell>
                        <div className="flex items-center gap-1">
                          {/* Quick approve/reject for applications */}
                          {isSoknad && onApprove && onReject && (
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button 
                                    variant="ghost" 
                                    size="icon" 
                                    className="h-8 w-8 text-green-600 hover:text-green-700 hover:bg-green-50"
                                    onClick={() => handleApprove(f)}
                                    disabled={isProcessing}
                                  >
                                    {isProcessing ? (
                                      <Loader2 className="h-4 w-4 animate-spin" />
                                    ) : (
                                      <Check className="h-4 w-4" />
                                    )}
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>Godkjenn</TooltipContent>
                              </Tooltip>
                              <Tooltip>
                                <TooltipTrigger asChild>
                                  <Button 
                                    variant="ghost" 
                                    size="icon"
                                    className="h-8 w-8 text-red-600 hover:text-red-700 hover:bg-red-50"
                                    onClick={() => handleReject(f)}
                                    disabled={isProcessing}
                                  >
                                    <X className="h-4 w-4" />
                                  </Button>
                                </TooltipTrigger>
                                <TooltipContent>Avslå</TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          )}
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => onEdit(f)}>
                                <Pencil className="mr-2 h-4 w-4" />
                                Rediger
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={() => onDelete(f.id)}
                                className="text-destructive"
                              >
                                <Trash2 className="mr-2 h-4 w-4" />
                                Slett
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </TableCell>
                    )}
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
        )}
      </CardContent>
    </Card>
  );
}
