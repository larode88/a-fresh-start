import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ArrowRight, AlertTriangle, Loader2 } from "lucide-react";
import { validateOverforing, formatHours } from "@/lib/ferieUtils";

const overforingSchema = z.object({
  timer: z.number().min(0.5, "Må overføre minst 0,5 timer"),
  kommentar: z.string().optional(),
});

type OverforingFormData = z.infer<typeof overforingSchema>;

interface FerieOverforingDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  ansattId: string;
  ansattNavn: string;
  tilgodeTimer: number;
  feriekravType: string;
  fraAar: number;
  onSuccess: () => void;
}

export function FerieOverforingDialog({
  open,
  onOpenChange,
  ansattId,
  ansattNavn,
  tilgodeTimer,
  feriekravType,
  fraAar,
  onSuccess
}: FerieOverforingDialogProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [validationWarning, setValidationWarning] = useState<string | null>(null);

  const tilAar = fraAar + 1;

  const form = useForm<OverforingFormData>({
    resolver: zodResolver(overforingSchema),
    defaultValues: {
      timer: tilgodeTimer,
      kommentar: "",
    },
  });

  const timerValue = form.watch("timer");

  const onSubmit = async (data: OverforingFormData) => {
    // Validate
    const validation = validateOverforing(
      tilgodeTimer,
      data.timer,
      fraAar,
      tilAar,
      feriekravType
    );

    if (!validation.valid) {
      toast({
        title: "Validering feilet",
        description: validation.error,
        variant: "destructive"
      });
      return;
    }

    if (validation.warning) {
      setValidationWarning(validation.warning);
    }

    setIsSubmitting(true);
    try {
      const { error } = await supabase.from("ferie_overforing").insert({
        user_id: ansattId,
        fra_aar: fraAar,
        til_aar: tilAar,
        timer: data.timer,
        kommentar: data.kommentar,
      });

      if (error) throw error;

      toast({
        title: "Overført",
        description: `${formatHours(data.timer)} overført fra ${fraAar} til ${tilAar}`
      });

      onSuccess();
      onOpenChange(false);
    } catch (error) {
      console.error("Error saving overforing:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke lagre overføring",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ArrowRight className="h-5 w-5" />
            Overfør ferie til neste år
          </DialogTitle>
          <DialogDescription>
            Overfør ubrukte ferietimer for {ansattNavn}
          </DialogDescription>
        </DialogHeader>

        <div className="flex items-center justify-center gap-4 py-4">
          <div className="text-center">
            <div className="text-2xl font-bold">{fraAar}</div>
            <div className="text-sm text-muted-foreground">Fra år</div>
          </div>
          <ArrowRight className="h-6 w-6 text-muted-foreground" />
          <div className="text-center">
            <div className="text-2xl font-bold">{tilAar}</div>
            <div className="text-sm text-muted-foreground">Til år</div>
          </div>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="timer"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Timer å overføre</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      step="0.5"
                      min="0.5"
                      max={tilgodeTimer}
                      {...field}
                      onChange={(e) => field.onChange(parseFloat(e.target.value))}
                    />
                  </FormControl>
                  <FormDescription>
                    Tilgjengelig: {formatHours(tilgodeTimer)} (maks)
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            {timerValue > tilgodeTimer && (
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  Kan ikke overføre mer enn til gode-timer
                </AlertDescription>
              </Alert>
            )}

            {validationWarning && (
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>{validationWarning}</AlertDescription>
              </Alert>
            )}

            <FormField
              control={form.control}
              name="kommentar"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Kommentar (valgfritt)</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Begrunnelse for overføring..."
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Avbryt
              </Button>
              <Button type="submit" disabled={isSubmitting || timerValue > tilgodeTimer}>
                {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Overfør
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
