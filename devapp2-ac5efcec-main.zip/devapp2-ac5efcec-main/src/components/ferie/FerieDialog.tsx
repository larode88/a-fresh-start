import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Card, CardContent } from "@/components/ui/card";
import { CalendarIcon, Info, Loader2, CalendarOff } from "lucide-react";
import { format } from "date-fns";
import { nb } from "date-fns/locale";
import { cn } from "@/lib/utils";
import { calculateFerieBeregning, formatHours, FerieBeregning } from "@/lib/ferieUtils";
import { regenererSkiftForPeriode } from "@/integrations/supabase/turnusService";
import { regenererBudsjettForAnsattPeriode } from "@/integrations/supabase/budgetsService";

const ferieFormSchema = z.object({
  ansatt_id: z.string().min(1, "Velg en ansatt"),
  startdato: z.date({ required_error: "Startdato er påkrevd" }),
  sluttdato: z.date({ required_error: "Sluttdato er påkrevd" }),
  type: z.string().min(1, "Velg ferietype"),
  status: z.string().min(1, "Velg status"),
  kommentar: z.string().optional(),
}).refine((data) => data.sluttdato >= data.startdato, {
  message: "Sluttdato må være etter startdato",
  path: ["sluttdato"],
}).refine((data) => {
  // Krev kommentar når status er avslått
  if (data.status === "avslatt") {
    return data.kommentar && data.kommentar.trim().length > 0;
  }
  return true;
}, {
  message: "Begrunnelse er påkrevd ved avslag",
  path: ["kommentar"],
});

type FerieFormData = z.infer<typeof ferieFormSchema>;

interface Ansatt {
  id: string;
  user_id?: string | null;
  fornavn: string;
  etternavn: string | null;
  stillingsprosent: number;
}

interface Ferie {
  id: string;
  ansatt_id?: string;
  user_id?: string;
  startdato: string;
  sluttdato: string;
  type?: string;
  status: string;
  kommentar?: string;
}

interface FerieDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  ansatte: Ansatt[];
  salonId: string;
  ferie?: Ferie;
  onSuccess: () => void;
}

const FERIE_TYPER = [
  { value: "Sommerferie", label: "Sommerferie" },
  { value: "Vinterferie", label: "Vinterferie" },
  { value: "Påskeferie", label: "Påskeferie" },
  { value: "Høstferie", label: "Høstferie" },
  { value: "Juleferie", label: "Juleferie" },
  { value: "Annen ferie", label: "Annen ferie" },
];

const FERIE_STATUS = [
  { value: "estimat", label: "📊 Estimat (kun budsjett)" },
  { value: "søknad", label: "Søknad" },
  { value: "planlagt", label: "Planlagt" },
  { value: "godkjent", label: "Godkjent" },
  { value: "avviklet", label: "Avviklet" },
  { value: "avslatt", label: "Avslått" },
];

// Hjelpefunksjon for å formatere dato uten tidssone-konvertering
const formatLocalDate = (date: Date) => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

export function FerieDialog({
  open,
  onOpenChange,
  ansatte,
  salonId,
  ferie,
  onSuccess
}: FerieDialogProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedAnsatt, setSelectedAnsatt] = useState<Ansatt | null>(null);
  const [sluttdatoDisplayMonth, setSluttdatoDisplayMonth] = useState<Date | undefined>(undefined);

  const form = useForm<FerieFormData>({
    resolver: zodResolver(ferieFormSchema),
    defaultValues: {
      ansatt_id: "",
      type: "Annen ferie",
      status: "planlagt",
      kommentar: "",
    },
  });

  const startdato = form.watch("startdato");
  const sluttdato = form.watch("sluttdato");
  const ansattId = form.watch("ansatt_id");
  const currentStatus = form.watch("status");

  // Calculate work days and hours when dates change - now async with holiday exclusion
  const { data: beregning, isLoading: isCalculating } = useQuery({
    queryKey: ['ferie-beregning', startdato?.toISOString(), sluttdato?.toISOString(), selectedAnsatt?.id],
    queryFn: async (): Promise<FerieBeregning | null> => {
      if (!startdato || !sluttdato || !selectedAnsatt) return null;
      return await calculateFerieBeregning(startdato, sluttdato, selectedAnsatt.stillingsprosent);
    },
    enabled: !!(startdato && sluttdato && selectedAnsatt),
  });

  // Update selected ansatt when ansatt_id changes
  useEffect(() => {
    const ansatt = ansatte.find(a => a.id === ansattId || a.user_id === ansattId);
    setSelectedAnsatt(ansatt || null);
  }, [ansattId, ansatte]);

  // Populate form when editing, or reset when opening for new
  useEffect(() => {
    if (open) {
      if (ferie) {
        const sluttdatoDate = new Date(ferie.sluttdato + 'T12:00:00');
        form.reset({
          ansatt_id: ferie.ansatt_id || ferie.user_id || "",
          startdato: new Date(ferie.startdato + 'T12:00:00'),
          sluttdato: sluttdatoDate,
          type: ferie.type || "Annen ferie",
          status: ferie.status || "planlagt",
          kommentar: ferie.kommentar || "",
        });
        setSluttdatoDisplayMonth(sluttdatoDate);
      } else {
        form.reset({
          ansatt_id: "",
          startdato: undefined,
          sluttdato: undefined,
          type: "Annen ferie",
          status: "planlagt",
          kommentar: "",
        });
        setSelectedAnsatt(null);
        setSluttdatoDisplayMonth(undefined);
      }
    }
  }, [ferie, open, form]);

  const onSubmit = async (data: FerieFormData) => {
    if (!selectedAnsatt) return;

    // Lagre gammel periode FØR oppdatering for å regenerere skift i begge perioder
    const oldStartdato = ferie?.startdato ? new Date(ferie.startdato + 'T12:00:00') : null;
    const oldSluttdato = ferie?.sluttdato ? new Date(ferie.sluttdato + 'T12:00:00') : null;
    const oldStatus = ferie?.status;

    setIsSubmitting(true);
    try {
      // VIKTIG: Beregn timer på nytt ved lagring for å garantere korrekte verdier
      // Dette forhindrer race conditions hvor cached data brukes
      const freshBeregning = await calculateFerieBeregning(
        data.startdato,
        data.sluttdato,
        selectedAnsatt.stillingsprosent
      );

      if (ferie) {
        // Update existing
        const { error } = await supabase
          .from("ferie")
          .update({
            startdato: formatLocalDate(data.startdato),
            sluttdato: formatLocalDate(data.sluttdato),
            timer: freshBeregning.timer,
            aar: data.startdato.getFullYear(),
            type: data.type,
            status: data.status as "planlagt" | "godkjent" | "avviklet" | "avslatt",
            kommentar: data.kommentar,
          })
          .eq("id", ferie.id);

        if (error) throw error;
        toast({ title: "Oppdatert", description: "Ferie ble oppdatert" });
      } else {
        // Create new - split if crossing year boundary
        const ferieRecords = freshBeregning.perioder.map(periode => ({
          ansatt_id: selectedAnsatt.id,
          user_id: selectedAnsatt.user_id || null,
          salon_id: salonId,
          startdato: periode.startdato,
          sluttdato: periode.sluttdato,
          timer: periode.timer,
          aar: periode.aar,
          type: data.type,
          status: data.status as "planlagt" | "godkjent" | "avviklet" | "avslatt",
          kommentar: data.kommentar,
        }));

        const { error } = await supabase.from("ferie").insert(ferieRecords);
        if (error) throw error;

        if (freshBeregning.perioder.length > 1) {
          toast({
            title: "Registrert",
            description: `Ferie registrert som ${freshBeregning.perioder.length} separate perioder (årsskifte)`
          });
        } else {
          toast({ title: "Registrert", description: "Ferie ble registrert" });
        }
      }

      // Statuser som blokkerer arbeid (inkluderer estimat for budsjettberegning)
      const blockingStatuses = ['godkjent', 'planlagt', 'avviklet', 'estimat'];
      
      // Regenerer skift for NYE datoer hvis status blokkerer arbeid
      if (blockingStatuses.includes(data.status)) {
        try {
          await regenererSkiftForPeriode(
            selectedAnsatt.id,
            salonId,
            data.startdato,
            data.sluttdato
          );
          
          // Regenerer budsjett for perioden etter at skift er oppdatert
          await regenererBudsjettForAnsattPeriode(
            salonId,
            selectedAnsatt.id,
            data.startdato,
            data.sluttdato
          );
        } catch (shiftError) {
          console.error("Error regenerating shifts/budget for new period:", shiftError);
        }
      }

      // Regenerer skift og budsjett for GAMLE datoer hvis perioden er endret
      // Dette sikrer at gamle skift/budsjett gjenopprettes når ferie flyttes
      if (ferie && oldStartdato && oldSluttdato) {
        const datesChanged = 
          formatLocalDate(oldStartdato) !== formatLocalDate(data.startdato) ||
          formatLocalDate(oldSluttdato) !== formatLocalDate(data.sluttdato);
        const statusWasBlocking = blockingStatuses.includes(oldStatus || '');
        
        if (datesChanged && statusWasBlocking) {
          try {
            await regenererSkiftForPeriode(
              selectedAnsatt.id,
              salonId,
              oldStartdato,
              oldSluttdato
            );
            
            // Regenerer budsjett for den gamle perioden
            await regenererBudsjettForAnsattPeriode(
              salonId,
              selectedAnsatt.id,
              oldStartdato,
              oldSluttdato
            );
          } catch (shiftError) {
            console.error("Error regenerating shifts/budget for old period:", shiftError);
          }
        }
      }

      // Invalidate alle relevante queries så UI oppdateres
      queryClient.invalidateQueries({ queryKey: ['skift'] });
      queryClient.invalidateQueries({ queryKey: ['ansatt-turnus'] });
      queryClient.invalidateQueries({ queryKey: ['turnus-skift'] });
      queryClient.invalidateQueries({ queryKey: ['budsjett'] });
      queryClient.invalidateQueries({ queryKey: ['budget'] });

      onSuccess();
      onOpenChange(false);
    } catch (error) {
      console.error("Error saving ferie:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke lagre ferie",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>{ferie ? "Rediger ferie" : "Ny ferieregistrering"}</DialogTitle>
          <DialogDescription>
            {ferie ? "Oppdater ferieperioden" : "Registrer ferie for en ansatt"}
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="ansatt_id"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Ansatt</FormLabel>
                  <Select
                    onValueChange={field.onChange}
                    value={field.value}
                    disabled={!!ferie}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Velg ansatt" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {ansatte.map((a) => (
                        <SelectItem key={a.id} value={a.id}>
                          {a.fornavn} {a.etternavn} ({a.stillingsprosent}%)
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="startdato"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Fra dato</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            className={cn(
                              "pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(field.value, "PPP", { locale: nb })
                            ) : (
                              <span>Velg dato</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          month={field.value}
                          locale={nb}
                          initialFocus
                          className="pointer-events-auto"
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="sluttdato"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Til dato</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            className={cn(
                              "pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(field.value, "PPP", { locale: nb })
                            ) : (
                              <span>Velg dato</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={(date) => {
                            field.onChange(date);
                            if (date) setSluttdatoDisplayMonth(date);
                          }}
                          month={sluttdatoDisplayMonth || field.value || startdato}
                          onMonthChange={setSluttdatoDisplayMonth}
                          disabled={(date) => startdato ? date < startdato : false}
                          locale={nb}
                          initialFocus
                          className="pointer-events-auto"
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Beregning */}
            {isCalculating && startdato && sluttdato && (
              <Card className="bg-muted/50">
                <CardContent className="pt-4 flex items-center gap-2 text-sm text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>Beregner ferietimer...</span>
                </CardContent>
              </Card>
            )}
            {beregning && !isCalculating && (
              <Card className="bg-muted/50">
                <CardContent className="pt-4 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Arbeidsdager:</span>
                    <span className="font-medium">{beregning.arbeidsdager} dager</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Ferietimer:</span>
                    <span className="font-medium">{beregning.timer}t</span>
                  </div>
                  {beregning.ekskluderteHelligdager.length > 0 && (
                    <div className="flex items-start gap-2 pt-2 border-t text-xs text-green-600">
                      <CalendarOff className="h-4 w-4 mt-0.5 shrink-0" />
                      <div>
                        <span className="font-medium">Helligdager trukket fra:</span>
                        <ul className="mt-1 space-y-0.5">
                          {beregning.ekskluderteHelligdager.map((h) => (
                            <li key={h.dato}>
                              • {h.helligdag_navn || format(new Date(h.dato + 'T12:00:00'), 'd. MMM', { locale: nb })}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  )}
                  {beregning.perioder.length > 1 && (
                    <div className="flex items-start gap-2 pt-2 border-t text-xs text-amber-600">
                      <Info className="h-4 w-4 mt-0.5 shrink-0" />
                      <span>
                        Perioden krysser årsskiftet og vil bli splittet i {beregning.perioder.length} separate registreringer.
                      </span>
                    </div>
                  )}
                  <div className="flex items-start gap-2 pt-2 border-t text-xs text-muted-foreground">
                    <Info className="h-4 w-4 mt-0.5 shrink-0" />
                    <span>
                      Ferietimer beregnes som 7,5 timer × stillingsprosent per arbeidsdag. Helligdager telles ikke som feriedager.
                    </span>
                  </div>
                </CardContent>
              </Card>
            )}

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Type</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {FERIE_TYPER.map((t) => (
                          <SelectItem key={t.value} value={t.value}>
                            {t.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {FERIE_STATUS.map((s) => (
                          <SelectItem key={s.value} value={s.value}>
                            {s.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="kommentar"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>
                    {currentStatus === "avslatt" ? "Begrunnelse for avslag *" : "Kommentar (valgfritt)"}
                  </FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder={currentStatus === "avslatt" ? "Skriv begrunnelse for avslaget..." : "Eventuell kommentar..."}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Avbryt
              </Button>
              <Button type="submit" disabled={isSubmitting || isCalculating}>
                {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {ferie ? "Oppdater" : "Registrer"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
