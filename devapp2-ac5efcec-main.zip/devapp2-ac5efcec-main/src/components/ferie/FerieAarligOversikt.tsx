import { useMemo } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { ArrowRight, TrendingUp } from "lucide-react";
import { 
  calculateFeriekrav, 
  calculateTotalAvailableForYear, 
  formatHours, 
  getStatusVariant 
} from "@/lib/ferieUtils";

interface Ansatt {
  id: string;
  fornavn: string;
  etternavn: string | null;
  stillingsprosent: number;
  feriekrav_timer_per_aar: number;
  feriekrav_type_enum: string | null;
}

interface Ferie {
  id: string;
  ansatt_id?: string;
  user_id?: string;
  timer: number;
  status: string;
}

interface Overforing {
  id: string;
  ansatt_id?: string;
  user_id?: string;
  timer: number;
  fra_aar: number;
  til_aar: number;
}

interface FerieAarligOversiktProps {
  ansatte: Ansatt[];
  ferie: Ferie[];
  overforingInn: Overforing[];
  overforingUt: Overforing[];
  selectedAar: number;
  onOverfor: (ansattId: string, tilgode: number, feriekravType: string) => void;
}

export function FerieAarligOversikt({
  ansatte,
  ferie,
  overforingInn,
  overforingUt,
  selectedAar,
  onOverfor
}: FerieAarligOversiktProps) {
  const ansattData = useMemo(() => {
    return ansatte.map((ansatt) => {
      const feriekrav = calculateFeriekrav(
        ansatt.feriekrav_timer_per_aar || 157.5,
        ansatt.stillingsprosent || 100
      );

      const overfortInnSum = overforingInn
        ?.filter((o) => (o.ansatt_id === ansatt.id || o.user_id === ansatt.id) && o.til_aar === selectedAar)
        .reduce((sum, o) => sum + Number(o.timer), 0) || 0;

      const overfortUtSum = overforingUt
        ?.filter((o) => (o.ansatt_id === ansatt.id || o.user_id === ansatt.id) && o.fra_aar === selectedAar)
        .reduce((sum, o) => sum + Number(o.timer), 0) || 0;

      const totalTilgjengelig = calculateTotalAvailableForYear(
        feriekrav, overfortInnSum, overfortUtSum
      );

      const ansattFerie = ferie?.filter(
        (f) => f.ansatt_id === ansatt.id || f.user_id === ansatt.id
      ) || [];

      // Kun planlagt og godkjent regnes med (ikke søknad eller avslatt)
      const planlagtTimer = ansattFerie
        .filter((f) => ["planlagt", "Planlagt", "godkjent"].includes(f.status))
        .reduce((sum, f) => sum + Number(f.timer || 0), 0);

      // Kun gjennomført ferie regnes som brukt
      const gjennomfortTimer = ansattFerie
        .filter((f) => ["avviklet", "Tatt"].includes(f.status))
        .reduce((sum, f) => sum + Number(f.timer || 0), 0);

      const totalBrukt = planlagtTimer + gjennomfortTimer;
      const tilgode = Math.max(0, totalTilgjengelig - gjennomfortTimer);
      
      const planlagtProsent = totalTilgjengelig > 0 
        ? Math.round((totalBrukt / totalTilgjengelig) * 100) 
        : 0;
      
      const gjennomfortProsent = totalTilgjengelig > 0 
        ? Math.round((gjennomfortTimer / totalTilgjengelig) * 100) 
        : 0;

      return {
        ...ansatt,
        feriekrav,
        overfortInn: overfortInnSum,
        overfortUt: overfortUtSum,
        totalTilgjengelig,
        planlagtTimer,
        gjennomfortTimer,
        tilgode,
        planlagtProsent,
        gjennomfortProsent
      };
    });
  }, [ansatte, ferie, overforingInn, overforingUt, selectedAar]);

  const totals = useMemo(() => {
    return ansattData.reduce(
      (acc, a) => ({
        feriekrav: acc.feriekrav + a.feriekrav,
        tilgjengelig: acc.tilgjengelig + a.totalTilgjengelig,
        planlagt: acc.planlagt + a.planlagtTimer,
        gjennomfort: acc.gjennomfort + a.gjennomfortTimer,
        tilgode: acc.tilgode + a.tilgode
      }),
      { feriekrav: 0, tilgjengelig: 0, planlagt: 0, gjennomfort: 0, tilgode: 0 }
    );
  }, [ansattData]);

  if (ansatte.length === 0) {
    return (
      <Card>
        <CardContent className="pt-6">
          <p className="text-center text-muted-foreground">Ingen ansatte funnet.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="h-5 w-5" />
          Årlig ferieoversikt
        </CardTitle>
        <CardDescription>
          Feriekrav, overføringer og status per ansatt
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Ansatt</TableHead>
                <TableHead className="text-right">Feriekrav</TableHead>
                <TableHead className="text-right">Overført inn</TableHead>
                <TableHead className="text-right">Overført ut</TableHead>
                <TableHead className="text-right">Tilgjengelig</TableHead>
                <TableHead className="text-center w-32">Planlagt</TableHead>
                <TableHead className="text-center w-32">Gjennomført</TableHead>
                <TableHead className="text-right">Til gode</TableHead>
                <TableHead className="w-12"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {ansattData.map((a) => (
                <TableRow key={a.id}>
                  <TableCell className="font-medium">
                    {a.fornavn} {a.etternavn}
                  </TableCell>
                  <TableCell className="text-right">{formatHours(a.feriekrav)}</TableCell>
                  <TableCell className="text-right">
                    {a.overfortInn > 0 ? (
                      <span className="text-green-600">+{formatHours(a.overfortInn)}</span>
                    ) : (
                      "-"
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    {a.overfortUt > 0 ? (
                      <span className="text-red-600">-{formatHours(a.overfortUt)}</span>
                    ) : (
                      "-"
                    )}
                  </TableCell>
                  <TableCell className="text-right font-medium">
                    {formatHours(a.totalTilgjengelig)}
                  </TableCell>
                  <TableCell>
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span>{formatHours(a.planlagtTimer + a.gjennomfortTimer)}</span>
                        <Badge variant={getStatusVariant(a.planlagtProsent)} className="text-xs">
                          {a.planlagtProsent}%
                        </Badge>
                      </div>
                      <Progress value={a.planlagtProsent} className="h-1.5" />
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span>{formatHours(a.gjennomfortTimer)}</span>
                        <Badge variant={getStatusVariant(a.gjennomfortProsent)} className="text-xs">
                          {a.gjennomfortProsent}%
                        </Badge>
                      </div>
                      <Progress value={a.gjennomfortProsent} className="h-1.5" />
                    </div>
                  </TableCell>
                  <TableCell className="text-right font-medium">
                    {formatHours(a.tilgode)}
                  </TableCell>
                  <TableCell>
                    {a.tilgode > 0 && (
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => onOverfor(a.id, a.tilgode, a.feriekrav_type_enum || "")}
                        title="Overfør til neste år"
                      >
                        <ArrowRight className="h-4 w-4" />
                      </Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
              {/* Totaler */}
              <TableRow className="bg-muted/50 font-medium">
                <TableCell>Totalt</TableCell>
                <TableCell className="text-right">{formatHours(totals.feriekrav)}</TableCell>
                <TableCell className="text-right">-</TableCell>
                <TableCell className="text-right">-</TableCell>
                <TableCell className="text-right">{formatHours(totals.tilgjengelig)}</TableCell>
                <TableCell className="text-center">{formatHours(totals.planlagt + totals.gjennomfort)}</TableCell>
                <TableCell className="text-center">{formatHours(totals.gjennomfort)}</TableCell>
                <TableCell className="text-right">{formatHours(totals.tilgode)}</TableCell>
                <TableCell></TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
