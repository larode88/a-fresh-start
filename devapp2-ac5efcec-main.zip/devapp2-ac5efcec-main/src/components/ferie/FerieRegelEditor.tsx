import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { nb } from "date-fns/locale";
import { 
  Settings2, 
  Sun, 
  Snowflake, 
  Leaf, 
  Gift, 
  Loader2,
  Save,
  RotateCcw,
  Users,
  CalendarIcon
} from "lucide-react";

interface FerieRegler {
  id?: string;
  salon_id: string;
  min_bemanning: number;
  sommer_start_uke: number;
  sommer_slutt_uke: number;
  sommer_antall_uker: number;
  sommer_bruk_dato: boolean;
  sommer_start_dato: string | null;
  sommer_slutt_dato: string | null;
  vinter_aktiv: boolean;
  vinter_start_uke: number;
  vinter_slutt_uke: number;
  vinter_bruk_dato: boolean;
  vinter_start_dato: string | null;
  vinter_slutt_dato: string | null;
  paske_aktiv: boolean;
  host_aktiv: boolean;
  host_start_uke: number;
  host_slutt_uke: number;
  host_bruk_dato: boolean;
  host_start_dato: string | null;
  host_slutt_dato: string | null;
  jul_aktiv: boolean;
  jul_start_uke: number;
  jul_slutt_uke: number;
  jul_bruk_dato: boolean;
  jul_start_dato: string | null;
  jul_slutt_dato: string | null;
}

const DEFAULT_REGLER: Omit<FerieRegler, "id" | "salon_id"> = {
  min_bemanning: 2,
  sommer_start_uke: 27,
  sommer_slutt_uke: 35,
  sommer_antall_uker: 3,
  sommer_bruk_dato: false,
  sommer_start_dato: null,
  sommer_slutt_dato: null,
  vinter_aktiv: true,
  vinter_start_uke: 8,
  vinter_slutt_uke: 9,
  vinter_bruk_dato: false,
  vinter_start_dato: null,
  vinter_slutt_dato: null,
  paske_aktiv: true,
  host_aktiv: true,
  host_start_uke: 40,
  host_slutt_uke: 41,
  host_bruk_dato: false,
  host_start_dato: null,
  host_slutt_dato: null,
  jul_aktiv: true,
  jul_start_uke: 52,
  jul_slutt_uke: 52,
  jul_bruk_dato: false,
  jul_start_dato: null,
  jul_slutt_dato: null,
};

interface FerieRegelEditorProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  salonId: string;
  onSaved?: () => void;
}

interface DatePickerFieldProps {
  label: string;
  value: string | null;
  onChange: (date: string | null) => void;
}

function DatePickerField({ label, value, onChange }: DatePickerFieldProps) {
  const date = value ? new Date(value) : undefined;
  
  return (
    <div className="space-y-2">
      <Label>{label}</Label>
      <Popover>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            className={cn(
              "w-full justify-start text-left font-normal",
              !date && "text-muted-foreground"
            )}
          >
            <CalendarIcon className="mr-2 h-4 w-4" />
            {date ? format(date, "d. MMM yyyy", { locale: nb }) : "Velg dato"}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="start">
          <Calendar
            mode="single"
            selected={date}
            onSelect={(d) => onChange(d ? format(d, "yyyy-MM-dd") : null)}
            initialFocus
            className="p-3 pointer-events-auto"
          />
        </PopoverContent>
      </Popover>
    </div>
  );
}

export function FerieRegelEditor({
  open,
  onOpenChange,
  salonId,
  onSaved
}: FerieRegelEditorProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [regler, setRegler] = useState<FerieRegler>({ ...DEFAULT_REGLER, salon_id: salonId });

  // Hent eksisterende regler
  const { data: eksisterendeRegler, isLoading } = useQuery({
    queryKey: ["salong-ferie-regler", salonId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("salong_ferie_regler")
        .select("*")
        .eq("salon_id", salonId)
        .maybeSingle();
      
      if (error) throw error;
      return data;
    },
    enabled: open && !!salonId
  });

  // Oppdater state når data lastes
  useEffect(() => {
    if (eksisterendeRegler) {
      setRegler({
        ...DEFAULT_REGLER,
        ...eksisterendeRegler,
      } as FerieRegler);
    } else {
      setRegler({ ...DEFAULT_REGLER, salon_id: salonId });
    }
  }, [eksisterendeRegler, salonId]);

  // Lagre/oppdater regler
  const saveMutation = useMutation({
    mutationFn: async (data: FerieRegler) => {
    const saveData = {
        min_bemanning: data.min_bemanning,
        sommer_start_uke: data.sommer_start_uke,
        sommer_slutt_uke: data.sommer_slutt_uke,
        sommer_antall_uker: data.sommer_antall_uker,
        sommer_bruk_dato: data.sommer_bruk_dato,
        sommer_start_dato: data.sommer_start_dato,
        sommer_slutt_dato: data.sommer_slutt_dato,
        vinter_aktiv: data.vinter_aktiv,
        vinter_start_uke: data.vinter_start_uke,
        vinter_slutt_uke: data.vinter_slutt_uke,
        vinter_bruk_dato: data.vinter_bruk_dato,
        vinter_start_dato: data.vinter_start_dato,
        vinter_slutt_dato: data.vinter_slutt_dato,
        paske_aktiv: data.paske_aktiv,
        host_aktiv: data.host_aktiv,
        host_start_uke: data.host_start_uke,
        host_slutt_uke: data.host_slutt_uke,
        host_bruk_dato: data.host_bruk_dato,
        host_start_dato: data.host_start_dato,
        host_slutt_dato: data.host_slutt_dato,
        jul_aktiv: data.jul_aktiv,
        jul_start_uke: data.jul_start_uke,
        jul_slutt_uke: data.jul_slutt_uke,
        jul_bruk_dato: data.jul_bruk_dato,
        jul_start_dato: data.jul_start_dato,
        jul_slutt_dato: data.jul_slutt_dato,
      };

      if (data.id) {
        // Oppdater eksisterende
        const { error } = await supabase
          .from("salong_ferie_regler")
          .update(saveData)
          .eq("id", data.id);
        
        if (error) throw error;
      } else {
        // Opprett ny
        const { error } = await supabase
          .from("salong_ferie_regler")
          .insert({
            salon_id: data.salon_id,
            ...saveData
          });
        
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["salong-ferie-regler", salonId] });
      toast({
        title: "Regler lagret",
        description: "Feriereglene for salongen er oppdatert",
      });
      onSaved?.();
      onOpenChange(false);
    },
    onError: (error) => {
      console.error("Error saving rules:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke lagre ferieregler",
        variant: "destructive"
      });
    }
  });

  const handleReset = () => {
    setRegler({ ...DEFAULT_REGLER, salon_id: salonId, id: regler.id });
  };

  const updateRegler = (field: keyof FerieRegler, value: number | boolean | string | null) => {
    setRegler(prev => ({ ...prev, [field]: value }));
  };


  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl max-h-[90vh] flex flex-col overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings2 className="h-5 w-5 text-primary" />
            Tilpass ferieregler
          </DialogTitle>
          <DialogDescription>
            Konfigurer ferieregler og bemanningskrav for din salong
          </DialogDescription>
        </DialogHeader>

        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : (
          <ScrollArea className="flex-1 [&>[data-radix-scroll-area-viewport]]:max-h-[calc(90vh-200px)]">
            <div className="space-y-4 pr-4">
              {/* Generelle innstillinger */}
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    Generelt
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <Label htmlFor="min_bemanning">Minimum bemanning i ferier</Label>
                    <Input
                      id="min_bemanning"
                      type="number"
                      min={1}
                      max={10}
                      value={regler.min_bemanning}
                      onChange={(e) => updateRegler("min_bemanning", parseInt(e.target.value) || 1)}
                      className="w-24"
                    />
                    <p className="text-xs text-muted-foreground">
                      Antall ansatte som må være på jobb under ferieperioder
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Sommerferie */}
              <Card className="border-orange-500/20 bg-orange-500/5">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium flex items-center gap-2">
                    <Sun className="h-4 w-4 text-orange-500" />
                    Sommerferie
                  </CardTitle>
                  <CardDescription>
                    Alle ansatte får fast sommerferie med bemanningskrav
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <RadioGroup
                    value={regler.sommer_bruk_dato ? "dato" : "uke"}
                    onValueChange={(v) => updateRegler("sommer_bruk_dato", v === "dato")}
                    className="flex gap-4"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="uke" id="sommer-uke" />
                      <Label htmlFor="sommer-uke" className="cursor-pointer">Ukenummer</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="dato" id="sommer-dato" />
                      <Label htmlFor="sommer-dato" className="cursor-pointer">Datoer</Label>
                    </div>
                  </RadioGroup>

                  {regler.sommer_bruk_dato ? (
                    <div className="grid grid-cols-2 gap-4">
                      <DatePickerField
                        label="Fra dato"
                        value={regler.sommer_start_dato}
                        onChange={(d) => updateRegler("sommer_start_dato", d)}
                      />
                      <DatePickerField
                        label="Til dato"
                        value={regler.sommer_slutt_dato}
                        onChange={(d) => updateRegler("sommer_slutt_dato", d)}
                      />
                    </div>
                  ) : (
                    <div className="grid grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="sommer_start">Start (uke)</Label>
                        <Input
                          id="sommer_start"
                          type="number"
                          min={22}
                          max={35}
                          value={regler.sommer_start_uke}
                          onChange={(e) => updateRegler("sommer_start_uke", parseInt(e.target.value) || 27)}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="sommer_slutt">Slutt (uke)</Label>
                        <Input
                          id="sommer_slutt"
                          type="number"
                          min={27}
                          max={40}
                          value={regler.sommer_slutt_uke}
                          onChange={(e) => updateRegler("sommer_slutt_uke", parseInt(e.target.value) || 35)}
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="sommer_uker">Antall uker</Label>
                        <Input
                          id="sommer_uker"
                          type="number"
                          min={1}
                          max={5}
                          value={regler.sommer_antall_uker}
                          onChange={(e) => updateRegler("sommer_antall_uker", parseInt(e.target.value) || 3)}
                        />
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Separator />

              <p className="text-sm text-muted-foreground">
                Følgende perioder fordeles roterende mellom ansatte. Aktive perioder: {
                  [regler.vinter_aktiv, regler.paske_aktiv, regler.host_aktiv, regler.jul_aktiv].filter(Boolean).length
                } av 4
              </p>

              {/* Vinterferie */}
              <Card className={regler.vinter_aktiv ? "border-blue-500/20" : "opacity-50"}>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      <Snowflake className="h-4 w-4 text-blue-500" />
                      Vinterferie
                    </CardTitle>
                    <Switch
                      checked={regler.vinter_aktiv}
                      onCheckedChange={(checked) => updateRegler("vinter_aktiv", checked)}
                    />
                  </div>
                </CardHeader>
                {regler.vinter_aktiv && (
                  <CardContent className="space-y-4">
                    <RadioGroup
                      value={regler.vinter_bruk_dato ? "dato" : "uke"}
                      onValueChange={(v) => updateRegler("vinter_bruk_dato", v === "dato")}
                      className="flex gap-4"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="uke" id="vinter-uke" />
                        <Label htmlFor="vinter-uke" className="cursor-pointer">Ukenummer</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="dato" id="vinter-dato" />
                        <Label htmlFor="vinter-dato" className="cursor-pointer">Datoer</Label>
                      </div>
                    </RadioGroup>

                    {regler.vinter_bruk_dato ? (
                      <div className="grid grid-cols-2 gap-4">
                        <DatePickerField
                          label="Fra dato"
                          value={regler.vinter_start_dato}
                          onChange={(d) => updateRegler("vinter_start_dato", d)}
                        />
                        <DatePickerField
                          label="Til dato"
                          value={regler.vinter_slutt_dato}
                          onChange={(d) => updateRegler("vinter_slutt_dato", d)}
                        />
                      </div>
                    ) : (
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>Start (uke)</Label>
                          <Input
                            type="number"
                            min={1}
                            max={12}
                            value={regler.vinter_start_uke}
                            onChange={(e) => updateRegler("vinter_start_uke", parseInt(e.target.value) || 8)}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Slutt (uke)</Label>
                          <Input
                            type="number"
                            min={1}
                            max={12}
                            value={regler.vinter_slutt_uke}
                            onChange={(e) => updateRegler("vinter_slutt_uke", parseInt(e.target.value) || 9)}
                          />
                        </div>
                      </div>
                    )}
                    
                  </CardContent>
                )}
              </Card>

              {/* Påskeferie */}
              <Card className={regler.paske_aktiv ? "border-yellow-500/20" : "opacity-50"}>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      <Sun className="h-4 w-4 text-yellow-500" />
                      Påskeferie
                    </CardTitle>
                    <Switch
                      checked={regler.paske_aktiv}
                      onCheckedChange={(checked) => updateRegler("paske_aktiv", checked)}
                    />
                  </div>
                </CardHeader>
                {regler.paske_aktiv && (
                  <CardContent>
                    <p className="text-xs text-muted-foreground">
                      Påskeuke beregnes automatisk basert på kalenderåret
                    </p>
                  </CardContent>
                )}
              </Card>

              {/* Høstferie */}
              <Card className={regler.host_aktiv ? "border-amber-500/20" : "opacity-50"}>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      <Leaf className="h-4 w-4 text-amber-600" />
                      Høstferie
                    </CardTitle>
                    <Switch
                      checked={regler.host_aktiv}
                      onCheckedChange={(checked) => updateRegler("host_aktiv", checked)}
                    />
                  </div>
                </CardHeader>
                {regler.host_aktiv && (
                  <CardContent className="space-y-4">
                    <RadioGroup
                      value={regler.host_bruk_dato ? "dato" : "uke"}
                      onValueChange={(v) => updateRegler("host_bruk_dato", v === "dato")}
                      className="flex gap-4"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="uke" id="host-uke" />
                        <Label htmlFor="host-uke" className="cursor-pointer">Ukenummer</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="dato" id="host-dato" />
                        <Label htmlFor="host-dato" className="cursor-pointer">Datoer</Label>
                      </div>
                    </RadioGroup>

                    {regler.host_bruk_dato ? (
                      <div className="grid grid-cols-2 gap-4">
                        <DatePickerField
                          label="Fra dato"
                          value={regler.host_start_dato}
                          onChange={(d) => updateRegler("host_start_dato", d)}
                        />
                        <DatePickerField
                          label="Til dato"
                          value={regler.host_slutt_dato}
                          onChange={(d) => updateRegler("host_slutt_dato", d)}
                        />
                      </div>
                    ) : (
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>Start (uke)</Label>
                          <Input
                            type="number"
                            min={38}
                            max={44}
                            value={regler.host_start_uke}
                            onChange={(e) => updateRegler("host_start_uke", parseInt(e.target.value) || 40)}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Slutt (uke)</Label>
                          <Input
                            type="number"
                            min={38}
                            max={44}
                            value={regler.host_slutt_uke}
                            onChange={(e) => updateRegler("host_slutt_uke", parseInt(e.target.value) || 41)}
                          />
                        </div>
                      </div>
                    )}
                    
                  </CardContent>
                )}
              </Card>

              {/* Juleferie */}
              <Card className={regler.jul_aktiv ? "border-red-500/20" : "opacity-50"}>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      <Gift className="h-4 w-4 text-red-500" />
                      Juleferie
                    </CardTitle>
                    <Switch
                      checked={regler.jul_aktiv}
                      onCheckedChange={(checked) => updateRegler("jul_aktiv", checked)}
                    />
                  </div>
                </CardHeader>
                {regler.jul_aktiv && (
                  <CardContent className="space-y-4">
                    <RadioGroup
                      value={regler.jul_bruk_dato ? "dato" : "uke"}
                      onValueChange={(v) => updateRegler("jul_bruk_dato", v === "dato")}
                      className="flex gap-4"
                    >
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="uke" id="jul-uke" />
                        <Label htmlFor="jul-uke" className="cursor-pointer">Ukenummer</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value="dato" id="jul-dato" />
                        <Label htmlFor="jul-dato" className="cursor-pointer">Datoer</Label>
                      </div>
                    </RadioGroup>

                    {regler.jul_bruk_dato ? (
                      <div className="grid grid-cols-2 gap-4">
                        <DatePickerField
                          label="Fra dato"
                          value={regler.jul_start_dato}
                          onChange={(d) => updateRegler("jul_start_dato", d)}
                        />
                        <DatePickerField
                          label="Til dato"
                          value={regler.jul_slutt_dato}
                          onChange={(d) => updateRegler("jul_slutt_dato", d)}
                        />
                      </div>
                    ) : (
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label>Start (uke)</Label>
                          <Input
                            type="number"
                            min={49}
                            max={52}
                            value={regler.jul_start_uke}
                            onChange={(e) => updateRegler("jul_start_uke", parseInt(e.target.value) || 52)}
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Slutt (uke)</Label>
                          <Input
                            type="number"
                            min={49}
                            max={52}
                            value={regler.jul_slutt_uke}
                            onChange={(e) => updateRegler("jul_slutt_uke", parseInt(e.target.value) || 52)}
                          />
                        </div>
                      </div>
                    )}
                    
                  </CardContent>
                )}
              </Card>
            </div>
          </ScrollArea>
        )}

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={handleReset}>
            <RotateCcw className="mr-2 h-4 w-4" />
            Tilbakestill
          </Button>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Avbryt
          </Button>
          <Button 
            onClick={() => saveMutation.mutate(regler)} 
            disabled={saveMutation.isPending}
          >
            {saveMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Lagrer...
              </>
            ) : (
              <>
                <Save className="mr-2 h-4 w-4" />
                Lagre regler
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
