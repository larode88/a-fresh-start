import { useState, useMemo, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Loader2, 
  Sparkles, 
  Calendar, 
  Users, 
  Clock, 
  Sun, 
  Snowflake, 
  Leaf, 
  Gift,
  AlertTriangle,
  Check,
  Settings2
} from "lucide-react";
import { format } from "date-fns";
import { nb } from "date-fns/locale";
import { 
  genererFerieEstimater, 
  getStandardFerieperioder, 
  beregnEstimatSammendrag,
  beregnBemanningPerUke,
  type AnsattFerieEstimat,
  type Ansatt,
  type BemanningPerUke,
  type FerieEstimatPeriode
} from "@/lib/ferieEstimatUtils";
import { formatHours } from "@/lib/ferieUtils";
import { regenererSkiftForPeriode } from "@/integrations/supabase/turnusService";
import { getFerieperioderForSalong } from "@/lib/ferieRegelService";
import { FerieRegelEditor } from "./FerieRegelEditor";

interface FerieEstimatGeneratorProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  ansatte: Ansatt[];
  salonId: string;
  currentYear: number;
  eksisterendeEstimater: any[];
  onSuccess: () => void;
}

const PERIODE_ICONS: Record<string, React.ReactNode> = {
  "Estimat - Vinterferie": <Snowflake className="h-4 w-4 text-blue-500" />,
  "Estimat - Påskeferie": <Sun className="h-4 w-4 text-yellow-500" />,
  "Estimat - Sommerferie": <Sun className="h-4 w-4 text-orange-500" />,
  "Estimat - Høstferie": <Leaf className="h-4 w-4 text-amber-600" />,
  "Estimat - Juleferie": <Gift className="h-4 w-4 text-red-500" />,
};

export function FerieEstimatGenerator({
  open,
  onOpenChange,
  ansatte,
  salonId,
  currentYear,
  eksisterendeEstimater,
  onSuccess
}: FerieEstimatGeneratorProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [selectedYear, setSelectedYear] = useState(currentYear + 1);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [generatedEstimater, setGeneratedEstimater] = useState<AnsattFerieEstimat[] | null>(null);
  const [bemanningOversikt, setBemanningOversikt] = useState<BemanningPerUke[] | null>(null);
  const [overskriveEksisterende, setOverskriveEksisterende] = useState(false);
  const [showRegelEditor, setShowRegelEditor] = useState(false);
  const [salongPerioder, setSalongPerioder] = useState<FerieEstimatPeriode[] | null>(null);
  const [salongMinBemanning, setSalongMinBemanning] = useState(2);

  const years = [currentYear, currentYear + 1, currentYear + 2];

  // Hent salong-spesifikke regler
  const { data: salongRegler, refetch: refetchRegler } = useQuery({
    queryKey: ["salong-ferie-regler", salonId, selectedYear],
    queryFn: () => getFerieperioderForSalong(salonId, selectedYear),
    enabled: open && !!salonId
  });

  // Oppdater state når regler lastes
  useEffect(() => {
    if (salongRegler) {
      setSalongPerioder(salongRegler.perioder);
      setSalongMinBemanning(salongRegler.minBemanning);
    }
  }, [salongRegler]);

  // Sjekk om det finnes estimater for valgt år
  const eksisterendeForAar = useMemo(() => {
    return eksisterendeEstimater.filter(e => 
      e.aar === selectedYear && 
      e.type?.startsWith("Estimat -")
    );
  }, [eksisterendeEstimater, selectedYear]);

  // Bruk salong-perioder hvis tilgjengelig, ellers standard
  const perioder = useMemo(() => 
    salongPerioder || getStandardFerieperioder(selectedYear), 
    [salongPerioder, selectedYear]
  );

  const sammendrag = useMemo(() => {
    if (!generatedEstimater) return null;
    return beregnEstimatSammendrag(generatedEstimater);
  }, [generatedEstimater]);

  const handleGenerate = async () => {
    setIsGenerating(true);
    try {
      // Beregn allerede brukte timer per ansatt fra ALLE ferieregistreringer for året
      // (estimater, planlagte, godkjente, avviklede)
      // Hvis "overskriv" er valgt, inkluder kun IKKE-estimater (planlagte/godkjente/avviklede)
      // siden estimatene vil bli slettet og erstattet
      let eksisterendeTimerMap: Map<string, number> | undefined;
      
      const alleFerieForAar = eksisterendeEstimater.filter(e => e.aar === selectedYear);
      
      if (alleFerieForAar.length > 0) {
        eksisterendeTimerMap = new Map<string, number>();
        
        alleFerieForAar.forEach(ferieItem => {
          const erEstimat = ferieItem.type?.startsWith("Estimat -") || ferieItem.status === "estimat";
          
          // Hvis overskriv er valgt, hopp over eksisterende estimater (de blir slettet)
          if (overskriveEksisterende && erEstimat) {
            return;
          }
          
          // Inkluder alle relevante statuser
          const status = ferieItem.status?.toLowerCase();
          const relevantStatus = ['estimat', 'planlagt', 'godkjent', 'avviklet'].includes(status);
          
          if (relevantStatus && ferieItem.timer) {
            const current = eksisterendeTimerMap!.get(ferieItem.ansatt_id) || 0;
            eksisterendeTimerMap!.set(ferieItem.ansatt_id, current + (ferieItem.timer || 0));
          }
        });
        
        // Hvis map er tom, sett til undefined
        if (eksisterendeTimerMap.size === 0) {
          eksisterendeTimerMap = undefined;
        }
      }

      const config = {
        aar: selectedYear,
        perioder: perioder,
        minBemanning: salongMinBemanning,
        eksisterendeTimerPerAnsatt: eksisterendeTimerMap
      };

      const estimater = await genererFerieEstimater(ansatte, config);
      setGeneratedEstimater(estimater);
      
      // Beregn bemanning per uke for sommeren
      const sommerFordeling = new Map<string, number>();
      estimater.forEach(ae => {
        const sommerEstimat = ae.estimater.find(e => e.type === "Estimat - Sommerferie");
        if (sommerEstimat) {
          sommerFordeling.set(ae.ansattId, sommerEstimat.startUke);
        }
      });
      
      const bemanning = beregnBemanningPerUke(ansatte, sommerFordeling, salongMinBemanning);
      setBemanningOversikt(bemanning);
    } catch (error) {
      console.error("Error generating estimates:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke generere ferie-estimater",
        variant: "destructive"
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSubmit = async () => {
    if (!generatedEstimater) return;

    setIsSubmitting(true);
    try {
      // Slett eksisterende estimater hvis valgt
      if (overskriveEksisterende && eksisterendeForAar.length > 0) {
        const idsToDelete = eksisterendeForAar.map(e => e.id);
        const { error: deleteError } = await supabase
          .from("ferie")
          .delete()
          .in("id", idsToDelete);
        
        if (deleteError) throw deleteError;
      }

      // Opprett nye ferie-poster
      const alleFeriePoster: any[] = [];
      
      for (const ansattEstimat of generatedEstimater) {
        for (const estimat of ansattEstimat.estimater) {
          const feriePost: any = {
            ansatt_id: ansattEstimat.ansattId,
            salon_id: salonId,
            startdato: estimat.startdato,
            sluttdato: estimat.sluttdato,
            timer: estimat.timer,
            aar: selectedYear,
            type: estimat.type,
            status: "estimat",
            kommentar: "Auto-generert ferie-estimat for budsjettering"
          };
          
          // Bare inkluder user_id hvis ansatt har koblet bruker (unngår foreign key constraint-feil)
          if (ansattEstimat.userId) {
            feriePost.user_id = ansattEstimat.userId;
          }
          
          alleFeriePoster.push(feriePost);
        }
      }

      if (alleFeriePoster.length > 0) {
        const { error: insertError } = await supabase
          .from("ferie")
          .insert(alleFeriePoster);

        if (insertError) throw insertError;
      }

      // Regenerer skift for alle berørte ansatte og perioder
      for (const ansattEstimat of generatedEstimater) {
        for (const estimat of ansattEstimat.estimater) {
          try {
            await regenererSkiftForPeriode(
              ansattEstimat.ansattId,
              salonId,
              new Date(estimat.startdato),
              new Date(estimat.sluttdato)
            );
          } catch (shiftError) {
            console.error(`Error regenerating shifts for ${ansattEstimat.ansattId}:`, shiftError);
          }
        }
      }

      // Invalidate queries
      queryClient.invalidateQueries({ queryKey: ["ferie"] });
      queryClient.invalidateQueries({ queryKey: ["skift"] });
      queryClient.invalidateQueries({ queryKey: ["ansatt-turnus"] });
      queryClient.invalidateQueries({ queryKey: ["turnus-skift"] });

      toast({
        title: "Ferie-estimater lagret",
        description: `${alleFeriePoster.length} ferieperioder opprettet for ${generatedEstimater.length} ansatte`,
      });

      onSuccess();
      onOpenChange(false);
      setGeneratedEstimater(null);
    } catch (error) {
      console.error("Error saving estimates:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke lagre ferie-estimater",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClose = () => {
    onOpenChange(false);
    setGeneratedEstimater(null);
  };

  const handleRegelsSaved = () => {
    refetchRegler();
    setGeneratedEstimater(null);
  };

  return (
    <>
      <Dialog open={open} onOpenChange={handleClose}>
        <DialogContent className="max-w-2xl max-h-[90vh] flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-primary" />
              Generer ferie-estimater
            </DialogTitle>
            <DialogDescription>
              Generer automatiske ferie-estimater med {salongMinBemanning > 0 ? salongMinBemanning : 2} ansatte på jobb.
              <Button 
                variant="outline" 
                size="sm"
                className="ml-2"
                onClick={() => setShowRegelEditor(true)}
              >
                <Settings2 className="h-4 w-4 mr-1" />
                Tilpass regler
              </Button>
            </DialogDescription>
          </DialogHeader>

        <div className="flex-1 overflow-y-auto space-y-4">
          {/* År-velger */}
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium">Budsjettår:</span>
            </div>
            <Select 
              value={selectedYear.toString()} 
              onValueChange={(v) => {
                setSelectedYear(parseInt(v));
                setGeneratedEstimater(null);
              }}
            >
              <SelectTrigger className="w-28">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {years.map(y => (
                  <SelectItem key={y} value={y.toString()}>{y}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Advarsel om eksisterende estimater */}
          {eksisterendeForAar.length > 0 && (
            <Alert variant="default" className="bg-amber-500/10 border-amber-500/20">
              <AlertTriangle className="h-4 w-4 text-amber-500" />
              <AlertDescription className="flex items-center justify-between">
                <span>
                  Det finnes allerede {eksisterendeForAar.length} estimat(er) for {selectedYear}.
                </span>
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="overwrite"
                    checked={overskriveEksisterende}
                    onCheckedChange={(checked) => setOverskriveEksisterende(!!checked)}
                  />
                  <label htmlFor="overwrite" className="text-sm cursor-pointer">
                    Overskriv eksisterende
                  </label>
                </div>
              </AlertDescription>
            </Alert>
          )}

          {/* Perioder som vil bli generert */}
          {!generatedEstimater && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium">Ferieperioder som vil fordeles</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {perioder.map((periode) => (
                  <div key={periode.type} className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      {PERIODE_ICONS[periode.type]}
                      <span>{periode.navn}</span>
                    </div>
                    <div className="flex items-center gap-3 text-muted-foreground">
                      <span>Uke {periode.startUke}-{periode.sluttUke}</span>
                      {periode.fasteUker ? (
                        <Badge variant="default" className="text-xs bg-orange-500">
                          {periode.fasteUker} uker (krav)
                        </Badge>
                      ) : (
                        <Badge variant="secondary" className="text-xs">
                          Roterende
                        </Badge>
                      )}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {/* Generert forhåndsvisning */}
          {generatedEstimater && (
            <>
              {/* Sammendrag */}
              <Card className="bg-primary/5 border-primary/20">
                <CardContent className="pt-4">
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex items-center gap-2">
                      <Users className="h-4 w-4 text-primary" />
                      <span className="text-sm">{sammendrag?.antallAnsatte} ansatte</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-primary" />
                      <span className="text-sm">{sammendrag?.antallPerioder} perioder</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-primary" />
                      <span className="text-sm">{formatHours(sammendrag?.totalTimer || 0)}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Bemanning sommer-oversikt */}
              {bemanningOversikt && bemanningOversikt.length > 0 && (
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium flex items-center gap-2">
                      <Sun className="h-4 w-4 text-orange-500" />
                      Bemanning sommer (uke 27-35)
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex gap-1">
                      {bemanningOversikt.map((uke) => (
                        <div 
                          key={uke.uke} 
                          className={`flex-1 text-center p-2 rounded text-xs ${
                            uke.erOk 
                              ? 'bg-green-500/10 text-green-700 dark:text-green-400' 
                              : 'bg-red-500/10 text-red-700 dark:text-red-400'
                          }`}
                        >
                          <div className="font-medium">U{uke.uke}</div>
                          <div className="text-[10px] opacity-80">
                            {uke.antallPaaJobb} på jobb
                          </div>
                        </div>
                      ))}
                    </div>
                    {bemanningOversikt.some(u => !u.erOk) && (
                      <Alert variant="destructive" className="mt-2">
                        <AlertTriangle className="h-4 w-4" />
                        <AlertDescription>
                          Noen uker har færre enn 2 ansatte på jobb
                        </AlertDescription>
                      </Alert>
                    )}
                  </CardContent>
                </Card>
              )}

              {/* Detaljert liste */}
              <ScrollArea className="flex-shrink-0 h-[300px] rounded-md border">
                <div className="p-4 space-y-4">
                  {generatedEstimater.map((ansattEstimat) => (
                    <div key={ansattEstimat.ansattId} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">{ansattEstimat.ansattNavn}</span>
                        <span className="text-sm text-muted-foreground">
                          Krav: {formatHours(ansattEstimat.totalFeriekrav)} • 
                          {ansattEstimat.stillingsprosent}%
                        </span>
                      </div>
                      <div className="pl-4 space-y-1">
                        {ansattEstimat.estimater.map((estimat, idx) => (
                          <div 
                            key={idx} 
                            className="flex items-center justify-between text-sm text-muted-foreground"
                          >
                            <div className="flex items-center gap-2">
                              {PERIODE_ICONS[estimat.type]}
                              <span>{estimat.type.replace("Estimat - ", "")}</span>
                            </div>
                            <div className="flex items-center gap-3">
                              <span>
                                {format(new Date(estimat.startdato), "d. MMM", { locale: nb })} - {format(new Date(estimat.sluttdato), "d. MMM", { locale: nb })}
                              </span>
                              <span className="text-xs bg-muted px-1.5 py-0.5 rounded">
                                Uke {estimat.startUke}
                              </span>
                              <Badge variant="outline" className="text-xs">
                                {formatHours(estimat.timer)}
                              </Badge>
                            </div>
                          </div>
                        ))}
                      </div>
                      <Separator />
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </>
          )}
        </div>

        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={handleClose}>
            Avbryt
          </Button>
          
          {!generatedEstimater ? (
            <Button 
              onClick={handleGenerate} 
              disabled={isGenerating || ansatte.length === 0}
            >
              {isGenerating ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Genererer...
                </>
              ) : (
                <>
                  <Sparkles className="mr-2 h-4 w-4" />
                  Generer ferieestimat
                </>
              )}
            </Button>
          ) : (
            <Button 
              onClick={handleSubmit} 
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Lagrer...
                </>
              ) : (
                <>
                  <Check className="mr-2 h-4 w-4" />
                  Lagre {sammendrag?.antallPerioder} perioder
                </>
              )}
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
    
    <FerieRegelEditor
      open={showRegelEditor}
      onOpenChange={setShowRegelEditor}
      salonId={salonId}
      onSaved={handleRegelsSaved}
    />
    </>
  );
}
