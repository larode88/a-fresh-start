import { useState, useMemo } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { CalendarIcon, Info, Loader2, Users } from "lucide-react";
import { format } from "date-fns";
import { nb } from "date-fns/locale";
import { cn } from "@/lib/utils";
import { calculateWorkDays, splitFeriePeriode, formatHours } from "@/lib/ferieUtils";
import { regenererSkiftForPeriode } from "@/integrations/supabase/turnusService";

const bulkFerieSchema = z.object({
  ansattIds: z.array(z.string()).min(1, "Velg minst én ansatt"),
  startdato: z.date({ required_error: "Startdato er påkrevd" }),
  sluttdato: z.date({ required_error: "Sluttdato er påkrevd" }),
  type: z.string().min(1, "Velg ferietype"),
}).refine((data) => data.sluttdato >= data.startdato, {
  message: "Sluttdato må være etter startdato",
  path: ["sluttdato"],
});

type BulkFerieFormData = z.infer<typeof bulkFerieSchema>;

interface Ansatt {
  id: string;
  user_id?: string | null;
  fornavn: string;
  etternavn: string | null;
  stillingsprosent: number;
}

interface BulkFerieDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  ansatte: Ansatt[];
  salonId: string;
  onSuccess: () => void;
}

const FERIE_TYPER = [
  { value: "Fellesferie", label: "Fellesferie (jul/sommer)" },
  { value: "Sommerferie", label: "Sommerferie" },
  { value: "Vinterferie", label: "Vinterferie" },
  { value: "Påskeferie", label: "Påskeferie" },
  { value: "Juleferie", label: "Juleferie" },
];

export function BulkFerieDialog({
  open,
  onOpenChange,
  ansatte,
  salonId,
  onSuccess
}: BulkFerieDialogProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<BulkFerieFormData>({
    resolver: zodResolver(bulkFerieSchema),
    defaultValues: {
      ansattIds: [],
      type: "Fellesferie",
    },
  });

  const startdato = form.watch("startdato");
  const sluttdato = form.watch("sluttdato");
  const selectedAnsattIds = form.watch("ansattIds");

  // Calculate summary
  const summary = useMemo(() => {
    if (!startdato || !sluttdato || selectedAnsattIds.length === 0) return null;

    const workDays = calculateWorkDays(startdato, sluttdato);
    let totalTimer = 0;
    let totalPerioder = 0;

    selectedAnsattIds.forEach(id => {
      const ansatt = ansatte.find(a => a.id === id);
      if (ansatt) {
        const perioder = splitFeriePeriode(startdato, sluttdato, ansatt.stillingsprosent);
        totalPerioder += perioder.length;
        perioder.forEach(p => totalTimer += p.timer);
      }
    });

    const crossesYear = startdato.getFullYear() !== sluttdato.getFullYear();

    return {
      workDays,
      totalTimer: Math.round(totalTimer * 10) / 10,
      totalPerioder,
      crossesYear,
      ansattCount: selectedAnsattIds.length
    };
  }, [startdato, sluttdato, selectedAnsattIds, ansatte]);

  const toggleAllAnsatte = () => {
    const currentIds = form.getValues("ansattIds");
    if (currentIds.length === ansatte.length) {
      form.setValue("ansattIds", []);
    } else {
      form.setValue("ansattIds", ansatte.map(a => a.id));
    }
  };

  const onSubmit = async (data: BulkFerieFormData) => {
    setIsSubmitting(true);
    try {
      const allFerieRecords: any[] = [];

      for (const ansattId of data.ansattIds) {
        const ansatt = ansatte.find(a => a.id === ansattId);
        if (!ansatt) continue;

        const perioder = splitFeriePeriode(
          data.startdato,
          data.sluttdato,
          ansatt.stillingsprosent
        );

        for (const periode of perioder) {
          allFerieRecords.push({
            ansatt_id: ansattId,
            user_id: ansatt.user_id || null,
            salon_id: salonId,
            startdato: periode.startdato,
            sluttdato: periode.sluttdato,
            timer: periode.timer,
            aar: periode.aar,
            type: data.type,
            status: "planlagt",
          });
        }
      }

      const { error } = await supabase.from("ferie").insert(allFerieRecords);
      if (error) throw error;

      // Regenerer skift for alle berørte ansatte
      for (const ansattId of data.ansattIds) {
        try {
          await regenererSkiftForPeriode(
            ansattId,
            salonId,
            data.startdato,
            data.sluttdato
          );
        } catch (shiftError) {
          console.error(`Error regenerating shifts for ${ansattId}:`, shiftError);
        }
      }
      
      // Invalidate skift-queries
      queryClient.invalidateQueries({ queryKey: ['skift'] });
      queryClient.invalidateQueries({ queryKey: ['ansatt-turnus'] });

      toast({
        title: "Registrert",
        description: `${allFerieRecords.length} ferieperioder registrert for ${data.ansattIds.length} ansatte`
      });

      onSuccess();
      onOpenChange(false);
      form.reset();
    } catch (error) {
      console.error("Error saving bulk ferie:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke lagre ferie",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Ferie for flere ansatte
          </DialogTitle>
          <DialogDescription>
            Registrer ferie for flere ansatte samtidig (f.eks. fellesferie)
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            {/* Ansatte selection */}
            <FormField
              control={form.control}
              name="ansattIds"
              render={({ field }) => (
                <FormItem>
                  <div className="flex items-center justify-between">
                    <FormLabel>Velg ansatte</FormLabel>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={toggleAllAnsatte}
                    >
                      {field.value.length === ansatte.length ? "Fjern alle" : "Velg alle"}
                    </Button>
                  </div>
                  <FormControl>
                    <ScrollArea className="h-40 rounded-md border p-3">
                      <div className="space-y-2">
                        {ansatte.map((ansatt) => (
                          <div key={ansatt.id} className="flex items-center space-x-2">
                            <Checkbox
                              id={ansatt.id}
                              checked={field.value.includes(ansatt.id)}
                              onCheckedChange={(checked) => {
                                if (checked) {
                                  field.onChange([...field.value, ansatt.id]);
                                } else {
                                  field.onChange(field.value.filter(id => id !== ansatt.id));
                                }
                              }}
                            />
                            <label
                              htmlFor={ansatt.id}
                              className="text-sm cursor-pointer flex-1"
                            >
                              {ansatt.fornavn} {ansatt.etternavn}
                              <span className="text-muted-foreground ml-2">
                                ({ansatt.stillingsprosent}%)
                              </span>
                            </label>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="startdato"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Fra dato</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            className={cn(
                              "pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(field.value, "PPP", { locale: nb })
                            ) : (
                              <span>Velg dato</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          locale={nb}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="sluttdato"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Til dato</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            className={cn(
                              "pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(field.value, "PPP", { locale: nb })
                            ) : (
                              <span>Velg dato</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          month={field.value || startdato}
                          locale={nb}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Type</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {FERIE_TYPER.map((t) => (
                        <SelectItem key={t.value} value={t.value}>
                          {t.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Summary */}
            {summary && (
              <Card className="bg-muted/50">
                <CardContent className="pt-4 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Ansatte:</span>
                    <span className="font-medium">{summary.ansattCount} personer</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Arbeidsdager:</span>
                    <span className="font-medium">{summary.workDays} dager</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Totale ferietimer:</span>
                    <span className="font-medium">{formatHours(summary.totalTimer)}</span>
                  </div>
                  {summary.crossesYear && (
                    <div className="flex items-start gap-2 pt-2 border-t text-xs text-amber-600">
                      <Info className="h-4 w-4 mt-0.5 shrink-0" />
                      <span>
                        Perioden krysser årsskiftet. Timer fordeles per år.
                      </span>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Avbryt
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Registrer for alle
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
