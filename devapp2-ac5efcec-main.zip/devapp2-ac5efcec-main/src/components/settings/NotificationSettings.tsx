import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Bell, Mail, MessageSquare, Shield, Users, FileText, Heart } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface NotificationPreference {
  notification_type: string;
  channel: "email" | "sms" | "both";
}

const notificationTypes = [
  { type: "insurance", label: "Forsikringsvarsler", description: "Statusoppdateringer for forsikringsbestillinger", icon: Shield },
  { type: "invitation", label: "Invitasjoner", description: "Invitasjoner til salonger og team", icon: Users },
  { type: "message", label: "Meldinger", description: "Nye meldinger i innboksen", icon: MessageSquare },
  { type: "role_change", label: "Rolle-endringer", description: "Varsler om endringer i din rolle", icon: FileText },
  { type: "puls_survey", label: "Pulsundersøkelser", description: "Påminnelser om nye pulsundersøkelser", icon: Heart },
  { type: "review", label: "Samtaler", description: "Påminnelser om medarbeidersamtaler", icon: Bell },
];

export function NotificationSettings() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [preferences, setPreferences] = useState<Record<string, string>>({});

  const { data: savedPreferences, isLoading } = useQuery({
    queryKey: ["notification-preferences", user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      const { data, error } = await supabase
        .from("notification_preferences")
        .select("*")
        .eq("user_id", user.id);
      if (error) throw error;
      return data as NotificationPreference[];
    },
    enabled: !!user?.id,
  });

  useEffect(() => {
    if (savedPreferences) {
      const prefMap: Record<string, string> = {};
      savedPreferences.forEach((p) => {
        prefMap[p.notification_type] = p.channel;
      });
      // Set defaults for missing types
      notificationTypes.forEach((nt) => {
        if (!prefMap[nt.type]) {
          prefMap[nt.type] = "email";
        }
      });
      setPreferences(prefMap);
    } else {
      // Set all defaults to email
      const defaults: Record<string, string> = {};
      notificationTypes.forEach((nt) => {
        defaults[nt.type] = "email";
      });
      setPreferences(defaults);
    }
  }, [savedPreferences]);

  const updatePreference = useMutation({
    mutationFn: async ({ type, channel }: { type: string; channel: string }) => {
      if (!user?.id) throw new Error("Not authenticated");
      
      const { error } = await supabase
        .from("notification_preferences")
        .upsert({
          user_id: user.id,
          notification_type: type,
          channel,
        }, {
          onConflict: "user_id,notification_type",
        });
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["notification-preferences"] });
      toast.success("Preferanse oppdatert");
    },
    onError: (error) => {
      console.error("Error updating preference:", error);
      toast.error("Kunne ikke oppdatere preferanse");
    },
  });

  const handleChannelChange = (type: string, channel: string) => {
    setPreferences((prev) => ({ ...prev, [type]: channel }));
    updatePreference.mutate({ type, channel });
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Varslingsinnstillinger</CardTitle>
          <CardDescription>Velg hvordan du vil motta varsler</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-20 w-full" />
          ))}
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bell className="h-5 w-5" />
          Varslingsinnstillinger
        </CardTitle>
        <CardDescription>
          Velg om du vil motta varsler via e-post, SMS, eller begge deler
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {notificationTypes.map((nt) => {
          const Icon = nt.icon;
          return (
            <div
              key={nt.type}
              className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-lg border bg-card"
            >
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-md bg-primary/10">
                  <Icon className="h-4 w-4 text-primary" />
                </div>
                <div>
                  <p className="font-medium">{nt.label}</p>
                  <p className="text-sm text-muted-foreground">{nt.description}</p>
                </div>
              </div>
              
              <RadioGroup
                value={preferences[nt.type] || "email"}
                onValueChange={(value) => handleChannelChange(nt.type, value)}
                className="flex gap-4"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="email" id={`${nt.type}-email`} />
                  <Label htmlFor={`${nt.type}-email`} className="flex items-center gap-1 cursor-pointer">
                    <Mail className="h-3.5 w-3.5" />
                    <span className="text-sm">E-post</span>
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="sms" id={`${nt.type}-sms`} />
                  <Label htmlFor={`${nt.type}-sms`} className="flex items-center gap-1 cursor-pointer">
                    <MessageSquare className="h-3.5 w-3.5" />
                    <span className="text-sm">SMS</span>
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="both" id={`${nt.type}-both`} />
                  <Label htmlFor={`${nt.type}-both`} className="text-sm cursor-pointer">
                    Begge
                  </Label>
                </div>
              </RadioGroup>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}
