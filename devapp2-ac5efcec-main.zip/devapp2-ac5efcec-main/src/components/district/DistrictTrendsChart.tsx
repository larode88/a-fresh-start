import { useEffect, useState } from "react";
import { Card } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import { getISOWeek, getISOWeekYear, subWeeks } from "date-fns";

interface DistrictTrendsChartProps {
  districtId?: string | null;
  isAdmin?: boolean;
}

interface WeekData {
  week: string;
  revenue: number;
  addonShare: number;
  rebooking: number;
}

export const DistrictTrendsChart = ({ districtId, isAdmin }: DistrictTrendsChartProps) => {
  const [data, setData] = useState<WeekData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTrends = async () => {
      setLoading(true);
      try {
        // Get last 8 weeks
        const weeks: { week: number; year: number }[] = [];
        for (let i = 7; i >= 0; i--) {
          const date = subWeeks(new Date(), i);
          weeks.push({
            week: getISOWeek(date),
            year: getISOWeekYear(date),
          });
        }

        // Get salon IDs in district
        let salonIds: string[] = [];
        
        if (isAdmin) {
          const { data: salons } = await supabase.from("salons").select("id");
          salonIds = salons?.map((s) => s.id) || [];
        } else if (districtId) {
          const { data: salons } = await supabase
            .from("salons")
            .select("id")
            .eq("district_id", districtId);
          salonIds = salons?.map((s) => s.id) || [];
        }

        if (salonIds.length === 0) {
          setData([]);
          setLoading(false);
          return;
        }

        // Fetch KPIs for all weeks
        const weekData: WeekData[] = [];

        for (const { week, year } of weeks) {
          const { data: kpis } = await supabase
            .from("weekly_kpis")
            .select("total_revenue, addon_share_percent, rebooking_percent")
            .in("salon_id", salonIds)
            .eq("week", week)
            .eq("year", year);

          const totalRevenue = kpis?.reduce((sum, k) => sum + Number(k.total_revenue), 0) || 0;
          const avgAddon = kpis && kpis.length > 0
            ? kpis.reduce((sum, k) => sum + Number(k.addon_share_percent), 0) / kpis.length
            : 0;
          const avgRebooking = kpis && kpis.length > 0
            ? kpis.reduce((sum, k) => sum + Number(k.rebooking_percent), 0) / kpis.length
            : 0;

          weekData.push({
            week: `Uke ${week}`,
            revenue: Math.round(totalRevenue / 1000), // In thousands
            addonShare: Math.round(avgAddon),
            rebooking: Math.round(avgRebooking),
          });
        }

        setData(weekData);
      } catch (error) {
        console.error("Error fetching trends:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchTrends();
  }, [districtId, isAdmin]);

  if (loading) {
    return (
      <Card className="p-6">
        <div className="h-6 bg-muted rounded w-1/3 mb-4 animate-pulse" />
        <div className="h-64 bg-muted rounded animate-pulse" />
      </Card>
    );
  }

  if (data.length === 0) {
    return (
      <Card className="p-6">
        <h3 className="font-semibold text-foreground mb-4">Trendutvikling</h3>
        <div className="h-64 flex items-center justify-center">
          <p className="text-muted-foreground text-sm">Ingen trenddata tilgjengelig</p>
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-6">
      <h3 className="font-semibold text-foreground mb-4">Trendutvikling (siste 8 uker)</h3>
      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
            <XAxis dataKey="week" tick={{ fontSize: 12 }} className="text-muted-foreground" />
            <YAxis yAxisId="left" tick={{ fontSize: 12 }} className="text-muted-foreground" />
            <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 12 }} className="text-muted-foreground" />
            <Tooltip
              contentStyle={{
                backgroundColor: "hsl(var(--card))",
                border: "1px solid hsl(var(--border))",
                borderRadius: "8px",
              }}
            />
            <Legend />
            <Line
              yAxisId="left"
              type="monotone"
              dataKey="revenue"
              name="Omsetning (1000 kr)"
              stroke="hsl(var(--primary))"
              strokeWidth={2}
              dot={{ fill: "hsl(var(--primary))" }}
            />
            <Line
              yAxisId="right"
              type="monotone"
              dataKey="addonShare"
              name="Merbehandling %"
              stroke="hsl(var(--success))"
              strokeWidth={2}
              dot={{ fill: "hsl(var(--success))" }}
            />
            <Line
              yAxisId="right"
              type="monotone"
              dataKey="rebooking"
              name="Rebooking %"
              stroke="hsl(var(--warning))"
              strokeWidth={2}
              dot={{ fill: "hsl(var(--warning))" }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
};
