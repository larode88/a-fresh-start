import { Card } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Trophy } from "lucide-react";

interface Salon {
  id: string;
  name: string;
  city: string | null;
  totalRevenue: number;
  addonSharePercent: number;
  rebookingPercent: number;
  efficiencyPercent: number;
  stylistCount: number;
}

interface SalonComparisonTableProps {
  salons: Salon[];
  loading: boolean;
}

export const SalonComparisonTable = ({ salons, loading }: SalonComparisonTableProps) => {
  if (loading) {
    return (
      <Card className="p-6">
        <div className="h-6 bg-muted rounded w-1/3 mb-4 animate-pulse" />
        <div className="space-y-3">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-12 bg-muted rounded animate-pulse" />
          ))}
        </div>
      </Card>
    );
  }

  if (salons.length === 0) {
    return (
      <Card className="p-6">
        <h3 className="font-semibold text-foreground mb-4">Salongsammenligning</h3>
        <p className="text-muted-foreground text-sm text-center py-8">
          Ingen salonger i dette distriktet
        </p>
      </Card>
    );
  }

  const getPerformanceBadge = (index: number) => {
    if (index === 0) return <Badge className="bg-yellow-500 text-white"><Trophy className="h-3 w-3 mr-1" />1.</Badge>;
    if (index === 1) return <Badge variant="secondary">2.</Badge>;
    if (index === 2) return <Badge variant="outline">3.</Badge>;
    return <span className="text-muted-foreground text-sm">{index + 1}.</span>;
  };

  return (
    <Card className="p-6">
      <h3 className="font-semibold text-foreground mb-4">Salongsammenligning</h3>
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-12">#</TableHead>
              <TableHead>Salong</TableHead>
              <TableHead className="text-right">Omsetning</TableHead>
              <TableHead className="text-right">Merbehandling</TableHead>
              <TableHead className="text-right">Rebooking</TableHead>
              <TableHead className="text-right">Frisører</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {salons.map((salon, index) => (
              <TableRow key={salon.id}>
                <TableCell>{getPerformanceBadge(index)}</TableCell>
                <TableCell>
                  <div>
                    <p className="font-medium text-foreground">{salon.name}</p>
                    {salon.city && (
                      <p className="text-xs text-muted-foreground">{salon.city}</p>
                    )}
                  </div>
                </TableCell>
                <TableCell className="text-right font-medium">
                  {Math.round(salon.totalRevenue).toLocaleString("nb-NO")} kr
                </TableCell>
                <TableCell className="text-right">
                  {Math.round(salon.addonSharePercent)}%
                </TableCell>
                <TableCell className="text-right">
                  {Math.round(salon.rebookingPercent)}%
                </TableCell>
                <TableCell className="text-right">{salon.stylistCount}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </Card>
  );
};
