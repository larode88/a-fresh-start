import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { getISOWeek, getISOWeekYear } from "date-fns";
import { Card } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";

interface WeeklyTrend {
  week: number;
  omsetning: number;
  merbehandling: number;
  rebooking: number;
  effektivitet: number;
}

interface TeamTrendsChartProps {
  salonId: string;
  selectedDate: Date;
}

export const TeamTrendsChart = ({ salonId, selectedDate }: TeamTrendsChartProps) => {
  const [trends, setTrends] = useState<WeeklyTrend[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTrends = async () => {
      if (!salonId) return;

      try {
        const year = getISOWeekYear(selectedDate);
        const currentWeek = getISOWeek(selectedDate);

        // Get last 8 weeks
        const startWeek = Math.max(1, currentWeek - 7);

        const { data, error } = await supabase
          .from("weekly_kpis")
          .select("*")
          .eq("salon_id", salonId)
          .eq("year", year)
          .gte("week", startWeek)
          .lte("week", currentWeek)
          .order("week", { ascending: true });

        if (error) throw error;

        // Aggregate by week
        const weeklyData: { [key: number]: any } = {};
        
        (data || []).forEach((item: any) => {
          if (!weeklyData[item.week]) {
            weeklyData[item.week] = {
              week: item.week,
              total_revenue: 0,
              addon_share: 0,
              rebooking: 0,
              efficiency: 0,
              count: 0,
            };
          }
          weeklyData[item.week].total_revenue += Number(item.total_revenue);
          weeklyData[item.week].addon_share += Number(item.addon_share_percent);
          weeklyData[item.week].rebooking += Number(item.rebooking_percent);
          weeklyData[item.week].efficiency += Number(item.efficiency_percent);
          weeklyData[item.week].count += 1;
        });

        const formattedTrends = Object.values(weeklyData).map((week: any) => ({
          week: week.week,
          omsetning: Math.round(week.total_revenue / 1000), // in thousands
          merbehandling: Math.round(week.addon_share / week.count),
          rebooking: Math.round(week.rebooking / week.count),
          effektivitet: Math.round(week.efficiency / week.count),
        }));

        setTrends(formattedTrends);
      } catch (error) {
        console.error("Error fetching trends:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchTrends();
  }, [salonId, selectedDate]);

  if (loading) {
    return (
      <Card className="p-6">
        <h2 className="text-xl font-semibold mb-4 text-foreground">
          Trender siste 8 uker
        </h2>
        <div className="h-80 bg-muted animate-pulse rounded"></div>
      </Card>
    );
  }

  if (trends.length === 0) {
    return (
      <Card className="p-6">
        <h2 className="text-xl font-semibold mb-4 text-foreground">
          Trender siste 8 uker
        </h2>
        <div className="text-center py-20">
          <p className="text-muted-foreground">Ingen data tilgjengelig</p>
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-6 border-border shadow-card">
      <h2 className="text-xl font-semibold mb-4 text-foreground">
        Trender siste 8 uker
      </h2>
      
      <ResponsiveContainer width="100%" height={400}>
        <LineChart data={trends}>
          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
          <XAxis 
            dataKey="week" 
            label={{ value: 'Uke', position: 'insideBottom', offset: -5 }}
            stroke="hsl(var(--muted-foreground))"
          />
          <YAxis 
            stroke="hsl(var(--muted-foreground))"
          />
          <Tooltip 
            contentStyle={{ 
              backgroundColor: 'hsl(var(--card))', 
              border: '1px solid hsl(var(--border))',
              borderRadius: '8px'
            }}
          />
          <Legend />
          <Line 
            type="monotone" 
            dataKey="omsetning" 
            stroke="hsl(var(--info))" 
            strokeWidth={2}
            name="Omsetning (tkr)"
          />
          <Line 
            type="monotone" 
            dataKey="merbehandling" 
            stroke="hsl(var(--success))" 
            strokeWidth={2}
            name="Merbehandling (%)"
          />
          <Line 
            type="monotone" 
            dataKey="rebooking" 
            stroke="hsl(var(--accent))" 
            strokeWidth={2}
            name="Rebooking (%)"
          />
          <Line 
            type="monotone" 
            dataKey="effektivitet" 
            stroke="hsl(var(--primary))" 
            strokeWidth={2}
            name="Effektivitet (%)"
          />
        </LineChart>
      </ResponsiveContainer>
    </Card>
  );
};
