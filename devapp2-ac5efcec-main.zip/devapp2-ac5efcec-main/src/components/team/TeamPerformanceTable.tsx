import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { getISOWeek, getISOWeekYear } from "date-fns";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Search, X, Filter, UserCheck, Pencil } from "lucide-react";
import { useNavigate } from "react-router-dom";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

interface StylistPerformance {
  stylist_id: string;
  stylist_name: string;
  stylist_avatar: string | null;
  total_revenue: number;
  addon_share_percent: number;
  rebooking_percent: number;
  efficiency_percent: number;
  submitted_by_name: string | null;
  submitted_by_id: string | null;
}

interface TeamPerformanceTableProps {
  salonId: string;
  selectedDate: Date;
}

export const TeamPerformanceTable = ({ salonId, selectedDate }: TeamPerformanceTableProps) => {
  const navigate = useNavigate();
  const [stylists, setStylists] = useState<StylistPerformance[]>([]);
  const [filteredStylists, setFilteredStylists] = useState<StylistPerformance[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [performanceFilter, setPerformanceFilter] = useState<string>("all");

  const year = getISOWeekYear(selectedDate);
  const week = getISOWeek(selectedDate);

  useEffect(() => {
    const fetchStylistPerformance = async () => {
      if (!salonId) return;

      try {
        const year = getISOWeekYear(selectedDate);
        const weekNumber = getISOWeek(selectedDate);

        // Fetch KPIs with user data
        const { data: kpiData, error: kpiError } = await supabase
          .from("weekly_kpis")
          .select(`
            *,
            stylist:users!weekly_kpis_stylist_id_fkey(id, name, avatar_url)
          `)
          .eq("salon_id", salonId)
          .eq("year", year)
          .eq("week", weekNumber);

        if (kpiError) throw kpiError;

        // Fetch input data to get submitted_by info
        const { data: inputData, error: inputError } = await supabase
          .from("weekly_kpi_inputs")
          .select(`
            stylist_id,
            submitted_by:users!weekly_kpi_inputs_submitted_by_user_id_fkey(id, name)
          `)
          .eq("salon_id", salonId)
          .eq("year", year)
          .eq("week", weekNumber);

        if (inputError) throw inputError;

        // Create a map of stylist_id to submitted_by info
        const submittedByMap = new Map<string, { id: string; name: string } | null>();
        (inputData || []).forEach((item: any) => {
          if (item.stylist_id && item.submitted_by) {
            submittedByMap.set(item.stylist_id, item.submitted_by);
          }
        });

        const formatted = (kpiData || []).map((item: any) => {
          const submittedBy = submittedByMap.get(item.stylist_id);
          const isSubmittedBySelf = submittedBy?.id === item.stylist_id;
          return {
            stylist_id: item.stylist_id,
            stylist_name: item.stylist?.name || "Ukjent",
            stylist_avatar: item.stylist?.avatar_url || null,
            total_revenue: Number(item.total_revenue),
            addon_share_percent: Number(item.addon_share_percent),
            rebooking_percent: Number(item.rebooking_percent),
            efficiency_percent: Number(item.efficiency_percent),
            submitted_by_name: isSubmittedBySelf ? null : (submittedBy?.name || null),
            submitted_by_id: submittedBy?.id || null,
          };
        });

        // Sort by total revenue descending
        formatted.sort((a, b) => b.total_revenue - a.total_revenue);
        setStylists(formatted);
        setFilteredStylists(formatted);
      } catch (error) {
        console.error("Error fetching stylist performance:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchStylistPerformance();
  }, [salonId, selectedDate]);

  useEffect(() => {
    let filtered = [...stylists];

    // Apply search filter
    if (searchQuery) {
      filtered = filtered.filter((stylist) =>
        stylist.stylist_name.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Apply performance filter
    if (performanceFilter !== "all") {
      filtered = filtered.filter((stylist) => {
        const avgPerformance = (
          stylist.addon_share_percent +
          stylist.rebooking_percent +
          stylist.efficiency_percent
        ) / 3;

        if (performanceFilter === "excellent") return avgPerformance >= 80;
        if (performanceFilter === "good") return avgPerformance >= 60 && avgPerformance < 80;
        if (performanceFilter === "needs-improvement") return avgPerformance < 60;
        return true;
      });
    }

    setFilteredStylists(filtered);
  }, [searchQuery, performanceFilter, stylists]);

  const handleClearFilters = () => {
    setSearchQuery("");
    setPerformanceFilter("all");
  };

  const getPerformanceBadge = (value: number, type: 'revenue' | 'percent') => {
    if (type === 'percent') {
      if (value >= 80) return <Badge variant="default" className="bg-success">Utmerket</Badge>;
      if (value >= 60) return <Badge variant="secondary">Bra</Badge>;
      return <Badge variant="outline">Forbedring</Badge>;
    }
    return null;
  };

  if (loading) {
    return (
      <Card className="p-6">
        <h2 className="text-xl font-semibold mb-4 text-foreground">
          Stylist Prestasjon
        </h2>
        <div className="animate-pulse space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-12 bg-muted rounded"></div>
          ))}
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-6 border-border shadow-card">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
        <h2 className="text-xl font-semibold text-foreground">
          Stylist Prestasjon
        </h2>
        
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full sm:w-auto">
          <div className="relative flex-1 sm:w-64">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Søk etter stylist..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 pr-9"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>

          <Select value={performanceFilter} onValueChange={setPerformanceFilter}>
            <SelectTrigger className="w-full sm:w-[180px]">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Prestasjonsnivå" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Alle nivåer</SelectItem>
              <SelectItem value="excellent">Utmerket (80%+)</SelectItem>
              <SelectItem value="good">Bra (60-80%)</SelectItem>
              <SelectItem value="needs-improvement">Forbedring (&lt;60%)</SelectItem>
            </SelectContent>
          </Select>

          {(searchQuery || performanceFilter !== "all") && (
            <Button
              variant="ghost"
              size="sm"
              onClick={handleClearFilters}
              className="whitespace-nowrap"
            >
              <X className="h-4 w-4 mr-1" />
              Nullstill
            </Button>
          )}
        </div>
      </div>
      
      {stylists.length === 0 ? (
        <div className="text-center py-8">
          <p className="text-muted-foreground">
            Ingen data registrert for denne uken ennå
          </p>
        </div>
      ) : filteredStylists.length === 0 ? (
        <div className="text-center py-8">
          <p className="text-muted-foreground">
            Ingen stylister funnet med de valgte filtrene
          </p>
          <Button
            variant="outline"
            size="sm"
            onClick={handleClearFilters}
            className="mt-4"
          >
            Nullstill filtre
          </Button>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <div className="text-sm text-muted-foreground mb-2">
            Viser {filteredStylists.length} av {stylists.length} stylister
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Stylist</TableHead>
                <TableHead className="text-right">Omsetning</TableHead>
                <TableHead className="text-right">Merbehandling</TableHead>
                <TableHead className="text-right">Rebooking</TableHead>
                <TableHead className="text-right">Effektivitet</TableHead>
                <TableHead className="text-right">Status</TableHead>
                <TableHead className="text-right w-[60px]"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredStylists.map((stylist, index) => (
                <TableRow key={stylist.stylist_id}>
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-2">
                      <span className="text-muted-foreground text-sm">#{index + 1}</span>
                      <Avatar className="h-7 w-7">
                        <AvatarImage src={stylist.stylist_avatar || undefined} />
                        <AvatarFallback className="text-xs">
                          {stylist.stylist_name.split(" ").map(n => n[0]).join("").slice(0, 2)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex flex-col">
                        <span>{stylist.stylist_name}</span>
                        {stylist.submitted_by_name && (
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <span className="text-xs text-muted-foreground flex items-center gap-1 cursor-help">
                                <UserCheck className="h-3 w-3" />
                                Registrert av {stylist.submitted_by_name}
                              </span>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Denne dataen ble registrert av {stylist.submitted_by_name}</p>
                            </TooltipContent>
                          </Tooltip>
                        )}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="text-right font-semibold">
                    {Math.round(stylist.total_revenue).toLocaleString()} kr
                  </TableCell>
                  <TableCell className="text-right">
                    {Math.round(stylist.addon_share_percent)}%
                  </TableCell>
                  <TableCell className="text-right">
                    {Math.round(stylist.rebooking_percent)}%
                  </TableCell>
                  <TableCell className="text-right">
                    {Math.round(stylist.efficiency_percent)}%
                  </TableCell>
                  <TableCell className="text-right">
                    {getPerformanceBadge(stylist.efficiency_percent, 'percent')}
                  </TableCell>
                  <TableCell className="text-right">
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => navigate(`/kpi-input?stylistId=${stylist.stylist_id}&year=${year}&week=${week}`)}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Rediger KPI-data</p>
                      </TooltipContent>
                    </Tooltip>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </Card>
  );
};
