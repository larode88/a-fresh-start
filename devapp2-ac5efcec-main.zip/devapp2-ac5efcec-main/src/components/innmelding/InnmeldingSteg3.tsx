import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { InnmeldingData } from '@/pages/InnmeldingWizard';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Building, GraduationCap, Armchair, Home, Scissors, MapPinned, User, Percent, Calculator, Clock } from 'lucide-react';
import { useUserRole } from '@/hooks/useUserRole';

interface Props {
  data: InnmeldingData;
  updateData: (updates: Partial<InnmeldingData>) => void;
}

const MEDLEMSTYPER = [
  { value: 'salong', label: 'Salong', icon: Building, description: 'Standard frisørsalong' },
  { value: 'skole', label: 'Skole', icon: GraduationCap, description: 'Frisørskole/utdanningsinstitusjon' },
  { value: 'stol', label: 'Stolleie', icon: Armchair, description: 'Stolleier i salong' },
  { value: 'hjemmesalong', label: 'Hjemmesalong', icon: Home, description: 'Hjemmebasert virksomhet' },
  { value: 'barber', label: 'Barber', icon: Scissors, description: 'Barbershop' },
];

// Standard avgifter basert på medlemstype
const STANDARD_AVGIFTER: Record<string, number> = {
  salong: 3500,
  skole: 2500,
  stol: 1500,
  hjemmesalong: 1500,
  barber: 3500,
};

export default function InnmeldingSteg3({ data, updateData }: Props) {
  const { isAdmin } = useUserRole();

  // Fetch districts
  const { data: districts } = useQuery({
    queryKey: ['districts'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('districts')
        .select('*')
        .order('name');
      if (error) throw error;
      return data;
    },
  });

  // Fetch HubSpot owners for admin selector
  const { data: owners } = useQuery({
    queryKey: ['hubspot-owners-for-innmelding'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('hubspot_owner_district_mapping')
        .select('*')
        .order('hubspot_owner_name');
      if (error) throw error;
      return data;
    },
    enabled: isAdmin,
  });

  const handleTypeChange = (type: string) => {
    updateData({ 
      type_medlemskap: type,
      medlemsavgift: STANDARD_AVGIFTER[type] || 3500,
    });
  };

  const handleOwnerChange = (ownerId: string) => {
    const owner = owners?.find(o => o.hubspot_owner_id === ownerId);
    updateData({
      hubspot_owner_id: ownerId,
      hubspot_owner_name: owner?.hubspot_owner_name || '',
      district_id: owner?.district_id || data.district_id,
    });
  };
  
  return (
    <div className="space-y-6">
      {/* Kontakteier (HubSpot Owner) - Admin velger, DM ser read-only */}
      {isAdmin ? (
        <div className="space-y-2">
          <Label htmlFor="hubspot_owner" className="flex items-center gap-2">
            <User className="h-4 w-4 text-muted-foreground" />
            Kontakteier (HubSpot) *
          </Label>
          <Select
            value={data.hubspot_owner_id || ''}
            onValueChange={handleOwnerChange}
          >
            <SelectTrigger id="hubspot_owner">
              <SelectValue placeholder="Velg kontakteier..." />
            </SelectTrigger>
            <SelectContent>
              {owners?.map((owner) => (
                <SelectItem key={owner.hubspot_owner_id} value={owner.hubspot_owner_id}>
                  {owner.hubspot_owner_name} ({owner.hubspot_owner_email})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <p className="text-xs text-muted-foreground">
            Velg ansvarlig distriktssjef - signerer avtalen på vegne av Hår1
          </p>
        </div>
      ) : data.hubspot_owner_name ? (
        <div className="bg-muted/50 p-4 rounded-lg border">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
            <User className="h-4 w-4" />
            Kontakteier (signerer for Hår1)
          </div>
          <p className="font-medium">{data.hubspot_owner_name}</p>
        </div>
      ) : null}

      {/* Distrikt - Admin dropdown, DM read-only */}
      {isAdmin ? (
        <div className="space-y-2">
          <Label htmlFor="district_id" className="flex items-center gap-2">
            <MapPinned className="h-4 w-4 text-muted-foreground" />
            Distrikt *
          </Label>
          <Select
            value={data.district_id || ''}
            onValueChange={(value) => updateData({ district_id: value })}
          >
            <SelectTrigger id="district_id">
              <SelectValue placeholder="Velg distrikt" />
            </SelectTrigger>
            <SelectContent>
              {districts?.map((district) => (
                <SelectItem key={district.id} value={district.id}>
                  {district.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <p className="text-xs text-muted-foreground">
            Auto-fylt fra kontakteier - kan overstyres
          </p>
        </div>
      ) : data.district_id ? (
        <div className="bg-muted/50 p-4 rounded-lg border">
          <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
            <MapPinned className="h-4 w-4" />
            Distrikt
          </div>
          <p className="font-medium">
            {districts?.find(d => d.id === data.district_id)?.name || 'Laster...'}
          </p>
        </div>
      ) : null}

      {/* Medlemstype */}
      <div className="space-y-3">
        <Label>Type medlemskap *</Label>
        <RadioGroup
          value={data.type_medlemskap}
          onValueChange={handleTypeChange}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3"
        >
          {MEDLEMSTYPER.map((type) => {
            const Icon = type.icon;
            const isSelected = data.type_medlemskap === type.value;
            
            return (
              <Label
                key={type.value}
                htmlFor={type.value}
                className={`cursor-pointer`}
              >
                <Card className={`transition-all ${isSelected ? 'ring-2 ring-primary bg-primary/5' : 'hover:bg-muted/50'}`}>
                  <CardContent className="pt-4 flex items-start gap-3">
                    <RadioGroupItem value={type.value} id={type.value} className="mt-1" />
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <Icon className={`h-4 w-4 ${isSelected ? 'text-primary' : 'text-muted-foreground'}`} />
                        <span className="font-medium">{type.label}</span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">
                        {type.description}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </Label>
            );
          })}
        </RadioGroup>
      </div>
      
      {/* Avgifter */}
      <div className="space-y-4">
        <Label className="text-base font-semibold">Avgifter</Label>
        
        {/* Type medlemsavgift - prosent eller fast */}
        <div className="p-4 bg-muted/30 rounded-lg border space-y-4">
          <Label className="flex items-center gap-2">
            <Calculator className="h-4 w-4 text-muted-foreground" />
            Beregning av medlemsavgift
          </Label>
          
          <RadioGroup
            value={data.medlemsavgift_type || 'fast'}
            onValueChange={(value: 'prosent' | 'fast') => {
              if (value === 'prosent' && data.sum_driftsinntekter) {
                // Beregn 1% av omsetning
                const beregnetAvgift = Math.round(data.sum_driftsinntekter * 0.01 / 12); // Per måned
                updateData({ medlemsavgift_type: value, medlemsavgift: beregnetAvgift });
              } else {
                updateData({ medlemsavgift_type: value });
              }
            }}
            className="grid grid-cols-1 md:grid-cols-2 gap-3"
          >
            <Label htmlFor="avgift-prosent" className="cursor-pointer">
              <Card className={`transition-all ${data.medlemsavgift_type === 'prosent' ? 'ring-2 ring-primary bg-primary/5' : 'hover:bg-muted/50'}`}>
                <CardContent className="pt-4 flex items-start gap-3">
                  <RadioGroupItem value="prosent" id="avgift-prosent" className="mt-1" />
                  <div className="flex-1">
                    <span className="font-medium">1% av omsetning</span>
                    {data.sum_driftsinntekter ? (
                      <>
                        <p className="text-xs text-muted-foreground mt-1">
                          Basert på BRREG omsetning: kr {data.sum_driftsinntekter.toLocaleString('nb-NO')}/år
                        </p>
                        <div className="mt-2 p-2 bg-primary/10 rounded text-sm">
                          <span className="text-muted-foreground">1% = </span>
                          <span className="font-semibold text-primary">
                            kr {Math.round(data.sum_driftsinntekter * 0.01).toLocaleString('nb-NO')}/år
                          </span>
                          <span className="text-muted-foreground"> (kr {Math.round(data.sum_driftsinntekter * 0.01 / 12).toLocaleString('nb-NO')}/mnd)</span>
                        </div>
                      </>
                    ) : (
                      <p className="text-xs text-destructive mt-1">
                        Omsetningsdata ikke tilgjengelig fra BRREG
                      </p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </Label>
            
            <Label htmlFor="avgift-fast" className="cursor-pointer">
              <Card className={`transition-all ${data.medlemsavgift_type === 'fast' ? 'ring-2 ring-primary bg-primary/5' : 'hover:bg-muted/50'}`}>
                <CardContent className="pt-4 flex items-start gap-3">
                  <RadioGroupItem value="fast" id="avgift-fast" className="mt-1" />
                  <div className="flex-1">
                    <span className="font-medium">Fast avgift</span>
                    <p className="text-xs text-muted-foreground mt-1">
                      Velg et fast beløp per måned
                    </p>
                  </div>
                </CardContent>
              </Card>
            </Label>
          </RadioGroup>
        </div>

        {/* Prøvetid toggle */}
        <div className="p-4 bg-muted/30 rounded-lg border">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Clock className="h-5 w-5 text-muted-foreground" />
              <div>
                <Label htmlFor="provetid" className="font-medium cursor-pointer">
                  12 måneders prøvetid
                </Label>
                <p className="text-xs text-muted-foreground">
                  Medlem kan si opp uten bindingstid i prøveperioden
                </p>
              </div>
            </div>
            <Switch
              id="provetid"
              checked={data.har_provetid ?? false}
              onCheckedChange={(checked) => updateData({ har_provetid: checked })}
            />
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="medlemsavgift">Månedlig medlemsavgift (kr) *</Label>
            <Input
              id="medlemsavgift"
              type="number"
              value={data.medlemsavgift || ''}
              onChange={(e) => updateData({ medlemsavgift: parseInt(e.target.value) || 0 })}
              placeholder="3500"
              disabled={data.medlemsavgift_type === 'prosent'}
            />
            <p className="text-xs text-muted-foreground">
              {data.medlemsavgift_type === 'prosent' 
                ? 'Beregnet fra 1% av årlig omsetning'
                : `Standard for ${data.type_medlemskap}: kr ${STANDARD_AVGIFTER[data.type_medlemskap]?.toLocaleString('nb-NO')}`}
            </p>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="bankkontonummer">Bankkontonummer</Label>
            <Input
              id="bankkontonummer"
              value={data.bankkontonummer || ''}
              onChange={(e) => updateData({ bankkontonummer: e.target.value })}
              placeholder="1234 56 78901"
            />
            <p className="text-xs text-muted-foreground">
              For utbetaling av bonuser o.l.
            </p>
          </div>
        </div>
        
        {/* Innmeldingsavgift rabatt */}
        <div className="p-4 bg-muted/30 rounded-lg border space-y-3">
          <div className="flex items-center justify-between">
            <Label className="flex items-center gap-2">
              <Percent className="h-4 w-4 text-muted-foreground" />
              Rabatt på innmeldingsavgift
            </Label>
            <span className="text-lg font-semibold text-primary">
              {data.innmeldingsavgift_rabatt ?? 100}%
            </span>
          </div>
          
          <Slider
            value={[data.innmeldingsavgift_rabatt ?? 100]}
            onValueChange={(value) => updateData({ innmeldingsavgift_rabatt: value[0] })}
            min={0}
            max={100}
            step={5}
            className="w-full"
          />
          
          <div className="flex justify-between text-xs text-muted-foreground">
            <span>0% (full pris)</span>
            <span>100% (gratis)</span>
          </div>
          
          <div className="flex items-center justify-between pt-2 border-t">
            <span className="text-sm text-muted-foreground">Innmeldingsavgift (kr 5.000):</span>
            <div className="text-right">
              {(data.innmeldingsavgift_rabatt ?? 100) > 0 && (
                <span className="text-sm line-through text-muted-foreground mr-2">
                  kr 5 000
                </span>
              )}
              <span className="font-semibold text-green-600">
                kr {(5000 * (1 - (data.innmeldingsavgift_rabatt ?? 100) / 100)).toLocaleString('nb-NO')}
              </span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Fakturaadresse */}
      <div className="space-y-2">
        <Label htmlFor="fakturaadresse">Fakturaadresse (hvis annen enn forretningsadresse)</Label>
        <Textarea
          id="fakturaadresse"
          value={data.fakturaadresse || ''}
          onChange={(e) => updateData({ fakturaadresse: e.target.value })}
          placeholder="Fakturagata 1&#10;1234 Fakturaby"
          rows={3}
        />
      </div>
      
      {/* Summary */}
      {data.type_medlemskap && data.medlemsavgift > 0 && (
        <Card className="bg-primary/5 border-primary/20">
          <CardContent className="pt-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium">Oppsummering</p>
                <p className="text-sm text-muted-foreground">
                  {MEDLEMSTYPER.find(t => t.value === data.type_medlemskap)?.label} - {data.navn}
                </p>
              </div>
              <div className="text-right">
                <p className="text-2xl font-semibold">
                  kr {data.medlemsavgift.toLocaleString('nb-NO')}
                </p>
                <p className="text-sm text-muted-foreground">per år</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
