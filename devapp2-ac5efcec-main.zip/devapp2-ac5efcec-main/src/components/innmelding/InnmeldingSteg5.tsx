import { useState, useEffect, useCallback } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { InnmeldingData } from '@/pages/InnmeldingWizard';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FileText, Upload, Send, Check, Loader2, ExternalLink, RefreshCw, Eye, Download, Building2, TestTube } from 'lucide-react';
import { toast } from 'sonner';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import html2pdf from 'html2pdf.js';

interface Props {
  data: InnmeldingData;
  updateData: (updates: Partial<InnmeldingData>) => void;
}

// Hår1 logo URL - use absolute URL for print window
const HAAR1_LOGO_URL = window.location.origin + '/haar1-logo-black.png';

export default function InnmeldingSteg5({ data, updateData }: Props) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [signingUrl, setSigningUrl] = useState<string | null>(null);
  const queryClient = useQueryClient();
  
  // Fetch current user with profile
  const { data: currentUser } = useQuery({
    queryKey: ['current-user-for-agreement'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return null;
      
      // Get user profile for name
      const { data: profile } = await supabase
        .from('users')
        .select('first_name, last_name')
        .eq('id', user.id)
        .single();
      
      return { ...user, profile };
    },
  });

  // Get the main contact person
  const hovedkontakt = data.kontaktpersoner.find(k => k.er_hovedkontakt) || data.kontaktpersoner[0];
  const haar1Signerer = currentUser?.profile 
    ? `${currentUser.profile.first_name || ''} ${currentUser.profile.last_name || ''}`.trim() 
    : '';

  // Generate HTML content for PDF - shared between download and Firma.dev
  // Uses HTML tables instead of flexbox for reliable html2canvas rendering
  // Design matches the approved A4 reference layout
  const generatePdfHtml = (includeSignatures: boolean) => {
    const hovedkontaktNavn = hovedkontakt ? `${hovedkontakt.fornavn} ${hovedkontakt.etternavn}` : '';
    const originalFee = 5000;
    const rabatt = data.innmeldingsavgift_rabatt ?? 0;
    const discountedFee = originalFee * (1 - rabatt / 100);
    
    // Compact styles to fit everything on one A4 page - all inline for html2canvas compatibility
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Medlemsavtale - ${data.navn}</title>
      </head>
      <body style="font-family: Georgia, 'Times New Roman', serif; padding: 12px 20px; color: #2D2D2D; line-height: 1.3; font-size: 7.5pt; background: #fff; margin: 0;">
        
        <!-- Header -->
        <div style="text-align: center; margin-bottom: 10px;">
          <img src="${HAAR1_LOGO_URL}" alt="Hår1 Logo" style="height: 28px; margin-bottom: 8px;" />
          <div style="border-top: 1px solid #C4A574; margin: 0 auto 8px auto; width: 100%;"></div>
          <h1 style="font-size: 11pt; font-weight: normal; color: #8B7355; margin: 0 0 6px 0; letter-spacing: 0.5px;">Samarbeidsavtale mellom ${data.navn} og Hår1. Kjeden AS</h1>
          <div style="border-top: 1px solid #C4A574; margin: 8px auto 0 auto; width: 100%;"></div>
        </div>
        
        <!-- Avtaleparter section header -->
        <div style="margin: 8px 0 6px 0; border-bottom: 1px solid #C4A574; padding-bottom: 2px;">
          <span style="font-size: 9pt; color: #C4A574; font-style: italic; font-weight: normal;">Avtaleparter</span>
        </div>
        <p style="font-size: 7pt; color: #555; margin-bottom: 6px; line-height: 1.4;">Avtale inngås mellom <strong>Hår1. Kjeden AS</strong> (org.nr: 987 658 738) og selskapet beskrevet nedenfor.</p>
        
        <!-- Parties table -->
        <table style="width: 100%; border-collapse: separate; border-spacing: 8px 0; margin: 0 -4px 6px -4px;">
          <tr>
            <td style="width: 50%; vertical-align: top; padding: 8px 10px; background: #FAFAF8; border: 1px solid #E8E4DC; font-size: 7pt;">
              <div style="display: table; width: 100%; margin: 0 0 4px 0; font-size: 8pt; font-weight: 600; color: #2D2D2D;">
                <span style="color: #C4A574; font-size: 8pt; margin-right: 4px;">■</span> Hår1. Kjeden AS
              </div>
              <p style="margin: 2px 0; line-height: 1.3; color: #444;"><strong style="color: #2D2D2D;">Org.nr:</strong> 987 658 738</p>
              <p style="margin: 2px 0; line-height: 1.3; color: #444;"><strong style="color: #2D2D2D;">Adresse:</strong> Apotekergata 10 B, 0180 Oslo</p>
            </td>
            <td style="width: 50%; vertical-align: top; padding: 8px 10px; background: #FAFAF8; border: 1px solid #E8E4DC; font-size: 7pt;">
              <div style="display: table; width: 100%; margin: 0 0 4px 0; font-size: 8pt; font-weight: 600; color: #2D2D2D;">
                <span style="color: #C4A574; font-size: 8pt; margin-right: 4px;">■</span> ${data.navn}
              </div>
              <p style="margin: 2px 0; line-height: 1.3; color: #444;"><strong style="color: #2D2D2D;">Org.nr:</strong> ${data.org_nummer}</p>
              <p style="margin: 2px 0; line-height: 1.3; color: #444;"><strong style="color: #2D2D2D;">Adresse:</strong> ${data.adresse || '-'}, ${data.postnummer} ${data.poststed}</p>
              <p style="margin: 2px 0; line-height: 1.3; color: #444;"><strong style="color: #2D2D2D;">Kontakt:</strong> ${hovedkontaktNavn} | ${hovedkontakt?.epost || '-'} | ${hovedkontakt?.telefon || '-'}</p>
            </td>
          </tr>
        </table>
        
        <!-- Medlemsvilkår section header -->
        <div style="margin: 8px 0 6px 0; border-bottom: 1px solid #C4A574; padding-bottom: 2px;">
          <span style="font-size: 9pt; color: #C4A574; font-style: italic; font-weight: normal;">Medlemsvilkår</span>
        </div>
        
        <!-- Terms - two columns -->
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 6px;">
          <tr>
            <td style="width: 50%; vertical-align: top; padding-right: 10px; font-size: 6.5pt;">
              <div style="margin-bottom: 5px;">
                <p style="font-size: 7pt; font-weight: 600; font-style: italic; margin: 0 0 1px 0; color: #2D2D2D;">§1 Hensikt og Målsetting</p>
                <p style="margin: 0; line-height: 1.35; color: #444;">Hår1 bistår med helhetlig konsept for frisørsalonger for å øke lønnsomheten gjennom faglig utvikling, service- og salgsutvikling, og driftsstøtte.</p>
              </div>
              
              <div style="margin-bottom: 5px;">
                <p style="font-size: 7pt; font-weight: 600; font-style: italic; margin: 0 0 1px 0; color: #2D2D2D;">§2 Hår1s Forpliktelser</p>
                <p style="margin: 0; line-height: 1.35; color: #444;">Responsgaranti 24t, skreddersydde opplæringsprogrammer, markedets beste priser, deling av nøkkeltall, markedsføringsstøtte, HR-rådgivning.</p>
              </div>
              
              <div style="margin-bottom: 5px;">
                <p style="font-size: 7pt; font-weight: 600; font-style: italic; margin: 0 0 1px 0; color: #2D2D2D;">§3 Bonusprogram</p>
                <p style="margin: 0; line-height: 1.35; color: #444;">Lojalitetsbonus i mars basert på varekjøp opp til 5%. Vekstbonus inntil 10%.</p>
              </div>
            </td>
            <td style="width: 50%; vertical-align: top; padding-left: 10px; font-size: 6.5pt;">
              <div style="margin-bottom: 5px;">
                <p style="font-size: 7pt; font-weight: 600; font-style: italic; margin: 0 0 1px 0; color: #2D2D2D;">§4 Overdragelse av Medlemskap</p>
                <p style="margin: 0; line-height: 1.35; color: #444;">Rettigheter og forpliktelser følger virksomheten ved endringer i eierskap.</p>
              </div>
              
              <div style="margin-bottom: 5px;">
                <p style="font-size: 7pt; font-weight: 600; font-style: italic; margin: 0 0 1px 0; color: #2D2D2D;">§5 Personvern og GDPR</p>
                <p style="margin: 0; line-height: 1.35; color: #444;">Hår1 behandler personopplysninger iht. GDPR. Kontaktinfo kan deles med partnere for brukerprofiler.</p>
              </div>
              
              <div style="margin-bottom: 5px;">
                <p style="font-size: 7pt; font-weight: 600; font-style: italic; margin: 0 0 1px 0; color: #2D2D2D;">§6 Varighet og Oppsigelse</p>
                <p style="margin: 0; line-height: 1.35; color: #444;">${data.har_provetid ? '12 mnd prøveperiode. ' : ''}Automatisk fornyelse, 6 mnd oppsigelsesvarsel.</p>
              </div>
            </td>
          </tr>
        </table>
        
        <!-- Avgifter section header -->
        <div style="margin: 8px 0 6px 0; border-bottom: 1px solid #C4A574; padding-bottom: 2px;">
          <span style="font-size: 9pt; color: #C4A574; font-style: italic; font-weight: normal;">Avgifter</span>
        </div>
        
        <!-- Fees table -->
        <table style="width: 100%; border-collapse: separate; border-spacing: 8px 0; margin: 0 -4px 6px -4px;">
          <tr>
            <td style="width: 50%; vertical-align: top; padding: 8px 10px; background: #FAFAF8; border: 1px solid #E8E4DC; font-size: 7pt;">
              <p style="margin: 0 0 4px 0; font-size: 8pt; font-weight: 600; color: #2D2D2D;">Innmeldingsavgift</p>
              <p style="margin: 2px 0; line-height: 1.3; color: #555;">Ved innmelding: kr 5.000 eks. mva.</p>
              ${rabatt > 0 ? `
                <p style="margin-top: 4px;">
                  <span style="text-decoration: line-through; color: #999; font-size: 7pt;">NOK 5 000</span>
                  <span style="color: #5A8F5A; font-weight: 600; font-size: 7pt; margin-left: 6px;">${rabatt}% rabatt</span>
                </p>
                <p style="font-size: 10pt; font-weight: 700; color: #D4856A; margin-top: 3px;">NOK ${discountedFee.toLocaleString('nb-NO', { minimumFractionDigits: 0 })}</p>
              ` : `
                <p style="font-size: 10pt; font-weight: 700; color: #D4856A; margin-top: 3px;">NOK 5 000</p>
              `}
            </td>
            <td style="width: 50%; vertical-align: top; padding: 8px 10px; background: #FAFAF8; border: 1px solid #E8E4DC; font-size: 7pt;">
              <p style="margin: 0 0 4px 0; font-size: 8pt; font-weight: 600; color: #2D2D2D;">Månedlig medlemsavgift</p>
              <p style="margin: 2px 0; line-height: 1.3; color: #555;">${data.medlemsavgift_type === 'prosent' ? '1% av omsetning ekskl. mva, min:' : 'Fast avgift:'}</p>
              <p style="font-size: 10pt; font-weight: 700; color: #D4856A; margin-top: 3px;">NOK ${data.medlemsavgift?.toLocaleString('nb-NO') || '0'},- / mnd</p>
            </td>
          </tr>
        </table>
        
        ${includeSignatures ? `
        <!-- Signaturer section header -->
        <div style="margin: 8px 0 6px 0; border-bottom: 1px solid #C4A574; padding-bottom: 2px;">
          <span style="font-size: 9pt; color: #C4A574; font-style: italic; font-weight: normal;">Signaturer</span>
        </div>
        
        <!-- Signatures table -->
        <table style="width: 100%; border-collapse: separate; border-spacing: 8px 0; margin: 0 -4px 6px -4px;">
          <tr>
            <td style="width: 50%; vertical-align: top; padding: 8px 10px; background: #FAFAF8; border: 1px solid #E8E4DC; font-size: 7pt;">
              <p style="margin: 0 0 6px 0; font-size: 8pt; font-weight: 600;">For Hår1. Kjeden AS</p>
              <p style="margin-bottom: 4px; color: #444;">Navn: ${data.hubspot_owner_name || '_______________________'}</p>
              <div style="border-bottom: 1px solid #2D2D2D; margin: 4px 0 2px 0; padding-top: 20px;"></div>
              <p style="font-size: 6pt; color: #777; font-style: italic;">Signatur</p>
              <p style="margin-top: 6px; color: #444;">Dato: _______________________</p>
            </td>
            <td style="width: 50%; vertical-align: top; padding: 8px 10px; background: #FAFAF8; border: 1px solid #E8E4DC; font-size: 7pt;">
              <p style="margin: 0 0 6px 0; font-size: 8pt; font-weight: 600;">For ${data.navn}</p>
              <p style="margin-bottom: 4px; color: #444;">Navn: ${hovedkontaktNavn || '_______________________'}</p>
              <div style="border-bottom: 1px solid #2D2D2D; margin: 4px 0 2px 0; padding-top: 20px;"></div>
              <p style="font-size: 6pt; color: #777; font-style: italic;">Signatur</p>
              <p style="margin-top: 6px; color: #444;">Dato: _______________________</p>
            </td>
          </tr>
        </table>
        ` : ''}
        
        <!-- Footer -->
        <div style="margin-top: 8px; text-align: center; font-size: 6pt; color: #888; border-top: 1px solid #E8E4DC; padding-top: 6px;">
          Hår1. Kjeden AS | Apotekergata 10 B, 0180 Oslo | Org.nr: 987 658 738 | www.haar1.no
        </div>
      </body>
      </html>
    `;
  };

  // Generate PDF Base64 using html2pdf.js which properly handles full HTML documents
  const generatePdfBase64 = async (includeSignatures: boolean): Promise<string> => {
    const htmlContent = generatePdfHtml(includeSignatures);
    
    // Create an iframe to properly render the full HTML document
    const iframe = document.createElement('iframe');
    iframe.style.position = 'absolute';
    iframe.style.left = '-9999px';
    iframe.style.width = '210mm';
    iframe.style.height = '297mm';
    document.body.appendChild(iframe);
    
    // Write the full HTML document to the iframe
    const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
    if (!iframeDoc) {
      document.body.removeChild(iframe);
      throw new Error('Could not access iframe document');
    }
    
    iframeDoc.open();
    iframeDoc.write(htmlContent);
    iframeDoc.close();
    
    // Wait for content and images to render
    await new Promise(resolve => setTimeout(resolve, 500));
    
    try {
      const element = iframeDoc.body;
      
      // Use html2pdf.js which handles iframe content correctly
      const opt = {
        margin: 0,
        filename: 'avtale.pdf',
        image: { type: 'jpeg' as const, quality: 0.98 },
        html2canvas: { 
          scale: 2, 
          useCORS: true, 
          logging: false,
          backgroundColor: '#ffffff',
        },
        jsPDF: { unit: 'mm' as const, format: 'a4' as const, orientation: 'portrait' as const },
      };
      
      // Generate PDF as blob first, then convert to base64
      const pdfBlob = await html2pdf().set(opt).from(element).outputPdf('blob');
      
      // Convert blob to base64
      return new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
          const result = reader.result as string;
          const base64 = result.split(',')[1];
          resolve(base64);
        };
        reader.onerror = reject;
        reader.readAsDataURL(pdfBlob);
      });
    } finally {
      document.body.removeChild(iframe);
    }
  };
  
  // Test function to verify PDF generation before sending to Firma.dev
  const handleTestPdf = async () => {
    try {
      toast.info('Genererer test-PDF...');
      
      const base64 = await generatePdfBase64(false);
      const fileSizeKB = Math.round(base64.length * 0.75 / 1024);
      
      console.log('PDF base64 length:', base64.length);
      console.log('PDF estimated size KB:', fileSizeKB);
      console.log('PDF base64 start:', base64.substring(0, 100));
      
      if (fileSizeKB < 10) {
        toast.error(`PDF er for liten: ${fileSizeKB}KB - noe er galt!`);
        return;
      }
      
      // Convert base64 to Blob
      const byteCharacters = atob(base64);
      const byteNumbers = new Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      const byteArray = new Uint8Array(byteNumbers);
      const blob = new Blob([byteArray], { type: 'application/pdf' });
      
      // Trigger download instead of opening (bypasses browser blocking)
      const blobUrl = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = `TEST_Medlemsavtale_${data.navn || 'avtale'}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(blobUrl);
      
      toast.success(`PDF generert og lastet ned: ${fileSizeKB}KB - åpne filen for å verifisere innhold`);
    } catch (error) {
      console.error('Test PDF error:', error);
      toast.error('Kunne ikke generere test-PDF: ' + (error instanceof Error ? error.message : 'Ukjent feil'));
    }
  };
  
  const handleGenerateAgreement = async () => {
    if (!hovedkontakt) {
      toast.error('Ingen kontaktperson valgt');
      return;
    }
    
    setIsGenerating(true);
    try {
      const startdato = new Date().toLocaleDateString('nb-NO');
      
      // Generate PDF from HTML using jsPDF + html2canvas (without signatures - Firma.dev will add those)
      toast.info('Genererer PDF...');
      const pdfBase64 = await generatePdfBase64(false);
      
      // Get the draft ID from URL params
      const urlParams = new URLSearchParams(window.location.search);
      const innmeldingUtkastId = urlParams.get('draft');
      
      const { data: result, error } = await supabase.functions.invoke('firma-sign', {
        body: {
          action: 'create_agreement',
          pdfBase64, // Send the pre-generated PDF
          data: {
            salongnavn: data.navn,
            org_nummer: data.org_nummer,
            adresse: data.adresse,
            postnummer: data.postnummer,
            poststed: data.poststed,
            kontaktperson_navn: `${hovedkontakt.fornavn} ${hovedkontakt.etternavn}`,
            kontaktperson_epost: hovedkontakt.epost,
            telefon: hovedkontakt.telefon || data.telefon,
            type_medlemskap: data.type_medlemskap,
            startdato,
            medlemsavgift: data.medlemsavgift,
            innmeldingsavgift_rabatt: data.innmeldingsavgift_rabatt ?? 100,
            district_id: data.district_id,
            hubspot_owner_id: data.hubspot_owner_id,
            // Hår1 signerer info
            created_by_name: haar1Signerer || 'Hår1 Medlem',
            created_by_email: currentUser?.email || 'post@har1.no',
          },
          userId: currentUser?.id,
          innmeldingUtkastId,
        },
      });
      
      if (error) throw error;
      
      if (result.agreementId) {
        updateData({ 
          avtale_status: 'sendt',
          avtale_url: result.signingUrl,
        });
        
        setSigningUrl(result.signingUrl);
        
        toast.success('Avtale sendt til signering via Firma.dev');
        toast.info('Mottaker vil motta e-post med signeringslenke');
        
        // Invalidate cache to ensure fresh data
        if (innmeldingUtkastId) {
          queryClient.invalidateQueries({ queryKey: ['innmelding-draft', innmeldingUtkastId] });
          queryClient.invalidateQueries({ queryKey: ['innmelding-utkast'] });
        }
      } else {
        throw new Error(result.error || 'Ukjent feil');
      }
    } catch (error) {
      console.error('Agreement error:', error);
      toast.error('Kunne ikke sende avtale: ' + (error instanceof Error ? error.message : 'Ukjent feil'));
    } finally {
      setIsGenerating(false);
    }
  };
  
  // Check signing status from Firma.dev
  const checkSigningStatus = useCallback(async () => {
    if (!data.avtale_url || data.avtale_status === 'signert') return null;
    
    try {
      // Extract agreement ID - it's stored directly in avtale_url or as the last part
      const agreementId = data.avtale_url.includes('/')
        ? data.avtale_url.split('/').pop()
        : data.avtale_url;
      
      if (!agreementId) return null;
      
      const { data: result, error } = await supabase.functions.invoke('firma-sign', {
        body: {
          action: 'get_status',
          agreementId,
        },
      });
      
      if (error) throw error;
      
      // Firma.dev returns status as an object: { sent: boolean, finished: boolean, cancelled: boolean, expired: boolean }
      if (result?.status) {
        const status = result.status;
        
        if (status.finished === true) {
          return 'signert';
        } else if (status.cancelled === true) {
          return 'avvist';
        } else if (status.expired === true) {
          return 'utlopt';
        } else if (status.sent === true) {
          return 'sendt';
        }
      }
      
      return null;
    } catch (error) {
      console.error('Error checking signing status:', error);
      return null;
    }
  }, [data.avtale_url, data.avtale_status]);

  const handleRefreshStatus = async () => {
    if (!data.avtale_url) return;
    
    setIsRefreshing(true);
    try {
      const newStatus = await checkSigningStatus();
      
      if (newStatus && newStatus !== data.avtale_status) {
        updateData({ avtale_status: newStatus as InnmeldingData['avtale_status'] });
        
        // Invalidate caches to ensure parent component updates
        const urlParams = new URLSearchParams(window.location.search);
        const draftId = urlParams.get('draft');
        if (draftId) {
          queryClient.invalidateQueries({ queryKey: ['innmelding-draft', draftId] });
          queryClient.invalidateQueries({ queryKey: ['innmelding-utkast'] });
        }
        
        if (newStatus === 'signert') {
          toast.success('Avtalen er signert!');
        } else {
          toast.info(`Status oppdatert: ${newStatus}`);
        }
      } else {
        toast.info('Ingen endringer i status');
      }
    } catch (error) {
      toast.error('Kunne ikke sjekke status');
    } finally {
      setIsRefreshing(false);
    }
  };
  
  // Auto-poll for status updates when waiting for signature
  useEffect(() => {
    if (data.avtale_status !== 'sendt') return;
    
    const pollInterval = setInterval(async () => {
      const newStatus = await checkSigningStatus();
      
      if (newStatus && newStatus !== data.avtale_status) {
        updateData({ avtale_status: newStatus as InnmeldingData['avtale_status'] });
        
        // Invalidate caches
        const urlParams = new URLSearchParams(window.location.search);
        const draftId = urlParams.get('draft');
        if (draftId) {
          queryClient.invalidateQueries({ queryKey: ['innmelding-draft', draftId] });
          queryClient.invalidateQueries({ queryKey: ['innmelding-utkast'] });
        }
        
        if (newStatus === 'signert') {
          toast.success('Avtalen er signert!');
          clearInterval(pollInterval);
        }
      }
    }, 10000); // Poll every 10 seconds
    
    return () => clearInterval(pollInterval);
  }, [data.avtale_status, checkSigningStatus, updateData, queryClient]);
  
  const handleSendReminder = async () => {
    if (!data.avtale_url) {
      toast.error('Ingen aktiv avtale å sende påminnelse for');
      return;
    }
    
    setIsSending(true);
    try {
      // Extract agreement ID from URL or stored reference
      const agreementId = data.avtale_url.split('/').pop();
      
      const { error } = await supabase.functions.invoke('firma-sign', {
        body: {
          action: 'send_reminder',
          agreementId,
        },
      });
      
      if (error) throw error;
      toast.success('Påminnelse sendt via Firma.dev');
    } catch (error) {
      toast.error('Kunne ikke sende påminnelse');
    } finally {
      setIsSending(false);
    }
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.type !== 'application/pdf') {
        toast.error('Kun PDF-filer er støttet');
        return;
      }
      setUploadedFile(file);
    }
  };
  
  const handleUploadManual = async () => {
    if (!uploadedFile) return;
    
    setIsGenerating(true);
    try {
      // Upload to Supabase storage
      const fileName = `manual-agreements/${data.org_nummer}-${Date.now()}.pdf`;
      const { error: uploadError } = await supabase.storage
        .from('insurance-documents')
        .upload(fileName, uploadedFile);
      
      if (uploadError) throw uploadError;
      
      const { data: publicUrl } = supabase.storage
        .from('insurance-documents')
        .getPublicUrl(fileName);
      
      updateData({
        avtale_status: 'manuell',
        avtale_url: publicUrl.publicUrl,
      });
      
      toast.success('Avtale lastet opp');
    } catch (error) {
      toast.error('Kunne ikke laste opp avtale');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownloadPdf = () => {
    // Generate HTML with signatures included for manual signing
    const htmlContent = generatePdfHtml(true);
    
    // Wrap in full HTML document with print styles
    const printHtml = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <title>Medlemsavtale - ${data.navn}</title>
        <style>
          @page {
            size: A4;
            margin: 15mm;
          }
          @media print {
            body {
              -webkit-print-color-adjust: exact !important;
              print-color-adjust: exact !important;
            }
          }
        </style>
      </head>
      <body>
        ${htmlContent}
      </body>
      </html>
    `;
    
    // Open in new window for browser print
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printHtml);
      printWindow.document.close();
      
      // Trigger print dialog after content loads
      printWindow.onload = () => {
        printWindow.print();
      };
    } else {
      toast.error('Kunne ikke åpne print-vindu. Sjekk at popup-blokkering er deaktivert.');
    }
  };
  
  const getStatusBadge = () => {
    switch (data.avtale_status) {
      case 'sendt':
        return <Badge variant="secondary" className="gap-1"><Send className="h-3 w-3" />Venter på signering</Badge>;
      case 'signert':
        return <Badge variant="default" className="bg-green-600 gap-1"><Check className="h-3 w-3" />Signert</Badge>;
      case 'manuell':
        return <Badge variant="default" className="gap-1"><Check className="h-3 w-3" />Manuelt lastet opp</Badge>;
      default:
        return <Badge variant="outline">Ikke sendt</Badge>;
    }
  };
  
  return (
    <div className="space-y-6">
      {/* Status */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-medium">Avtalestatus</h3>
          <p className="text-sm text-muted-foreground">
            {data.navn} - Medlemsavtale
          </p>
        </div>
        <div className="flex items-center gap-2">
          {getStatusBadge()}
          {data.avtale_status === 'sendt' && (
            <Button 
              variant="ghost" 
              size="icon"
              onClick={handleRefreshStatus}
              disabled={isRefreshing}
            >
              <RefreshCw className={`h-4 w-4 ${isRefreshing ? 'animate-spin' : ''}`} />
            </Button>
          )}
        </div>
      </div>

      {/* Info about saving */}
      {data.avtale_status === 'sendt' && (
        <div className="p-4 bg-blue-50 dark:bg-blue-950/30 rounded-lg border border-blue-200 dark:border-blue-900">
          <p className="text-sm text-blue-700 dark:text-blue-400">
            💡 <strong>Tips:</strong> Du kan gå tilbake til <a href="/innmeldinger" className="underline">Innmeldinger-oversikten</a> og 
            fortsette senere når avtalen er signert. Status oppdateres automatisk.
          </p>
        </div>
      )}

      {/* Full Agreement preview */}
      {data.avtale_status === 'utkast' && hovedkontakt && (
        <Card className="border-primary/20">
          <CardHeader className="pb-3 bg-muted/30">
            <CardTitle className="text-lg flex items-center gap-2">
              <FileText className="h-5 w-5 text-primary" />
              Medlemsavtale - Forhåndsvisning
            </CardTitle>
            <CardDescription>
              Denne avtalen vil bli sendt til signering
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6 pt-6">
            {/* Logo */}
            <div className="text-center py-2">
              <img src="/haar1-logo-black.png" alt="Hår1 Logo" className="h-12 mx-auto" />
            </div>
            {/* Agreement Header */}
            <div className="text-center py-4 border-b">
              <h2 className="text-xl font-serif font-semibold">
                Samarbeidsavtale mellom {data.navn} og Hår1. Kjeden AS
              </h2>
            </div>
            <div className="space-y-4">
              <h4 className="font-semibold text-primary border-b pb-2">Avtaleparter</h4>
              <p className="text-sm text-muted-foreground">
                Avtale inngås mellom <strong>Hår1. Kjeden AS</strong> (org.nr: 987 658 738) og selskapet beskrevet nedenfor.
              </p>
              
              <div className="grid md:grid-cols-2 gap-4">
                {/* Hår1 Info */}
                <div className="p-4 bg-primary/5 rounded-lg border border-primary/20">
                  <div className="flex items-center gap-2 mb-3">
                    <Building2 className="h-4 w-4 text-primary" />
                    <span className="font-semibold text-primary">Hår1. Kjeden AS</span>
                  </div>
                  <div className="space-y-1 text-sm">
                    <p><span className="text-muted-foreground">Org.nr:</span> 987 658 738</p>
                    <p><span className="text-muted-foreground">Adresse:</span> Apotekergata 10 B</p>
                    <p><span className="text-muted-foreground">Postnr/Sted:</span> 0180 Oslo</p>
                  </div>
                </div>
                
                {/* Salon Info */}
                <div className="p-4 bg-muted/50 rounded-lg border">
                  <div className="flex items-center gap-2 mb-3">
                    <Building2 className="h-4 w-4" />
                    <span className="font-semibold">{data.navn}</span>
                  </div>
                  <div className="space-y-1 text-sm">
                    <p><span className="text-muted-foreground">Org.nr:</span> {data.org_nummer}</p>
                    <p><span className="text-muted-foreground">Adresse:</span> {data.adresse || '-'}</p>
                    <p><span className="text-muted-foreground">Postnr/Sted:</span> {data.postnummer} {data.poststed}</p>
                    <p><span className="text-muted-foreground">Kontaktperson:</span> {hovedkontakt.fornavn} {hovedkontakt.etternavn}</p>
                    <p><span className="text-muted-foreground">E-post:</span> {hovedkontakt.epost}</p>
                    <p><span className="text-muted-foreground">Telefon:</span> {hovedkontakt.telefon || data.telefon || '-'}</p>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Terms Section */}
            <div className="space-y-4">
              <h4 className="font-semibold text-primary border-b pb-2">Medlemsvilkår</h4>
              
              <div className="space-y-4 text-sm">
                <div className="p-3 bg-muted/20 rounded-lg">
                  <h5 className="font-semibold mb-2">§1 Hensikt og Målsetting</h5>
                  <p className="text-muted-foreground">Hår1 har som mål å bistå med et helhetlig konsept for frisørsalonger og salongeiere i Norge for å øke lønnsomheten gjennom utvidet samarbeid basert på faglig utvikling, service- og salgsutvikling, og driftsstøtte.</p>
                </div>
                
                <div className="p-3 bg-muted/20 rounded-lg">
                  <h5 className="font-semibold mb-2">§2 Hår1s Forpliktelser</h5>
                  <p className="text-muted-foreground mb-2">Som din driftspartner, garanterer Hår1:</p>
                  <ul className="text-muted-foreground space-y-1 ml-4 list-disc">
                    <li><strong>Ubetinget Tilgjengelighet:</strong> Responsgaranti innen 24 timer</li>
                    <li><strong>Faglig og Personlig Utvikling:</strong> Skreddersydde opplæringsprogrammer</li>
                    <li><strong>Strategiske Partnerskap:</strong> Tilgang til markedets beste priser</li>
                    <li><strong>Effektiv Drift:</strong> Deling av nøkkeltall og beste praksiser</li>
                    <li><strong>Markedsføringsstøtte:</strong> Unike markedsføringskampanjer</li>
                    <li><strong>Personalforvaltning og HR:</strong> Rådgivning og støtteverktøy</li>
                  </ul>
                </div>
                
                <div className="p-3 bg-muted/20 rounded-lg">
                  <h5 className="font-semibold mb-2">§3 Bonusprogram for Vekst og Lojalitet</h5>
                  <p className="text-muted-foreground">Lojalitetsbonus utbetalt i mars året etter, basert på faktisk varekjøp opp til 5%. Vekst i varekjøp fra utvalgte partnere gir mulighet for bonus på inntil 10%.</p>
                </div>
                
                <div className="p-3 bg-muted/20 rounded-lg">
                  <h5 className="font-semibold mb-2">§4 Overdragelse av Medlemskap</h5>
                  <p className="text-muted-foreground">Rettigheter og forpliktelser som medlem følger virksomheten, selv ved endringer i eierskap.</p>
                </div>
                
                <div className="p-3 bg-muted/20 rounded-lg">
                  <h5 className="font-semibold mb-2">§5 Personvern og GDPR</h5>
                  <p className="text-muted-foreground">Hår1 behandler personopplysninger i samsvar med GDPR. Kontaktopplysninger kan deles med utvalgte samarbeidspartnere for å opprette brukerprofiler og gi tilgang til tjenester.</p>
                </div>
                
                <div className="p-3 bg-muted/20 rounded-lg">
                  <h5 className="font-semibold mb-2">§6 Avtalens Varighet og Oppsigelse</h5>
                  <p className="text-muted-foreground">12 måneders prøveperiode. Automatisk fornyelse med mindre oppsigelse med 6 måneders varsel før utløp.</p>
                </div>
              </div>
            </div>
            
            {/* Fees Section */}
            <div className="space-y-4">
              <h4 className="font-semibold text-primary border-b pb-2">Avgifter</h4>
              
              <div className="grid md:grid-cols-2 gap-4">
                <div className="p-4 bg-green-50 dark:bg-green-950/30 rounded-lg border border-green-200 dark:border-green-800">
                  <h5 className="font-semibold mb-2">Innmeldingsavgift</h5>
                  <p className="text-sm text-muted-foreground mb-2">
                    Ved innmelding skal medlemmet betale kr 5.000 avgift, eks. mva.
                  </p>
                  <p className="text-sm">
                    {(data.innmeldingsavgift_rabatt ?? 100) > 0 && (
                      <span className="line-through text-muted-foreground">NOK 5 000,00</span>
                    )}
                    {(data.innmeldingsavgift_rabatt ?? 100) > 0 ? (
                      <span className="ml-2 text-green-600 font-semibold">
                        {data.innmeldingsavgift_rabatt}% rabatt → NOK {(5000 * (1 - (data.innmeldingsavgift_rabatt ?? 100) / 100)).toLocaleString('nb-NO')}
                      </span>
                    ) : (
                      <span className="font-semibold">NOK 5 000,00</span>
                    )}
                  </p>
                </div>
                
                <div className="p-4 bg-primary/5 rounded-lg border border-primary/20">
                  <h5 className="font-semibold mb-2">Månedlig medlemsavgift</h5>
                  <p className="text-sm text-muted-foreground mb-2">
                    1% av salongens totale omsetning ekskl. mva, minimum:
                  </p>
                  <p className="text-lg font-bold text-primary">
                    NOK {data.medlemsavgift?.toLocaleString('nb-NO') || '0'},- / måned
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
      
      <Tabs defaultValue="digital" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="digital">Digital signering</TabsTrigger>
          <TabsTrigger value="manual">Manuell opplasting</TabsTrigger>
        </TabsList>
        
        <TabsContent value="digital" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Digital signering
              </CardTitle>
              <CardDescription>
                Send avtale for digital signering via Firma.dev
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {data.avtale_status === 'utkast' && (
                <div className="space-y-4">
                  {/* TEST BUTTON - for verifying PDF generation before sending */}
                  <Button 
                    variant="secondary"
                    onClick={handleTestPdf}
                    className="w-full"
                  >
                    <TestTube className="h-4 w-4 mr-2" />
                    Test PDF (verifiser før sending)
                  </Button>
                  
                  <Button 
                    onClick={handleGenerateAgreement}
                    disabled={isGenerating || !hovedkontakt}
                    className="w-full"
                  >
                    {isGenerating ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Sender til signering...
                      </>
                    ) : (
                      <>
                        <Send className="h-4 w-4 mr-2" />
                        Send til signering
                      </>
                    )}
                  </Button>
                  
                  <Button 
                    variant="outline"
                    onClick={handleDownloadPdf}
                    className="w-full"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Last ned PDF for manuell signering
                  </Button>
                </div>
              )}
              
              {data.avtale_status === 'sendt' && (
                <div className="space-y-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="text-sm">
                      Avtale sendt til <strong>{hovedkontakt?.epost}</strong>. Venter på signering.
                    </p>
                    {data.avtale_url && (
                      <a 
                        href={data.avtale_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-sm text-primary flex items-center gap-1 mt-2"
                      >
                        Se avtale i Firma.dev
                        <ExternalLink className="h-3 w-3" />
                      </a>
                    )}
                  </div>
                  
                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      onClick={handleSendReminder}
                      disabled={isSending}
                    >
                      {isSending ? (
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      ) : (
                        <Send className="h-4 w-4 mr-2" />
                      )}
                      Send påminnelse
                    </Button>
                    
                    <Button 
                      variant="outline"
                      onClick={() => updateData({ avtale_status: 'signert' })}
                    >
                      <Check className="h-4 w-4 mr-2" />
                      Merk som signert
                    </Button>
                  </div>
                </div>
              )}
              
              {data.avtale_status === 'signert' && (
                <div className="p-4 bg-green-50 dark:bg-green-950/30 rounded-lg border border-green-200 dark:border-green-900">
                  <div className="flex items-center gap-2 text-green-700 dark:text-green-400">
                    <Check className="h-5 w-5" />
                    <span className="font-medium">Avtale signert</span>
                  </div>
                  {data.avtale_url && (
                    <a 
                      href={data.avtale_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm text-primary flex items-center gap-1 mt-2"
                    >
                      Last ned signert avtale
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="manual" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Upload className="h-5 w-5" />
                Manuell opplasting
              </CardTitle>
              <CardDescription>
                Last opp en signert avtale manuelt (PDF)
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {data.avtale_status !== 'manuell' ? (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="avtale-fil">Velg fil</Label>
                    <Input
                      id="avtale-fil"
                      type="file"
                      accept=".pdf"
                      onChange={handleFileChange}
                    />
                    <p className="text-xs text-muted-foreground">
                      Kun PDF-filer er støttet
                    </p>
                  </div>
                  
                  {uploadedFile && (
                    <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
                      <div className="flex items-center gap-2">
                        <FileText className="h-4 w-4" />
                        <span className="text-sm">{uploadedFile.name}</span>
                      </div>
                      <Button
                        size="sm"
                        onClick={handleUploadManual}
                        disabled={isGenerating}
                      >
                        {isGenerating ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          'Last opp'
                        )}
                      </Button>
                    </div>
                  )}
                </>
              ) : (
                <div className="p-4 bg-green-50 dark:bg-green-950/30 rounded-lg border border-green-200 dark:border-green-900">
                  <div className="flex items-center gap-2 text-green-700 dark:text-green-400">
                    <Check className="h-5 w-5" />
                    <span className="font-medium">Avtale lastet opp</span>
                  </div>
                  {data.avtale_url && (
                    <a 
                      href={data.avtale_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm text-primary flex items-center gap-1 mt-2"
                    >
                      Se opplastet avtale
                      <ExternalLink className="h-3 w-3" />
                    </a>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}