import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { InnmeldingData, LeverandorValg, MerkeValg } from '@/pages/InnmeldingWizard';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { ChevronDown, ChevronRight, Search, Package, FlaskConical, ShoppingBag } from 'lucide-react';

interface Props {
  data: InnmeldingData;
  updateData: (updates: Partial<InnmeldingData>) => void;
}

interface Leverandor {
  id: string;
  navn: string;
}

interface Merke {
  id: string;
  leverandor_id: string;
  navn: string;
  har_kjemi: boolean;
  har_produkter: boolean;
}

export default function InnmeldingSteg4({ data, updateData }: Props) {
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedLeverandorer, setExpandedLeverandorer] = useState<Set<string>>(new Set());
  
  const { data: leverandorer = [] } = useQuery({
    queryKey: ['leverandorer'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('leverandorer')
        .select('*')
        .eq('aktiv', true)
        .order('navn');
      if (error) throw error;
      return data as Leverandor[];
    },
  });
  
  const { data: merker = [] } = useQuery({
    queryKey: ['leverandor-merker'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('leverandor_merker')
        .select('*')
        .eq('aktiv', true)
        .order('navn');
      if (error) throw error;
      return data as Merke[];
    },
  });
  
  const toggleExpanded = (id: string) => {
    const newSet = new Set(expandedLeverandorer);
    if (newSet.has(id)) {
      newSet.delete(id);
    } else {
      newSet.add(id);
    }
    setExpandedLeverandorer(newSet);
  };
  
  const getLeverandorValg = (leverandorId: string): LeverandorValg | undefined => {
    return data.leverandorer.find(l => l.leverandor_id === leverandorId);
  };
  
  const getMerkeValg = (leverandorId: string, merkeId: string): MerkeValg | undefined => {
    const lev = getLeverandorValg(leverandorId);
    return lev?.valgte_merker.find(m => m.merke_id === merkeId);
  };
  
  const toggleMerke = (leverandorId: string, leverandorNavn: string, merke: Merke) => {
    const existingLev = getLeverandorValg(leverandorId);
    const existingMerke = getMerkeValg(leverandorId, merke.id);
    
    let newLeverandorer = [...data.leverandorer];
    
    if (existingMerke) {
      // Remove merke
      const levIndex = newLeverandorer.findIndex(l => l.leverandor_id === leverandorId);
      if (levIndex >= 0) {
        const newMerker = newLeverandorer[levIndex].valgte_merker.filter(m => m.merke_id !== merke.id);
        if (newMerker.length === 0) {
          // Remove leverandør if no merker left
          newLeverandorer.splice(levIndex, 1);
        } else {
          newLeverandorer[levIndex] = { ...newLeverandorer[levIndex], valgte_merker: newMerker };
        }
      }
    } else {
      // Add merke
      const newMerkeValg: MerkeValg = {
        merke_id: merke.id,
        merke_navn: merke.navn,
      };
      
      if (existingLev) {
        const levIndex = newLeverandorer.findIndex(l => l.leverandor_id === leverandorId);
        newLeverandorer[levIndex] = {
          ...newLeverandorer[levIndex],
          valgte_merker: [...newLeverandorer[levIndex].valgte_merker, newMerkeValg],
        };
      } else {
        newLeverandorer.push({
          leverandor_id: leverandorId,
          leverandor_navn: leverandorNavn,
          valgte_merker: [newMerkeValg],
        });
      }
    }
    
    updateData({ leverandorer: newLeverandorer });
  };
  
  const filteredLeverandorer = leverandorer.filter(l => 
    l.navn.toLowerCase().includes(searchQuery.toLowerCase()) ||
    merker.some(m => m.leverandor_id === l.id && m.navn.toLowerCase().includes(searchQuery.toLowerCase()))
  );
  
  const getMerkerForLeverandor = (leverandorId: string) => {
    return merker.filter(m => m.leverandor_id === leverandorId);
  };
  
  const totalMerkeCount = data.leverandorer.reduce((sum, l) => sum + l.valgte_merker.length, 0);
  
  return (
    <div className="space-y-6">
      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Søk etter leverandør eller merke..."
          className="pl-10"
        />
      </div>
      
      {/* Summary */}
      {totalMerkeCount > 0 && (
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="gap-1">
            <Package className="h-3 w-3" />
            {totalMerkeCount} merke{totalMerkeCount !== 1 ? 'r' : ''} valgt
          </Badge>
        </div>
      )}
      
      {/* Leverandører */}
      <div className="space-y-3">
        {filteredLeverandorer.map((leverandor) => {
          const valg = getLeverandorValg(leverandor.id);
          const leverandorMerker = getMerkerForLeverandor(leverandor.id);
          const isExpanded = expandedLeverandorer.has(leverandor.id);
          const hasSelection = valg && valg.valgte_merker.length > 0;
          
          return (
            <Card key={leverandor.id} className={hasSelection ? 'ring-1 ring-primary/50' : ''}>
              <Collapsible open={isExpanded} onOpenChange={() => toggleExpanded(leverandor.id)}>
                <CollapsibleTrigger asChild>
                  <CardHeader className="cursor-pointer hover:bg-muted/50 transition-colors py-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        {isExpanded ? (
                          <ChevronDown className="h-4 w-4 text-muted-foreground" />
                        ) : (
                          <ChevronRight className="h-4 w-4 text-muted-foreground" />
                        )}
                        <CardTitle className="text-base">{leverandor.navn}</CardTitle>
                        {hasSelection && (
                          <Badge variant="secondary" className="text-xs">
                            {valg.valgte_merker.length} merke{valg.valgte_merker.length !== 1 ? 'r' : ''}
                          </Badge>
                        )}
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {leverandorMerker.length} merker
                      </span>
                    </div>
                  </CardHeader>
                </CollapsibleTrigger>
                
                <CollapsibleContent>
                  <CardContent className="pt-0 space-y-2">
                    {leverandorMerker.length > 0 ? (
                      <div className="space-y-2">
                        {leverandorMerker.map((merke) => {
                          const isSelected = !!getMerkeValg(leverandor.id, merke.id);
                          
                          return (
                            <div 
                              key={merke.id} 
                              className={`flex items-center justify-between rounded-lg border p-3 transition-colors cursor-pointer ${
                                isSelected ? 'bg-primary/5 border-primary/30' : 'bg-muted/30 hover:bg-muted/50'
                              }`}
                              onClick={() => toggleMerke(leverandor.id, leverandor.navn, merke)}
                            >
                              <div className="flex items-center gap-3">
                                <Checkbox
                                  checked={isSelected}
                                  onCheckedChange={() => toggleMerke(leverandor.id, leverandor.navn, merke)}
                                  onClick={(e) => e.stopPropagation()}
                                />
                                <Label className="font-medium cursor-pointer">
                                  {merke.navn}
                                </Label>
                              </div>
                              <div className="flex gap-1.5">
                                {merke.har_kjemi && (
                                  <Badge variant="secondary" className="text-xs gap-1">
                                    <FlaskConical className="h-3 w-3" />
                                    Kjemi
                                  </Badge>
                                )}
                                {merke.har_produkter && (
                                  <Badge variant="outline" className="text-xs gap-1">
                                    <ShoppingBag className="h-3 w-3" />
                                    Videre salg
                                  </Badge>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    ) : (
                      <p className="text-sm text-muted-foreground text-center py-4">
                        Ingen merker registrert for denne leverandøren
                      </p>
                    )}
                  </CardContent>
                </CollapsibleContent>
              </Collapsible>
            </Card>
          );
        })}
      </div>
      
      {filteredLeverandorer.length === 0 && (
        <p className="text-center text-muted-foreground py-8">
          Ingen leverandører funnet
        </p>
      )}
    </div>
  );
}
