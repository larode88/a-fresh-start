import { useState } from 'react';
import { InnmeldingData } from '@/pages/InnmeldingWizard';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Loader2, Search, Building2, MapPin, Users, Calendar, TrendingUp, TrendingDown, Phone, Mail } from 'lucide-react';
import { lookupOrgNumber, lookupFinancials, formatCurrency } from '@/lib/brreg';
import { toast } from 'sonner';

interface Props {
  data: InnmeldingData;
  updateData: (updates: Partial<InnmeldingData>) => void;
}

export default function InnmeldingSteg1({ data, updateData }: Props) {
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingFinancials, setIsLoadingFinancials] = useState(false);
  const [orgInput, setOrgInput] = useState(data.org_nummer || '');
  
  const formatOrgNumber = (value: string) => {
    const digits = value.replace(/\D/g, '').slice(0, 9);
    if (digits.length <= 3) return digits;
    if (digits.length <= 6) return `${digits.slice(0, 3)} ${digits.slice(3)}`;
    return `${digits.slice(0, 3)} ${digits.slice(3, 6)} ${digits.slice(6)}`;
  };
  
  const handleOrgInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatOrgNumber(e.target.value);
    setOrgInput(formatted);
  };
  
  const handleLookup = async () => {
    const cleanedOrg = orgInput.replace(/\s/g, '');
    if (cleanedOrg.length !== 9) {
      toast.error('Org.nummer må være 9 siffer');
      return;
    }
    
    setIsLoading(true);
    try {
      const result = await lookupOrgNumber(cleanedOrg);
      
      // Parse postnummer and poststed - BRREG sometimes returns combined
      let postnummer = result.adresse?.postnummer || '';
      let poststed = result.adresse?.poststed || '';
      
      // If postnummer is empty but poststed contains it (e.g., "4625 FLEKKERØY")
      if (!postnummer && poststed.match(/^\d{4}\s/)) {
        const match = poststed.match(/^(\d{4})\s+(.+)$/);
        if (match) {
          postnummer = match[1];
          poststed = match[2];
        }
      }
      // Also handle if postnummer contains both (e.g., "4625 FLEKKERØY" in postnummer field)
      else if (postnummer.match(/^\d{4}\s/)) {
        const match = postnummer.match(/^(\d{4})\s+(.+)$/);
        if (match) {
          postnummer = match[1];
          poststed = poststed || match[2];
        }
      }
      
      updateData({
        org_nummer: result.organisasjonsnummer,
        navn: result.juridiskNavn,
        adresse: result.adresse?.gate || '',
        postnummer,
        poststed,
        stiftelsesdato: result.stiftelsesdato,
        antall_ansatte: result.antallAnsatte,
      });
      
      toast.success('Bedriftsinfo hentet fra BRREG');
      
      // Fetch financials in background
      setIsLoadingFinancials(true);
      const financials = await lookupFinancials(cleanedOrg);
      if (financials) {
        updateData({
          sum_driftsinntekter: financials.sumDriftsinntekter,
          driftsresultat: financials.driftsresultat,
          regnskapsaar: financials.regnskapsaar,
        });
      }
      setIsLoadingFinancials(false);
      
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Kunne ikke hente bedriftsinfo');
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleLookup();
    }
  };
  
  return (
    <div className="space-y-6">
      {/* BRREG Lookup */}
      <div className="space-y-2">
        <Label htmlFor="org_nummer">Organisasjonsnummer</Label>
        <div className="flex gap-2">
          <Input
            id="org_nummer"
            value={orgInput}
            onChange={handleOrgInputChange}
            onKeyDown={handleKeyDown}
            placeholder="123 456 789"
            className="font-mono"
          />
          <Button onClick={handleLookup} disabled={isLoading}>
            {isLoading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <>
                <Search className="h-4 w-4 mr-2" />
                Søk
              </>
            )}
          </Button>
        </div>
        <p className="text-xs text-muted-foreground">
          Skriv inn org.nummer for å hente bedriftsinfo automatisk fra Brønnøysundregistrene
        </p>
      </div>
      
      {/* Results */}
      {data.navn && (
        <div className="space-y-4">
          {/* Company Info Card */}
          <Card className="bg-muted/30">
            <CardContent className="pt-6">
              <div className="flex items-start gap-4">
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Building2 className="h-6 w-6 text-primary" />
                </div>
                <div className="flex-1 space-y-1">
                  <h3 className="text-lg font-medium">{data.navn}</h3>
                  <p className="text-sm text-muted-foreground font-mono">
                    Org.nr: {data.org_nummer}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Details Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Address */}
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-muted-foreground" />
                Adresse
              </Label>
              <Input
                value={data.adresse}
                onChange={(e) => updateData({ adresse: e.target.value })}
                placeholder="Gateadresse"
              />
              <div className="grid grid-cols-2 gap-2">
                <Input
                  value={data.postnummer}
                  onChange={(e) => updateData({ postnummer: e.target.value })}
                  placeholder="Postnr"
                />
                <Input
                  value={data.poststed}
                  onChange={(e) => updateData({ poststed: e.target.value })}
                  placeholder="Sted"
                />
              </div>
            </div>
            
            {/* Company Details */}
            <div className="space-y-4">
              {data.stiftelsesdato && (
                <div className="flex items-center gap-3">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Stiftet</p>
                    <p className="font-medium">
                      {new Date(data.stiftelsesdato).toLocaleDateString('nb-NO')}
                    </p>
                  </div>
                </div>
              )}
              
              {data.antall_ansatte !== undefined && (
                <div className="flex items-center gap-3">
                  <Users className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Antall ansatte</p>
                    <p className="font-medium">{data.antall_ansatte}</p>
                  </div>
                </div>
              )}
            </div>
          </div>
          
          {/* Contact Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="telefon" className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-muted-foreground" />
                Telefon bedrift
              </Label>
              <Input
                id="telefon"
                value={data.telefon || ''}
                onChange={(e) => updateData({ telefon: e.target.value })}
                placeholder="+47 XXX XX XXX"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="epost" className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-muted-foreground" />
                E-post bedrift
              </Label>
              <Input
                id="epost"
                type="email"
                value={data.epost || ''}
                onChange={(e) => updateData({ epost: e.target.value })}
                placeholder="post@salong.no"
              />
            </div>
          </div>
          
          {/* Financials */}
          {isLoadingFinancials ? (
            <div className="flex items-center gap-2 text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" />
              <span className="text-sm">Henter regnskapsdata...</span>
            </div>
          ) : data.regnskapsaar ? (
            <Card className="bg-muted/30">
              <CardContent className="pt-4">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm font-medium">Regnskapsdata</span>
                  <Badge variant="secondary">{data.regnskapsaar}</Badge>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <p className="text-xs text-muted-foreground">Omsetning</p>
                      <p className="font-medium">{formatCurrency(data.sum_driftsinntekter)}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {(data.driftsresultat ?? 0) >= 0 ? (
                      <TrendingUp className="h-4 w-4 text-green-600" />
                    ) : (
                      <TrendingDown className="h-4 w-4 text-red-600" />
                    )}
                    <div>
                      <p className="text-xs text-muted-foreground">Driftsresultat</p>
                      <p className={`font-medium ${(data.driftsresultat ?? 0) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        {formatCurrency(data.driftsresultat)}
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ) : null}
        </div>
      )}
    </div>
  );
}
