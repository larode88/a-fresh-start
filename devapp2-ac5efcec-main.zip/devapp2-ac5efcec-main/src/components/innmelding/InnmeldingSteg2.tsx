import { useState } from 'react';
import { InnmeldingData, KontaktpersonData } from '@/pages/InnmeldingWizard';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Plus, Trash2, User, Mail, Phone, Star, Pencil } from 'lucide-react';

interface Props {
  data: InnmeldingData;
  updateData: (updates: Partial<InnmeldingData>) => void;
}

const TITLER = [
  'Daglig leder',
  'Eier',
  'Avdelingsleder',
  'Styreleder',
  'Regnskapsfører',
  'Markedsansvarlig',
  'Annet',
];

export default function InnmeldingSteg2({ data, updateData }: Props) {
  const [showForm, setShowForm] = useState(data.kontaktpersoner.length === 0);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [formData, setFormData] = useState<KontaktpersonData>({
    fornavn: '',
    etternavn: '',
    epost: '',
    telefon: '',
    tittel: '',
    er_hovedkontakt: data.kontaktpersoner.length === 0,
  });
  
  const resetForm = () => {
    setFormData({
      fornavn: '',
      etternavn: '',
      epost: '',
      telefon: '',
      tittel: '',
      er_hovedkontakt: data.kontaktpersoner.length === 0,
    });
    setEditingIndex(null);
    setShowForm(false);
  };
  
  const handleSave = () => {
    if (!formData.fornavn || !formData.etternavn || !formData.epost || !formData.tittel) return;
    
    const newKontaktpersoner = [...data.kontaktpersoner];
    
    // If setting as hovedkontakt, remove from others
    if (formData.er_hovedkontakt) {
      newKontaktpersoner.forEach(k => k.er_hovedkontakt = false);
    }
    
    if (editingIndex !== null) {
      newKontaktpersoner[editingIndex] = formData;
    } else {
      newKontaktpersoner.push(formData);
    }
    
    updateData({ kontaktpersoner: newKontaktpersoner });
    resetForm();
  };
  
  const handleEdit = (index: number) => {
    setFormData(data.kontaktpersoner[index]);
    setEditingIndex(index);
    setShowForm(true);
  };
  
  const handleDelete = (index: number) => {
    const newKontaktpersoner = data.kontaktpersoner.filter((_, i) => i !== index);
    updateData({ kontaktpersoner: newKontaktpersoner });
  };
  
  const handleSetHovedkontakt = (index: number) => {
    const newKontaktpersoner = data.kontaktpersoner.map((k, i) => ({
      ...k,
      er_hovedkontakt: i === index,
    }));
    updateData({ kontaktpersoner: newKontaktpersoner });
  };

  const getFullName = (kontakt: KontaktpersonData) => {
    return `${kontakt.fornavn} ${kontakt.etternavn}`.trim();
  };
  
  return (
    <div className="space-y-6">
      {/* Existing contacts */}
      {data.kontaktpersoner.length > 0 && (
        <div className="space-y-3">
          {data.kontaktpersoner.map((kontakt, index) => (
            <Card key={index} className={kontakt.er_hovedkontakt ? 'ring-2 ring-primary' : ''}>
              <CardContent className="pt-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3">
                    <div className="h-10 w-10 rounded-full bg-muted flex items-center justify-center">
                      <User className="h-5 w-5 text-muted-foreground" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{getFullName(kontakt)}</span>
                        {kontakt.er_hovedkontakt && (
                          <Badge variant="default" className="text-xs">
                            <Star className="h-3 w-3 mr-1" />
                            Hovedkontakt
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">{kontakt.tittel}</p>
                      <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Mail className="h-3 w-3" />
                          {kontakt.epost}
                        </span>
                        {kontakt.telefon && (
                          <span className="flex items-center gap-1">
                            <Phone className="h-3 w-3" />
                            {kontakt.telefon}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {!kontakt.er_hovedkontakt && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleSetHovedkontakt(index)}
                      >
                        Sett som hovedkontakt
                      </Button>
                    )}
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleEdit(index)}
                    >
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleDelete(index)}
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
      
      {/* Add/Edit Form */}
      {showForm ? (
        <Card className="bg-muted/30">
          <CardContent className="pt-6 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="kontakt-fornavn">Fornavn *</Label>
                <Input
                  id="kontakt-fornavn"
                  value={formData.fornavn}
                  onChange={(e) => setFormData({ ...formData, fornavn: e.target.value })}
                  placeholder="Ola"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="kontakt-etternavn">Etternavn *</Label>
                <Input
                  id="kontakt-etternavn"
                  value={formData.etternavn}
                  onChange={(e) => setFormData({ ...formData, etternavn: e.target.value })}
                  placeholder="Nordmann"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="kontakt-tittel">Stilling *</Label>
                <Select
                  value={formData.tittel}
                  onValueChange={(value) => setFormData({ ...formData, tittel: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Velg stilling" />
                  </SelectTrigger>
                  <SelectContent>
                    {TITLER.map((tittel) => (
                      <SelectItem key={tittel} value={tittel}>
                        {tittel}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="kontakt-epost">E-post *</Label>
                <Input
                  id="kontakt-epost"
                  type="email"
                  value={formData.epost}
                  onChange={(e) => setFormData({ ...formData, epost: e.target.value })}
                  placeholder="ola@salong.no"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="kontakt-telefon">Telefon</Label>
                <Input
                  id="kontakt-telefon"
                  value={formData.telefon}
                  onChange={(e) => setFormData({ ...formData, telefon: e.target.value })}
                  placeholder="123 45 678"
                />
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <Checkbox
                id="hovedkontakt"
                checked={formData.er_hovedkontakt}
                onCheckedChange={(checked) => 
                  setFormData({ ...formData, er_hovedkontakt: checked === true })
                }
              />
              <Label htmlFor="hovedkontakt" className="text-sm">
                Sett som hovedkontakt
              </Label>
            </div>
            
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={resetForm}>
                Avbryt
              </Button>
              <Button 
                onClick={handleSave}
                disabled={!formData.fornavn || !formData.etternavn || !formData.epost || !formData.tittel}
              >
                {editingIndex !== null ? 'Oppdater' : 'Legg til'}
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Button variant="outline" onClick={() => setShowForm(true)} className="w-full">
          <Plus className="h-4 w-4 mr-2" />
          Legg til kontaktperson
        </Button>
      )}
      
      {/* Validation message */}
      {data.kontaktpersoner.length > 0 && !data.kontaktpersoner.some(k => k.er_hovedkontakt) && (
        <p className="text-sm text-amber-600">
          Velg en hovedkontakt for å fortsette
        </p>
      )}
    </div>
  );
}
