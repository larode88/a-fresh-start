import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { InnmeldingData } from '@/pages/InnmeldingWizard';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Building2, MapPin, Users, CreditCard, Package, FileText, 
  ClipboardList, Check, Loader2, AlertCircle, Star, Phone, Mail,
  MapPinned, Copy, Info, CheckCircle2, XCircle
} from 'lucide-react';
import { toast } from 'sonner';

// Helper to map title to role
const mapTittelToRole = (tittel: string): string => {
  const mapping: Record<string, string> = {
    'Daglig leder': 'daglig_leder',
    'Eier': 'salon_owner',
    'Avdelingsleder': 'avdelingsleder',
    'Styreleder': 'styreleder',
    'Regnskapsfører': 'stylist',
    'Markedsansvarlig': 'stylist',
    'Annet': 'stylist',
  };
  return mapping[tittel] || 'stylist';
};

interface Props {
  data: InnmeldingData;
  updateData: (updates: Partial<InnmeldingData>) => void;
  onComplete: () => void;
}

interface CreationStatus {
  salon: 'pending' | 'success' | 'error';
  hubspot: 'pending' | 'success' | 'error' | 'skipped';
  invitations: 'pending' | 'success' | 'error';
  leverandorer: 'pending' | 'success' | 'error' | 'skipped';
}

export default function InnmeldingSteg7({ data, updateData, onComplete }: Props) {
  const [isCreating, setIsCreating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [emailEnabled, setEmailEnabled] = useState(true);
  const [status, setStatus] = useState<CreationStatus>({
    salon: 'pending',
    hubspot: 'pending',
    invitations: 'pending',
    leverandorer: 'pending',
  });
  const [invitationLinks, setInvitationLinks] = useState<Array<{ navn: string; url: string }>>([]);

  // Check if email is enabled
  useEffect(() => {
    const checkEmailSetting = async () => {
      const { data: setting } = await supabase
        .from('system_settings')
        .select('value')
        .eq('key', 'email_enabled')
        .single();
      
      if (setting) {
        setEmailEnabled(setting.value === 'true');
      }
    };
    checkEmailSetting();
  }, []);
  
  const handleCreate = async () => {
    setIsCreating(true);
    setError(null);
    setInvitationLinks([]);
    
    try {
      // 0. Check if salon with this org_number already exists
      const { data: existingSalon } = await supabase
        .from('salons')
        .select('id, name')
        .eq('org_number', data.org_nummer)
        .maybeSingle();
      
      if (existingSalon) {
        setError(`En salong med org.nr ${data.org_nummer} er allerede registrert: "${existingSalon.name}"`);
        toast.error('Duplikat org.nummer', {
          description: `Salongen "${existingSalon.name}" har allerede dette organisasjonsnummeret.`,
        });
        setIsCreating(false);
        return;
      }
      
      // 1. Create salon
      console.log('Creating salon with data:', {
        name: data.navn,
        org_number: data.org_nummer,
        postal_code: data.postnummer,
        city: data.poststed,
        district_id: data.district_id,
      });

      const { data: salon, error: salonError } = await supabase
        .from('salons')
        .insert({
          name: data.navn,
          org_number: data.org_nummer,
          address: data.adresse,
          postal_code: data.postnummer,
          city: data.poststed,
          phone: data.telefon || null,
          type_medlemskap: data.type_medlemskap as any,
          medlemsavgift: data.medlemsavgift,
          bankkontonummer: data.bankkontonummer,
          lifecyclestage: 'medlem',
          medlemsstatus: 'aktiv',
          start_medlemskap_dato: new Date().toISOString().split('T')[0],
          hubspot_owner_id: data.hubspot_owner_id || null,
          district_id: data.district_id,
        })
        .select()
        .single();
      
      if (salonError) {
        console.error('Salon creation error:', salonError);
        setStatus(prev => ({ ...prev, salon: 'error' }));
        throw salonError;
      }

      console.log('Salon created:', salon);
      setStatus(prev => ({ ...prev, salon: 'success' }));
      
      // 2. Create company in HubSpot and link
      let hubspotCompanyId: string | null = null;
      try {
        // Build HubSpot properties - only include valid HubSpot company properties
        // Capitalize type_medlemskap for HubSpot (DB stores lowercase, HubSpot expects capitalized)
        const capitalizedTypeMedlemskap = data.type_medlemskap
          ? data.type_medlemskap.charAt(0).toUpperCase() + data.type_medlemskap.slice(1)
          : '';
        
        const hubspotProperties: Record<string, string> = {
          name: data.navn,
          orgnr: data.org_nummer,
          address: data.adresse,
          zip: data.postnummer,
          city: data.poststed,
          type_medlemskap: capitalizedTypeMedlemskap,
          medlmestype: 'Medlem',
          lifecyclestage: 'customer',
        };

        // Add optional fields
        if (data.telefon) hubspotProperties.phone = data.telefon;
        if (data.medlemsavgift) hubspotProperties.medlemsavgift = data.medlemsavgift.toString();
        if (data.bankkontonummer) hubspotProperties.bankkontonummer = data.bankkontonummer.replace(/\s/g, '');

        console.log('Creating HubSpot company with properties:', hubspotProperties);

        const { data: hsResult, error: hsError } = await supabase.functions.invoke('hubspot-api', {
          body: {
            action: 'create_company',
            properties: hubspotProperties,
            hubspot_owner_id: data.hubspot_owner_id,
          },
        });

        if (hsError) {
          console.error('HubSpot API error:', hsError);
          setStatus(prev => ({ ...prev, hubspot: 'error' }));
        } else if (hsResult?.id) {
          hubspotCompanyId = hsResult.id;
          // Update salon with HubSpot company ID
          await supabase
            .from('salons')
            .update({
              hs_object_id: hsResult.id,
              hubspot_synced_at: new Date().toISOString(),
            })
            .eq('id', salon.id);
          
          console.log('HubSpot company created:', hsResult.id);
          setStatus(prev => ({ ...prev, hubspot: 'success' }));
        } else {
          console.warn('HubSpot response missing id:', hsResult);
          setStatus(prev => ({ ...prev, hubspot: 'error' }));
        }
      } catch (hubspotErr) {
        console.error('HubSpot sync failed (non-critical):', hubspotErr);
        setStatus(prev => ({ ...prev, hubspot: 'error' }));
        // Not a critical failure - salon is created locally
      }
      
      // 3. Create invitations for contact persons and sync to HubSpot
      const createdLinks: Array<{ navn: string; url: string }> = [];
      
      for (const kontakt of data.kontaktpersoner) {
        const invitationToken = crypto.randomUUID();
        const role = mapTittelToRole(kontakt.tittel);
        const invitationUrl = `${window.location.origin}/onboarding?token=${invitationToken}`;
        
        // 3a. Insert invitation record
        const { error: invError } = await supabase
          .from('invitations')
          .insert({
            email: kontakt.epost,
            role: role as any,
            salon_id: salon.id,
            token: invitationToken,
            expires_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days
          });
        
        if (invError) {
          console.error('Error creating invitation:', invError);
        } else {
          createdLinks.push({ navn: `${kontakt.fornavn} ${kontakt.etternavn}`, url: invitationUrl });
          
          // 3b. Send invitation email (if enabled)
          if (emailEnabled) {
            try {
              await supabase.functions.invoke('send-invitation-email', {
                body: {
                  email: kontakt.epost,
                  role: role,
                  salonName: data.navn,
                  invitationUrl,
                },
              });
              console.log(`Invitation email sent to ${kontakt.epost}`);
            } catch (emailErr) {
              console.warn('Failed to send invitation email:', emailErr);
            }
          }
        }
        
        // 3c. Create HubSpot contact (if HubSpot is connected)
        if (hubspotCompanyId) {
          try {
            // Map tittel to valid HubSpot stilling values
            const validStillingOptions = ['Lærling', 'Frisør', 'Seniorfrisør', 'Avdelingsleder', 'Dagligleder', 'Dagligleder/Eier', 'Kjede Eier', 'Styreleder'];
            let hubspotStilling = kontakt.tittel;
            
            // Map common titles to valid HubSpot options
            if (kontakt.tittel === 'Eier') {
              hubspotStilling = 'Dagligleder/Eier';
            } else if (!validStillingOptions.includes(kontakt.tittel)) {
              // If not a valid option, don't send stilling to avoid API error
              hubspotStilling = undefined;
            }
            
            const contactProperties: Record<string, string | undefined> = {
              email: kontakt.epost,
              firstname: kontakt.fornavn,
              lastname: kontakt.etternavn,
              phone: kontakt.telefon || '',
              lifecyclestage: 'customer',
            };
            
            // Only add stilling if it's a valid value
            if (hubspotStilling) {
              contactProperties.stilling = hubspotStilling;
            }
            
            const { data: hsContact, error: hsContactError } = await supabase.functions.invoke('hubspot-api', {
              body: {
                action: 'create_contact',
                properties: contactProperties,
                hubspot_owner_id: data.hubspot_owner_id,
              },
            });
            
            // 3d. Associate contact with company
            if (!hsContactError && hsContact?.id) {
              await supabase.functions.invoke('hubspot-api', {
                body: {
                  action: 'associate_contact_to_company',
                  contactId: hsContact.id,
                  companyId: hubspotCompanyId,
                },
              });
              console.log(`HubSpot contact ${hsContact.id} associated with company ${hubspotCompanyId}`);
            }
          } catch (hsErr) {
            console.warn('HubSpot contact sync failed:', hsErr);
          }
        }
      }
      
      setInvitationLinks(createdLinks);
      setStatus(prev => ({ ...prev, invitations: createdLinks.length > 0 ? 'success' : 'error' }));
      
      // 4. Create leverandør and merke connections
      if (data.leverandorer.length > 0) {
        for (const lev of data.leverandorer) {
          if (lev.valgte_merker.length === 0) continue;
          
          // Create leverandør connection
          const { error: levError } = await supabase
            .from('salong_leverandorer')
            .insert({
              salon_id: salon.id,
              leverandor_id: lev.leverandor_id,
              har_kjemi: lev.valgte_merker.some(m => m.rapporteringstype === 'kjemi' || m.rapporteringstype === 'begge_separat'),
              har_produkter: lev.valgte_merker.some(m => m.rapporteringstype === 'produkt' || m.rapporteringstype === 'begge_separat'),
            });
          
          if (levError) console.error('Error creating leverandør link:', levError);
          
          // Create merke connections
          for (const merkeValg of lev.valgte_merker) {
            const { error: merkeError } = await supabase
              .from('salong_merker')
              .insert({
                salon_id: salon.id,
                merke_id: merkeValg.merke_id,
              });
            
            if (merkeError) console.error('Error creating merke link:', merkeError);
          }
        }
        setStatus(prev => ({ ...prev, leverandorer: 'success' }));
      } else {
        setStatus(prev => ({ ...prev, leverandorer: 'skipped' }));
      }
      
      // 5. Update prospekt if came from one
      if (data.prospekt_id) {
        const { error: prospektError } = await supabase
          .from('prospekter')
          .update({ 
            pipeline_status: 'vunnet',
            salon_id: salon.id,
          })
          .eq('id', data.prospekt_id);
        
        if (prospektError) console.error('Error updating prospekt:', prospektError);
      }
      
      toast.success('Medlem opprettet!', {
        description: `${data.navn} er nå registrert som medlem i Hår1`,
      });
      
      // Don't auto-navigate if email is disabled - show invitation links first
      if (emailEnabled) {
        onComplete();
      }
      
    } catch (err) {
      console.error('Error creating member:', err);
      setError(err instanceof Error ? err.message : 'Kunne ikke opprette medlem');
      toast.error('Feil ved opprettelse av medlem');
    } finally {
      setIsCreating(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success('Kopiert til utklippstavle');
  };
  
  const hovedkontakt = data.kontaktpersoner.find(k => k.er_hovedkontakt);
  const leverandorCount = data.leverandorer.filter(l => l.valgte_merker.length > 0).length;
  const merkeCount = data.leverandorer.reduce((sum, l) => sum + l.valgte_merker.length, 0);

  const StatusIcon = ({ status: s }: { status: 'pending' | 'success' | 'error' | 'skipped' }) => {
    if (s === 'success') return <CheckCircle2 className="h-4 w-4 text-green-600" />;
    if (s === 'error') return <XCircle className="h-4 w-4 text-red-600" />;
    if (s === 'skipped') return <Check className="h-4 w-4 text-muted-foreground" />;
    return <div className="h-4 w-4 rounded-full bg-muted" />;
  };
  
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-medium">Oppsummering</h3>
        <p className="text-muted-foreground">
          Gjennomgå informasjonen før du oppretter medlemmet
        </p>
      </div>

      {!emailEnabled && (
        <Alert>
          <Info className="h-4 w-4" />
          <AlertDescription>
            E-post sending er deaktivert. Invitasjonslenker vil bli vist etter opprettelse så du kan dele dem manuelt.
          </AlertDescription>
        </Alert>
      )}
      
      <div className="space-y-4">
        {/* Bedriftsinfo */}
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-start gap-3">
              <Building2 className="h-5 w-5 text-muted-foreground mt-0.5" />
              <div className="flex-1">
                <p className="font-medium">{data.navn}</p>
                <p className="text-sm text-muted-foreground font-mono">
                  Org.nr: {data.org_nummer}
                </p>
                <div className="flex items-center gap-1 text-sm text-muted-foreground mt-1">
                  <MapPin className="h-3 w-3" />
                  {data.adresse}, {data.postnummer} {data.poststed}
                </div>
                {(data.telefon || data.epost) && (
                  <div className="flex flex-wrap gap-3 mt-2 text-sm text-muted-foreground">
                    {data.telefon && (
                      <span className="flex items-center gap-1">
                        <Phone className="h-3 w-3" />
                        {data.telefon}
                      </span>
                    )}
                    {data.epost && (
                      <span className="flex items-center gap-1">
                        <Mail className="h-3 w-3" />
                        {data.epost}
                      </span>
                    )}
                  </div>
                )}
              </div>
              <Badge>{data.type_medlemskap}</Badge>
            </div>
          </CardContent>
        </Card>

        {/* Distrikt */}
        {data.district_id && (
          <Card>
            <CardContent className="pt-4">
              <div className="flex items-start gap-3">
                <MapPinned className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div className="flex-1">
                  <p className="font-medium">Distrikt</p>
                  <p className="text-sm text-muted-foreground">
                    Tilordnet et distrikt
                  </p>
                </div>
                <Check className="h-5 w-5 text-green-600" />
              </div>
            </CardContent>
          </Card>
        )}
        
        {/* Kontaktpersoner */}
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-start gap-3">
              <Users className="h-5 w-5 text-muted-foreground mt-0.5" />
              <div className="flex-1">
                <p className="font-medium">Kontaktpersoner</p>
                <div className="space-y-1 mt-1">
                  {data.kontaktpersoner.map((k, i) => (
                    <div key={i} className="flex items-center gap-2 text-sm">
                      <span>{k.fornavn} {k.etternavn}</span>
                      <span className="text-muted-foreground">({k.tittel})</span>
                      {k.er_hovedkontakt && (
                        <Star className="h-3 w-3 text-amber-500" />
                      )}
                    </div>
                  ))}
                </div>
              </div>
              <Badge variant="secondary">{data.kontaktpersoner.length}</Badge>
            </div>
          </CardContent>
        </Card>
        
        {/* Økonomi */}
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-start gap-3">
              <CreditCard className="h-5 w-5 text-muted-foreground mt-0.5" />
              <div className="flex-1">
                <p className="font-medium">Medlemsavgift</p>
                <p className="text-sm text-muted-foreground">
                  kr {data.medlemsavgift.toLocaleString('nb-NO')} per år
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Leverandører */}
        {leverandorCount > 0 && (
          <Card>
            <CardContent className="pt-4">
              <div className="flex items-start gap-3">
                <Package className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div className="flex-1">
                  <p className="font-medium">Leverandører</p>
                  <p className="text-sm text-muted-foreground">
                    {leverandorCount} leverandør{leverandorCount !== 1 ? 'er' : ''}, {merkeCount} merke{merkeCount !== 1 ? 'r' : ''}
                  </p>
                </div>
                <Badge variant="secondary">{leverandorCount}</Badge>
              </div>
            </CardContent>
          </Card>
        )}
        
        {/* Avtale */}
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-start gap-3">
              <FileText className="h-5 w-5 text-muted-foreground mt-0.5" />
              <div className="flex-1">
                <p className="font-medium">Medlemsavtale</p>
                <p className="text-sm text-muted-foreground">
                  {data.avtale_status === 'signert' ? 'Signert digitalt' : 
                   data.avtale_status === 'manuell' ? 'Manuelt lastet opp' : 
                   'Ikke signert'}
                </p>
              </div>
              {(data.avtale_status === 'signert' || data.avtale_status === 'manuell') && (
                <Check className="h-5 w-5 text-green-600" />
              )}
            </div>
          </CardContent>
        </Card>
        
      </div>
      
      <Separator />

      {/* Creation Status */}
      {isCreating && (
        <div className="space-y-2">
          <p className="text-sm font-medium">Oppretter medlem...</p>
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-sm">
              <StatusIcon status={status.salon} />
              <span>Oppretter salong lokalt</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <StatusIcon status={status.hubspot} />
              <span>Synkroniserer med HubSpot</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <StatusIcon status={status.invitations} />
              <span>Oppretter invitasjoner</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <StatusIcon status={status.leverandorer} />
              <span>Kobler leverandører</span>
            </div>
          </div>
        </div>
      )}

      {/* Invitation Links (shown when email is disabled) */}
      {invitationLinks.length > 0 && !emailEnabled && (
        <Card className="bg-amber-50 border-amber-200">
          <CardContent className="pt-4">
            <p className="font-medium text-amber-800 mb-3">
              E-post er deaktivert - del invitasjonslenkene manuelt:
            </p>
            <div className="space-y-2">
              {invitationLinks.map((link, i) => (
                <div key={i} className="flex items-center gap-2 bg-white p-2 rounded border">
                  <span className="text-sm font-medium flex-1">{link.navn}</span>
                  <code className="text-xs bg-muted px-2 py-1 rounded truncate max-w-[200px]">
                    {link.url}
                  </code>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => copyToClipboard(link.url)}
                  >
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
            <Button 
              className="w-full mt-4" 
              onClick={onComplete}
            >
              Gå til medlemslisten
            </Button>
          </CardContent>
        </Card>
      )}
      
      {error && (
        <div className="flex items-center gap-2 p-4 bg-destructive/10 text-destructive rounded-lg">
          <AlertCircle className="h-5 w-5" />
          <p className="text-sm">{error}</p>
        </div>
      )}
      
      {!invitationLinks.length && (
        <Button 
          onClick={handleCreate}
          disabled={isCreating}
          className="w-full"
          size="lg"
        >
          {isCreating ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Oppretter medlem...
            </>
          ) : (
            <>
              <Check className="h-4 w-4 mr-2" />
              Opprett medlem
            </>
          )}
        </Button>
      )}
    </div>
  );
}
