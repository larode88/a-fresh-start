import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { HelpCircle, Mail } from "lucide-react";

const faqItems = [
  {
    question: "Hvilke skader dekker salongforsikringen?",
    answer: `Salongforsikringen dekker plutselige og uforutsette skader på maskiner, inventar og løsøre, samt varer og utstyr i salongen. Den omfatter også glasskader (for eksempel vinduer og speil), og skader som følge av brann, vann, innbrudd, tyveri, hærverk og naturskade. I tillegg er maskinskade og kasko inkludert, samt tap av inntekt ved avbrudd i driften.`,
  },
  {
    question: "Hva er forskjellen på nivå 1, 2 og 3?",
    answer: `De tre nivåene har forskjellige dekningsbeløp:
    
• Nivå 1: Tingdekning 500.000 kr, Avbruddstap 2.000.000 kr
• Nivå 2: Tingdekning 1.000.000 kr, Avbruddstap 3.000.000 kr  
• Nivå 3: Tingdekning 2.000.000 kr, Avbruddstap 5.000.000 kr

Alle nivåer har 15.000 kr egenandel (5.000 kr for glass) og 12 måneders ansvarstid.`,
  },
  {
    question: "Hva dekker ikke forsikringen?",
    answer: `Forsikringen dekker ikke skader som skyldes slitasje, dårlig vedlikehold eller feil bruk av maskiner. Den dekker heller ikke skader som skjer under ombygging uten at Frende er varslet, eller tyveri og innbrudd uten tilfredsstillende sikring. Brudd på sikkerhetsforskrifter, som for eksempel manglende sertifisering ved varme arbeider, kan føre til redusert eller bortfalt erstatning.`,
  },
  {
    question: "Hva gjelder ved avbrudd i drift?",
    answer: `Dersom salongen må stenge etter en dekningsberettiget skade, dekker forsikringen dokumentert økonomisk tap. Dette kan være tapt omsetning, lønnskostnader i oppsigelsestid og midlertidige lokaler eller utstyr. Erstatning gis i inntil 12 måneder.`,
  },
  {
    question: "Dekker forsikringen kundens eiendeler?",
    answer: `Ja, kunders eiendeler er dekket med inntil 100.000 kr per forsikringsår dersom de skades mens de befinner seg i salongen.`,
  },
  {
    question: "Hva med ansvar overfor kunder og ansatte?",
    answer: `Forsikringen inkluderer bedriftsansvar dersom noen skades i salongen og salongen er ansvarlig, produktansvar dersom produkter brukt i behandling skader kunden, og underslagsforsikring ved økonomisk tap som følge av ansatte som handler uærlig (inntil 100.000 kr).`,
  },
  {
    question: "Hva må vi gjøre for at forsikringen skal gjelde?",
    answer: `Sikkerhetsforskriftene må følges. Dette innebærer forsvarlig brann- og tyverisikring, trygg oppbevaring av kontanter og utstyr, samt bruk av sertifiserte håndverkere ved teknisk arbeid. Det anbefales også å dokumentere verdier og rutiner jevnlig.`,
  },
  {
    question: "Hvem melder vi skade til, og hvordan?",
    answer: `Alle skader meldes til forsikring@har1.no så snart som mulig. Meldingen bør inneholde beskrivelse av hva som har skjedd, dato og tidspunkt, eventuelle bilder og politirapport ved tyveri eller hærverk. Skaden må meldes senest ett år etter at den ble kjent.`,
  },
  {
    question: "Hva må vi gjøre for å få erstatning raskt?",
    answer: `Skaden bør meldes umiddelbart, med grundig dokumentasjon. Dette inkluderer bilder, kvitteringer og eventuelt regnskap over tapte inntekter. Det er viktig å følge sikkerhetsforskriftene og være tilgjengelig for eventuell befaring eller oppfølgingsspørsmål fra Frende.`,
  },
  {
    question: "Kan vi oppgradere nivå?",
    answer: `Ja, nivå kan oppgraderes ved behov. Ta kontakt med forsikring@har1.no for vurdering av dekning basert på salongens verdier og risikoeksponering.`,
  },
];

export function InsuranceFAQ() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <HelpCircle className="h-5 w-5" />
          Ofte stilte spørsmål
        </CardTitle>
        <CardDescription>
          Vanlige spørsmål om salongforsikring
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Accordion type="single" collapsible className="w-full">
          {faqItems.map((item, index) => (
            <AccordionItem key={index} value={`item-${index}`}>
              <AccordionTrigger className="text-left">
                {item.question}
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground whitespace-pre-line">
                {item.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>

        <div className="mt-6 p-4 bg-muted rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <Mail className="h-4 w-4 text-muted-foreground" />
            <span className="font-medium">Trenger du hjelp?</span>
          </div>
          <p className="text-sm text-muted-foreground">
            Kontakt oss på{" "}
            <a href="mailto:forsikring@har1.no" className="text-primary hover:underline">
              forsikring@har1.no
            </a>{" "}
            for spørsmål om forsikringer eller skademeldinger.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
