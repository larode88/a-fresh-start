import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { AlertTriangle, Calendar } from "lucide-react";

interface InsuranceCancelDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  salonId: string;
  insuranceType: string;
  insuranceLabel: string;
  isHealthInsurance?: boolean;
  onSuccess?: () => void;
}

export function InsuranceCancelDialog({
  open,
  onOpenChange,
  salonId,
  insuranceType,
  insuranceLabel,
  isHealthInsurance = false,
  onSuccess,
}: InsuranceCancelDialogProps) {
  const queryClient = useQueryClient();
  const [cancellationDate, setCancellationDate] = useState<string>("");
  const [reason, setReason] = useState<string>("");

  const cancelMutation = useMutation({
    mutationFn: async () => {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) throw new Error("Not authenticated");

      // Create scheduled cancellation
      const { data, error } = await supabase
        .from("insurance_scheduled_cancellations")
        .insert({
          salon_id: salonId,
          insurance_type: insuranceType,
          cancellation_date: cancellationDate,
          reason: reason || null,
          scheduled_by: userData.user.id,
        })
        .select()
        .single();

      if (error) throw error;

      // If date is today or in the past, process immediately
      const selectedDate = new Date(cancellationDate);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      selectedDate.setHours(0, 0, 0, 0);

      if (selectedDate <= today) {
        const { error: processError } = await supabase.functions.invoke(
          "process-insurance-cancellations"
        );
        if (processError) {
          console.error("Error processing cancellation:", processError);
        }
      }

      // Send win-back notification to admin
      try {
        const { data: salon } = await supabase
          .from("salons")
          .select("name")
          .eq("id", salonId)
          .single();

        const { data: userProfile } = await supabase
          .from("users")
          .select("name, phone")
          .eq("id", userData.user.id)
          .single();

        await supabase.functions.invoke("send-insurance-notification", {
          body: {
            type: "cancellation_winback",
            recipientEmail: "forsikring@har1.no",
            recipientName: "Hår1 Forsikring",
            salonName: salon?.name || "Ukjent salong",
            orderId: data.id,
            orderDetails: {
              insuranceType: insuranceLabel,
              cancellationDate,
              reason: reason || "Ikke oppgitt",
              contactName: userProfile?.name,
              contactPhone: userProfile?.phone,
              isHealthInsurance,
            },
          },
        });
      } catch (emailError) {
        console.error("Failed to send win-back notification:", emailError);
      }

      return data;
    },
    onSuccess: (result) => {
      const selectedDate = new Date(cancellationDate);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      selectedDate.setHours(0, 0, 0, 0);

      if (selectedDate <= today) {
        toast.success("Forsikring avsluttet");
      } else {
        toast.success(`Oppsigelse planlagt til ${cancellationDate}`);
      }
      
      queryClient.invalidateQueries({ queryKey: ["scheduled-cancellations"] });
      queryClient.invalidateQueries({ queryKey: ["my-salon-insurance"] });
      onOpenChange(false);
      setCancellationDate("");
      setReason("");
      onSuccess?.();
    },
    onError: (error) => {
      console.error("Error scheduling cancellation:", error);
      toast.error("Kunne ikke planlegge oppsigelse");
    },
  });

  const isImmediateCancel = () => {
    if (!cancellationDate) return false;
    const selectedDate = new Date(cancellationDate);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    selectedDate.setHours(0, 0, 0, 0);
    return selectedDate <= today;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-amber-500" />
            Si opp {insuranceLabel}
          </DialogTitle>
          <DialogDescription>
            {isHealthInsurance 
              ? "Oppsigelse vil gjelde for alle ansatte med helseforsikring."
              : "Velg en sluttdato for forsikringen."}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Warning */}
          <div className="flex items-start gap-2 p-3 bg-amber-50 text-amber-800 rounded-lg text-sm">
            <AlertTriangle className="h-4 w-4 mt-0.5 flex-shrink-0" />
            <p>
              {isImmediateCancel()
                ? "Oppsigelsen vil utføres umiddelbart. Dette kan ikke angres."
                : "Oppsigelsen vil prosesseres automatisk på valgt dato."}
            </p>
          </div>

          {/* Date */}
          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Sluttdato
            </Label>
            <Input
              type="date"
              value={cancellationDate}
              onChange={(e) => setCancellationDate(e.target.value)}
            />
          </div>

          {/* Reason */}
          <div className="space-y-2">
            <Label>Begrunnelse (valgfritt)</Label>
            <Textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="F.eks. Bytte leverandør, Avslutter virksomhet..."
              rows={3}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Avbryt
          </Button>
          <Button
            variant="destructive"
            onClick={() => cancelMutation.mutate()}
            disabled={!cancellationDate || cancelMutation.isPending}
          >
            {cancelMutation.isPending 
              ? "Behandler..." 
              : isImmediateCancel() 
                ? "Avslutt nå" 
                : "Planlegg oppsigelse"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
