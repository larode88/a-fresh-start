import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { toast } from "sonner";
import { RefreshCw, Mail, User, Calendar, Shield, ShieldCheck, ShieldX, Building2, Heart, ChevronDown, Users } from "lucide-react";
import { format } from "date-fns";
import { nb } from "date-fns/locale";
import { useState } from "react";

interface SalonInsurance {
  id: string;
  salon_id: string;
  hubspot_synced_at: string | null;
  aktivering_dato: string | null;
  innmelding_dato: string | null;
  oppsigelse_dato: string | null;
  avsluttede_forsikringer: boolean;
  helse_status: boolean;
  antall_ansatte: number | null;
  antall_arsverk: number | null;
  antall_fritidsulykke: number | null;
  antall_reiseforsikring: number | null;
  arlig_omsetning: number | null;
  cyber_aktiv: boolean;
  fritidsulykke_aktiv: boolean;
  reise_aktiv: boolean;
  salong_aktiv: boolean;
  yrkesskadeforsikring_aktiv: boolean;
  salong_niva: string | null;
  sum_mvil: string | null;
  pris_cyber: number | null;
  pris_fritidsulykke: number | null;
  pris_reise: number | null;
  pris_salong: number | null;
  pris_yrkesskadeforsikring: number | null;
  sum_fritidsulykke: number | null;
  sum_reise: number | null;
  sum_totalt: number | null;
  sum_yrkesskadeforsikring: number | null;
  kontaktperson_navn: string | null;
  kontaktperson_epost: string | null;
  helse_antall_aktive: number | null;
  salons: {
    id: string;
    name: string;
    hs_object_id: string | null;
    hubspot_owner_id: string | null;
  };
  district_name?: string | null;
}

interface EmployeeHealthInsurance {
  id: string;
  name: string | null;
  first_name: string | null;
  email: string;
  helseforsikring_status: string | null;
  helseforsikring_oppstartsdato: string | null;
  helseforsikring_oppsigelsesdato: string | null;
  helseforsikring_pris: number | null;
}

interface InsuranceSalonDetailProps {
  insurance: SalonInsurance;
  open: boolean;
  onClose: () => void;
  readOnly?: boolean;
}

export function InsuranceSalonDetail({ insurance, open, onClose, readOnly = false }: InsuranceSalonDetailProps) {
  const queryClient = useQueryClient();
  const [healthOpen, setHealthOpen] = useState(false);

  // Fetch employees with health insurance for this salon
  const { data: healthEmployees } = useQuery({
    queryKey: ["salon-health-insurance", insurance.salon_id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("users")
        .select("id, name, first_name, email, helseforsikring_status, helseforsikring_oppstartsdato, helseforsikring_oppsigelsesdato, helseforsikring_pris")
        .eq("salon_id", insurance.salon_id)
        .not("helseforsikring_status", "is", null);

      if (error) throw error;
      return data as EmployeeHealthInsurance[];
    },
    enabled: open && !!insurance.salon_id,
  });

  // Fetch health insurance product price
  const { data: helseProduct } = useQuery({
    queryKey: ["insurance-product-helse"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("insurance_products")
        .select("base_price")
        .eq("product_type", "helse")
        .single();
      if (error) throw error;
      return data;
    },
    enabled: open,
  });

  const helsePrisPerPerson = helseProduct?.base_price ? parseFloat(String(helseProduct.base_price)) : 5050;
  const activeHealthEmployees = healthEmployees?.filter(e => e.helseforsikring_status === 'Aktiv') || [];
  const totalHealthInsuranceCost = helsePrisPerPerson * activeHealthEmployees.length;

  // Beregn bedriftsforsikring total
  const calculateBusinessTotal = () => {
    let total = 0;
    if (insurance.salong_aktiv && insurance.pris_salong) {
      total += insurance.pris_salong;
    }
    if (insurance.yrkesskadeforsikring_aktiv && insurance.pris_yrkesskadeforsikring) {
      total += insurance.pris_yrkesskadeforsikring * (insurance.antall_arsverk || 1);
    }
    if (insurance.cyber_aktiv && insurance.pris_cyber) {
      total += insurance.pris_cyber;
    }
    if (insurance.reise_aktiv && insurance.pris_reise) {
      total += insurance.pris_reise * (insurance.antall_reiseforsikring || 1);
    }
    if (insurance.fritidsulykke_aktiv && insurance.pris_fritidsulykke) {
      total += insurance.pris_fritidsulykke * (insurance.antall_fritidsulykke || 1);
    }
    return total;
  };

  const businessTotal = calculateBusinessTotal();
  const grandTotal = businessTotal + totalHealthInsuranceCost;

  const syncMutation = useMutation({
    mutationFn: async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error("Ikke logget inn");

      const response = await supabase.functions.invoke("hubspot-api", {
        body: { 
          action: "sync_salon_insurance",
          salonId: insurance.salon_id,
          hubspotCompanyId: insurance.salons?.hs_object_id
        },
      });

      if (response.error) throw response.error;
      return response.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["salon-insurance"] });
      toast.success("Forsikringsdata synkronisert");
    },
    onError: (error) => {
      toast.error(`Synkronisering feilet: ${error.message}`);
    },
  });

  const formatDate = (date: string | null) => {
    if (!date) return "-";
    return format(new Date(date), "d. MMMM yyyy", { locale: nb });
  };

  const formatCurrency = (value: number | null) => {
    if (value === null || value === undefined) return "-";
    return `${Math.round(value).toLocaleString("nb-NO")} kr`;
  };

  const InsuranceTypeCard = ({ 
    title, 
    active, 
    price, 
    sum, 
    persons,
    level 
  }: { 
    title: string; 
    active: boolean; 
    price?: number | null;
    sum?: number | null;
    persons?: number | null;
    level?: string | null;
  }) => (
    <div className={`p-4 rounded-lg border ${active ? 'bg-green-50 border-green-200 dark:bg-green-950/20 dark:border-green-800' : 'bg-muted/50'}`}>
      <div className="flex items-center justify-between mb-2">
        <span className="font-medium">{title}</span>
        {active ? (
          <Badge className="bg-green-600">
            <ShieldCheck className="h-3 w-3 mr-1" />
            Aktiv
          </Badge>
        ) : (
          <Badge variant="secondary">
            <ShieldX className="h-3 w-3 mr-1" />
            Inaktiv
          </Badge>
        )}
      </div>
      {active && (
        <div className="grid grid-cols-2 gap-2 text-sm text-muted-foreground">
          {price !== undefined && (
            <div>
              <span className="text-xs">Pris:</span>
              <p className="font-medium text-foreground">{formatCurrency(price)}</p>
            </div>
          )}
          {sum !== undefined && (
            <div>
              <span className="text-xs">Sum:</span>
              <p className="font-medium text-foreground">{formatCurrency(sum)}</p>
            </div>
          )}
          {persons !== undefined && persons !== null && (
            <div>
              <span className="text-xs">Antall personer:</span>
              <p className="font-medium text-foreground">{persons}</p>
            </div>
          )}
          {level && (
            <div>
              <span className="text-xs">Nivå:</span>
              <p className="font-medium text-foreground">{level}</p>
            </div>
          )}
        </div>
      )}
    </div>
  );

  return (
    <Dialog open={open} onOpenChange={(isOpen) => !isOpen && onClose()}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle className="text-xl flex items-center gap-2">
                <Building2 className="h-5 w-5" />
                {insurance.salons?.name}
              </DialogTitle>
              <DialogDescription>
                {insurance.district_name || "Ingen distrikt"}
              </DialogDescription>
            </div>
            {!readOnly && (
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => syncMutation.mutate()}
                disabled={syncMutation.isPending}
              >
                <RefreshCw className={`h-4 w-4 mr-2 ${syncMutation.isPending ? 'animate-spin' : ''}`} />
                Synk
              </Button>
            )}
          </div>
        </DialogHeader>

        <div className="space-y-6">
          {/* Status and dates */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                Status og datoer
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div>
                  <span className="text-xs text-muted-foreground">Status</span>
                  <p className="font-medium">
                    {insurance.avsluttede_forsikringer ? (
                      <Badge variant="destructive">Avsluttet</Badge>
                    ) : (
                      <Badge className="bg-green-600">Aktiv</Badge>
                    )}
                  </p>
                </div>
                <div>
                  <span className="text-xs text-muted-foreground">Aktivert</span>
                  <p className="font-medium">{formatDate(insurance.aktivering_dato)}</p>
                </div>
                <div>
                  <span className="text-xs text-muted-foreground">Innmeldt</span>
                  <p className="font-medium">{formatDate(insurance.innmelding_dato)}</p>
                </div>
                <div>
                  <span className="text-xs text-muted-foreground">Oppsigelse</span>
                  <p className="font-medium">{formatDate(insurance.oppsigelse_dato)}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Contact info */}
          {(insurance.kontaktperson_navn || insurance.kontaktperson_epost) && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <User className="h-4 w-4" />
                  Kontaktperson forsikring
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-4">
                  {insurance.kontaktperson_navn && (
                    <div className="flex items-center gap-2">
                      <User className="h-4 w-4 text-muted-foreground" />
                      <span>{insurance.kontaktperson_navn}</span>
                    </div>
                  )}
                  {insurance.kontaktperson_epost && (
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      <a href={`mailto:${insurance.kontaktperson_epost}`} className="text-primary hover:underline">
                        {insurance.kontaktperson_epost}
                      </a>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Company data */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base">Grunnlagsdata</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
                <div className="flex flex-col justify-end h-full">
                  <span className="text-xs text-muted-foreground mb-1">Antall ansatte</span>
                  <p className="text-lg font-semibold">{insurance.antall_ansatte ?? "-"}</p>
                </div>
                <div className="flex flex-col justify-end h-full">
                  <span className="text-xs text-muted-foreground mb-1">Antall årsverk</span>
                  <p className="text-lg font-semibold">{insurance.antall_arsverk ?? "-"}</p>
                </div>
                <div className="flex flex-col justify-end h-full">
                  <span className="text-xs text-muted-foreground mb-1">Årlig omsetning</span>
                  <p className="text-lg font-semibold">{formatCurrency(insurance.arlig_omsetning)}</p>
                </div>
                <div className="flex flex-col justify-end h-full">
                  <span className="text-xs text-muted-foreground mb-1">Dekningsverdi inventar/varer</span>
                  <p className="text-lg font-semibold">
                    {insurance.sum_mvil 
                      ? formatCurrency(parseFloat(insurance.sum_mvil.split('-')[1]?.replace(/[^\d]/g, '') || '0'))
                      : "-"}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Bedriftsforsikring */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Building2 className="h-4 w-4" />
                Bedriftsforsikring
              </CardTitle>
              <CardDescription>
                Årlig premie bedrift
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <InsuranceTypeCard 
                  title="Salongforsikring" 
                  active={insurance.salong_aktiv}
                  price={insurance.pris_salong}
                  level={insurance.salong_niva}
                />
                <InsuranceTypeCard 
                  title="Yrkesskadeforsikring" 
                  active={insurance.yrkesskadeforsikring_aktiv}
                  price={insurance.pris_yrkesskadeforsikring}
                  sum={
                    (insurance.sum_yrkesskadeforsikring && insurance.sum_yrkesskadeforsikring > 0)
                      ? insurance.sum_yrkesskadeforsikring
                      : (insurance.pris_yrkesskadeforsikring && insurance.antall_arsverk)
                        ? insurance.pris_yrkesskadeforsikring * insurance.antall_arsverk
                        : null
                  }
                />
                <InsuranceTypeCard 
                  title="Cyberforsikring" 
                  active={insurance.cyber_aktiv}
                  price={insurance.pris_cyber}
                />
                <InsuranceTypeCard 
                  title="Reiseforsikring" 
                  active={insurance.reise_aktiv}
                  price={insurance.pris_reise}
                  sum={insurance.sum_reise}
                  persons={insurance.antall_reiseforsikring}
                />
                <InsuranceTypeCard 
                  title="Fritidsulykkeforsikring" 
                  active={insurance.fritidsulykke_aktiv}
                  price={insurance.pris_fritidsulykke}
                  sum={insurance.sum_fritidsulykke}
                  persons={insurance.antall_fritidsulykke}
                />
              </div>
              {businessTotal > 0 && (
                <div className="flex items-center justify-between pt-3 border-t">
                  <span className="text-sm text-muted-foreground">Sum bedriftsforsikring</span>
                  <span className="font-semibold">{formatCurrency(businessTotal)}</span>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Helseforsikring */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Heart className="h-4 w-4" />
                Helseforsikring
              </CardTitle>
              <CardDescription>
                Registreres på ansatt-nivå
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className={`p-4 rounded-lg border ${insurance.helse_status ? 'bg-green-50 border-green-200 dark:bg-green-950/20 dark:border-green-800' : 'bg-muted/50'}`}>
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium">Helseforsikring</span>
                  {insurance.helse_status ? (
                    <Badge className="bg-green-600">
                      <ShieldCheck className="h-3 w-3 mr-1" />
                      Aktiv
                    </Badge>
                  ) : (
                    <Badge variant="secondary">
                      <ShieldX className="h-3 w-3 mr-1" />
                      Ingen aktive
                    </Badge>
                  )}
                </div>
                {insurance.helse_status && (
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div className="flex items-center gap-2">
                        <Users className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium">{activeHealthEmployees.length}</span>
                        <span className="text-muted-foreground">aktive</span>
                      </div>
                      <div>
                        <span className="text-xs text-muted-foreground">Pris per person:</span>
                        <p className="font-medium">{formatCurrency(helsePrisPerPerson)}</p>
                      </div>
                    </div>
                    
                    {healthEmployees && healthEmployees.length > 0 && (
                      <Collapsible open={healthOpen} onOpenChange={setHealthOpen}>
                        <CollapsibleTrigger asChild>
                          <Button variant="ghost" size="sm" className="w-full justify-between">
                            <span>Vis ansatte ({healthEmployees.length})</span>
                            <ChevronDown className={`h-4 w-4 transition-transform ${healthOpen ? 'rotate-180' : ''}`} />
                          </Button>
                        </CollapsibleTrigger>
                        <CollapsibleContent className="mt-2">
                          <div className="space-y-2">
                            {healthEmployees.map((emp) => (
                              <div key={emp.id} className="flex items-center justify-between p-2 rounded bg-background/50 text-sm">
                                <div className="flex items-center gap-2">
                                  <User className="h-3 w-3 text-muted-foreground" />
                                  <span>{emp.first_name || emp.name || emp.email}</span>
                                </div>
                                <div className="flex items-center gap-3">
                                  {emp.helseforsikring_status === 'Aktiv' && (
                                    <span className="text-xs font-medium">{formatCurrency(emp.helseforsikring_pris || helsePrisPerPerson)}</span>
                                  )}
                                  <Badge 
                                    variant={emp.helseforsikring_status === 'Aktiv' ? 'default' : 'secondary'}
                                    className={emp.helseforsikring_status === 'Aktiv' ? 'bg-green-600' : ''}
                                  >
                                    {emp.helseforsikring_status}
                                  </Badge>
                                  {emp.helseforsikring_oppstartsdato && (
                                    <span className="text-xs text-muted-foreground">
                                      fra {formatDate(emp.helseforsikring_oppstartsdato)}
                                    </span>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        </CollapsibleContent>
                      </Collapsible>
                    )}
                  </div>
                )}
              </div>
              {totalHealthInsuranceCost > 0 && (
                <div className="flex items-center justify-between pt-3 border-t">
                  <span className="text-sm text-muted-foreground">Sum helseforsikring</span>
                  <span className="font-semibold">{formatCurrency(totalHealthInsuranceCost)}</span>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Totaloversikt */}
          {(businessTotal > 0 || totalHealthInsuranceCost > 0) && (
            <Card className="bg-muted/50">
              <CardContent className="pt-6">
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground flex items-center gap-2">
                      <Building2 className="h-4 w-4" />
                      Bedriftsforsikring
                    </span>
                    <span className="font-medium">{formatCurrency(businessTotal)}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground flex items-center gap-2">
                      <Heart className="h-4 w-4" />
                      Helseforsikring
                    </span>
                    <span className="font-medium">{formatCurrency(totalHealthInsuranceCost)}</span>
                  </div>
                  <Separator />
                  <div className="flex items-center justify-between">
                    <span className="font-medium">Total årlig premie</span>
                    <span className="text-xl font-bold">{formatCurrency(grandTotal)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Sync info */}
          <div className="text-xs text-muted-foreground text-center">
            Sist synkronisert: {insurance.hubspot_synced_at 
              ? format(new Date(insurance.hubspot_synced_at), "d. MMMM yyyy 'kl.' HH:mm", { locale: nb })
              : "Aldri"
            }
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
