import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { format, addDays } from "date-fns";
import { nb } from "date-fns/locale";
import { CalendarIcon, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";

interface HealthEmployeeCancelDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  employee: { id: string; name: string } | null;
  salonId: string;
}

export function HealthEmployeeCancelDialog({ open, onOpenChange, employee, salonId }: HealthEmployeeCancelDialogProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [cancellationDate, setCancellationDate] = useState<Date | undefined>(addDays(new Date(), 30));
  const [reason, setReason] = useState("");

  const mutation = useMutation({
    mutationFn: async () => {
      if (!employee || !cancellationDate) throw new Error("Mangler data");

      const { error } = await supabase
        .from("ansatte")
        .update({
          helseforsikring_status: "oppsigelse",
          helseforsikring_oppsigelsesdato: format(cancellationDate, "yyyy-MM-dd"),
        })
        .eq("id", employee.id);

      if (error) throw error;
    },
    onSuccess: () => {
      toast({ title: "Oppsigelse registrert", description: `Helseforsikring for ${employee?.name} er sagt opp.` });
      queryClient.invalidateQueries({ queryKey: ["health-employees", salonId] });
      queryClient.invalidateQueries({ queryKey: ["my-salon-insurance", salonId] });
      onOpenChange(false);
      setReason("");
      setCancellationDate(addDays(new Date(), 30));
    },
    onError: (error) => {
      toast({ title: "Feil", description: error.message, variant: "destructive" });
    },
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-amber-500" />
            Si opp helseforsikring
          </DialogTitle>
          <DialogDescription>
            Du er i ferd med å si opp helseforsikringen for <strong>{employee?.name}</strong>.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Oppsigelsesdato</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className={cn("w-full justify-start text-left font-normal", !cancellationDate && "text-muted-foreground")}>
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {cancellationDate ? format(cancellationDate, "d. MMMM yyyy", { locale: nb }) : "Velg dato"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={cancellationDate}
                  onSelect={setCancellationDate}
                  disabled={(date) => date < new Date()}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
            <p className="text-xs text-muted-foreground">Forsikringen avsluttes ved utgangen av valgt dato.</p>
          </div>

          <div className="space-y-2">
            <Label>Grunn (valgfritt)</Label>
            <Textarea
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Skriv inn grunn for oppsigelse..."
              rows={3}
            />
          </div>
        </div>

        <DialogFooter className="gap-2 sm:gap-0">
          <Button variant="outline" onClick={() => onOpenChange(false)}>Avbryt</Button>
          <Button variant="destructive" onClick={() => mutation.mutate()} disabled={mutation.isPending || !cancellationDate}>
            {mutation.isPending ? "Behandler..." : "Bekreft oppsigelse"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
