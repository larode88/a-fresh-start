import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Heart, Building2, Shield, Activity, Plane, ShieldCheck, FileText, Plus, Check, Minus } from "lucide-react";

interface InsuranceProduct {
  id: string;
  name: string;
  description: string | null;
  product_type: string;
  price_model: string;
  base_price: number;
  requires_employee_selection: boolean;
  active: boolean;
  sort_order: number;
  icon_name: string | null;
}

interface ProductTier {
  id: string;
  product_id: string;
  tier_name: string;
  tier_description: string | null;
  price: number;
  sort_order: number;
}

interface CoverageDetail {
  id: string;
  tier_id: string;
  coverage_type: string;
  coverage_value: string;
  sort_order: number;
}

interface ProductDocument {
  id: string;
  product_id: string;
  document_type: string;
  title: string;
  file_url: string;
}

interface CartItem {
  productId: string;
  tierId?: string;
  quantity: number;
}

interface InsuranceProductCatalogProps {
  cart: CartItem[];
  onAddToCart: (productId: string, tierId?: string, quantity?: number) => void;
  onRemoveFromCart: (productId: string) => void;
  arsverk?: number;
}

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Heart,
  Building2,
  Shield,
  Activity,
  Plane,
  ShieldCheck,
};

const priceModelLabels: Record<string, string> = {
  fast: "Fast pris",
  per_arsverk: "Per årsverk",
  per_person: "Per person",
};

export function InsuranceProductCatalog({ cart, onAddToCart, onRemoveFromCart, arsverk }: InsuranceProductCatalogProps) {
  const [selectedProduct, setSelectedProduct] = useState<InsuranceProduct | null>(null);
  const [showTierSelector, setShowTierSelector] = useState(false);
  const [selectedTierId, setSelectedTierId] = useState<string | null>(null);
  
  // Quantity popup state
  const [showQuantityDialog, setShowQuantityDialog] = useState(false);
  const [quantityProduct, setQuantityProduct] = useState<InsuranceProduct | null>(null);
  const [selectedQuantity, setSelectedQuantity] = useState(1);

  const { data: products, isLoading: productsLoading } = useQuery({
    queryKey: ["insurance-products-catalog"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("insurance_products")
        .select("*")
        .eq("active", true)
        .order("sort_order");
      
      if (error) throw error;
      return data as InsuranceProduct[];
    },
  });

  const { data: tiers } = useQuery({
    queryKey: ["insurance-product-tiers-catalog"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("insurance_product_tiers")
        .select("*")
        .order("sort_order");
      
      if (error) throw error;
      return data as ProductTier[];
    },
  });

  const { data: coverageDetails } = useQuery({
    queryKey: ["insurance-coverage-details-catalog"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("insurance_coverage_details")
        .select("*")
        .order("sort_order");
      
      if (error) throw error;
      return data as CoverageDetail[];
    },
  });

  const { data: documents } = useQuery({
    queryKey: ["insurance-product-documents-catalog"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("insurance_product_documents")
        .select("*")
        .eq("document_type", "vilkar");
      
      if (error) throw error;
      return data as ProductDocument[];
    },
  });

  // Filter out health insurance products - these are handled separately
  const filteredProducts = products?.filter(p => p.product_type !== "helse");

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("nb-NO", {
      style: "currency",
      currency: "NOK",
      maximumFractionDigits: 0,
    }).format(price);
  };

  const getProductTiers = (productId: string) => {
    return tiers?.filter((t) => t.product_id === productId) || [];
  };

  const getTierCoverage = (tierId: string) => {
    return coverageDetails?.filter((c) => c.tier_id === tierId) || [];
  };

  const getProductDocument = (productId: string) => {
    return documents?.find((d) => d.product_id === productId);
  };

  const isInCart = (productId: string) => {
    return cart.some((item) => item.productId === productId);
  };

  const getCartItem = (productId: string) => {
    return cart.find((item) => item.productId === productId);
  };

  const calculatePrice = (product: InsuranceProduct, tierId?: string) => {
    if (product.product_type === "salong" && tierId) {
      const tier = tiers?.find((t) => t.id === tierId);
      return tier?.price || 0;
    }
    
    if (product.price_model === "per_arsverk" && arsverk) {
      return product.base_price * arsverk;
    }
    
    return product.base_price;
  };

  const renderIcon = (iconName: string | null) => {
    if (!iconName || !iconMap[iconName]) return <Shield className="h-8 w-8" />;
    const Icon = iconMap[iconName];
    return <Icon className="h-8 w-8" />;
  };

  const handleAddProduct = (product: InsuranceProduct) => {
    const productTiers = getProductTiers(product.id);
    
    if (productTiers.length > 0) {
      // Product has tiers - show tier selector
      setSelectedProduct(product);
      setShowTierSelector(true);
      setSelectedTierId(productTiers[0]?.id || null);
    } else if (product.price_model === "per_person" && !product.requires_employee_selection) {
      // Per person without employee selection - show quantity popup
      setQuantityProduct(product);
      setSelectedQuantity(1);
      setShowQuantityDialog(true);
    } else {
      // Standard product - add directly
      onAddToCart(product.id);
    }
  };

  const handleTierConfirm = () => {
    if (selectedProduct && selectedTierId) {
      onAddToCart(selectedProduct.id, selectedTierId);
      setShowTierSelector(false);
      setSelectedProduct(null);
      setSelectedTierId(null);
    }
  };

  const handleQuantityConfirm = () => {
    if (quantityProduct && selectedQuantity > 0) {
      onAddToCart(quantityProduct.id, undefined, selectedQuantity);
      setShowQuantityDialog(false);
      setQuantityProduct(null);
      setSelectedQuantity(1);
    }
  };

  if (productsLoading) {
    return (
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {[...Array(6)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader className="space-y-2">
              <div className="h-8 w-8 rounded bg-muted" />
              <div className="h-5 w-32 rounded bg-muted" />
              <div className="h-4 w-full rounded bg-muted" />
            </CardHeader>
            <CardContent>
              <div className="h-6 w-24 rounded bg-muted" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {filteredProducts?.map((product) => {
          const productTiers = getProductTiers(product.id);
          const hasTiers = productTiers.length > 0;
          const inCart = isInCart(product.id);
          const cartItem = getCartItem(product.id);
          const doc = getProductDocument(product.id);

          return (
            <Card 
              key={product.id} 
              className={`relative transition-all ${inCart ? "ring-2 ring-primary" : ""}`}
            >
              {inCart && (
                <div className="absolute -top-2 -right-2">
                  <Badge className="bg-primary text-primary-foreground">
                    <Check className="h-3 w-3 mr-1" />
                    {cartItem && cartItem.quantity > 1 ? `${cartItem.quantity} stk` : "Valgt"}
                  </Badge>
                </div>
              )}
              
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="p-2 rounded-lg bg-muted text-muted-foreground">
                    {renderIcon(product.icon_name)}
                  </div>
                  <Badge variant="outline" className="text-xs">
                    {priceModelLabels[product.price_model]}
                  </Badge>
                </div>
                <CardTitle className="mt-3">{product.name}</CardTitle>
                {product.description && (
                  <CardDescription className="line-clamp-2">
                    {product.description}
                  </CardDescription>
                )}
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="flex items-baseline justify-between">
                  <div>
                    {hasTiers ? (
                      <div className="space-y-1">
                        {productTiers.map((tier) => (
                          <div key={tier.id} className="flex justify-between text-sm">
                            <span className="text-muted-foreground">{tier.tier_name}:</span>
                            <span className="font-medium">{formatPrice(tier.price)}/år</span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div>
                        <span className="text-2xl font-bold">
                          {formatPrice(product.base_price)}
                        </span>
                        <span className="text-muted-foreground text-sm">
                          /{product.price_model === "per_person" ? "person" : product.price_model === "per_arsverk" ? "årsverk" : "år"}
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                {product.price_model === "per_arsverk" && arsverk && (
                  <p className="text-sm text-muted-foreground">
                    Estimert total: {formatPrice(product.base_price * arsverk)}/år ({arsverk} årsverk)
                  </p>
                )}

                <div className="flex gap-2">
                  {doc && (
                    <Button variant="outline" size="sm" asChild className="flex-1">
                      <a href={doc.file_url} target="_blank" rel="noopener noreferrer">
                        <FileText className="h-4 w-4 mr-2" />
                        Vilkår
                      </a>
                    </Button>
                  )}
                  
                  {inCart ? (
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => onRemoveFromCart(product.id)}
                      className="flex-1"
                    >
                      Fjern
                    </Button>
                  ) : (
                    <Button 
                      size="sm" 
                      onClick={() => handleAddProduct(product)}
                      className="flex-1"
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Legg til
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Tier selector dialog */}
      <Dialog open={showTierSelector} onOpenChange={setShowTierSelector}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Velg nivå for {selectedProduct?.name}</DialogTitle>
            <DialogDescription>
              Sammenlign dekningsnivåer og velg det som passer for din salong
            </DialogDescription>
          </DialogHeader>

          {selectedProduct && (
            <div className="space-y-6">
              <RadioGroup value={selectedTierId || ""} onValueChange={setSelectedTierId}>
                <div className="grid gap-4 md:grid-cols-3">
                  {getProductTiers(selectedProduct.id).map((tier) => {
                    const coverage = getTierCoverage(tier.id);
                    const isSelected = selectedTierId === tier.id;

                    return (
                      <div
                        key={tier.id}
                        className={`border rounded-lg p-4 cursor-pointer transition-all ${
                          isSelected ? "ring-2 ring-primary border-primary" : "hover:border-primary/50"
                        }`}
                        onClick={() => setSelectedTierId(tier.id)}
                      >
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <RadioGroupItem value={tier.id} id={tier.id} className="sr-only" />
                            <Label htmlFor={tier.id} className="font-semibold cursor-pointer">
                              {tier.tier_name}
                            </Label>
                            {tier.tier_description && (
                              <p className="text-sm text-muted-foreground mt-1">
                                {tier.tier_description}
                              </p>
                            )}
                          </div>
                          {isSelected && (
                            <Check className="h-5 w-5 text-primary" />
                          )}
                        </div>
                        
                        <div className="text-xl font-bold mb-3">
                          {formatPrice(tier.price)}/år
                        </div>

                        <div className="space-y-2">
                          {coverage.slice(0, 5).map((c) => (
                            <div key={c.id} className="flex justify-between text-sm">
                              <span className="text-muted-foreground">{c.coverage_type}</span>
                              <span className="font-medium">{c.coverage_value}</span>
                            </div>
                          ))}
                          {coverage.length > 5 && (
                            <p className="text-xs text-muted-foreground">
                              +{coverage.length - 5} flere dekninger
                            </p>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </RadioGroup>

              {/* Full coverage comparison table */}
              <div className="border rounded-lg overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Dekningstype</TableHead>
                      {getProductTiers(selectedProduct.id).map((tier) => (
                        <TableHead key={tier.id} className="text-center">
                          {tier.tier_name}
                        </TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {/* Get unique coverage types */}
                    {[...new Set(coverageDetails?.filter(c => 
                      getProductTiers(selectedProduct.id).some(t => t.id === c.tier_id)
                    ).map(c => c.coverage_type))].map((coverageType) => (
                      <TableRow key={coverageType}>
                        <TableCell className="font-medium">{coverageType}</TableCell>
                        {getProductTiers(selectedProduct.id).map((tier) => {
                          const value = coverageDetails?.find(
                            c => c.tier_id === tier.id && c.coverage_type === coverageType
                          )?.coverage_value || "-";
                          return (
                            <TableCell key={tier.id} className="text-center">
                              {value}
                            </TableCell>
                          );
                        })}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setShowTierSelector(false)}>
                  Avbryt
                </Button>
                <Button onClick={handleTierConfirm} disabled={!selectedTierId}>
                  Legg til {selectedTierId && getProductTiers(selectedProduct.id).find(t => t.id === selectedTierId)?.tier_name}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Quantity selector dialog */}
      <Dialog open={showQuantityDialog} onOpenChange={setShowQuantityDialog}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Velg antall personer</DialogTitle>
            <DialogDescription>
              Hvor mange personer skal ha {quantityProduct?.name?.toLowerCase()}?
            </DialogDescription>
          </DialogHeader>

          {quantityProduct && (
            <div className="space-y-6 py-4">
              <div className="flex items-center justify-center gap-4">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setSelectedQuantity(Math.max(1, selectedQuantity - 1))}
                  disabled={selectedQuantity <= 1}
                >
                  <Minus className="h-4 w-4" />
                </Button>
                <Input
                  type="number"
                  min={1}
                  value={selectedQuantity}
                  onChange={(e) => setSelectedQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-20 text-center text-lg font-bold"
                />
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setSelectedQuantity(selectedQuantity + 1)}
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>

              <div className="text-center space-y-1">
                <p className="text-sm text-muted-foreground">
                  {formatPrice(quantityProduct.base_price)} × {selectedQuantity} personer
                </p>
                <p className="text-2xl font-bold">
                  {formatPrice(quantityProduct.base_price * selectedQuantity)}/år
                </p>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowQuantityDialog(false)}>
              Avbryt
            </Button>
            <Button onClick={handleQuantityConfirm}>
              Legg til {selectedQuantity} {selectedQuantity === 1 ? "person" : "personer"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
