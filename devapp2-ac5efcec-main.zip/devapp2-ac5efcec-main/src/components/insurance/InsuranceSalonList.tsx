import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ChevronRight, Heart, Shield, ShieldCheck, ShieldX } from "lucide-react";
import { format } from "date-fns";
import { nb } from "date-fns/locale";

interface SalonInsurance {
  id: string;
  salon_id: string;
  hubspot_synced_at: string | null;
  avsluttede_forsikringer: boolean;
  cyber_aktiv: boolean;
  fritidsulykke_aktiv: boolean;
  reise_aktiv: boolean;
  salong_aktiv: boolean;
  yrkesskadeforsikring_aktiv: boolean;
  helse_status: boolean;
  helse_antall_aktive: number | null;
  sum_totalt: number | null;
  salons: {
    id: string;
    name: string;
    hs_object_id?: string | null;
    hubspot_owner_id?: string | null;
  };
  district_name?: string | null;
}

interface InsuranceSalonListProps {
  data: SalonInsurance[];
  onSelect: (salonId: string) => void;
}

const HELSE_PRIS_PER_PERSON = 5050;

export function InsuranceSalonList({ data, onSelect }: InsuranceSalonListProps) {
  const getActiveInsuranceCount = (item: SalonInsurance) => {
    let count = 0;
    if (item.cyber_aktiv) count++;
    if (item.fritidsulykke_aktiv) count++;
    if (item.reise_aktiv) count++;
    if (item.salong_aktiv) count++;
    if (item.yrkesskadeforsikring_aktiv) count++;
    if (item.helse_status) count++;
    return count;
  };

  const getTotalPremium = (item: SalonInsurance) => {
    const businessTotal = item.sum_totalt || 0;
    const healthTotal = (item.helse_antall_aktive || 0) * HELSE_PRIS_PER_PERSON;
    return businessTotal + healthTotal;
  };

  const getStatusBadge = (item: SalonInsurance) => {
    if (item.avsluttede_forsikringer) {
      return (
        <Badge variant="destructive" className="gap-1">
          <ShieldX className="h-3 w-3" />
          Avsluttet
        </Badge>
      );
    }
    const activeCount = getActiveInsuranceCount(item);
    const hasOnlyHealth = activeCount === 1 && item.helse_status;
    if (activeCount === 0) {
      return (
        <Badge variant="secondary" className="gap-1">
          <Shield className="h-3 w-3" />
          Ingen aktive
        </Badge>
      );
    }
    return (
      <Badge variant="default" className="inline-flex items-center gap-1 bg-green-600 whitespace-nowrap">
        <ShieldCheck className="h-3 w-3 flex-shrink-0" />
        <span>{activeCount} aktive</span>
      </Badge>
    );
  };

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Salong</TableHead>
            <TableHead>Distrikt</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Aktive forsikringer</TableHead>
          <TableHead className="text-right whitespace-nowrap">Total premie</TableHead>
            <TableHead className="w-[50px]"></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {[...data].sort((a, b) => 
            (a.salons?.name || "").localeCompare(b.salons?.name || "", "nb")
          ).map((item) => (
            <TableRow 
              key={item.id}
              className="cursor-pointer hover:bg-muted/50"
              onClick={() => onSelect(item.salon_id)}
            >
              <TableCell className="font-medium">
                {item.salons?.name || "Ukjent salong"}
              </TableCell>
              <TableCell className="text-muted-foreground whitespace-nowrap">
                {item.district_name 
                  ? (item.district_name.includes(" - ") 
                      ? item.district_name.split(" - ").slice(1).join(" - ")
                      : item.district_name)
                  : "-"}
              </TableCell>
              <TableCell>
                {getStatusBadge(item)}
              </TableCell>
              <TableCell>
                <div className="flex gap-1 flex-wrap">
                  {item.salong_aktiv && <Badge variant="outline" className="text-xs">Salong</Badge>}
                  {item.yrkesskadeforsikring_aktiv && <Badge variant="outline" className="text-xs">Yrkesskade</Badge>}
                  {item.cyber_aktiv && <Badge variant="outline" className="text-xs">Cyber</Badge>}
                  {item.reise_aktiv && <Badge variant="outline" className="text-xs">Reise</Badge>}
                  {item.fritidsulykke_aktiv && <Badge variant="outline" className="text-xs">Fritidsulykke</Badge>}
                  {item.helse_status && (
                    <Badge variant="outline" className="text-xs gap-1">
                      <Heart className="h-2.5 w-2.5" />
                      Helse
                    </Badge>
                  )}
                </div>
              </TableCell>
              <TableCell className="text-right font-medium whitespace-nowrap">
                {(() => {
                  const total = getTotalPremium(item);
                  return total > 0 ? `${Math.round(total).toLocaleString("nb-NO")} kr` : "-";
                })()}
              </TableCell>
              <TableCell>
                <Button variant="ghost" size="icon">
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
