// Insurance admin form component
import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { toast } from "sonner";
import { Save, Send, Building2, Calendar, Shield, Users, DollarSign, RefreshCw, Plus, X, ClipboardList, Trash2, FileSignature, Check, AlertCircle } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { HealthInsuranceEmployeeManager } from "./HealthInsuranceEmployeeManager";
import { ScheduledCancellationsPanel } from "./ScheduledCancellationsPanel";

interface Salon {
  id: string;
  name: string;
  hs_object_id: string | null;
}

interface SalonInsurance {
  id: string;
  salon_id: string;
  antall_ansatte: number | null;
  antall_arsverk: number | null;
  arlig_omsetning: number | null;
  aktivering_dato: string | null;
  innmelding_dato: string | null;
  bestillingsdato: string | null;
  oppstartsdato: string | null;
  oppsigelse_dato: string | null;
  salong_aktiv: boolean | null;
  salong_niva: string | null;
  pris_salong: number | null;
  yrkesskadeforsikring_aktiv: boolean | null;
  pris_yrkesskadeforsikring: number | null;
  sum_yrkesskadeforsikring: number | null;
  cyber_aktiv: boolean | null;
  pris_cyber: number | null;
  reise_aktiv: boolean | null;
  pris_reise: number | null;
  antall_reiseforsikring: number | null;
  sum_reise: number | null;
  fritidsulykke_aktiv: boolean | null;
  pris_fritidsulykke: number | null;
  antall_fritidsulykke: number | null;
  sum_fritidsulykke: number | null;
  helse_status: boolean | null;
  helse_antall_aktive: number | null;
  // New health insurance fields
  helseforsikring_status: string | null;
  helseforsikring_avtalenummer: string | null;
  helseforsikring_oppstartsdato: string | null;
  helseforsikring_premie: number | null;
  helseforsikring_oppsigelsesdato: string | null;
  kontaktperson_navn: string | null;
  kontaktperson_epost: string | null;
  bytter_selskap: boolean | null;
  tidligere_forsikringer: string | null;
  sum_totalt: number | null;
  hubspot_company_id: string | null;
}

interface InsuranceProduct {
  id: string;
  name: string;
  base_price: number;
  price_model: string;
  product_type: string;
  active: boolean;
  requires_employee_selection: boolean | null;
}

interface InsuranceProductTier {
  id: string;
  product_id: string;
  tier_name: string;
  price: number;
}

interface OrderItem {
  productId: string;
  tierId?: string;
  quantity: number;
  selectedEmployees?: string[];
}

interface Employee {
  id: string;
  name: string;
}

interface PreviousInsurance {
  company: string;
  policyNumber: string;
}

interface InsuranceAdminFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  embedded?: boolean;
}

export function InsuranceAdminForm({ open, onOpenChange, embedded = false }: InsuranceAdminFormProps) {
  const { user, profile } = useAuth();
  const queryClient = useQueryClient();
  const [selectedSalonId, setSelectedSalonId] = useState<string>("");
  const [mode, setMode] = useState<"edit" | "order">("edit");
  const [isSyncingAvtalenummer, setIsSyncingAvtalenummer] = useState(false);
  
  // Edit mode state
  const [formData, setFormData] = useState<Partial<SalonInsurance>>({});
  
  // Order mode state
  const [orderItems, setOrderItems] = useState<OrderItem[]>([]);
  const [orderContactName, setOrderContactName] = useState("");
  const [orderContactEmail, setOrderContactEmail] = useState("");
  const [orderContactPhone, setOrderContactPhone] = useState("");
  
  // Frende info
  const [orderAntallAnsatte, setOrderAntallAnsatte] = useState("");
  const [orderAntallArsverk, setOrderAntallArsverk] = useState("");
  const [orderAarligOmsetning, setOrderAarligOmsetning] = useState("");
  const [orderDesiredStartDate, setOrderDesiredStartDate] = useState("");
  
  // Switching provider
  const [orderSwitchingProvider, setOrderSwitchingProvider] = useState(false);
  const [orderPreviousInsurances, setOrderPreviousInsurances] = useState<PreviousInsurance[]>([{ company: "", policyNumber: "" }]);
  
  // POA
  const [orderSignatureName, setOrderSignatureName] = useState("");
  
  // Terms
  const [orderAcceptedTerms, setOrderAcceptedTerms] = useState(false);

  // Fetch all salons
  const { data: salons } = useQuery({
    queryKey: ["all-salons-admin"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("salons")
        .select("id, name, hs_object_id")
        .order("name");
      if (error) throw error;
      return data as Salon[];
    },
  });

  // Fetch selected salon's insurance data
  const { data: salonInsurance, isLoading: insuranceLoading } = useQuery({
    queryKey: ["salon-insurance-admin", selectedSalonId],
    queryFn: async () => {
      if (!selectedSalonId) return null;
      const { data, error } = await supabase
        .from("salon_insurance")
        .select("*")
        .eq("salon_id", selectedSalonId)
        .single();
      if (error && error.code !== "PGRST116") throw error;
      return data as SalonInsurance | null;
    },
    enabled: !!selectedSalonId,
  });

  // Fetch products and tiers for order mode
  const { data: products } = useQuery({
    queryKey: ["insurance-products-admin"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("insurance_products")
        .select("*")
        .eq("active", true)
        .order("sort_order");
      if (error) throw error;
      return data as InsuranceProduct[];
    },
  });

  const { data: tiers } = useQuery({
    queryKey: ["insurance-tiers-admin"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("insurance_product_tiers")
        .select("*")
        .order("sort_order");
      if (error) throw error;
      return data as InsuranceProductTier[];
    },
  });

  // Fetch employees for selected salon (for employee selection in orders)
  const { data: employees } = useQuery({
    queryKey: ["employees-for-order-admin", selectedSalonId],
    queryFn: async () => {
      if (!selectedSalonId) return [];
      const { data, error } = await supabase
        .from("users")
        .select("id, name")
        .eq("salon_id", selectedSalonId)
        .order("name");
      if (error) throw error;
      return data as Employee[];
    },
    enabled: !!selectedSalonId,
  });

  // Update form data when insurance data loads
  useEffect(() => {
    if (salonInsurance) {
      setFormData(salonInsurance);
      setOrderContactName(salonInsurance.kontaktperson_navn || "");
      setOrderContactEmail(salonInsurance.kontaktperson_epost || "");
      setOrderAntallAnsatte(salonInsurance.antall_ansatte ? String(salonInsurance.antall_ansatte) : "");
      setOrderAntallArsverk(salonInsurance.antall_arsverk ? String(salonInsurance.antall_arsverk) : "");
      setOrderAarligOmsetning(salonInsurance.arlig_omsetning ? String(salonInsurance.arlig_omsetning) : "");
    } else if (selectedSalonId) {
      setFormData({ salon_id: selectedSalonId });
      setOrderContactName("");
      setOrderContactEmail("");
      setOrderAntallAnsatte("");
      setOrderAntallArsverk("");
      setOrderAarligOmsetning("");
    }
    setOrderItems([]);
    setOrderContactPhone("");
    setOrderDesiredStartDate("");
    setOrderSwitchingProvider(false);
    setOrderPreviousInsurances([{ company: "", policyNumber: "" }]);
    setOrderSignatureName("");
    setOrderAcceptedTerms(false);
    setOrderPersonnummer({});
  }, [salonInsurance, selectedSalonId]);

  // Save mutation for edit mode
  const saveMutation = useMutation({
    mutationFn: async () => {
      if (!selectedSalonId) throw new Error("Ingen salong valgt");
      
      const dataToSave = {
        ...formData,
        salon_id: selectedSalonId,
        updated_at: new Date().toISOString(),
      };

      // Calculate sum_totalt
      let sumTotalt = 0;
      if (formData.salong_aktiv && formData.pris_salong) sumTotalt += formData.pris_salong;
      if (formData.yrkesskadeforsikring_aktiv && formData.sum_yrkesskadeforsikring) sumTotalt += formData.sum_yrkesskadeforsikring;
      if (formData.cyber_aktiv && formData.pris_cyber) sumTotalt += formData.pris_cyber;
      if (formData.reise_aktiv && formData.sum_reise) sumTotalt += formData.sum_reise;
      if (formData.fritidsulykke_aktiv && formData.sum_fritidsulykke) sumTotalt += formData.sum_fritidsulykke;
      dataToSave.sum_totalt = sumTotalt;

      const { error } = await supabase
        .from("salon_insurance")
        .upsert(dataToSave, { onConflict: "salon_id" });

      if (error) throw error;
      
      return { salonId: selectedSalonId, hubspotCompanyId: selectedSalon?.hs_object_id };
    },
    onSuccess: async (result) => {
      queryClient.invalidateQueries({ queryKey: ["salon-insurance"] });
      queryClient.invalidateQueries({ queryKey: ["salon-insurance-admin"] });
      
      // Automatically sync to HubSpot if salon has HubSpot connection
      if (result?.hubspotCompanyId) {
        try {
          const { data, error } = await supabase.functions.invoke('hubspot-api', {
            body: { action: 'sync_insurance_to_hubspot', salonId: result.salonId }
          });
          
          if (error) throw error;
          
          if (data?.success) {
            toast.success("Forsikringsdata lagret og synkronisert til HubSpot");
          } else {
            toast.success("Forsikringsdata lagret");
            toast.warning(data?.message || "HubSpot-sync ikke utført");
          }
        } catch (hubspotError) {
          console.error("HubSpot sync failed:", hubspotError);
          toast.success("Forsikringsdata lagret lokalt");
          toast.warning("HubSpot-synkronisering feilet");
        }
      } else {
        toast.success("Forsikringsdata lagret (ingen HubSpot-kobling)");
      }
    },
    onError: (error) => {
      console.error("Save error:", error);
      toast.error("Kunne ikke lagre data");
    },
  });

  // Create order mutation
  const createOrderMutation = useMutation({
    mutationFn: async () => {
      if (!selectedSalonId || !user) throw new Error("Mangler salon eller bruker");
      if (orderItems.length === 0) throw new Error("Legg til minst ett produkt");

      // Validate personnummer for health insurance
      const healthItems = getHealthInsuranceItems();
      if (healthItems.length > 0 && !validatePersonnummer()) {
        throw new Error("Personnummer (11 siffer) er påkrevd for alle ansatte i helseforsikring");
      }

      // Calculate total
      let totalPrice = 0;
      const items: { product_id: string; tier_id: string | null; quantity: number; unit_price: number; total_price: number; itemIndex: number }[] = [];

      for (let i = 0; i < orderItems.length; i++) {
        const item = orderItems[i];
        const product = products?.find(p => p.id === item.productId);
        if (!product) continue;

        let unitPrice = product.base_price;
        let quantity = item.quantity;
        
        if (item.tierId) {
          const tier = tiers?.find(t => t.id === item.tierId);
          if (tier) unitPrice = tier.price;
        }

        // Handle per_arsverk pricing
        if (product.price_model === "per_arsverk" && orderAntallArsverk) {
          quantity = parseFloat(orderAntallArsverk);
        }

        // Handle employee selection
        if (item.selectedEmployees && item.selectedEmployees.length > 0) {
          quantity = item.selectedEmployees.length;
        }

        const itemTotal = unitPrice * quantity;
        totalPrice += itemTotal;

        items.push({
          product_id: item.productId,
          tier_id: item.tierId || null,
          quantity: quantity,
          unit_price: unitPrice,
          total_price: itemTotal,
          itemIndex: i,
        });
      }

      // Format previous insurances
      const formattedPreviousInsurances = orderSwitchingProvider 
        ? orderPreviousInsurances.filter(p => p.company || p.policyNumber)
        : null;

      // Create order with all fields
      const { data: order, error: orderError } = await supabase
        .from("insurance_orders")
        .insert({
          salon_id: selectedSalonId,
          ordered_by_user_id: user.id,
          status: "pending_approval",
          order_type: "new",
          total_price: totalPrice,
          contact_name: orderContactName,
          contact_email: orderContactEmail,
          contact_phone: orderContactPhone || null,
          antall_ansatte: orderAntallAnsatte ? parseInt(orderAntallAnsatte) : null,
          antall_arsverk: orderAntallArsverk ? parseFloat(orderAntallArsverk) : null,
          aarlig_omsetning: orderAarligOmsetning ? parseFloat(orderAarligOmsetning) : null,
          desired_start_date: orderDesiredStartDate || null,
          switching_provider: orderSwitchingProvider,
          previous_insurances: formattedPreviousInsurances,
          poa_signature_name: orderSignatureName || null,
          poa_signature_at: orderSignatureName ? new Date().toISOString() : null,
        } as any)
        .select()
        .single();

      if (orderError) throw orderError;

      // Create order items
      for (const item of items) {
        const { data: orderItem, error: itemError } = await supabase
          .from("insurance_order_items")
          .insert({
            order_id: order.id,
            product_id: item.product_id,
            tier_id: item.tier_id,
            quantity: item.quantity,
            unit_price: item.unit_price,
            total_price: item.total_price,
          })
          .select()
          .single();
        if (itemError) throw itemError;

        // Add selected employees if applicable (using itemIndex for correct lookup)
        const cartItem = orderItems[item.itemIndex];
        if (cartItem?.selectedEmployees && cartItem.selectedEmployees.length > 0) {
          const employeeInserts = cartItem.selectedEmployees.map(empId => ({
            order_item_id: orderItem.id,
            user_id: empId,
          }));

          const { error: empError } = await supabase
            .from("insurance_order_employees")
            .insert(employeeInserts);

          if (empError) throw empError;

          // Save personnummer for health insurance employees
          const product = products?.find(p => p.id === cartItem.productId);
          if (product?.product_type === 'helse') {
            for (const empId of cartItem.selectedEmployees) {
              const pnr = orderPersonnummer[empId];
              if (pnr) {
                await supabase
                  .from("users")
                  .update({ helseforsikring_personnummer: pnr })
                  .eq("id", empId);
              }
            }
          }
        }
      }

      return order;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["insurance-orders"] });
      queryClient.invalidateQueries({ queryKey: ["insurance-pending-orders"] });
      toast.success("Bestilling opprettet og lagt i pipeline");
      setOrderItems([]);
      setOrderPersonnummer({});
      onOpenChange(false);
    },
    onError: (error: any) => {
      console.error("Order error:", error);
      toast.error(error.message || "Kunne ikke opprette bestilling");
    },
  });

  // Helper function to get product price by type
  const getProductPrice = (productType: string): number | null => {
    const product = products?.find(p => p.product_type === productType);
    return product?.base_price || null;
  };

  // Helper function to get salon tier price by level
  const getSalongTierPrice = (nivel: string): number | null => {
    const salongProduct = products?.find(p => p.product_type === 'salong');
    if (!salongProduct) return null;
    // nivel is now "Nivå 1", "Nivå 2", etc. - match tier_name that contains the nivel
    const tier = tiers?.find(t => t.product_id === salongProduct.id && t.tier_name === nivel);
    return tier?.price || null;
  };

  const updateField = (field: keyof SalonInsurance, value: any) => {
    setFormData(prev => {
      const updated = { ...prev, [field]: value };
      
      // Clear fields when insurance is deactivated
      if (field === "salong_aktiv" && value === false) {
        updated.pris_salong = null;
        updated.salong_niva = null;
      }
      
      if (field === "yrkesskadeforsikring_aktiv" && value === false) {
        updated.pris_yrkesskadeforsikring = null;
        updated.sum_yrkesskadeforsikring = null;
      }
      
      if (field === "cyber_aktiv" && value === false) {
        updated.pris_cyber = null;
      }
      
      if (field === "reise_aktiv" && value === false) {
        updated.pris_reise = null;
        updated.sum_reise = null;
        updated.antall_reiseforsikring = null;
      }
      
      if (field === "fritidsulykke_aktiv" && value === false) {
        updated.pris_fritidsulykke = null;
        updated.sum_fritidsulykke = null;
        updated.antall_fritidsulykke = null;
      }
      
      if (field === "helse_status" && value === false) {
        updated.helse_antall_aktive = null;
        updated.helseforsikring_premie = null;
      }
      
      // Auto-populate prices when insurance type is activated - ALLTID sett riktig enhetspris
      if (field === "yrkesskadeforsikring_aktiv" && value === true) {
        const price = getProductPrice('yrkesskade');
        if (price) {
          updated.pris_yrkesskadeforsikring = price;
          if (updated.antall_arsverk) {
            updated.sum_yrkesskadeforsikring = price * updated.antall_arsverk;
          }
        }
      }
      
      if (field === "cyber_aktiv" && value === true) {
        const price = getProductPrice('cyber');
        if (price) updated.pris_cyber = price;
      }
      
      if (field === "reise_aktiv" && value === true) {
        const price = getProductPrice('reise');
        if (price) {
          updated.pris_reise = price;
          if (updated.antall_reiseforsikring) {
            updated.sum_reise = price * updated.antall_reiseforsikring;
          }
        }
      }
      
      if (field === "fritidsulykke_aktiv" && value === true) {
        const price = getProductPrice('fritidsulykke');
        if (price) {
          updated.pris_fritidsulykke = price;
          if (updated.antall_fritidsulykke) {
            updated.sum_fritidsulykke = price * updated.antall_fritidsulykke;
          }
        }
      }
      
      // Auto-populate salong price when level is selected (always update on level change)
      if (field === "salong_niva" && value) {
        const price = getSalongTierPrice(value);
        if (price) updated.pris_salong = price;
      }
      
      // Also auto-populate salong price when activated and level already selected - ALLTID
      if (field === "salong_aktiv" && value === true && updated.salong_niva) {
        const price = getSalongTierPrice(updated.salong_niva);
        if (price) updated.pris_salong = price;
      }
      
      // Auto-calculate sums - ALLTID bruk faste enhetspriser ved endring av antall
      if (field === "antall_arsverk" && updated.yrkesskadeforsikring_aktiv) {
        const fixedPrice = getProductPrice('yrkesskade') || 1499;
        updated.pris_yrkesskadeforsikring = fixedPrice;
        if (value) {
          updated.sum_yrkesskadeforsikring = fixedPrice * value;
        } else {
          updated.sum_yrkesskadeforsikring = null;
        }
      }
      if (field === "antall_reiseforsikring" && updated.reise_aktiv) {
        const fixedPrice = getProductPrice('reise') || 1499;
        updated.pris_reise = fixedPrice;
        if (value) {
          updated.sum_reise = fixedPrice * value;
        } else {
          updated.sum_reise = null;
        }
      }
      if (field === "antall_fritidsulykke" && updated.fritidsulykke_aktiv) {
        const fixedPrice = getProductPrice('fritidsulykke') || 949;
        updated.pris_fritidsulykke = fixedPrice;
        if (value) {
          updated.sum_fritidsulykke = fixedPrice * value;
        } else {
          updated.sum_fritidsulykke = null;
        }
      }
      
      return updated;
    });
  };

  const addOrderItem = () => {
    setOrderItems(prev => [...prev, { productId: "", quantity: 1 }]);
  };

  const updateOrderItem = (index: number, field: keyof OrderItem, value: any) => {
    setOrderItems(prev => prev.map((item, i) => 
      i === index ? { ...item, [field]: value } : item
    ));
  };

  const removeOrderItem = (index: number) => {
    setOrderItems(prev => prev.filter((_, i) => i !== index));
  };

  // Helper functions for previous insurances
  const addPreviousInsurance = () => {
    setOrderPreviousInsurances(prev => [...prev, { company: "", policyNumber: "" }]);
  };

  const updatePreviousInsurance = (index: number, field: keyof PreviousInsurance, value: string) => {
    setOrderPreviousInsurances(prev => prev.map((item, i) => 
      i === index ? { ...item, [field]: value } : item
    ));
  };

  const removePreviousInsurance = (index: number) => {
    if (orderPreviousInsurances.length > 1) {
      setOrderPreviousInsurances(prev => prev.filter((_, i) => i !== index));
    }
  };

  // Helper function to update employee selection for an order item by index
  const handleUpdateEmployees = (itemIndex: number, employeeIds: string[]) => {
    setOrderItems(prev => prev.map((item, i) => 
      i === itemIndex 
        ? { ...item, selectedEmployees: employeeIds, quantity: employeeIds.length || 1 }
        : item
    ));
  };

  // State for personnummer per employee (for helseforsikring)
  const [orderPersonnummer, setOrderPersonnummer] = useState<Record<string, string>>({});

  const updatePersonnummer = (employeeId: string, value: string) => {
    setOrderPersonnummer(prev => ({ ...prev, [employeeId]: value }));
  };

  // Check if any health insurance product requires personnummer
  const getHealthInsuranceItems = () => {
    return orderItems.filter(item => {
      const product = products?.find(p => p.id === item.productId);
      return product?.product_type === 'helse' && product?.requires_employee_selection;
    });
  };

  // Validate personnummer for all selected health insurance employees
  const validatePersonnummer = () => {
    const healthItems = getHealthInsuranceItems();
    for (const item of healthItems) {
      for (const empId of (item.selectedEmployees || [])) {
        const pnr = orderPersonnummer[empId];
        if (!pnr || pnr.length !== 11 || !/^\d{11}$/.test(pnr)) {
          return false;
        }
      }
    }
    return true;
  };

  // Get products that require employee selection with their index
  const getProductsRequiringEmployeesWithIndex = () => {
    return orderItems.map((item, index) => ({ item, index })).filter(({ item }) => {
      const product = products?.find(p => p.id === item.productId);
      return product?.requires_employee_selection;
    });
  };

  const formatPrice = (price: number | null | undefined) => {
    if (!price) return "kr 0";
    return new Intl.NumberFormat("nb-NO", {
      style: "currency",
      currency: "NOK",
      maximumFractionDigits: 0,
    }).format(price);
  };

  const calculateOrderTotal = () => {
    let total = 0;
    for (const item of orderItems) {
      if (!item.productId) continue;
      const product = products?.find(p => p.id === item.productId);
      if (!product) continue;

      let unitPrice = product.base_price;
      let quantity = item.quantity;
      
      if (item.tierId) {
        const tier = tiers?.find(t => t.id === item.tierId);
        if (tier) unitPrice = tier.price;
      }

      // Handle per_arsverk pricing
      if (product.price_model === "per_arsverk" && orderAntallArsverk) {
        quantity = parseFloat(orderAntallArsverk);
      }

      // Handle employee selection
      if (item.selectedEmployees && item.selectedEmployees.length > 0) {
        quantity = item.selectedEmployees.length;
      }

      total += unitPrice * quantity;
    }
    return total;
  };

  const selectedSalon = salons?.find(s => s.id === selectedSalonId);

  const content = (
    <div className="space-y-6">
          {/* Salon selector */}
          <div className="space-y-2">
            <Label>Velg salong</Label>
            <Select value={selectedSalonId} onValueChange={setSelectedSalonId}>
              <SelectTrigger>
                <SelectValue placeholder="Søk eller velg salong..." />
              </SelectTrigger>
              <SelectContent>
                {salons?.map(salon => (
                  <SelectItem key={salon.id} value={salon.id}>
                    {salon.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {selectedSalon && !selectedSalon.hs_object_id && (
              <p className="text-xs text-amber-600">Denne salongen har ikke HubSpot-kobling</p>
            )}
          </div>

          {selectedSalonId && (
            <Tabs value={mode} onValueChange={(v) => setMode(v as "edit" | "order")}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="edit">
                  <Shield className="h-4 w-4 mr-2" />
                  Rediger data
                </TabsTrigger>
                <TabsTrigger value="order">
                  <Send className="h-4 w-4 mr-2" />
                  Ny bestilling
                </TabsTrigger>
              </TabsList>

              {/* EDIT MODE */}
              <TabsContent value="edit" className="space-y-6 mt-4">
                {insuranceLoading ? (
                  <div className="animate-pulse space-y-4">
                    <div className="h-20 bg-muted rounded" />
                    <div className="h-20 bg-muted rounded" />
                  </div>
                ) : (
                  <>
                    {/* Grunnlagsdata */}
                    <Card>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base flex items-center gap-2">
                          <Building2 className="h-4 w-4" />
                          Grunnlagsdata
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="grid grid-cols-3 gap-4">
                        <div className="space-y-1">
                          <Label className="text-xs">Antall ansatte</Label>
                          <Input
                            type="number"
                            value={formData.antall_ansatte || ""}
                            onChange={(e) => updateField("antall_ansatte", e.target.value ? parseInt(e.target.value) : null)}
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs">Antall årsverk</Label>
                          <Input
                            type="number"
                            step="0.1"
                            value={formData.antall_arsverk || ""}
                            onChange={(e) => updateField("antall_arsverk", e.target.value ? parseFloat(e.target.value) : null)}
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs">Årlig omsetning</Label>
                          <Input
                            type="number"
                            value={formData.arlig_omsetning || ""}
                            onChange={(e) => updateField("arlig_omsetning", e.target.value ? parseFloat(e.target.value) : null)}
                          />
                        </div>
                      </CardContent>
                    </Card>

                    {/* Forsikringsavtale */}
                    <Card>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base flex items-center gap-2">
                          <Calendar className="h-4 w-4" />
                          Forsikringsavtale
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="grid grid-cols-3 gap-4">
                        <div className="space-y-1">
                          <Label className="text-xs">Innmeldingsdato</Label>
                          <Input
                            type="date"
                            value={formData.innmelding_dato || ""}
                            onChange={(e) => updateField("innmelding_dato", e.target.value || null)}
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs">Aktiveringsdato</Label>
                          <Input
                            type="date"
                            value={formData.aktivering_dato || ""}
                            onChange={(e) => updateField("aktivering_dato", e.target.value || null)}
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs">Oppsigelsesdato</Label>
                          <Input
                            type="date"
                            value={formData.oppsigelse_dato || ""}
                            onChange={(e) => updateField("oppsigelse_dato", e.target.value || null)}
                          />
                        </div>
                      </CardContent>
                    </Card>

                    {/* Siste bestilling */}
                    <Card>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base flex items-center gap-2">
                          <ClipboardList className="h-4 w-4" />
                          Siste bestilling
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="grid grid-cols-2 gap-4">
                        <div className="space-y-1">
                          <Label className="text-xs">Bestillingsdato</Label>
                          <Input
                            type="date"
                            value={formData.bestillingsdato || ""}
                            onChange={(e) => updateField("bestillingsdato", e.target.value || null)}
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs">Oppstartsdato</Label>
                          <Input
                            type="date"
                            value={formData.oppstartsdato || ""}
                            onChange={(e) => updateField("oppstartsdato", e.target.value || null)}
                          />
                        </div>
                      </CardContent>
                    </Card>

                    {/* Forsikringstyper */}
                    <Card>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base flex items-center gap-2">
                          <Shield className="h-4 w-4" />
                          Forsikringstyper
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {/* Salongforsikring */}
                        <div className="flex items-center gap-4 p-3 border rounded-lg">
                          <Switch
                            checked={formData.salong_aktiv || false}
                            onCheckedChange={(checked) => updateField("salong_aktiv", checked)}
                          />
                          <div className="flex-1">
                            <p className="font-medium text-sm">Salongforsikring</p>
                          </div>
                          <div className="flex gap-2">
                            <Select
                              value={formData.salong_niva || ""}
                              onValueChange={(v) => updateField("salong_niva", v)}
                            >
                              <SelectTrigger className="w-24">
                                <SelectValue placeholder="Nivå" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="Nivå 1">Nivå 1</SelectItem>
                                <SelectItem value="Nivå 2">Nivå 2</SelectItem>
                                <SelectItem value="Nivå 3">Nivå 3</SelectItem>
                              </SelectContent>
                            </Select>
                            <Input
                              type="number"
                              placeholder="Pris"
                              className="w-28"
                              value={formData.pris_salong || ""}
                              onChange={(e) => updateField("pris_salong", e.target.value ? parseFloat(e.target.value) : null)}
                            />
                          </div>
                        </div>

                        {/* Yrkesskadeforsikring */}
                        <div className="flex items-center gap-4 p-3 border rounded-lg">
                          <Switch
                            checked={formData.yrkesskadeforsikring_aktiv || false}
                            onCheckedChange={(checked) => updateField("yrkesskadeforsikring_aktiv", checked)}
                          />
                          <div className="flex-1">
                            <p className="font-medium text-sm">Yrkesskadeforsikring</p>
                            <p className="text-xs text-muted-foreground">Per årsverk</p>
                          </div>
                          <div className="flex gap-2 items-center">
                            <Input
                              type="number"
                              placeholder="Pris/årsverk"
                              className="w-28"
                              value={formData.pris_yrkesskadeforsikring || ""}
                              onChange={(e) => updateField("pris_yrkesskadeforsikring", e.target.value ? parseFloat(e.target.value) : null)}
                            />
                            <span className="text-xs text-muted-foreground">
                              Sum: {formatPrice(formData.sum_yrkesskadeforsikring)}
                            </span>
                          </div>
                        </div>

                        {/* Cyberforsikring */}
                        <div className="flex items-center gap-4 p-3 border rounded-lg">
                          <Switch
                            checked={formData.cyber_aktiv || false}
                            onCheckedChange={(checked) => updateField("cyber_aktiv", checked)}
                          />
                          <div className="flex-1">
                            <p className="font-medium text-sm">Cyberforsikring</p>
                          </div>
                          <Input
                            type="number"
                            placeholder="Pris"
                            className="w-28"
                            value={formData.pris_cyber || ""}
                            onChange={(e) => updateField("pris_cyber", e.target.value ? parseFloat(e.target.value) : null)}
                          />
                        </div>

                        {/* Reiseforsikring */}
                        <div className="flex items-center gap-4 p-3 border rounded-lg">
                          <Switch
                            checked={formData.reise_aktiv || false}
                            onCheckedChange={(checked) => updateField("reise_aktiv", checked)}
                          />
                          <div className="flex-1">
                            <p className="font-medium text-sm">Reiseforsikring</p>
                            <p className="text-xs text-muted-foreground">Per person</p>
                          </div>
                          <div className="flex gap-2 items-center">
                            <Input
                              type="number"
                              placeholder="Pris"
                              className="w-24"
                              value={formData.pris_reise || ""}
                              onChange={(e) => updateField("pris_reise", e.target.value ? parseFloat(e.target.value) : null)}
                            />
                            <Input
                              type="number"
                              placeholder="Antall"
                              className="w-20"
                              value={formData.antall_reiseforsikring || ""}
                              onChange={(e) => updateField("antall_reiseforsikring", e.target.value ? parseInt(e.target.value) : null)}
                            />
                            <span className="text-xs text-muted-foreground">
                              Sum: {formatPrice(formData.sum_reise)}
                            </span>
                          </div>
                        </div>

                        {/* Fritidsulykke */}
                        <div className="flex items-center gap-4 p-3 border rounded-lg">
                          <Switch
                            checked={formData.fritidsulykke_aktiv || false}
                            onCheckedChange={(checked) => updateField("fritidsulykke_aktiv", checked)}
                          />
                          <div className="flex-1">
                            <p className="font-medium text-sm">Fritidsulykke</p>
                            <p className="text-xs text-muted-foreground">Per person</p>
                          </div>
                          <div className="flex gap-2 items-center">
                            <Input
                              type="number"
                              placeholder="Pris"
                              className="w-24"
                              value={formData.pris_fritidsulykke || ""}
                              onChange={(e) => updateField("pris_fritidsulykke", e.target.value ? parseFloat(e.target.value) : null)}
                            />
                            <Input
                              type="number"
                              placeholder="Antall"
                              className="w-20"
                              value={formData.antall_fritidsulykke || ""}
                              onChange={(e) => updateField("antall_fritidsulykke", e.target.value ? parseInt(e.target.value) : null)}
                            />
                            <span className="text-xs text-muted-foreground">
                              Sum: {formatPrice(formData.sum_fritidsulykke)}
                            </span>
                          </div>
                        </div>

                      </CardContent>
                    </Card>

                    {/* Helseforsikring sync and management */}
                    <Card>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base">Helseforsikring synkronisering</CardTitle>
                        <CardDescription>Synkroniser alle helseforsikringsfelter fra HubSpot (avtalenummer, status, oppstartsdato, oppsigelsesdato, pris)</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <Button
                          variant="outline"
                          disabled={isSyncingAvtalenummer}
                          onClick={async () => {
                            setIsSyncingAvtalenummer(true);
                            try {
                              const { data, error } = await supabase.functions.invoke('hubspot-api', {
                                body: { action: 'sync_health_insurance_fields' }
                              });
                              if (error) throw error;
                              const results = data?.results;
                              toast.success(`Synkronisert helseforsikring til ${results?.updated || 0} ansatte`);
                              queryClient.invalidateQueries({ queryKey: ["salon-employees-health"] });
                            } catch (err) {
                              console.error('Sync error:', err);
                              toast.error('Kunne ikke synkronisere helseforsikring');
                            } finally {
                              setIsSyncingAvtalenummer(false);
                            }
                          }}
                        >
                          <RefreshCw className={`h-4 w-4 mr-2 ${isSyncingAvtalenummer ? 'animate-spin' : ''}`} />
                          {isSyncingAvtalenummer ? 'Synkroniserer...' : 'Synk helseforsikring fra HubSpot'}
                        </Button>
                      </CardContent>
                    </Card>

                    <HealthInsuranceEmployeeManager
                      salonId={selectedSalonId}
                      onTotalChange={(activeCount, totalPremium) => {
                        // Update local form data for HubSpot sync
                        if (formData.helse_antall_aktive !== activeCount || formData.helseforsikring_premie !== totalPremium) {
                          setFormData(prev => ({
                            ...prev,
                            helse_antall_aktive: activeCount,
                            helseforsikring_premie: totalPremium,
                            helseforsikring_status: activeCount > 0 ? "Aktiv" : null,
                          }));
                        }
                      }}
                    />

                    {/* Kontaktinfo og bytte */}
                    <Card>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-base flex items-center gap-2">
                          <Users className="h-4 w-4" />
                          Kontakt og historikk
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-1">
                            <Label className="text-xs">Kontaktperson</Label>
                            <Input
                              value={formData.kontaktperson_navn || ""}
                              onChange={(e) => updateField("kontaktperson_navn", e.target.value || null)}
                            />
                          </div>
                          <div className="space-y-1">
                            <Label className="text-xs">E-post</Label>
                            <Input
                              type="email"
                              value={formData.kontaktperson_epost || ""}
                              onChange={(e) => updateField("kontaktperson_epost", e.target.value || null)}
                            />
                          </div>
                        </div>
                        <div className="flex items-center gap-4">
                          <Switch
                            checked={formData.bytter_selskap || false}
                            onCheckedChange={(checked) => updateField("bytter_selskap", checked)}
                          />
                          <Label>Bytter fra annet selskap</Label>
                        </div>
                        {formData.bytter_selskap && (
                          <div className="space-y-1">
                            <Label className="text-xs">Tidligere forsikringer</Label>
                            <Textarea
                              placeholder="Selskap: Polisenr&#10;Selskap: Polisenr"
                              value={formData.tidligere_forsikringer || ""}
                              onChange={(e) => updateField("tidligere_forsikringer", e.target.value || null)}
                            />
                          </div>
                        )}
                      </CardContent>
                    </Card>

                    {/* Total */}
                    <Card className="bg-muted/50">
                      <CardContent className="py-4">
                        <div className="flex justify-between items-center">
                          <span className="font-medium">Estimert årlig premie</span>
                          <span className="text-xl font-bold">{formatPrice(formData.sum_totalt)}</span>
                        </div>
                      </CardContent>
                    </Card>

                    {/* Scheduled Cancellations */}
                    <ScheduledCancellationsPanel
                      salonId={selectedSalonId}
                      activeInsurances={[
                        { type: "salong", label: "Salongforsikring", isActive: formData.salong_aktiv || false },
                        { type: "yrkesskade", label: "Yrkesskadeforsikring", isActive: formData.yrkesskadeforsikring_aktiv || false },
                        { type: "cyber", label: "Cyberforsikring", isActive: formData.cyber_aktiv || false },
                        { type: "reise", label: "Reiseforsikring", isActive: formData.reise_aktiv || false },
                        { type: "fritidsulykke", label: "Fritidsulykke", isActive: formData.fritidsulykke_aktiv || false },
                        { type: "helse", label: "Helseforsikring", isActive: formData.helse_status || false },
                      ]}
                      onCancellationScheduled={() => {
                        queryClient.invalidateQueries({ queryKey: ["salon-insurance-admin", selectedSalonId] });
                      }}
                    />

                    {/* Actions */}
                    <div className="flex gap-2 justify-end">
                      <Button variant="outline" onClick={() => onOpenChange(false)}>
                        Avbryt
                      </Button>
                      <Button onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending}>
                        <Save className="h-4 w-4 mr-2" />
                        Lagre
                      </Button>
                    </div>
                  </>
                )}
              </TabsContent>

              {/* ORDER MODE */}
              <TabsContent value="order" className="space-y-4 mt-4">
                {/* Products selection */}
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base">Produkter</CardTitle>
                    <CardDescription>Legg til produkter i bestillingen</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-end">
                      <Button variant="outline" size="sm" onClick={addOrderItem}>
                        <Plus className="h-4 w-4 mr-1" />
                        Legg til produkt
                      </Button>
                    </div>

                    {orderItems.length === 0 ? (
                      <p className="text-sm text-muted-foreground text-center py-4">
                        Klikk "Legg til produkt" for å begynne
                      </p>
                    ) : (
                      <div className="space-y-2">
                        {orderItems.map((item, index) => {
                          const product = products?.find(p => p.id === item.productId);
                          const productTiers = tiers?.filter(t => t.product_id === item.productId);
                          
                          return (
                            <div key={index} className="flex gap-2 items-center p-2 border rounded">
                              <Select
                                value={item.productId}
                                onValueChange={(v) => {
                                  const newProduct = products?.find(p => p.id === v);
                                  updateOrderItem(index, "productId", v);
                                  // Initialize selectedEmployees if product requires it
                                  if (newProduct?.requires_employee_selection) {
                                    setOrderItems(prev => prev.map((it, i) => 
                                      i === index ? { ...it, selectedEmployees: [] } : it
                                    ));
                                  }
                                }}
                              >
                                <SelectTrigger className="flex-1">
                                  <SelectValue placeholder="Velg produkt" />
                                </SelectTrigger>
                                <SelectContent>
                                  {products?.map(p => (
                                    <SelectItem key={p.id} value={p.id}>
                                      {p.name} - {formatPrice(p.base_price)}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>

                              {productTiers && productTiers.length > 0 && (
                                <Select
                                  value={item.tierId || ""}
                                  onValueChange={(v) => updateOrderItem(index, "tierId", v || undefined)}
                                >
                                  <SelectTrigger className="w-32">
                                    <SelectValue placeholder="Nivå" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {productTiers.map(t => (
                                      <SelectItem key={t.id} value={t.id}>
                                        {t.tier_name}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              )}

                              {!product?.requires_employee_selection && product?.price_model !== "per_arsverk" && (
                                <Input
                                  type="number"
                                  min="1"
                                  className="w-20"
                                  value={item.quantity}
                                  onChange={(e) => updateOrderItem(index, "quantity", parseInt(e.target.value) || 1)}
                                />
                              )}

                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => removeOrderItem(index)}
                              >
                                <X className="h-4 w-4" />
                              </Button>
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Employee selection for products that require it */}
                {getProductsRequiringEmployeesWithIndex().length > 0 && (
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base flex items-center gap-2">
                        <Users className="h-4 w-4" />
                        Velg ansatte
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {getProductsRequiringEmployeesWithIndex().map(({ item, index: itemIndex }) => {
                        const product = products?.find(p => p.id === item.productId);
                        const isHealthInsurance = product?.product_type === 'helse';
                        
                        // Count duplicates for labeling
                        const sameProductItems = orderItems.filter(o => o.productId === item.productId);
                        const productNumber = sameProductItems.length > 1 
                          ? ` (${sameProductItems.indexOf(item) + 1})`
                          : '';
                        
                        return (
                          <div key={`${item.productId}-${itemIndex}`} className="space-y-2">
                            <Label>{product?.name}{productNumber}</Label>
                            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                              {employees?.map(emp => {
                                const isSelected = item.selectedEmployees?.includes(emp.id);
                                const pnrValue = orderPersonnummer[emp.id] || "";
                                const pnrIsValid = pnrValue.length === 11 && /^\d{11}$/.test(pnrValue);
                                
                                return (
                                  <div key={emp.id} className="space-y-1">
                                    <div
                                      className={`flex items-center gap-3 p-2 border rounded cursor-pointer transition-colors text-sm ${
                                        isSelected ? "border-primary bg-primary/5" : "hover:border-primary/50"
                                      }`}
                                      onClick={() => {
                                        const newSelection = isSelected
                                          ? (item.selectedEmployees || []).filter(id => id !== emp.id)
                                          : [...(item.selectedEmployees || []), emp.id];
                                        handleUpdateEmployees(itemIndex, newSelection);
                                      }}
                                    >
                                      <Checkbox checked={isSelected} />
                                      <span>{emp.name}</span>
                                    </div>
                                    
                                    {/* Personnummer field for health insurance */}
                                    {isHealthInsurance && isSelected && (
                                      <div className="pl-2 space-y-1">
                                        <Input
                                          type="text"
                                          placeholder="Personnummer (11 siffer)"
                                          value={pnrValue}
                                          onChange={(e) => {
                                            const val = e.target.value.replace(/\D/g, '').slice(0, 11);
                                            updatePersonnummer(emp.id, val);
                                          }}
                                          className={`h-8 text-xs ${
                                            pnrValue && !pnrIsValid ? "border-destructive" : ""
                                          }`}
                                        />
                                        {pnrValue && !pnrIsValid && (
                                          <p className="text-xs text-destructive flex items-center gap-1">
                                            <AlertCircle className="h-3 w-3" />
                                            Må være 11 siffer
                                          </p>
                                        )}
                                      </div>
                                    )}
                                  </div>
                                );
                              })}
                            </div>
                            <p className="text-xs text-muted-foreground">
                              {item.selectedEmployees?.length || 0} valgt × {formatPrice(product?.base_price || 0)}
                            </p>
                            {isHealthInsurance && (
                              <p className="text-xs text-muted-foreground">
                                Personnummer kreves av Frende. Slettes automatisk etter bekreftelse.
                              </p>
                            )}
                          </div>
                        );
                      })}
                    </CardContent>
                  </Card>
                )}

                {/* Frende info */}
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base">Informasjon til Frende</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      <div className="space-y-1">
                        <Label className="text-xs">Antall ansatte *</Label>
                        <Input
                          type="number"
                          min="1"
                          value={orderAntallAnsatte}
                          onChange={(e) => setOrderAntallAnsatte(e.target.value)}
                          placeholder="f.eks. 5"
                        />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs">Antall årsverk *</Label>
                        <Input
                          type="number"
                          min="0.1"
                          step="0.1"
                          value={orderAntallArsverk}
                          onChange={(e) => setOrderAntallArsverk(e.target.value)}
                          placeholder="f.eks. 4.5"
                        />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs">Årlig omsetning</Label>
                        <Input
                          type="number"
                          min="0"
                          value={orderAarligOmsetning}
                          onChange={(e) => setOrderAarligOmsetning(e.target.value)}
                          placeholder="f.eks. 2000000"
                        />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs">Ønsket oppstart</Label>
                        <Input
                          type="date"
                          value={orderDesiredStartDate}
                          onChange={(e) => setOrderDesiredStartDate(e.target.value)}
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Switching provider */}
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base">Bytte forsikringsselskap?</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-start gap-3">
                      <Checkbox
                        id="orderSwitchingProvider"
                        checked={orderSwitchingProvider}
                        onCheckedChange={(checked) => setOrderSwitchingProvider(checked === true)}
                      />
                      <Label htmlFor="orderSwitchingProvider" className="cursor-pointer text-sm leading-relaxed">
                        Kunden bytter fra annet selskap og ønsker oppsigelse av eksisterende forsikringer
                      </Label>
                    </div>

                    {orderSwitchingProvider && (
                      <div className="space-y-3 pt-3 border-t">
                        <p className="text-xs text-muted-foreground">
                          Oppgi tidligere forsikringsselskap og polisenummer:
                        </p>
                        {orderPreviousInsurances.map((insurance, index) => (
                          <div key={index} className="flex gap-2 items-end">
                            <div className="flex-1 space-y-1">
                              <Label className="text-xs">Selskap</Label>
                              <Input
                                value={insurance.company}
                                onChange={(e) => updatePreviousInsurance(index, "company", e.target.value)}
                                placeholder="f.eks. Gjensidige"
                              />
                            </div>
                            <div className="flex-1 space-y-1">
                              <Label className="text-xs">Polisenummer</Label>
                              <Input
                                value={insurance.policyNumber}
                                onChange={(e) => updatePreviousInsurance(index, "policyNumber", e.target.value)}
                                placeholder="f.eks. 123456789"
                              />
                            </div>
                            {orderPreviousInsurances.length > 1 && (
                              <Button 
                                variant="ghost" 
                                size="icon"
                                onClick={() => removePreviousInsurance(index)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            )}
                          </div>
                        ))}
                        <Button variant="outline" size="sm" onClick={addPreviousInsurance}>
                          <Plus className="h-4 w-4 mr-1" />
                          Legg til flere
                        </Button>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Contact info */}
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base">Kontaktinformasjon</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-3 gap-3">
                      <div className="space-y-1">
                        <Label className="text-xs">Kontaktperson *</Label>
                        <Input
                          value={orderContactName}
                          onChange={(e) => setOrderContactName(e.target.value)}
                          placeholder="Navn"
                        />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs">E-post *</Label>
                        <Input
                          type="email"
                          value={orderContactEmail}
                          onChange={(e) => setOrderContactEmail(e.target.value)}
                          placeholder="e-post@eksempel.no"
                        />
                      </div>
                      <div className="space-y-1">
                        <Label className="text-xs">Telefon</Label>
                        <Input
                          value={orderContactPhone}
                          onChange={(e) => setOrderContactPhone(e.target.value)}
                          placeholder="+47 xxx xx xxx"
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* POA (optional for admin) */}
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-base flex items-center gap-2">
                      <FileSignature className="h-4 w-4" />
                      Fullmakt (valgfritt for admin)
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <p className="text-xs text-muted-foreground">
                      Hvis kunden har signert fullmakt, skriv inn navnet her:
                    </p>
                    <Input
                      value={orderSignatureName}
                      onChange={(e) => setOrderSignatureName(e.target.value)}
                      placeholder="Kundens fulle navn (valgfritt)"
                    />
                  </CardContent>
                </Card>

                {/* Terms (optional for admin) */}
                <Card>
                  <CardContent className="pt-4">
                    <div className="flex items-start gap-3">
                      <Checkbox
                        id="orderTerms"
                        checked={orderAcceptedTerms}
                        onCheckedChange={(checked) => setOrderAcceptedTerms(checked === true)}
                      />
                      <Label htmlFor="orderTerms" className="text-xs leading-relaxed cursor-pointer">
                        Bekreft at kunden har akseptert vilkårene (valgfritt for admin-bestillinger)
                      </Label>
                    </div>
                  </CardContent>
                </Card>

                {/* Order total */}
                <Card className="bg-muted/50">
                  <CardContent className="py-4">
                    <div className="flex justify-between items-center">
                      <span className="font-medium">Estimert årlig premie</span>
                      <span className="text-xl font-bold">{formatPrice(calculateOrderTotal())}</span>
                    </div>
                  </CardContent>
                </Card>

                {/* Actions */}
                <div className="flex gap-2 justify-end">
                  <Button variant="outline" onClick={() => onOpenChange(false)}>
                    Avbryt
                  </Button>
                  <Button 
                    onClick={() => createOrderMutation.mutate()} 
                    disabled={
                      createOrderMutation.isPending || 
                      orderItems.length === 0 || 
                      !orderContactName || 
                      !orderContactEmail ||
                      !orderAntallAnsatte ||
                      !orderAntallArsverk
                    }
                  >
                    <Send className="h-4 w-4 mr-2" />
                    Opprett bestilling
                  </Button>
                </div>
              </TabsContent>
            </Tabs>
          )}
    </div>
  );

  if (embedded) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Forsikringsadministrasjon</CardTitle>
          <CardDescription>
            Administrer forsikringsdata direkte eller opprett bestillinger
          </CardDescription>
        </CardHeader>
        <CardContent>{content}</CardContent>
      </Card>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Forsikringsadministrasjon</DialogTitle>
          <DialogDescription>
            Administrer forsikringsdata direkte eller opprett bestillinger
          </DialogDescription>
        </DialogHeader>
        {content}
      </DialogContent>
    </Dialog>
  );
}
