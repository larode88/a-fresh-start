import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { ArrowRight, TrendingUp, TrendingDown, Minus, Calendar } from "lucide-react";

interface ProductTier {
  id: string;
  tier_name: string;
  price: number;
}

interface InsuranceChangeDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  salonId: string;
  insuranceType: string;
  currentValues: {
    tierName?: string | null;
    tierId?: string | null;
    quantity?: number | null;
    price: number | null;
    antallAnsatte?: number | null;
  };
  onSuccess?: () => void;
}

const typeLabels: Record<string, string> = {
  salong: "Salongforsikring",
  yrkesskade: "Utvidet Yrkesskade",
  reise: "Reiseforsikring",
  fritidsulykke: "Fritidsulykke",
};

const formatPrice = (price: number) => {
  return new Intl.NumberFormat("nb-NO", {
    style: "currency",
    currency: "NOK",
    maximumFractionDigits: 0,
  }).format(price);
};

export function InsuranceChangeDialog({
  open,
  onOpenChange,
  salonId,
  insuranceType,
  currentValues,
  onSuccess,
}: InsuranceChangeDialogProps) {
  const queryClient = useQueryClient();
  const [selectedTierId, setSelectedTierId] = useState<string | null>(currentValues.tierId || null);
  const [quantity, setQuantity] = useState<number>(currentValues.quantity || 1);
  const [antallAnsatte, setAntallAnsatte] = useState<number>(currentValues.antallAnsatte || 1);
  const [desiredDate, setDesiredDate] = useState<string>("");

  // Reset state when dialog opens
  useEffect(() => {
    if (open) {
      setSelectedTierId(currentValues.tierId || null);
      const defaultQty = insuranceType === "yrkesskade" ? 0.5 : 1;
      setQuantity(currentValues.quantity || defaultQty);
      setAntallAnsatte(currentValues.antallAnsatte || 1);
      setDesiredDate("");
    }
  }, [open, currentValues, insuranceType]);

  // Fetch tiers for salong
  const { data: tiers } = useQuery({
    queryKey: ["insurance-tiers-for-change", insuranceType],
    queryFn: async () => {
      if (insuranceType !== "salong") return [];
      
      const { data: products } = await supabase
        .from("insurance_products")
        .select("id")
        .eq("product_type", "salong")
        .single();
      
      if (!products) return [];

      const { data, error } = await supabase
        .from("insurance_product_tiers")
        .select("id, tier_name, price")
        .eq("product_id", products.id)
        .order("sort_order");
      
      if (error) throw error;
      return data as ProductTier[];
    },
    enabled: open && insuranceType === "salong",
  });

  // Fetch base price for quantity-based products
  const { data: basePrice } = useQuery({
    queryKey: ["insurance-base-price", insuranceType],
    queryFn: async () => {
      const productTypeMap: Record<string, string> = {
        yrkesskade: "yrkesskade",
        reise: "reise",
        fritidsulykke: "fritidsulykke",
      };
      
      const productType = productTypeMap[insuranceType];
      if (!productType) return 0;
      
      const { data, error } = await supabase
        .from("insurance_products")
        .select("base_price")
        .eq("product_type", productType as "yrkesskade" | "reise" | "fritidsulykke")
        .single();
      
      if (error) throw error;
      return data?.base_price || 0;
    },
    enabled: open && insuranceType !== "salong",
  });

  // Calculate new price
  const calculateNewPrice = () => {
    if (insuranceType === "salong" && selectedTierId && tiers) {
      const tier = tiers.find(t => t.id === selectedTierId);
      return tier?.price || 0;
    }
    if (basePrice) {
      return basePrice * quantity;
    }
    return 0;
  };

  const newPrice = calculateNewPrice();
  const priceDifference = newPrice - (currentValues.price || 0);

  // Submit change request
  const changeMutation = useMutation({
    mutationFn: async () => {
      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) throw new Error("Not authenticated");

      // Get salon info
      const { data: salon } = await supabase
        .from("salons")
        .select("name, org_number")
        .eq("id", salonId)
        .single();

      // Get user info
      const { data: userProfile } = await supabase
        .from("users")
        .select("name, email, phone")
        .eq("id", userData.user.id)
        .single();

      // Build change details
      const changeDetails: Record<string, unknown> = {
        insurance_type: insuranceType,
      };
      const originalValues: Record<string, unknown> = {
        price: currentValues.price,
      };

      if (insuranceType === "salong") {
        const newTier = tiers?.find(t => t.id === selectedTierId);
        changeDetails.new_tier_id = selectedTierId;
        changeDetails.new_tier_name = newTier?.tier_name;
        originalValues.tier_name = currentValues.tierName;
        originalValues.tier_id = currentValues.tierId;
      } else {
        changeDetails.new_quantity = quantity;
        originalValues.quantity = currentValues.quantity;
        // For yrkesskade, include antall ansatte if changed
        if (insuranceType === "yrkesskade" && antallAnsatte !== currentValues.antallAnsatte) {
          changeDetails.new_antall_ansatte = antallAnsatte;
          originalValues.antall_ansatte = currentValues.antallAnsatte;
        }
      }

      // Create change order
      const { data: order, error } = await supabase
        .from("insurance_orders")
        .insert([{
          salon_id: salonId,
          ordered_by_user_id: userData.user.id,
          order_type: "change" as const,
          status: "pending_approval" as const,
          order_category: "bedrift",
          total_price: newPrice,
          contact_name: userProfile?.name || "",
          contact_email: userProfile?.email || userData.user.email || "",
          contact_phone: userProfile?.phone || "",
          change_details: changeDetails as unknown as undefined,
          original_values: originalValues as unknown as undefined,
          desired_start_date: desiredDate || null,
        }])
        .select()
        .single();

      if (error) throw error;

      // Send notification to admin
      try {
        await supabase.functions.invoke("send-insurance-notification", {
          body: {
            type: "change_submitted",
            recipientEmail: "forsikring@har1.no",
            recipientName: "Hår1 Forsikring",
            salonName: salon?.name || "Ukjent salong",
            orderId: order.id,
            orderTotal: newPrice,
            orderDetails: {
              insuranceType: typeLabels[insuranceType],
              originalValue: insuranceType === "salong" 
                ? `Nivå ${currentValues.tierName}` 
                : `${currentValues.quantity} ${insuranceType === "yrkesskade" ? "årsverk" : "personer"}`,
              newValue: insuranceType === "salong"
                ? `Nivå ${tiers?.find(t => t.id === selectedTierId)?.tier_name}`
                : `${quantity} ${insuranceType === "yrkesskade" ? "årsverk" : "personer"}`,
              priceDifference,
              contactName: userProfile?.name,
              contactEmail: userProfile?.email || userData.user.email,
              contactPhone: userProfile?.phone,
            },
          },
        });
      } catch (emailError) {
        console.error("Failed to send notification:", emailError);
      }

      return order;
    },
    onSuccess: () => {
      toast.success("Endringsforespørsel sendt! Vi tar kontakt med deg.");
      queryClient.invalidateQueries({ queryKey: ["insurance-orders"] });
      onOpenChange(false);
      onSuccess?.();
    },
    onError: (error) => {
      console.error("Error submitting change:", error);
      toast.error("Kunne ikke sende endringsforespørsel");
    },
  });

  const renderContent = () => {
    if (insuranceType === "salong" && tiers) {
      return (
        <div className="space-y-4">
          <Label>Velg nytt nivå</Label>
          <RadioGroup value={selectedTierId || ""} onValueChange={setSelectedTierId}>
            <div className="grid gap-3">
              {tiers.map((tier) => {
                const isCurrentTier = tier.tier_name === currentValues.tierName;
                return (
                  <div
                    key={tier.id}
                    className={`border rounded-lg p-4 cursor-pointer transition-all ${
                      selectedTierId === tier.id 
                        ? "ring-2 ring-primary border-primary" 
                        : "hover:border-primary/50"
                    } ${isCurrentTier ? "bg-muted/50" : ""}`}
                    onClick={() => setSelectedTierId(tier.id)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <RadioGroupItem value={tier.id} id={tier.id} />
                        <div>
                          <Label htmlFor={tier.id} className="font-medium cursor-pointer">
                            {tier.tier_name}
                          </Label>
                          {isCurrentTier && (
                            <Badge variant="secondary" className="ml-2 text-xs">Nåværende</Badge>
                          )}
                        </div>
                      </div>
                      <span className="font-bold">{formatPrice(tier.price)}/år</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </RadioGroup>
        </div>
      );
    }

    // Quantity-based products
    return (
      <div className="space-y-4">
        <div>
          <Label>
            {insuranceType === "yrkesskade" ? "Antall årsverk" : "Antall personer"}
          </Label>
          <div className="flex items-center gap-2 mt-2">
            <Button
              variant="outline"
              size="icon"
              onClick={() => {
                if (insuranceType === "yrkesskade") {
                  setQuantity(Math.max(0.5, quantity - 0.5));
                } else {
                  setQuantity(Math.max(1, quantity - 1));
                }
              }}
              disabled={insuranceType === "yrkesskade" ? quantity <= 0.5 : quantity <= 1}
            >
              <Minus className="h-4 w-4" />
            </Button>
            <Input
              type="number"
              min={insuranceType === "yrkesskade" ? 0.5 : 1}
              step={insuranceType === "yrkesskade" ? "0.5" : "1"}
              value={quantity}
              onChange={(e) => {
                const val = parseFloat(e.target.value);
                if (insuranceType === "yrkesskade") {
                  setQuantity(Math.max(0.5, val || 0.5));
                } else {
                  setQuantity(Math.max(1, Math.round(val) || 1));
                }
              }}
              className="w-24 text-center"
            />
            <Button
              variant="outline"
              size="icon"
              onClick={() => setQuantity(quantity + (insuranceType === "yrkesskade" ? 0.5 : 1))}
            >
              <TrendingUp className="h-4 w-4" />
            </Button>
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            Nåværende: {currentValues.quantity?.toLocaleString('nb-NO')} {insuranceType === "yrkesskade" ? "årsverk" : "personer"}
          </p>
        </div>

        {/* Antall ansatte - kun for yrkesskade */}
        {insuranceType === "yrkesskade" && (
          <div className="pt-4 border-t">
            <Label>Oppdater antall ansatte (valgfritt)</Label>
            <div className="flex items-center gap-2 mt-2">
              <Button
                variant="outline"
                size="icon"
                onClick={() => setAntallAnsatte(Math.max(1, antallAnsatte - 1))}
                disabled={antallAnsatte <= 1}
              >
                <Minus className="h-4 w-4" />
              </Button>
              <Input
                type="number"
                min={1}
                step="1"
                value={antallAnsatte}
                onChange={(e) => setAntallAnsatte(Math.max(1, parseInt(e.target.value) || 1))}
                className="w-24 text-center"
              />
              <Button
                variant="outline"
                size="icon"
                onClick={() => setAntallAnsatte(antallAnsatte + 1)}
              >
                <TrendingUp className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Nåværende: {currentValues.antallAnsatte || "-"} ansatte
            </p>
          </div>
        )}
      </div>
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Endre {typeLabels[insuranceType]}</DialogTitle>
          <DialogDescription>
            Endringer krever godkjenning og vil bli behandlet av vårt team.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {renderContent()}

          {/* Desired date */}
          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              Ønsket endringsdato (valgfritt)
            </Label>
            <Input
              type="date"
              value={desiredDate}
              onChange={(e) => setDesiredDate(e.target.value)}
              min={new Date().toISOString().split("T")[0]}
            />
          </div>

          {/* Price comparison */}
          <div className="bg-muted rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Nåværende pris</span>
              <span>{formatPrice(currentValues.price || 0)}/år</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Ny pris</span>
              <span className="font-bold">{formatPrice(newPrice)}/år</span>
            </div>
            {priceDifference !== 0 && (
              <div className="flex items-center justify-between pt-2 border-t">
                <span className="text-muted-foreground">Differanse</span>
                <div className={`flex items-center gap-1 font-medium ${
                  priceDifference > 0 ? "text-amber-600" : "text-green-600"
                }`}>
                  {priceDifference > 0 ? (
                    <TrendingUp className="h-4 w-4" />
                  ) : (
                    <TrendingDown className="h-4 w-4" />
                  )}
                  {priceDifference > 0 ? "+" : ""}{formatPrice(priceDifference)}
                </div>
              </div>
            )}
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Avbryt
          </Button>
          <Button 
            onClick={() => changeMutation.mutate()}
            disabled={changeMutation.isPending || (insuranceType === "salong" && !selectedTierId)}
          >
            {changeMutation.isPending ? "Sender..." : "Send endringsforespørsel"}
            <ArrowRight className="h-4 w-4 ml-2" />
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
