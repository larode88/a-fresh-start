import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { toast } from "sonner";
import { CalendarOff, Plus, Trash2, Clock, AlertTriangle } from "lucide-react";
import { format, isFuture, isPast, isToday } from "date-fns";
import { nb } from "date-fns/locale";

interface ScheduledCancellation {
  id: string;
  salon_id: string;
  insurance_type: string;
  cancellation_date: string;
  reason: string | null;
  scheduled_by: string | null;
  scheduled_at: string;
  processed: boolean;
  processed_at: string | null;
  hubspot_synced: boolean;
  scheduled_by_user?: {
    name: string;
    email: string;
  };
}

interface ActiveInsurance {
  type: string;
  label: string;
  isActive: boolean;
}

interface ScheduledCancellationsPanelProps {
  salonId: string;
  activeInsurances: ActiveInsurance[];
  onCancellationScheduled?: () => void;
}

const insuranceTypeLabels: Record<string, string> = {
  salong: "Salongforsikring",
  yrkesskade: "Yrkesskadeforsikring",
  cyber: "Cyberforsikring",
  reise: "Reiseforsikring",
  fritidsulykke: "Fritidsulykke",
  helse: "Helseforsikring",
};

export function ScheduledCancellationsPanel({ 
  salonId, 
  activeInsurances,
  onCancellationScheduled 
}: ScheduledCancellationsPanelProps) {
  const queryClient = useQueryClient();
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [selectedType, setSelectedType] = useState("");
  const [cancellationDate, setCancellationDate] = useState("");
  const [reason, setReason] = useState("");

  // Fetch scheduled cancellations for this salon
  const { data: scheduledCancellations, isLoading } = useQuery({
    queryKey: ["scheduled-cancellations", salonId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("insurance_scheduled_cancellations")
        .select(`
          *,
          scheduled_by_user:users!scheduled_by(name, email)
        `)
        .eq("salon_id", salonId)
        .order("cancellation_date", { ascending: true });
      if (error) throw error;
      return data as ScheduledCancellation[];
    },
    enabled: !!salonId,
  });

  // Create scheduled cancellation
  const createMutation = useMutation({
    mutationFn: async () => {
      const { data: userData } = await supabase.auth.getUser();
      const { data, error } = await supabase
        .from("insurance_scheduled_cancellations")
        .insert({
          salon_id: salonId,
          insurance_type: selectedType,
          cancellation_date: cancellationDate,
          reason: reason || null,
          scheduled_by: userData.user?.id,
        })
        .select()
        .single();
      if (error) throw error;

      // Check if the date is today or in the past - process immediately
      const selectedDate = new Date(cancellationDate);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      selectedDate.setHours(0, 0, 0, 0);

      if (selectedDate <= today) {
        // Process immediately
        const { error: processError } = await supabase.functions.invoke(
          "process-insurance-cancellations"
        );
        if (processError) {
          console.error("Error processing cancellation:", processError);
          // Don't throw - the cancellation is scheduled, just processing failed
          return { processedImmediately: false };
        }
        return { processedImmediately: true };
      }

      return { processedImmediately: false };
    },
    onSuccess: (result) => {
      if (result?.processedImmediately) {
        toast.success("Oppsigelse utført og synkronisert");
      } else {
        toast.success("Oppsigelse planlagt");
      }
      queryClient.invalidateQueries({ queryKey: ["scheduled-cancellations", salonId] });
      queryClient.invalidateQueries({ queryKey: ["salon-insurance"] });
      setShowAddDialog(false);
      setSelectedType("");
      setCancellationDate("");
      setReason("");
      onCancellationScheduled?.();
    },
    onError: (error) => {
      console.error("Error scheduling cancellation:", error);
      toast.error("Kunne ikke planlegge oppsigelse");
    },
  });

  // Delete scheduled cancellation
  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from("insurance_scheduled_cancellations")
        .delete()
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Planlagt oppsigelse kansellert");
      queryClient.invalidateQueries({ queryKey: ["scheduled-cancellations", salonId] });
    },
    onError: (error) => {
      console.error("Error deleting cancellation:", error);
      toast.error("Kunne ikke kansellere oppsigelse");
    },
  });

  // Filter out insurances that already have pending cancellations
  const pendingTypes = new Set(
    scheduledCancellations?.filter(c => !c.processed).map(c => c.insurance_type) || []
  );
  const availableForCancellation = activeInsurances.filter(
    ins => ins.isActive && !pendingTypes.has(ins.type)
  );

  const pendingCancellations = scheduledCancellations?.filter(c => !c.processed) || [];
  const processedCancellations = scheduledCancellations?.filter(c => c.processed) || [];

  const getStatusBadge = (cancellation: ScheduledCancellation) => {
    if (cancellation.processed) {
      return <Badge variant="secondary">Utført</Badge>;
    }
    const date = new Date(cancellation.cancellation_date);
    if (isPast(date) && !isToday(date)) {
      return <Badge variant="destructive">Venter på prosessering</Badge>;
    }
    if (isToday(date)) {
      return <Badge variant="default">I dag</Badge>;
    }
    return <Badge variant="outline">Planlagt</Badge>;
  };

  return (
    <>
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <CalendarOff className="h-4 w-4" />
                Planlagte oppsigelser
              </CardTitle>
              <CardDescription>
                Sett fremtidige sluttdatoer for forsikringer
              </CardDescription>
            </div>
            {availableForCancellation.length > 0 && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowAddDialog(true)}
              >
                <Plus className="h-4 w-4 mr-1" />
                Planlegg oppsigelse
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {isLoading ? (
            <p className="text-sm text-muted-foreground">Laster...</p>
          ) : pendingCancellations.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              Ingen planlagte oppsigelser
            </p>
          ) : (
            <div className="space-y-3">
              {pendingCancellations.map((cancellation) => (
                <div
                  key={cancellation.id}
                  className="flex items-center justify-between p-3 border rounded-lg"
                >
                  <div className="flex items-center gap-3">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-sm">
                          {insuranceTypeLabels[cancellation.insurance_type]}
                        </span>
                        {getStatusBadge(cancellation)}
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Sluttdato: {format(new Date(cancellation.cancellation_date), "d. MMMM yyyy", { locale: nb })}
                        {cancellation.reason && ` • ${cancellation.reason}`}
                      </p>
                      {cancellation.scheduled_by_user && (
                        <p className="text-xs text-muted-foreground">
                          Planlagt av: {cancellation.scheduled_by_user.name}
                        </p>
                      )}
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      if (confirm("Er du sikker på at du vil kansellere denne planlagte oppsigelsen?")) {
                        deleteMutation.mutate(cancellation.id);
                      }
                    }}
                    disabled={deleteMutation.isPending}
                  >
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              ))}
            </div>
          )}

          {/* Show processed cancellations history */}
          {processedCancellations.length > 0 && (
            <div className="mt-4 pt-4 border-t">
              <p className="text-xs font-medium text-muted-foreground mb-2">
                Utførte oppsigelser
              </p>
              <div className="space-y-2">
                {processedCancellations.slice(0, 3).map((cancellation) => (
                  <div
                    key={cancellation.id}
                    className="flex items-center justify-between text-sm text-muted-foreground"
                  >
                    <span>{insuranceTypeLabels[cancellation.insurance_type]}</span>
                    <span>
                      {format(new Date(cancellation.cancellation_date), "d. MMM yyyy", { locale: nb })}
                      {cancellation.hubspot_synced && (
                        <Badge variant="outline" className="ml-2 text-xs">Synket</Badge>
                      )}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Add cancellation dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Planlegg forsikringsoppsigelse</DialogTitle>
            <DialogDescription>
              Velg forsikringstype og sluttdato. Forsikringen vil automatisk deaktiveres på denne datoen.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="flex items-center gap-2 p-3 bg-amber-50 text-amber-800 rounded-lg text-sm">
              <AlertTriangle className="h-4 w-4 flex-shrink-0" />
              <span>
                {cancellationDate && new Date(cancellationDate) <= new Date(new Date().toISOString().split("T")[0])
                  ? "Oppsigelsen vil utføres umiddelbart og synkroniseres til HubSpot."
                  : "Oppsigelsen vil prosesseres automatisk kl. 00:01 på valgt dato og synkroniseres til HubSpot."}
              </span>
            </div>

            <div className="space-y-2">
              <Label>Forsikringstype</Label>
              <Select value={selectedType} onValueChange={setSelectedType}>
                <SelectTrigger>
                  <SelectValue placeholder="Velg forsikring" />
                </SelectTrigger>
                <SelectContent>
                  {availableForCancellation.map((ins) => (
                    <SelectItem key={ins.type} value={ins.type}>
                      {ins.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Sluttdato</Label>
              <Input
                type="date"
                value={cancellationDate}
                onChange={(e) => setCancellationDate(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label>Begrunnelse (valgfritt)</Label>
              <Textarea
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="F.eks. Bytte leverandør, Avslutter virksomhet..."
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddDialog(false)}>
              Avbryt
            </Button>
            <Button
              onClick={() => createMutation.mutate()}
              disabled={!selectedType || !cancellationDate || createMutation.isPending}
            >
              Planlegg oppsigelse
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
