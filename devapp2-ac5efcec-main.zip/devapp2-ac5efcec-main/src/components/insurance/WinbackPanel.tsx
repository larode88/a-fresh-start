import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { Phone, AlertTriangle, CheckCircle, XCircle, Clock } from "lucide-react";
import { format, differenceInDays } from "date-fns";
import { nb } from "date-fns/locale";

interface ScheduledCancellation {
  id: string;
  salon_id: string;
  insurance_type: string;
  cancellation_date: string;
  reason: string | null;
  scheduled_at: string;
  winback_contacted: boolean;
  winback_contacted_at: string | null;
  winback_outcome: string | null;
  salon: {
    name: string;
  };
  scheduled_by_user: {
    name: string;
    phone: string;
    email: string;
  } | null;
}

const insuranceTypeLabels: Record<string, string> = {
  salong: "Salongforsikring",
  yrkesskade: "Yrkesskadeforsikring",
  cyber: "Cyberforsikring",
  reise: "Reiseforsikring",
  fritidsulykke: "Fritidsulykke",
  helse: "Helseforsikring",
};

const outcomeLabels: Record<string, { label: string; icon: React.ReactNode; color: string }> = {
  saved: { label: "Reddet", icon: <CheckCircle className="h-4 w-4" />, color: "bg-green-100 text-green-800" },
  confirmed_cancel: { label: "Bekreftet avslutning", icon: <XCircle className="h-4 w-4" />, color: "bg-red-100 text-red-800" },
  no_response: { label: "Ikke svar", icon: <Clock className="h-4 w-4" />, color: "bg-gray-100 text-gray-800" },
};

export function WinbackPanel() {
  const queryClient = useQueryClient();

  const { data: pendingCancellations, isLoading } = useQuery({
    queryKey: ["winback-cancellations"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("insurance_scheduled_cancellations")
        .select(`
          id,
          salon_id,
          insurance_type,
          cancellation_date,
          reason,
          scheduled_at,
          winback_contacted,
          winback_contacted_at,
          winback_outcome,
          salon:salons(name),
          scheduled_by_user:users!scheduled_by(name, phone, email)
        `)
        .eq("processed", false)
        .order("cancellation_date", { ascending: true });

      if (error) throw error;
      return data as unknown as ScheduledCancellation[];
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, outcome }: { id: string; outcome: string }) => {
      const { data: userData } = await supabase.auth.getUser();
      
      const { error } = await supabase
        .from("insurance_scheduled_cancellations")
        .update({
          winback_contacted: true,
          winback_contacted_by: userData.user?.id,
          winback_contacted_at: new Date().toISOString(),
          winback_outcome: outcome,
        })
        .eq("id", id);

      if (error) throw error;

      // If saved, delete the cancellation
      if (outcome === "saved") {
        const { error: deleteError } = await supabase
          .from("insurance_scheduled_cancellations")
          .delete()
          .eq("id", id);
        
        if (deleteError) throw deleteError;
      }
    },
    onSuccess: (_, variables) => {
      if (variables.outcome === "saved") {
        toast.success("Kunde reddet! Oppsigelse kansellert.");
      } else {
        toast.success("Status oppdatert");
      }
      queryClient.invalidateQueries({ queryKey: ["winback-cancellations"] });
      queryClient.invalidateQueries({ queryKey: ["scheduled-cancellations"] });
    },
    onError: (error) => {
      console.error("Error updating winback:", error);
      toast.error("Kunne ikke oppdatere status");
    },
  });

  const urgentCancellations = pendingCancellations?.filter(c => {
    const daysUntil = differenceInDays(new Date(c.cancellation_date), new Date());
    return daysUntil <= 7 && !c.winback_contacted;
  }) || [];

  const pendingContact = pendingCancellations?.filter(c => !c.winback_contacted) || [];
  const contacted = pendingCancellations?.filter(c => c.winback_contacted) || [];

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Phone className="h-5 w-5" />
            Win-back
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground">Laster...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Phone className="h-5 w-5" />
              Win-back Dashboard
              {urgentCancellations.length > 0 && (
                <Badge variant="destructive">{urgentCancellations.length} haster</Badge>
              )}
            </CardTitle>
            <CardDescription>
              Kontakt kunder som planlegger å avslutte forsikring
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Urgent section */}
        {urgentCancellations.length > 0 && (
          <div className="space-y-3">
            <h4 className="font-medium text-destructive flex items-center gap-2">
              <AlertTriangle className="h-4 w-4" />
              Haster - Ring nå!
            </h4>
            {urgentCancellations.map((cancellation) => (
              <WinbackItem 
                key={cancellation.id} 
                cancellation={cancellation}
                onUpdate={(outcome) => updateMutation.mutate({ id: cancellation.id, outcome })}
                isUpdating={updateMutation.isPending}
                urgent
              />
            ))}
          </div>
        )}

        {/* Pending contact */}
        {pendingContact.filter(c => !urgentCancellations.includes(c)).length > 0 && (
          <div className="space-y-3">
            <h4 className="font-medium text-muted-foreground">Venter på kontakt</h4>
            {pendingContact
              .filter(c => !urgentCancellations.includes(c))
              .map((cancellation) => (
                <WinbackItem 
                  key={cancellation.id} 
                  cancellation={cancellation}
                  onUpdate={(outcome) => updateMutation.mutate({ id: cancellation.id, outcome })}
                  isUpdating={updateMutation.isPending}
                />
              ))}
          </div>
        )}

        {/* Already contacted */}
        {contacted.length > 0 && (
          <div className="space-y-3">
            <h4 className="font-medium text-muted-foreground">Kontaktet</h4>
            {contacted.map((cancellation) => (
              <WinbackItem 
                key={cancellation.id} 
                cancellation={cancellation}
                onUpdate={(outcome) => updateMutation.mutate({ id: cancellation.id, outcome })}
                isUpdating={updateMutation.isPending}
                contacted
              />
            ))}
          </div>
        )}

        {pendingCancellations?.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            <CheckCircle className="h-12 w-12 mx-auto mb-2 opacity-50" />
            <p>Ingen planlagte oppsigelser</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

interface WinbackItemProps {
  cancellation: ScheduledCancellation;
  onUpdate: (outcome: string) => void;
  isUpdating: boolean;
  urgent?: boolean;
  contacted?: boolean;
}

function WinbackItem({ cancellation, onUpdate, isUpdating, urgent, contacted }: WinbackItemProps) {
  const [selectedOutcome, setSelectedOutcome] = useState<string>("");
  const daysUntil = differenceInDays(new Date(cancellation.cancellation_date), new Date());

  return (
    <div className={`border rounded-lg p-4 ${urgent ? "border-destructive bg-destructive/5" : ""}`}>
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className="font-medium truncate">{cancellation.salon?.name}</span>
            <Badge variant="secondary" className="text-xs shrink-0">
              {insuranceTypeLabels[cancellation.insurance_type]}
            </Badge>
            {daysUntil <= 0 && (
              <Badge variant="destructive" className="text-xs">I dag!</Badge>
            )}
            {daysUntil > 0 && daysUntil <= 7 && (
              <Badge variant="outline" className="text-xs border-amber-500 text-amber-700">
                {daysUntil} dager
              </Badge>
            )}
          </div>
          
          <p className="text-sm text-muted-foreground">
            Sluttdato: {format(new Date(cancellation.cancellation_date), "d. MMMM yyyy", { locale: nb })}
          </p>
          
          {cancellation.reason && (
            <p className="text-sm text-muted-foreground">
              Begrunnelse: {cancellation.reason}
            </p>
          )}

          {cancellation.scheduled_by_user && (
            <div className="mt-2 text-sm">
              <span className="text-muted-foreground">Kontakt: </span>
              <span className="font-medium">{cancellation.scheduled_by_user.name}</span>
              {cancellation.scheduled_by_user.phone && (
                <a 
                  href={`tel:${cancellation.scheduled_by_user.phone}`}
                  className="ml-2 text-primary hover:underline"
                >
                  {cancellation.scheduled_by_user.phone}
                </a>
              )}
            </div>
          )}

          {contacted && cancellation.winback_outcome && (
            <div className="mt-2">
              <Badge className={outcomeLabels[cancellation.winback_outcome]?.color}>
                {outcomeLabels[cancellation.winback_outcome]?.icon}
                <span className="ml-1">{outcomeLabels[cancellation.winback_outcome]?.label}</span>
              </Badge>
            </div>
          )}
        </div>

        {!contacted && (
          <div className="flex items-center gap-2 shrink-0">
            {cancellation.scheduled_by_user?.phone && (
              <Button
                size="sm"
                variant={urgent ? "default" : "outline"}
                asChild
              >
                <a href={`tel:${cancellation.scheduled_by_user.phone}`}>
                  <Phone className="h-4 w-4 mr-1" />
                  Ring
                </a>
              </Button>
            )}
            
            <Select value={selectedOutcome} onValueChange={(value) => {
              setSelectedOutcome(value);
              onUpdate(value);
            }}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Utfall" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="saved">✅ Reddet</SelectItem>
                <SelectItem value="confirmed_cancel">❌ Bekreftet</SelectItem>
                <SelectItem value="no_response">⏳ Ikke svar</SelectItem>
              </SelectContent>
            </Select>
          </div>
        )}
      </div>
    </div>
  );
}
