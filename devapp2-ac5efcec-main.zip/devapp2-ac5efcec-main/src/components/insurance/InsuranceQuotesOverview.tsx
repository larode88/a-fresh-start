import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import { 
  Plus, 
  Search, 
  FileText, 
  Clock, 
  CheckCircle2, 
  XCircle,
  Send,
  ExternalLink,
  MoreHorizontal,
  Edit,
  Trash2,
  RefreshCw,
  Eye,
  Copy,
  Loader2,
  ShoppingCart,
  AlertTriangle
} from "lucide-react";

interface InsuranceQuote {
  id: string;
  salon_name: string;
  org_number: string;
  contact_name: string;
  email: string;
  total_price: number;
  status: string;
  sent_at: string | null;
  accepted_at: string | null;
  expires_at: string | null;
  completed_at: string | null;
  created_at: string;
  acceptance_token: string | null;
  link_to_fullmakt: string | null;
  district_manager: {
    first_name: string | null;
    last_name: string | null;
  } | null;
  related_order: {
    id: string;
    status: string;
  } | null;
}

const statusConfig: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline"; icon: React.ReactNode }> = {
  draft: { label: "Utkast", variant: "outline", icon: <FileText className="h-3 w-3" /> },
  sent: { label: "Sendt", variant: "secondary", icon: <Send className="h-3 w-3" /> },
  accepted: { label: "Venter på signatur", variant: "secondary", icon: <Clock className="h-3 w-3" /> },
  completed: { label: "Fullført", variant: "default", icon: <CheckCircle2 className="h-3 w-3" /> },
  expired: { label: "Utløpt", variant: "destructive", icon: <Clock className="h-3 w-3" /> },
  withdrawn: { label: "Trukket tilbake", variant: "destructive", icon: <XCircle className="h-3 w-3" /> },
};

export function InsuranceQuotesOverview() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { profile } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  
  // Action states
  const [sendingQuoteId, setSendingQuoteId] = useState<string | null>(null);
  const [withdrawingQuoteId, setWithdrawingQuoteId] = useState<string | null>(null);
  const [deletingQuoteId, setDeletingQuoteId] = useState<string | null>(null);
  
  // Confirmation dialogs
  const [withdrawDialogOpen, setWithdrawDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [selectedQuote, setSelectedQuote] = useState<InsuranceQuote | null>(null);

  const isAdmin = profile?.role === "admin";
  const isDistrictManager = profile?.role === "district_manager";

  // Fetch quotes
  const { data: quotes, isLoading, refetch } = useQuery({
    queryKey: ["insurance-quotes", profile?.id],
    queryFn: async () => {
      let query = supabase
        .from("insurance_quotes")
        .select(`
          id,
          salon_name,
          org_number,
          contact_name,
          email,
          total_price,
          status,
          sent_at,
          accepted_at,
          expires_at,
          completed_at,
          created_at,
          acceptance_token,
          link_to_fullmakt,
          district_manager:district_manager_id(first_name, last_name)
        `)
        .order("created_at", { ascending: false });

      // District managers only see their own quotes
      if (isDistrictManager && !isAdmin) {
        query = query.eq("district_manager_id", profile?.id);
      }

      const { data, error } = await query;
      if (error) throw error;

      // Fetch related orders for completed quotes
      const quoteIds = data?.map(q => q.id) || [];
      const { data: orders } = await supabase
        .from("insurance_orders")
        .select("id, status, source_quote_id")
        .in("source_quote_id", quoteIds);

      // Map orders to quotes
      const orderByQuoteId: Record<string, { id: string; status: string }> = {};
      if (orders) {
        for (const order of orders) {
          if (order.source_quote_id) {
            orderByQuoteId[order.source_quote_id] = { id: order.id, status: order.status };
          }
        }
      }

      return data?.map(q => ({
        ...q,
        related_order: orderByQuoteId[q.id] || null
      })) as InsuranceQuote[];
    },
    enabled: !!profile,
  });

  // Check if quote is expired
  const isExpired = (quote: InsuranceQuote) => {
    return quote.status === "sent" && quote.expires_at && new Date(quote.expires_at) < new Date();
  };

  // Get effective status (including expired check)
  const getEffectiveStatus = (quote: InsuranceQuote) => {
    if (isExpired(quote)) return "expired";
    return quote.status;
  };

  // Calculate stats
  const stats = {
    total: quotes?.length || 0,
    sent: quotes?.filter(q => q.status === "sent" && !isExpired(q)).length || 0,
    accepted: quotes?.filter(q => q.status === "accepted").length || 0,
    completed: quotes?.filter(q => q.status === "completed").length || 0,
    conversionRate: quotes?.length 
      ? Math.round(((quotes.filter(q => ["accepted", "completed"].includes(q.status)).length) / quotes.length) * 100)
      : 0,
  };

  // Filter quotes
  const filteredQuotes = quotes?.filter(quote => {
    const matchesSearch = 
      quote.salon_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      quote.contact_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      quote.email.toLowerCase().includes(searchQuery.toLowerCase());
    
    const effectiveStatus = getEffectiveStatus(quote);
    const matchesStatus = statusFilter === "all" || effectiveStatus === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("nb-NO", { maximumFractionDigits: 0 }).format(price);
  };

  const formatDate = (dateStr: string | null) => {
    if (!dateStr) return "-";
    return new Date(dateStr).toLocaleDateString("nb-NO", {
      day: "2-digit",
      month: "short",
      year: "numeric"
    });
  };

  const getStatusBadge = (quote: InsuranceQuote) => {
    const effectiveStatus = getEffectiveStatus(quote);
    const config = statusConfig[effectiveStatus] || statusConfig.draft;
    return (
      <Badge variant={config.variant} className="gap-1">
        {config.icon}
        {config.label}
      </Badge>
    );
  };

  // Copy acceptance link
  const copyLink = (quote: InsuranceQuote) => {
    if (!quote.acceptance_token) {
      toast.error("Tilbudet har ingen akseptlenke");
      return;
    }
    const link = `${window.location.origin}/quote/accept/${quote.acceptance_token}`;
    navigator.clipboard.writeText(link);
    toast.success("Lenke kopiert til utklippstavlen");
  };

  // Send quote (for drafts)
  const sendQuote = async (quote: InsuranceQuote) => {
    setSendingQuoteId(quote.id);
    try {
      const { error } = await supabase.functions.invoke("send-quote-email", {
        body: { quoteId: quote.id, action: "send_quote" }
      });
      if (error) throw error;
      toast.success(`Tilbud sendt til ${quote.email}`);
      refetch();
    } catch (error: any) {
      console.error("Error sending quote:", error);
      toast.error(error.message || "Kunne ikke sende tilbudet");
    } finally {
      setSendingQuoteId(null);
    }
  };

  // Resend quote
  const resendQuote = async (quote: InsuranceQuote) => {
    setSendingQuoteId(quote.id);
    try {
      const { error } = await supabase.functions.invoke("send-quote-email", {
        body: { quoteId: quote.id, action: "send_quote" }
      });
      if (error) throw error;
      toast.success(`E-post sendt på nytt til ${quote.email}`);
    } catch (error: any) {
      console.error("Error resending quote:", error);
      toast.error(error.message || "Kunne ikke sende e-post på nytt");
    } finally {
      setSendingQuoteId(null);
    }
  };

  // Withdraw quote
  const withdrawQuote = async () => {
    if (!selectedQuote) return;
    setWithdrawingQuoteId(selectedQuote.id);
    try {
      const { error } = await supabase
        .from("insurance_quotes")
        .update({ 
          status: "withdrawn" as any,
          withdrawn_at: new Date().toISOString() 
        })
        .eq("id", selectedQuote.id);
      
      if (error) throw error;
      toast.success("Tilbudet er trukket tilbake");
      refetch();
    } catch (error: any) {
      console.error("Error withdrawing quote:", error);
      toast.error("Kunne ikke trekke tilbake tilbudet");
    } finally {
      setWithdrawingQuoteId(null);
      setWithdrawDialogOpen(false);
      setSelectedQuote(null);
    }
  };

  // Delete quote
  const deleteQuote = async () => {
    if (!selectedQuote) return;
    setDeletingQuoteId(selectedQuote.id);
    try {
      const { error } = await supabase
        .from("insurance_quotes")
        .delete()
        .eq("id", selectedQuote.id);
      
      if (error) throw error;
      toast.success("Tilbudet er slettet");
      refetch();
    } catch (error: any) {
      console.error("Error deleting quote:", error);
      toast.error("Kunne ikke slette tilbudet");
    } finally {
      setDeletingQuoteId(null);
      setDeleteDialogOpen(false);
      setSelectedQuote(null);
    }
  };

  // Navigate to edit
  const editQuote = (quoteId: string) => {
    navigate(`/district/insurance/quotes/create?edit=${quoteId}`);
  };

  // Navigate to details
  const viewQuoteDetails = (quoteId: string) => {
    navigate(`/district/insurance/quotes/${quoteId}`);
  };

  // Duplicate quote (create new based on existing)
  const duplicateQuote = (quoteId: string) => {
    navigate(`/district/insurance/quotes/create?duplicate=${quoteId}`);
  };

  // Render action menu for a quote
  const renderActionMenu = (quote: InsuranceQuote) => {
    const effectiveStatus = getEffectiveStatus(quote);
    const isProcessing = sendingQuoteId === quote.id || withdrawingQuoteId === quote.id || deletingQuoteId === quote.id;

    return (
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="sm" disabled={isProcessing}>
            {isProcessing ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <MoreHorizontal className="h-4 w-4" />
            )}
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          {/* Draft actions */}
          {effectiveStatus === "draft" && (
            <>
              <DropdownMenuItem onClick={() => editQuote(quote.id)}>
                <Edit className="h-4 w-4 mr-2" />
                Rediger
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => sendQuote(quote)}>
                <Send className="h-4 w-4 mr-2" />
                Send tilbud
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem 
                className="text-destructive"
                onClick={() => {
                  setSelectedQuote(quote);
                  setDeleteDialogOpen(true);
                }}
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Slett
              </DropdownMenuItem>
            </>
          )}

          {/* Sent actions */}
          {effectiveStatus === "sent" && (
            <>
              <DropdownMenuItem onClick={() => viewQuoteDetails(quote.id)}>
                <Eye className="h-4 w-4 mr-2" />
                Se detaljer
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => resendQuote(quote)}>
                <RefreshCw className="h-4 w-4 mr-2" />
                Send på nytt
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => copyLink(quote)}>
                <Copy className="h-4 w-4 mr-2" />
                Kopier lenke
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem 
                className="text-destructive"
                onClick={() => {
                  setSelectedQuote(quote);
                  setWithdrawDialogOpen(true);
                }}
              >
                <XCircle className="h-4 w-4 mr-2" />
                Trekk tilbake
              </DropdownMenuItem>
            </>
          )}

          {/* Accepted/Completed actions */}
          {(effectiveStatus === "accepted" || effectiveStatus === "completed") && (
            <>
              <DropdownMenuItem onClick={() => viewQuoteDetails(quote.id)}>
                <Eye className="h-4 w-4 mr-2" />
                Se detaljer
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => copyLink(quote)}>
                <Copy className="h-4 w-4 mr-2" />
                Kopier lenke
              </DropdownMenuItem>
            </>
          )}

          {/* Expired/Withdrawn actions */}
          {(effectiveStatus === "expired" || effectiveStatus === "withdrawn") && (
            <>
              <DropdownMenuItem onClick={() => viewQuoteDetails(quote.id)}>
                <Eye className="h-4 w-4 mr-2" />
                Se detaljer
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => duplicateQuote(quote.id)}>
                <Copy className="h-4 w-4 mr-2" />
                Opprett ny basert på denne
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem 
                className="text-destructive"
                onClick={() => {
                  setSelectedQuote(quote);
                  setDeleteDialogOpen(true);
                }}
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Slett
              </DropdownMenuItem>
            </>
          )}
        </DropdownMenuContent>
      </DropdownMenu>
    );
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Totalt</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Sendt</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-amber-600">{stats.sent}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Akseptert</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-600">{stats.accepted}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Fullført</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats.completed}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Konvertering</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.conversionRate}%</div>
          </CardContent>
        </Card>
      </div>

      {/* Filters and actions */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between">
        <div className="flex gap-2 flex-1">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Søk etter salong eller kontakt..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Alle</SelectItem>
              <SelectItem value="draft">Utkast</SelectItem>
              <SelectItem value="sent">Sendt</SelectItem>
              <SelectItem value="accepted">Akseptert</SelectItem>
              <SelectItem value="completed">Fullført</SelectItem>
              <SelectItem value="expired">Utløpt</SelectItem>
              <SelectItem value="withdrawn">Trukket tilbake</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button onClick={() => navigate("/district/insurance/quotes/create")}>
          <Plus className="h-4 w-4 mr-2" />
          Nytt tilbud
        </Button>
      </div>

      {/* Quotes table */}
      <Card>
        <CardHeader>
          <CardTitle>Forsikringstilbud</CardTitle>
          <CardDescription>
            Oversikt over alle forsikringstilbud sendt til medlemmer
          </CardDescription>
        </CardHeader>
        <CardContent>
          {filteredQuotes && filteredQuotes.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Salong</TableHead>
                  <TableHead>Kontakt</TableHead>
                  <TableHead>Beløp</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Sendt</TableHead>
                  {isAdmin && <TableHead>Distriktsleder</TableHead>}
                  <TableHead className="text-right">Handlinger</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredQuotes.map((quote) => (
                  <TableRow key={quote.id}>
                    <TableCell className="font-medium">
                      <div>
                        <p>{quote.salon_name}</p>
                        <p className="text-xs text-muted-foreground">Org: {quote.org_number}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <p>{quote.contact_name}</p>
                        <p className="text-xs text-muted-foreground">{quote.email}</p>
                      </div>
                    </TableCell>
                    <TableCell>{formatPrice(quote.total_price)} kr</TableCell>
                    <TableCell>{getStatusBadge(quote)}</TableCell>
                    <TableCell>{formatDate(quote.sent_at)}</TableCell>
                    {isAdmin && (
                      <TableCell>
                        {quote.district_manager
                          ? `${quote.district_manager.first_name || ""} ${quote.district_manager.last_name || ""}`.trim()
                          : "-"}
                      </TableCell>
                    )}
                    <TableCell className="text-right">
                      {renderActionMenu(quote)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Ingen tilbud funnet</p>
              <Button 
                variant="link" 
                onClick={() => navigate("/district/insurance/quotes/create")}
                className="mt-2"
              >
                Opprett ditt første tilbud
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Withdraw confirmation dialog */}
      <AlertDialog open={withdrawDialogOpen} onOpenChange={setWithdrawDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Trekk tilbake tilbud</AlertDialogTitle>
            <AlertDialogDescription>
              Er du sikker på at du vil trekke tilbake tilbudet til {selectedQuote?.salon_name}? 
              Kunden vil ikke lenger kunne akseptere tilbudet.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Avbryt</AlertDialogCancel>
            <AlertDialogAction 
              onClick={withdrawQuote}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Trekk tilbake
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete confirmation dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Slett tilbud</AlertDialogTitle>
            <AlertDialogDescription>
              Er du sikker på at du vil slette tilbudet til {selectedQuote?.salon_name}? 
              Denne handlingen kan ikke angres.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Avbryt</AlertDialogCancel>
            <AlertDialogAction 
              onClick={deleteQuote}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Slett
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
