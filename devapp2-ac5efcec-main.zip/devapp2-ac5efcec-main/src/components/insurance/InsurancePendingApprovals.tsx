import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { format } from "date-fns";
import { nb } from "date-fns/locale";
import { Eye, CheckCircle, XCircle, Send, Clock, Package, FileText, Receipt, Heart, Building2, Mail, Users, ClipboardCopy, Save, CalendarIcon } from "lucide-react";
import { HealthWelcomeEmailPreview } from "./HealthWelcomeEmailPreview";

interface ChangeDetails {
  insurance_type: string;
  new_quantity?: number;
  new_tier_id?: string;
  new_tier_name?: string;
  new_antall_ansatte?: number;
  desired_date?: string;
  original_values?: {
    quantity?: number;
    tier_id?: string;
    tier_name?: string;
    price?: number;
    antall_ansatte?: number;
  };
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type JsonChangeDetails = any;

interface InsuranceOrder {
  id: string;
  salon_id: string;
  ordered_by_user_id: string;
  status: string;
  order_type: string;
  order_category: string | null;
  total_price: number;
  contact_name: string | null;
  contact_email: string | null;
  contact_phone: string | null;
  admin_notes: string | null;
  created_at: string;
  frende_transfer_date: string | null;
  invoiced_at: string | null;
  salon_address: string | null;
  salon_postal_code: string | null;
  salon_city: string | null;
  antall_ansatte: number | null;
  antall_arsverk: number | null;
  aarlig_omsetning: number | null;
  switching_provider: boolean | null;
  previous_insurances: unknown | null;
  change_details?: JsonChangeDetails;
  original_values?: JsonChangeDetails;
  salons?: {
    name: string;
    districts?: {
      name: string;
    } | null;
  };
  ordered_by?: {
    name: string;
    email: string;
  };
}

interface OrderItem {
  id: string;
  order_id: string;
  product_id: string;
  tier_id: string | null;
  quantity: number;
  unit_price: number;
  total_price: number;
  insurance_products?: {
    name: string;
  };
  insurance_product_tiers?: {
    tier_name: string;
  } | null;
}

interface SalonInsurance {
  antall_ansatte: number | null;
  antall_arsverk: number | null;
}

interface HealthEmployee {
  id: string;
  first_name: string | null;
  name: string | null;
  email: string | null;
  phone: string | null;
  personnummer: string | null;
  helseforsikring_avtalenummer: string | null;
  helseforsikring_oppstartsdato: string | null;
}

export function InsurancePendingApprovals() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [selectedOrder, setSelectedOrder] = useState<InsuranceOrder | null>(null);
  const [rejectionReason, setRejectionReason] = useState("");
  const [showRejectDialog, setShowRejectDialog] = useState(false);
  const [viewMode, setViewMode] = useState<"pending" | "processing">("pending");
  const [categoryFilter, setCategoryFilter] = useState<"all" | "bedrift" | "helse">("all");
  const [frendeTransferDate, setFrendeTransferDate] = useState("");
  const [agreementNumbers, setAgreementNumbers] = useState<Record<string, string>>({});
  const [startDates, setStartDates] = useState<Record<string, Date | undefined>>({});
  const [showEmailPreview, setShowEmailPreview] = useState(false);
  const [previewEmployee, setPreviewEmployee] = useState<HealthEmployee | null>(null);

  const { data: pendingOrders, isLoading: pendingLoading } = useQuery({
    queryKey: ["insurance-pending-orders"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("insurance_orders")
        .select(`
          *,
          salons:salon_id (
            name,
            districts:district_id (name)
          ),
          ordered_by:users!insurance_orders_ordered_by_user_id_fkey (name, email)
        `)
        .eq("status", "pending_approval")
        .order("created_at", { ascending: true });
      if (error) throw error;
      return data as InsuranceOrder[];
    }
  });

  // Processing orders: registered, sent_to_frende, approved, invoiced
  const { data: processingOrders, isLoading: processingLoading } = useQuery({
    queryKey: ["insurance-processing-orders"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("insurance_orders")
        .select(`
          *,
          salons:salon_id (
            name,
            districts:district_id (name)
          ),
          ordered_by:users!insurance_orders_ordered_by_user_id_fkey (name, email)
        `)
        .in("status", ["registered", "sent_to_frende", "approved", "invoiced"])
        .order("created_at", { ascending: true });
      if (error) throw error;
      return data as InsuranceOrder[];
    }
  });

  // Filter orders by category
  const filterByCategory = (orders: InsuranceOrder[] | undefined) => {
    if (!orders) return [];
    if (categoryFilter === "all") return orders;
    return orders.filter(o => (o.order_category || "bedrift") === categoryFilter);
  };

  const orders = filterByCategory(viewMode === "pending" ? pendingOrders : processingOrders);

  // Category counts for filter badges
  const currentOrders = viewMode === "pending" ? pendingOrders : processingOrders;
  const bedriftCount = currentOrders?.filter(o => (o.order_category || "bedrift") === "bedrift").length || 0;
  const helseCount = currentOrders?.filter(o => o.order_category === "helse").length || 0;

  const { data: orderItems } = useQuery({
    queryKey: ["insurance-order-items-pending", selectedOrder?.id],
    queryFn: async () => {
      if (!selectedOrder) return [];
      const { data, error } = await supabase
        .from("insurance_order_items")
        .select(`
          *,
          insurance_products:product_id (name),
          insurance_product_tiers:tier_id (tier_name)
        `)
        .eq("order_id", selectedOrder.id);
      if (error) throw error;
      return data as OrderItem[];
    },
    enabled: !!selectedOrder
  });

  // Fetch employees for health insurance orders (with personnummer via RPC)
  const { data: healthEmployees, isLoading: healthEmployeesLoading } = useQuery({
    queryKey: ["health-order-employees", selectedOrder?.id],
    queryFn: async () => {
      if (!selectedOrder || selectedOrder.order_category !== "helse") return [];

      // Get order item IDs
      const { data: items } = await supabase
        .from("insurance_order_items")
        .select("id")
        .eq("order_id", selectedOrder.id);

      if (!items?.length) return [];

      // Get employees via insurance_order_employees
      const { data: orderEmps } = await supabase
        .from("insurance_order_employees")
        .select("user_id")
        .in("order_item_id", items.map(i => i.id));

      if (!orderEmps?.length) return [];

      // Fetch user profiles including start date
      const { data: users } = await supabase
        .from("users")
        .select("id, first_name, name, email, phone, helseforsikring_avtalenummer, helseforsikring_oppstartsdato")
        .in("id", orderEmps.map(e => e.user_id));

      // Fetch personnummer for each user via RPC
      const employeesWithData: HealthEmployee[] = await Promise.all(
        (users || []).map(async (u) => {
          const { data: pnr } = await supabase.rpc("get_helseforsikring_personnummer", {
            p_user_id: u.id
          });
          return {
            ...u,
            personnummer: pnr || null,
            helseforsikring_oppstartsdato: u.helseforsikring_oppstartsdato || null
          };
        })
      );

      return employeesWithData;
    },
    enabled: !!selectedOrder && selectedOrder.order_category === "helse"
  });

  // Initialize agreementNumbers and startDates with existing data when healthEmployees loads
  useEffect(() => {
    if (healthEmployees && healthEmployees.length > 0) {
      const initialAgreements: Record<string, string> = {};
      const initialDates: Record<string, Date | undefined> = {};
      
      healthEmployees.forEach((emp) => {
        if (emp.helseforsikring_avtalenummer) {
          initialAgreements[emp.id] = emp.helseforsikring_avtalenummer;
        }
        if (emp.helseforsikring_oppstartsdato) {
          initialDates[emp.id] = new Date(emp.helseforsikring_oppstartsdato);
        }
      });
      
      setAgreementNumbers(prev => ({ ...initialAgreements, ...prev }));
      setStartDates(prev => ({ ...initialDates, ...prev }));
    }
  }, [healthEmployees]);

  const { data: salonInsurance } = useQuery({
    queryKey: ["salon-insurance-detail", selectedOrder?.salon_id],
    queryFn: async () => {
      if (!selectedOrder) return null;
      const { data, error } = await supabase
        .from("salon_insurance")
        .select("antall_ansatte, antall_arsverk")
        .eq("salon_id", selectedOrder.salon_id)
        .single();
      if (error && error.code !== "PGRST116") throw error;
      return data as SalonInsurance | null;
    },
    enabled: !!selectedOrder
  });

  // Frende email recipient (temporary during development)
  const FRENDE_EMAIL = "lars-ivar@har1.no";

  // Send to Frende (first step after pending_approval) - ONLY for bedrift orders
  const sendToFrendeMutation = useMutation({
    mutationFn: async (order: InsuranceOrder) => {
      // Fetch order items for the email
      const { data: items } = await supabase
        .from("insurance_order_items")
        .select(`
          quantity,
          unit_price,
          total_price,
          insurance_products(name),
          insurance_product_tiers(tier_name)
        `)
        .eq("order_id", order.id);

      // Fetch salon details
      const { data: salon } = await supabase
        .from("salons")
        .select("org_number")
        .eq("id", order.salon_id)
        .single();

      const { error } = await supabase
        .from("insurance_orders")
        .update({
          status: "sent_to_frende",
          sent_to_frende_at: new Date().toISOString()
        })
        .eq("id", order.id);
      if (error) throw error;

      // Send detailed order email TO Frende
      try {
        await supabase.functions.invoke("send-insurance-notification", {
          body: {
            type: "order_to_frende",
            orderId: order.id,
            salonName: order.salons?.name,
            recipientEmail: FRENDE_EMAIL,
            recipientName: "Frende",
            orderTotal: order.total_price,
            orderDetails: {
              salonAddress: order.salon_address,
              salonPostalCode: order.salon_postal_code,
              salonCity: order.salon_city,
              orgNumber: salon?.org_number,
              contactName: order.contact_name,
              contactEmail: order.contact_email,
              contactPhone: order.contact_phone,
              antallAnsatte: order.antall_ansatte || salonInsurance?.antall_ansatte,
              antallArsverk: order.antall_arsverk || salonInsurance?.antall_arsverk,
              aarligOmsetning: order.aarlig_omsetning,
              switchingProvider: order.switching_provider,
              previousInsurances: order.previous_insurances ? JSON.stringify(order.previous_insurances) : null,
              products: items?.map(item => ({
                name: item.insurance_products?.name || "Ukjent produkt",
                tierName: item.insurance_product_tiers?.tier_name,
                quantity: item.quantity,
                unitPrice: item.unit_price,
                totalPrice: item.total_price
              }))
            }
          }
        });
      } catch (notificationError) {
        console.error("Failed to send Frende notification:", notificationError);
        throw new Error("Kunne ikke sende e-post til Frende");
      }

      // Also send confirmation to customer
      if (order.contact_email) {
        try {
          await supabase.functions.invoke("send-insurance-notification", {
            body: {
              type: "order_sent_to_frende",
              orderId: order.id,
              salonName: order.salons?.name,
              recipientEmail: order.contact_email,
              recipientName: order.contact_name || "Kunde",
              orderTotal: order.total_price
            }
          });
        } catch (notificationError) {
          console.error("Failed to send customer notification:", notificationError);
        }
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["insurance-pending-orders"] });
      queryClient.invalidateQueries({ queryKey: ["insurance-orders"] });
      queryClient.invalidateQueries({ queryKey: ["insurance-processing-orders"] });
      queryClient.invalidateQueries({ queryKey: ["insurance-order-stats"] });
      toast.success("Bestilling sendt til Frende");
      setSelectedOrder(null);
    },
    onError: (error) => {
      toast.error(error instanceof Error ? error.message : "Kunne ikke oppdatere status");
    }
  });

  // Register in Ergo (for health insurance orders) - NO email sent
  const registerInErgoMutation = useMutation({
    mutationFn: async (order: InsuranceOrder) => {
      const { error } = await supabase
        .from("insurance_orders")
        .update({
          status: "registered",
          approved_by_user_id: user?.id,
          approved_at: new Date().toISOString()
        })
        .eq("id", order.id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["insurance-pending-orders"] });
      queryClient.invalidateQueries({ queryKey: ["insurance-orders"] });
      queryClient.invalidateQueries({ queryKey: ["insurance-processing-orders"] });
      queryClient.invalidateQueries({ queryKey: ["insurance-order-stats"] });
      toast.success("Bestilling markert som registrert i Ergo");
    },
    onError: () => {
      toast.error("Kunne ikke oppdatere status");
    }
  });

  // Save agreement numbers, start dates and complete health order
  const saveAgreementNumbersMutation = useMutation({
    mutationFn: async ({ 
      order, 
      agreements, 
      dates 
    }: { 
      order: InsuranceOrder; 
      agreements: Record<string, string>;
      dates: Record<string, Date | undefined>;
    }) => {
      // Update each employee's agreement number, start date, and clear personnummer
      for (const userId of Object.keys(agreements)) {
        const avtalenummer = agreements[userId];
        const oppstartsdato = dates[userId];
        
        if (avtalenummer?.trim()) {
          const updateData: Record<string, unknown> = { 
            helseforsikring_avtalenummer: avtalenummer.trim(),
            helseforsikring_status: 'aktiv',
            helseforsikring_personnummer: null // Explicitly clear personnummer for privacy
          };
          
          if (oppstartsdato) {
            updateData.helseforsikring_oppstartsdato = format(oppstartsdato, 'yyyy-MM-dd');
          }
          
          const { error } = await supabase
            .from("users")
            .update(updateData)
            .eq("id", userId);
          if (error) throw error;
        }
      }

      // Mark order as approved (ready for invoicing)
      const { error } = await supabase
        .from("insurance_orders")
        .update({
          status: "approved",
          approved_by_user_id: (await supabase.auth.getUser()).data.user?.id,
          approved_at: new Date().toISOString()
        })
        .eq("id", order.id);
      if (error) throw error;

      // Sync ALL health insurance employees to HubSpot (not just those with new agreement numbers)
      const allEmployeeIds = Object.keys(agreements);
      
      if (allEmployeeIds.length > 0) {
        try {
          await supabase.functions.invoke("hubspot-api", {
            body: {
              action: "sync_health_to_hubspot",
              userIds: allEmployeeIds,
              orderId: order.id
            }
          });
          console.log("Health insurance synced to HubSpot");
        } catch (syncError) {
          console.error("Failed to sync to HubSpot:", syncError);
          // Don't fail the whole operation, just log the error
        }

        // Send welcome emails to employees with new agreement numbers
        const employeesForEmail = Object.entries(agreements)
          .filter(([_, avtalenummer]) => avtalenummer?.trim())
          .map(([userId]) => ({
            userId,
            avtalenummer: agreements[userId],
            oppstartsdato: dates[userId] 
              ? format(dates[userId]!, "d. MMMM yyyy", { locale: nb })
              : ""
          }));

        if (employeesForEmail.length > 0) {
          console.log("Sending welcome emails to:", employeesForEmail);
          const { data: emailResult, error: emailError } = await supabase.functions.invoke("send-health-welcome-email", {
            body: { employees: employeesForEmail }
          });
          
          if (emailError) {
            console.error("Failed to send welcome emails:", emailError);
          } else {
            console.log("Welcome emails result:", emailResult);
          }
        }
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["insurance-pending-orders"] });
      queryClient.invalidateQueries({ queryKey: ["insurance-orders"] });
      queryClient.invalidateQueries({ queryKey: ["insurance-processing-orders"] });
      queryClient.invalidateQueries({ queryKey: ["insurance-order-stats"] });
      queryClient.invalidateQueries({ queryKey: ["health-order-employees"] });
      toast.success("Avtalenummer lagret, personnummer slettet, synkronisert til HubSpot – klar til fakturering");
      setSelectedOrder(null);
      setAgreementNumbers({});
      setStartDates({});
    },
    onError: () => {
      toast.error("Kunne ikke lagre data");
    }
  });

  // Approve (after sent_to_frende, requires frende_transfer_date)
  const approveMutation = useMutation({
    mutationFn: async ({ order, transferDate }: { order: InsuranceOrder; transferDate: string }) => {
      const { error } = await supabase
        .from("insurance_orders")
        .update({
          status: "approved",
          approved_by_user_id: user?.id,
          approved_at: new Date().toISOString(),
          frende_transfer_date: transferDate
        })
        .eq("id", order.id);
      if (error) throw error;
      if (order.contact_email) {
        try {
          await supabase.functions.invoke("send-insurance-notification", {
            body: {
              type: "order_approved",
              orderId: order.id,
              salonName: order.salons?.name,
              recipientEmail: order.contact_email,
              recipientName: order.contact_name || "Kunde",
              orderTotal: order.total_price,
              transferDate: transferDate
            }
          });
        } catch (notificationError) {
          console.error("Failed to send notification:", notificationError);
        }
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["insurance-pending-orders"] });
      queryClient.invalidateQueries({ queryKey: ["insurance-orders"] });
      queryClient.invalidateQueries({ queryKey: ["insurance-processing-orders"] });
      queryClient.invalidateQueries({ queryKey: ["insurance-order-stats"] });
      toast.success("Bestilling godkjent med overføringsdato");
      setSelectedOrder(null);
      setFrendeTransferDate("");
    },
    onError: () => {
      toast.error("Kunne ikke godkjenne bestilling");
    }
  });

  // Mark as invoiced
  const invoicedMutation = useMutation({
    mutationFn: async (order: InsuranceOrder) => {
      const { error } = await supabase
        .from("insurance_orders")
        .update({
          status: "invoiced",
          invoiced_at: new Date().toISOString()
        })
        .eq("id", order.id);
      if (error) throw error;
      if (order.contact_email) {
        try {
          await supabase.functions.invoke("send-insurance-notification", {
            body: {
              type: "order_invoiced",
              orderId: order.id,
              salonName: order.salons?.name,
              recipientEmail: order.contact_email,
              recipientName: order.contact_name || "Kunde",
              orderTotal: order.total_price
            }
          });
        } catch (notificationError) {
          console.error("Failed to send notification:", notificationError);
        }
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["insurance-orders"] });
      queryClient.invalidateQueries({ queryKey: ["insurance-processing-orders"] });
      queryClient.invalidateQueries({ queryKey: ["insurance-order-stats"] });
      toast.success("Bestilling markert som fakturert");
      setSelectedOrder(null);
    },
    onError: () => {
      toast.error("Kunne ikke oppdatere status");
    }
  });

  // Complete order (final step)
  const completeMutation = useMutation({
    mutationFn: async (order: InsuranceOrder) => {
      const { error } = await supabase
        .from("insurance_orders")
        .update({
          status: "completed",
          completed_at: new Date().toISOString()
        })
        .eq("id", order.id);
      if (error) throw error;
      if (order.contact_email) {
        try {
          await supabase.functions.invoke("send-insurance-notification", {
            body: {
              type: "order_completed",
              orderId: order.id,
              salonName: order.salons?.name,
              recipientEmail: order.contact_email,
              recipientName: order.contact_name || "Kunde",
              orderTotal: order.total_price
            }
          });
        } catch (notificationError) {
          console.error("Failed to send notification:", notificationError);
        }
      }

      // Sync completed order to HubSpot
      try {
        const response = await supabase.functions.invoke("hubspot-api", {
          body: {
            action: "sync_completed_order",
            orderId: order.id
          }
        });
        if (response.data?.success) {
          console.log("HubSpot sync successful:", response.data);
        } else {
          console.log("HubSpot sync skipped:", response.data?.message);
        }
      } catch (hubspotError) {
        console.error("Failed to sync to HubSpot:", hubspotError);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["insurance-pending-orders"] });
      queryClient.invalidateQueries({ queryKey: ["insurance-orders"] });
      queryClient.invalidateQueries({ queryKey: ["insurance-processing-orders"] });
      queryClient.invalidateQueries({ queryKey: ["insurance-order-stats"] });
      queryClient.invalidateQueries({ queryKey: ["salon-insurance"] });
      toast.success("Bestilling fullført og synkronisert");
      setSelectedOrder(null);
    },
    onError: () => {
      toast.error("Kunne ikke fullføre bestilling");
    }
  });

  const rejectMutation = useMutation({
    mutationFn: async ({ order, reason }: { order: InsuranceOrder; reason: string }) => {
      const { error } = await supabase
        .from("insurance_orders")
        .update({
          status: "rejected",
          rejection_reason: reason,
          approved_by_user_id: user?.id,
          approved_at: new Date().toISOString()
        })
        .eq("id", order.id);
      if (error) throw error;
      if (order.contact_email) {
        try {
          await supabase.functions.invoke("send-insurance-notification", {
            body: {
              type: "order_rejected",
              orderId: order.id,
              salonName: order.salons?.name,
              recipientEmail: order.contact_email,
              recipientName: order.contact_name || "Kunde",
              rejectionReason: reason
            }
          });
        } catch (notificationError) {
          console.error("Failed to send notification:", notificationError);
        }
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["insurance-pending-orders"] });
      queryClient.invalidateQueries({ queryKey: ["insurance-orders"] });
      queryClient.invalidateQueries({ queryKey: ["insurance-order-stats"] });
      toast.success("Bestilling avvist");
      setSelectedOrder(null);
      setShowRejectDialog(false);
      setRejectionReason("");
    },
    onError: () => {
      toast.error("Kunne ikke avvise bestilling");
    }
  });

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("nb-NO", {
      style: "currency",
      currency: "NOK",
      maximumFractionDigits: 0
    }).format(price);
  };

  const pendingCount = pendingOrders?.length || 0;
  const processingCount = processingOrders?.length || 0;

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending_approval":
        return <Badge variant="outline">Venter på behandling</Badge>;
      case "registered":
        return <Badge className="bg-violet-100 text-violet-700 border-violet-200 hover:bg-violet-100">Registrert i Ergo</Badge>;
      case "sent_to_frende":
        return <Badge variant="secondary">Sendt til Frende</Badge>;
      case "approved":
        return <Badge className="bg-blue-100 text-blue-700 border-blue-200 hover:bg-blue-100">Godkjent</Badge>;
      case "invoiced":
        return <Badge className="bg-amber-100 text-amber-700 border-amber-200 hover:bg-amber-100">Fakturert</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  // Helper for change details display
  const changeTypeLabels: Record<string, string> = {
    salong: "Salongforsikring",
    yrkesskade: "Yrkesskade",
    reise: "Reiseforsikring",
    fritidsulykke: "Fritidsulykke",
  };

  const formatChangeValue = (values: { quantity?: number; tier_name?: string } | undefined, insuranceType: string) => {
    if (!values) return "-";
    if (values.tier_name) return values.tier_name;
    if (values.quantity !== undefined) {
      return `${values.quantity.toLocaleString('nb-NO')} ${insuranceType === 'yrkesskade' ? 'årsverk' : 'personer'}`;
    }
    return "-";
  };

  const getChangeDetails = (): ChangeDetails | null => {
    if (!selectedOrder?.change_details) return null;
    const changeDetails = selectedOrder.change_details as ChangeDetails;
    // Hent original_values fra separat felt hvis ikke i change_details
    if (!changeDetails.original_values && selectedOrder.original_values) {
      changeDetails.original_values = selectedOrder.original_values;
    }
    return changeDetails;
  };

  // Helper to get last name
  const getLastName = (fullName: string | null, firstName: string | null) => {
    if (!fullName) return "-";
    if (firstName && fullName.startsWith(firstName)) {
      return fullName.slice(firstName.length).trim() || "-";
    }
    const parts = fullName.split(" ");
    return parts.length > 1 ? parts.slice(1).join(" ") : "-";
  };

  // Copy employee data to clipboard
  const copyEmployeeData = (emp: HealthEmployee) => {
    const firstName = emp.first_name || emp.name?.split(" ")[0] || "";
    const lastName = getLastName(emp.name, emp.first_name);
    const data = `${firstName}\t${lastName}\t${emp.personnummer || ""}\t${emp.email || ""}\t${emp.phone || ""}`;
    navigator.clipboard.writeText(data);
    toast.success("Data kopiert til utklippstavle");
  };

  // Check if all agreement numbers are filled (either in state or database)
  const allAgreementNumbersFilled = healthEmployees?.every(emp => {
    const stateValue = agreementNumbers[emp.id];
    // If we have a value in state, use that; otherwise check existing db value
    const value = stateValue !== undefined ? stateValue : emp.helseforsikring_avtalenummer;
    return value?.trim();
  });

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Package className="h-5 w-5" />
            Bestillinger
          </CardTitle>
          <CardDescription>Behandle og administrer forsikringsbestillinger</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={viewMode} onValueChange={(v) => setViewMode(v as "pending" | "processing")}>
            <div className="flex flex-wrap items-center gap-4 mb-4">
              <TabsList>
                <TabsTrigger value="pending" className="relative">
                  <Clock className="h-4 w-4 mr-2" />
                  Ventende
                  {pendingCount > 0 && (
                    <Badge variant="destructive" className="ml-2 h-5 w-5 p-0 flex items-center justify-center text-xs">
                      {pendingCount}
                    </Badge>
                  )}
                </TabsTrigger>
                <TabsTrigger value="processing" className="relative">
                  <FileText className="h-4 w-4 mr-2" />
                  Under behandling
                  {processingCount > 0 && (
                    <Badge variant="secondary" className="ml-2 h-5 min-w-5 px-1 flex items-center justify-center text-xs">
                      {processingCount}
                    </Badge>
                  )}
                </TabsTrigger>
              </TabsList>

              {/* Category filter */}
              <div className="flex items-center gap-2 border rounded-lg p-1">
                <Button
                  variant={categoryFilter === "all" ? "secondary" : "ghost"}
                  size="sm"
                  onClick={() => setCategoryFilter("all")}
                >
                  Alle
                </Button>
                <Button
                  variant={categoryFilter === "bedrift" ? "secondary" : "ghost"}
                  size="sm"
                  onClick={() => setCategoryFilter("bedrift")}
                  className="gap-1"
                >
                  <Building2 className="h-3 w-3" />
                  Bedrift
                  {bedriftCount > 0 && (
                    <Badge variant="outline" className="ml-1 h-4 px-1 text-xs">{bedriftCount}</Badge>
                  )}
                </Button>
                <Button
                  variant={categoryFilter === "helse" ? "secondary" : "ghost"}
                  size="sm"
                  onClick={() => setCategoryFilter("helse")}
                  className="gap-1"
                >
                  <Heart className="h-3 w-3" />
                  Helse
                  {helseCount > 0 && (
                    <Badge variant="outline" className="ml-1 h-4 px-1 text-xs">{helseCount}</Badge>
                  )}
                </Button>
              </div>
            </div>

            <TabsContent value="pending">
              {pendingLoading ? (
                <div className="text-center py-8 text-muted-foreground">Laster bestillinger...</div>
              ) : orders.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <CheckCircle className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p>Ingen ventende bestillinger</p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Salong</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Distrikt</TableHead>
                      <TableHead>Bestilt av</TableHead>
                      <TableHead>Dato</TableHead>
                      <TableHead className="text-right">Beløp</TableHead>
                      <TableHead></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {orders.map((order) => (
                      <TableRow key={order.id}>
                        <TableCell className="font-medium">{order.salons?.name}</TableCell>
                        <TableCell>
                          {order.order_category === "helse" ? (
                            <Badge variant="outline" className="gap-1"><Heart className="h-3 w-3" />Helse</Badge>
                          ) : (
                            <Badge variant="outline" className="gap-1"><Building2 className="h-3 w-3" />Bedrift</Badge>
                          )}
                        </TableCell>
                        <TableCell>{getStatusBadge(order.status)}</TableCell>
                        <TableCell>{order.salons?.districts?.name || "-"}</TableCell>
                        <TableCell>{order.ordered_by?.name}</TableCell>
                        <TableCell>{format(new Date(order.created_at), "d. MMM yyyy", { locale: nb })}</TableCell>
                        <TableCell className="text-right font-medium">{formatPrice(order.total_price)}</TableCell>
                        <TableCell>
                          <Button variant="ghost" size="sm" onClick={() => setSelectedOrder(order)}>
                            <Eye className="h-4 w-4 mr-1" />
                            Behandle
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </TabsContent>

            <TabsContent value="processing">
              {processingLoading ? (
                <div className="text-center py-8 text-muted-foreground">Laster bestillinger...</div>
              ) : orders.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <FileText className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p>Ingen bestillinger under behandling</p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Salong</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Bestilt av</TableHead>
                      <TableHead>Dato</TableHead>
                      <TableHead className="text-right">Beløp</TableHead>
                      <TableHead></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {orders.map((order) => (
                      <TableRow key={order.id}>
                        <TableCell className="font-medium">{order.salons?.name}</TableCell>
                        <TableCell>
                          {order.order_category === "helse" ? (
                            <Badge variant="outline" className="gap-1"><Heart className="h-3 w-3" />Helse</Badge>
                          ) : (
                            <Badge variant="outline" className="gap-1"><Building2 className="h-3 w-3" />Bedrift</Badge>
                          )}
                        </TableCell>
                        <TableCell>{getStatusBadge(order.status)}</TableCell>
                        <TableCell>{order.ordered_by?.name}</TableCell>
                        <TableCell>{format(new Date(order.created_at), "d. MMM yyyy", { locale: nb })}</TableCell>
                        <TableCell className="text-right font-medium">{formatPrice(order.total_price)}</TableCell>
                        <TableCell>
                          <Button variant="ghost" size="sm" onClick={() => setSelectedOrder(order)}>
                            <Eye className="h-4 w-4 mr-1" />
                            Detaljer
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Order detail & approval dialog */}
      <Dialog open={!!selectedOrder && !showRejectDialog} onOpenChange={() => setSelectedOrder(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {selectedOrder?.order_category === "helse" ? (
                <Heart className="h-5 w-5 text-pink-500" />
              ) : (
                <Building2 className="h-5 w-5" />
              )}
              {selectedOrder?.status === "pending_approval" ? "Behandle bestilling" : 
               selectedOrder?.status === "registered" ? "Registrer avtalenummer" : "Bestillingsdetaljer"}
            </DialogTitle>
          </DialogHeader>

          {selectedOrder && (
            <div className="space-y-6">
              {/* Salon info */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 bg-muted rounded-lg">
                <div>
                  <p className="text-sm text-muted-foreground">Salong</p>
                  <p className="font-medium">{selectedOrder.salons?.name}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Distrikt</p>
                  <p className="font-medium">{selectedOrder.salons?.districts?.name || "-"}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Antall ansatte</p>
                  <p className="font-medium">{salonInsurance?.antall_ansatte || "-"}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Årsverk</p>
                  <p className="font-medium">{salonInsurance?.antall_arsverk || "-"}</p>
                </div>
              </div>

              {/* Contact info */}
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Bestilt av</p>
                  <p className="font-medium">{selectedOrder.ordered_by?.name}</p>
                  <p className="text-sm text-muted-foreground">{selectedOrder.ordered_by?.email}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Kontaktperson</p>
                  <p className="font-medium">{selectedOrder.contact_name || "-"}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">E-post for kvittering</p>
                  <p className="font-medium">{selectedOrder.contact_email || "-"}</p>
                </div>
              </div>

              {/* Health insurance employee details - for Ergo registration */}
              {selectedOrder.order_category === "helse" && (
                <div className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="font-medium flex items-center gap-2">
                      <Users className="h-4 w-4" />
                      Ansatte for registrering i Ergo ({healthEmployees?.length || 0})
                    </h4>
                    {selectedOrder.status === "registered" && (
                      <Badge className="bg-violet-100 text-violet-700 border-violet-200">Venter på avtalenummer</Badge>
                    )}
                  </div>

                  {healthEmployeesLoading ? (
                    <div className="text-center py-4 text-muted-foreground">Laster ansattdata...</div>
                  ) : healthEmployees && healthEmployees.length > 0 ? (
                    <div className="grid gap-3">
                      {healthEmployees.map((emp) => {
                        const firstName = emp.first_name || emp.name?.split(" ")[0] || "";
                        const lastName = getLastName(emp.name, emp.first_name);
                        
                        return (
                          <div key={emp.id} className="flex flex-col sm:flex-row gap-3 p-3 bg-muted/50 rounded-lg border">
                            {/* Employee info - left section */}
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="font-medium truncate">{firstName} {lastName}</span>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-6 w-6 flex-shrink-0"
                                  onClick={() => copyEmployeeData(emp)}
                                  title="Kopier all data"
                                >
                                  <ClipboardCopy className="h-3 w-3" />
                                </Button>
                              </div>
                              <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted-foreground">
                                <span className="font-mono">{emp.personnummer || "Mangler pnr"}</span>
                                <span className="truncate">{emp.email}</span>
                                <span>{emp.phone}</span>
                              </div>
                            </div>
                            
                            {/* Input fields - right section */}
                            {selectedOrder.status === "registered" && (
                              <div className="flex flex-col sm:flex-row gap-2 sm:items-center flex-shrink-0">
                                <div className="flex flex-col gap-1">
                                  <Label className="text-xs text-muted-foreground">Avtalenummer</Label>
                                  <Input
                                    placeholder="F.eks. 13251479"
                                    value={agreementNumbers[emp.id] ?? emp.helseforsikring_avtalenummer ?? ""}
                                    onChange={(e) => setAgreementNumbers(prev => ({
                                      ...prev,
                                      [emp.id]: e.target.value
                                    }))}
                                    className="w-full sm:w-[130px] h-9"
                                  />
                                </div>
                                <div className="flex flex-col gap-1">
                                  <Label className="text-xs text-muted-foreground">Oppstartsdato</Label>
                                  <Popover>
                                    <PopoverTrigger asChild>
                                      <Button
                                        variant="outline"
                                        className={cn(
                                          "w-full sm:w-[140px] h-9 justify-start text-left font-normal",
                                          !startDates[emp.id] && !emp.helseforsikring_oppstartsdato && "text-muted-foreground"
                                        )}
                                      >
                                        <CalendarIcon className="mr-2 h-4 w-4 flex-shrink-0" />
                                        {startDates[emp.id] 
                                          ? format(startDates[emp.id]!, "dd.MM.yyyy")
                                          : emp.helseforsikring_oppstartsdato
                                            ? format(new Date(emp.helseforsikring_oppstartsdato), "dd.MM.yyyy")
                                            : "Velg dato"
                                        }
                                      </Button>
                                    </PopoverTrigger>
                                    <PopoverContent className="w-auto p-0 z-50" align="end" side="bottom">
                                      <Calendar
                                        mode="single"
                                        selected={startDates[emp.id] || (emp.helseforsikring_oppstartsdato ? new Date(emp.helseforsikring_oppstartsdato) : undefined)}
                                        onSelect={(date) => setStartDates(prev => ({
                                          ...prev,
                                          [emp.id]: date
                                        }))}
                                        initialFocus
                                        className={cn("p-3 pointer-events-auto")}
                                        locale={nb}
                                      />
                                    </PopoverContent>
                                  </Popover>
                                </div>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-9 w-9 flex-shrink-0"
                                  onClick={() => {
                                    setPreviewEmployee(emp);
                                    setShowEmailPreview(true);
                                  }}
                                  title="Forhåndsvis velkomst-e-post"
                                >
                                  <Mail className="h-4 w-4" />
                                </Button>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="text-center py-4 text-muted-foreground">
                      Ingen ansatte tilknyttet bestillingen
                    </div>
                  )}
                </div>
              )}

              {/* Order items or Change details */}
              {selectedOrder.order_type === "change" ? (
                <div className="space-y-4">
                  <h4 className="font-medium mb-3">Endringsdetaljer</h4>
                  {(() => {
                    const changeDetails = getChangeDetails();
                    if (!changeDetails) return <p className="text-muted-foreground">Ingen endringsdetaljer tilgjengelig</p>;
                    
                      return (
                      <div className="p-4 border rounded-lg bg-muted/50">
                        <p className="text-sm font-medium mb-3">
                          {changeTypeLabels[changeDetails.insurance_type] || changeDetails.insurance_type}
                        </p>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <p className="text-xs text-muted-foreground">Nåværende</p>
                            <p className="font-medium">
                              {formatChangeValue(changeDetails.original_values, changeDetails.insurance_type)}
                            </p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground">Ny verdi</p>
                            <p className="font-medium text-primary">
                              {formatChangeValue(
                                { quantity: changeDetails.new_quantity, tier_name: changeDetails.new_tier_name },
                                changeDetails.insurance_type
                              )}
                            </p>
                          </div>
                        </div>
                        {/* Vis endring av antall ansatte hvis det er med */}
                        {changeDetails.new_antall_ansatte !== undefined && 
                         changeDetails.new_antall_ansatte !== changeDetails.original_values?.antall_ansatte && (
                          <div className="grid grid-cols-2 gap-4 mt-3 pt-3 border-t">
                            <div>
                              <p className="text-xs text-muted-foreground">Antall ansatte - Nåværende</p>
                              <p className="font-medium">{changeDetails.original_values?.antall_ansatte ?? "-"}</p>
                            </div>
                            <div>
                              <p className="text-xs text-muted-foreground">Antall ansatte - Ny verdi</p>
                              <p className="font-medium text-primary">{changeDetails.new_antall_ansatte}</p>
                            </div>
                          </div>
                        )}
                        {changeDetails.desired_date && (
                          <p className="text-sm mt-3 pt-3 border-t">
                            <span className="text-muted-foreground">Ønsket endringsdato:</span>{" "}
                            {format(new Date(changeDetails.desired_date), "d. MMMM yyyy", { locale: nb })}
                          </p>
                        )}
                      </div>
                    );
                  })()}

                  <div className="flex justify-end mt-4 pt-4 border-t">
                    <div className="text-right">
                      <p className="text-sm text-muted-foreground">Differanse årlig premie</p>
                      <p className="text-3xl font-bold">{formatPrice(selectedOrder.total_price)}</p>
                    </div>
                  </div>
                </div>
              ) : (
                <div>
                  <h4 className="font-medium mb-3">Bestilte produkter</h4>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Produkt</TableHead>
                        <TableHead className="text-center">Antall</TableHead>
                        <TableHead className="text-right">Enhetspris</TableHead>
                        <TableHead className="text-right">Total</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {orderItems?.map(item => (
                        <TableRow key={item.id}>
                          <TableCell>
                            <div>
                              <p className="font-medium">{item.insurance_products?.name}</p>
                              {item.insurance_product_tiers && (
                                <p className="text-sm text-muted-foreground">
                                  {item.insurance_product_tiers.tier_name}
                                </p>
                              )}
                            </div>
                          </TableCell>
                          <TableCell className="text-center">{item.quantity}</TableCell>
                          <TableCell className="text-right">{formatPrice(item.unit_price)}</TableCell>
                          <TableCell className="text-right font-medium">{formatPrice(item.total_price)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>

                  <div className="flex justify-end mt-4 pt-4 border-t">
                    <div className="text-right">
                      <p className="text-sm text-muted-foreground">Total årlig premie</p>
                      <p className="text-3xl font-bold">{formatPrice(selectedOrder.total_price)}</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Frende transfer date input for sent_to_frende status (bedrift only) */}
              {selectedOrder.status === "sent_to_frende" && selectedOrder.order_category !== "helse" && (
                <div className="p-4 border rounded-lg bg-muted/50">
                  <Label htmlFor="frende-transfer-date" className="text-sm font-medium">
                    Overføringsdato fra Frende
                  </Label>
                  <p className="text-xs text-muted-foreground mb-2">
                    Angi datoen forsikringen blir aktiv/overført fra Frende
                  </p>
                  <Input
                    id="frende-transfer-date"
                    type="date"
                    value={frendeTransferDate}
                    onChange={e => setFrendeTransferDate(e.target.value)}
                    className="max-w-xs"
                  />
                </div>
              )}

              {/* Show transfer date if approved */}
              {selectedOrder.frende_transfer_date && (
                <p className="text-sm text-muted-foreground">
                  Overføringsdato: {format(new Date(selectedOrder.frende_transfer_date), "d. MMMM yyyy", { locale: nb })}
                </p>
              )}

              {/* Show invoiced date if invoiced */}
              {selectedOrder.invoiced_at && (
                <p className="text-sm text-muted-foreground">
                  Fakturert: {format(new Date(selectedOrder.invoiced_at), "d. MMMM yyyy", { locale: nb })}
                </p>
              )}

              <DialogFooter className="flex-col sm:flex-row gap-2">
                {/* pending_approval: Different actions for bedrift vs helse */}
                {selectedOrder.status === "pending_approval" && (
                  <>
                    <Button
                      variant="destructive"
                      onClick={() => setShowRejectDialog(true)}
                      disabled={rejectMutation.isPending}
                    >
                      <XCircle className="h-4 w-4 mr-2" />
                      Avvis
                    </Button>

                    {/* Bedrift: Send to Frende */}
                    {selectedOrder.order_category !== "helse" && (
                      <Button
                        onClick={() => sendToFrendeMutation.mutate(selectedOrder)}
                        disabled={sendToFrendeMutation.isPending}
                      >
                        <Send className="h-4 w-4 mr-2" />
                        Send til Frende
                      </Button>
                    )}

                    {/* Helse: Register in Ergo (no email) */}
                    {selectedOrder.order_category === "helse" && (
                      <Button
                        onClick={() => registerInErgoMutation.mutate(selectedOrder)}
                        disabled={registerInErgoMutation.isPending}
                        className="bg-purple-600 hover:bg-purple-700"
                      >
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Registrer i Ergo
                      </Button>
                    )}
                  </>
                )}

                {/* registered (helse only): Save agreement numbers and start dates */}
                {selectedOrder.status === "registered" && selectedOrder.order_category === "helse" && (
                  <Button
                    onClick={() => saveAgreementNumbersMutation.mutate({
                      order: selectedOrder,
                      agreements: agreementNumbers,
                      dates: startDates
                    })}
                    disabled={saveAgreementNumbersMutation.isPending || !allAgreementNumbersFilled}
                  >
                    <Save className="h-4 w-4 mr-2" />
                    Lagre og fullfør
                  </Button>
                )}

                {/* sent_to_frende: Resend email + Approve with transfer date */}
                {selectedOrder.status === "sent_to_frende" && (
                  <>
                    <Button
                      variant="outline"
                      onClick={async () => {
                        try {
                          const { data: items } = await supabase
                            .from("insurance_order_items")
                            .select(`
                              quantity,
                              unit_price,
                              total_price,
                              insurance_products(name),
                              insurance_product_tiers(tier_name)
                            `)
                            .eq("order_id", selectedOrder.id);

                          const { data: salon } = await supabase
                            .from("salons")
                            .select("org_number")
                            .eq("id", selectedOrder.salon_id)
                            .single();

                          await supabase.functions.invoke("send-insurance-notification", {
                            body: {
                              type: "order_to_frende",
                              orderId: selectedOrder.id,
                              salonName: selectedOrder.salons?.name,
                              recipientEmail: FRENDE_EMAIL,
                              recipientName: "Frende",
                              orderTotal: selectedOrder.total_price,
                              orderDetails: {
                                salonAddress: selectedOrder.salon_address,
                                salonPostalCode: selectedOrder.salon_postal_code,
                                salonCity: selectedOrder.salon_city,
                                orgNumber: salon?.org_number,
                                contactName: selectedOrder.contact_name,
                                contactEmail: selectedOrder.contact_email,
                                contactPhone: selectedOrder.contact_phone,
                                antallAnsatte: selectedOrder.antall_ansatte,
                                antallArsverk: selectedOrder.antall_arsverk,
                                aarligOmsetning: selectedOrder.aarlig_omsetning,
                                switchingProvider: selectedOrder.switching_provider,
                                previousInsurances: selectedOrder.previous_insurances ? JSON.stringify(selectedOrder.previous_insurances) : null,
                                products: items?.map(item => ({
                                  name: (item.insurance_products as any)?.name || "Ukjent produkt",
                                  tierName: (item.insurance_product_tiers as any)?.tier_name,
                                  quantity: item.quantity,
                                  unitPrice: item.unit_price,
                                  totalPrice: item.total_price
                                }))
                              }
                            }
                          });
                          toast.success("E-post sendt til Frende");
                        } catch (error) {
                          console.error("Failed to resend Frende notification:", error);
                          toast.error("Kunne ikke sende e-post");
                        }
                      }}
                    >
                      <Mail className="h-4 w-4 mr-2" />
                      Send e-post på nytt
                    </Button>
                    <Button
                      onClick={() => approveMutation.mutate({
                        order: selectedOrder,
                        transferDate: frendeTransferDate
                      })}
                      disabled={approveMutation.isPending || !frendeTransferDate}
                    >
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Merk godkjent
                    </Button>
                  </>
                )}

                {/* approved: Mark as invoiced */}
                {selectedOrder.status === "approved" && (
                  <Button
                    onClick={() => invoicedMutation.mutate(selectedOrder)}
                    disabled={invoicedMutation.isPending}
                  >
                    <Receipt className="h-4 w-4 mr-2" />
                    Merk fakturert
                  </Button>
                )}

                {/* invoiced: Mark as completed */}
                {selectedOrder.status === "invoiced" && (
                  <Button
                    onClick={() => completeMutation.mutate(selectedOrder)}
                    disabled={completeMutation.isPending}
                  >
                    <Package className="h-4 w-4 mr-2" />
                    Merk fullført
                  </Button>
                )}
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Reject dialog */}
      <Dialog open={showRejectDialog} onOpenChange={setShowRejectDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Avvis bestilling</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Vennligst oppgi en grunn for avvisningen. Denne vil bli sendt til bestilleren.
            </p>
            <Textarea
              placeholder="Skriv avvisningsgrunn..."
              value={rejectionReason}
              onChange={e => setRejectionReason(e.target.value)}
              rows={4}
            />
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowRejectDialog(false)}>
              Avbryt
            </Button>
            <Button
              variant="destructive"
              onClick={() => {
                if (selectedOrder) {
                  rejectMutation.mutate({
                    order: selectedOrder,
                    reason: rejectionReason
                  });
                }
              }}
              disabled={!rejectionReason || rejectMutation.isPending}
            >
              Avvis bestilling
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Email Preview Dialog */}
      <Dialog open={showEmailPreview} onOpenChange={setShowEmailPreview}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Mail className="h-5 w-5" />
              Forhåndsvisning av velkomst-e-post
            </DialogTitle>
            <DialogDescription>
              Slik vil e-posten se ut for den ansatte
            </DialogDescription>
          </DialogHeader>
          
          {previewEmployee && (
            <HealthWelcomeEmailPreview
              firstName={previewEmployee.first_name || previewEmployee.name?.split(" ")[0] || ""}
              avtalenummer={agreementNumbers[previewEmployee.id] ?? previewEmployee.helseforsikring_avtalenummer ?? ""}
              oppstartsdato={
                startDates[previewEmployee.id] 
                  ? format(startDates[previewEmployee.id]!, "d. MMMM yyyy", { locale: nb })
                  : previewEmployee.helseforsikring_oppstartsdato
                    ? format(new Date(previewEmployee.helseforsikring_oppstartsdato), "d. MMMM yyyy", { locale: nb })
                    : ""
              }
            />
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEmailPreview(false)}>
              Lukk
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
