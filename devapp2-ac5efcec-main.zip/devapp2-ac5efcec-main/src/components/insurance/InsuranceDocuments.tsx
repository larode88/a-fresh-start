import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Download } from "lucide-react";

interface ProductDocument {
  id: string;
  product_id: string;
  document_type: string;
  title: string;
  file_url: string;
  version: string | null;
  tier_id: string | null;
  insurance_products: {
    name: string;
    product_type: string;
  };
  insurance_product_tiers: {
    tier_name: string;
  } | null;
}

interface InsuranceDocumentsProps {
  activeProducts?: {
    salong?: boolean;
    yrkesskade?: boolean;
    cyber?: boolean;
    reise?: boolean;
    fritidsulykke?: boolean;
    helse?: boolean;
  };
  salongNiva?: string | null;
}

const documentTypeLabels: Record<string, string> = {
  vilkar: "Vilkår",
  produktark: "Produktark",
  brosjyre: "Brosjyre",
  sertifikat: "Forsikringsbevis",
  reisekort: "Reisekort",
  annet: "Annet",
};

export function InsuranceDocuments({ activeProducts, salongNiva }: InsuranceDocumentsProps) {
  // Fetch tiers to map salong_niva to tier_id
  const { data: salongTiers } = useQuery({
    queryKey: ["salong-tiers"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("insurance_product_tiers")
        .select(`
          id,
          tier_name,
          insurance_products!inner (
            product_type
          )
        `)
        .eq("insurance_products.product_type", "salong");

      if (error) throw error;
      return data;
    },
  });

  const { data: documents, isLoading } = useQuery({
    queryKey: ["insurance-documents-for-salon"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("insurance_product_documents")
        .select(`
          *,
          insurance_products:product_id (
            name,
            product_type
          ),
          insurance_product_tiers:tier_id (
            tier_name
          )
        `)
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data as ProductDocument[];
    },
  });

  // Find the tier_id that matches the salon's salong_niva
  // salong_niva is stored as "Nivå 1", "Nivå 2", etc. - same as tier_name
  const matchingSalongTierId = salongTiers?.find((tier) => {
    return tier.tier_name === salongNiva;
  })?.id;

  // Filter documents to show only those for active products (if specified)
  // For salong products, also filter by tier level
  const filteredDocuments = documents?.filter((doc) => {
    if (!activeProducts) return true; // Show all if no filter

    const productType = doc.insurance_products?.product_type;
    if (!productType) return false;

    // Check if product type is active
    let isActive = false;
    switch (productType) {
      case "salong":
        isActive = !!activeProducts.salong;
        // For salong, also filter by tier
        if (isActive && doc.tier_id) {
          // Only show documents that match the salon's tier or have no tier (general)
          return doc.tier_id === matchingSalongTierId;
        }
        // Documents without tier_id are general and should be shown
        return isActive;
      case "yrkesskade":
        return activeProducts.yrkesskade;
      case "cyber":
        return activeProducts.cyber;
      case "reise":
        return activeProducts.reise;
      case "fritidsulykke":
        return activeProducts.fritidsulykke;
      case "helse":
        return activeProducts.helse;
      default:
        return true;
    }
  });

  // Sort order for document types: sertifikat first, then others
  const documentTypeOrder: Record<string, number> = {
    sertifikat: 0,
    reisekort: 1,
    vilkar: 2,
    produktark: 3,
    brosjyre: 4,
    annet: 5,
  };

  // Group documents by product and sort within each group
  const groupedDocuments = filteredDocuments?.reduce((acc, doc) => {
    const productName = doc.insurance_products?.name || "Annet";
    if (!acc[productName]) {
      acc[productName] = [];
    }
    acc[productName].push(doc);
    return acc;
  }, {} as Record<string, ProductDocument[]>);

  // Sort documents within each product group
  if (groupedDocuments) {
    Object.keys(groupedDocuments).forEach((key) => {
      groupedDocuments[key].sort((a, b) => {
        const orderA = documentTypeOrder[a.document_type] ?? 99;
        const orderB = documentTypeOrder[b.document_type] ?? 99;
        return orderA - orderB;
      });
    });
  }

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Mine dokumenter</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-2">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-12 bg-muted rounded" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!filteredDocuments || filteredDocuments.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Mine dokumenter
          </CardTitle>
          <CardDescription>
            Vilkår og dokumenter for dine forsikringer
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground text-center py-8">
            Ingen dokumenter tilgjengelig ennå.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="h-5 w-5" />
          Mine dokumenter
        </CardTitle>
        <CardDescription>
          Vilkår og dokumenter for dine aktive forsikringer
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {Object.entries(groupedDocuments || {}).map(([productName, docs]) => (
          <div key={productName}>
            <h4 className="font-medium mb-3 text-sm text-muted-foreground uppercase tracking-wide">
              {productName}
            </h4>
            <div className="space-y-2">
              {docs.map((doc) => (
                <div
                  key={doc.id}
                  className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded bg-muted">
                      <FileText className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="font-medium text-sm">{doc.title}</p>
                      <p className="text-xs text-muted-foreground">
                        {documentTypeLabels[doc.document_type] || doc.document_type}
                        {doc.version && ` • Versjon ${doc.version}`}
                      </p>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm" asChild>
                    <a
                      href={doc.file_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-2"
                    >
                      <Download className="h-4 w-4" />
                      Last ned
                    </a>
                  </Button>
                </div>
              ))}
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
