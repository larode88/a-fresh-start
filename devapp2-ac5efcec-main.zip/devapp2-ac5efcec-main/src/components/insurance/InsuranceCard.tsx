import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { 
  Shield, Building2, Activity, Plane, Heart, ShieldCheck,
  Settings, FileText, XCircle, AlertTriangle, Users, ChevronDown, ChevronUp
} from "lucide-react";
import { format } from "date-fns";
import { nb } from "date-fns/locale";

export interface HealthEmployee {
  id: string;
  name: string;
  status: string;
}

export interface InsuranceCardData {
  type: string;
  label: string;
  isActive: boolean;
  price: number | null;
  quantity?: number | null;
  tierName?: string | null;
  unitLabel?: string;
  employees?: HealthEmployee[];
  scheduledCancellation?: {
    date: string;
    id: string;
  } | null;
}

interface InsuranceCardProps {
  insurance: InsuranceCardData;
  onEdit: () => void;
  onCancel: () => void;
  onCancelCancellation?: () => void;
  onViewTerms?: () => void;
  isHealthInsurance?: boolean;
  onManageEmployees?: () => void;
  onCancelEmployee?: (employeeId: string, employeeName: string) => void;
}

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  salong: Building2,
  yrkesskade: ShieldCheck,
  cyber: Shield,
  reise: Plane,
  fritidsulykke: Activity,
  helse: Heart,
};

const formatPrice = (price: number) => {
  return new Intl.NumberFormat("nb-NO", {
    style: "currency",
    currency: "NOK",
    maximumFractionDigits: 0,
  }).format(price);
};

export function InsuranceCard({
  insurance,
  onEdit,
  onCancel,
  onCancelCancellation,
  onViewTerms,
  isHealthInsurance = false,
  onManageEmployees,
  onCancelEmployee,
}: InsuranceCardProps) {
  const [employeesOpen, setEmployeesOpen] = useState(false);
  const Icon = iconMap[insurance.type] || Shield;
  const hasScheduledCancellation = !!insurance.scheduledCancellation;
  const canEdit = insurance.type !== "cyber"; // Cyber has fixed price, no editing
  const employees = insurance.employees || [];
  const activeEmployees = employees.filter(e => e.status === "aktiv" || e.status === "Aktiv");
  const pendingCancelEmployees = employees.filter(e => e.status === "oppsigelse" || e.status === "Oppsigelse");

  const getStatusBadge = (status: string) => {
    const lower = status.toLowerCase();
    if (lower === "aktiv") return <Badge className="bg-emerald-100 text-emerald-700 text-xs">Aktiv</Badge>;
    if (lower === "oppsigelse") return <Badge className="bg-amber-100 text-amber-700 text-xs">Oppsigelse</Badge>;
    if (lower === "sokt" || lower === "søkt") return <Badge className="bg-blue-100 text-blue-700 text-xs">Søkt</Badge>;
    return <Badge variant="secondary" className="text-xs">{status}</Badge>;
  };

  return (
    <Card className={`relative overflow-hidden transition-all ${
      hasScheduledCancellation ? "border-amber-300 bg-amber-50/30" : ""
    }`}>
      {/* Scheduled cancellation badge */}
      {hasScheduledCancellation && (
        <div className="absolute top-0 right-0 bg-amber-500 text-white text-xs px-2 py-1 rounded-bl-lg font-medium flex items-center gap-1">
          <AlertTriangle className="h-3 w-3" />
          Sies opp {format(new Date(insurance.scheduledCancellation!.date), "d. MMM", { locale: nb })}
        </div>
      )}

      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          {/* Icon */}
          <div className="p-2 rounded-lg bg-muted text-muted-foreground shrink-0">
            <Icon className="h-5 w-5" />
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <h4 className="font-medium text-sm truncate">{insurance.label}</h4>
              <Badge className="bg-[hsl(32,38%,57%)] hover:bg-[hsl(32,38%,47%)] text-white text-xs shrink-0">
                Aktiv
              </Badge>
            </div>

            {/* Details */}
            <div className="text-xs text-muted-foreground mb-2">
              {insurance.tierName && <span>Nivå {insurance.tierName}</span>}
              {insurance.quantity && insurance.unitLabel && (
                <span>{insurance.quantity} {insurance.unitLabel}</span>
              )}
            </div>

            {/* Price */}
            {insurance.price && (
              <p className="text-lg font-bold">
                {formatPrice(insurance.price)}
                <span className="text-sm font-normal text-muted-foreground">/år</span>
              </p>
            )}
          </div>
        </div>

        {/* Employees list for health insurance */}
        {isHealthInsurance && employees.length > 0 && (
          <Collapsible open={employeesOpen} onOpenChange={setEmployeesOpen} className="mt-3 pt-3 border-t">
            <CollapsibleTrigger asChild>
              <Button variant="ghost" size="sm" className="w-full justify-between hover:bg-muted/50">
                <span className="flex items-center gap-2">
                  <Users className="h-4 w-4" />
                  <span>{activeEmployees.length} aktive</span>
                  {pendingCancelEmployees.length > 0 && (
                    <Badge variant="outline" className="text-amber-600 border-amber-300 text-xs">
                      {pendingCancelEmployees.length} under oppsigelse
                    </Badge>
                  )}
                </span>
                {employeesOpen ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
              </Button>
            </CollapsibleTrigger>
            <CollapsibleContent className="mt-2 space-y-1">
              {employees.map((emp) => (
                <div key={emp.id} className="flex items-center justify-between py-1.5 px-2 rounded-md hover:bg-muted/50 group">
                  <div className="flex items-center gap-2">
                    <span className="text-sm">{emp.name}</span>
                    {getStatusBadge(emp.status)}
                  </div>
                  {emp.status.toLowerCase() === "aktiv" && onCancelEmployee && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onCancelEmployee(emp.id, emp.name)}
                      className="opacity-0 group-hover:opacity-100 transition-opacity h-7 px-2 text-destructive hover:text-destructive hover:bg-destructive/10"
                    >
                      <XCircle className="h-3 w-3" />
                    </Button>
                  )}
                </div>
              ))}
            </CollapsibleContent>
          </Collapsible>
        )}

        {/* Actions */}
        <div className="flex flex-wrap gap-2 mt-4 pt-3 border-t">
          {/* Health insurance special actions */}
          {isHealthInsurance && onManageEmployees && (
            <Button variant="outline" size="sm" onClick={onManageEmployees} className="flex-1">
              <Users className="h-3 w-3 mr-1" />
              Administrer ansatte
            </Button>
          )}

          {/* Edit button for non-health, non-cyber */}
          {!isHealthInsurance && canEdit && (
            <Button variant="outline" size="sm" onClick={onEdit} className="flex-1">
              <Settings className="h-3 w-3 mr-1" />
              {insurance.type === "salong" ? "Endre nivå" : 
               insurance.type === "yrkesskade" ? "Endre årsverk" : "Endre"}
            </Button>
          )}

          {/* Terms button */}
          {onViewTerms && (
            <Button variant="ghost" size="sm" onClick={onViewTerms}>
              <FileText className="h-3 w-3 mr-1" />
              Vilkår
            </Button>
          )}

          {/* Cancel/Abort cancellation */}
          {hasScheduledCancellation && onCancelCancellation ? (
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={onCancelCancellation}
              className="text-amber-700 hover:text-amber-800 hover:bg-amber-100"
            >
              <XCircle className="h-3 w-3 mr-1" />
              Avbryt oppsigelse
            </Button>
          ) : (
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={onCancel}
              className="text-destructive hover:text-destructive hover:bg-destructive/10"
            >
              <XCircle className="h-3 w-3 mr-1" />
              Si opp...
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
