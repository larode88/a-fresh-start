import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { format } from "date-fns";
import { nb } from "date-fns/locale";
import { useState } from "react";
import { Eye, Clock, CheckCircle, XCircle, Send, Package } from "lucide-react";

interface InsuranceOrder {
  id: string;
  salon_id: string;
  ordered_by_user_id: string;
  status: string;
  order_type: string;
  total_price: number;
  contact_name: string | null;
  contact_email: string | null;
  rejection_reason: string | null;
  created_at: string;
  approved_at: string | null;
  sent_to_frende_at: string | null;
  frende_transfer_date: string | null;
  invoiced_at: string | null;
  completed_at: string | null;
  salons?: { name: string };
  ordered_by?: { name: string };
}

interface OrderItem {
  id: string;
  order_id: string;
  product_id: string;
  tier_id: string | null;
  quantity: number;
  unit_price: number;
  total_price: number;
  insurance_products?: { name: string };
  insurance_product_tiers?: { tier_name: string } | null;
}

import { Receipt } from "lucide-react";

const statusConfig: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline"; icon: React.ReactNode }> = {
  draft: { label: "Utkast", variant: "outline", icon: <Clock className="h-3 w-3" /> },
  pending_approval: { label: "Venter godkjenning", variant: "secondary", icon: <Clock className="h-3 w-3" /> },
  sent_to_frende: { label: "Sendt til Frende", variant: "secondary", icon: <Send className="h-3 w-3" /> },
  approved: { label: "Godkjent", variant: "default", icon: <CheckCircle className="h-3 w-3" /> },
  invoiced: { label: "Fakturert", variant: "default", icon: <Receipt className="h-3 w-3" /> },
  completed: { label: "Fullført", variant: "default", icon: <Package className="h-3 w-3" /> },
  rejected: { label: "Avvist", variant: "destructive", icon: <XCircle className="h-3 w-3" /> },
  cancelled: { label: "Kansellert", variant: "outline", icon: <XCircle className="h-3 w-3" /> },
};

export function InsuranceOrderHistory({ salonId }: { salonId?: string }) {
  const { profile } = useAuth();
  const [selectedOrder, setSelectedOrder] = useState<InsuranceOrder | null>(null);

  const { data: orders, isLoading } = useQuery({
    queryKey: ["insurance-orders", salonId],
    queryFn: async () => {
      let query = supabase
        .from("insurance_orders")
        .select(`
          *,
          salons:salon_id (name),
          ordered_by:users!insurance_orders_ordered_by_user_id_fkey (name)
        `)
        .order("created_at", { ascending: false });

      if (salonId) {
        query = query.eq("salon_id", salonId);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data as InsuranceOrder[];
    },
  });

  const { data: orderItems } = useQuery({
    queryKey: ["insurance-order-items", selectedOrder?.id],
    queryFn: async () => {
      if (!selectedOrder) return [];
      
      const { data, error } = await supabase
        .from("insurance_order_items")
        .select(`
          *,
          insurance_products:product_id (name),
          insurance_product_tiers:tier_id (tier_name)
        `)
        .eq("order_id", selectedOrder.id);

      if (error) throw error;
      return data as OrderItem[];
    },
    enabled: !!selectedOrder,
  });

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("nb-NO", {
      style: "currency",
      currency: "NOK",
      maximumFractionDigits: 0,
    }).format(price);
  };

  const getStatusBadge = (status: string) => {
    const config = statusConfig[status] || statusConfig.draft;
    return (
      <Badge variant={config.variant} className="flex items-center gap-1">
        {config.icon}
        {config.label}
      </Badge>
    );
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Bestillingshistorikk</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-2">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-12 bg-muted rounded" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!orders || orders.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Bestillingshistorikk</CardTitle>
          <CardDescription>Ingen bestillinger ennå</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground text-center py-8">
            Du har ikke sendt inn noen forsikringsbestillinger ennå.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Bestillingshistorikk</CardTitle>
          <CardDescription>
            Oversikt over alle forsikringsbestillinger
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Dato</TableHead>
                {!salonId && <TableHead>Salong</TableHead>}
                <TableHead>Bestilt av</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Total</TableHead>
                <TableHead className="text-right">Handlinger</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {orders.map((order) => (
                <TableRow key={order.id}>
                  <TableCell>
                    {format(new Date(order.created_at), "d. MMM yyyy", { locale: nb })}
                  </TableCell>
                  {!salonId && (
                    <TableCell>{order.salons?.name || "-"}</TableCell>
                  )}
                  <TableCell>{order.ordered_by?.name || "-"}</TableCell>
                  <TableCell>{getStatusBadge(order.status)}</TableCell>
                  <TableCell className="text-right">
                    {formatPrice(order.total_price)}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setSelectedOrder(order)}
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Order detail dialog */}
      <Dialog open={!!selectedOrder} onOpenChange={() => setSelectedOrder(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Bestillingsdetaljer</DialogTitle>
          </DialogHeader>

          {selectedOrder && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Bestilt</p>
                  <p className="font-medium">
                    {format(new Date(selectedOrder.created_at), "d. MMMM yyyy 'kl.' HH:mm", { locale: nb })}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Status</p>
                  <div className="mt-1">{getStatusBadge(selectedOrder.status)}</div>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Salong</p>
                  <p className="font-medium">{selectedOrder.salons?.name || "-"}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Bestilt av</p>
                  <p className="font-medium">{selectedOrder.ordered_by?.name || "-"}</p>
                </div>
                {selectedOrder.contact_name && (
                  <div>
                    <p className="text-sm text-muted-foreground">Kontaktperson</p>
                    <p className="font-medium">{selectedOrder.contact_name}</p>
                  </div>
                )}
                {selectedOrder.contact_email && (
                  <div>
                    <p className="text-sm text-muted-foreground">E-post</p>
                    <p className="font-medium">{selectedOrder.contact_email}</p>
                  </div>
                )}
              </div>

              {selectedOrder.rejection_reason && (
                <div className="p-4 bg-destructive/10 rounded-lg">
                  <p className="text-sm font-medium text-destructive">Avvisningsgrunn:</p>
                  <p className="text-sm mt-1">{selectedOrder.rejection_reason}</p>
                </div>
              )}

              <div>
                <h4 className="font-medium mb-3">Bestilte produkter</h4>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Produkt</TableHead>
                      <TableHead className="text-center">Antall</TableHead>
                      <TableHead className="text-right">Enhetspris</TableHead>
                      <TableHead className="text-right">Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {orderItems?.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell>
                          <div>
                            <p className="font-medium">{item.insurance_products?.name}</p>
                            {item.insurance_product_tiers && (
                              <p className="text-sm text-muted-foreground">
                                {item.insurance_product_tiers.tier_name}
                              </p>
                            )}
                          </div>
                        </TableCell>
                        <TableCell className="text-center">{item.quantity}</TableCell>
                        <TableCell className="text-right">{formatPrice(item.unit_price)}</TableCell>
                        <TableCell className="text-right">{formatPrice(item.total_price)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                
                <div className="flex justify-end mt-4 pt-4 border-t">
                  <div className="text-right">
                    <p className="text-sm text-muted-foreground">Total årlig premie</p>
                    <p className="text-2xl font-bold">{formatPrice(selectedOrder.total_price)}</p>
                  </div>
                </div>
              </div>

              <div className="space-y-1">
                {selectedOrder.sent_to_frende_at && (
                  <p className="text-sm text-muted-foreground">
                    Sendt til Frende: {format(new Date(selectedOrder.sent_to_frende_at), "d. MMMM yyyy", { locale: nb })}
                  </p>
                )}
                {selectedOrder.frende_transfer_date && (
                  <p className="text-sm text-muted-foreground">
                    Overføringsdato: {format(new Date(selectedOrder.frende_transfer_date), "d. MMMM yyyy", { locale: nb })}
                  </p>
                )}
                {selectedOrder.approved_at && (
                  <p className="text-sm text-muted-foreground">
                    Godkjent: {format(new Date(selectedOrder.approved_at), "d. MMMM yyyy", { locale: nb })}
                  </p>
                )}
                {selectedOrder.invoiced_at && (
                  <p className="text-sm text-muted-foreground">
                    Fakturert: {format(new Date(selectedOrder.invoiced_at), "d. MMMM yyyy", { locale: nb })}
                  </p>
                )}
                {selectedOrder.completed_at && (
                  <p className="text-sm text-muted-foreground">
                    Fullført: {format(new Date(selectedOrder.completed_at), "d. MMMM yyyy", { locale: nb })}
                  </p>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
