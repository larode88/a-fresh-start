import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import { Heart, Plus, Pencil, Trash2, User, Check, X, Info, ShieldCheck } from "lucide-react";

interface Employee {
  id: string;
  name: string;
  email: string;
  helseforsikring_status: string | null;
  helseforsikring_oppstartsdato: string | null;
  helseforsikring_oppsigelsesdato: string | null;
  helseforsikring_pris: number | null;
  helseforsikring_avtalenummer: string | null;
  helseforsikring_personnummer?: string | null;
}

interface HealthInsuranceEmployeeManagerProps {
  salonId: string;
  onTotalChange?: (activeCount: number, totalPremium: number) => void;
}

const HEALTH_INSURANCE_PRICE = 5050;

export function HealthInsuranceEmployeeManager({ salonId, onTotalChange }: HealthInsuranceEmployeeManagerProps) {
  const queryClient = useQueryClient();
  const { profile } = useAuth();
  const isAdmin = profile?.role === "admin";
  
  const [selectedEmployeeId, setSelectedEmployeeId] = useState<string>("");
  const [newPersonnummer, setNewPersonnummer] = useState<string>("");
  const [editingEmployeeId, setEditingEmployeeId] = useState<string | null>(null);
  const [editFormData, setEditFormData] = useState<{
    status: string;
    oppstartsdato: string;
    oppsigelsesdato: string;
    avtalenummer: string;
    personnummer: string;
  }>({ status: "", oppstartsdato: "", oppsigelsesdato: "", avtalenummer: "", personnummer: "" });

  // Fetch employees in salon
  const { data: employees, isLoading } = useQuery({
    queryKey: ["salon-employees-health", salonId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("users")
        .select("id, name, email, helseforsikring_status, helseforsikring_oppstartsdato, helseforsikring_oppsigelsesdato, helseforsikring_pris, helseforsikring_avtalenummer")
        .eq("salon_id", salonId)
        .order("name");
      if (error) throw error;
      return data as Employee[];
    },
    enabled: !!salonId,
  });

  // Fetch personnummer for employees (admin only via RPC)
  const { data: personnummerMap } = useQuery({
    queryKey: ["salon-employees-personnummer", salonId, isAdmin],
    queryFn: async () => {
      if (!isAdmin || !employees) return {};
      
      const map: Record<string, string | null> = {};
      for (const emp of employees) {
        const { data } = await supabase.rpc("get_helseforsikring_personnummer", { p_user_id: emp.id });
        map[emp.id] = data;
      }
      return map;
    },
    enabled: !!salonId && isAdmin && !!employees,
  });

  // Employees with health insurance
  const employeesWithInsurance = employees?.filter(e => 
    e.helseforsikring_status && e.helseforsikring_status !== "Ingen"
  ) || [];

  // Employees available to add (no health insurance yet)
  const availableEmployees = employees?.filter(e => 
    !e.helseforsikring_status || e.helseforsikring_status === "Ingen"
  ) || [];

  // Calculate totals
  const activeCount = employeesWithInsurance.filter(e => e.helseforsikring_status === "Aktiv").length;
  const totalPremium = activeCount * HEALTH_INSURANCE_PRICE;

  // Notify parent of total changes
  useEffect(() => {
    if (onTotalChange) {
      onTotalChange(activeCount, totalPremium);
    }
  }, [activeCount, totalPremium, onTotalChange]);

  // Validate personnummer (11 digits)
  const isValidPersonnummer = (pnr: string) => {
    return /^\d{11}$/.test(pnr);
  };

  // Mask personnummer for display
  const maskPersonnummer = (pnr: string | null | undefined) => {
    if (!pnr) return null;
    return `******${pnr.slice(-5)}`;
  };

  // Add health insurance mutation
  const addMutation = useMutation({
    mutationFn: async ({ employeeId, personnummer }: { employeeId: string; personnummer?: string }) => {
      const updateData: Record<string, unknown> = {
        helseforsikring_status: "Ventende",
        helseforsikring_oppstartsdato: new Date().toISOString().split('T')[0],
        helseforsikring_pris: HEALTH_INSURANCE_PRICE,
      };
      
      if (personnummer && isAdmin) {
        updateData.helseforsikring_personnummer = personnummer;
      }
      
      const { error } = await supabase
        .from("users")
        .update(updateData)
        .eq("id", employeeId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["salon-employees-health", salonId] });
      queryClient.invalidateQueries({ queryKey: ["salon-employees-personnummer", salonId] });
      toast.success("Helseforsikring aktivert");
      setSelectedEmployeeId("");
      setNewPersonnummer("");
    },
    onError: () => {
      toast.error("Kunne ikke aktivere helseforsikring");
    },
  });

  // Update health insurance mutation
  const updateMutation = useMutation({
    mutationFn: async ({ employeeId, data }: { employeeId: string; data: typeof editFormData }) => {
      const updateData: Record<string, unknown> = {
        helseforsikring_status: data.status || null,
        helseforsikring_oppstartsdato: data.oppstartsdato || null,
        helseforsikring_oppsigelsesdato: data.oppsigelsesdato || null,
        helseforsikring_pris: data.status === "Aktiv" ? HEALTH_INSURANCE_PRICE : null,
        helseforsikring_avtalenummer: data.avtalenummer || null,
      };
      
      // Only update personnummer if admin and field is provided
      if (isAdmin && data.personnummer !== undefined) {
        updateData.helseforsikring_personnummer = data.personnummer || null;
      }
      
      const { error } = await supabase
        .from("users")
        .update(updateData)
        .eq("id", employeeId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["salon-employees-health", salonId] });
      queryClient.invalidateQueries({ queryKey: ["salon-employees-personnummer", salonId] });
      toast.success("Helseforsikring oppdatert");
      setEditingEmployeeId(null);
    },
    onError: () => {
      toast.error("Kunne ikke oppdatere helseforsikring");
    },
  });

  // Remove health insurance mutation
  const removeMutation = useMutation({
    mutationFn: async (employeeId: string) => {
      const { error } = await supabase
        .from("users")
        .update({
          helseforsikring_status: null,
          helseforsikring_oppstartsdato: null,
          helseforsikring_oppsigelsesdato: null,
          helseforsikring_pris: null,
          helseforsikring_avtalenummer: null,
          helseforsikring_personnummer: null,
        })
        .eq("id", employeeId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["salon-employees-health", salonId] });
      queryClient.invalidateQueries({ queryKey: ["salon-employees-personnummer", salonId] });
      toast.success("Helseforsikring fjernet");
    },
    onError: () => {
      toast.error("Kunne ikke fjerne helseforsikring");
    },
  });

  const handleAddEmployee = () => {
    if (selectedEmployeeId) {
      if (isAdmin && newPersonnummer && !isValidPersonnummer(newPersonnummer)) {
        toast.error("Personnummer må være 11 siffer");
        return;
      }
      addMutation.mutate({ employeeId: selectedEmployeeId, personnummer: newPersonnummer || undefined });
    }
  };

  const startEditing = (employee: Employee) => {
    setEditingEmployeeId(employee.id);
    setEditFormData({
      status: employee.helseforsikring_status || "",
      oppstartsdato: employee.helseforsikring_oppstartsdato || "",
      oppsigelsesdato: employee.helseforsikring_oppsigelsesdato || "",
      avtalenummer: employee.helseforsikring_avtalenummer || "",
      personnummer: personnummerMap?.[employee.id] || "",
    });
  };

  const saveEdit = () => {
    if (editingEmployeeId) {
      if (isAdmin && editFormData.personnummer && !isValidPersonnummer(editFormData.personnummer)) {
        toast.error("Personnummer må være 11 siffer");
        return;
      }
      updateMutation.mutate({ employeeId: editingEmployeeId, data: editFormData });
    }
  };

  const cancelEdit = () => {
    setEditingEmployeeId(null);
    setEditFormData({ status: "", oppstartsdato: "", oppsigelsesdato: "", avtalenummer: "", personnummer: "" });
  };

  const formatDate = (dateStr: string | null) => {
    if (!dateStr) return "-";
    return new Date(dateStr).toLocaleDateString("nb-NO");
  };

  const getStatusBadge = (status: string | null) => {
    switch (status) {
      case "Aktiv":
        return <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">Aktiv</Badge>;
      case "Ventende":
        return <Badge className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200">Ventende</Badge>;
      case "Avsluttet":
        return <Badge className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200">Avsluttet</Badge>;
      default:
        return null;
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("nb-NO", {
      style: "currency",
      currency: "NOK",
      maximumFractionDigits: 0,
    }).format(price);
  };

  // Check if personnummer field should be shown for an employee
  const shouldShowPersonnummer = (employee: Employee) => {
    if (!isAdmin) return false;
    // Show if status is Ventende AND no avtalenummer yet
    return employee.helseforsikring_status === "Ventende" && !employee.helseforsikring_avtalenummer;
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-6 bg-muted rounded w-1/3" />
            <div className="h-10 bg-muted rounded" />
            <div className="h-20 bg-muted rounded" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <Heart className="h-4 w-4" />
          Helseforsikring
        </CardTitle>
        <CardDescription>
          <span>{formatPrice(HEALTH_INSURANCE_PRICE)} per person per år</span>
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Add employee section */}
        <div className="space-y-2">
          <Label className="text-xs">Legg til helseforsikring</Label>
          <div className="flex gap-2">
            <Select value={selectedEmployeeId} onValueChange={setSelectedEmployeeId}>
              <SelectTrigger className="flex-1">
                <SelectValue placeholder="Velg ansatt..." />
              </SelectTrigger>
              <SelectContent>
                {availableEmployees.length === 0 ? (
                  <div className="p-2 text-sm text-muted-foreground text-center">
                    Alle ansatte har helseforsikring
                  </div>
                ) : (
                  availableEmployees.map(emp => (
                    <SelectItem key={emp.id} value={emp.id}>
                      {emp.name}
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
            <Button 
              size="sm" 
              onClick={handleAddEmployee}
              disabled={!selectedEmployeeId || addMutation.isPending || (isAdmin && newPersonnummer.length > 0 && !isValidPersonnummer(newPersonnummer))}
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>
          
          {/* Personnummer input for new employee (admin only) */}
          {isAdmin && selectedEmployeeId && (
            <div className="space-y-1.5 mt-2">
              <Label className="text-xs flex items-center gap-1">
                <ShieldCheck className="h-3 w-3" />
                Personnummer (11 siffer)
              </Label>
              <Input
                type="text"
                placeholder="DDMMÅÅXXXXX"
                maxLength={11}
                value={newPersonnummer}
                onChange={(e) => setNewPersonnummer(e.target.value.replace(/\D/g, ""))}
                className="font-mono"
              />
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                <Info className="h-3 w-3" />
                Slettes automatisk når avtalenummer registreres
              </p>
            </div>
          )}
        </div>

        <Separator />

        {/* Employees with health insurance */}
        <div className="space-y-2">
          <Label className="text-xs">
            Ansatte med helseforsikring ({employeesWithInsurance.length})
          </Label>
          
          {employeesWithInsurance.length === 0 ? (
            <p className="text-sm text-muted-foreground py-4 text-center">
              Ingen ansatte har helseforsikring ennå
            </p>
          ) : (
            <div className="space-y-2">
              {employeesWithInsurance.map(emp => (
                <div key={emp.id} className="border rounded-lg p-3">
                  {editingEmployeeId === emp.id ? (
                    // Edit mode
                    <div className="space-y-3">
                      <div className="flex items-center gap-2">
                        <User className="h-4 w-4 text-muted-foreground" />
                        <span className="font-medium text-sm">{emp.name}</span>
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                        <div className="space-y-1">
                          <Label className="text-xs">Status</Label>
                          <Select 
                            value={editFormData.status} 
                            onValueChange={(v) => setEditFormData(prev => ({ ...prev, status: v }))}
                          >
                            <SelectTrigger className="h-8">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Aktiv">Aktiv</SelectItem>
                              <SelectItem value="Ventende">Ventende</SelectItem>
                              <SelectItem value="Avsluttet">Avsluttet</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs">Oppstart</Label>
                          <Input
                            type="date"
                            className="h-8"
                            value={editFormData.oppstartsdato}
                            onChange={(e) => setEditFormData(prev => ({ ...prev, oppstartsdato: e.target.value }))}
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs">Oppsigelse</Label>
                          <Input
                            type="date"
                            className="h-8"
                            value={editFormData.oppsigelsesdato}
                            onChange={(e) => setEditFormData(prev => ({ ...prev, oppsigelsesdato: e.target.value }))}
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs">Avtalenummer</Label>
                          <Input
                            className="h-8"
                            placeholder="FRE-123456"
                            value={editFormData.avtalenummer}
                            onChange={(e) => setEditFormData(prev => ({ ...prev, avtalenummer: e.target.value }))}
                          />
                        </div>
                      </div>
                      
                      {/* Personnummer edit field (admin only, only when status is Ventende and no avtalenummer) */}
                      {isAdmin && editFormData.status === "Ventende" && !editFormData.avtalenummer && (
                        <div className="space-y-1">
                          <Label className="text-xs flex items-center gap-1">
                            <ShieldCheck className="h-3 w-3" />
                            Personnummer (11 siffer)
                          </Label>
                          <Input
                            type="text"
                            placeholder="DDMMÅÅXXXXX"
                            maxLength={11}
                            value={editFormData.personnummer}
                            onChange={(e) => setEditFormData(prev => ({ ...prev, personnummer: e.target.value.replace(/\D/g, "") }))}
                            className="font-mono h-8"
                          />
                          <p className="text-xs text-muted-foreground flex items-center gap-1">
                            <Info className="h-3 w-3" />
                            Slettes automatisk når avtalenummer registreres
                          </p>
                        </div>
                      )}
                      
                      {/* Show confirmation message when avtalenummer is present */}
                      {isAdmin && editFormData.avtalenummer && (
                        <div className="flex items-center gap-2 text-xs text-green-600 dark:text-green-400 bg-green-50 dark:bg-green-950 p-2 rounded">
                          <ShieldCheck className="h-3 w-3" />
                          Personnummer er slettet (forsikring bekreftet)
                        </div>
                      )}
                      
                      <div className="flex justify-end gap-2">
                        <Button size="sm" variant="outline" onClick={cancelEdit}>
                          <X className="h-3 w-3 mr-1" /> Avbryt
                        </Button>
                        <Button size="sm" onClick={saveEdit} disabled={updateMutation.isPending}>
                          <Check className="h-3 w-3 mr-1" /> Lagre
                        </Button>
                      </div>
                    </div>
                  ) : (
                    // View mode
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <User className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <p className="font-medium text-sm">{emp.name}</p>
                          <p className="text-xs text-muted-foreground">
                            fra {formatDate(emp.helseforsikring_oppstartsdato)}
                            {emp.helseforsikring_oppsigelsesdato && ` • til ${formatDate(emp.helseforsikring_oppsigelsesdato)}`}
                            {emp.helseforsikring_avtalenummer && ` • Avtalenr: ${emp.helseforsikring_avtalenummer}`}
                          </p>
                          {/* Show masked personnummer for admin if it exists */}
                          {isAdmin && personnummerMap?.[emp.id] && shouldShowPersonnummer(emp) && (
                            <p className="text-xs text-muted-foreground font-mono">
                              Personnr: {maskPersonnummer(personnummerMap[emp.id])}
                            </p>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {getStatusBadge(emp.helseforsikring_status)}
                        <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => startEditing(emp)}>
                          <Pencil className="h-3 w-3" />
                        </Button>
                        <Button 
                          size="icon" 
                          variant="ghost" 
                          className="h-7 w-7 text-destructive"
                          onClick={() => removeMutation.mutate(emp.id)}
                          disabled={removeMutation.isPending}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        <Separator />

        {/* Summary */}
        <div className="bg-muted/50 rounded-lg p-3">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm font-medium">Totalt</p>
              <p className="text-xs text-muted-foreground">
                {activeCount} aktive × {formatPrice(HEALTH_INSURANCE_PRICE)}
              </p>
            </div>
            <p className="text-lg font-semibold">
              {formatPrice(totalPremium)}
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
