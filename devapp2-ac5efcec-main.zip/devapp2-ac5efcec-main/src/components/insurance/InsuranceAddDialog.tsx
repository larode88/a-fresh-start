import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import { Plus, Shield, Building2, Activity, Plane, ShieldCheck, Check } from "lucide-react";

interface InsuranceProduct {
  id: string;
  name: string;
  description: string | null;
  product_type: string;
  price_model: string;
  base_price: number;
}

interface ProductTier {
  id: string;
  product_id: string;
  tier_name: string;
  price: number;
}

interface InsuranceAddDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  salonId: string;
  existingInsurances: string[];
  arsverk?: number;
  onSuccess?: () => void;
}

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  salong: Building2,
  yrkesskade: ShieldCheck,
  cyber: Shield,
  reise: Plane,
  fritidsulykke: Activity,
};

const formatPrice = (price: number) => {
  return new Intl.NumberFormat("nb-NO", {
    style: "currency",
    currency: "NOK",
    maximumFractionDigits: 0,
  }).format(price);
};

export function InsuranceAddDialog({
  open,
  onOpenChange,
  salonId,
  existingInsurances,
  arsverk = 1,
  onSuccess,
}: InsuranceAddDialogProps) {
  const queryClient = useQueryClient();
  const [selectedProduct, setSelectedProduct] = useState<InsuranceProduct | null>(null);
  const [selectedTierId, setSelectedTierId] = useState<string | null>(null);
  const [quantity, setQuantity] = useState<number>(1);
  const [step, setStep] = useState<"select" | "configure">("select");

  // Reset when dialog opens
  useEffect(() => {
    if (open) {
      setSelectedProduct(null);
      setSelectedTierId(null);
      setQuantity(1);
      setStep("select");
    }
  }, [open]);

  // Fetch available products
  const { data: products } = useQuery({
    queryKey: ["available-insurance-products"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("insurance_products")
        .select("id, name, description, product_type, price_model, base_price")
        .eq("active", true)
        .neq("product_type", "helse")
        .order("sort_order");
      
      if (error) throw error;
      return data as InsuranceProduct[];
    },
    enabled: open,
  });

  // Fetch tiers
  const { data: tiers } = useQuery({
    queryKey: ["insurance-tiers"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("insurance_product_tiers")
        .select("id, product_id, tier_name, price")
        .order("sort_order");
      
      if (error) throw error;
      return data as ProductTier[];
    },
    enabled: open,
  });

  // Filter out products the salon already has
  const availableProducts = products?.filter(p => !existingInsurances.includes(p.product_type));

  const getProductTiers = (productId: string) => {
    return tiers?.filter(t => t.product_id === productId) || [];
  };

  const calculatePrice = () => {
    if (!selectedProduct) return 0;
    
    const productTiers = getProductTiers(selectedProduct.id);
    if (productTiers.length > 0 && selectedTierId) {
      const tier = productTiers.find(t => t.id === selectedTierId);
      return tier?.price || 0;
    }

    if (selectedProduct.price_model === "per_arsverk") {
      return selectedProduct.base_price * quantity;
    }
    if (selectedProduct.price_model === "per_person") {
      return selectedProduct.base_price * quantity;
    }
    return selectedProduct.base_price;
  };

  // Submit new insurance request
  const addMutation = useMutation({
    mutationFn: async () => {
      if (!selectedProduct) throw new Error("No product selected");

      const { data: userData } = await supabase.auth.getUser();
      if (!userData.user) throw new Error("Not authenticated");

      const { data: salon } = await supabase
        .from("salons")
        .select("name, org_number")
        .eq("id", salonId)
        .single();

      const { data: userProfile } = await supabase
        .from("users")
        .select("name, email, phone")
        .eq("id", userData.user.id)
        .single();

      const productTiers = getProductTiers(selectedProduct.id);
      const selectedTier = productTiers.find(t => t.id === selectedTierId);
      const totalPrice = calculatePrice();

      // Create order
      const { data: order, error: orderError } = await supabase
        .from("insurance_orders")
        .insert({
          salon_id: salonId,
          ordered_by_user_id: userData.user.id,
          order_type: "new",
          status: "pending_approval",
          order_category: "bedrift",
          total_price: totalPrice,
          contact_name: userProfile?.name || "",
          contact_email: userProfile?.email || userData.user.email || "",
          contact_phone: userProfile?.phone || "",
          antall_arsverk: selectedProduct.price_model === "per_arsverk" ? quantity : null,
        })
        .select()
        .single();

      if (orderError) throw orderError;

      // Create order item
      const { error: itemError } = await supabase
        .from("insurance_order_items")
        .insert({
          order_id: order.id,
          product_id: selectedProduct.id,
          tier_id: selectedTierId || null,
          quantity: selectedProduct.price_model === "per_person" ? quantity : 
                   selectedProduct.price_model === "per_arsverk" ? quantity : 1,
          unit_price: selectedProduct.base_price,
          total_price: totalPrice,
        });

      if (itemError) throw itemError;

      // Send notification
      try {
        await supabase.functions.invoke("send-insurance-notification", {
          body: {
            type: "order_submitted",
            recipientEmail: "forsikring@har1.no",
            recipientName: "Hår1 Forsikring",
            salonName: salon?.name || "Ukjent salong",
            orderId: order.id,
            orderTotal: totalPrice,
            orderDetails: {
              products: [{
                name: selectedProduct.name,
                tierName: selectedTier?.tier_name,
                quantity: quantity,
                unitPrice: selectedProduct.base_price,
                totalPrice: totalPrice,
              }],
              contactName: userProfile?.name,
              contactEmail: userProfile?.email || userData.user.email,
              contactPhone: userProfile?.phone,
            },
          },
        });
      } catch (emailError) {
        console.error("Failed to send notification:", emailError);
      }

      return order;
    },
    onSuccess: () => {
      toast.success("Bestilling sendt! Vi tar kontakt med deg.");
      queryClient.invalidateQueries({ queryKey: ["insurance-orders"] });
      queryClient.invalidateQueries({ queryKey: ["my-salon-insurance"] });
      onOpenChange(false);
      onSuccess?.();
    },
    onError: (error) => {
      console.error("Error adding insurance:", error);
      toast.error("Kunne ikke sende bestilling");
    },
  });

  const handleSelectProduct = (product: InsuranceProduct) => {
    setSelectedProduct(product);
    const productTiers = getProductTiers(product.id);
    if (productTiers.length > 0) {
      setSelectedTierId(productTiers[0].id);
    }
    if (product.price_model === "per_arsverk") {
      setQuantity(arsverk);
    }
    setStep("configure");
  };

  const renderProductSelection = () => (
    <div className="grid gap-3">
      {availableProducts?.map((product) => {
        const Icon = iconMap[product.product_type] || Shield;
        return (
          <Card 
            key={product.id}
            className="cursor-pointer hover:border-primary transition-all"
            onClick={() => handleSelectProduct(product)}
          >
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-muted">
                  <Icon className="h-5 w-5 text-muted-foreground" />
                </div>
                <div className="flex-1">
                  <h4 className="font-medium">{product.name}</h4>
                  <p className="text-sm text-muted-foreground line-clamp-1">
                    {product.description}
                  </p>
                  <p className="text-sm font-medium mt-1">
                    Fra {formatPrice(product.base_price)}
                    {product.price_model === "per_arsverk" && "/årsverk"}
                    {product.price_model === "per_person" && "/person"}
                    {product.price_model === "fast" && "/år"}
                  </p>
                </div>
                <Plus className="h-5 w-5 text-muted-foreground" />
              </div>
            </CardContent>
          </Card>
        );
      })}
      
      {availableProducts?.length === 0 && (
        <div className="text-center py-8 text-muted-foreground">
          <Check className="h-12 w-12 mx-auto mb-2 opacity-50" />
          <p>Du har allerede alle tilgjengelige forsikringer!</p>
        </div>
      )}
    </div>
  );

  const renderConfiguration = () => {
    if (!selectedProduct) return null;
    const productTiers = getProductTiers(selectedProduct.id);

    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2 p-3 bg-muted rounded-lg">
          <Badge variant="secondary">{selectedProduct.name}</Badge>
          <Button variant="ghost" size="sm" onClick={() => setStep("select")}>
            Endre
          </Button>
        </div>

        {/* Tier selection */}
        {productTiers.length > 0 && (
          <div className="space-y-2">
            <Label>Velg nivå</Label>
            <RadioGroup value={selectedTierId || ""} onValueChange={setSelectedTierId}>
              {productTiers.map((tier) => (
                <div
                  key={tier.id}
                  className={`border rounded-lg p-3 cursor-pointer transition-all ${
                    selectedTierId === tier.id ? "ring-2 ring-primary border-primary" : ""
                  }`}
                  onClick={() => setSelectedTierId(tier.id)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <RadioGroupItem value={tier.id} id={tier.id} />
                      <Label htmlFor={tier.id} className="cursor-pointer">
                        {tier.tier_name}
                      </Label>
                    </div>
                    <span className="font-medium">{formatPrice(tier.price)}/år</span>
                  </div>
                </div>
              ))}
            </RadioGroup>
          </div>
        )}

        {/* Quantity input */}
        {(selectedProduct.price_model === "per_arsverk" || selectedProduct.price_model === "per_person") && (
          <div className="space-y-2">
            <Label>
              {selectedProduct.price_model === "per_arsverk" ? "Antall årsverk" : "Antall personer"}
            </Label>
            <Input
              type="number"
              min={1}
              value={quantity}
              onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
            />
          </div>
        )}

        {/* Price summary */}
        <div className="bg-muted rounded-lg p-4">
          <div className="flex items-center justify-between">
            <span className="text-muted-foreground">Årlig premie</span>
            <span className="text-xl font-bold">{formatPrice(calculatePrice())}</span>
          </div>
        </div>
      </div>
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>
            {step === "select" ? "Legg til forsikring" : "Konfigurer forsikring"}
          </DialogTitle>
          <DialogDescription>
            {step === "select" 
              ? "Velg en forsikring du ønsker å legge til" 
              : "Tilpass forsikringen etter dine behov"}
          </DialogDescription>
        </DialogHeader>

        <div className="py-4">
          {step === "select" ? renderProductSelection() : renderConfiguration()}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Avbryt
          </Button>
          {step === "configure" && selectedProduct && (
            <Button 
              onClick={() => addMutation.mutate()}
              disabled={addMutation.isPending || (getProductTiers(selectedProduct.id).length > 0 && !selectedTierId)}
            >
              {addMutation.isPending ? "Sender..." : "Send bestilling"}
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
