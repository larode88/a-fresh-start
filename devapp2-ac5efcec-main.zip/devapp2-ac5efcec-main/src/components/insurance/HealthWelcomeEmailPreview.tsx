import { format } from "date-fns";
import { nb } from "date-fns/locale";
import ergoLogo from "@/assets/ergo-logo.png";
import haar1Logo from "@/assets/haar1-forsikring-logo.png";

interface HealthWelcomeEmailPreviewProps {
  firstName: string;
  avtalenummer: string;
  oppstartsdato: string;
}

export function HealthWelcomeEmailPreview({ 
  firstName, 
  avtalenummer, 
  oppstartsdato 
}: HealthWelcomeEmailPreviewProps) {
  return (
    <div className="bg-white rounded-lg border shadow-sm overflow-hidden">
      {/* Email Header */}
      <div className="bg-[#1a1a1a] px-6 py-4 flex items-center justify-between">
        <img src={haar1Logo} alt="Hår1 Forsikring" className="h-8" />
        <img src={ergoLogo} alt="ERGO" className="h-6" />
      </div>

      {/* Email Body */}
      <div className="p-6 space-y-5 text-sm text-gray-700">
        {/* Greeting */}
        <div>
          <p className="text-base font-medium text-gray-900">
            Kjære {firstName || "[Fornavn]"}
          </p>
        </div>

        {/* Welcome message */}
        <p>
          Velkommen til Hår1 Helseforsikring hos ERGO! Vi er glade for at du har valgt 
          en forsikring som gir deg trygghet og rask tilgang til medisinsk behandling 
          når du trenger det.
        </p>

        {/* Start date highlight */}
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
          <p className="text-gray-900">
            <span className="font-medium">Oppstart for forsikringen:</span>{" "}
            <span className="font-semibold text-amber-800">
              {oppstartsdato || "[Oppstartsdato]"}
            </span>
          </p>
        </div>

        {/* Coverage list */}
        <div>
          <p className="font-medium text-gray-900 mb-3">Forsikringen din dekker blant annet:</p>
          <ul className="space-y-2">
            <li className="flex items-start gap-2">
              <span className="text-green-600 font-bold">✔</span>
              <span>Operasjoner og dagkirurgi</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-green-600 font-bold">✔</span>
              <span>Sykehusinnleggelse</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-green-600 font-bold">✔</span>
              <span>Behandling hos legespesialist</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-green-600 font-bold">✔</span>
              <span>Kreftbehandling</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-green-600 font-bold">✔</span>
              <span>Psykologisk førstehjelp (12 behandlingstimer)</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-green-600 font-bold">✔</span>
              <span>Fysikalsk behandling (12 behandlingstimer - egenandel 250 kr per behandling)</span>
            </li>
          </ul>
        </div>

        {/* How to use */}
        <div className="bg-gray-50 rounded-lg p-4 space-y-3">
          <p className="font-medium text-gray-900">Slik bruker du forsikringen:</p>
          <div>
            <p className="flex items-center gap-2">
              <span>📲</span>
              <span className="font-medium">BliFrisk-appen</span>
            </p>
            <p className="ml-6 text-gray-600">
              Last ned appen på{" "}
              <a 
                href="https://blifrisk.no/last-ned" 
                className="text-blue-600 underline"
                target="_blank"
                rel="noopener noreferrer"
              >
                blifrisk.no/last-ned
              </a>{" "}
              og få rask tilgang til helsetjenester, bestill behandling og hold oversikt 
              over din forsikring og vilkårene.
            </p>
          </div>
          <div className="bg-white border border-gray-200 rounded p-3 mt-2">
            <p className="text-gray-600 text-xs uppercase tracking-wide mb-1">
              Benytt ditt avtalenummer ved registrering i appen:
            </p>
            <p className="font-mono text-lg font-semibold text-gray-900">
              {avtalenummer || "[Avtalenummer]"}
            </p>
          </div>
        </div>

        {/* Contact info */}
        <div className="border-t pt-4">
          <p className="flex items-center gap-2 text-gray-600">
            <span>💬</span>
            <span>
              <span className="font-medium">Spørsmål?</span> Vi hjelper deg gjerne! 
              Kontakt ERGO på{" "}
              <span className="font-medium">800 83 313</span> eller{" "}
              <a href="mailto:infohelse@ergo.no" className="text-blue-600 underline">
                infohelse@ergo.no
              </a>
            </span>
          </p>
        </div>

        {/* Closing */}
        <div className="pt-2">
          <p>Takk for at du valgte Hår1 Helseforsikring – vi er her for deg!</p>
        </div>

        {/* Signature */}
        <div className="pt-4 border-t">
          <p className="font-medium text-gray-900">Varme hilsener</p>
          <p className="text-gray-900 font-medium mt-1">Hår1-teamet</p>
          <p className="text-gray-500 text-xs mt-2">
            Hår1 Forsikringer – Din trygghet i frisørhverdagen
          </p>
          <div className="flex items-center gap-4 text-xs text-gray-500 mt-1">
            <span>📞 +47 4000 3345</span>
            <span>📧 forsikring@har1.no</span>
          </div>
        </div>
      </div>
    </div>
  );
}
