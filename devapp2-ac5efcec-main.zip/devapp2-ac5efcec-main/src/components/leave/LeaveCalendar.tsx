import { useState, useEffect, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  ChevronLeft, 
  ChevronRight, 
  Calendar as CalendarIcon,
  AlertTriangle
} from "lucide-react";
import { 
  format, 
  startOfMonth, 
  endOfMonth, 
  eachDayOfInterval, 
  isSameMonth, 
  isToday, 
  getDay,
  addMonths,
  subMonths,
  isSameDay,
  isWithinInterval,
  parseISO
} from "date-fns";
import { nb } from "date-fns/locale";
import { cn } from "@/lib/utils";

interface LeaveCalendarProps {
  salonId: string;
  year: number;
  onEditFerie?: (ferieId: string) => void;
}

interface LeaveEvent {
  id: string;
  ansattId: string;
  userName: string;
  startDate: Date;
  endDate: Date;
  status: string;
  type: "ferie" | "fravaer";
  fravaerstype?: string;
  ferieType?: string;
  timer?: number;
}

interface ShiftConflict {
  date: Date;
  userName: string;
  shiftStart: string;
  shiftEnd: string;
}

const STATUS_COLORS: Record<string, string> = {
  estimat: "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300 border-dashed border-purple-400",
  soknad: "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300",
  planlagt: "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300",
  godkjent: "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300",
  avviklet: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300",
  avslatt: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300",
};

const WEEKDAYS = ["Man", "Tir", "Ons", "Tor", "Fre", "Lør", "Søn"];

const FERIE_TYPE_COLORS: Record<string, string> = {
  "Sommerferie": "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300",
  "Vinterferie": "bg-sky-100 text-sky-800 dark:bg-sky-900/30 dark:text-sky-300",
  "Påskeferie": "bg-pink-100 text-pink-800 dark:bg-pink-900/30 dark:text-pink-300",
  "Høstferie": "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300",
  "Juleferie": "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300",
  "Annen ferie": "bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-300",
};

export function LeaveCalendar({ salonId, year, onEditFerie }: LeaveCalendarProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [currentMonth, setCurrentMonth] = useState(new Date(year, new Date().getMonth(), 1));
  const [leaveEvents, setLeaveEvents] = useState<LeaveEvent[]>([]);
  const [conflicts, setConflicts] = useState<ShiftConflict[]>([]);
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        // Fetch leave requests (ferie) using ansatt_id
        const { data: ferieData, error: ferieError } = await supabase
          .from("ferie")
          .select(`
            id, ansatt_id, startdato, sluttdato, status, type, timer,
            ansatte!ferie_ansatt_id_fkey(id, fornavn, etternavn)
          `)
          .eq("salon_id", salonId)
          .eq("aar", year);

        if (ferieError) throw ferieError;

        // Fetch absences (fravær) using ansatt_id
        const { data: fravaerData, error: fravaerError } = await supabase
          .from("fravaer")
          .select(`
            id, ansatt_id, startdato, sluttdato, fravaerstype, status,
            ansatte!fravaer_ansatt_id_fkey(id, fornavn, etternavn)
          `)
          .eq("salon_id", salonId)
          .gte("startdato", `${year}-01-01`)
          .lte("sluttdato", `${year}-12-31`);

        if (fravaerError) throw fravaerError;

        const events: LeaveEvent[] = [];

        // Map ferie to events using ansatt_id
        (ferieData || []).forEach(f => {
          const ansatt = f.ansatte as any;
          const navn = ansatt ? `${ansatt.fornavn || ''} ${ansatt.etternavn || ''}`.trim() : "Ukjent";
          events.push({
            id: f.id,
            ansattId: f.ansatt_id,
            userName: navn || "Ukjent",
            startDate: parseISO(f.startdato),
            endDate: parseISO(f.sluttdato),
            status: f.status || "planlagt",
            type: "ferie",
            ferieType: f.type,
            timer: f.timer ?? undefined
          });
        });

        // Map fravær to events using ansatt_id
        (fravaerData || []).forEach(f => {
          const ansatt = f.ansatte as any;
          const navn = ansatt ? `${ansatt.fornavn || ''} ${ansatt.etternavn || ''}`.trim() : "Ukjent";
          events.push({
            id: f.id,
            ansattId: f.ansatt_id,
            userName: navn || "Ukjent",
            startDate: parseISO(f.startdato),
            endDate: parseISO(f.sluttdato),
            status: f.status || "aktiv",
            type: "fravaer",
            fravaerstype: f.fravaerstype
          });
        });

        setLeaveEvents(events);

        // Check for shift conflicts (planlagte vakter som overlapper med ferie)
        await checkShiftConflicts(events.filter(e => e.type === "ferie" && e.status === "planlagt"));
      } catch (error) {
        console.error("Error fetching calendar data:", error);
        toast({
          title: "Feil",
          description: "Kunne ikke laste kalenderdata",
          variant: "destructive"
        });
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [salonId, year]);

  const checkShiftConflicts = async (pendingLeave: LeaveEvent[]) => {
    if (pendingLeave.length === 0) {
      setConflicts([]);
      return;
    }

    try {
      const foundConflicts: ShiftConflict[] = [];

      for (const leave of pendingLeave) {
        // Check turnus for this employee during leave period using ansatt_id
        const { data: turnusData } = await supabase
          .from("ansatt_turnus")
          .select("*")
          .eq("ansatt_id", leave.ansattId)
          .eq("salon_id", salonId)
          .eq("fridag", false);

        if (!turnusData || turnusData.length === 0) continue;

        // Get all days in leave period
        const leaveDays = eachDayOfInterval({ start: leave.startDate, end: leave.endDate });

        for (const day of leaveDays) {
          const dayOfWeek = getDay(day);
          // Convert Sunday (0) to 7 for Norwegian week format
          const norwegianDay = dayOfWeek === 0 ? 7 : dayOfWeek;

          const matchingTurnus = turnusData.find(t => t.ukedag === norwegianDay);
          if (matchingTurnus && matchingTurnus.start_tid && matchingTurnus.slutt_tid) {
            foundConflicts.push({
              date: day,
              userName: leave.userName,
              shiftStart: matchingTurnus.start_tid,
              shiftEnd: matchingTurnus.slutt_tid
            });
          }
        }
      }

      setConflicts(foundConflicts);
    } catch (error) {
      console.error("Error checking shift conflicts:", error);
    }
  };

  const monthDays = useMemo(() => {
    const start = startOfMonth(currentMonth);
    const end = endOfMonth(currentMonth);
    const days = eachDayOfInterval({ start, end });

    // Add padding days for week alignment (Monday = 0)
    const startDay = getDay(start);
    const paddingStart = startDay === 0 ? 6 : startDay - 1;

    return { days, paddingStart };
  }, [currentMonth]);

  const getEventsForDay = (date: Date) => {
    return leaveEvents.filter(event => 
      isWithinInterval(date, { start: event.startDate, end: event.endDate })
    );
  };

  const getConflictsForDay = (date: Date) => {
    return conflicts.filter(c => isSameDay(c.date, date));
  };

  const selectedDayEvents = selectedDate ? getEventsForDay(selectedDate) : [];
  const selectedDayConflicts = selectedDate ? getConflictsForDay(selectedDate) : [];

  if (loading) {
    return <Skeleton className="h-96" />;
  }

  return (
    <div className="grid gap-4 lg:grid-cols-3">
      {/* Calendar */}
      <Card className="lg:col-span-2">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <CalendarIcon className="h-5 w-5" />
                Feriekalender
              </CardTitle>
              <CardDescription>Visuell oversikt over ferie og fravær</CardDescription>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="icon"
                onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <span className="min-w-32 text-center font-medium capitalize">
                {format(currentMonth, "MMMM", { locale: nb })}
              </span>
              <Button
                variant="outline"
                size="icon"
                onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* Weekday headers */}
          <div className="grid grid-cols-7 gap-1 mb-2">
            {WEEKDAYS.map(day => (
              <div key={day} className="text-center text-sm font-medium text-muted-foreground py-2">
                {day}
              </div>
            ))}
          </div>

          {/* Calendar grid */}
          <div className="grid grid-cols-7 gap-1">
            {/* Padding cells */}
            {Array.from({ length: monthDays.paddingStart }).map((_, i) => (
              <div key={`pad-${i}`} className="h-24 rounded-lg" />
            ))}

            {/* Day cells */}
            {monthDays.days.map(day => {
              const dayEvents = getEventsForDay(day);
              const dayConflicts = getConflictsForDay(day);
              const hasConflicts = dayConflicts.length > 0;
              const isSelected = selectedDate && isSameDay(day, selectedDate);

              return (
                <button
                  key={day.toISOString()}
                  onClick={() => setSelectedDate(day)}
                  className={cn(
                    "h-24 p-1.5 rounded-lg border text-left transition-colors hover:bg-accent relative",
                    isToday(day) && "border-primary",
                    isSelected && "ring-2 ring-primary ring-offset-2",
                    !isSameMonth(day, currentMonth) && "text-muted-foreground",
                    hasConflicts && "border-destructive"
                  )}
                >
                  <div className="flex items-center justify-between">
                    <span className={cn(
                      "text-sm font-medium",
                      isToday(day) && "bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center"
                    )}>
                      {format(day, "d")}
                    </span>
                    {hasConflicts && (
                      <AlertTriangle className="h-3 w-3 text-destructive" />
                    )}
                  </div>
                  
                  <div className="mt-1 space-y-0.5 overflow-hidden">
                    {dayEvents.slice(0, 2).map(event => (
                      <div
                        key={event.id}
                        className={cn(
                          "text-xs px-1 rounded truncate",
                          event.type === "ferie" 
                            ? STATUS_COLORS[event.status] || STATUS_COLORS.planlagt
                            : "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300"
                        )}
                      >
                        {event.userName.split(" ")[0]}
                      </div>
                    ))}
                    {dayEvents.length > 2 && (
                      <div className="text-xs text-muted-foreground">
                        +{dayEvents.length - 2} til
                      </div>
                    )}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Legend */}
          <div className="mt-4 flex flex-wrap gap-3 text-xs">
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 rounded bg-amber-100 dark:bg-amber-900/30" />
              <span>Planlagt</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 rounded bg-green-100 dark:bg-green-900/30" />
              <span>Godkjent</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 rounded bg-blue-100 dark:bg-blue-900/30" />
              <span>Avholdt</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-3 h-3 rounded bg-purple-100 dark:bg-purple-900/30" />
              <span>Fravær</span>
            </div>
            <div className="flex items-center gap-1">
              <AlertTriangle className="h-3 w-3 text-destructive" />
              <span>Konflikt</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Day details sidebar */}
      <Card className="h-full flex flex-col">
        <CardHeader>
          <CardTitle className="text-lg">
            {selectedDate 
              ? format(selectedDate, "EEEE d. MMMM", { locale: nb })
              : "Velg en dag"
            }
          </CardTitle>
          <CardDescription>
            {selectedDate 
              ? `${selectedDayEvents.length} registreringer`
              : "Klikk på en dag for detaljer"
            }
          </CardDescription>
        </CardHeader>
        <CardContent className="flex-1 flex flex-col">
          {selectedDate ? (
            <ScrollArea className="flex-1">
              <div className="space-y-3">
                {selectedDayConflicts.length > 0 && (
                  <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/20">
                    <div className="flex items-center gap-2 text-destructive font-medium text-sm mb-2">
                      <AlertTriangle className="h-4 w-4" />
                      Vaktkonflikt
                    </div>
                    {selectedDayConflicts.map((conflict, i) => (
                      <div key={i} className="text-sm text-muted-foreground">
                        {conflict.userName}: {conflict.shiftStart} - {conflict.shiftEnd}
                      </div>
                    ))}
                  </div>
                )}

                {selectedDayEvents.length === 0 && selectedDayConflicts.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    Ingen registreringer denne dagen
                  </p>
                ) : (
                  selectedDayEvents.map(event => (
                    <div 
                      key={event.id} 
                      className={cn(
                        "p-3 rounded-lg border bg-card",
                        event.type === "ferie" && onEditFerie && "cursor-pointer hover:bg-accent transition-colors"
                      )}
                      onClick={() => {
                        if (event.type === "ferie" && onEditFerie) {
                          onEditFerie(event.id);
                        }
                      }}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-medium">{event.userName}</span>
                        <Badge 
                          variant="outline"
                          className={cn(
                            event.type === "ferie" 
                              ? FERIE_TYPE_COLORS[event.ferieType || ""] || "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300"
                              : "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300"
                          )}
                        >
                          {event.type === "ferie" ? (event.ferieType || "Ferie") : event.fravaerstype}
                        </Badge>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {format(event.startDate, "d. MMM", { locale: nb })} - {format(event.endDate, "d. MMM", { locale: nb })}
                        {event.type === "ferie" && event.timer != null && (
                          <span className="ml-2 font-medium">({event.timer}t)</span>
                        )}
                      </div>
                      {event.type === "ferie" && (
                        <Badge 
                          variant="outline" 
                          className={cn("mt-2", STATUS_COLORS[event.status])}
                        >
                          {event.status === "estimat" ? "📊 Estimat" :
                           event.status === "soknad" ? "Søknad" :
                           event.status === "planlagt" ? "Planlagt" : 
                           event.status === "godkjent" ? "Godkjent" :
                           event.status === "avviklet" ? "Avviklet" : "Avslått"}
                        </Badge>
                      )}
                    </div>
                  ))
                )}
              </div>
            </ScrollArea>
          ) : (
            <p className="text-sm text-muted-foreground text-center py-8">
              Klikk på en dag i kalenderen for å se detaljer
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
