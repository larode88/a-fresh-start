import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Palmtree, Clock, CheckCircle } from "lucide-react";

interface LeaveBalanceProps {
  salonId: string;
  userId?: string;
  year: number;
}

interface BalanceData {
  userId: string;
  userName: string;
  totalHours: number;
  usedHours: number;
  pendingHours: number;
  transferredIn: number;
  transferredOut: number;
}

const ANNUAL_LEAVE_HOURS = 187.5; // 25 days × 7.5 hours

export function LeaveBalance({ salonId, userId, year }: LeaveBalanceProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [balances, setBalances] = useState<BalanceData[]>([]);

  useEffect(() => {
    const fetchBalances = async () => {
      setLoading(true);
      try {
        // Fetch employees
        let usersQuery = supabase
          .from("users")
          .select("id, name, stillingsprosent")
          .eq("salon_id", salonId)
          .eq("aktiv", true);

        if (userId) {
          usersQuery = usersQuery.eq("id", userId);
        }

        const { data: users, error: usersError } = await usersQuery;
        if (usersError) throw usersError;

        // Fetch leave data for the year
        const { data: leaveData, error: leaveError } = await supabase
          .from("ferie")
          .select("*")
          .eq("salon_id", salonId)
          .eq("aar", year);

        if (leaveError) throw leaveError;

        // Fetch transfers
        const { data: transfers, error: transferError } = await supabase
          .from("ferie_overforing")
          .select("*")
          .or(`fra_aar.eq.${year},til_aar.eq.${year}`);

        if (transferError) throw transferError;

        // Calculate balances
        const balanceData: BalanceData[] = (users || []).map(user => {
          const userLeave = leaveData?.filter(l => l.user_id === user.id) || [];
        const usedHours = userLeave
            .filter(l => l.status === "avviklet")
            .reduce((sum, l) => sum + (l.timer || 0), 0);
          const pendingHours = userLeave
            .filter(l => l.status === "planlagt")
            .reduce((sum, l) => sum + (l.timer || 0), 0);

          const userTransfers = transfers?.filter(t => t.user_id === user.id) || [];
          const transferredIn = userTransfers
            .filter(t => t.til_aar === year && t.godkjent_dato)
            .reduce((sum, t) => sum + t.timer, 0);
          const transferredOut = userTransfers
            .filter(t => t.fra_aar === year && t.godkjent_dato)
            .reduce((sum, t) => sum + t.timer, 0);

          const baseHours = ANNUAL_LEAVE_HOURS * ((user.stillingsprosent || 100) / 100);

          return {
            userId: user.id,
            userName: user.name,
            totalHours: baseHours + transferredIn - transferredOut,
            usedHours,
            pendingHours,
            transferredIn,
            transferredOut
          };
        });

        setBalances(balanceData);
      } catch (error) {
        console.error("Error fetching leave balances:", error);
        toast({
          title: "Feil",
          description: "Kunne ikke hente feriesaldo",
          variant: "destructive"
        });
      } finally {
        setLoading(false);
      }
    };

    fetchBalances();
  }, [salonId, userId, year]);

  if (loading) {
    return <Skeleton className="h-32" />;
  }

  if (balances.length === 0) {
    return null;
  }

  const formatHours = (hours: number) => {
    const days = Math.floor(hours / 7.5);
    const remainingHours = hours % 7.5;
    if (remainingHours === 0) return `${days}d`;
    return `${days}d ${remainingHours.toFixed(1)}t`;
  };

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      {balances.map(balance => {
        const availableHours = balance.totalHours - balance.usedHours - balance.pendingHours;
        const usedPercent = (balance.usedHours / balance.totalHours) * 100;
        const pendingPercent = (balance.pendingHours / balance.totalHours) * 100;

        return (
          <Card key={balance.userId}>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <Palmtree className="h-4 w-4" />
                {balance.userName}
              </CardTitle>
              <CardDescription>Feriesaldo {year}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-1">
                <div className="flex justify-between text-sm">
                  <span>Tilgjengelig</span>
                  <span className="font-medium">{formatHours(availableHours)}</span>
                </div>
                <Progress value={100 - usedPercent - pendingPercent} className="h-2" />
              </div>

              <div className="grid grid-cols-3 gap-2 text-center text-xs">
                <div className="p-2 rounded bg-muted">
                  <CheckCircle className="h-3 w-3 mx-auto mb-1 text-green-600" />
                  <div className="font-medium">{formatHours(balance.usedHours)}</div>
                  <div className="text-muted-foreground">Brukt</div>
                </div>
                <div className="p-2 rounded bg-muted">
                  <Clock className="h-3 w-3 mx-auto mb-1 text-yellow-600" />
                  <div className="font-medium">{formatHours(balance.pendingHours)}</div>
                  <div className="text-muted-foreground">Planlagt</div>
                </div>
                <div className="p-2 rounded bg-muted">
                  <Palmtree className="h-3 w-3 mx-auto mb-1 text-primary" />
                  <div className="font-medium">{formatHours(balance.totalHours)}</div>
                  <div className="text-muted-foreground">Totalt</div>
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
