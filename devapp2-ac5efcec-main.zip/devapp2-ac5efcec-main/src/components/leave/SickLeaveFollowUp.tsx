import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertTriangle, Plus, Phone, MessageSquare, FileText, Users, Calendar, Clock, Loader2 } from "lucide-react";
import { format, differenceInDays, isAfter, isBefore, parseISO } from "date-fns";
import { nb } from "date-fns/locale";

interface SickLeaveFollowUpProps {
  salonId: string;
  canManage: boolean;
}

interface SickLeaveRecord {
  id: string;
  user_id: string;
  user_name: string;
  startdato: string;
  sluttdato: string;
  prosent: number | null;
  days_absent: number;
  followups: FollowUpRecord[];
}

interface FollowUpRecord {
  id: string;
  oppfolging_type: string;
  dato: string;
  notater: string | null;
  neste_oppfolging: string | null;
  utfort_av_name: string | null;
}

const FOLLOWUP_TYPES = [
  { value: "telefonsamtale", label: "Telefonsamtale", icon: Phone },
  { value: "samtale", label: "Personlig samtale", icon: MessageSquare },
  { value: "oppfolgingsplan", label: "Oppfølgingsplan", icon: FileText },
  { value: "dialogmote", label: "Dialogmøte", icon: Users },
  { value: "tilrettelegging", label: "Tilrettelegging", icon: Calendar },
  { value: "annet", label: "Annet", icon: Clock }
];

export function SickLeaveFollowUp({ salonId, canManage }: SickLeaveFollowUpProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [sickLeaves, setSickLeaves] = useState<SickLeaveRecord[]>([]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedFravaerId, setSelectedFravaerId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  // Form state
  const [formType, setFormType] = useState("telefonsamtale");
  const [formDato, setFormDato] = useState(format(new Date(), "yyyy-MM-dd"));
  const [formNotater, setFormNotater] = useState("");
  const [formNesteOppfolging, setFormNesteOppfolging] = useState("");

  const fetchData = async () => {
    setLoading(true);
    try {
      // Fetch active sick leaves (sykmelding type, either ongoing or recent)
      const today = new Date().toISOString().split('T')[0];
      const { data: fravaerData, error: fravaerError } = await supabase
        .from("fravaer")
        .select(`
          id, user_id, startdato, sluttdato, prosent,
          users!fravaer_user_id_fkey(name)
        `)
        .eq("salon_id", salonId)
        .eq("fravaerstype", "sykmelding")
        .eq("status", "aktiv")
        .order("startdato", { ascending: false });

      if (fravaerError) throw fravaerError;

      // Fetch follow-ups for these sick leaves
      const fravaerIds = (fravaerData || []).map(f => f.id);
      
      let followupsMap: Record<string, FollowUpRecord[]> = {};
      if (fravaerIds.length > 0) {
        const { data: followups, error: followupsError } = await supabase
          .from("sykefravear_oppfolging")
          .select(`
            id, fravaer_id, oppfolging_type, dato, notater, neste_oppfolging,
            users!sykefravear_oppfolging_utfort_av_fkey(name)
          `)
          .in("fravaer_id", fravaerIds)
          .order("dato", { ascending: false });

        if (!followupsError && followups) {
          followups.forEach(f => {
            if (!followupsMap[f.fravaer_id]) {
              followupsMap[f.fravaer_id] = [];
            }
            followupsMap[f.fravaer_id].push({
              id: f.id,
              oppfolging_type: f.oppfolging_type,
              dato: f.dato,
              notater: f.notater,
              neste_oppfolging: f.neste_oppfolging,
              utfort_av_name: (f.users as any)?.name || null
            });
          });
        }
      }

      const records: SickLeaveRecord[] = (fravaerData || []).map(f => ({
        id: f.id,
        user_id: f.user_id,
        user_name: (f.users as any)?.name || "Ukjent",
        startdato: f.startdato,
        sluttdato: f.sluttdato,
        prosent: f.prosent,
        days_absent: differenceInDays(parseISO(f.sluttdato), parseISO(f.startdato)) + 1,
        followups: followupsMap[f.id] || []
      }));

      setSickLeaves(records);
    } catch (error) {
      console.error("Error fetching sick leaves:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke hente sykefravær",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [salonId]);

  const handleAddFollowUp = async () => {
    if (!user || !selectedFravaerId) return;
    
    const selectedLeave = sickLeaves.find(s => s.id === selectedFravaerId);
    if (!selectedLeave) return;

    setSaving(true);
    try {
      const { error } = await supabase.from("sykefravear_oppfolging").insert({
        fravaer_id: selectedFravaerId,
        user_id: selectedLeave.user_id,
        salon_id: salonId,
        oppfolging_type: formType,
        dato: formDato,
        notater: formNotater || null,
        neste_oppfolging: formNesteOppfolging || null,
        utfort_av: user.id
      });

      if (error) throw error;

      toast({ title: "Lagret", description: "Oppfølging registrert" });
      setDialogOpen(false);
      resetForm();
      fetchData();
    } catch (error) {
      console.error("Error saving follow-up:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke lagre oppfølging",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const resetForm = () => {
    setFormType("telefonsamtale");
    setFormDato(format(new Date(), "yyyy-MM-dd"));
    setFormNotater("");
    setFormNesteOppfolging("");
    setSelectedFravaerId(null);
  };

  const getUrgencyBadge = (daysAbsent: number, followups: FollowUpRecord[]) => {
    const hasRecentFollowup = followups.some(f => 
      differenceInDays(new Date(), parseISO(f.dato)) <= 7
    );

    if (daysAbsent >= 28 && !hasRecentFollowup) {
      return <Badge variant="destructive">Dialogmøte påkrevd</Badge>;
    }
    if (daysAbsent >= 14 && followups.length === 0) {
      return <Badge variant="destructive">Oppfølging påkrevd</Badge>;
    }
    if (daysAbsent >= 7 && followups.length === 0) {
      return <Badge className="bg-amber-500 hover:bg-amber-600">Bør følges opp</Badge>;
    }
    if (hasRecentFollowup) {
      return <Badge variant="secondary">Oppfølging utført</Badge>;
    }
    return null;
  };

  const getPendingFollowups = () => {
    return sickLeaves.filter(s => {
      const needsFollowup = s.days_absent >= 7 && s.followups.length === 0;
      const hasUpcomingFollowup = s.followups.some(f => 
        f.neste_oppfolging && isAfter(parseISO(f.neste_oppfolging), new Date())
      );
      const hasOverdueFollowup = s.followups.some(f => 
        f.neste_oppfolging && isBefore(parseISO(f.neste_oppfolging), new Date())
      );
      return needsFollowup || hasOverdueFollowup;
    });
  };

  if (loading) {
    return <Skeleton className="h-64" />;
  }

  const pendingFollowups = getPendingFollowups();

  return (
    <div className="space-y-6">
      {pendingFollowups.length > 0 && (
        <Card className="border-amber-500/50 bg-amber-50/50 dark:bg-amber-950/20">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-amber-700 dark:text-amber-400">
              <AlertTriangle className="h-5 w-5" />
              Oppfølging påkrevd ({pendingFollowups.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {pendingFollowups.map(leave => (
                <div key={leave.id} className="flex items-center justify-between p-3 rounded-lg bg-background border">
                  <div>
                    <span className="font-medium">{leave.user_name}</span>
                    <span className="text-sm text-muted-foreground ml-2">
                      {leave.days_absent} dager sykmeldt
                    </span>
                  </div>
                  {canManage && (
                    <Button 
                      size="sm" 
                      onClick={() => {
                        setSelectedFravaerId(leave.id);
                        setDialogOpen(true);
                      }}
                    >
                      <Plus className="h-4 w-4 mr-1" />
                      Registrer oppfølging
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Sykefraværsoppfølging</CardTitle>
          <CardDescription>Aktive sykmeldinger og oppfølgingshistorikk</CardDescription>
        </CardHeader>
        <CardContent>
          {sickLeaves.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">
              Ingen aktive sykmeldinger.
            </p>
          ) : (
            <div className="space-y-4">
              {sickLeaves.map(leave => (
                <div key={leave.id} className="p-4 rounded-lg border bg-card">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{leave.user_name}</span>
                        {leave.prosent && leave.prosent < 100 && (
                          <Badge variant="outline">{leave.prosent}% sykmeldt</Badge>
                        )}
                        {getUrgencyBadge(leave.days_absent, leave.followups)}
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">
                        {format(parseISO(leave.startdato), "d. MMM", { locale: nb })} - {format(parseISO(leave.sluttdato), "d. MMM yyyy", { locale: nb })}
                        <span className="ml-2">({leave.days_absent} dager)</span>
                      </p>
                    </div>
                    {canManage && (
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => {
                          setSelectedFravaerId(leave.id);
                          setDialogOpen(true);
                        }}
                      >
                        <Plus className="h-4 w-4 mr-1" />
                        Legg til
                      </Button>
                    )}
                  </div>

                  {leave.followups.length > 0 && (
                    <div className="mt-3 pt-3 border-t space-y-2">
                      {leave.followups.map(f => {
                        const typeInfo = FOLLOWUP_TYPES.find(t => t.value === f.oppfolging_type);
                        const Icon = typeInfo?.icon || Clock;
                        return (
                          <div key={f.id} className="flex items-start gap-3 text-sm">
                            <Icon className="h-4 w-4 mt-0.5 text-muted-foreground" />
                            <div className="flex-1">
                              <div className="flex items-center gap-2">
                                <span className="font-medium">{typeInfo?.label}</span>
                                <span className="text-muted-foreground">
                                  {format(parseISO(f.dato), "d. MMM yyyy", { locale: nb })}
                                </span>
                                {f.utfort_av_name && (
                                  <span className="text-muted-foreground">av {f.utfort_av_name}</span>
                                )}
                              </div>
                              {f.notater && <p className="text-muted-foreground mt-1">{f.notater}</p>}
                              {f.neste_oppfolging && (
                                <p className="text-muted-foreground mt-1">
                                  Neste oppfølging: {format(parseISO(f.neste_oppfolging), "d. MMM yyyy", { locale: nb })}
                                </p>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={(open) => {
        setDialogOpen(open);
        if (!open) resetForm();
      }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Registrer oppfølging</DialogTitle>
            <DialogDescription>
              {selectedFravaerId && sickLeaves.find(s => s.id === selectedFravaerId)?.user_name}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Type oppfølging</Label>
              <Select value={formType} onValueChange={setFormType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {FOLLOWUP_TYPES.map(type => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Dato</Label>
              <Input type="date" value={formDato} onChange={e => setFormDato(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Notater</Label>
              <Textarea 
                value={formNotater} 
                onChange={e => setFormNotater(e.target.value)}
                placeholder="Oppsummering av samtale/møte..."
                rows={3}
              />
            </div>
            <div className="space-y-2">
              <Label>Neste oppfølging (valgfritt)</Label>
              <Input 
                type="date" 
                value={formNesteOppfolging} 
                onChange={e => setFormNesteOppfolging(e.target.value)} 
              />
            </div>
            <Button onClick={handleAddFollowUp} className="w-full" disabled={saving}>
              {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Lagre oppfølging
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}