import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Calendar, Plus, Check, X, Loader2 } from "lucide-react";
import { format } from "date-fns";
import { nb } from "date-fns/locale";
import { LeaveRequestForm } from "./LeaveRequestForm";

interface LeaveRequestListProps {
  salonId: string;
  userId?: string;
  year: number;
  canManage: boolean;
}

interface LeaveRequest {
  id: string;
  user_id: string;
  user_name: string;
  startdato: string;
  sluttdato: string;
  antall_dager: number | null;
  timer: number | null;
  status: string;
  kommentar: string | null;
  godkjent_av: string | null;
  godkjent_dato: string | null;
}

export function LeaveRequestList({ salonId, userId, year, canManage }: LeaveRequestListProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [requests, setRequests] = useState<LeaveRequest[]>([]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [processing, setProcessing] = useState<string | null>(null);

  const fetchRequests = async () => {
    setLoading(true);
    try {
      let query = supabase
        .from("ferie")
        .select(`
          id, user_id, startdato, sluttdato, antall_dager, timer, status, kommentar, godkjent_av, godkjent_dato,
          users!ferie_user_id_fkey(name)
        `)
        .eq("salon_id", salonId)
        .eq("aar", year)
        .order("startdato", { ascending: true });

      if (userId) {
        query = query.eq("user_id", userId);
      }

      const { data, error } = await query;
      if (error) throw error;

      const formatted: LeaveRequest[] = (data || []).map(r => ({
        id: r.id,
        user_id: r.user_id,
        user_name: (r.users as any)?.name || "Ukjent",
        startdato: r.startdato,
        sluttdato: r.sluttdato,
        antall_dager: r.antall_dager,
        timer: r.timer,
        status: r.status || "planlagt",
        kommentar: r.kommentar,
        godkjent_av: r.godkjent_av,
        godkjent_dato: r.godkjent_dato
      }));

      setRequests(formatted);
    } catch (error) {
      console.error("Error fetching leave requests:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke hente feriesøknader",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRequests();
  }, [salonId, userId, year]);

  const handleApprove = async (requestId: string) => {
    setProcessing(requestId);
    try {
      await supabase
        .from("ferie")
        .update({
          status: "godkjent",
          godkjent_av: user?.id,
          godkjent_dato: new Date().toISOString()
        })
        .eq("id", requestId);

      toast({ title: "Godkjent", description: "Feriesøknaden er godkjent" });
      fetchRequests();
    } catch (error) {
      console.error("Error approving:", error);
      toast({ title: "Feil", description: "Kunne ikke godkjenne", variant: "destructive" });
    } finally {
      setProcessing(null);
    }
  };

  const handleReject = async (requestId: string) => {
    setProcessing(requestId);
    try {
      await supabase
        .from("ferie")
        .update({ status: "avslatt" })
        .eq("id", requestId);

      toast({ title: "Avslått", description: "Feriesøknaden er avslått" });
      fetchRequests();
    } catch (error) {
      console.error("Error rejecting:", error);
      toast({ title: "Feil", description: "Kunne ikke avslå", variant: "destructive" });
    } finally {
      setProcessing(null);
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, { variant: "default" | "secondary" | "destructive" | "outline"; label: string }> = {
      planlagt: { variant: "secondary", label: "Planlagt" },
      godkjent: { variant: "default", label: "Godkjent" },
      avholdt: { variant: "outline", label: "Avholdt" },
      avslatt: { variant: "destructive", label: "Avslått" }
    };
    const config = variants[status] || { variant: "secondary", label: status };
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  if (loading) {
    return <Skeleton className="h-64" />;
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Feriesøknader
            </CardTitle>
            <CardDescription>Oversikt over planlagt og avholdt ferie</CardDescription>
          </div>
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Ny søknad
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Ny feriesøknad</DialogTitle>
                <DialogDescription>Registrer ferie for {year}</DialogDescription>
              </DialogHeader>
              <LeaveRequestForm
                salonId={salonId}
                year={year}
                onSuccess={() => {
                  setDialogOpen(false);
                  fetchRequests();
                }}
              />
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        {requests.length === 0 ? (
          <p className="text-center text-muted-foreground py-8">
            Ingen feriesøknader registrert for {year}.
          </p>
        ) : (
          <div className="space-y-3">
            {requests.map(request => (
              <div
                key={request.id}
                className="flex items-center justify-between p-4 rounded-lg border bg-card"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{request.user_name}</span>
                    {getStatusBadge(request.status)}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {format(new Date(request.startdato), "d. MMM", { locale: nb })} - {format(new Date(request.sluttdato), "d. MMM yyyy", { locale: nb })}
                    {request.timer && <span className="ml-2">({request.timer}t)</span>}
                  </div>
                  {request.kommentar && (
                    <p className="text-sm text-muted-foreground">{request.kommentar}</p>
                  )}
                </div>

                {canManage && request.status === "planlagt" && (
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleApprove(request.id)}
                      disabled={processing === request.id}
                    >
                      {processing === request.id ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Check className="h-4 w-4" />
                      )}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleReject(request.id)}
                      disabled={processing === request.id}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
