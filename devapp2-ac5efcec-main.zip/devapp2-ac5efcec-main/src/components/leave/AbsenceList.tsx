import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertCircle, Plus } from "lucide-react";
import { format } from "date-fns";
import { nb } from "date-fns/locale";
import { AbsenceForm } from "./AbsenceForm";
import type { Database } from "@/integrations/supabase/types";

type Fravaerstype = Database["public"]["Enums"]["fravaerstype"];

interface AbsenceListProps {
  salonId: string;
  userId?: string;
  year: number;
  canManage: boolean;
}

interface AbsenceRecord {
  id: string;
  user_id: string;
  user_name: string;
  fravaerstype: Fravaerstype;
  startdato: string;
  sluttdato: string;
  timer: number | null;
  prosent: number | null;
  kommentar: string | null;
  status: string | null;
}

const ABSENCE_TYPE_LABELS: Record<Fravaerstype, string> = {
  egenmelding: "Egenmelding",
  sykmelding: "Sykmelding",
  lege_helse: "Lege/helse",
  velferdspermisjon: "Velferdspermisjon",
  foreldrepermisjon: "Foreldrepermisjon",
  ulonnet_permisjon: "Ulønnet permisjon",
  annet: "Annet"
};

export function AbsenceList({ salonId, userId, year, canManage }: AbsenceListProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [absences, setAbsences] = useState<AbsenceRecord[]>([]);
  const [dialogOpen, setDialogOpen] = useState(false);

  const fetchAbsences = async () => {
    setLoading(true);
    try {
      let query = supabase
        .from("fravaer")
        .select(`
          id, user_id, fravaerstype, startdato, sluttdato, timer, prosent, kommentar, status,
          users!fravaer_user_id_fkey(name)
        `)
        .eq("salon_id", salonId)
        .gte("startdato", `${year}-01-01`)
        .lte("startdato", `${year}-12-31`)
        .order("startdato", { ascending: false });

      if (userId) {
        query = query.eq("user_id", userId);
      }

      const { data, error } = await query;
      if (error) throw error;

      const formatted: AbsenceRecord[] = (data || []).map(r => ({
        id: r.id,
        user_id: r.user_id,
        user_name: (r.users as any)?.name || "Ukjent",
        fravaerstype: r.fravaerstype,
        startdato: r.startdato,
        sluttdato: r.sluttdato,
        timer: r.timer,
        prosent: r.prosent,
        kommentar: r.kommentar,
        status: r.status
      }));

      setAbsences(formatted);
    } catch (error) {
      console.error("Error fetching absences:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke hente fravær",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAbsences();
  }, [salonId, userId, year]);

  const getTypeBadgeVariant = (type: Fravaerstype): "default" | "secondary" | "destructive" | "outline" => {
    switch (type) {
      case "egenmelding":
        return "secondary";
      case "sykmelding":
        return "destructive";
      case "lege_helse":
        return "outline";
      default:
        return "default";
    }
  };

  if (loading) {
    return <Skeleton className="h-64" />;
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5" />
              Fraværsoversikt
            </CardTitle>
            <CardDescription>Registrert fravær for {year}</CardDescription>
          </div>
          {canManage && (
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Registrer fravær
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Registrer fravær</DialogTitle>
                  <DialogDescription>Legg til fraværsregistrering</DialogDescription>
                </DialogHeader>
                <AbsenceForm
                  salonId={salonId}
                  onSuccess={() => {
                    setDialogOpen(false);
                    fetchAbsences();
                  }}
                />
              </DialogContent>
            </Dialog>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {absences.length === 0 ? (
          <p className="text-center text-muted-foreground py-8">
            Ingen fravær registrert for {year}.
          </p>
        ) : (
          <div className="space-y-3">
            {absences.map(absence => (
              <div
                key={absence.id}
                className="flex items-center justify-between p-4 rounded-lg border bg-card"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{absence.user_name}</span>
                    <Badge variant={getTypeBadgeVariant(absence.fravaerstype)}>
                      {ABSENCE_TYPE_LABELS[absence.fravaerstype]}
                    </Badge>
                    {absence.prosent && absence.prosent < 100 && (
                      <Badge variant="outline">{absence.prosent}%</Badge>
                    )}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {format(new Date(absence.startdato), "d. MMM", { locale: nb })}
                    {absence.startdato !== absence.sluttdato && (
                      <> - {format(new Date(absence.sluttdato), "d. MMM yyyy", { locale: nb })}</>
                    )}
                    {absence.timer && <span className="ml-2">({absence.timer}t)</span>}
                  </div>
                  {absence.kommentar && (
                    <p className="text-sm text-muted-foreground">{absence.kommentar}</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
