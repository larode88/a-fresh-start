import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2 } from "lucide-react";
import type { Database } from "@/integrations/supabase/types";

type Fravaerstype = Database["public"]["Enums"]["fravaerstype"];

interface AbsenceFormProps {
  salonId: string;
  onSuccess: () => void;
}

const ABSENCE_TYPES: { value: Fravaerstype; label: string }[] = [
  { value: "egenmelding", label: "Egenmelding" },
  { value: "sykmelding", label: "Sykmelding" },
  { value: "lege_helse", label: "Lege/helse" },
  { value: "velferdspermisjon", label: "Velferdspermisjon" },
  { value: "foreldrepermisjon", label: "Foreldrepermisjon" },
  { value: "ulonnet_permisjon", label: "Ulønnet permisjon" },
  { value: "annet", label: "Annet" }
];

interface Employee {
  id: string;
  name: string;
}

export function AbsenceForm({ salonId, onSuccess }: AbsenceFormProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [saving, setSaving] = useState(false);
  const [employees, setEmployees] = useState<Employee[]>([]);
  
  const [selectedUserId, setSelectedUserId] = useState("");
  const [fravaerstype, setFravaerstype] = useState<Fravaerstype>("egenmelding");
  const [startdato, setStartdato] = useState("");
  const [sluttdato, setSluttdato] = useState("");
  const [prosent, setProsent] = useState("100");
  const [kommentar, setKommentar] = useState("");

  useEffect(() => {
    const fetchEmployees = async () => {
      const { data, error } = await supabase
        .from("users")
        .select("id, name")
        .eq("salon_id", salonId)
        .eq("aktiv", true)
        .order("name");

      if (!error && data) {
        setEmployees(data);
        if (data.length > 0) {
          setSelectedUserId(data[0].id);
        }
      }
    };

    fetchEmployees();
  }, [salonId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !selectedUserId || !startdato || !sluttdato) return;

    setSaving(true);
    try {
      const start = new Date(startdato);
      const end = new Date(sluttdato);
      
      if (end < start) {
        toast({
          title: "Feil",
          description: "Sluttdato må være etter startdato",
          variant: "destructive"
        });
        return;
      }

      const { error } = await supabase.from("fravaer").insert({
        salon_id: salonId,
        user_id: selectedUserId,
        fravaerstype,
        startdato,
        sluttdato,
        prosent: parseInt(prosent),
        kommentar: kommentar || null,
        registrert_av: user.id,
        status: "aktiv"
      });

      if (error) throw error;

      toast({
        title: "Registrert",
        description: "Fraværet er registrert"
      });
      onSuccess();
    } catch (error) {
      console.error("Error creating absence:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke registrere fravær",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="employee">Ansatt</Label>
        <Select value={selectedUserId} onValueChange={setSelectedUserId}>
          <SelectTrigger>
            <SelectValue placeholder="Velg ansatt" />
          </SelectTrigger>
          <SelectContent>
            {employees.map(emp => (
              <SelectItem key={emp.id} value={emp.id}>{emp.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="type">Type fravær</Label>
        <Select value={fravaerstype} onValueChange={(v) => setFravaerstype(v as Fravaerstype)}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {ABSENCE_TYPES.map(type => (
              <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="startdato">Fra dato</Label>
          <Input
            id="startdato"
            type="date"
            value={startdato}
            onChange={(e) => setStartdato(e.target.value)}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="sluttdato">Til dato</Label>
          <Input
            id="sluttdato"
            type="date"
            value={sluttdato}
            onChange={(e) => setSluttdato(e.target.value)}
            required
          />
        </div>
      </div>

      {(fravaerstype === "sykmelding" || fravaerstype === "foreldrepermisjon") && (
        <div className="space-y-2">
          <Label htmlFor="prosent">Stillingsprosent fravær</Label>
          <Select value={prosent} onValueChange={setProsent}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="100">100%</SelectItem>
              <SelectItem value="80">80%</SelectItem>
              <SelectItem value="60">60%</SelectItem>
              <SelectItem value="50">50%</SelectItem>
              <SelectItem value="40">40%</SelectItem>
              <SelectItem value="20">20%</SelectItem>
            </SelectContent>
          </Select>
        </div>
      )}

      <div className="space-y-2">
        <Label htmlFor="kommentar">Kommentar (valgfritt)</Label>
        <Textarea
          id="kommentar"
          value={kommentar}
          onChange={(e) => setKommentar(e.target.value)}
          placeholder="Eventuell kommentar..."
          rows={3}
        />
      </div>

      <Button type="submit" className="w-full" disabled={saving}>
        {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
        Registrer fravær
      </Button>
    </form>
  );
}
