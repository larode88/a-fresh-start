import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Loader2 } from "lucide-react";
import { differenceInBusinessDays } from "date-fns";

interface LeaveRequestFormProps {
  salonId: string;
  year: number;
  onSuccess: () => void;
}

export function LeaveRequestForm({ salonId, year, onSuccess }: LeaveRequestFormProps) {
  const { user, profile } = useAuth();
  const { toast } = useToast();
  const [saving, setSaving] = useState(false);
  const [startdato, setStartdato] = useState("");
  const [sluttdato, setSluttdato] = useState("");
  const [kommentar, setKommentar] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !startdato || !sluttdato) return;

    setSaving(true);
    try {
      const start = new Date(startdato);
      const end = new Date(sluttdato);
      
      if (end < start) {
        toast({
          title: "Feil",
          description: "Sluttdato må være etter startdato",
          variant: "destructive"
        });
        return;
      }

      // Calculate business days and hours
      const businessDays = differenceInBusinessDays(end, start) + 1;
      const stillingsprosent = 100; // Default to 100%
      const hoursPerDay = 7.5 * (stillingsprosent / 100);
      const totalHours = businessDays * hoursPerDay;

      const { error } = await supabase.from("ferie").insert({
        salon_id: salonId,
        user_id: user.id,
        aar: year,
        startdato,
        sluttdato,
        antall_dager: businessDays,
        timer: totalHours,
        status: "planlagt",
        kommentar: kommentar || null
      });

      if (error) throw error;

      toast({
        title: "Søknad registrert",
        description: `Feriesøknad for ${businessDays} dager er sendt`
      });
      onSuccess();
    } catch (error) {
      console.error("Error creating leave request:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke registrere feriesøknad",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="startdato">Fra dato</Label>
          <Input
            id="startdato"
            type="date"
            value={startdato}
            onChange={(e) => setStartdato(e.target.value)}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="sluttdato">Til dato</Label>
          <Input
            id="sluttdato"
            type="date"
            value={sluttdato}
            onChange={(e) => setSluttdato(e.target.value)}
            required
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="kommentar">Kommentar (valgfritt)</Label>
        <Textarea
          id="kommentar"
          value={kommentar}
          onChange={(e) => setKommentar(e.target.value)}
          placeholder="Eventuell kommentar..."
          rows={3}
        />
      </div>

      <Button type="submit" className="w-full" disabled={saving}>
        {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
        Send søknad
      </Button>
    </form>
  );
}
