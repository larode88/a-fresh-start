import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { ChevronLeft, ChevronRight, ExternalLink } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

interface Announcement {
  id: string;
  title: string;
  description: string | null;
  image_url: string | null;
  link_type: string;
  external_url: string | null;
  slug: string;
  target_roles: string[] | null;
}

export function AnnouncementCarousel() {
  const { profile } = useAuth();
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAnnouncements();
  }, [profile?.role]);

  const fetchAnnouncements = async () => {
    const { data, error } = await supabase
      .from("announcements")
      .select("id, title, description, image_url, link_type, external_url, slug, target_roles")
      .eq("published", true)
      .order("display_order", { ascending: true });

    if (!error && data) {
      // Filter by role if target_roles is set
      const filtered = data.filter((a) => {
        if (!a.target_roles || a.target_roles.length === 0) return true;
        return profile?.role && a.target_roles.includes(profile.role);
      });
      setAnnouncements(filtered);
    }
    setLoading(false);
  };

  useEffect(() => {
    if (announcements.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % announcements.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [announcements.length]);

  const goToPrevious = () => {
    setCurrentIndex((prev) => (prev - 1 + announcements.length) % announcements.length);
  };

  const goToNext = () => {
    setCurrentIndex((prev) => (prev + 1) % announcements.length);
  };

  if (loading) {
    return <Skeleton className="h-36 w-full rounded-xl" />;
  }

  if (announcements.length === 0) {
    return null;
  }

  const current = announcements[currentIndex];
  const isExternal = current.link_type === "external" && current.external_url;

  const CardContent = (
    <div className="relative h-[140px] sm:h-[160px] lg:h-[200px] w-full overflow-hidden group cursor-pointer rounded-none sm:mx-4 sm:rounded-xl bg-gray-900">
      {current.image_url && (
        <img
          src={current.image_url}
          alt={current.title}
          className="absolute inset-0 h-full w-full min-h-full min-w-full object-cover object-center opacity-80 group-hover:opacity-90 transition-opacity"
        />
      )}
      <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-black/20" />
      <div className="absolute inset-0 bg-gradient-to-t from-black/30 via-transparent to-transparent" />
      <div className="relative z-10 flex h-full flex-col justify-center px-6 sm:px-8 lg:px-12">
        <h3 className="text-xl sm:text-2xl lg:text-3xl font-bold text-white line-clamp-2 drop-shadow-lg max-w-3xl">
          {current.title}
        </h3>
        {current.description && (
          <p className="mt-1 sm:mt-2 text-sm sm:text-base lg:text-lg text-white/90 line-clamp-2 drop-shadow-md max-w-3xl">
            {current.description}
          </p>
        )}
        <div className="mt-2 sm:mt-3">
          <span className="inline-flex items-center gap-2 text-sm sm:text-base font-semibold text-white/90 group-hover:text-white underline underline-offset-4 transition-colors">
            Les mer
            {isExternal && <ExternalLink className="h-4 w-4" />}
          </span>
        </div>
      </div>
    </div>
  );

  return (
    <div className="relative mb-6">
      {isExternal ? (
        <a href={current.external_url!} target="_blank" rel="noopener noreferrer">
          {CardContent}
        </a>
      ) : (
        <Link to={`/news/${current.slug}`}>{CardContent}</Link>
      )}

      {announcements.length > 1 && (
        <>
          <Button
            variant="ghost"
            size="icon"
            className="absolute left-4 sm:left-8 lg:left-16 top-1/2 -translate-y-1/2 h-10 w-10 sm:h-12 sm:w-12 rounded-full bg-white/20 text-white hover:bg-white/40 backdrop-blur-sm transition-all"
            onClick={(e) => {
              e.preventDefault();
              goToPrevious();
            }}
          >
            <ChevronLeft className="h-5 w-5 sm:h-6 sm:w-6" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="absolute right-4 sm:right-8 lg:right-16 top-1/2 -translate-y-1/2 h-10 w-10 sm:h-12 sm:w-12 rounded-full bg-white/20 text-white hover:bg-white/40 backdrop-blur-sm transition-all"
            onClick={(e) => {
              e.preventDefault();
              goToNext();
            }}
          >
            <ChevronRight className="h-5 w-5 sm:h-6 sm:w-6" />
          </Button>

          <div className="absolute bottom-4 sm:bottom-6 left-1/2 -translate-x-1/2 flex gap-2">
            {announcements.map((_, idx) => (
              <button
                key={idx}
                onClick={(e) => {
                  e.preventDefault();
                  setCurrentIndex(idx);
                }}
                className={`h-2 sm:h-2.5 rounded-full transition-all ${
                  idx === currentIndex
                    ? "w-6 sm:w-8 bg-white"
                    : "w-2 sm:w-2.5 bg-white/50 hover:bg-white/70"
                }`}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
