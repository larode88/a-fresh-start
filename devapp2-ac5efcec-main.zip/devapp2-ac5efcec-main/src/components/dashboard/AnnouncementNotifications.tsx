import { useState, useEffect } from "react";
import { Bell } from "lucide-react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { format } from "date-fns";
import { nb } from "date-fns/locale";

interface Notification {
  id: string;
  announcement_id: string;
  read_at: string | null;
  created_at: string;
  announcement: {
    title: string;
    slug: string;
    description: string | null;
  };
}

interface AnnouncementNotificationsProps {
  inDropdown?: boolean;
}

export function AnnouncementNotifications({ inDropdown = false }: AnnouncementNotificationsProps) {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (user) {
      fetchNotifications();
    }
  }, [user]);

  const fetchNotifications = async () => {
    const { data, error } = await supabase
      .from("announcement_notifications")
      .select(`
        id,
        announcement_id,
        read_at,
        created_at,
        announcement:announcements(title, slug, description)
      `)
      .eq("user_id", user!.id)
      .order("created_at", { ascending: false })
      .limit(10);

    if (!error && data) {
      const validNotifications = data.filter(n => n.announcement) as Notification[];
      setNotifications(validNotifications);
      setUnreadCount(validNotifications.filter(n => !n.read_at).length);
    }
  };

  const markAsRead = async (notificationId: string) => {
    await supabase
      .from("announcement_notifications")
      .update({ read_at: new Date().toISOString() })
      .eq("id", notificationId);
    
    fetchNotifications();
  };

  const markAllAsRead = async () => {
    const unreadIds = notifications.filter(n => !n.read_at).map(n => n.id);
    if (unreadIds.length === 0) return;

    await supabase
      .from("announcement_notifications")
      .update({ read_at: new Date().toISOString() })
      .in("id", unreadIds);
    
    fetchNotifications();
  };

  // When used inside a dropdown menu, render as a simple menu item trigger
  if (inDropdown) {
    return (
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <button className="flex items-center w-full px-2 py-1.5 text-sm hover:bg-accent rounded-sm cursor-pointer">
            <Bell className="mr-2 h-4 w-4" />
            Varsler
            {unreadCount > 0 && (
              <Badge className="ml-auto h-5 min-w-5 flex items-center justify-center text-xs px-1">
                {unreadCount}
              </Badge>
            )}
          </button>
        </PopoverTrigger>
        <PopoverContent className="w-80 p-0 bg-popover border border-border shadow-lg z-[60]" align="end" side="right">
          <div className="flex items-center justify-between p-3 border-b">
            <h4 className="font-semibold text-sm">Varsler</h4>
            {unreadCount > 0 && (
              <Button variant="ghost" size="sm" onClick={markAllAsRead}>
                Merk alle som lest
              </Button>
            )}
          </div>
          <div className="max-h-80 overflow-y-auto">
            {notifications.length === 0 ? (
              <p className="p-4 text-sm text-muted-foreground text-center">
                Ingen varsler
              </p>
            ) : (
              notifications.map((notification) => (
                <Link
                  key={notification.id}
                  to={`/news/${notification.announcement.slug}`}
                  onClick={() => {
                    if (!notification.read_at) {
                      markAsRead(notification.id);
                    }
                    setOpen(false);
                  }}
                  className={`block p-3 border-b hover:bg-muted/50 transition-colors ${
                    !notification.read_at ? "bg-primary/5" : ""
                  }`}
                >
                  <div className="flex items-start gap-2">
                    {!notification.read_at && (
                      <span className="mt-1.5 h-2 w-2 rounded-full bg-primary flex-shrink-0" />
                    )}
                    <div className={!notification.read_at ? "" : "ml-4"}>
                      <p className="text-sm font-medium line-clamp-1">
                        {notification.announcement.title}
                      </p>
                      {notification.announcement.description && (
                        <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">
                          {notification.announcement.description}
                        </p>
                      )}
                      <p className="text-xs text-muted-foreground mt-1">
                        {format(new Date(notification.created_at), "d. MMM HH:mm", { locale: nb })}
                      </p>
                    </div>
                  </div>
                </Link>
              ))
            )}
          </div>
        </PopoverContent>
      </Popover>
    );
  }

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="outline" size="icon" className="relative">
          <Bell className="h-4 w-4" />
          {unreadCount > 0 && (
            <span className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-destructive text-destructive-foreground text-xs flex items-center justify-center">
              {unreadCount > 9 ? "9+" : unreadCount}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0 bg-popover border border-border shadow-lg z-50" align="end">
        <div className="flex items-center justify-between p-3 border-b">
          <h4 className="font-semibold text-sm">Varsler</h4>
          {unreadCount > 0 && (
            <Button variant="ghost" size="sm" onClick={markAllAsRead}>
              Merk alle som lest
            </Button>
          )}
        </div>
        <div className="max-h-80 overflow-y-auto">
          {notifications.length === 0 ? (
            <p className="p-4 text-sm text-muted-foreground text-center">
              Ingen varsler
            </p>
          ) : (
            notifications.map((notification) => (
              <Link
                key={notification.id}
                to={`/news/${notification.announcement.slug}`}
                onClick={() => {
                  if (!notification.read_at) {
                    markAsRead(notification.id);
                  }
                  setOpen(false);
                }}
                className={`block p-3 border-b hover:bg-muted/50 transition-colors ${
                  !notification.read_at ? "bg-primary/5" : ""
                }`}
              >
                <div className="flex items-start gap-2">
                  {!notification.read_at && (
                    <span className="mt-1.5 h-2 w-2 rounded-full bg-primary flex-shrink-0" />
                  )}
                  <div className={!notification.read_at ? "" : "ml-4"}>
                    <p className="text-sm font-medium line-clamp-1">
                      {notification.announcement.title}
                    </p>
                    {notification.announcement.description && (
                      <p className="text-xs text-muted-foreground line-clamp-2 mt-0.5">
                        {notification.announcement.description}
                      </p>
                    )}
                    <p className="text-xs text-muted-foreground mt-1">
                      {format(new Date(notification.created_at), "d. MMM HH:mm", { locale: nb })}
                    </p>
                  </div>
                </div>
              </Link>
            ))
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}
