import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card } from "@/components/ui/card";
import { Target, Trophy, Calendar, TrendingUp } from "lucide-react";

interface Challenge {
  id: string;
  title: string;
  description: string | null;
  goal_description: string | null;
  kpi_focus: string;
  period_type: string;
  target_value: number | null;
  month: number;
  year: number;
}

interface ChallengeProgress {
  progress_value: number;
  achieved: boolean;
}

const periodLabels: Record<string, string> = {
  month: "Månedens",
  quarter: "Kvartalets",
  half_year: "Halvårets",
  year: "Årets",
};

export const ChallengeCard = () => {
  const { profile } = useAuth();
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [progressMap, setProgressMap] = useState<Record<string, ChallengeProgress>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchChallengeData = async () => {
      if (!profile?.salon_id) return;

      const now = new Date();
      const currentYear = now.getFullYear();
      const currentMonth = now.getMonth() + 1;
      const currentQuarter = Math.ceil(currentMonth / 3);
      const currentHalf = currentMonth <= 6 ? 1 : 2;

      try {
        // Fetch active challenges for current periods
        const { data: challengeData, error: challengeError } = await supabase
          .from("monthly_challenges")
          .select("*")
          .eq("year", currentYear)
          .or(`and(period_type.eq.month,month.eq.${currentMonth}),and(period_type.eq.quarter,month.eq.${currentQuarter}),and(period_type.eq.half_year,month.eq.${currentHalf}),period_type.eq.year`);

        if (challengeError) throw challengeError;
        setChallenges(challengeData || []);

        // Fetch salon's progress for these challenges
        if (challengeData && challengeData.length > 0) {
          const { data: progressData } = await supabase
            .from("challenge_progress")
            .select("*")
            .eq("salon_id", profile.salon_id)
            .eq("year", currentYear);

          if (progressData) {
            const map: Record<string, ChallengeProgress> = {};
            progressData.forEach((p) => {
              const key = `${p.year}-${p.month}-${p.period_type}`;
              map[key] = { progress_value: p.progress_value || 0, achieved: p.achieved || false };
            });
            setProgressMap(map);
          }
        }
      } catch (error) {
        console.error("Error fetching challenge data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchChallengeData();
  }, [profile?.salon_id]);

  if (loading) {
    return (
      <Card className="lg:col-span-2 p-6">
        <div className="animate-pulse">
          <div className="h-6 bg-muted rounded w-1/3 mb-4"></div>
          <div className="h-24 bg-muted rounded"></div>
        </div>
      </Card>
    );
  }

  if (challenges.length === 0) {
    return (
      <Card className="lg:col-span-2 p-6">
        <div className="text-center py-8">
          <Target className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
          <p className="text-muted-foreground">Ingen aktive challenges akkurat nå</p>
        </div>
      </Card>
    );
  }

  return (
    <Card className="lg:col-span-2 p-6 border-border shadow-card">
      <h2 className="text-xl font-semibold mb-4 text-foreground flex items-center gap-2">
        <Trophy className="h-5 w-5 text-accent" />
        Aktive Challenges
      </h2>
      <div className="space-y-4">
        {challenges.map((challenge) => {
          const progressKey = `${challenge.year}-${challenge.month}-${challenge.period_type}`;
          const progress = progressMap[progressKey];
          const progressValue = progress?.progress_value || 0;
          const targetValue = challenge.target_value || 75;
          const progressPercent = Math.min((progressValue / targetValue) * 100, 100);
          const remainingPercent = Math.max(targetValue - progressValue, 0);

          return (
            <div
              key={challenge.id}
              className="bg-gradient-to-br from-accent/10 to-accent/5 rounded-lg p-4 border border-accent/20"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs px-2 py-0.5 rounded-full bg-accent/20 text-accent font-medium">
                      {periodLabels[challenge.period_type] || "Månedens"} Challenge
                    </span>
                  </div>
                  <h3 className="text-lg font-semibold text-accent">
                    {challenge.title}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {challenge.goal_description}
                  </p>
                </div>
                <div className="text-right ml-4">
                  <p className="text-2xl font-bold text-accent">
                    {progressValue.toFixed(0)}%
                  </p>
                  <p className="text-xs text-muted-foreground">av {targetValue}%</p>
                </div>
              </div>
              
              <div className="w-full bg-background/50 rounded-full h-2.5 overflow-hidden">
                <div
                  className="bg-gradient-to-r from-accent to-accent/80 h-full rounded-full transition-all duration-500"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
              
              {progress?.achieved ? (
                <p className="text-sm font-medium text-green-600 mt-2 flex items-center gap-2">
                  <TrendingUp className="h-4 w-4" /> Målet er nådd!
                </p>
              ) : (
                <p className="text-xs text-muted-foreground mt-2">
                  {remainingPercent > 0 ? `${remainingPercent.toFixed(1)}% igjen til målet` : "Over målet!"}
                </p>
              )}
            </div>
          );
        })}
      </div>
    </Card>
  );
};