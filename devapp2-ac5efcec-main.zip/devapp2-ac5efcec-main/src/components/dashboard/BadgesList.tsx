import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card } from "@/components/ui/card";
import { Award } from "lucide-react";

interface Badge {
  id: string;
  name: string;
  icon_key: string;
  description: string;
  earned_at: string;
}

export const BadgesList = () => {
  const { user } = useAuth();
  const [badges, setBadges] = useState<Badge[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchBadges = async () => {
      if (!user) return;

      try {
        const { data, error } = await supabase
          .from("user_badges")
          .select(`
            id,
            earned_at,
            badge:badges (
              id,
              name,
              icon_key,
              description
            )
          `)
          .eq("user_id", user.id)
          .order("earned_at", { ascending: false });

        if (error) throw error;

        const formattedBadges = data.map((item: any) => ({
          id: item.badge.id,
          name: item.badge.name,
          icon_key: item.badge.icon_key,
          description: item.badge.description,
          earned_at: item.earned_at,
        }));

        setBadges(formattedBadges);
      } catch (error) {
        console.error("Error fetching badges:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchBadges();
  }, [user]);

  if (loading) {
    return (
      <Card className="p-6">
        <h2 className="text-xl font-semibold mb-4 text-foreground">Mine Badges</h2>
        <div className="space-y-3">
          {[1, 2].map((i) => (
            <div key={i} className="animate-pulse flex items-center gap-3 p-3 bg-muted rounded-lg">
              <div className="w-10 h-10 rounded-full bg-muted-foreground/20"></div>
              <div className="flex-1">
                <div className="h-4 bg-muted-foreground/20 rounded w-2/3 mb-2"></div>
                <div className="h-3 bg-muted-foreground/20 rounded w-full"></div>
              </div>
            </div>
          ))}
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-6 border-border shadow-card">
      <h2 className="text-xl font-semibold mb-4 text-foreground">Mine Badges</h2>
      
      {badges.length === 0 ? (
        <div className="text-center py-8">
          <Award className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
          <p className="text-sm text-muted-foreground">
            Ingen badges ennå. Hold ut og oppnå dine mål!
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {badges.map((badge) => (
            <div
              key={badge.id}
              className="flex items-center gap-3 p-3 bg-gradient-to-br from-success/10 to-success/5 rounded-lg border border-success/20 transition-smooth hover:shadow-md"
            >
              <div className="w-10 h-10 rounded-full bg-success flex items-center justify-center text-white text-xl font-bold shadow-sm">
                {badge.icon_key}
              </div>
              <div className="flex-1">
                <p className="font-medium text-foreground">{badge.name}</p>
                <p className="text-xs text-muted-foreground">{badge.description}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </Card>
  );
};
