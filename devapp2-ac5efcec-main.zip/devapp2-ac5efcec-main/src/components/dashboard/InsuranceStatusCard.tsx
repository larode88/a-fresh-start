import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Shield, ShieldCheck, ShieldAlert, ArrowRight, Clock } from "lucide-react";

export function InsuranceStatusCard() {
  const navigate = useNavigate();
  const { profile } = useAuth();
  const salonId = profile?.salon_id;

  const { data: insurance, isLoading } = useQuery({
    queryKey: ["salon-insurance-status", salonId],
    queryFn: async () => {
      if (!salonId) return null;
      const { data, error } = await supabase
        .from("salon_insurance")
        .select("*")
        .eq("salon_id", salonId)
        .single();
      if (error && error.code !== "PGRST116") throw error;
      return data;
    },
    enabled: !!salonId,
  });

  const { data: pendingOrders } = useQuery({
    queryKey: ["insurance-pending-orders-count", salonId],
    queryFn: async () => {
      if (!salonId) return 0;
      const { count, error } = await supabase
        .from("insurance_orders")
        .select("*", { count: "exact", head: true })
        .eq("salon_id", salonId)
        .in("status", ["pending_approval", "approved", "sent_to_frende"]);
      if (error) throw error;
      return count || 0;
    },
    enabled: !!salonId,
  });

  if (!salonId) return null;

  const getActiveCount = () => {
    if (!insurance) return 0;
    let count = 0;
    if (insurance.salong_aktiv) count++;
    if (insurance.yrkesskadeforsikring_aktiv) count++;
    if (insurance.reise_aktiv) count++;
    if (insurance.fritidsulykke_aktiv) count++;
    if (insurance.cyber_aktiv) count++;
    if (insurance.helse_status) count++;
    return count;
  };

  const activeCount = getActiveCount();
  const hasInsurance = activeCount > 0;

  if (isLoading) {
    return (
      <Card>
        <CardContent className="py-6">
          <div className="animate-pulse h-20 bg-muted rounded" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="relative overflow-hidden">
      <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full -translate-y-1/2 translate-x-1/2" />
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-base">
          {hasInsurance ? (
            <ShieldCheck className="h-5 w-5 text-green-600" />
          ) : (
            <ShieldAlert className="h-5 w-5 text-amber-500" />
          )}
          Forsikringer
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-2xl font-bold">{activeCount}</p>
            <p className="text-sm text-muted-foreground">aktive forsikringer</p>
          </div>
          {pendingOrders && pendingOrders > 0 && (
            <Badge variant="secondary" className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              {pendingOrders} under behandling
            </Badge>
          )}
        </div>

        {hasInsurance ? (
          <div className="flex flex-wrap gap-1.5">
            {insurance?.salong_aktiv && (
              <Badge variant="outline" className="text-xs">Salong</Badge>
            )}
            {insurance?.yrkesskadeforsikring_aktiv && (
              <Badge variant="outline" className="text-xs">Yrkesskade</Badge>
            )}
            {insurance?.reise_aktiv && (
              <Badge variant="outline" className="text-xs">Reise</Badge>
            )}
            {insurance?.fritidsulykke_aktiv && (
              <Badge variant="outline" className="text-xs">Fritidsulykke</Badge>
            )}
            {insurance?.cyber_aktiv && (
              <Badge variant="outline" className="text-xs">Cyber</Badge>
            )}
            {insurance?.helse_status && (
              <Badge variant="outline" className="text-xs">Helse</Badge>
            )}
          </div>
        ) : (
          <p className="text-sm text-muted-foreground">
            Ingen aktive forsikringer registrert
          </p>
        )}

        <Button 
          variant="outline" 
          size="sm" 
          className="w-full"
          onClick={() => navigate("/insurance")}
        >
          <Shield className="h-4 w-4 mr-2" />
          Se forsikringer
          <ArrowRight className="h-4 w-4 ml-auto" />
        </Button>
      </CardContent>
    </Card>
  );
}
