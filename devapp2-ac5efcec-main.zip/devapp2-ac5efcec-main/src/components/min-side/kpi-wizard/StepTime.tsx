import { format, differenceInMinutes, parse } from "date-fns";
import { nb } from "date-fns/locale";
import { Clock, ChevronLeft, ChevronRight, Coffee, ChevronDown, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { cn } from "@/lib/utils";
import { DailyData } from "./types";
import { useIsMobile } from "@/hooks/use-mobile";
import { useState } from "react";

interface StepTimeProps {
  selectedDates: string[];
  dailyData: Record<string, DailyData>;
  onDataChange: (dateStr: string, field: keyof DailyData, value: any) => void;
  onPrevious: () => void;
  onNext: () => void;
}

export function StepTime({
  selectedDates,
  dailyData,
  onDataChange,
  onPrevious,
  onNext,
}: StepTimeProps) {
  const isMobile = useIsMobile();
  const [expandedDays, setExpandedDays] = useState<string[]>(
    selectedDates.length === 1 ? selectedDates : []
  );

  const calculateHours = (startTime: string, endTime: string, breakMinutes: number): number => {
    try {
      const start = parse(startTime, 'HH:mm', new Date());
      const end = parse(endTime, 'HH:mm', new Date());
      const minutes = differenceInMinutes(end, start) - breakMinutes;
      return Math.max(0, minutes / 60);
    } catch {
      return 0;
    }
  };

  const getTotalHours = () => {
    return selectedDates.reduce((total, dateStr) => {
      const data = dailyData[dateStr];
      if (!data) return total;
      return total + calculateHours(data.startTime, data.endTime, data.breakMinutes);
    }, 0);
  };

  const getTotalClientHours = () => {
    return selectedDates.reduce((total, dateStr) => {
      const data = dailyData[dateStr];
      if (!data) return total;
      return total + (data.hoursWithClient || 0);
    }, 0);
  };

  const getEfficiency = () => {
    const totalHours = getTotalHours();
    const clientHours = getTotalClientHours();
    if (totalHours <= 0) return 0;
    return Math.min(100, (clientHours / totalHours) * 100);
  };

  const toggleDay = (dateStr: string) => {
    setExpandedDays(prev => 
      prev.includes(dateStr) 
        ? prev.filter(d => d !== dateStr)
        : [...prev, dateStr]
    );
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Header */}
      <div className="text-center">
        <div className="inline-flex items-center gap-2 text-primary mb-2">
          <Clock className="h-5 w-5" />
          <h3 className="font-semibold">Timeregistrering</h3>
        </div>
        <p className="text-sm text-muted-foreground">
          {isMobile && selectedDates.length > 1 
            ? "Trykk på en dag for å redigere" 
            : `Legg inn arbeidstid for ${selectedDates.length === 1 ? 'denne dagen' : 'valgte dager'}`
          }
        </p>
      </div>

      {/* Total summary */}
      <div className="grid grid-cols-3 gap-2 sm:gap-3">
        <div className="bg-gradient-to-r from-primary/10 to-primary/5 rounded-lg p-3 text-center">
          <p className="text-xs text-muted-foreground mb-1">Totalt timer</p>
          <p className="text-xl sm:text-2xl font-bold text-primary">
            {getTotalHours().toFixed(1)}
          </p>
        </div>
        <div className="bg-gradient-to-r from-blue-500/10 to-blue-500/5 rounded-lg p-3 text-center">
          <p className="text-xs text-muted-foreground mb-1">Kundetimer</p>
          <p className="text-xl sm:text-2xl font-bold text-blue-600 dark:text-blue-400">
            {getTotalClientHours().toFixed(1)}
          </p>
        </div>
        <div className="bg-gradient-to-r from-green-500/10 to-green-500/5 rounded-lg p-3 text-center">
          <p className="text-xs text-muted-foreground mb-1">Effektivitet</p>
          <p className="text-xl sm:text-2xl font-bold text-green-600 dark:text-green-400">
            {getEfficiency().toFixed(0)}%
          </p>
          <Progress value={getEfficiency()} className="h-1 mt-1" />
        </div>
      </div>

      {/* Time entries */}
      <div className="space-y-2 sm:space-y-3">
        {selectedDates.sort().map((dateStr, index) => {
          const data = dailyData[dateStr];
          if (!data) return null;

          const hours = calculateHours(data.startTime, data.endTime, data.breakMinutes);
          const isExpanded = expandedDays.includes(dateStr) || !isMobile || selectedDates.length === 1;

          // Bruk collapsible layout for flere dager (alltid, for bedre UX)
          if (selectedDates.length > 1) {
            return (
              <Collapsible 
                key={dateStr} 
                open={isExpanded}
                onOpenChange={() => toggleDay(dateStr)}
              >
                <Card className="transition-all duration-200 overflow-hidden">
                  <CollapsibleTrigger asChild>
                    <CardContent className="p-3 sm:p-4 cursor-pointer active:bg-muted/50">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2 min-w-0 flex-1">
                          <span className="font-medium capitalize text-sm truncate">
                            {format(new Date(dateStr), 'EEEE', { locale: nb })}
                          </span>
                          <Badge variant="outline" className="text-xs flex-shrink-0">
                            {format(new Date(dateStr), 'd/M')}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-2 flex-shrink-0">
                          <Badge 
                            variant="secondary" 
                            className={cn(
                              "min-w-[50px] justify-center text-xs",
                              hours >= 7.5 && "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
                            )}
                          >
                            {hours.toFixed(1)}t
                          </Badge>
                          <ChevronDown className={cn(
                            "h-4 w-4 text-muted-foreground transition-transform flex-shrink-0",
                            isExpanded && "rotate-180"
                          )} />
                        </div>
                      </div>
                    </CardContent>
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    <div className="px-3 sm:px-4 pb-3 sm:pb-4 pt-0 space-y-3 border-t overflow-hidden">
                      <div className="grid grid-cols-2 gap-2 sm:gap-3 pt-3">
                        <div className="space-y-1">
                          <Label className="text-xs text-muted-foreground">Fra</Label>
                          <Input
                            type="time"
                            value={data.startTime}
                            onChange={(e) => onDataChange(dateStr, 'startTime', e.target.value)}
                            className="h-10 sm:h-11 text-center"
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs text-muted-foreground">Til</Label>
                          <Input
                            type="time"
                            value={data.endTime}
                            onChange={(e) => onDataChange(dateStr, 'endTime', e.target.value)}
                            className="h-10 sm:h-11 text-center"
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-2 sm:gap-3">
                        <div className="space-y-1">
                          <Label className="flex items-center gap-2 text-xs text-muted-foreground">
                            <Coffee className="h-3 w-3" />
                            Pause
                          </Label>
                          <div className="flex items-center gap-2">
                            <Input
                              type="number"
                              value={data.breakMinutes}
                              onChange={(e) => onDataChange(dateStr, 'breakMinutes', parseInt(e.target.value) || 0)}
                              className="w-20 h-10 text-center"
                              min={0}
                              step={5}
                              inputMode="numeric"
                            />
                            <span className="text-xs text-muted-foreground">min</span>
                          </div>
                        </div>
                        <div className="space-y-1">
                          <Label className="flex items-center gap-2 text-xs text-muted-foreground">
                            <Users className="h-3 w-3" />
                            Timer med kunde
                          </Label>
                          <div className="flex items-center gap-2">
                            <Input
                              type="number"
                              value={data.hoursWithClient || 0}
                              onChange={(e) => onDataChange(dateStr, 'hoursWithClient', parseFloat(e.target.value) || 0)}
                              className="w-20 h-10 text-center"
                              min={0}
                              step={0.5}
                              inputMode="decimal"
                            />
                            <span className="text-xs text-muted-foreground">timer</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CollapsibleContent>
                </Card>
              </Collapsible>
            );
          }

          // Single day view - optimalisert vertikal layout
          return (
            <Card 
              key={dateStr}
              className="transition-all duration-200 overflow-hidden"
            >
              <CardContent className="p-3 sm:p-4 space-y-3">
                {/* Rad 1: Dag + Timer */}
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="font-medium capitalize text-sm">
                      {format(new Date(dateStr), 'EEEE', { locale: nb })}
                    </span>
                    <Badge variant="outline" className="text-xs">
                      {format(new Date(dateStr), 'd/M')}
                    </Badge>
                  </div>
                  <Badge 
                    variant="secondary" 
                    className={cn(
                      "min-w-[50px] justify-center text-xs flex-shrink-0",
                      hours >= 7.5 && "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
                    )}
                  >
                    {hours.toFixed(1)}t
                  </Badge>
                </div>

                {/* Tid og pause på samme linje */}
                <div className="flex items-end gap-4 flex-wrap">
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">Fra</Label>
                    <Input
                      type="time"
                      value={data.startTime}
                      onChange={(e) => onDataChange(dateStr, 'startTime', e.target.value)}
                      className="h-9 w-[110px] text-center text-sm"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">Til</Label>
                    <Input
                      type="time"
                      value={data.endTime}
                      onChange={(e) => onDataChange(dateStr, 'endTime', e.target.value)}
                      className="h-9 w-[110px] text-center text-sm"
                    />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground flex items-center gap-1">
                      <Coffee className="h-3 w-3" />
                      Pause
                    </Label>
                    <div className="flex items-center gap-1">
                      <Input
                        type="number"
                        value={data.breakMinutes}
                        onChange={(e) => onDataChange(dateStr, 'breakMinutes', parseInt(e.target.value) || 0)}
                        className="w-20 h-9 text-center text-sm"
                        min={0}
                        step={5}
                        inputMode="numeric"
                      />
                      <span className="text-xs text-muted-foreground">min</span>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground flex items-center gap-1">
                      <Users className="h-3 w-3" />
                      Kundetimer
                    </Label>
                    <div className="flex items-center gap-1">
                      <Input
                        type="number"
                        value={data.hoursWithClient || 0}
                        onChange={(e) => onDataChange(dateStr, 'hoursWithClient', parseFloat(e.target.value) || 0)}
                        className="w-20 h-9 text-center text-sm"
                        min={0}
                        step={0.5}
                        inputMode="decimal"
                      />
                      <span className="text-xs text-muted-foreground">timer</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Navigation - sticky on mobile */}
      <div className={cn(
        isMobile && "sticky bottom-0 -mx-4 px-4 py-3 bg-background border-t",
        "flex justify-between gap-3"
      )}>
        <Button 
          variant="outline" 
          size="lg" 
          onClick={onPrevious} 
          className={cn("gap-2", isMobile && "flex-1")}
        >
          <ChevronLeft className="h-4 w-4" />
          Tilbake
        </Button>
        <Button 
          size="lg" 
          onClick={onNext} 
          className={cn("gap-2", isMobile ? "flex-1" : "min-w-[140px]")}
        >
          Neste
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
