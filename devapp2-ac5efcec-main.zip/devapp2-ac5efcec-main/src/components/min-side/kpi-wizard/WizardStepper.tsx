import { cn } from "@/lib/utils";
import { Check, Calendar, Clock, Wallet, Users } from "lucide-react";
import { WIZARD_STEPS } from "./types";
import { useIsMobile } from "@/hooks/use-mobile";

interface WizardStepperProps {
  currentStep: number;
  onStepClick?: (step: number) => void;
}

const stepIcons = {
  calendar: Calendar,
  clock: Clock,
  wallet: Wallet,
  users: Users,
};

export function WizardStepper({ currentStep, onStepClick }: WizardStepperProps) {
  const isMobile = useIsMobile();

  return (
    <div className="relative">
      {/* Progress line */}
      <div className={cn(
        "absolute h-0.5 bg-muted",
        isMobile ? "top-4 left-4 right-4" : "top-5 left-0 right-0 mx-8"
      )}>
        <div 
          className="h-full bg-primary transition-all duration-500 ease-out"
          style={{ width: `${(currentStep / (WIZARD_STEPS.length - 1)) * 100}%` }}
        />
      </div>

      {/* Steps */}
      <div className="relative flex justify-between">
        {WIZARD_STEPS.map((step, index) => {
          const Icon = stepIcons[step.icon as keyof typeof stepIcons];
          const isCompleted = index < currentStep;
          const isCurrent = index === currentStep;
          const isClickable = index <= currentStep;

          return (
            <button
              key={step.id}
              onClick={() => isClickable && onStepClick?.(index)}
              disabled={!isClickable}
              className={cn(
                "flex flex-col items-center gap-1.5 sm:gap-2 transition-all",
                isClickable && "cursor-pointer active:scale-95",
                !isClickable && "cursor-not-allowed opacity-50"
              )}
            >
              <div
                className={cn(
                  "rounded-full flex items-center justify-center transition-all duration-300",
                  isMobile ? "w-8 h-8" : "w-10 h-10",
                  isCompleted && "bg-primary text-primary-foreground shadow-lg shadow-primary/25",
                  isCurrent && "bg-primary text-primary-foreground ring-4 ring-primary/20 scale-110",
                  !isCompleted && !isCurrent && "bg-muted text-muted-foreground"
                )}
              >
                {isCompleted ? (
                  <Check className={cn(isMobile ? "h-4 w-4" : "h-5 w-5", "animate-in zoom-in-50 duration-200")} />
                ) : (
                  <Icon className={isMobile ? "h-4 w-4" : "h-5 w-5"} />
                )}
              </div>
              <span
                className={cn(
                  "font-medium transition-colors text-center",
                  isMobile ? "text-[10px] leading-tight max-w-[60px]" : "text-xs",
                  isCurrent && "text-primary",
                  !isCurrent && "text-muted-foreground"
                )}
              >
                {isMobile ? step.shortLabel || step.label : step.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
