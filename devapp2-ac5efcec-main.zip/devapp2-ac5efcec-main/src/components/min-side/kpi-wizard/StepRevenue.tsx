import { format } from "date-fns";
import { nb } from "date-fns/locale";
import { Wallet, Scissors, ShoppingBag, ChevronLeft, ChevronRight, TrendingUp, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { DailyData } from "./types";
import { useIsMobile } from "@/hooks/use-mobile";

interface StepRevenueProps {
  selectedDates: string[];
  dailyData: Record<string, DailyData>;
  onDataChange: (dateStr: string, field: keyof DailyData, value: any) => void;
  onPrevious: () => void;
  onNext: () => void;
}

export function StepRevenue({
  selectedDates,
  dailyData,
  onDataChange,
  onPrevious,
  onNext,
}: StepRevenueProps) {
  const isMobile = useIsMobile();

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('nb-NO', { style: 'currency', currency: 'NOK', maximumFractionDigits: 0 }).format(value);
  };

  const getTotalRevenue = () => {
    return selectedDates.reduce((total, dateStr) => {
      const data = dailyData[dateStr];
      if (!data) return total;
      // addonRevenue er en del av treatmentRevenue, ikke separat
      return total + (data.treatmentRevenue || 0) + (data.retailRevenue || 0);
    }, 0);
  };

  const getTotalTreatment = () => {
    return selectedDates.reduce((total, dateStr) => {
      const data = dailyData[dateStr];
      return total + (data?.treatmentRevenue || 0);
    }, 0);
  };

  const getTotalRetail = () => {
    return selectedDates.reduce((total, dateStr) => {
      const data = dailyData[dateStr];
      return total + (data?.retailRevenue || 0);
    }, 0);
  };

  const getTotalAddon = () => {
    return selectedDates.reduce((total, dateStr) => {
      const data = dailyData[dateStr];
      return total + (data?.addonRevenue || 0);
    }, 0);
  };

  const retailPercentage = getTotalRevenue() > 0 
    ? (getTotalRetail() / getTotalRevenue() * 100).toFixed(0) 
    : '0';

  const addonPercentage = getTotalRevenue() > 0 
    ? (getTotalAddon() / getTotalRevenue() * 100).toFixed(0) 
    : '0';

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Header */}
      <div className="text-center">
        <div className="inline-flex items-center gap-2 text-primary mb-2">
          <Wallet className="h-5 w-5" />
          <h3 className="font-semibold">Omsetning</h3>
        </div>
        <p className="text-sm text-muted-foreground">
          Omsetning inkl. mva for {selectedDates.length === 1 ? 'denne dagen' : 'valgte dager'}
        </p>
      </div>

      {/* Total summary */}
      <div className="bg-gradient-to-r from-green-500/10 to-emerald-500/5 rounded-lg p-4">
        <div className="grid grid-cols-4 gap-2 sm:gap-4 text-center">
          <div>
            <p className="text-xs text-muted-foreground mb-1">Behandling</p>
            <p className={cn("font-bold text-foreground", isMobile ? "text-xs" : "text-base")}>
              {formatCurrency(getTotalTreatment())}
            </p>
          </div>
          <div className="border-x border-border/50">
            <p className="text-xs text-muted-foreground mb-1">Total</p>
            <p className={cn("font-bold text-green-600 dark:text-green-400", isMobile ? "text-base" : "text-xl")}>
              {formatCurrency(getTotalRevenue())}
            </p>
          </div>
          <div>
            <p className="text-xs text-muted-foreground mb-1">Produktsalg</p>
            <p className={cn("font-bold text-foreground", isMobile ? "text-xs" : "text-base")}>
              {formatCurrency(getTotalRetail())}
            </p>
            <Badge variant="outline" className="text-xs mt-1">
              {retailPercentage}%
            </Badge>
          </div>
          <div>
            <p className="text-xs text-muted-foreground mb-1">Tilleggsandel</p>
            <p className={cn("font-bold text-purple-600 dark:text-purple-400", isMobile ? "text-base" : "text-xl")}>
              {formatCurrency(getTotalAddon())}
            </p>
            <Badge variant="outline" className="text-xs mt-1">
              {addonPercentage}%
            </Badge>
          </div>
        </div>
      </div>

      {/* Revenue inputs per day */}
      <div className="space-y-3">
        {selectedDates.sort().map((dateStr, index) => {
          const data = dailyData[dateStr];
          if (!data) return null;

          const dayTotal = (data.treatmentRevenue || 0) + (data.retailRevenue || 0);

          return (
            <Card 
              key={dateStr}
              className={cn(
                "transition-all duration-200 hover:shadow-md",
                "animate-in fade-in-50 slide-in-from-bottom-3",
              )}
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <CardContent className="p-4">
                <div className="flex flex-col gap-4">
                  {/* Date header */}
                  <div className="flex items-center justify-between">
                    <span className="font-medium capitalize">
                      {format(new Date(dateStr), isMobile ? 'EEE d. MMM' : 'EEEE d. MMM', { locale: nb })}
                    </span>
                    {dayTotal > 0 && (
                      <Badge className="bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400 gap-1">
                        <TrendingUp className="h-3 w-3" />
                        {formatCurrency(dayTotal)}
                      </Badge>
                    )}
                  </div>

                  {/* Input fields - Row 1: Behandling + Tillegg */}
                  <div className="grid grid-cols-2 gap-3 sm:gap-4">
                    <div className="space-y-2">
                      <Label htmlFor={`treatment-${dateStr}`} className="flex items-center gap-2 text-sm">
                        <Scissors className="h-4 w-4 text-primary" />
                        Sum Total Behandlinger
                      </Label>
                      <div className="relative">
                        <Input
                          id={`treatment-${dateStr}`}
                          type="number"
                          inputMode="decimal"
                          value={data.treatmentRevenue || ''}
                          onChange={(e) => onDataChange(dateStr, 'treatmentRevenue', parseFloat(e.target.value) || 0)}
                          placeholder="0"
                          className={cn(
                            "pr-10 font-medium",
                            isMobile ? "h-14 text-xl" : "text-lg"
                          )}
                        />
                        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">kr</span>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor={`addon-${dateStr}`} className="flex items-center gap-2 text-sm">
                        <Sparkles className="h-4 w-4 text-purple-500" />
                        Sum kur og tilleggsbehandlinger
                      </Label>
                      <div className="relative">
                        <Input
                          id={`addon-${dateStr}`}
                          type="number"
                          inputMode="decimal"
                          value={data.addonRevenue || ''}
                          onChange={(e) => onDataChange(dateStr, 'addonRevenue', parseFloat(e.target.value) || 0)}
                          placeholder="0"
                          className={cn(
                            "pr-10 font-medium",
                            isMobile ? "h-14 text-xl" : "text-lg"
                          )}
                        />
                        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">kr</span>
                      </div>
                    </div>
                  </div>

                  {/* Row 2: Produktsalg (full width) */}
                  <div className="space-y-2">
                    <Label htmlFor={`retail-${dateStr}`} className="flex items-center gap-2 text-sm">
                      <ShoppingBag className="h-4 w-4 text-amber-500" />
                      Sum Totalt Produktsalg
                    </Label>
                    <div className="relative">
                      <Input
                        id={`retail-${dateStr}`}
                        type="number"
                        inputMode="decimal"
                        value={data.retailRevenue || ''}
                        onChange={(e) => onDataChange(dateStr, 'retailRevenue', parseFloat(e.target.value) || 0)}
                        placeholder="0"
                        className={cn(
                          "pr-10 font-medium",
                          isMobile ? "h-14 text-xl" : "text-lg"
                        )}
                      />
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">kr</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Navigation - sticky on mobile */}
      <div className={cn(
        isMobile && "sticky bottom-0 -mx-4 px-4 py-3 bg-background border-t",
        "flex justify-between gap-3"
      )}>
        <Button 
          variant="outline" 
          size="lg" 
          onClick={onPrevious} 
          className={cn("gap-2", isMobile && "flex-1")}
        >
          <ChevronLeft className="h-4 w-4" />
          Tilbake
        </Button>
        <Button 
          size="lg" 
          onClick={onNext} 
          className={cn("gap-2", isMobile ? "flex-1" : "min-w-[140px]")}
        >
          Neste
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
