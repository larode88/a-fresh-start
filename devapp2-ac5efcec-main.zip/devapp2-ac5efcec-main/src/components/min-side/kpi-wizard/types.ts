export interface DailyData {
  date: string;
  startTime: string;
  endTime: string;
  breakMinutes: number;
  hoursWithClient: number;
  treatmentRevenue: number;
  retailRevenue: number;
  addonRevenue: number;
  visitCount: number;
  visitsWithAddon: number;
  addonCount: number;
  rebookedVisits: number;
  isComplete: boolean;
}

export interface ShiftInfo {
  date: string;
  startTime: string;
  endTime: string;
  breakMinutes: number;
  isFromTemplate: boolean;
}

export interface WizardState {
  mode: 'day' | 'week';
  selectedDates: string[];
  dailyData: Record<string, DailyData>;
  currentStep: number;
}

export const WIZARD_STEPS = [
  { id: 'period', label: 'Velg periode', shortLabel: 'Periode', icon: 'calendar' },
  { id: 'time', label: 'Timeregistrering', shortLabel: 'Timer', icon: 'clock' },
  { id: 'revenue', label: 'Omsetning', shortLabel: 'Salg', icon: 'wallet' },
  { id: 'visits', label: 'Besøk & Rebooking', shortLabel: 'Besøk', icon: 'users' },
] as const;

export type WizardStep = typeof WIZARD_STEPS[number]['id'];

export const getDefaultDailyData = (date: string, shift?: ShiftInfo): DailyData => ({
  date,
  startTime: shift?.startTime || '09:00',
  endTime: shift?.endTime || '17:00',
  breakMinutes: shift?.breakMinutes || 30,
  hoursWithClient: 0,
  treatmentRevenue: 0,
  retailRevenue: 0,
  addonRevenue: 0,
  visitCount: 0,
  visitsWithAddon: 0,
  addonCount: 0,
  rebookedVisits: 0,
  isComplete: false,
});
