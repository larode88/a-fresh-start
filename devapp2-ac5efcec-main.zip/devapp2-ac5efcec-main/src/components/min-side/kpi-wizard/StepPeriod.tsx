import { useState } from "react";
import { format, startOfWeek, endOfWeek, eachDayOfInterval, isWeekend } from "date-fns";
import { nb } from "date-fns/locale";
import { Calendar as CalendarIcon, CalendarDays, ChevronLeft, ChevronRight, Trash2, FileText, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Badge } from "@/components/ui/badge";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { cn } from "@/lib/utils";
import { DailyData, getDefaultDailyData, ShiftInfo } from "./types";
import { useIsMobile } from "@/hooks/use-mobile";

interface StepPeriodProps {
  mode: 'day' | 'week';
  selectedDates: string[];
  dailyData: Record<string, DailyData>;
  existingDates: string[];
  shiftInfoMap: Record<string, ShiftInfo>;
  viewDate: Date;
  onViewDateChange: (date: Date) => void;
  onModeChange: (mode: 'day' | 'week') => void;
  onDatesChange: (dates: string[], dailyData: Record<string, DailyData>) => void;
  onDeleteDate?: (dateStr: string) => void;
  isDeleting?: boolean;
  onNext: () => void;
}

export function StepPeriod({
  mode,
  selectedDates,
  dailyData,
  existingDates,
  shiftInfoMap,
  viewDate,
  onViewDateChange,
  onModeChange,
  onDatesChange,
  onDeleteDate,
  isDeleting,
  onNext,
}: StepPeriodProps) {
  const isMobile = useIsMobile();
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);

  const handleWeekSelect = () => {
    const weekStart = startOfWeek(viewDate, { weekStartsOn: 1 });
    const weekEnd = endOfWeek(viewDate, { weekStartsOn: 1 });
    
    // Only select days with actual shifts
    const weekDays = eachDayOfInterval({ start: weekStart, end: weekEnd })
      .filter(d => shiftInfoMap[format(d, 'yyyy-MM-dd')])
      .map(d => format(d, 'yyyy-MM-dd'));
    
    if (weekDays.length === 0) {
      // Fallback: select weekdays if no shifts found
      const fallbackDays = eachDayOfInterval({ start: weekStart, end: weekEnd })
        .filter(d => !isWeekend(d))
        .map(d => format(d, 'yyyy-MM-dd'));
      
      const newDailyData: Record<string, DailyData> = {};
      fallbackDays.forEach(dateStr => {
        newDailyData[dateStr] = dailyData[dateStr] || getDefaultDailyData(dateStr);
      });
      onDatesChange(fallbackDays, newDailyData);
      return;
    }
    
    const newDailyData: Record<string, DailyData> = {};
    weekDays.forEach(dateStr => {
      const shift = shiftInfoMap[dateStr];
      newDailyData[dateStr] = dailyData[dateStr] || getDefaultDailyData(dateStr, shift);
    });
    
    onDatesChange(weekDays, newDailyData);
  };

  const isDateSelected = (date: Date) => {
    return selectedDates.includes(format(date, 'yyyy-MM-dd'));
  };

  const hasExistingData = (date: Date) => {
    return existingDates.includes(format(date, 'yyyy-MM-dd'));
  };

  const hasShift = (date: Date) => {
    return !!shiftInfoMap[format(date, 'yyyy-MM-dd')];
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Mode Toggle - compact on mobile */}
      <div className="flex justify-center gap-2">
        <Button
          variant={mode === 'day' ? 'default' : 'outline'}
          size={isMobile ? 'default' : 'lg'}
          onClick={() => onModeChange('day')}
          className={cn(
            "gap-2 transition-all duration-200 flex-1 sm:flex-none",
            mode === 'day' && "shadow-lg shadow-primary/25"
          )}
        >
          <CalendarDays className="h-4 w-4 sm:h-5 sm:w-5" />
          <span className="sm:inline">Enkeltdag</span>
        </Button>
        <Button
          variant={mode === 'week' ? 'default' : 'outline'}
          size={isMobile ? 'default' : 'lg'}
          onClick={() => onModeChange('week')}
          className={cn(
            "gap-2 transition-all duration-200 flex-1 sm:flex-none",
            mode === 'week' && "shadow-lg shadow-primary/25"
          )}
        >
          <CalendarIcon className="h-4 w-4 sm:h-5 sm:w-5" />
          <span className="sm:inline">Hel uke</span>
        </Button>
      </div>

      {/* Quick week selection for week mode - above calendar on mobile */}
      {mode === 'week' && (
        <div className="flex justify-center">
          <Button
            variant="secondary"
            size="sm"
            onClick={handleWeekSelect}
            className="gap-2 w-full sm:w-auto"
          >
            <CalendarIcon className="h-4 w-4" />
            Velg alle dager denne uken
          </Button>
        </div>
      )}

      {/* Legend - compact */}
      <div className="flex justify-center gap-4 text-xs text-muted-foreground">
        <div className="flex items-center gap-1.5">
          <div className="w-2.5 h-2.5 rounded-full bg-blue-500" />
          <span>Vakt</span>
        </div>
        {existingDates.length > 0 && (
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-green-500" />
            <span>Har data</span>
          </div>
        )}
      </div>

      {/* Calendar - larger touch targets on mobile */}
      <div className="flex justify-center">
        <Calendar
          mode="multiple"
          selected={selectedDates.map(d => new Date(d))}
          onSelect={(dates) => {
            if (!dates || dates.length === 0) {
              onDatesChange([], {});
              return;
            }
            
            const newDateStrs = dates.map(d => format(d, 'yyyy-MM-dd'));
            const addedDates = newDateStrs.filter(d => !selectedDates.includes(d));
            const removedDates = selectedDates.filter(d => !newDateStrs.includes(d));
            
            if (addedDates.length > 0) {
              const dateStr = addedDates[0];
              const shift = shiftInfoMap[dateStr];
              
              if (mode === 'day') {
                const newDailyData = { [dateStr]: dailyData[dateStr] || getDefaultDailyData(dateStr, shift) };
                onDatesChange([dateStr], newDailyData);
              } else {
                // Week mode: Velg hele uken basert på klikket dato
                const clickedDate = new Date(dateStr);
                const weekStart = startOfWeek(clickedDate, { weekStartsOn: 1 });
                const weekEnd = endOfWeek(clickedDate, { weekStartsOn: 1 });
                
                // Finn alle dager i uken med registrert vakt
                const weekDays = eachDayOfInterval({ start: weekStart, end: weekEnd })
                  .filter(d => shiftInfoMap[format(d, 'yyyy-MM-dd')])
                  .map(d => format(d, 'yyyy-MM-dd'));
                
                // Fallback til ukedager hvis ingen vakter funnet
                const daysToSelect = weekDays.length > 0 
                  ? weekDays 
                  : eachDayOfInterval({ start: weekStart, end: weekEnd })
                      .filter(d => !isWeekend(d))
                      .map(d => format(d, 'yyyy-MM-dd'));
                
                // Opprett dailyData for alle valgte dager
                const newDailyData: Record<string, DailyData> = {};
                daysToSelect.forEach(d => {
                  const dayShift = shiftInfoMap[d];
                  newDailyData[d] = dailyData[d] || getDefaultDailyData(d, dayShift);
                });
                
                // Erstatt alle valgte datoer med den nye ukens dager
                onDatesChange(daysToSelect, newDailyData);
                
                // Oppdater visningsdato til den valgte uken
                onViewDateChange(clickedDate);
              }
            } else if (removedDates.length > 0) {
              const dateStr = removedDates[0];
              const newDates = selectedDates.filter(d => d !== dateStr);
              const newDailyData = { ...dailyData };
              delete newDailyData[dateStr];
              onDatesChange(newDates, newDailyData);
            }
          }}
          month={viewDate}
          onMonthChange={onViewDateChange}
          locale={nb}
          className={cn(
            "rounded-lg border shadow-sm p-3 w-full max-w-[350px]",
            // Larger touch targets on mobile
            isMobile && "[&_.rdp-button]:h-11 [&_.rdp-button]:w-11 [&_.rdp-button]:text-base"
          )}
          modifiers={{
            selected: (date) => isDateSelected(date),
            hasData: (date) => hasExistingData(date),
            hasShift: (date) => hasShift(date) && !isDateSelected(date),
          }}
          modifiersStyles={{
            selected: { backgroundColor: 'hsl(var(--primary))', color: 'hsl(var(--primary-foreground))' },
          }}
          modifiersClassNames={{
            hasData: 'relative after:absolute after:bottom-1 after:left-1/2 after:-translate-x-1/2 after:w-1.5 after:h-1.5 after:bg-green-500 after:rounded-full',
            hasShift: 'relative before:absolute before:inset-1 before:border-2 before:border-blue-500 before:rounded-md',
          }}
          components={{
            Caption: ({ displayMonth }) => (
              <div className="flex items-center justify-between py-2">
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-9 w-9"
                  onClick={() => onViewDateChange(new Date(viewDate.getFullYear(), viewDate.getMonth() - 1))}
                >
                  <ChevronLeft className="h-5 w-5" />
                </Button>
                <h2 className="font-semibold capitalize text-base">
                  {format(displayMonth, 'MMMM yyyy', { locale: nb })}
                </h2>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-9 w-9"
                  onClick={() => onViewDateChange(new Date(viewDate.getFullYear(), viewDate.getMonth() + 1))}
                >
                  <ChevronRight className="h-5 w-5" />
                </Button>
              </div>
            ),
          }}
        />
      </div>

      {/* Selected summary */}
      {selectedDates.length > 0 && (
        <div className="bg-primary/5 rounded-lg p-3 sm:p-4 text-center">
          <p className="text-sm font-medium">
            {selectedDates.length === 1 
              ? format(new Date(selectedDates[0]), 'EEEE d. MMMM', { locale: nb })
              : `${selectedDates.length} dager valgt`}
          </p>
          {selectedDates.length > 1 && (
            <p className="text-xs text-muted-foreground mt-1">
              {selectedDates.map(d => format(new Date(d), 'EEE', { locale: nb })).join(', ')}
            </p>
          )}
        </div>
      )}

      {/* Existing registrations with delete option */}
      {existingDates.length > 0 && onDeleteDate && (
        <div className="space-y-2">
          <h4 className="text-sm font-medium flex items-center gap-2 text-muted-foreground">
            <FileText className="h-4 w-4" />
            Registrerte dager
          </h4>
          <div className="grid gap-2">
            {existingDates.map(dateStr => (
              <div 
                key={dateStr} 
                className="flex items-center justify-between p-2.5 bg-muted/50 rounded-lg"
              >
                <Badge variant="outline" className="bg-green-500/10 text-green-700 border-green-500/30">
                  {format(new Date(dateStr), 'EEEE d/M', { locale: nb })}
                </Badge>
                <AlertDialog open={deleteTarget === dateStr} onOpenChange={(open) => !open && setDeleteTarget(null)}>
                  <AlertDialogTrigger asChild>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="text-destructive hover:bg-destructive/10 h-8 w-8 p-0"
                      onClick={() => setDeleteTarget(dateStr)}
                      disabled={isDeleting}
                    >
                      {isDeleting && deleteTarget === dateStr ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Trash2 className="h-4 w-4" />
                      )}
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Slett registrering?</AlertDialogTitle>
                      <AlertDialogDescription>
                        Dette vil permanent slette KPI-data for {format(new Date(dateStr), 'EEEE d. MMMM', { locale: nb })}.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Avbryt</AlertDialogCancel>
                      <AlertDialogAction 
                        onClick={() => {
                          onDeleteDate(dateStr);
                          setDeleteTarget(null);
                        }} 
                        className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                      >
                        Slett
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Next button - sticky on mobile */}
      <div className={cn(
        isMobile && "sticky bottom-0 -mx-4 px-4 py-3 bg-background border-t",
        "flex justify-end"
      )}>
        <Button
          size="lg"
          onClick={onNext}
          disabled={selectedDates.length === 0}
          className={cn("gap-2", isMobile ? "w-full" : "min-w-[140px]")}
        >
          Neste
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
