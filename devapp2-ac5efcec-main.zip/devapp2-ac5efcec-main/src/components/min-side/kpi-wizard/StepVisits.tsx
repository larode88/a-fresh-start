import { format } from "date-fns";
import { nb } from "date-fns/locale";
import { Users, CalendarCheck, Sparkles, ChevronLeft, Save, Loader2, Minus, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
import { DailyData } from "./types";
import { useIsMobile } from "@/hooks/use-mobile";

interface StepVisitsProps {
  selectedDates: string[];
  dailyData: Record<string, DailyData>;
  onDataChange: (dateStr: string, field: keyof DailyData, value: any) => void;
  onPrevious: () => void;
  onSave: () => void;
  isSaving: boolean;
}

// Stepper input component for mobile
function StepperInput({ 
  value, 
  onChange, 
  min = 0,
  label,
  icon: Icon
}: { 
  value: number; 
  onChange: (value: number) => void;
  min?: number;
  label: string;
  icon: React.ElementType;
}) {
  return (
    <div className="space-y-2">
      <Label className="text-xs flex items-center gap-1 text-muted-foreground">
        <Icon className="h-3 w-3" />
        {label}
      </Label>
      <div className="flex items-center justify-center gap-1">
        <Button 
          variant="outline" 
          size="icon"
          className="h-10 w-10 shrink-0"
          onClick={() => onChange(Math.max(min, value - 1))}
          disabled={value <= min}
        >
          <Minus className="h-4 w-4" />
        </Button>
        <span className="text-2xl font-bold w-12 text-center">{value}</span>
        <Button 
          variant="outline" 
          size="icon"
          className="h-10 w-10 shrink-0"
          onClick={() => onChange(value + 1)}
        >
          <Plus className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}

export function StepVisits({
  selectedDates,
  dailyData,
  onDataChange,
  onPrevious,
  onSave,
  isSaving,
}: StepVisitsProps) {
  const isMobile = useIsMobile();

  const getTotals = () => {
    return selectedDates.reduce((acc, dateStr) => {
      const data = dailyData[dateStr];
      if (!data) return acc;
      return {
        visits: acc.visits + (data.visitCount || 0),
        rebooked: acc.rebooked + (data.rebookedVisits || 0),
        withAddon: acc.withAddon + (data.visitsWithAddon || 0),
        addons: acc.addons + (data.addonCount || 0),
      };
    }, { visits: 0, rebooked: 0, withAddon: 0, addons: 0 });
  };

  const totals = getTotals();
  const rebookingPercent = totals.visits > 0 ? (totals.rebooked / totals.visits * 100) : 0;
  const addonPercent = totals.visits > 0 ? (totals.withAddon / totals.visits * 100) : 0;
  // Gjennomsnittlig antall tilleggsbehandlinger per besøk totalt
  const addonPerVisit = totals.visits > 0 ? (totals.addons / totals.visits) : 0;

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* Header */}
      <div className="text-center">
        <div className="inline-flex items-center gap-2 text-primary mb-2">
          <Users className="h-5 w-5" />
          <h3 className="font-semibold">Besøk & Rebooking</h3>
        </div>
        <p className="text-sm text-muted-foreground">
          Siste steg! Legg inn besøksdata
        </p>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 gap-2 sm:gap-3">
        <div className="bg-primary/5 rounded-lg p-3 sm:p-4 text-center">
          <p className="text-xs text-muted-foreground mb-1">Antall besøk</p>
          <p className="text-2xl sm:text-3xl font-bold text-primary">{totals.visits}</p>
        </div>
        <div className="bg-green-500/5 rounded-lg p-3 sm:p-4 text-center">
          <p className="text-xs text-muted-foreground mb-1">Antall rebooket</p>
          <p className="text-xl sm:text-2xl font-bold text-green-600 dark:text-green-400">
            {rebookingPercent.toFixed(0)}%
          </p>
          <Progress value={rebookingPercent} className="h-1.5 mt-2" />
        </div>
        <div className="bg-purple-500/5 rounded-lg p-3 sm:p-4 text-center">
          <p className="text-xs text-muted-foreground mb-1">Antall tilleggsbehandlinger</p>
          <p className="text-xl sm:text-2xl font-bold text-purple-600 dark:text-purple-400">
            {addonPerVisit.toFixed(1)}
          </p>
          <p className="text-xs text-muted-foreground mt-1">per besøk</p>
        </div>
        <div className="bg-amber-500/5 rounded-lg p-3 sm:p-4 text-center">
          <p className="text-xs text-muted-foreground mb-1">Besøk m/tilleggsbehandling</p>
          <p className="text-xl sm:text-2xl font-bold text-amber-600 dark:text-amber-400">
            {addonPercent.toFixed(0)}%
          </p>
          <Progress value={addonPercent} className="h-1.5 mt-2" />
        </div>
      </div>

      {/* Visit inputs per day */}
      <div className="space-y-3">
        {selectedDates.sort().map((dateStr, index) => {
          const data = dailyData[dateStr];
          if (!data) return null;

          return (
            <Card 
              key={dateStr}
              className={cn(
                "transition-all duration-200 hover:shadow-md",
                "animate-in fade-in-50 slide-in-from-bottom-3",
              )}
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <CardContent className="p-4">
                <div className="flex flex-col gap-4">
                  {/* Date header */}
                  <span className="font-medium capitalize text-center sm:text-left">
                    {format(new Date(dateStr), isMobile ? 'EEE d. MMM' : 'EEEE d. MMM', { locale: nb })}
                  </span>

                  {/* Input grid - stepper on mobile, input on desktop */}
                  {isMobile ? (
                    <div className="space-y-4">
                      {/* Rad 1: Besøk & Rebooking */}
                      <div className="grid grid-cols-2 gap-4">
                        <StepperInput
                          value={data.visitCount || 0}
                          onChange={(val) => onDataChange(dateStr, 'visitCount', val)}
                          label="Besøk"
                          icon={Users}
                        />
                        <StepperInput
                          value={data.rebookedVisits || 0}
                          onChange={(val) => onDataChange(dateStr, 'rebookedVisits', val)}
                          label="Rebooket"
                          icon={CalendarCheck}
                        />
                      </div>
                      {/* Rad 2: Tilleggsbehandlinger */}
                      <div className="grid grid-cols-2 gap-4 pt-2 border-t">
                        <StepperInput
                          value={data.visitsWithAddon || 0}
                          onChange={(val) => onDataChange(dateStr, 'visitsWithAddon', val)}
                          label="M/tillegg"
                          icon={Sparkles}
                        />
                        <StepperInput
                          value={data.addonCount || 0}
                          onChange={(val) => onDataChange(dateStr, 'addonCount', val)}
                          label="Ant. tillegg"
                          icon={Sparkles}
                        />
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {/* Rad 1: Besøk & Rebooking */}
                      <div className="grid grid-cols-2 gap-3">
                        <div className="space-y-1">
                          <Label htmlFor={`visits-${dateStr}`} className="text-xs flex items-center gap-1">
                            <Users className="h-3 w-3" />
                            Antall Besøk
                          </Label>
                          <Input
                            id={`visits-${dateStr}`}
                            type="number"
                            value={data.visitCount || ''}
                            onChange={(e) => onDataChange(dateStr, 'visitCount', parseInt(e.target.value) || 0)}
                            placeholder="0"
                            className="h-10 text-center font-medium"
                            min={0}
                          />
                        </div>

                        <div className="space-y-1">
                          <Label htmlFor={`rebooked-${dateStr}`} className="text-xs flex items-center gap-1">
                            <CalendarCheck className="h-3 w-3" />
                            Antall Rebooket
                          </Label>
                          <Input
                            id={`rebooked-${dateStr}`}
                            type="number"
                            value={data.rebookedVisits || ''}
                            onChange={(e) => onDataChange(dateStr, 'rebookedVisits', parseInt(e.target.value) || 0)}
                            placeholder="0"
                            className="h-10 text-center font-medium"
                            min={0}
                          />
                        </div>
                      </div>

                      {/* Rad 2: Tilleggsbehandlinger */}
                      <div className="grid grid-cols-2 gap-3 pt-2 border-t">
                        <div className="space-y-1">
                          <Label htmlFor={`addon-visits-${dateStr}`} className="text-xs flex items-center gap-1">
                            <Sparkles className="h-3 w-3" />
                            Antall Besøk med tilleggsbehandling
                          </Label>
                          <Input
                            id={`addon-visits-${dateStr}`}
                            type="number"
                            value={data.visitsWithAddon || ''}
                            onChange={(e) => onDataChange(dateStr, 'visitsWithAddon', parseInt(e.target.value) || 0)}
                            placeholder="0"
                            className="h-10 text-center font-medium"
                            min={0}
                          />
                        </div>

                        <div className="space-y-1">
                          <Label htmlFor={`addons-${dateStr}`} className="text-xs flex items-center gap-1">
                            <Sparkles className="h-3 w-3" />
                            Antall tilleggsbehandlinger
                          </Label>
                          <Input
                            id={`addons-${dateStr}`}
                            type="number"
                            value={data.addonCount || ''}
                            onChange={(e) => onDataChange(dateStr, 'addonCount', parseInt(e.target.value) || 0)}
                            placeholder="0"
                            className="h-10 text-center font-medium"
                            min={0}
                          />
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Navigation - sticky on mobile */}
      <div className={cn(
        isMobile && "sticky bottom-0 -mx-4 px-4 py-3 bg-background border-t",
        "flex justify-between gap-3"
      )}>
        <Button 
          variant="outline" 
          size="lg" 
          onClick={onPrevious} 
          className={cn("gap-2", isMobile && "flex-1")}
        >
          <ChevronLeft className="h-4 w-4" />
          Tilbake
        </Button>
        <Button 
          size="lg" 
          onClick={onSave} 
          disabled={isSaving}
          className={cn(
            "gap-2 bg-green-600 hover:bg-green-700",
            isMobile ? "flex-1" : "min-w-[160px]"
          )}
        >
          {isSaving ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              Lagrer...
            </>
          ) : (
            <>
              <Save className="h-4 w-4" />
              Lagre data
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
