import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { format, startOfWeek, endOfWeek, differenceInMinutes, parse, startOfMonth, endOfMonth } from "date-fns";
import { nb } from "date-fns/locale";
import { useToast } from "@/hooks/use-toast";
import { useIsMobile } from "@/hooks/use-mobile";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { WizardStepper } from "./WizardStepper";
import { StepPeriod } from "./StepPeriod";
import { StepTime } from "./StepTime";
import { StepRevenue } from "./StepRevenue";
import { StepVisits } from "./StepVisits";
import { DailyData, getDefaultDailyData, WIZARD_STEPS, ShiftInfo } from "./types";
import { getISOWeekNumber } from "@/lib/dateUtils";
import { cn } from "@/lib/utils";

interface KPIRegistreringWizardProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  ansatt: {
    id: string;
    user_id: string | null;
    salong_id: string | null;
    fornavn: string;
    etternavn?: string | null;
  };
  initialDate?: Date;
}

export function KPIRegistreringWizard({
  open,
  onOpenChange,
  ansatt,
  initialDate = new Date(),
}: KPIRegistreringWizardProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const isMobile = useIsMobile();
  const contentRef = useRef<HTMLDivElement>(null);

  const [currentStep, setCurrentStep] = useState(0);
  const [direction, setDirection] = useState<'forward' | 'backward'>('forward');
  const [mode, setMode] = useState<'day' | 'week'>('week');
  const [selectedDates, setSelectedDates] = useState<string[]>([]);
  const [dailyData, setDailyData] = useState<Record<string, DailyData>>({});
  const [viewDate, setViewDate] = useState(initialDate);

  // Swipe handling for step navigation
  const touchStartX = useRef<number>(0);
  const touchStartY = useRef<number>(0);

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
    touchStartY.current = e.touches[0].clientY;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    const touchEndX = e.changedTouches[0].clientX;
    const touchEndY = e.changedTouches[0].clientY;
    const diffX = touchEndX - touchStartX.current;
    const diffY = touchEndY - touchStartY.current;

    // Only trigger if horizontal swipe is dominant
    if (Math.abs(diffX) > Math.abs(diffY) && Math.abs(diffX) > 50) {
      if (diffX < 0 && currentStep < WIZARD_STEPS.length - 1) {
        // Swipe left = next step
        if (currentStep === 0 && selectedDates.length === 0) return;
        goToStep(currentStep + 1);
      } else if (diffX > 0 && currentStep > 0) {
        // Swipe right = previous step
        goToStep(currentStep - 1);
      }
    }
  };

  const goToStep = (step: number) => {
    setDirection(step > currentStep ? 'forward' : 'backward');
    setCurrentStep(step);
    // Scroll content to top on step change
    contentRef.current?.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Fetch existing data for the current week
  const weekStart = startOfWeek(initialDate, { weekStartsOn: 1 });
  const weekEnd = endOfWeek(initialDate, { weekStartsOn: 1 });

  // Fetch shifts for the viewed month
  const monthStart = startOfMonth(viewDate);
  const monthEnd = endOfMonth(viewDate);

  // Fetch only actual shifts from turnus_skift (not templates)
  const { data: shiftsData } = useQuery({
    queryKey: ['employee-shifts', ansatt.id, ansatt.salong_id, format(monthStart, 'yyyy-MM-dd')],
    queryFn: async () => {
      if (!ansatt.id || !ansatt.salong_id) return [];

      const { data } = await supabase
        .from('turnus_skift')
        .select('dato, start_tid, slutt_tid')
        .eq('ansatt_id', ansatt.id)
        .eq('salon_id', ansatt.salong_id)
        .gte('dato', format(monthStart, 'yyyy-MM-dd'))
        .lte('dato', format(monthEnd, 'yyyy-MM-dd'));

      return data || [];
    },
    enabled: open && !!ansatt.id && !!ansatt.salong_id,
  });

  // Build shift info map from actual shifts only
  const shiftInfoMap: Record<string, ShiftInfo> = {};
  
  const shiftsArray = Array.isArray(shiftsData) ? shiftsData : [];
  shiftsArray.forEach(s => {
    shiftInfoMap[s.dato] = {
      date: s.dato,
      startTime: s.start_tid?.slice(0, 5) || '09:00',
      endTime: s.slutt_tid?.slice(0, 5) || '17:00',
      breakMinutes: 30,
      isFromTemplate: false,
    };
  });

  const { data: existingData } = useQuery({
    queryKey: ['existing-daily-kpi', ansatt.id, ansatt.salong_id, format(weekStart, 'yyyy-MM-dd')],
    queryFn: async () => {
      if (!ansatt.id || !ansatt.salong_id) return { kpis: [], times: [] };

      const [kpiResult, timeResult] = await Promise.all([
        supabase
          .from('daily_kpi_inputs')
          .select('*')
          .eq('ansatt_id', ansatt.id)
          .eq('salon_id', ansatt.salong_id)
          .gte('date', format(weekStart, 'yyyy-MM-dd'))
          .lte('date', format(weekEnd, 'yyyy-MM-dd')),
        supabase
          .from('daily_time_entries')
          .select('*')
          .eq('ansatt_id', ansatt.id)
          .eq('salon_id', ansatt.salong_id)
          .gte('date', format(weekStart, 'yyyy-MM-dd'))
          .lte('date', format(weekEnd, 'yyyy-MM-dd')),
      ]);

      return {
        kpis: kpiResult.data || [],
        times: timeResult.data || [],
      };
    },
    enabled: open && !!ansatt.id && !!ansatt.salong_id,
  });

  // Get dates that have existing data
  const existingDates = existingData?.kpis.map(k => k.date) || [];

  // Load existing data when dialog opens
  useEffect(() => {
    if (open && existingData) {
      const loadedData: Record<string, DailyData> = {};
      
      existingData.kpis.forEach(kpi => {
        const timeEntry = existingData.times.find(t => t.date === kpi.date);
        loadedData[kpi.date] = {
          date: kpi.date,
          startTime: timeEntry?.start_time?.slice(0, 5) || '09:00',
          endTime: timeEntry?.end_time?.slice(0, 5) || '17:00',
          breakMinutes: timeEntry?.break_minutes || 30,
          hoursWithClient: (timeEntry as any)?.hours_with_client || 0,
          treatmentRevenue: kpi.treatment_revenue || 0,
          retailRevenue: kpi.retail_revenue || 0,
          addonRevenue: (kpi as any).addon_revenue || 0,
          visitCount: kpi.visit_count || 0,
          visitsWithAddon: kpi.visits_with_addon || 0,
          addonCount: kpi.addon_count || 0,
          rebookedVisits: kpi.rebooked_visits || 0,
          isComplete: !kpi.is_draft,
        };
      });

      if (Object.keys(loadedData).length > 0) {
        setDailyData(loadedData);
        setSelectedDates(Object.keys(loadedData));
      }
    }
  }, [open, existingData]);

  // Reset when dialog closes
  useEffect(() => {
    if (!open) {
      setCurrentStep(0);
      setDirection('forward');
      setMode('week');
      setSelectedDates([]);
      setDailyData({});
    }
  }, [open]);

  const handleDataChange = (dateStr: string, field: keyof DailyData, value: any) => {
    setDailyData(prev => ({
      ...prev,
      [dateStr]: {
        ...prev[dateStr],
        [field]: value,
      },
    }));
  };

  const handleDatesChange = (dates: string[], newDailyData: Record<string, DailyData>) => {
    setSelectedDates(dates);
    setDailyData(prev => ({ ...prev, ...newDailyData }));
  };

  // Calculate hours from time entries
  const calculateHours = (startTime: string, endTime: string, breakMinutes: number): number => {
    try {
      const start = parse(startTime, 'HH:mm', new Date());
      const end = parse(endTime, 'HH:mm', new Date());
      const minutes = differenceInMinutes(end, start) - breakMinutes;
      return Math.max(0, minutes / 60);
    } catch {
      return 0;
    }
  };

  // Save mutation
  const saveMutation = useMutation({
    mutationFn: async () => {
      if (!ansatt.id || !ansatt.salong_id) {
        throw new Error("Mangler ansatt-ID eller salong-ID");
      }

      // Save daily KPI inputs
      const kpiInserts = selectedDates.map(dateStr => {
        const data = dailyData[dateStr];
        return {
          ansatt_id: ansatt.id,
          salon_id: ansatt.salong_id!,
          date: dateStr,
          treatment_revenue: data?.treatmentRevenue || 0,
          retail_revenue: data?.retailRevenue || 0,
          addon_revenue: data?.addonRevenue || 0,
          visit_count: data?.visitCount || 0,
          visits_with_addon: data?.visitsWithAddon || 0,
          addon_count: data?.addonCount || 0,
          rebooked_visits: data?.rebookedVisits || 0,
          is_draft: false,
        };
      });

      // Save daily time entries
      const timeInserts = selectedDates.map(dateStr => {
        const data = dailyData[dateStr];
        return {
          ansatt_id: ansatt.id,
          salon_id: ansatt.salong_id!,
          date: dateStr,
          start_time: data?.startTime || '09:00',
          end_time: data?.endTime || '17:00',
          break_minutes: data?.breakMinutes || 30,
          hours_with_client: data?.hoursWithClient || 0,
        };
      });

      // Upsert KPIs
      const { error: kpiError } = await supabase
        .from('daily_kpi_inputs')
        .upsert(kpiInserts, { onConflict: 'ansatt_id,salon_id,date' });

      if (kpiError) throw kpiError;

      // Upsert time entries
      const { error: timeError } = await supabase
        .from('daily_time_entries')
        .upsert(timeInserts, { onConflict: 'ansatt_id,salon_id,date' });

      if (timeError) throw timeError;

      // Also aggregate to weekly_kpi_inputs for compatibility
      const weekNumber = getISOWeekNumber(new Date(selectedDates[0]));
      const year = new Date(selectedDates[0]).getFullYear();

      const totalTreatment = selectedDates.reduce((sum, d) => sum + (dailyData[d]?.treatmentRevenue || 0), 0);
      const totalRetail = selectedDates.reduce((sum, d) => sum + (dailyData[d]?.retailRevenue || 0), 0);
      const totalAddon = selectedDates.reduce((sum, d) => sum + (dailyData[d]?.addonRevenue || 0), 0);
      const totalVisits = selectedDates.reduce((sum, d) => sum + (dailyData[d]?.visitCount || 0), 0);
      const totalRebooked = selectedDates.reduce((sum, d) => sum + (dailyData[d]?.rebookedVisits || 0), 0);
      const totalWithAddon = selectedDates.reduce((sum, d) => sum + (dailyData[d]?.visitsWithAddon || 0), 0);
      const totalAddons = selectedDates.reduce((sum, d) => sum + (dailyData[d]?.addonCount || 0), 0);
      const totalHours = selectedDates.reduce((sum, d) => {
        const data = dailyData[d];
        return sum + calculateHours(data?.startTime || '09:00', data?.endTime || '17:00', data?.breakMinutes || 30);
      }, 0);
      const totalClientHours = selectedDates.reduce((sum, d) => sum + (dailyData[d]?.hoursWithClient || 0), 0);

      if (ansatt.user_id) {
        await supabase
          .from('weekly_kpi_inputs')
          .upsert({
            stylist_id: ansatt.user_id,
            salon_id: ansatt.salong_id,
            year,
            week: weekNumber,
            treatment_revenue: totalTreatment,
            retail_revenue: totalRetail,
            addon_revenue: totalAddon,
            visit_count: totalVisits,
            rebooked_visits: totalRebooked,
            visits_with_addon: totalWithAddon,
            addon_count: totalAddons,
            hours_worked: totalHours,
            hours_with_client: totalClientHours,
          }, { onConflict: 'salon_id,stylist_id,year,week' });
      }
    },
    onSuccess: () => {
      toast({
        title: "Data lagret! 🎉",
        description: `KPI-data for ${selectedDates.length} dag${selectedDates.length > 1 ? 'er' : ''} er lagret.`,
      });
      queryClient.invalidateQueries({ queryKey: ['existing-daily-kpi'] });
      queryClient.invalidateQueries({ queryKey: ['mine-faktiske-resultater'] });
      queryClient.invalidateQueries({ queryKey: ['mine-kpi'] });
      onOpenChange(false);
    },
    onError: (error) => {
      toast({
        title: "Feil ved lagring",
        description: error instanceof Error ? error.message : "Kunne ikke lagre data.",
        variant: "destructive",
      });
    },
  });

  // Helper to recalculate weekly KPI after deletion
  const recalculateWeeklyKPI = async (deletedDateStr: string) => {
    if (!ansatt.user_id || !ansatt.salong_id) return;

    const deletedDate = new Date(deletedDateStr);
    const weekStartDate = startOfWeek(deletedDate, { weekStartsOn: 1 });
    const weekEndDate = endOfWeek(deletedDate, { weekStartsOn: 1 });
    const weekNumber = getISOWeekNumber(deletedDate);
    const year = deletedDate.getFullYear();

    // Fetch remaining daily data for the week
    const { data: remainingKPIs } = await supabase
      .from('daily_kpi_inputs')
      .select('*')
      .eq('ansatt_id', ansatt.id)
      .eq('salon_id', ansatt.salong_id)
      .gte('date', format(weekStartDate, 'yyyy-MM-dd'))
      .lte('date', format(weekEndDate, 'yyyy-MM-dd'));

    const { data: remainingTimes } = await supabase
      .from('daily_time_entries')
      .select('*')
      .eq('ansatt_id', ansatt.id)
      .eq('salon_id', ansatt.salong_id)
      .gte('date', format(weekStartDate, 'yyyy-MM-dd'))
      .lte('date', format(weekEndDate, 'yyyy-MM-dd'));

    if (!remainingKPIs || remainingKPIs.length === 0) {
      // No data left for the week - delete weekly entry
      await supabase
        .from('weekly_kpi_inputs')
        .delete()
        .eq('salon_id', ansatt.salong_id)
        .eq('stylist_id', ansatt.user_id)
        .eq('year', year)
        .eq('week', weekNumber);
    } else {
      // Recalculate weekly totals
      const totals = remainingKPIs.reduce((acc, kpi) => ({
        treatment: acc.treatment + (kpi.treatment_revenue || 0),
        retail: acc.retail + (kpi.retail_revenue || 0),
        addon: acc.addon + ((kpi as any).addon_revenue || 0),
        visits: acc.visits + (kpi.visit_count || 0),
        rebooked: acc.rebooked + (kpi.rebooked_visits || 0),
        withAddon: acc.withAddon + (kpi.visits_with_addon || 0),
        addonCount: acc.addonCount + (kpi.addon_count || 0),
      }), { treatment: 0, retail: 0, addon: 0, visits: 0, rebooked: 0, withAddon: 0, addonCount: 0 });

      const totalHours = (remainingTimes || []).reduce((sum, t) => {
        return sum + calculateHours(t.start_time?.slice(0, 5) || '09:00', t.end_time?.slice(0, 5) || '17:00', t.break_minutes || 30);
      }, 0);
      const totalClientHours = (remainingTimes || []).reduce((sum, t) => sum + ((t as any).hours_with_client || 0), 0);

      await supabase
        .from('weekly_kpi_inputs')
        .upsert({
          stylist_id: ansatt.user_id,
          salon_id: ansatt.salong_id,
          year,
          week: weekNumber,
          treatment_revenue: totals.treatment,
          retail_revenue: totals.retail,
          addon_revenue: totals.addon,
          visit_count: totals.visits,
          rebooked_visits: totals.rebooked,
          visits_with_addon: totals.withAddon,
          addon_count: totals.addonCount,
          hours_worked: totalHours,
          hours_with_client: totalClientHours,
        }, { onConflict: 'salon_id,stylist_id,year,week' });
    }
  };

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: async (dateStr: string) => {
      if (!ansatt.id || !ansatt.salong_id) {
        throw new Error("Mangler ansatt-ID eller salong-ID");
      }

      // Delete from daily_kpi_inputs
      const { error: kpiError } = await supabase
        .from('daily_kpi_inputs')
        .delete()
        .eq('ansatt_id', ansatt.id)
        .eq('salon_id', ansatt.salong_id)
        .eq('date', dateStr);

      if (kpiError) throw kpiError;

      // Delete from daily_time_entries
      const { error: timeError } = await supabase
        .from('daily_time_entries')
        .delete()
        .eq('ansatt_id', ansatt.id)
        .eq('salon_id', ansatt.salong_id)
        .eq('date', dateStr);

      if (timeError) throw timeError;

      // Recalculate weekly KPI
      await recalculateWeeklyKPI(dateStr);
    },
    onSuccess: (_, dateStr) => {
      toast({
        title: "Registrering slettet",
        description: `Data for ${format(new Date(dateStr), 'd. MMMM', { locale: nb })} er fjernet.`,
      });
      // Remove from local state
      setSelectedDates(prev => prev.filter(d => d !== dateStr));
      setDailyData(prev => {
        const newData = { ...prev };
        delete newData[dateStr];
        return newData;
      });
      queryClient.invalidateQueries({ queryKey: ['existing-daily-kpi'] });
      queryClient.invalidateQueries({ queryKey: ['mine-faktiske-resultater'] });
      queryClient.invalidateQueries({ queryKey: ['mine-kpi'] });
    },
    onError: (error) => {
      toast({
        title: "Feil ved sletting",
        description: error instanceof Error ? error.message : "Kunne ikke slette data.",
        variant: "destructive",
      });
    },
  });

  const renderStep = () => {
    const animationClass = direction === 'forward' 
      ? 'animate-in slide-in-from-right-5 fade-in-50 duration-300' 
      : 'animate-in slide-in-from-left-5 fade-in-50 duration-300';

    switch (currentStep) {
      case 0:
        return (
          <div className={animationClass}>
            <StepPeriod
              mode={mode}
              selectedDates={selectedDates}
              dailyData={dailyData}
              existingDates={existingDates}
              shiftInfoMap={shiftInfoMap}
              viewDate={viewDate}
              onViewDateChange={setViewDate}
              onModeChange={setMode}
              onDatesChange={handleDatesChange}
              onDeleteDate={(dateStr) => deleteMutation.mutate(dateStr)}
              isDeleting={deleteMutation.isPending}
              onNext={() => goToStep(1)}
            />
          </div>
        );
      case 1:
        return (
          <div className={animationClass}>
            <StepTime
              selectedDates={selectedDates}
              dailyData={dailyData}
              onDataChange={handleDataChange}
              onPrevious={() => goToStep(0)}
              onNext={() => goToStep(2)}
            />
          </div>
        );
      case 2:
        return (
          <div className={animationClass}>
            <StepRevenue
              selectedDates={selectedDates}
              dailyData={dailyData}
              onDataChange={handleDataChange}
              onPrevious={() => goToStep(1)}
              onNext={() => goToStep(3)}
            />
          </div>
        );
      case 3:
        return (
          <div className={animationClass}>
            <StepVisits
              selectedDates={selectedDates}
              dailyData={dailyData}
              onDataChange={handleDataChange}
              onPrevious={() => goToStep(2)}
              onSave={() => saveMutation.mutate()}
              isSaving={saveMutation.isPending}
            />
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent 
        className={cn(
          "flex flex-col overflow-hidden p-0",
          isMobile 
            ? "w-full h-[100dvh] max-w-full rounded-none" 
            : "sm:max-w-[600px] max-h-[90vh] rounded-lg"
        )}
      >
        {/* Sticky header */}
        <div className="sticky top-0 z-10 bg-background border-b flex-shrink-0">
          <DialogHeader className="p-4 pb-2">
            <DialogTitle className="text-lg sm:text-xl">Registrer Timer & Resultater</DialogTitle>
            <DialogDescription className="text-sm">
              {ansatt.fornavn} {ansatt.etternavn || ''}
            </DialogDescription>
          </DialogHeader>

          {/* Stepper */}
          <div className="px-4 pb-3">
            <WizardStepper
              currentStep={currentStep}
              onStepClick={(step) => step <= currentStep && goToStep(step)}
            />
          </div>
        </div>

        {/* Step content - scrollable */}
        <div 
          ref={contentRef}
          className={cn(
            "flex-1 overflow-y-auto overscroll-contain",
            isMobile ? "px-4 pb-[calc(1rem+env(safe-area-inset-bottom))]" : "px-6 py-6"
          )}
          onTouchStart={handleTouchStart}
          onTouchEnd={handleTouchEnd}
        >
          {renderStep()}
        </div>
      </DialogContent>
    </Dialog>
  );
}
