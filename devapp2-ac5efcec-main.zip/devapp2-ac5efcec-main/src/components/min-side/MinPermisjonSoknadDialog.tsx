import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { format } from "date-fns";
import { nb } from "date-fns/locale";
import { CalendarIcon, Users } from "lucide-react";
import { CurrentAnsatt } from "@/hooks/useCurrentAnsatt";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from "@/lib/utils";

const PERMISJON_TYPER = [
  { 
    value: "velferdspermisjon", 
    label: "Velferdspermisjon",
    description: "Bryllup, begravelse, flytting, etc."
  },
  { 
    value: "foreldrepermisjon", 
    label: "Foreldrepermisjon",
    description: "Fødsel, adopsjon, omsorgspermisjon"
  },
  { 
    value: "ulonnet_permisjon", 
    label: "Ulønnet permisjon",
    description: "Permisjon uten lønn"
  },
] as const;

const formSchema = z.object({
  permisjonstype: z.enum(["velferdspermisjon", "foreldrepermisjon", "ulonnet_permisjon"], {
    required_error: "Velg type permisjon",
  }),
  startdato: z.date({ required_error: "Velg startdato" }),
  sluttdato: z.date({ required_error: "Velg sluttdato" }),
  prosent: z.number().min(1).max(100).default(100),
  kommentar: z.string().min(1, "Vennligst beskriv årsaken til permisjonssøknaden"),
}).refine((data) => data.sluttdato >= data.startdato, {
  message: "Sluttdato må være etter startdato",
  path: ["sluttdato"],
});

type FormData = z.infer<typeof formSchema>;

interface MinPermisjonSoknadDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void;
  ansatt: CurrentAnsatt;
}

export function MinPermisjonSoknadDialog({
  open,
  onOpenChange,
  onSuccess,
  ansatt,
}: MinPermisjonSoknadDialogProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [sluttdatoDisplayMonth, setSluttdatoDisplayMonth] = useState<Date | undefined>();

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      prosent: 100,
      kommentar: "",
    },
  });

  const startdato = form.watch("startdato");
  const permisjonstype = form.watch("permisjonstype");

  const onSubmit = async (data: FormData) => {
    if (!ansatt?.id || !ansatt?.salong_id) {
      toast.error("Mangler brukerinfo");
      return;
    }

    setIsSubmitting(true);
    try {
      const { error } = await supabase.from("fravaer").insert({
        ansatt_id: ansatt.id,
        user_id: ansatt.user_id || null,
        salon_id: ansatt.salong_id,
        fravaerstype: data.permisjonstype,
        startdato: format(data.startdato, "yyyy-MM-dd"),
        sluttdato: format(data.sluttdato, "yyyy-MM-dd"),
        prosent: data.prosent,
        kommentar: data.kommentar,
        status: "pending",
        registrert_av: ansatt.user_id || null,
      });

      if (error) throw error;

      const typeLabel = PERMISJON_TYPER.find(t => t.value === data.permisjonstype)?.label || "Permisjon";
      toast.success(`Søknad om ${typeLabel.toLowerCase()} sendt til godkjenning`);
      form.reset();
      onOpenChange(false);
      onSuccess?.();
    } catch (error) {
      console.error("Error submitting leave request:", error);
      toast.error("Kunne ikke sende permisjonssøknad");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Søk om permisjon
          </DialogTitle>
          <DialogDescription>
            Send søknad om permisjon til din leder for godkjenning.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="permisjonstype"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Type permisjon</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Velg type permisjon" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {PERMISJON_TYPER.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          <div>
                            <div>{type.label}</div>
                            <div className="text-xs text-muted-foreground">{type.description}</div>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="startdato"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Fra dato</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            className={cn(
                              "pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(field.value, "d. MMM yyyy", { locale: nb })
                            ) : (
                              <span>Velg dato</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          month={field.value}
                          locale={nb}
                          initialFocus
                          className="pointer-events-auto"
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="sluttdato"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Til dato</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            className={cn(
                              "pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(field.value, "d. MMM yyyy", { locale: nb })
                            ) : (
                              <span>Velg dato</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={(date) => {
                            field.onChange(date);
                            if (date) setSluttdatoDisplayMonth(date);
                          }}
                          month={sluttdatoDisplayMonth || field.value || startdato}
                          onMonthChange={setSluttdatoDisplayMonth}
                          disabled={(date) => startdato && date < startdato}
                          locale={nb}
                          initialFocus
                          className="pointer-events-auto"
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {permisjonstype === "foreldrepermisjon" && (
              <FormField
                control={form.control}
                name="prosent"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Permisjonsprosent</FormLabel>
                    <FormControl>
                      <Select 
                        onValueChange={(val) => field.onChange(Number(val))} 
                        value={String(field.value)}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="100">100% (full permisjon)</SelectItem>
                          <SelectItem value="80">80%</SelectItem>
                          <SelectItem value="50">50%</SelectItem>
                          <SelectItem value="20">20%</SelectItem>
                        </SelectContent>
                      </Select>
                    </FormControl>
                    <FormDescription>
                      Velg grad av permisjon (gradert permisjon = jobber delvis)
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}

            <FormField
              control={form.control}
              name="kommentar"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Begrunnelse</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Beskriv årsaken til permisjonssøknaden..."
                      className="resize-none min-h-[100px]"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex justify-end gap-3 pt-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
              >
                Avbryt
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? "Sender..." : "Send søknad"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
