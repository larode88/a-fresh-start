import { useState } from "react";
import { PlusCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { KPIRegistreringWizard } from "./kpi-wizard/KPIRegistreringWizard";

interface RegistrerDataDialogProps {
  ansatt: {
    id: string;
    user_id: string | null;
    salong_id: string | null;
    fornavn: string;
    etternavn?: string | null;
  };
  selectedDate: Date;
  isViewingAsOther?: boolean;
}

export function RegistrerDataDialog({ ansatt, selectedDate, isViewingAsOther }: RegistrerDataDialogProps) {
  const [open, setOpen] = useState(false);

  return (
    <>
      <Button variant="outline" size="sm" className="gap-2" onClick={() => setOpen(true)}>
        <PlusCircle className="h-4 w-4" />
        <span className="hidden sm:inline">Registrer Timer & Resultater</span>
      </Button>
      
      <KPIRegistreringWizard
        open={open}
        onOpenChange={setOpen}
        ansatt={ansatt}
        initialDate={selectedDate}
      />
    </>
  );
}
