import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { format, differenceInCalendarDays } from "date-fns";
import { nb } from "date-fns/locale";
import { CalendarIcon, Thermometer, AlertCircle } from "lucide-react";
import { CurrentAnsatt } from "@/hooks/useCurrentAnsatt";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { Alert, AlertDescription } from "@/components/ui/alert";

const FRAVAER_TYPER = [
  { value: "egenmelding", label: "Egenmelding", maxDays: 3 },
  { value: "lege_helse", label: "Lege/helse", maxDays: null },
  { value: "annet", label: "Annet korttidsfravær", maxDays: null },
] as const;

const formSchema = z.object({
  fravaerstype: z.enum(["egenmelding", "lege_helse", "annet"], {
    required_error: "Velg type fravær",
  }),
  startdato: z.date({ required_error: "Velg startdato" }),
  sluttdato: z.date({ required_error: "Velg sluttdato" }),
  kommentar: z.string().optional(),
});

type FormData = z.infer<typeof formSchema>;

interface MinFravaerRegistreringDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void;
  ansatt: CurrentAnsatt;
}

export function MinFravaerRegistreringDialog({
  open,
  onOpenChange,
  onSuccess,
  ansatt,
}: MinFravaerRegistreringDialogProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [sluttdatoDisplayMonth, setSluttdatoDisplayMonth] = useState<Date | undefined>();

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      kommentar: "",
    },
  });

  const fravaerstype = form.watch("fravaerstype");
  const startdato = form.watch("startdato");
  const sluttdato = form.watch("sluttdato");

  // Check egenmelding limit
  const egenmeldingWarning = () => {
    if (fravaerstype !== "egenmelding" || !startdato || !sluttdato) return null;
    const days = differenceInCalendarDays(sluttdato, startdato) + 1;
    if (days > 3) {
      return "Egenmelding kan normalt kun brukes i opptil 3 dager. Lengre fravær krever sykmelding fra lege.";
    }
    return null;
  };

  const warning = egenmeldingWarning();

  const onSubmit = async (data: FormData) => {
    if (!ansatt?.id || !ansatt?.salong_id) {
      toast.error("Mangler brukerinfo");
      return;
    }

    // Validate egenmelding limit
    if (data.fravaerstype === "egenmelding") {
      const days = differenceInCalendarDays(data.sluttdato, data.startdato) + 1;
      if (days > 3) {
        toast.error("Egenmelding kan maks være 3 dager. Kontakt lege for lengre fravær.");
        return;
      }
    }

    setIsSubmitting(true);
    try {
      const { error } = await supabase.from("fravaer").insert({
        ansatt_id: ansatt.id,
        user_id: ansatt.user_id || null,
        salon_id: ansatt.salong_id,
        fravaerstype: data.fravaerstype,
        startdato: format(data.startdato, "yyyy-MM-dd"),
        sluttdato: format(data.sluttdato, "yyyy-MM-dd"),
        kommentar: data.kommentar || null,
        prosent: 100,
        status: "aktiv",
        registrert_av: ansatt.user_id || null,
      });

      if (error) throw error;

      const typeLabel = FRAVAER_TYPER.find(t => t.value === data.fravaerstype)?.label || "Fravær";
      toast.success(`${typeLabel} registrert`);
      form.reset();
      onOpenChange(false);
      onSuccess?.();
    } catch (error) {
      console.error("Error registering absence:", error);
      toast.error("Kunne ikke registrere fravær");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Thermometer className="h-5 w-5" />
            Meld fravær
          </DialogTitle>
          <DialogDescription>
            Registrer egenmelding, legebesøk eller annet korttidsfravær.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="fravaerstype"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Type fravær</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Velg type fravær" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {FRAVAER_TYPER.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                          {type.maxDays && (
                            <span className="text-muted-foreground ml-1">
                              (maks {type.maxDays} dager)
                            </span>
                          )}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="startdato"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Fra dato</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            className={cn(
                              "pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(field.value, "d. MMM yyyy", { locale: nb })
                            ) : (
                              <span>Velg dato</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          month={field.value}
                          locale={nb}
                          initialFocus
                          className="pointer-events-auto"
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="sluttdato"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Til dato</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            className={cn(
                              "pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(field.value, "d. MMM yyyy", { locale: nb })
                            ) : (
                              <span>Velg dato</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={(date) => {
                            field.onChange(date);
                            if (date) setSluttdatoDisplayMonth(date);
                          }}
                          month={sluttdatoDisplayMonth || field.value || startdato}
                          onMonthChange={setSluttdatoDisplayMonth}
                          disabled={(date) => startdato && date < startdato}
                          locale={nb}
                          initialFocus
                          className="pointer-events-auto"
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {warning && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>{warning}</AlertDescription>
              </Alert>
            )}

            <FormField
              control={form.control}
              name="kommentar"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Kommentar (valgfritt)</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Kort beskrivelse..."
                      className="resize-none"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex justify-end gap-3 pt-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
              >
                Avbryt
              </Button>
              <Button type="submit" disabled={isSubmitting || !!warning}>
                {isSubmitting ? "Registrerer..." : "Registrer fravær"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
