import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useQuery } from "@tanstack/react-query";
import { format, differenceInCalendarDays } from "date-fns";
import { nb } from "date-fns/locale";
import { CalendarIcon, Plane, Clock, Loader2, CalendarOff } from "lucide-react";
import { CurrentAnsatt } from "@/hooks/useCurrentAnsatt";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { calculateFerieBeregning, FerieBeregning } from "@/lib/ferieUtils";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { Card, CardContent } from "@/components/ui/card";

const FERIE_TYPER = [
  { value: "Sommerferie", label: "Sommerferie" },
  { value: "Vinterferie", label: "Vinterferie" },
  { value: "Påskeferie", label: "Påskeferie" },
  { value: "Høstferie", label: "Høstferie" },
  { value: "Juleferie", label: "Juleferie" },
  { value: "Annen ferie", label: "Annen ferie" },
];

const formSchema = z.object({
  type: z.string().default("Annen ferie"),
  startdato: z.date({ required_error: "Velg startdato" }),
  sluttdato: z.date({ required_error: "Velg sluttdato" }),
  kommentar: z.string().optional(),
}).refine((data) => data.sluttdato >= data.startdato, {
  message: "Sluttdato må være etter startdato",
  path: ["sluttdato"],
});

type FormData = z.infer<typeof formSchema>;

interface MinFerieSoknadDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void;
  ansatt: CurrentAnsatt;
}

export function MinFerieSoknadDialog({ 
  open, 
  onOpenChange,
  onSuccess,
  ansatt
}: MinFerieSoknadDialogProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [sluttdatoDisplayMonth, setSluttdatoDisplayMonth] = useState<Date | undefined>();

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      type: "Annen ferie",
      kommentar: "",
    },
  });

  const startdato = form.watch("startdato");
  const sluttdato = form.watch("sluttdato");

  // Calculate days and hours - now async with holiday exclusion
  const { data: ferieInfo, isLoading: isCalculating } = useQuery({
    queryKey: ['min-ferie-beregning', startdato?.toISOString(), sluttdato?.toISOString(), ansatt?.id],
    queryFn: async () => {
      if (!startdato || !sluttdato || !ansatt) return null;
      const stillingsprosent = ansatt.stillingsprosent || 100;
      const beregning = await calculateFerieBeregning(startdato, sluttdato, stillingsprosent);
      return {
        ...beregning,
        calendarDays: differenceInCalendarDays(sluttdato, startdato) + 1
      };
    },
    enabled: !!(startdato && sluttdato && ansatt),
  });

  const onSubmit = async (data: FormData) => {
    if (!ansatt?.id || !ansatt?.salong_id) {
      toast.error("Mangler brukerinfo");
      return;
    }

    setIsSubmitting(true);
    try {
      // VIKTIG: Beregn timer på nytt ved lagring for å garantere korrekte verdier
      // Dette forhindrer race conditions hvor cached data brukes
      const stillingsprosent = ansatt.stillingsprosent || 100;
      const freshBeregning = await calculateFerieBeregning(
        data.startdato,
        data.sluttdato,
        stillingsprosent
      );

      const { error } = await supabase.from("ferie").insert({
        ansatt_id: ansatt.id,
        user_id: ansatt.user_id || null,
        salon_id: ansatt.salong_id,
        startdato: format(data.startdato, "yyyy-MM-dd"),
        sluttdato: format(data.sluttdato, "yyyy-MM-dd"),
        aar: data.startdato.getFullYear(),
        antall_dager: freshBeregning.arbeidsdager,
        timer: freshBeregning.timer,
        type: data.type,
        kommentar: data.kommentar || null,
        status: "søknad",
      });

      if (error) throw error;

      toast.success("Feriesøknad sendt til godkjenning");
      form.reset();
      onOpenChange(false);
      onSuccess?.();
    } catch (error) {
      console.error("Error submitting vacation request:", error);
      toast.error("Kunne ikke sende feriesøknad");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Plane className="h-5 w-5" />
            Søk om ferie
          </DialogTitle>
          <DialogDescription>
            Velg type og periode, og send søknad til din leder for godkjenning.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Ferietype</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Velg ferietype" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {FERIE_TYPER.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="startdato"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Fra dato</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            className={cn(
                              "pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(field.value, "d. MMM yyyy", { locale: nb })
                            ) : (
                              <span>Velg dato</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          month={field.value}
                          disabled={(date) => date < new Date()}
                          locale={nb}
                          initialFocus
                          className="pointer-events-auto"
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="sluttdato"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Til dato</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            className={cn(
                              "pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(field.value, "d. MMM yyyy", { locale: nb })
                            ) : (
                              <span>Velg dato</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={(date) => {
                            field.onChange(date);
                            if (date) setSluttdatoDisplayMonth(date);
                          }}
                          month={sluttdatoDisplayMonth || field.value || startdato}
                          onMonthChange={setSluttdatoDisplayMonth}
                          disabled={(date) => 
                            date < new Date() || 
                            (startdato && date < startdato)
                          }
                          locale={nb}
                          initialFocus
                          className="pointer-events-auto"
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {isCalculating && startdato && sluttdato && (
              <Card className="bg-primary/5 border-primary/20">
                <CardContent className="py-3 flex items-center gap-2 text-sm text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span>Beregner ferietimer...</span>
                </CardContent>
              </Card>
            )}
            {ferieInfo && !isCalculating && (
              <Card className="bg-primary/5 border-primary/20">
                <CardContent className="py-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-sm">
                      <Clock className="h-4 w-4 text-primary" />
                      <span className="text-muted-foreground">Beregnet ferie:</span>
                    </div>
                    <div className="text-right">
                      <span className="font-semibold">{ferieInfo.arbeidsdager} arbeidsdager</span>
                      <span className="text-muted-foreground ml-1">({ferieInfo.timer}t)</span>
                    </div>
                  </div>
                  {ferieInfo.ekskluderteHelligdager.length > 0 && (
                    <div className="flex items-start gap-2 pt-2 border-t text-xs text-green-600">
                      <CalendarOff className="h-3.5 w-3.5 mt-0.5 shrink-0" />
                      <div>
                        <span className="font-medium">Helligdager trukket fra:</span>
                        <ul className="mt-0.5">
                          {ferieInfo.ekskluderteHelligdager.map((h) => (
                            <li key={h.dato}>
                              • {h.helligdag_navn || format(new Date(h.dato + 'T12:00:00'), 'd. MMM', { locale: nb })}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  )}
                  {ansatt?.stillingsprosent && ansatt.stillingsprosent < 100 && (
                    <p className="text-xs text-muted-foreground pt-1 border-t">
                      Justert for {ansatt.stillingsprosent}% stilling
                    </p>
                  )}
                </CardContent>
              </Card>
            )}

            <FormField
              control={form.control}
              name="kommentar"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Kommentar (valgfritt)</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="F.eks. årsak eller spesielle ønsker..."
                      className="resize-none"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="flex justify-end gap-3 pt-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
              >
                Avbryt
              </Button>
              <Button type="submit" disabled={isSubmitting || isCalculating}>
                {isSubmitting ? "Sender..." : "Send søknad"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
