import { useEffect, useCallback } from "react";
import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { useDroppable } from "@dnd-kit/core";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { GripVertical, Trash2, Copy, ChevronUp, ChevronDown } from "lucide-react";
import EmailModuleRenderer from "./EmailModuleRenderer";
import type { EmailModule } from "@/lib/emailHtmlGenerator";
import type { PreviewMode, ZoomLevel } from "./EmailCanvasToolbar";

interface SortableModuleProps {
  module: EmailModule;
  isActive: boolean;
  index: number;
  totalModules: number;
  onSelect: () => void;
  onUpdate: (updates: Partial<EmailModule>) => void;
  onDelete: () => void;
  onDuplicate?: () => void;
  onMoveUp?: () => void;
  onMoveDown?: () => void;
}

function SortableModule({ 
  module, 
  isActive, 
  index,
  totalModules,
  onSelect, 
  onUpdate, 
  onDelete, 
  onDuplicate,
  onMoveUp,
  onMoveDown 
}: SortableModuleProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: module.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={cn(
        "group relative rounded-lg transition-all",
        isDragging && "opacity-50 z-50",
        isActive ? "ring-2 ring-primary ring-offset-2" : "hover:ring-1 hover:ring-border"
      )}
      onClick={(e) => {
        e.stopPropagation();
        onSelect();
      }}
      tabIndex={0}
      onKeyDown={(e) => {
        // Don't handle keyboard shortcuts when user is editing text
        const target = e.target as HTMLElement;
        const isEditing = target.isContentEditable || 
                          target.tagName === "INPUT" || 
                          target.tagName === "TEXTAREA" ||
                          target.closest('[contenteditable="true"]');
        
        if (e.key === "Enter" || e.key === " ") {
          if (!isEditing) {
            e.preventDefault();
            onSelect();
          }
        }
        if (e.key === "Delete" || e.key === "Backspace") {
          if (!isEditing) {
            e.preventDefault();
            onDelete();
          }
        }
        if (e.key === "ArrowUp" && e.altKey && !isEditing) {
          e.preventDefault();
          onMoveUp?.();
        }
        if (e.key === "ArrowDown" && e.altKey && !isEditing) {
          e.preventDefault();
          onMoveDown?.();
        }
        if (e.key === "d" && (e.metaKey || e.ctrlKey) && !isEditing) {
          e.preventDefault();
          onDuplicate?.();
        }
      }}
    >
      {/* Module toolbar */}
      <div className={cn(
        "absolute -top-10 left-1/2 transform -translate-x-1/2 flex items-center gap-1 bg-background border rounded-lg shadow-sm p-1 transition-opacity z-10",
        isActive ? "opacity-100" : "opacity-0 group-hover:opacity-100"
      )}>
        <Button
          variant="ghost"
          size="icon"
          className="h-7 w-7"
          onClick={(e) => {
            e.stopPropagation();
            onMoveUp?.();
          }}
          disabled={index === 0}
          title="Flytt opp (Alt+↑)"
        >
          <ChevronUp className="h-4 w-4" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="h-7 w-7"
          onClick={(e) => {
            e.stopPropagation();
            onMoveDown?.();
          }}
          disabled={index === totalModules - 1}
          title="Flytt ned (Alt+↓)"
        >
          <ChevronDown className="h-4 w-4" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="h-7 w-7 cursor-grab active:cursor-grabbing"
          {...attributes}
          {...listeners}
        >
          <GripVertical className="h-4 w-4" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="h-7 w-7"
          onClick={(e) => {
            e.stopPropagation();
            onDuplicate?.();
          }}
          title="Dupliser (Ctrl+D)"
        >
          <Copy className="h-4 w-4" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="h-7 w-7 text-destructive hover:text-destructive"
          onClick={(e) => {
            e.stopPropagation();
            onDelete();
          }}
          title="Slett (Delete)"
        >
          <Trash2 className="h-4 w-4" />
        </Button>
      </div>

      {/* Module content */}
      <div className="bg-white rounded-lg overflow-hidden">
        <EmailModuleRenderer module={module} isEditing={isActive} onUpdate={onUpdate} />
      </div>
    </div>
  );
}

interface EmailCanvasProps {
  modules: EmailModule[];
  activeModuleId: string | null;
  onModuleSelect: (id: string | null) => void;
  onModuleUpdate: (id: string, updates: Partial<EmailModule>) => void;
  onModuleDelete: (id: string) => void;
  onModuleDuplicate?: (id: string) => void;
  onModuleMove?: (fromIndex: number, toIndex: number) => void;
  previewMode?: PreviewMode;
  zoom?: ZoomLevel;
}

export default function EmailCanvas({
  modules,
  activeModuleId,
  onModuleSelect,
  onModuleUpdate,
  onModuleDelete,
  onModuleDuplicate,
  onModuleMove,
  previewMode = "desktop",
  zoom = 100,
}: EmailCanvasProps) {
  const { setNodeRef, isOver } = useDroppable({
    id: "canvas-dropzone",
  });

  // Get canvas width based on preview mode
  const getCanvasWidth = () => {
    switch (previewMode) {
      case "mobile":
        return 375;
      case "tablet":
        return 480;
      case "desktop":
      default:
        return 600;
    }
  };

  // Keyboard navigation between modules
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable) {
        return;
      }

      if (!activeModuleId) return;

      const currentIndex = modules.findIndex(m => m.id === activeModuleId);
      if (currentIndex === -1) return;

      if (e.key === "ArrowUp" && !e.altKey) {
        e.preventDefault();
        if (currentIndex > 0) {
          onModuleSelect(modules[currentIndex - 1].id);
        }
      }

      if (e.key === "ArrowDown" && !e.altKey) {
        e.preventDefault();
        if (currentIndex < modules.length - 1) {
          onModuleSelect(modules[currentIndex + 1].id);
        }
      }

      if (e.key === "Escape") {
        e.preventDefault();
        onModuleSelect(null);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [activeModuleId, modules, onModuleSelect]);

  const handleMoveUp = useCallback((index: number) => {
    if (index > 0 && onModuleMove) {
      onModuleMove(index, index - 1);
    }
  }, [onModuleMove]);

  const handleMoveDown = useCallback((index: number) => {
    if (index < modules.length - 1 && onModuleMove) {
      onModuleMove(index, index + 1);
    }
  }, [modules.length, onModuleMove]);

  const canvasWidth = getCanvasWidth();
  const scaledWidth = canvasWidth * (zoom / 100);

  return (
    <div 
      className="flex justify-center py-6 transition-all duration-200"
      style={{ transform: `scale(${zoom / 100})`, transformOrigin: "top center" }}
    >
      <div style={{ width: canvasWidth + 100 }}>
        {/* Canvas area */}
        <div 
          ref={setNodeRef}
          className={cn(
            "bg-[#FAF8F5] rounded-xl shadow-sm min-h-[600px] overflow-hidden mx-auto transition-all duration-200",
            isOver && "ring-2 ring-primary ring-dashed"
          )}
          onClick={() => onModuleSelect(null)}
          style={{ width: canvasWidth + 100 }}
        >
          {/* Email container */}
          <div 
            className="mx-auto bg-white shadow-sm my-6 transition-all duration-200"
            style={{ width: canvasWidth }}
          >
            {modules.length === 0 ? (
              <div className="p-12 text-center text-muted-foreground border-2 border-dashed m-4 rounded-lg">
                <p className="text-lg font-medium mb-2">Dra moduler hit</p>
                <p className="text-sm">Velg en modul fra panelet til venstre og dra den hit for å begynne</p>
                <p className="text-xs mt-4 text-muted-foreground/70">
                  Tip: Bruk piltaster for å navigere mellom moduler
                </p>
              </div>
            ) : (
              <div className="space-y-0">
                {modules.map((module, index) => (
                  <SortableModule
                    key={module.id}
                    module={module}
                    index={index}
                    totalModules={modules.length}
                    isActive={module.id === activeModuleId}
                    onSelect={() => onModuleSelect(module.id)}
                    onUpdate={(updates) => onModuleUpdate(module.id, updates)}
                    onDelete={() => onModuleDelete(module.id)}
                    onDuplicate={onModuleDuplicate ? () => onModuleDuplicate(module.id) : undefined}
                    onMoveUp={() => handleMoveUp(index)}
                    onMoveDown={() => handleMoveDown(index)}
                  />
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Preview mode indicator */}
        <div className="text-center mt-4">
          <span className="text-xs text-muted-foreground bg-muted/50 px-3 py-1 rounded-full">
            {previewMode === "desktop" && "Desktop (600px)"}
            {previewMode === "tablet" && "Tablet (480px)"}
            {previewMode === "mobile" && "Mobil (375px)"}
          </span>
        </div>
      </div>
    </div>
  );
}
