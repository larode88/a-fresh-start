import { useState } from "react";
import { useDraggable } from "@dnd-kit/core";
import { CSS } from "@dnd-kit/utilities";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import {
  Search,
  Type,
  Image,
  MousePointer2,
  Info,
  CheckCircle,
  AlertTriangle,
  Table,
  List,
  FileSignature,
  Scale,
  Minus,
  Columns,
  KeyRound,
  LayoutTemplate,
  Calendar,
  MessageCircle,
  Heading,
  Space,
  Quote,
  Building,
  ListChecks,
  LayoutGrid,
  ImageIcon,
  CreditCard,
  Scissors,
  Star,
  Megaphone,
  CalendarDays,
  Share2,
  UserMinus,
  ShoppingBag,
  PanelTop,
  Images,
  Square,
  PanelLeft,
  PanelRight,
} from "lucide-react";

interface ModuleLibraryItem {
  id: string;
  name: string;
  type: string;
  description: string | null;
  is_system_module: boolean;
  default_content: Record<string, any>;
  default_styles: Record<string, any>;
}

interface EmailModulePanelProps {
  modules: ModuleLibraryItem[];
}

const MODULE_ICONS: Record<string, any> = {
  "header-logo": LayoutTemplate,
  "header-portalen": LayoutTemplate,
  "heading": Heading,
  "text": Type,
  "cta-button": MousePointer2,
  "cta-section": PanelTop,
  "info-box": Info,
  "success-banner": CheckCircle,
  "warning-banner": AlertTriangle,
  "product-table": Table,
  "product-card": ShoppingBag,
  "benefits-list": List,
  "icon-list": ListChecks,
  "footer-signature": FileSignature,
  "footer-disclaimer": Scale,
  "footer-social": Share2,
  "footer-unsubscribe": UserMinus,
  "separator": Minus,
  "divider": Minus,
  "spacer": Space,
  "image": Image,
  "image-text-left": PanelLeft,
  "image-text-right": PanelRight,
  "gallery-grid": Images,
  "section-container": Square,
  "two-columns": Columns,
  "three-columns": LayoutGrid,
  "hero-image": ImageIcon,
  "otp-box": KeyRound,
  "date-highlight": Calendar,
  "contact-box": MessageCircle,
  "agreement-box": KeyRound,
  "note-box": Quote,
  "quote-box": Quote,
  "salon-info": Building,
  "salon-card": Building,
  "campaign-price": CreditCard,
  "treatment-list": Scissors,
  "benefits-highlight": Star,
  "event-card": CalendarDays,
  "campaign-banner": Megaphone,
};

// Quick access modules - most commonly used
const QUICK_ACCESS_TYPES = ["text", "heading", "image", "cta-button", "spacer", "info-box"];

// Category color coding
const CATEGORY_COLORS: Record<string, string> = {
  struktur: "bg-blue-500/10 text-blue-600 dark:text-blue-400",
  tekst: "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400",
  media: "bg-purple-500/10 text-purple-600 dark:text-purple-400",
  komponenter: "bg-amber-500/10 text-amber-600 dark:text-amber-400",
  bannere: "bg-rose-500/10 text-rose-600 dark:text-rose-400",
};

function CompactModuleCard({ module }: { module: ModuleLibraryItem }) {
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({
    id: `library-${module.type}`,
    data: {
      isNew: true,
      type: module.type,
    },
  });

  const style = {
    transform: CSS.Translate.toString(transform),
    opacity: isDragging ? 0.5 : 1,
  };

  const IconComponent = MODULE_ICONS[module.type] || Type;

  return (
    <TooltipProvider delayDuration={300}>
      <Tooltip>
        <TooltipTrigger asChild>
          <div
            ref={setNodeRef}
            style={style}
            {...listeners}
            {...attributes}
            className="flex flex-col items-center justify-center p-2 bg-background border rounded-lg cursor-grab active:cursor-grabbing hover:border-primary hover:shadow-md hover:scale-105 transition-all group aspect-square"
          >
            <div className="p-2 rounded-md bg-muted group-hover:bg-primary/10 transition-colors">
              <IconComponent className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors" />
            </div>
            <span className="text-[10px] text-muted-foreground mt-1.5 text-center leading-tight line-clamp-2 group-hover:text-foreground transition-colors">
              {module.name}
            </span>
          </div>
        </TooltipTrigger>
        <TooltipContent side="right" className="max-w-[200px]">
          <p className="font-medium">{module.name}</p>
          {module.description && (
            <p className="text-xs text-muted-foreground mt-1">{module.description}</p>
          )}
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

function QuickAccessCard({ module }: { module: ModuleLibraryItem }) {
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({
    id: `library-${module.type}`,
    data: {
      isNew: true,
      type: module.type,
    },
  });

  const style = {
    transform: CSS.Translate.toString(transform),
    opacity: isDragging ? 0.5 : 1,
  };

  const IconComponent = MODULE_ICONS[module.type] || Type;

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...listeners}
      {...attributes}
      className="flex items-center gap-2 px-3 py-2 bg-primary/5 border border-primary/20 rounded-lg cursor-grab active:cursor-grabbing hover:bg-primary/10 hover:border-primary/40 transition-all"
    >
      <IconComponent className="h-4 w-4 text-primary" />
      <span className="text-xs font-medium text-primary">{module.name}</span>
    </div>
  );
}

export default function EmailModulePanel({ modules }: EmailModulePanelProps) {
  const [search, setSearch] = useState("");

  const systemModules = modules.filter((m) => m.is_system_module);
  const userModules = modules.filter((m) => !m.is_system_module);

  const filteredSystemModules = systemModules.filter(
    (m) =>
      m.name.toLowerCase().includes(search.toLowerCase()) ||
      m.type.toLowerCase().includes(search.toLowerCase())
  );

  const filteredUserModules = userModules.filter(
    (m) =>
      m.name.toLowerCase().includes(search.toLowerCase()) ||
      m.type.toLowerCase().includes(search.toLowerCase())
  );

  // Quick access modules
  const quickAccessModules = systemModules.filter((m) => 
    QUICK_ACCESS_TYPES.includes(m.type)
  );

  // Consolidated categories (5 main categories)
  const strukturModules = filteredSystemModules.filter((m) => 
    m.type.includes("header") || m.type.includes("footer") || 
    ["separator", "divider", "spacer", "two-columns", "three-columns", "section-container"].includes(m.type)
  );
  
  const tekstModules = filteredSystemModules.filter((m) => 
    ["heading", "text", "quote-box", "note-box"].includes(m.type)
  );
  
  const mediaModules = filteredSystemModules.filter((m) => 
    ["image", "hero-image", "image-text-left", "image-text-right", "gallery-grid"].includes(m.type)
  );
  
  const komponentModules = filteredSystemModules.filter((m) => 
    ["cta-button", "cta-section", "info-box", "otp-box", "date-highlight", "contact-box", 
     "agreement-box", "product-table", "product-card", "benefits-list", "icon-list", 
     "treatment-list", "salon-info", "salon-card", "campaign-price", "benefits-highlight", "event-card"].includes(m.type)
  );
  
  const bannerModules = filteredSystemModules.filter((m) => 
    ["success-banner", "warning-banner", "campaign-banner"].includes(m.type)
  );

  const showQuickAccess = !search && quickAccessModules.length > 0;

  return (
    <div className="w-64 bg-background border-r flex flex-col">
      <div className="p-3 border-b">
        <h2 className="font-semibold text-sm mb-2">Moduler</h2>
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 transform -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
          <Input
            placeholder="Søk..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-8 h-8 text-sm"
          />
        </div>
      </div>

      <ScrollArea className="flex-1">
        <div className="p-3 space-y-4">
          {/* Quick Access Section */}
          {showQuickAccess && (
            <div className="space-y-2">
              <h3 className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                Hurtigvalg
              </h3>
              <div className="flex flex-wrap gap-1.5">
                {quickAccessModules.map((module) => (
                  <QuickAccessCard key={module.id} module={module} />
                ))}
              </div>
            </div>
          )}

          {/* Category Accordion - only one open by default */}
          <Accordion type="single" collapsible defaultValue="tekst" className="space-y-1">
            {strukturModules.length > 0 && (
              <AccordionItem value="struktur" className="border rounded-lg overflow-hidden">
                <AccordionTrigger className="py-2 px-3 text-xs font-medium hover:no-underline hover:bg-muted/50">
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${CATEGORY_COLORS.struktur}`} />
                    Struktur
                  </div>
                  <Badge variant="outline" className="ml-auto mr-2 h-5 text-[10px]">
                    {strukturModules.length}
                  </Badge>
                </AccordionTrigger>
                <AccordionContent className="p-2 pt-0">
                  <div className="grid grid-cols-3 gap-1.5">
                    {strukturModules.map((module) => (
                      <CompactModuleCard key={module.id} module={module} />
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>
            )}

            {tekstModules.length > 0 && (
              <AccordionItem value="tekst" className="border rounded-lg overflow-hidden">
                <AccordionTrigger className="py-2 px-3 text-xs font-medium hover:no-underline hover:bg-muted/50">
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${CATEGORY_COLORS.tekst}`} />
                    Tekst
                  </div>
                  <Badge variant="outline" className="ml-auto mr-2 h-5 text-[10px]">
                    {tekstModules.length}
                  </Badge>
                </AccordionTrigger>
                <AccordionContent className="p-2 pt-0">
                  <div className="grid grid-cols-3 gap-1.5">
                    {tekstModules.map((module) => (
                      <CompactModuleCard key={module.id} module={module} />
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>
            )}

            {mediaModules.length > 0 && (
              <AccordionItem value="media" className="border rounded-lg overflow-hidden">
                <AccordionTrigger className="py-2 px-3 text-xs font-medium hover:no-underline hover:bg-muted/50">
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${CATEGORY_COLORS.media}`} />
                    Media
                  </div>
                  <Badge variant="outline" className="ml-auto mr-2 h-5 text-[10px]">
                    {mediaModules.length}
                  </Badge>
                </AccordionTrigger>
                <AccordionContent className="p-2 pt-0">
                  <div className="grid grid-cols-3 gap-1.5">
                    {mediaModules.map((module) => (
                      <CompactModuleCard key={module.id} module={module} />
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>
            )}

            {komponentModules.length > 0 && (
              <AccordionItem value="komponenter" className="border rounded-lg overflow-hidden">
                <AccordionTrigger className="py-2 px-3 text-xs font-medium hover:no-underline hover:bg-muted/50">
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${CATEGORY_COLORS.komponenter}`} />
                    Komponenter
                  </div>
                  <Badge variant="outline" className="ml-auto mr-2 h-5 text-[10px]">
                    {komponentModules.length}
                  </Badge>
                </AccordionTrigger>
                <AccordionContent className="p-2 pt-0">
                  <div className="grid grid-cols-3 gap-1.5">
                    {komponentModules.map((module) => (
                      <CompactModuleCard key={module.id} module={module} />
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>
            )}

            {bannerModules.length > 0 && (
              <AccordionItem value="bannere" className="border rounded-lg overflow-hidden">
                <AccordionTrigger className="py-2 px-3 text-xs font-medium hover:no-underline hover:bg-muted/50">
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${CATEGORY_COLORS.bannere}`} />
                    Bannere
                  </div>
                  <Badge variant="outline" className="ml-auto mr-2 h-5 text-[10px]">
                    {bannerModules.length}
                  </Badge>
                </AccordionTrigger>
                <AccordionContent className="p-2 pt-0">
                  <div className="grid grid-cols-3 gap-1.5">
                    {bannerModules.map((module) => (
                      <CompactModuleCard key={module.id} module={module} />
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>
            )}

            {filteredUserModules.length > 0 && (
              <AccordionItem value="egne" className="border rounded-lg overflow-hidden">
                <AccordionTrigger className="py-2 px-3 text-xs font-medium hover:no-underline hover:bg-muted/50">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-primary" />
                    Egne moduler
                  </div>
                  <Badge variant="outline" className="ml-auto mr-2 h-5 text-[10px]">
                    {filteredUserModules.length}
                  </Badge>
                </AccordionTrigger>
                <AccordionContent className="p-2 pt-0">
                  <div className="grid grid-cols-3 gap-1.5">
                    {filteredUserModules.map((module) => (
                      <CompactModuleCard key={module.id} module={module} />
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>
            )}
          </Accordion>

          {filteredSystemModules.length === 0 && filteredUserModules.length === 0 && (
            <div className="text-center py-6 text-muted-foreground">
              <p className="text-xs">Ingen moduler funnet</p>
            </div>
          )}
        </div>
      </ScrollArea>

      <div className="p-2 border-t bg-muted/30">
        <p className="text-[10px] text-muted-foreground text-center">
          Dra til canvas for å legge til
        </p>
      </div>
    </div>
  );
}
