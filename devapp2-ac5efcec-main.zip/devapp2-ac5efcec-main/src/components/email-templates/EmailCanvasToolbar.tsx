import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { 
  Undo2, 
  Redo2, 
  Monitor, 
  Tablet, 
  Smartphone,
  ZoomIn,
  ZoomOut,
  Loader2,
  Check,
  AlertCircle,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { AutosaveStatus } from "@/hooks/useAutosave";

export type PreviewMode = "desktop" | "tablet" | "mobile";
export type ZoomLevel = 50 | 75 | 100 | 125;

interface EmailCanvasToolbarProps {
  // Undo/Redo
  canUndo: boolean;
  canRedo: boolean;
  onUndo: () => void;
  onRedo: () => void;
  historyLength: number;
  
  // Preview mode
  previewMode: PreviewMode;
  onPreviewModeChange: (mode: PreviewMode) => void;
  
  // Zoom
  zoom: ZoomLevel;
  onZoomChange: (zoom: ZoomLevel) => void;
  
  // Autosave status
  autosaveStatus: AutosaveStatus;
  lastSavedAt: Date | null;
}

export default function EmailCanvasToolbar({
  canUndo,
  canRedo,
  onUndo,
  onRedo,
  historyLength,
  previewMode,
  onPreviewModeChange,
  zoom,
  onZoomChange,
  autosaveStatus,
  lastSavedAt,
}: EmailCanvasToolbarProps) {
  const formatLastSaved = (date: Date | null) => {
    if (!date) return "";
    return date.toLocaleTimeString("nb-NO", { hour: "2-digit", minute: "2-digit" });
  };

  return (
    <div className="flex items-center justify-between bg-background/95 backdrop-blur-sm border-b px-4 py-2 sticky top-0 z-40">
      {/* Left section - Undo/Redo */}
      <div className="flex items-center gap-2">
        <Button
          variant="ghost"
          size="sm"
          onClick={onUndo}
          disabled={!canUndo}
          title="Angre (Ctrl+Z)"
          className="h-8"
        >
          <Undo2 className="h-4 w-4 mr-1" />
          Angre
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={onRedo}
          disabled={!canRedo}
          title="Gjør om (Ctrl+Shift+Z)"
          className="h-8"
        >
          <Redo2 className="h-4 w-4 mr-1" />
          Gjør om
        </Button>
        {historyLength > 0 && (
          <span className="text-xs text-muted-foreground ml-2">
            {historyLength} {historyLength === 1 ? "handling" : "handlinger"}
          </span>
        )}
      </div>

      {/* Center section - Preview modes */}
      <div className="flex items-center gap-1 bg-muted/50 rounded-lg p-1">
        <Button
          variant={previewMode === "desktop" ? "secondary" : "ghost"}
          size="sm"
          onClick={() => onPreviewModeChange("desktop")}
          title="Desktop (600px)"
          className="h-7 px-3"
        >
          <Monitor className="h-4 w-4" />
        </Button>
        <Button
          variant={previewMode === "tablet" ? "secondary" : "ghost"}
          size="sm"
          onClick={() => onPreviewModeChange("tablet")}
          title="Tablet (480px)"
          className="h-7 px-3"
        >
          <Tablet className="h-4 w-4" />
        </Button>
        <Button
          variant={previewMode === "mobile" ? "secondary" : "ghost"}
          size="sm"
          onClick={() => onPreviewModeChange("mobile")}
          title="Mobil (375px)"
          className="h-7 px-3"
        >
          <Smartphone className="h-4 w-4" />
        </Button>
      </div>

      {/* Right section - Zoom & Status */}
      <div className="flex items-center gap-3">
        {/* Zoom controls */}
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onZoomChange(Math.max(50, zoom - 25) as ZoomLevel)}
            disabled={zoom <= 50}
            className="h-7 w-7"
          >
            <ZoomOut className="h-4 w-4" />
          </Button>
          <Select
            value={String(zoom)}
            onValueChange={(v) => onZoomChange(Number(v) as ZoomLevel)}
          >
            <SelectTrigger className="h-7 w-20 text-xs">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="50">50%</SelectItem>
              <SelectItem value="75">75%</SelectItem>
              <SelectItem value="100">100%</SelectItem>
              <SelectItem value="125">125%</SelectItem>
            </SelectContent>
          </Select>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onZoomChange(Math.min(125, zoom + 25) as ZoomLevel)}
            disabled={zoom >= 125}
            className="h-7 w-7"
          >
            <ZoomIn className="h-4 w-4" />
          </Button>
        </div>

        <Separator orientation="vertical" className="h-6" />

        {/* Autosave status */}
        <div className="flex items-center gap-2 text-xs">
          {autosaveStatus === "saving" && (
            <>
              <Loader2 className="h-3 w-3 animate-spin text-muted-foreground" />
              <span className="text-muted-foreground">Lagrer...</span>
            </>
          )}
          {autosaveStatus === "saved" && (
            <>
              <Check className="h-3 w-3 text-green-600" />
              <span className="text-green-600">Lagret</span>
            </>
          )}
          {autosaveStatus === "error" && (
            <>
              <AlertCircle className="h-3 w-3 text-destructive" />
              <span className="text-destructive">Lagring feilet</span>
            </>
          )}
          {autosaveStatus === "idle" && lastSavedAt && (
            <span className="text-muted-foreground">
              Lagret {formatLastSaved(lastSavedAt)}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
