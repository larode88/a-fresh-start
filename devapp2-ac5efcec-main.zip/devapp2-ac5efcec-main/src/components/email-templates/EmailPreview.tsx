import { useMemo } from "react";
import { generateEmailHtml, type EmailStructure } from "@/lib/emailHtmlGenerator";

interface EmailPreviewProps {
  structure: EmailStructure;
  mode: "desktop" | "mobile";
}

export default function EmailPreview({ structure, mode }: EmailPreviewProps) {
  const html = useMemo(() => {
    // Use the shared HTML generator (same logic as render-email-template edge function)
    return generateEmailHtml(structure);
  }, [structure]);

  return (
    <div 
      className="flex justify-center p-4 bg-muted/30 rounded-lg"
      style={{ minHeight: "500px" }}
    >
      <div 
        className="bg-white shadow-lg rounded-lg overflow-hidden"
        style={{ 
          width: mode === "mobile" ? "375px" : "100%",
          maxWidth: "700px",
        }}
      >
        <iframe
          srcDoc={html}
          title="E-post forhåndsvisning"
          className="w-full h-[600px] border-0"
        />
      </div>
    </div>
  );
}
