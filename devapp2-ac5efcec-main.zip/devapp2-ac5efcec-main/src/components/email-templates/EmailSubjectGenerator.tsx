import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Loader2, Sparkles, Copy, Check } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

interface SubjectSuggestion {
  subject: string;
  previewText: string;
}

interface EmailSubjectGeneratorProps {
  emailContent: string;
  currentSubject: string;
  onSubjectSelect: (subject: string) => void;
}

export default function EmailSubjectGenerator({
  emailContent,
  currentSubject,
  onSubjectSelect,
}: EmailSubjectGeneratorProps) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [suggestions, setSuggestions] = useState<SubjectSuggestion[]>([]);
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);
  const [copied, setCopied] = useState<number | null>(null);

  const generateSuggestions = async () => {
    if (!emailContent?.trim()) {
      toast.error("E-posten har ingen innhold å analysere");
      return;
    }

    setLoading(true);
    setSuggestions([]);
    setSelectedIndex(null);

    try {
      const { data, error } = await supabase.functions.invoke('email-ai-assistant', {
        body: {
          action: 'subject-lines',
          content: emailContent,
        },
      });

      if (error) throw error;

      if (data?.error) {
        throw new Error(data.error);
      }

      const result = data?.result;
      
      if (Array.isArray(result)) {
        setSuggestions(result);
      } else {
        throw new Error('Uventet respons fra AI');
      }
    } catch (error) {
      console.error('Subject generation error:', error);
      toast.error(error instanceof Error ? error.message : 'Kunne ikke generere emnelinjer');
    } finally {
      setLoading(false);
    }
  };

  const handleSelect = (suggestion: SubjectSuggestion, index: number) => {
    setSelectedIndex(index);
    onSubjectSelect(suggestion.subject);
    toast.success("Emnelinje valgt");
  };

  const handleCopy = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopied(index);
    setTimeout(() => setCopied(null), 2000);
    toast.success("Kopiert til utklippstavle");
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2">
          <Sparkles className="h-4 w-4" />
          AI forslag
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5" />
            Emnelinje-forslag
          </DialogTitle>
          <DialogDescription>
            Generer AI-forslag til emnelinje basert på e-postinnholdet.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Current subject */}
          <div className="space-y-2">
            <Label className="text-sm text-muted-foreground">Nåværende emnelinje</Label>
            <Input value={currentSubject || "(ingen)"} disabled className="bg-muted" />
          </div>

          {/* Generate button */}
          {suggestions.length === 0 && (
            <Button 
              onClick={generateSuggestions} 
              disabled={loading || !emailContent?.trim()}
              className="w-full gap-2"
            >
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Genererer forslag...
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4" />
                  Generer emnelinjeforslag
                </>
              )}
            </Button>
          )}

          {/* Suggestions list */}
          {suggestions.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-sm">Forslag ({suggestions.length})</Label>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={generateSuggestions}
                  disabled={loading}
                  className="text-xs"
                >
                  {loading ? (
                    <Loader2 className="h-3 w-3 animate-spin" />
                  ) : (
                    "Generer nye"
                  )}
                </Button>
              </div>
              <ScrollArea className="h-[280px] rounded-md border">
                <div className="p-3 space-y-3">
                  {suggestions.map((suggestion, index) => (
                    <div
                      key={index}
                      className={cn(
                        "p-3 rounded-lg border transition-colors cursor-pointer",
                        selectedIndex === index 
                          ? "border-primary bg-primary/5" 
                          : "hover:border-primary/50 hover:bg-muted/50"
                      )}
                      onClick={() => handleSelect(suggestion, index)}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-sm truncate">
                            {suggestion.subject}
                          </p>
                          <p className="text-xs text-muted-foreground mt-1 truncate">
                            {suggestion.previewText}
                          </p>
                        </div>
                        <div className="flex items-center gap-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-7 w-7"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleCopy(suggestion.subject, index);
                            }}
                          >
                            {copied === index ? (
                              <Check className="h-3 w-3 text-green-600" />
                            ) : (
                              <Copy className="h-3 w-3" />
                            )}
                          </Button>
                          {selectedIndex === index && (
                            <Badge variant="secondary" className="text-[10px]">
                              Valgt
                            </Badge>
                          )}
                        </div>
                      </div>
                      <div className="mt-2">
                        <Badge variant="outline" className="text-[10px]">
                          {suggestion.subject.length} tegn
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>
            Lukk
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
