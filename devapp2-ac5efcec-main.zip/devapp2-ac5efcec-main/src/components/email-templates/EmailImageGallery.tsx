import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Slider } from "@/components/ui/slider";
import { 
  Upload, 
  ImageIcon, 
  Trash2, 
  Check, 
  Loader2,
  Grid3X3,
  Search
} from "lucide-react";

interface EmailImageGalleryProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSelectImage: (url: string, width?: string) => void;
  currentImage?: string;
}

interface StoredImage {
  name: string;
  url: string;
  created_at: string;
}

export default function EmailImageGallery({ 
  open, 
  onOpenChange, 
  onSelectImage, 
  currentImage 
}: EmailImageGalleryProps) {
  const [images, setImages] = useState<StoredImage[]>([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(currentImage || null);
  const [imageWidth, setImageWidth] = useState(100);
  const [searchTerm, setSearchTerm] = useState("");
  const [deleting, setDeleting] = useState<string | null>(null);

  // Fetch images from storage
  const fetchImages = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.storage
        .from('email-assets')
        .list('email-images', {
          sortBy: { column: 'created_at', order: 'desc' }
        });

      if (error) throw error;

      const imageFiles = (data || []).filter(file => 
        file.name.match(/\.(jpg|jpeg|png|gif|webp|svg)$/i)
      );

      const imagesWithUrls = imageFiles.map(file => ({
        name: file.name,
        url: supabase.storage.from('email-assets').getPublicUrl(`email-images/${file.name}`).data.publicUrl,
        created_at: file.created_at || ''
      }));

      setImages(imagesWithUrls);
    } catch (error) {
      console.error('Error fetching images:', error);
      toast.error('Kunne ikke laste bilder');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (open) {
      fetchImages();
      setSelectedImage(currentImage || null);
    }
  }, [open, currentImage]);

  // Upload new image
  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.error('Vennligst velg en bildefil');
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      toast.error('Bildet er for stort (maks 5MB)');
      return;
    }

    setUploading(true);
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;
      const filePath = `email-images/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('email-assets')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      toast.success('Bilde lastet opp');
      await fetchImages();
    } catch (error: any) {
      console.error('Upload error:', error);
      toast.error('Kunne ikke laste opp bilde');
    } finally {
      setUploading(false);
    }
  };

  // Delete image
  const handleDelete = async (imageName: string) => {
    if (!confirm('Er du sikker på at du vil slette dette bildet?')) return;

    setDeleting(imageName);
    try {
      const { error } = await supabase.storage
        .from('email-assets')
        .remove([`email-images/${imageName}`]);

      if (error) throw error;

      toast.success('Bilde slettet');
      setImages(prev => prev.filter(img => img.name !== imageName));
      if (selectedImage && selectedImage.includes(imageName)) {
        setSelectedImage(null);
      }
    } catch (error) {
      console.error('Delete error:', error);
      toast.error('Kunne ikke slette bilde');
    } finally {
      setDeleting(null);
    }
  };

  // Confirm selection
  const handleConfirm = () => {
    if (selectedImage) {
      onSelectImage(selectedImage, `${imageWidth}%`);
      onOpenChange(false);
    }
  };

  // Filter images by search term
  const filteredImages = images.filter(img => 
    img.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl h-[80vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Grid3X3 className="h-5 w-5" />
            Bildegalleri
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="gallery" className="flex-1 flex flex-col min-h-0">
          <TabsList className="w-full">
            <TabsTrigger value="gallery" className="flex-1">Galleri</TabsTrigger>
            <TabsTrigger value="upload" className="flex-1">Last opp</TabsTrigger>
          </TabsList>

          <TabsContent value="gallery" className="flex-1 flex flex-col min-h-0 mt-4">
            {/* Search */}
            <div className="relative mb-4">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Søk etter bilder..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>

            {loading ? (
              <div className="flex-1 flex items-center justify-center">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : filteredImages.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground">
                <ImageIcon className="h-12 w-12 mb-4" />
                <p>Ingen bilder funnet</p>
                <p className="text-sm">Last opp bilder i "Last opp"-fanen</p>
              </div>
            ) : (
              <ScrollArea className="flex-1">
                <div className="grid grid-cols-3 md:grid-cols-4 gap-4 p-1">
                  {filteredImages.map((image) => (
                    <div
                      key={image.name}
                      className={`
                        relative group rounded-lg overflow-hidden border-2 cursor-pointer
                        transition-all hover:shadow-lg
                        ${selectedImage === image.url 
                          ? 'border-primary ring-2 ring-primary/20' 
                          : 'border-border hover:border-primary/50'
                        }
                      `}
                      onClick={() => setSelectedImage(image.url)}
                    >
                      <div className="aspect-square bg-muted">
                        <img
                          src={image.url}
                          alt={image.name}
                          className="w-full h-full object-contain"
                        />
                      </div>
                      
                      {/* Selection indicator */}
                      {selectedImage === image.url && (
                        <div className="absolute top-2 right-2 bg-primary text-primary-foreground rounded-full p-1">
                          <Check className="h-3 w-3" />
                        </div>
                      )}

                      {/* Delete button */}
                      <Button
                        variant="destructive"
                        size="icon"
                        className="absolute bottom-2 right-2 h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDelete(image.name);
                        }}
                        disabled={deleting === image.name}
                      >
                        {deleting === image.name ? (
                          <Loader2 className="h-3 w-3 animate-spin" />
                        ) : (
                          <Trash2 className="h-3 w-3" />
                        )}
                      </Button>

                      {/* Image name */}
                      <div className="absolute bottom-0 left-0 right-0 bg-black/60 px-2 py-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <p className="text-xs text-white truncate">{image.name}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            )}

            {/* Size control and confirm */}
            {selectedImage && (
              <div className="border-t pt-4 mt-4 space-y-4">
                <div className="flex items-center gap-4">
                  <div className="flex-1">
                    <Label className="text-sm">Bildestørrelse: {imageWidth}%</Label>
                    <Slider
                      value={[imageWidth]}
                      onValueChange={([v]) => setImageWidth(v)}
                      min={25}
                      max={100}
                      step={5}
                      className="mt-2"
                    />
                    <div className="flex justify-between text-xs text-muted-foreground mt-1">
                      <span>25%</span>
                      <span>50%</span>
                      <span>75%</span>
                      <span>100%</span>
                    </div>
                  </div>
                  <div className="w-24 h-16 bg-muted rounded border flex items-center justify-center overflow-hidden">
                    <img 
                      src={selectedImage} 
                      alt="Preview" 
                      className="object-contain"
                      style={{ maxWidth: `${imageWidth}%`, maxHeight: '100%' }}
                    />
                  </div>
                </div>
                <Button onClick={handleConfirm} className="w-full">
                  <Check className="h-4 w-4 mr-2" />
                  Bruk valgt bilde
                </Button>
              </div>
            )}
          </TabsContent>

          <TabsContent value="upload" className="flex-1 flex flex-col mt-4">
            <div className="flex-1 flex flex-col items-center justify-center border-2 border-dashed rounded-lg p-8">
              <ImageIcon className="h-16 w-16 text-muted-foreground mb-4" />
              <h3 className="text-lg font-medium mb-2">Last opp nytt bilde</h3>
              <p className="text-sm text-muted-foreground mb-4 text-center">
                Dra og slipp eller klikk for å velge<br />
                Maks 5MB • JPG, PNG, GIF, WebP, SVG
              </p>
              <Button 
                variant="outline" 
                disabled={uploading}
                onClick={() => document.getElementById('gallery-upload')?.click()}
              >
                {uploading ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Laster opp...
                  </>
                ) : (
                  <>
                    <Upload className="h-4 w-4 mr-2" />
                    Velg fil
                  </>
                )}
              </Button>
              <input
                id="gallery-upload"
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleUpload}
              />
            </div>

            {/* Recent uploads preview */}
            {images.length > 0 && (
              <div className="mt-4">
                <Label className="text-sm text-muted-foreground">Siste opplastinger</Label>
                <div className="flex gap-2 mt-2 overflow-x-auto pb-2">
                  {images.slice(0, 6).map(img => (
                    <div 
                      key={img.name}
                      className="w-16 h-16 rounded border bg-muted flex-shrink-0 overflow-hidden cursor-pointer hover:ring-2 ring-primary transition-all"
                      onClick={() => {
                        setSelectedImage(img.url);
                      }}
                    >
                      <img src={img.url} alt={img.name} className="w-full h-full object-contain" />
                    </div>
                  ))}
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
