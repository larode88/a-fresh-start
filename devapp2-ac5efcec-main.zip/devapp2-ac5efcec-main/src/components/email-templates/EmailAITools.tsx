import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu";
import { Loader2, Sparkles, RefreshCw, Minimize2, Maximize2, Image } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface EmailAIToolsProps {
  content: string;
  onContentUpdate: (newContent: string) => void;
  imageUrl?: string;
  onAltTextGenerated?: (altText: string) => void;
  disabled?: boolean;
}

type AIAction = 'rewrite' | 'shorten' | 'expand' | 'alt-text';

export default function EmailAITools({
  content,
  onContentUpdate,
  imageUrl,
  onAltTextGenerated,
  disabled = false,
}: EmailAIToolsProps) {
  const [loading, setLoading] = useState<AIAction | null>(null);

  const handleAIAction = async (action: AIAction) => {
    if (action !== 'alt-text' && !content?.trim()) {
      toast.error("Ingen tekst å bearbeide");
      return;
    }

    if (action === 'alt-text' && !imageUrl && !onAltTextGenerated) {
      toast.error("Ingen bilde-URL tilgjengelig");
      return;
    }

    setLoading(action);

    try {
      const { data, error } = await supabase.functions.invoke('email-ai-assistant', {
        body: {
          action,
          content: action === 'alt-text' ? undefined : content,
          imageUrl: action === 'alt-text' ? imageUrl : undefined,
        },
      });

      if (error) throw error;

      if (data?.error) {
        throw new Error(data.error);
      }

      const result = data?.result;
      
      if (action === 'alt-text') {
        onAltTextGenerated?.(result);
        toast.success("Alt-tekst generert");
      } else {
        onContentUpdate(result);
        toast.success(
          action === 'rewrite' ? "Tekst omskrevet" :
          action === 'shorten' ? "Tekst forkortet" :
          "Tekst utvidet"
        );
      }
    } catch (error) {
      console.error('AI action error:', error);
      toast.error(error instanceof Error ? error.message : 'AI-feil oppstod');
    } finally {
      setLoading(null);
    }
  };

  const isLoading = loading !== null;

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="outline"
          size="sm"
          disabled={disabled || isLoading}
          className="gap-2"
        >
          {isLoading ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Sparkles className="h-4 w-4" />
          )}
          AI
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-48">
        <DropdownMenuLabel className="text-xs text-muted-foreground">
          Tekst-verktøy
        </DropdownMenuLabel>
        <DropdownMenuItem
          onClick={() => handleAIAction('rewrite')}
          disabled={isLoading || !content?.trim()}
          className="gap-2"
        >
          <RefreshCw className="h-4 w-4" />
          <span>Skriv om</span>
          {loading === 'rewrite' && <Loader2 className="h-3 w-3 ml-auto animate-spin" />}
        </DropdownMenuItem>
        <DropdownMenuItem
          onClick={() => handleAIAction('shorten')}
          disabled={isLoading || !content?.trim()}
          className="gap-2"
        >
          <Minimize2 className="h-4 w-4" />
          <span>Forkort</span>
          {loading === 'shorten' && <Loader2 className="h-3 w-3 ml-auto animate-spin" />}
        </DropdownMenuItem>
        <DropdownMenuItem
          onClick={() => handleAIAction('expand')}
          disabled={isLoading || !content?.trim()}
          className="gap-2"
        >
          <Maximize2 className="h-4 w-4" />
          <span>Utvid</span>
          {loading === 'expand' && <Loader2 className="h-3 w-3 ml-auto animate-spin" />}
        </DropdownMenuItem>
        
        {onAltTextGenerated && (
          <>
            <DropdownMenuSeparator />
            <DropdownMenuLabel className="text-xs text-muted-foreground">
              Bilde-verktøy
            </DropdownMenuLabel>
            <DropdownMenuItem
              onClick={() => handleAIAction('alt-text')}
              disabled={isLoading}
              className="gap-2"
            >
              <Image className="h-4 w-4" />
              <span>Generer alt-tekst</span>
              {loading === 'alt-text' && <Loader2 className="h-3 w-3 ml-auto animate-spin" />}
            </DropdownMenuItem>
          </>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
