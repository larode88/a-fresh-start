// EmailModuleEditor component for editing email template modules
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, AlignLeft, AlignCenter, AlignRight, Upload, ImageIcon, Grid3X3 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import type { EmailModule } from "@/lib/emailHtmlGenerator";
import EmailImageGallery from "./EmailImageGallery";
import EmailAITools from "./EmailAITools";

interface EmailModuleEditorProps {
  module: EmailModule;
  onUpdate: (updates: Partial<EmailModule>) => void;
}

// Token/variable picker
const AVAILABLE_TOKENS = [
  { token: "{fornavn}", label: "Fornavn" },
  { token: "{navn}", label: "Fullt navn" },
  { token: "{salongnavn}", label: "Salongnavn" },
  { token: "{org_nummer}", label: "Org. nummer" },
  { token: "{dato}", label: "Dagens dato" },
  { token: "{premie}", label: "Premie" },
  { token: "{avtalenummer}", label: "Avtalenummer" },
  { token: "{link}", label: "Lenke" },
  { token: "{distriktsleder}", label: "Distriktsleder" },
  { token: "{otp_code}", label: "Engangskode" },
  { token: "{oppstartsdato}", label: "Oppstartsdato" },
  { token: "{kontaktperson}", label: "Kontaktperson" },
  { token: "{epost}", label: "E-post" },
  { token: "{telefon}", label: "Telefon" },
];

export default function EmailModuleEditor({ module, onUpdate }: EmailModuleEditorProps) {
  const { type, content, styles = {} } = module;
  const [uploading, setUploading] = useState(false);
  const [galleryOpen, setGalleryOpen] = useState(false);
  const [galleryField, setGalleryField] = useState<string>("logoUrl");

  const updateContent = (key: string, value: any) => {
    onUpdate({
      content: { ...content, [key]: value },
    });
  };

  const updateStyles = (key: string, value: any) => {
    onUpdate({
      styles: { ...styles, [key]: value },
    });
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>, field: string) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.error('Vennligst velg en bildefil');
      return;
    }

    setUploading(true);
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;
      const filePath = `email-images/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('email-assets')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('email-assets')
        .getPublicUrl(filePath);

      updateContent(field, publicUrl);
      toast.success('Bilde lastet opp');
    } catch (error: any) {
      console.error('Upload error:', error);
      toast.error('Kunne ikke laste opp bilde');
    } finally {
      setUploading(false);
    }
  };

  const renderContentEditor = () => {
    switch (type) {
      case "header-logo":
      case "header-portalen":
        return (
          <div className="space-y-4">
            <div>
              <Label>Logo</Label>
              <div className="mt-2 space-y-2">
                {content.logoUrl && (
                  <div className="p-4 bg-muted rounded-lg text-center">
                    <img 
                      src={content.logoUrl} 
                      alt="Logo preview" 
                      className="max-h-16 mx-auto"
                    />
                  </div>
                )}
                <div className="flex gap-2">
                  <Input
                    value={content.logoUrl || ""}
                    onChange={(e) => updateContent("logoUrl", e.target.value)}
                    placeholder="https://..."
                    className="flex-1"
                  />
                  <Button 
                    variant="outline" 
                    size="icon"
                    title="Åpne bildegalleri"
                    onClick={() => {
                      setGalleryField("logoUrl");
                      setGalleryOpen(true);
                    }}
                  >
                    <Grid3X3 className="h-4 w-4" />
                  </Button>
                  <Button 
                    variant="outline" 
                    size="icon"
                    disabled={uploading}
                    title="Last opp bilde"
                    onClick={() => document.getElementById(`logo-upload-${module.id}`)?.click()}
                  >
                    <Upload className="h-4 w-4" />
                  </Button>
                  <input
                    id={`logo-upload-${module.id}`}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => handleImageUpload(e, 'logoUrl')}
                  />
                </div>
              </div>
            </div>
            <div>
              <Label>Alt-tekst</Label>
              <Input
                value={content.logoAlt || ""}
                onChange={(e) => updateContent("logoAlt", e.target.value)}
                placeholder="Hår1 logo"
              />
            </div>
            <div>
              <Label>Bakgrunnsfarge</Label>
              <div className="flex gap-2">
                <Input
                  type="color"
                  value={content.backgroundColor || "#FAF8F5"}
                  onChange={(e) => updateContent("backgroundColor", e.target.value)}
                  className="w-12 h-10 p-1"
                />
                <Input
                  value={content.backgroundColor || "#FAF8F5"}
                  onChange={(e) => updateContent("backgroundColor", e.target.value)}
                  className="flex-1"
                />
              </div>
            </div>
          </div>
        );

      case "heading":
        return (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label>Tekst</Label>
              <EmailAITools
                content={content.text || ""}
                onContentUpdate={(newContent) => updateContent("text", newContent)}
              />
            </div>
            <Input
              value={content.text || ""}
              onChange={(e) => updateContent("text", e.target.value)}
              placeholder="Overskrift"
            />
            <div>
              <Label>Størrelse</Label>
              <Select
                value={content.level || "h2"}
                onValueChange={(v) => updateContent("level", v)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="h1">Stor (H1)</SelectItem>
                  <SelectItem value="h2">Medium (H2)</SelectItem>
                  <SelectItem value="h3">Liten (H3)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Farge</Label>
              <div className="flex gap-2">
                <Input
                  type="color"
                  value={styles.color || "#8B7355"}
                  onChange={(e) => updateStyles("color", e.target.value)}
                  className="w-12 h-10 p-1"
                />
                <Input
                  value={styles.color || "#8B7355"}
                  onChange={(e) => updateStyles("color", e.target.value)}
                  className="flex-1"
                />
              </div>
            </div>
          </div>
        );

      case "text":
        return (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <Label>Innhold</Label>
              <EmailAITools
                content={content.content || content.text || ""}
                onContentUpdate={(newContent) => updateContent("content", newContent)}
              />
            </div>
            <p className="text-xs text-muted-foreground">
              Bruk editoren i canvas for å redigere tekst
            </p>
            <Separator />
            <div>
              <Label className="text-xs text-muted-foreground">Tilgjengelige variabler</Label>
              <div className="flex flex-wrap gap-1 mt-2">
                {AVAILABLE_TOKENS.map(({ token, label }) => (
                  <Button
                    key={token}
                    variant="outline"
                    size="sm"
                    className="text-xs h-7"
                    onClick={() => {
                      const newContent = (content.content || "") + token;
                      updateContent("content", newContent);
                    }}
                  >
                    {label}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        );

      case "cta-button":
        return (
          <div className="space-y-4">
            <div>
              <Label>Knappetekst</Label>
              <Input
                value={content.text || ""}
                onChange={(e) => updateContent("text", e.target.value)}
                placeholder="Klikk her"
              />
            </div>
            <div>
              <Label>URL</Label>
              <Input
                value={content.url || ""}
                onChange={(e) => updateContent("url", e.target.value)}
                placeholder="https://..."
              />
              <p className="text-xs text-muted-foreground mt-1">
                Bruk {"{link}"} for dynamisk lenke
              </p>
            </div>
          </div>
        );

      case "info-box":
        return (
          <div className="space-y-4">
            <div>
              <Label>Tittel</Label>
              <Input
                value={content.title || ""}
                onChange={(e) => updateContent("title", e.target.value)}
                placeholder="Viktig informasjon"
              />
            </div>
            <div>
              <Label>Innhold</Label>
              <p className="text-xs text-muted-foreground">
                Bruk editoren i canvas
              </p>
            </div>
          </div>
        );

      case "success-banner":
        return (
          <div className="space-y-4">
            <div>
              <Label>Emoji</Label>
              <Input
                value={content.emoji || "🎉"}
                onChange={(e) => updateContent("emoji", e.target.value)}
                placeholder="🎉"
              />
            </div>
            <div>
              <Label>Tekst</Label>
              <Input
                value={content.text || ""}
                onChange={(e) => updateContent("text", e.target.value)}
                placeholder="Vellykket!"
              />
            </div>
          </div>
        );

      case "warning-banner":
        return (
          <div className="space-y-4">
            <div>
              <Label>Tekst</Label>
              <Input
                value={content.text || ""}
                onChange={(e) => updateContent("text", e.target.value)}
                placeholder="Obs!"
              />
            </div>
          </div>
        );

      case "benefits-list":
        const items = content.items || [];
        return (
          <div className="space-y-4">
            <div>
              <Label>Tittel</Label>
              <Input
                value={content.title || ""}
                onChange={(e) => updateContent("title", e.target.value)}
                placeholder="Forsikringen din dekker blant annet:"
              />
            </div>
            <Separator />
            <div>
              <Label>Fordeler</Label>
              <div className="space-y-2 mt-2">
                {items.map((item: string, index: number) => (
                  <div key={index} className="flex gap-2">
                    <Input
                      value={item}
                      onChange={(e) => {
                        const newItems = [...items];
                        newItems[index] = e.target.value;
                        updateContent("items", newItems);
                      }}
                    />
                    <Button
                      variant="ghost"
                      size="icon"
                      className="shrink-0"
                      onClick={() => {
                        const newItems = items.filter((_: string, i: number) => i !== index);
                        updateContent("items", newItems);
                      }}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full"
                  onClick={() => updateContent("items", [...items, "Ny fordel"])}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Legg til fordel
                </Button>
              </div>
            </div>
          </div>
        );

      case "icon-list":
        const iconItems = content.items || [];
        return (
          <div className="space-y-4">
            <div>
              <Label>Ikon</Label>
              <Select
                value={content.icon || "check"}
                onValueChange={(v) => updateContent("icon", v)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="check">✓ Checkmark</SelectItem>
                  <SelectItem value="star">★ Stjerne</SelectItem>
                  <SelectItem value="arrow">→ Pil</SelectItem>
                  <SelectItem value="bullet">• Punkt</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Separator />
            <div>
              <Label>Elementer</Label>
              <div className="space-y-2 mt-2">
                {iconItems.map((item: string, index: number) => (
                  <div key={index} className="flex gap-2">
                    <Input
                      value={item}
                      onChange={(e) => {
                        const newItems = [...iconItems];
                        newItems[index] = e.target.value;
                        updateContent("items", newItems);
                      }}
                    />
                    <Button
                      variant="ghost"
                      size="icon"
                      className="shrink-0"
                      onClick={() => {
                        const newItems = iconItems.filter((_: string, i: number) => i !== index);
                        updateContent("items", newItems);
                      }}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full"
                  onClick={() => updateContent("items", [...iconItems, "Nytt element"])}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Legg til element
                </Button>
              </div>
            </div>
          </div>
        );

      case "footer-signature":
        return (
          <div className="space-y-4">
            <div>
              <Label>Signatur (HTML)</Label>
              <Textarea
                value={content.signature || ""}
                onChange={(e) => updateContent("signature", e.target.value)}
                placeholder="Med vennlig hilsen,<br><strong>Hår1-teamet</strong>"
                rows={3}
              />
            </div>
            <Separator />
            <div>
              <Label>Kontaktinfo</Label>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Telefon</Label>
              <Input
                value={content.contact?.phone || ""}
                onChange={(e) => updateContent("contact", { ...content.contact, phone: e.target.value })}
                placeholder="22 00 81 00"
              />
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">E-post</Label>
              <Input
                value={content.contact?.email || ""}
                onChange={(e) => updateContent("contact", { ...content.contact, email: e.target.value })}
                placeholder="forsikring@har1.no"
              />
            </div>
            <div>
              <Label className="text-xs text-muted-foreground">Nettside</Label>
              <Input
                value={content.contact?.website || ""}
                onChange={(e) => updateContent("contact", { ...content.contact, website: e.target.value })}
                placeholder="www.har1.no"
              />
            </div>
          </div>
        );

      case "footer-disclaimer":
        return (
          <div className="space-y-4">
            <div>
              <Label>Disclaimer-tekst</Label>
              <Textarea
                value={content.text || ""}
                onChange={(e) => updateContent("text", e.target.value)}
                rows={3}
              />
            </div>
          </div>
        );

      case "separator":
      case "divider":
        return (
          <div className="space-y-4">
            <div>
              <Label>Stil</Label>
              <Select
                value={content.style || "solid"}
                onValueChange={(v) => updateContent("style", v)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="solid">Heltrukket</SelectItem>
                  <SelectItem value="dashed">Stiplet</SelectItem>
                  <SelectItem value="dotted">Prikket</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Farge</Label>
              <div className="flex gap-2">
                <Input
                  type="color"
                  value={content.color || "#E8E0D5"}
                  onChange={(e) => updateContent("color", e.target.value)}
                  className="w-12 h-10 p-1"
                />
                <Input
                  value={content.color || "#E8E0D5"}
                  onChange={(e) => updateContent("color", e.target.value)}
                  className="flex-1"
                />
              </div>
            </div>
          </div>
        );

      case "spacer":
        const spacerPresets = { S: "16", M: "32", L: "48" };
        const currentHeight = parseInt(content.height) || 24;
        const currentPreset = Object.entries(spacerPresets).find(([_, v]) => parseInt(v) === currentHeight)?.[0] || null;
        return (
          <div className="space-y-4">
            <div>
              <Label>Høyde</Label>
              <div className="flex gap-2 mt-2">
                {Object.entries(spacerPresets).map(([size, px]) => (
                  <Button
                    key={size}
                    variant={currentPreset === size ? "default" : "outline"}
                    size="sm"
                    className="flex-1"
                    onClick={() => updateContent("height", `${px}px`)}
                  >
                    {size} ({px}px)
                  </Button>
                ))}
              </div>
            </div>
          </div>
        );

      case "image":
        return (
          <div className="space-y-4">
            <div>
              <Label>Bilde</Label>
              <div className="mt-2 space-y-2">
                {content.src ? (
                  <div className="p-4 bg-muted rounded-lg text-center">
                    <img 
                      src={content.src} 
                      alt={content.alt || "Preview"} 
                      className="max-h-32 mx-auto rounded"
                      style={{ maxWidth: content.width || '100%' }}
                    />
                  </div>
                ) : (
                  <div className="p-8 bg-muted rounded-lg text-center border-2 border-dashed">
                    <ImageIcon className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
                    <p className="text-sm text-muted-foreground">Ingen bilde valgt</p>
                  </div>
                )}
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    className="flex-1"
                    onClick={() => {
                      setGalleryField("src");
                      setGalleryOpen(true);
                    }}
                  >
                    <Grid3X3 className="h-4 w-4 mr-2" />
                    Velg fra galleri
                  </Button>
                  <Button 
                    variant="outline" 
                    size="icon"
                    disabled={uploading}
                    title="Last opp nytt bilde"
                    onClick={() => document.getElementById(`image-upload-${module.id}`)?.click()}
                  >
                    <Upload className="h-4 w-4" />
                  </Button>
                  <input
                    id={`image-upload-${module.id}`}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => handleImageUpload(e, 'src')}
                  />
                </div>
                {content.src && (
                  <Input
                    value={content.src || ""}
                    onChange={(e) => updateContent("src", e.target.value)}
                    placeholder="https://..."
                    className="text-xs"
                  />
                )}
              </div>
            </div>
            <div>
              <Label>Alt-tekst</Label>
              <Input
                value={content.alt || ""}
                onChange={(e) => updateContent("alt", e.target.value)}
                placeholder="Beskrivelse av bildet"
              />
            </div>
            <div>
              <Label>Bredde: {content.width || "100%"}</Label>
              <Slider
                value={[parseInt(content.width) || 100]}
                onValueChange={([v]) => updateContent("width", `${v}%`)}
                min={25}
                max={100}
                step={5}
                className="mt-2"
              />
              <div className="flex justify-between text-xs text-muted-foreground mt-1">
                <span>25%</span>
                <span>50%</span>
                <span>75%</span>
                <span>100%</span>
              </div>
            </div>
          </div>
        );

      case "otp-box":
        return (
          <div className="space-y-4">
            <div>
              <Label>Label</Label>
              <Input
                value={content.label || ""}
                onChange={(e) => updateContent("label", e.target.value)}
                placeholder="Din engangskode"
              />
            </div>
            <div>
              <Label>Kode (variabel)</Label>
              <Input
                value={content.code || "{otp_code}"}
                onChange={(e) => updateContent("code", e.target.value)}
              />
              <p className="text-xs text-muted-foreground mt-1">
                Bruk {"{otp_code}"} for dynamisk kode
              </p>
            </div>
            <div>
              <Label>Utløper (minutter)</Label>
              <Input
                type="number"
                value={content.expiryMinutes || 10}
                onChange={(e) => updateContent("expiryMinutes", parseInt(e.target.value))}
              />
            </div>
          </div>
        );

      case "agreement-box":
        return (
          <div className="space-y-4">
            <div>
              <Label>Label (overskrift)</Label>
              <Input
                value={content.label || ""}
                onChange={(e) => updateContent("label", e.target.value)}
                placeholder="DITT AVTALENUMMER (BRUK VED REGISTRERING)"
              />
            </div>
            <div>
              <Label>Avtalenummer (variabel)</Label>
              <Input
                value={content.value || "{avtalenummer}"}
                onChange={(e) => updateContent("value", e.target.value)}
              />
              <p className="text-xs text-muted-foreground mt-1">
                Bruk {"{avtalenummer}"} for dynamisk verdi
              </p>
            </div>
          </div>
        );

      case "date-highlight":
        return (
          <div className="space-y-4">
            <div>
              <Label>Label (overskrift)</Label>
              <Input
                value={content.label || ""}
                onChange={(e) => updateContent("label", e.target.value)}
                placeholder="Oppstart for forsikringen"
              />
            </div>
            <div>
              <Label>Dato</Label>
              <Input
                value={content.date || ""}
                onChange={(e) => updateContent("date", e.target.value)}
                placeholder="10. januar 2024"
              />
              <p className="text-xs text-muted-foreground mt-1">
                Bruk {"{oppstartsdato}"} for dynamisk dato
              </p>
            </div>
          </div>
        );

      case "contact-box":
        return (
          <div className="space-y-4">
            <div>
              <Label>Tittel</Label>
              <Input
                value={content.title || ""}
                onChange={(e) => updateContent("title", e.target.value)}
                placeholder="Spørsmål om helseforsikringen?"
              />
            </div>
            <div>
              <Label>Beskrivelse</Label>
              <Input
                value={content.description || ""}
                onChange={(e) => updateContent("description", e.target.value)}
                placeholder="Kontakt ERGO på"
              />
            </div>
            <div>
              <Label>Telefon</Label>
              <Input
                value={content.phone || ""}
                onChange={(e) => updateContent("phone", e.target.value)}
                placeholder="800 83 313"
              />
            </div>
            <div>
              <Label>E-post</Label>
              <Input
                value={content.email || ""}
                onChange={(e) => updateContent("email", e.target.value)}
                placeholder="infohelse@ergo.no"
              />
            </div>
          </div>
        );

      case "note-box":
        return (
          <div className="space-y-4">
            <div>
              <Label>Ikon</Label>
              <Input
                value={content.icon || "💬"}
                onChange={(e) => updateContent("icon", e.target.value)}
                placeholder="💬"
              />
            </div>
            <div>
              <Label>Tittel</Label>
              <Input
                value={content.title || ""}
                onChange={(e) => updateContent("title", e.target.value)}
                placeholder="Merk"
              />
            </div>
            <div>
              <Label>Innhold</Label>
              <Textarea
                value={content.content || ""}
                onChange={(e) => updateContent("content", e.target.value)}
                placeholder="Viktig informasjon..."
                rows={3}
              />
            </div>
          </div>
        );

      case "quote-box":
        return (
          <div className="space-y-4">
            <div>
              <Label>Sitat</Label>
              <Textarea
                value={content.text || ""}
                onChange={(e) => updateContent("text", e.target.value)}
                placeholder="Viktig melding..."
                rows={3}
              />
            </div>
            <div>
              <Label>Forfatter (valgfritt)</Label>
              <Input
                value={content.author || ""}
                onChange={(e) => updateContent("author", e.target.value)}
                placeholder="Navn"
              />
            </div>
          </div>
        );

      case "salon-info":
        return (
          <div className="space-y-4">
            <p className="text-xs text-muted-foreground">
              Denne modulen viser salonginfo automatisk basert på tokens.
            </p>
            <Separator />
            <div>
              <Label className="text-xs text-muted-foreground">Tilgjengelige tokens</Label>
              <div className="flex flex-wrap gap-1 mt-2">
                {["{salongnavn}", "{org_nummer}", "{kontaktperson}", "{epost}", "{telefon}"].map((token) => (
                  <Button
                    key={token}
                    variant="outline"
                    size="sm"
                    className="text-xs h-7"
                    disabled
                  >
                    {token}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        );

      // Layout modules
      case "image-text-left":
      case "image-text-right":
        return (
          <div className="space-y-4">
            <div>
              <Label>Bilde</Label>
              <div className="mt-2 space-y-2">
                {content.imageUrl && (
                  <div className="p-4 bg-muted rounded-lg text-center">
                    <img src={content.imageUrl} alt="Preview" className="max-h-24 mx-auto rounded" />
                  </div>
                )}
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    className="flex-1"
                    onClick={() => { setGalleryField("imageUrl"); setGalleryOpen(true); }}
                  >
                    <Grid3X3 className="h-4 w-4 mr-2" />
                    Velg fra galleri
                  </Button>
                  <Button 
                    variant="outline" 
                    size="icon"
                    disabled={uploading}
                    onClick={() => document.getElementById(`img-upload-${module.id}`)?.click()}
                  >
                    <Upload className="h-4 w-4" />
                  </Button>
                  <input
                    id={`img-upload-${module.id}`}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => handleImageUpload(e, 'imageUrl')}
                  />
                </div>
              </div>
            </div>
            <div>
              <Label>Tittel</Label>
              <Input
                value={content.title || ""}
                onChange={(e) => updateContent("title", e.target.value)}
                placeholder="Overskrift"
              />
            </div>
            <div>
              <Label>Tekst</Label>
              <Textarea
                value={content.text || ""}
                onChange={(e) => updateContent("text", e.target.value)}
                placeholder="Beskrivelse..."
                rows={3}
              />
            </div>
            <div>
              <Label>Knappetekst (valgfritt)</Label>
              <Input
                value={content.buttonText || ""}
                onChange={(e) => updateContent("buttonText", e.target.value)}
                placeholder="Les mer"
              />
            </div>
            <div>
              <Label>Knapp-URL</Label>
              <Input
                value={content.buttonUrl || ""}
                onChange={(e) => updateContent("buttonUrl", e.target.value)}
                placeholder="https://..."
              />
            </div>
          </div>
        );

      case "gallery-grid":
        const galleryImages = content.images || [];
        return (
          <div className="space-y-4">
            <div>
              <Label>Kolonner</Label>
              <div className="flex gap-2 mt-2">
                {[2, 3, 4].map((cols) => (
                  <Button
                    key={cols}
                    variant={content.columns === cols ? "default" : "outline"}
                    size="sm"
                    onClick={() => updateContent("columns", cols)}
                  >
                    {cols}
                  </Button>
                ))}
              </div>
            </div>
            <Separator />
            <div>
              <Label>Bilder ({galleryImages.length})</Label>
              <div className="space-y-2 mt-2">
                {galleryImages.map((img: string, index: number) => (
                  <div key={index} className="flex gap-2 items-center">
                    <img src={img} alt="" className="w-12 h-12 object-cover rounded" />
                    <Input
                      value={img}
                      onChange={(e) => {
                        const newImages = [...galleryImages];
                        newImages[index] = e.target.value;
                        updateContent("images", newImages);
                      }}
                      className="flex-1"
                    />
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => {
                        const newImages = galleryImages.filter((_: string, i: number) => i !== index);
                        updateContent("images", newImages);
                      }}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full"
                  onClick={() => {
                    setGalleryField(`images.${galleryImages.length}`);
                    setGalleryOpen(true);
                  }}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Legg til bilde
                </Button>
              </div>
            </div>
          </div>
        );

      case "section-container":
        const sectionPaddingPresets = { S: "16px", M: "24px", L: "32px" };
        return (
          <div className="space-y-4">
            <div>
              <Label>Bakgrunnsfarge</Label>
              <div className="flex gap-2">
                <Input
                  type="color"
                  value={content.backgroundColor || "#FFFFFF"}
                  onChange={(e) => updateContent("backgroundColor", e.target.value)}
                  className="w-12 h-10 p-1"
                />
                <Input
                  value={content.backgroundColor || "#FFFFFF"}
                  onChange={(e) => updateContent("backgroundColor", e.target.value)}
                  className="flex-1"
                />
              </div>
            </div>
            <div>
              <Label>Padding</Label>
              <div className="flex gap-2 mt-2">
                {Object.entries(sectionPaddingPresets).map(([size, value]) => (
                  <Button
                    key={size}
                    variant={content.padding === value ? "default" : "outline"}
                    size="sm"
                    className="flex-1"
                    onClick={() => updateContent("padding", value)}
                  >
                    {size}
                  </Button>
                ))}
              </div>
            </div>
            <div>
              <Label>Avrundede hjørner</Label>
              <div className="flex gap-2 mt-2">
                {["0", "8px", "16px"].map((radius) => (
                  <Button
                    key={radius}
                    variant={content.borderRadius === radius ? "default" : "outline"}
                    size="sm"
                    onClick={() => updateContent("borderRadius", radius)}
                  >
                    {radius === "0" ? "Ingen" : radius}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        );

      // Business modules
      case "cta-section":
        return (
          <div className="space-y-4">
            <div>
              <Label>Tittel</Label>
              <Input
                value={content.title || ""}
                onChange={(e) => updateContent("title", e.target.value)}
                placeholder="Klar til å komme i gang?"
              />
            </div>
            <div>
              <Label>Beskrivelse</Label>
              <Textarea
                value={content.description || ""}
                onChange={(e) => updateContent("description", e.target.value)}
                placeholder="En kort beskrivelse..."
                rows={2}
              />
            </div>
            <div>
              <Label>Knappetekst</Label>
              <Input
                value={content.buttonText || ""}
                onChange={(e) => updateContent("buttonText", e.target.value)}
                placeholder="Kom i gang"
              />
            </div>
            <div>
              <Label>Knapp-URL</Label>
              <Input
                value={content.buttonUrl || ""}
                onChange={(e) => updateContent("buttonUrl", e.target.value)}
                placeholder="https://..."
              />
            </div>
            <div>
              <Label>Bakgrunnsfarge</Label>
              <div className="flex gap-2">
                <Input
                  type="color"
                  value={content.backgroundColor || "#FAF8F5"}
                  onChange={(e) => updateContent("backgroundColor", e.target.value)}
                  className="w-12 h-10 p-1"
                />
                <Input
                  value={content.backgroundColor || "#FAF8F5"}
                  onChange={(e) => updateContent("backgroundColor", e.target.value)}
                  className="flex-1"
                />
              </div>
            </div>
          </div>
        );

      case "product-card":
        return (
          <div className="space-y-4">
            <div>
              <Label>Produktbilde</Label>
              <div className="mt-2 space-y-2">
                {content.imageUrl && (
                  <div className="p-4 bg-muted rounded-lg text-center">
                    <img src={content.imageUrl} alt="Preview" className="max-h-24 mx-auto rounded" />
                  </div>
                )}
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    className="flex-1"
                    onClick={() => { setGalleryField("imageUrl"); setGalleryOpen(true); }}
                  >
                    <Grid3X3 className="h-4 w-4 mr-2" />
                    Velg fra galleri
                  </Button>
                  <Button 
                    variant="outline" 
                    size="icon"
                    disabled={uploading}
                    onClick={() => document.getElementById(`product-upload-${module.id}`)?.click()}
                  >
                    <Upload className="h-4 w-4" />
                  </Button>
                  <input
                    id={`product-upload-${module.id}`}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => handleImageUpload(e, 'imageUrl')}
                  />
                </div>
              </div>
            </div>
            <div>
              <Label>Produktnavn</Label>
              <Input
                value={content.name || ""}
                onChange={(e) => updateContent("name", e.target.value)}
                placeholder="Produktnavn"
              />
            </div>
            <div>
              <Label>Beskrivelse</Label>
              <Textarea
                value={content.description || ""}
                onChange={(e) => updateContent("description", e.target.value)}
                placeholder="Kort beskrivelse..."
                rows={2}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Originalpris</Label>
                <Input
                  value={content.originalPrice || ""}
                  onChange={(e) => updateContent("originalPrice", e.target.value)}
                  placeholder="kr 599"
                />
              </div>
              <div>
                <Label>Kampanjepris</Label>
                <Input
                  value={content.salePrice || ""}
                  onChange={(e) => updateContent("salePrice", e.target.value)}
                  placeholder="kr 399"
                />
              </div>
            </div>
            <div>
              <Label>Knappetekst</Label>
              <Input
                value={content.buttonText || ""}
                onChange={(e) => updateContent("buttonText", e.target.value)}
                placeholder="Kjøp nå"
              />
            </div>
            <div>
              <Label>Knapp-URL</Label>
              <Input
                value={content.buttonUrl || ""}
                onChange={(e) => updateContent("buttonUrl", e.target.value)}
                placeholder="https://..."
              />
            </div>
          </div>
        );

      case "footer-social":
        return (
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Legg til lenker til sosiale medier
            </p>
            <div>
              <Label>Facebook</Label>
              <Input
                value={content.facebook || ""}
                onChange={(e) => updateContent("facebook", e.target.value)}
                placeholder="https://facebook.com/..."
              />
            </div>
            <div>
              <Label>Instagram</Label>
              <Input
                value={content.instagram || ""}
                onChange={(e) => updateContent("instagram", e.target.value)}
                placeholder="https://instagram.com/..."
              />
            </div>
            <div>
              <Label>LinkedIn</Label>
              <Input
                value={content.linkedin || ""}
                onChange={(e) => updateContent("linkedin", e.target.value)}
                placeholder="https://linkedin.com/..."
              />
            </div>
          </div>
        );

      case "footer-unsubscribe":
        return (
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Lovpålagt footer med avmeldingslenke
            </p>
            <div>
              <Label>Firmanavn</Label>
              <Input
                value={content.companyName || ""}
                onChange={(e) => updateContent("companyName", e.target.value)}
                placeholder="Hår1 AS"
              />
            </div>
            <div>
              <Label>Adresse</Label>
              <Input
                value={content.address || ""}
                onChange={(e) => updateContent("address", e.target.value)}
                placeholder="Storgata 1, 0155 Oslo"
              />
            </div>
            <div>
              <Label>Org.nummer</Label>
              <Input
                value={content.orgNumber || ""}
                onChange={(e) => updateContent("orgNumber", e.target.value)}
                placeholder="123 456 789"
              />
            </div>
            <Separator />
            <div>
              <Label>Avmeldingstekst</Label>
              <Input
                value={content.unsubscribeText || ""}
                onChange={(e) => updateContent("unsubscribeText", e.target.value)}
                placeholder="Meld deg av"
              />
            </div>
            <div>
              <Label>Personverntekst</Label>
              <Input
                value={content.privacyText || ""}
                onChange={(e) => updateContent("privacyText", e.target.value)}
                placeholder="Personvernerklæring"
              />
            </div>
          </div>
        );

      case "hero-image":
        return (
          <div className="space-y-4">
            <div>
              <Label>Hero-bilde</Label>
              <div className="mt-2 space-y-2">
                {content.imageUrl && (
                  <div className="p-4 bg-muted rounded-lg text-center">
                    <img src={content.imageUrl} alt="Preview" className="max-h-32 mx-auto rounded" />
                  </div>
                )}
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    className="flex-1"
                    onClick={() => { setGalleryField("imageUrl"); setGalleryOpen(true); }}
                  >
                    <Grid3X3 className="h-4 w-4 mr-2" />
                    Velg fra galleri
                  </Button>
                  <Button 
                    variant="outline" 
                    size="icon"
                    disabled={uploading}
                    onClick={() => document.getElementById(`hero-upload-${module.id}`)?.click()}
                  >
                    <Upload className="h-4 w-4" />
                  </Button>
                  <input
                    id={`hero-upload-${module.id}`}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => handleImageUpload(e, 'imageUrl')}
                  />
                </div>
              </div>
            </div>
            <div>
              <Label>Overskrift</Label>
              <Input
                value={content.title || ""}
                onChange={(e) => updateContent("title", e.target.value)}
                placeholder="Stor overskrift"
              />
            </div>
            <div>
              <Label>Undertittel</Label>
              <Input
                value={content.subtitle || ""}
                onChange={(e) => updateContent("subtitle", e.target.value)}
                placeholder="Kort beskrivelse"
              />
            </div>
            <Separator />
            <div>
              <Label>Overlay</Label>
              <div className="flex gap-2 mt-2">
                <Button
                  variant={content.overlay ? "default" : "outline"}
                  size="sm"
                  onClick={() => updateContent("overlay", true)}
                >
                  På
                </Button>
                <Button
                  variant={!content.overlay ? "default" : "outline"}
                  size="sm"
                  onClick={() => updateContent("overlay", false)}
                >
                  Av
                </Button>
              </div>
            </div>
            {content.overlay && (
              <div>
                <Label>Overlay opacity</Label>
                <div className="flex gap-2 mt-2">
                  {["0.3", "0.5", "0.7"].map((opacity) => (
                    <Button
                      key={opacity}
                      variant={content.overlayOpacity === opacity ? "default" : "outline"}
                      size="sm"
                      onClick={() => updateContent("overlayOpacity", opacity)}
                    >
                      {Math.round(parseFloat(opacity) * 100)}%
                    </Button>
                  ))}
                </div>
              </div>
            )}
            <div>
              <Label>Tekstposisjon</Label>
              <div className="flex gap-2 mt-2">
                {["top", "center", "bottom"].map((pos) => (
                  <Button
                    key={pos}
                    variant={content.textPosition === pos ? "default" : "outline"}
                    size="sm"
                    onClick={() => updateContent("textPosition", pos)}
                  >
                    {pos === "top" ? "Topp" : pos === "center" ? "Midt" : "Bunn"}
                  </Button>
                ))}
              </div>
            </div>
            <Separator />
            <div>
              <Label>Knappetekst (valgfritt)</Label>
              <Input
                value={content.buttonText || ""}
                onChange={(e) => updateContent("buttonText", e.target.value)}
                placeholder="Les mer"
              />
            </div>
            <div>
              <Label>Knapp-URL</Label>
              <Input
                value={content.buttonUrl || ""}
                onChange={(e) => updateContent("buttonUrl", e.target.value)}
                placeholder="https://..."
              />
            </div>
          </div>
        );

      case "two-columns":
      case "three-columns":
        const numCols = type === "two-columns" ? 2 : 3;
        return (
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              {numCols}-kolonners layout. Rediger innholdet i hver kolonne.
            </p>
            {Array.from({ length: numCols }).map((_, idx) => (
              <div key={idx}>
                <Label>Kolonne {idx + 1}</Label>
                <Textarea
                  value={content[`col${idx + 1}`] || ""}
                  onChange={(e) => updateContent(`col${idx + 1}`, e.target.value)}
                  placeholder={`Innhold for kolonne ${idx + 1}...`}
                  rows={2}
                />
              </div>
            ))}
          </div>
        );

      case "event-card":
        return (
          <div className="space-y-4">
            <div>
              <Label>Arrangementnavn</Label>
              <Input
                value={content.eventName || ""}
                onChange={(e) => updateContent("eventName", e.target.value)}
                placeholder="Kursdag 2024"
              />
            </div>
            <div>
              <Label>Dato</Label>
              <Input
                value={content.date || ""}
                onChange={(e) => updateContent("date", e.target.value)}
                placeholder="15. januar 2024"
              />
            </div>
            <div>
              <Label>Tid</Label>
              <Input
                value={content.time || ""}
                onChange={(e) => updateContent("time", e.target.value)}
                placeholder="10:00 - 16:00"
              />
            </div>
            <div>
              <Label>Sted</Label>
              <Input
                value={content.location || ""}
                onChange={(e) => updateContent("location", e.target.value)}
                placeholder="Oslo Kongressenter"
              />
            </div>
            <div>
              <Label>Beskrivelse</Label>
              <Textarea
                value={content.description || ""}
                onChange={(e) => updateContent("description", e.target.value)}
                placeholder="Kort beskrivelse..."
                rows={2}
              />
            </div>
            <div>
              <Label>Knappetekst</Label>
              <Input
                value={content.buttonText || ""}
                onChange={(e) => updateContent("buttonText", e.target.value)}
                placeholder="Meld deg på"
              />
            </div>
            <div>
              <Label>Knapp-URL</Label>
              <Input
                value={content.buttonUrl || ""}
                onChange={(e) => updateContent("buttonUrl", e.target.value)}
                placeholder="https://..."
              />
            </div>
          </div>
        );

      case "campaign-banner":
        return (
          <div className="space-y-4">
            <div>
              <Label>Tittel</Label>
              <Input
                value={content.title || ""}
                onChange={(e) => updateContent("title", e.target.value)}
                placeholder="BLACK FRIDAY"
              />
            </div>
            <div>
              <Label>Undertittel</Label>
              <Input
                value={content.subtitle || ""}
                onChange={(e) => updateContent("subtitle", e.target.value)}
                placeholder="Opptil 50% rabatt"
              />
            </div>
            <div>
              <Label>Bakgrunnsfarge</Label>
              <div className="flex gap-2">
                <Input
                  type="color"
                  value={content.backgroundColor || "#1a1a1a"}
                  onChange={(e) => updateContent("backgroundColor", e.target.value)}
                  className="w-12 h-10 p-1"
                />
                <Input
                  value={content.backgroundColor || "#1a1a1a"}
                  onChange={(e) => updateContent("backgroundColor", e.target.value)}
                  className="flex-1"
                />
              </div>
            </div>
            <div>
              <Label>Tekstfarge</Label>
              <div className="flex gap-2">
                <Input
                  type="color"
                  value={content.textColor || "#ffffff"}
                  onChange={(e) => updateContent("textColor", e.target.value)}
                  className="w-12 h-10 p-1"
                />
                <Input
                  value={content.textColor || "#ffffff"}
                  onChange={(e) => updateContent("textColor", e.target.value)}
                  className="flex-1"
                />
              </div>
            </div>
            <div>
              <Label>Knappetekst</Label>
              <Input
                value={content.buttonText || ""}
                onChange={(e) => updateContent("buttonText", e.target.value)}
                placeholder="Handle nå"
              />
            </div>
            <div>
              <Label>Knapp-URL</Label>
              <Input
                value={content.buttonUrl || ""}
                onChange={(e) => updateContent("buttonUrl", e.target.value)}
                placeholder="https://..."
              />
            </div>
          </div>
        );

      default:
        return (
          <div className="text-center py-4 text-muted-foreground">
            <p className="text-sm">Ingen redigeringsalternativer for denne modulen ({type})</p>
          </div>
        );
    }
  };

  const PADDING_PRESETS = {
    "Ingen": "0",
    "S": "16px 24px",
    "M": "24px 32px",
    "L": "32px 48px",
  };

  const MARGIN_PRESETS = {
    "Ingen": "0",
    "S": "8px 0",
    "M": "16px 0",
    "L": "24px 0",
  };

  const getPresetKey = (value: string | undefined, presets: Record<string, string>) => {
    if (!value) return null;
    return Object.entries(presets).find(([_, v]) => v === value)?.[0] || null;
  };

  const renderStylesEditor = () => {
    const currentPadding = getPresetKey(styles.padding, PADDING_PRESETS);
    const currentMargin = getPresetKey(styles.margin, MARGIN_PRESETS);

    return (
      <div className="space-y-4">
        <div>
          <Label>Tekstjustering</Label>
          <div className="flex gap-2 mt-2">
            <Button 
              variant={styles.textAlign === 'left' || !styles.textAlign ? 'default' : 'outline'}
              size="sm"
              onClick={() => updateStyles("textAlign", "left")}
            >
              <AlignLeft className="h-4 w-4" />
            </Button>
            <Button 
              variant={styles.textAlign === 'center' ? 'default' : 'outline'}
              size="sm"
              onClick={() => updateStyles("textAlign", "center")}
            >
              <AlignCenter className="h-4 w-4" />
            </Button>
            <Button 
              variant={styles.textAlign === 'right' ? 'default' : 'outline'}
              size="sm"
              onClick={() => updateStyles("textAlign", "right")}
            >
              <AlignRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
        <Separator />
        <div>
          <Label>Padding</Label>
          <div className="flex flex-wrap gap-2 mt-2">
            {Object.entries(PADDING_PRESETS).map(([size, value]) => (
              <Button
                key={size}
                variant={currentPadding === size ? "default" : "outline"}
                size="sm"
                onClick={() => updateStyles("padding", value)}
              >
                {size}
              </Button>
            ))}
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            {styles.padding || "Standard"}
          </p>
        </div>
        <div>
          <Label>Margin</Label>
          <div className="flex flex-wrap gap-2 mt-2">
            {Object.entries(MARGIN_PRESETS).map(([size, value]) => (
              <Button
                key={size}
                variant={currentMargin === size ? "default" : "outline"}
                size="sm"
                onClick={() => updateStyles("margin", value)}
              >
                {size}
              </Button>
            ))}
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            {styles.margin || "Standard"}
          </p>
        </div>
        <Separator />
        <div>
          <Label>Bakgrunnsfarge</Label>
          <div className="flex gap-2">
            <Input
              type="color"
              value={styles.backgroundColor || "#FFFFFF"}
              onChange={(e) => updateStyles("backgroundColor", e.target.value)}
              className="w-12 h-10 p-1"
            />
            <Input
              value={styles.backgroundColor || ""}
              onChange={(e) => updateStyles("backgroundColor", e.target.value)}
              placeholder="#FFFFFF"
              className="flex-1"
            />
          </div>
        </div>
      </div>
    );
  };

  const handleGallerySelect = (url: string, width?: string) => {
    updateContent(galleryField, url);
    if (width && galleryField === 'src') {
      updateContent('width', width);
    }
  };

  return (
    <div className="h-full flex flex-col">
      <div className="p-4 border-b bg-muted/30">
        <h3 className="font-semibold capitalize">{type.replace(/-/g, ' ')}</h3>
        <p className="text-xs text-muted-foreground mt-1">Rediger modulens innhold og utseende</p>
      </div>
      <Tabs defaultValue="content" className="flex-1 flex flex-col">
        <TabsList className="w-full rounded-none border-b">
          <TabsTrigger value="content" className="flex-1">Innhold</TabsTrigger>
          <TabsTrigger value="styles" className="flex-1">Stiler</TabsTrigger>
          <TabsTrigger value="tokens" className="flex-1">Tokens</TabsTrigger>
        </TabsList>
        <ScrollArea className="flex-1">
          <TabsContent value="content" className="p-4 m-0">
            {renderContentEditor()}
          </TabsContent>
          <TabsContent value="styles" className="p-4 m-0">
            {renderStylesEditor()}
          </TabsContent>
          <TabsContent value="tokens" className="p-4 m-0">
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Klikk på en token for å kopiere den til utklippstavlen. Lim den inn i tekstfelter for dynamisk innhold.
              </p>
              <div className="grid grid-cols-1 gap-2">
                {AVAILABLE_TOKENS.map(({ token, label }) => (
                  <Button
                    key={token}
                    variant="outline"
                    size="sm"
                    className="justify-between h-auto py-2 px-3"
                    onClick={() => {
                      navigator.clipboard.writeText(token);
                      toast.success(`Kopiert: ${token}`);
                    }}
                  >
                    <span className="text-left">
                      <span className="font-medium">{label}</span>
                    </span>
                    <code className="text-xs bg-muted px-1.5 py-0.5 rounded">{token}</code>
                  </Button>
                ))}
              </div>
            </div>
          </TabsContent>
        </ScrollArea>
      </Tabs>

      {/* Image Gallery Dialog */}
      <EmailImageGallery
        open={galleryOpen}
        onOpenChange={setGalleryOpen}
        onSelectImage={handleGallerySelect}
        currentImage={galleryField === 'src' ? content.src : content.logoUrl}
      />
    </div>
  );
}
