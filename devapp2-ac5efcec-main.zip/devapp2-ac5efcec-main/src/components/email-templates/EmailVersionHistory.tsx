import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { History, RotateCcw, Eye, Loader2 } from "lucide-react";
import { format } from "date-fns";
import { nb } from "date-fns/locale";
import { toast } from "sonner";
import type { EmailStructure } from "@/lib/emailHtmlGenerator";
import EmailPreview from "./EmailPreview";

interface TemplateVersion {
  id: string;
  version_number: number;
  structure: EmailStructure;
  subject_template: string | null;
  change_notes: string | null;
  created_at: string;
  created_by: string | null;
  created_by_user?: {
    name: string | null;
  } | null;
}

interface EmailVersionHistoryProps {
  templateId: string;
  currentStructure: EmailStructure;
  currentSubject: string;
  onRestore: (structure: EmailStructure, subject: string) => void;
}

export default function EmailVersionHistory({
  templateId,
  currentStructure,
  currentSubject,
  onRestore,
}: EmailVersionHistoryProps) {
  const [open, setOpen] = useState(false);
  const [previewVersion, setPreviewVersion] = useState<TemplateVersion | null>(null);
  const [restoreVersion, setRestoreVersion] = useState<TemplateVersion | null>(null);
  const [isRestoring, setIsRestoring] = useState(false);

  const { data: versions, isLoading } = useQuery({
    queryKey: ["email-template-versions", templateId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("email_template_versions")
        .select(`
          id,
          version_number,
          structure,
          subject_template,
          change_notes,
          created_at,
          created_by,
          created_by_user:users!email_template_versions_created_by_fkey(name)
        `)
        .eq("template_id", templateId)
        .order("version_number", { ascending: false });

      if (error) throw error;
      return data.map((v) => ({
        ...v,
        structure: v.structure as unknown as EmailStructure,
      })) as TemplateVersion[];
    },
    enabled: open,
  });

  const handleRestore = async () => {
    if (!restoreVersion) return;

    setIsRestoring(true);
    try {
      onRestore(restoreVersion.structure, restoreVersion.subject_template || "");
      toast.success(`Versjon ${restoreVersion.version_number} gjenopprettet`);
      setRestoreVersion(null);
      setOpen(false);
    } catch (error) {
      toast.error("Kunne ikke gjenopprette versjon");
    } finally {
      setIsRestoring(false);
    }
  };

  const getModuleCount = (structure: EmailStructure) => {
    return structure?.modules?.length || 0;
  };

  return (
    <>
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetTrigger asChild>
          <Button variant="outline" size="sm">
            <History className="h-4 w-4 mr-2" />
            Historikk
          </Button>
        </SheetTrigger>
        <SheetContent className="w-[400px] sm:w-[540px]">
          <SheetHeader>
            <SheetTitle>Versjonshistorikk</SheetTitle>
            <SheetDescription>
              Se tidligere publiserte versjoner og gjenopprett ved behov.
            </SheetDescription>
          </SheetHeader>

          <div className="mt-6">
            {/* Current version indicator */}
            <div className="mb-4 p-3 rounded-lg bg-primary/10 border border-primary/20">
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-sm">Nåværende versjon</span>
                    <Badge variant="secondary" className="text-xs">
                      {getModuleCount(currentStructure)} moduler
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {currentSubject || "Ingen emnelinje"}
                  </p>
                </div>
              </div>
            </div>

            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
              </div>
            ) : versions && versions.length > 0 ? (
              <ScrollArea className="h-[calc(100vh-280px)]">
                <div className="space-y-2 pr-4">
                  {versions.map((version) => (
                    <div
                      key={version.id}
                      className="p-3 rounded-lg border bg-card hover:bg-muted/50 transition-colors"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-sm">
                              Versjon {version.version_number}
                            </span>
                            <Badge variant="outline" className="text-xs">
                              {getModuleCount(version.structure)} moduler
                            </Badge>
                          </div>
                          <p className="text-xs text-muted-foreground mt-1">
                            {format(new Date(version.created_at), "d. MMMM yyyy 'kl.' HH:mm", {
                              locale: nb,
                            })}
                          </p>
                          {version.created_by_user?.name && (
                            <p className="text-xs text-muted-foreground">
                              Av {version.created_by_user.name}
                            </p>
                          )}
                          {version.change_notes && (
                            <p className="text-xs mt-1 text-foreground/80">
                              {version.change_notes}
                            </p>
                          )}
                        </div>
                        <div className="flex items-center gap-1 ml-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => setPreviewVersion(version)}
                            title="Forhåndsvis"
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-8 w-8"
                            onClick={() => setRestoreVersion(version)}
                            title="Gjenopprett"
                          >
                            <RotateCcw className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <History className="h-12 w-12 mx-auto mb-3 opacity-30" />
                <p className="font-medium">Ingen tidligere versjoner</p>
                <p className="text-sm mt-1">
                  Versjoner lagres automatisk når du publiserer malen.
                </p>
              </div>
            )}
          </div>
        </SheetContent>
      </Sheet>

      {/* Preview Dialog */}
      <Dialog open={!!previewVersion} onOpenChange={() => setPreviewVersion(null)}>
        <DialogContent className="max-w-4xl h-[80vh]">
          <DialogHeader>
            <DialogTitle>
              Forhåndsvisning - Versjon {previewVersion?.version_number}
            </DialogTitle>
            <DialogDescription>
              {previewVersion?.subject_template || "Ingen emnelinje"}
            </DialogDescription>
          </DialogHeader>
          <div className="flex-1 overflow-auto">
            {previewVersion && (
              <EmailPreview structure={previewVersion.structure} mode="desktop" />
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setPreviewVersion(null)}>
              Lukk
            </Button>
            <Button
              onClick={() => {
                setRestoreVersion(previewVersion);
                setPreviewVersion(null);
              }}
            >
              <RotateCcw className="h-4 w-4 mr-2" />
              Gjenopprett denne versjonen
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Restore Confirmation Dialog */}
      <Dialog open={!!restoreVersion} onOpenChange={() => setRestoreVersion(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Gjenopprett versjon {restoreVersion?.version_number}?</DialogTitle>
            <DialogDescription>
              Dette vil erstatte innholdet i editoren med denne versjonen. Dine nåværende
              endringer vil gå tapt med mindre du lagrer dem først.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setRestoreVersion(null)}>
              Avbryt
            </Button>
            <Button onClick={handleRestore} disabled={isRestoring}>
              {isRestoring ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <RotateCcw className="h-4 w-4 mr-2" />
              )}
              Gjenopprett
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
