import { RichTextEditor } from "@/components/ui/rich-text-editor";
import type { EmailModule } from "@/pages/EmailTemplateEditor";

interface EmailModuleRendererProps {
  module: EmailModule;
  isEditing: boolean;
  onUpdate: (updates: Partial<EmailModule>) => void;
}

type TextAlign = "left" | "center" | "right";

// Preset spacing values (Phase 1: S/M/L presets)
const SPACING_PRESETS = {
  S: 16,
  M: 32,
  L: 48,
} as const;

export default function EmailModuleRenderer({
  module,
  isEditing,
  onUpdate,
}: EmailModuleRendererProps) {
  const { type, content, styles = {} } = module;

  const baseStyles = {
    fontFamily: "'DM Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
    fontSize: "16px",
    lineHeight: "1.6",
    color: "#3D3D3D",
  };

  // Get padding from preset or raw value
  const getPaddingValue = (preset: string | undefined): string => {
    if (!preset) return "16px 32px";
    if (preset in SPACING_PRESETS) {
      const val = SPACING_PRESETS[preset as keyof typeof SPACING_PRESETS];
      return `${val}px`;
    }
    return preset;
  };

  // Helper to get background color from either content or styles
  // Check for truthy non-empty values
  const getBgColor = (defaultColor: string = "#FFFFFF") => {
    if (content.backgroundColor && content.backgroundColor.trim() !== "") {
      return content.backgroundColor;
    }
    if (styles.backgroundColor && styles.backgroundColor.trim() !== "") {
      return styles.backgroundColor;
    }
    return defaultColor;
  };

  const renderModule = () => {
    switch (type) {
      case "header-logo":
      case "header-portalen":
        return (
          <div 
            style={{ 
              backgroundColor: getBgColor("#FAF8F5"),
              padding: styles.padding || "32px",
              textAlign: "center" as const,
            }}
          >
            <img
              src={content.logoUrl}
              alt={content.logoAlt || "Logo"}
              style={{ maxHeight: "60px", margin: "0 auto" }}
            />
          </div>
        );

      case "heading":
        const headingFontSize = content.level === "h1" ? "28px" : content.level === "h3" ? "18px" : "22px";
        const headingColor = styles.color || "#8B7355";
        return (
          <div 
            style={{ 
              ...baseStyles,
              backgroundColor: getBgColor("transparent"),
              padding: styles.padding || "24px 32px 8px 32px",
              fontSize: headingFontSize,
              fontWeight: 600,
              color: headingColor,
              textAlign: (styles.textAlign as TextAlign) || "left",
            }}
          >
            {content.text || "Overskrift"}
          </div>
        );

      case "text":
        const textContent = content.content || content.text || "";
        const textColor = styles.color || baseStyles.color;
        return (
          <div 
            style={{ 
              ...baseStyles,
              backgroundColor: getBgColor("transparent"),
              padding: styles.padding || "24px 32px",
              textAlign: (styles.textAlign as TextAlign) || "left",
              color: textColor,
            }}
          >
            {isEditing ? (
              <RichTextEditor
                content={textContent}
                onChange={(newContent) => 
                  onUpdate({ content: { ...content, content: newContent } })
                }
                placeholder="Skriv tekst her..."
              />
            ) : (
              <div dangerouslySetInnerHTML={{ __html: textContent }} />
            )}
          </div>
        );

      case "cta-button":
        const buttonVariant = content.variant || "primary";
        const buttonStyles = {
          primary: {
            background: "linear-gradient(135deg, #8B7355 0%, #6B5440 100%)",
            color: "#FFFFFF",
            border: "none",
          },
          secondary: {
            background: "#FAF8F5",
            color: "#8B7355",
            border: "2px solid #8B7355",
          },
          outline: {
            background: "transparent",
            color: "#8B7355",
            border: "2px solid #8B7355",
          },
        }[buttonVariant] || { background: "linear-gradient(135deg, #8B7355 0%, #6B5440 100%)", color: "#FFFFFF", border: "none" };
        
        return (
          <div style={{ padding: styles.padding || "16px 32px", textAlign: "center" as const }}>
            <a
              href={content.url || "#"}
              style={{
                display: "inline-block",
                padding: "14px 32px",
                ...buttonStyles,
                textDecoration: "none",
                borderRadius: "8px",
                fontWeight: 600,
                fontSize: "16px",
                fontFamily: baseStyles.fontFamily,
              }}
            >
              {content.text || "Klikk her"}
            </a>
          </div>
        );

      // Phase 2: CTA-seksjon modul
      case "cta-section":
        return (
          <div 
            style={{ 
              backgroundColor: getBgColor("#FAF8F5"),
              borderRadius: "12px",
              padding: "32px",
              margin: styles.margin || "16px 32px",
              textAlign: "center" as const,
            }}
          >
            {content.title && (
              <h3 style={{ 
                margin: "0 0 12px 0", 
                fontSize: "22px",
                fontWeight: 600,
                color: "#3D3D3D",
                fontFamily: baseStyles.fontFamily,
              }}>
                {content.title}
              </h3>
            )}
            {content.description && (
              <p style={{ 
                margin: "0 0 20px 0", 
                fontSize: "16px",
                color: "#6B6B6B",
                fontFamily: baseStyles.fontFamily,
              }}>
                {content.description}
              </p>
            )}
            {content.buttonText && (
              <a
                href={content.buttonUrl || "#"}
                style={{
                  display: "inline-block",
                  padding: "14px 32px",
                  background: "linear-gradient(135deg, #8B7355 0%, #6B5440 100%)",
                  color: "#FFFFFF",
                  textDecoration: "none",
                  borderRadius: "8px",
                  fontWeight: 600,
                  fontSize: "16px",
                  fontFamily: baseStyles.fontFamily,
                }}
              >
                {content.buttonText}
              </a>
            )}
          </div>
        );

      case "info-box":
        const infoBoxContent = content.content || content.text || "";
        return (
          <div 
            style={{ 
              background: "linear-gradient(135deg, #FAF7F2 0%, #F5EEE6 100%)",
              borderRadius: "12px",
              padding: styles.padding || "24px",
              margin: styles.margin || "16px 32px",
            }}
          >
            {content.title && (
              <h3 style={{ 
                margin: "0 0 12px 0", 
                fontWeight: 600,
                fontSize: "18px",
                color: "#3D3D3D",
                fontFamily: baseStyles.fontFamily,
              }}>
                {content.title}
              </h3>
            )}
            {isEditing ? (
              <RichTextEditor
                content={infoBoxContent}
                onChange={(newContent) => 
                  onUpdate({ content: { ...content, content: newContent } })
                }
                placeholder="Innhold..."
              />
            ) : (
              <div 
                style={{ ...baseStyles, fontSize: "15px" }}
                dangerouslySetInnerHTML={{ __html: infoBoxContent }} 
              />
            )}
          </div>
        );

      case "success-banner":
        return (
          <div 
            style={{ 
              background: "linear-gradient(135deg, #E8F5E9 0%, #C8E6C9 100%)",
              borderRadius: "12px",
              padding: "24px",
              margin: styles.margin || "16px 32px",
              textAlign: "center" as const,
            }}
          >
            <div style={{ fontSize: "48px", marginBottom: "12px" }}>{content.emoji || "🎉"}</div>
            <div style={{ fontWeight: 600, fontSize: "20px", color: "#2E7D32", fontFamily: baseStyles.fontFamily }}>
              {content.text || "Vellykket!"}
            </div>
          </div>
        );

      case "warning-banner":
        return (
          <div 
            style={{ 
              background: "#FFF8E7",
              border: "1px solid #F0C36D",
              borderRadius: "8px",
              padding: "16px",
              margin: styles.margin || "16px 32px",
            }}
          >
            <div style={{ fontWeight: 600, color: "#8B6914", fontFamily: baseStyles.fontFamily }}>
              ⚠️ {content.text || "Obs!"}
            </div>
          </div>
        );

      case "benefits-list":
        const items = content.items || [];
        return (
          <div 
            style={{ 
              background: "linear-gradient(135deg, #FAF7F2 0%, #F5EEE6 100%)",
              borderRadius: "12px",
              padding: styles.padding || "24px",
              margin: styles.margin || "16px 32px",
            }}
          >
            {content.title && (
              <h3 style={{ 
                margin: "0 0 16px 0", 
                fontWeight: 600,
                fontSize: "18px",
                color: "#8B7355",
                fontFamily: baseStyles.fontFamily,
              }}>
                {content.title}
              </h3>
            )}
            <ul style={{ margin: 0, padding: 0, listStyle: "none" }}>
              {items.map((item: string, index: number) => (
                <li 
                  key={index}
                  style={{ 
                    display: "flex",
                    alignItems: "flex-start",
                    gap: "12px",
                    marginBottom: "8px",
                    fontSize: "16px",
                    color: "#5A5A5A",
                    fontFamily: baseStyles.fontFamily,
                  }}
                >
                  <span style={{ color: "#4CAF50", fontWeight: "bold", flexShrink: 0 }}>✓</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        );

      case "icon-list":
        const iconItems = content.items || [];
        const iconMap: Record<string, string> = {
          check: "✓",
          star: "★",
          arrow: "→",
          bullet: "•",
        };
        const icon = iconMap[content.icon] || "✓";
        return (
          <div style={{ padding: styles.padding || "16px 32px" }}>
            <ul style={{ margin: 0, padding: 0, listStyle: "none" }}>
              {iconItems.map((item: string, index: number) => (
                <li 
                  key={index}
                  style={{ 
                    display: "flex",
                    alignItems: "flex-start",
                    gap: "12px",
                    marginBottom: "8px",
                    fontSize: "16px",
                    color: "#3D3D3D",
                    fontFamily: baseStyles.fontFamily,
                  }}
                >
                  <span style={{ color: styles.iconColor || "#22c55e", fontWeight: "bold", flexShrink: 0 }}>{icon}</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        );

      case "product-table":
        const headers = content.headers || ["Produkt", "Antall", "Pris"];
        const rows = content.rows || [];
        return (
          <div style={{ margin: styles.margin || "16px 32px" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", fontFamily: baseStyles.fontFamily }}>
              <thead>
                <tr style={{ background: "#8B7355" }}>
                  {headers.map((header: string, i: number) => (
                    <th 
                      key={i}
                      style={{ 
                        padding: "14px 16px",
                        textAlign: i === 0 ? "left" : "right" as const,
                        fontWeight: 600,
                        fontSize: "14px",
                        color: "#FFFFFF",
                        borderRadius: i === 0 ? "8px 0 0 0" : i === headers.length - 1 ? "0 8px 0 0" : undefined,
                      }}
                    >
                      {header}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.length === 0 ? (
                  <tr>
                    <td colSpan={headers.length} style={{ padding: "24px", textAlign: "center" as const, color: "#8B8B8B" }}>
                      Ingen produkter lagt til
                    </td>
                  </tr>
                ) : (
                  rows.map((row: string[], rowIndex: number) => (
                    <tr key={rowIndex}>
                      {row.map((cell, cellIndex) => (
                        <td 
                          key={cellIndex}
                          style={{ 
                            padding: "14px 16px",
                            textAlign: cellIndex === 0 ? "left" : "right" as const,
                            borderBottom: "1px solid #E8E0D8",
                            color: "#4A4A4A",
                          }}
                        >
                          {cell}
                        </td>
                      ))}
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        );

      // Phase 2: Produktmodul (for kampanjer)
      case "product-card":
        return (
          <div 
            style={{ 
              background: "#FFFFFF",
              border: "1px solid #E8E0D8",
              borderRadius: "12px",
              overflow: "hidden",
              margin: styles.margin || "16px 32px",
            }}
          >
            {content.imageUrl && (
              <div style={{ width: "100%", height: "200px", overflow: "hidden" }}>
                <img 
                  src={content.imageUrl} 
                  alt={content.name || "Produkt"} 
                  style={{ width: "100%", height: "100%", objectFit: "cover" }}
                />
              </div>
            )}
            <div style={{ padding: "20px", textAlign: "center" as const }}>
              <h3 style={{ 
                margin: "0 0 8px 0", 
                fontSize: "20px", 
                fontWeight: 600, 
                color: "#3D3D3D",
                fontFamily: baseStyles.fontFamily,
              }}>
                {content.name || "Produktnavn"}
              </h3>
              {content.description && (
                <p style={{ 
                  margin: "0 0 16px 0", 
                  fontSize: "14px", 
                  color: "#6B6B6B",
                  fontFamily: baseStyles.fontFamily,
                }}>
                  {content.description}
                </p>
              )}
              <div style={{ marginBottom: content.ctaText ? "16px" : 0 }}>
                {content.originalPrice && (
                  <span style={{ 
                    fontSize: "16px", 
                    color: "#8B8B8B", 
                    textDecoration: "line-through",
                    marginRight: "12px",
                    fontFamily: baseStyles.fontFamily,
                  }}>
                    kr {content.originalPrice}
                  </span>
                )}
                <span style={{ 
                  fontSize: "24px", 
                  fontWeight: 700, 
                  color: "#8B7355",
                  fontFamily: baseStyles.fontFamily,
                }}>
                  kr {content.price || "0"}
                </span>
              </div>
              {content.ctaText && (
                <a
                  href={content.ctaUrl || "#"}
                  style={{
                    display: "inline-block",
                    padding: "12px 24px",
                    background: "linear-gradient(135deg, #8B7355 0%, #6B5440 100%)",
                    color: "#FFFFFF",
                    textDecoration: "none",
                    borderRadius: "8px",
                    fontWeight: 600,
                    fontSize: "14px",
                    fontFamily: baseStyles.fontFamily,
                  }}
                >
                  {content.ctaText}
                </a>
              )}
            </div>
          </div>
        );

      case "note-box":
        return (
          <div 
            style={{ 
              background: "#F8F9FA",
              borderLeft: "4px solid #8B7355",
              borderRadius: "0 8px 8px 0",
              padding: "16px 20px",
              margin: styles.margin || "16px 32px",
            }}
          >
            {content.title && (
              <p style={{ margin: "0 0 8px 0", fontWeight: 600, color: "#8B7355", fontSize: "14px", fontFamily: baseStyles.fontFamily }}>
                {content.icon || "💬"} {content.title}
              </p>
            )}
            <p style={{ margin: 0, color: "#5A5A5A", fontStyle: "italic", fontFamily: baseStyles.fontFamily }}>
              {content.content || ""}
            </p>
          </div>
        );

      case "quote-box":
        return (
          <div 
            style={{ 
              background: styles.backgroundColor || "#FAF8F5",
              borderLeft: `4px solid ${styles.borderColor || "#8B7355"}`,
              borderRadius: "0 8px 8px 0",
              padding: "20px 24px",
              margin: styles.margin || "16px 32px",
            }}
          >
            <p style={{ margin: 0, fontSize: "16px", color: "#3D3D3D", fontStyle: "italic", fontFamily: baseStyles.fontFamily }}>
              "{content.text || ""}"
            </p>
            {content.author && (
              <p style={{ margin: "12px 0 0 0", fontSize: "14px", color: "#8B7355", fontWeight: 500, fontFamily: baseStyles.fontFamily }}>
                — {content.author}
              </p>
            )}
          </div>
        );

      case "footer-signature":
        return (
          <div 
            style={{ 
              backgroundColor: getBgColor("#FAF8F5"),
              padding: styles.padding || "32px",
              textAlign: "center" as const,
              borderTop: "1px solid #E8E0D5",
            }}
          >
            <div 
              style={{ ...baseStyles, marginBottom: "16px" }}
              dangerouslySetInnerHTML={{ __html: content.signature || "Med vennlig hilsen,<br><strong>Hår1-teamet</strong>" }}
            />
            {content.contact && (
              <div style={{ fontSize: "14px", color: "#6B6B6B" }}>
                {content.contact.phone && <p style={{ margin: "4px 0" }}>📞 {content.contact.phone}</p>}
                {content.contact.email && <p style={{ margin: "4px 0" }}>✉️ {content.contact.email}</p>}
                {content.contact.website && <p style={{ margin: "4px 0" }}>🌐 {content.contact.website}</p>}
              </div>
            )}
          </div>
        );

      // Phase 2: Sosiale medier footer
      case "footer-social":
        const socialLinks = content.links || [];
        const socialIcons: Record<string, string> = {
          facebook: "📘",
          instagram: "📸",
          linkedin: "💼",
          twitter: "🐦",
          youtube: "📺",
        };
        return (
          <div 
            style={{ 
              backgroundColor: getBgColor("#FAF8F5"),
              padding: styles.padding || "24px 32px",
              textAlign: "center" as const,
            }}
          >
            {content.title && (
              <p style={{ 
                margin: "0 0 16px 0", 
                fontSize: "14px", 
                color: "#6B6B6B",
                fontFamily: baseStyles.fontFamily,
              }}>
                {content.title}
              </p>
            )}
            <div style={{ display: "flex", justifyContent: "center", gap: "16px" }}>
              {socialLinks.map((link: { platform: string; url: string }, index: number) => (
                <a
                  key={index}
                  href={link.url || "#"}
                  style={{
                    display: "inline-flex",
                    alignItems: "center",
                    justifyContent: "center",
                    width: "40px",
                    height: "40px",
                    backgroundColor: "#8B7355",
                    borderRadius: "50%",
                    textDecoration: "none",
                    fontSize: "20px",
                  }}
                  title={link.platform}
                >
                  {socialIcons[link.platform] || "🔗"}
                </a>
              ))}
            </div>
          </div>
        );

      // Phase 2: Footer med avmelding (lovpålagt)
      case "footer-unsubscribe":
        return (
          <div 
            style={{ 
              backgroundColor: getBgColor("#F5F5F5"),
              padding: styles.padding || "24px 32px",
              textAlign: "center" as const,
              borderTop: "1px solid #E5E5E5",
            }}
          >
            <div style={{ marginBottom: "16px" }}>
              {content.companyName && (
                <p style={{ margin: "0 0 4px 0", fontSize: "14px", color: "#6B6B6B", fontFamily: baseStyles.fontFamily }}>
                  {content.companyName}
                </p>
              )}
              {content.address && (
                <p style={{ margin: "0 0 4px 0", fontSize: "12px", color: "#8B8B8B", fontFamily: baseStyles.fontFamily }}>
                  {content.address}
                </p>
              )}
              {content.orgNumber && (
                <p style={{ margin: "0", fontSize: "12px", color: "#8B8B8B", fontFamily: baseStyles.fontFamily }}>
                  Org.nr: {content.orgNumber}
                </p>
              )}
            </div>
            <div style={{ fontSize: "12px", color: "#8B8B8B", fontFamily: baseStyles.fontFamily }}>
              <a 
                href={content.unsubscribeUrl || "#"} 
                style={{ color: "#8B7355", textDecoration: "underline" }}
              >
                Meld deg av
              </a>
              {content.privacyUrl && (
                <>
                  {" • "}
                  <a 
                    href={content.privacyUrl} 
                    style={{ color: "#8B7355", textDecoration: "underline" }}
                  >
                    Personvern
                  </a>
                </>
              )}
            </div>
          </div>
        );

      case "footer-disclaimer":
        return (
          <div 
            style={{ 
              fontSize: "12px",
              color: "#8B8B8B",
              padding: styles.padding || "16px 32px",
              textAlign: "center" as const,
              fontFamily: baseStyles.fontFamily,
            }}
          >
            {content.text || "Denne e-posten er sendt fra Hår1."}
          </div>
        );

      case "separator":
      case "divider":
        return (
          <div style={{ margin: styles.margin || "16px 32px" }}>
            <hr 
              style={{ 
                border: "none",
                borderTop: `1px ${content.style || "solid"} ${content.color || "#E8E0D5"}`,
              }} 
            />
          </div>
        );

      // Phase 1: Spacer med S/M/L presets
      case "spacer":
        const spacerSize = content.size || "M";
        const spacerHeight = SPACING_PRESETS[spacerSize as keyof typeof SPACING_PRESETS] || parseInt(content.height) || 32;
        return (
          <div 
            style={{ 
              height: `${spacerHeight}px`, 
              background: isEditing ? "repeating-linear-gradient(45deg, transparent, transparent 5px, #f0f0f0 5px, #f0f0f0 10px)" : "transparent" 
            }} 
          />
        );

      case "image":
        return (
          <div style={{ 
            padding: styles.padding || "16px 32px", 
            textAlign: "center" as const,
            backgroundColor: getBgColor("transparent"),
          }}>
            {content.src ? (
              <img
                src={content.src}
                alt={content.alt || ""}
                style={{ maxWidth: content.width || "100%", height: "auto" }}
              />
            ) : (
              <div style={{ backgroundColor: "#F5F5F5", padding: "48px", color: "#8B8B8B" }}>
                Klikk for å velge bilde
              </div>
            )}
          </div>
        );

      // Phase 1: Bilde + tekst (venstre)
      case "image-text-left":
        return (
          <div style={{ padding: styles.padding || "16px 32px" }}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <tbody>
                <tr>
                  <td style={{ width: "50%", verticalAlign: "top", padding: "0 12px 0 0" }}>
                    {content.imageUrl ? (
                      <img
                        src={content.imageUrl}
                        alt={content.imageAlt || ""}
                        style={{ width: "100%", height: "auto", borderRadius: "8px" }}
                      />
                    ) : (
                      <div style={{ backgroundColor: "#F5F5F5", padding: "48px", textAlign: "center", borderRadius: "8px", color: "#8B8B8B" }}>
                        Bilde
                      </div>
                    )}
                  </td>
                  <td style={{ width: "50%", verticalAlign: "top", padding: "0 0 0 12px" }}>
                    {content.title && (
                      <h3 style={{ margin: "0 0 12px 0", fontSize: "20px", fontWeight: 600, color: "#3D3D3D", fontFamily: baseStyles.fontFamily }}>
                        {content.title}
                      </h3>
                    )}
                    {isEditing ? (
                      <RichTextEditor
                        content={content.text || ""}
                        onChange={(newContent) => onUpdate({ content: { ...content, text: newContent } })}
                        placeholder="Skriv tekst her..."
                      />
                    ) : (
                      <div style={{ ...baseStyles }} dangerouslySetInnerHTML={{ __html: content.text || "" }} />
                    )}
                    {content.ctaText && (
                      <a
                        href={content.ctaUrl || "#"}
                        style={{
                          display: "inline-block",
                          marginTop: "16px",
                          padding: "10px 20px",
                          background: "linear-gradient(135deg, #8B7355 0%, #6B5440 100%)",
                          color: "#FFFFFF",
                          textDecoration: "none",
                          borderRadius: "6px",
                          fontWeight: 600,
                          fontSize: "14px",
                          fontFamily: baseStyles.fontFamily,
                        }}
                      >
                        {content.ctaText}
                      </a>
                    )}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        );

      // Phase 1: Bilde + tekst (høyre)
      case "image-text-right":
        return (
          <div style={{ padding: styles.padding || "16px 32px" }}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <tbody>
                <tr>
                  <td style={{ width: "50%", verticalAlign: "top", padding: "0 12px 0 0" }}>
                    {content.title && (
                      <h3 style={{ margin: "0 0 12px 0", fontSize: "20px", fontWeight: 600, color: "#3D3D3D", fontFamily: baseStyles.fontFamily }}>
                        {content.title}
                      </h3>
                    )}
                    {isEditing ? (
                      <RichTextEditor
                        content={content.text || ""}
                        onChange={(newContent) => onUpdate({ content: { ...content, text: newContent } })}
                        placeholder="Skriv tekst her..."
                      />
                    ) : (
                      <div style={{ ...baseStyles }} dangerouslySetInnerHTML={{ __html: content.text || "" }} />
                    )}
                    {content.ctaText && (
                      <a
                        href={content.ctaUrl || "#"}
                        style={{
                          display: "inline-block",
                          marginTop: "16px",
                          padding: "10px 20px",
                          background: "linear-gradient(135deg, #8B7355 0%, #6B5440 100%)",
                          color: "#FFFFFF",
                          textDecoration: "none",
                          borderRadius: "6px",
                          fontWeight: 600,
                          fontSize: "14px",
                          fontFamily: baseStyles.fontFamily,
                        }}
                      >
                        {content.ctaText}
                      </a>
                    )}
                  </td>
                  <td style={{ width: "50%", verticalAlign: "top", padding: "0 0 0 12px" }}>
                    {content.imageUrl ? (
                      <img
                        src={content.imageUrl}
                        alt={content.imageAlt || ""}
                        style={{ width: "100%", height: "auto", borderRadius: "8px" }}
                      />
                    ) : (
                      <div style={{ backgroundColor: "#F5F5F5", padding: "48px", textAlign: "center", borderRadius: "8px", color: "#8B8B8B" }}>
                        Bilde
                      </div>
                    )}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        );

      // Phase 1: Gallerimodul (2-4 bilder)
      case "gallery-grid":
        const images = content.images || [];
        const columns = content.columns || 2;
        return (
          <div style={{ padding: styles.padding || "16px 32px" }}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <tbody>
                <tr>
                  {images.slice(0, columns).map((img: { src: string; alt?: string }, index: number) => (
                    <td 
                      key={index}
                      style={{ 
                        width: `${100 / columns}%`, 
                        padding: index === 0 ? "0 6px 0 0" : index === columns - 1 ? "0 0 0 6px" : "0 6px",
                        verticalAlign: "top",
                      }}
                    >
                      {img.src ? (
                        <img
                          src={img.src}
                          alt={img.alt || ""}
                          style={{ width: "100%", height: "auto", borderRadius: "8px" }}
                        />
                      ) : (
                        <div style={{ 
                          backgroundColor: "#F5F5F5", 
                          paddingTop: "75%", 
                          borderRadius: "8px",
                          position: "relative" as const,
                        }}>
                          <span style={{ 
                            position: "absolute" as const, 
                            top: "50%", 
                            left: "50%", 
                            transform: "translate(-50%, -50%)",
                            color: "#8B8B8B",
                          }}>
                            Bilde {index + 1}
                          </span>
                        </div>
                      )}
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
        );

      // Phase 1: Seksjonsmodul (container)
      case "section-container":
        // Support both paddingSize (preset key) and padding (raw value)
        const sectionPadding = content.padding || getPaddingValue(content.paddingSize);
        // Support both borderRadius (raw) and rounded (boolean)
        const sectionRadius = content.borderRadius || (content.rounded ? "12px" : "0");
        return (
          <div 
            style={{ 
              backgroundColor: getBgColor("#FFFFFF"),
              padding: sectionPadding,
              margin: styles.margin || "0",
              borderRadius: sectionRadius,
            }}
          >
            {isEditing ? (
              <div style={{ 
                border: "2px dashed #E8E0D8", 
                borderRadius: "8px", 
                padding: "24px", 
                textAlign: "center",
                color: "#8B8B8B",
              }}>
                Seksjonscontainer - dra moduler hit
              </div>
            ) : (
              <div dangerouslySetInnerHTML={{ __html: content.innerContent || "" }} />
            )}
          </div>
        );

      case "two-columns":
        return (
          <div style={{ padding: styles.padding || "16px 32px" }}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <tbody>
                <tr>
                  <td style={{ width: "50%", verticalAlign: "top", padding: "0 8px 0 0" }}>
                    <div dangerouslySetInnerHTML={{ __html: content.left?.content || "<p>Venstre kolonne</p>" }} />
                  </td>
                  <td style={{ width: "50%", verticalAlign: "top", padding: "0 0 0 8px" }}>
                    <div dangerouslySetInnerHTML={{ __html: content.right?.content || "<p>Høyre kolonne</p>" }} />
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        );

      case "three-columns":
        return (
          <div style={{ padding: styles.padding || "16px 32px" }}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <tbody>
                <tr>
                  <td style={{ width: "33.33%", verticalAlign: "top", padding: "0 8px 0 0" }}>
                    <div dangerouslySetInnerHTML={{ __html: content.left?.content || "<p>Kolonne 1</p>" }} />
                  </td>
                  <td style={{ width: "33.33%", verticalAlign: "top", padding: "0 8px" }}>
                    <div dangerouslySetInnerHTML={{ __html: content.center?.content || "<p>Kolonne 2</p>" }} />
                  </td>
                  <td style={{ width: "33.33%", verticalAlign: "top", padding: "0 0 0 8px" }}>
                    <div dangerouslySetInnerHTML={{ __html: content.right?.content || "<p>Kolonne 3</p>" }} />
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        );

      // Phase 3: Forbedret hero-modul med overlay-kontroll
      case "hero-image":
        const overlayOpacity = content.overlayOpacity || 0.4;
        const overlayColor = content.overlayColor || "#000000";
        const textPosition = content.textPosition || "center";
        const textPositionStyle = {
          top: { top: "20%", transform: "translateX(-50%)" },
          center: { top: "50%", transform: "translate(-50%, -50%)" },
          bottom: { bottom: "20%", transform: "translateX(-50%)" },
        }[textPosition] || { top: "50%", transform: "translate(-50%, -50%)" };

        return (
          <div style={{ position: "relative" as const, textAlign: "center" as const }}>
            {content.src ? (
              <div style={{ position: "relative" as const }}>
                <img
                  src={content.src}
                  alt={content.alt || ""}
                  style={{ width: "100%", height: "auto", display: "block" }}
                />
                {content.showOverlay && (
                  <div 
                    style={{ 
                      position: "absolute" as const,
                      top: 0,
                      left: 0,
                      right: 0,
                      bottom: 0,
                      backgroundColor: overlayColor,
                      opacity: overlayOpacity,
                    }}
                  />
                )}
                <div 
                  style={{ 
                    position: "absolute" as const,
                    left: "50%",
                    ...textPositionStyle,
                    textAlign: "center" as const,
                    color: "#FFFFFF",
                    textShadow: "0 2px 8px rgba(0,0,0,0.5)",
                    width: "90%",
                  }}
                >
                  <h2 style={{ margin: "0 0 8px 0", fontSize: "32px", fontWeight: 700, fontFamily: baseStyles.fontFamily }}>
                    {content.overlayText || ""}
                  </h2>
                  {content.overlaySubtext && (
                    <p style={{ margin: 0, fontSize: "18px", fontFamily: baseStyles.fontFamily }}>
                      {content.overlaySubtext}
                    </p>
                  )}
                  {content.ctaText && (
                    <a
                      href={content.ctaUrl || "#"}
                      style={{
                        display: "inline-block",
                        marginTop: "20px",
                        padding: "14px 32px",
                        background: "linear-gradient(135deg, #8B7355 0%, #6B5440 100%)",
                        color: "#FFFFFF",
                        textDecoration: "none",
                        borderRadius: "8px",
                        fontWeight: 600,
                        fontSize: "16px",
                        fontFamily: baseStyles.fontFamily,
                      }}
                    >
                      {content.ctaText}
                    </a>
                  )}
                </div>
              </div>
            ) : (
              <div style={{ backgroundColor: "#8B7355", padding: "80px 32px", color: "#FFFFFF" }}>
                <h2 style={{ margin: "0 0 8px 0", fontSize: "32px", fontWeight: 700, fontFamily: baseStyles.fontFamily }}>
                  {content.overlayText || "Din overskrift her"}
                </h2>
                {content.overlaySubtext && (
                  <p style={{ margin: 0, fontSize: "18px", fontFamily: baseStyles.fontFamily }}>
                    {content.overlaySubtext}
                  </p>
                )}
              </div>
            )}
          </div>
        );

      case "salon-card":
        return (
          <div 
            style={{ 
              background: "linear-gradient(135deg, #FAF7F2 0%, #F5EEE6 100%)",
              borderRadius: "12px",
              padding: "24px",
              margin: styles.margin || "16px 32px",
              textAlign: "center" as const,
            }}
          >
            {content.showLogo && (
              <div style={{ marginBottom: "16px" }}>
                <div style={{ width: "80px", height: "80px", borderRadius: "50%", backgroundColor: "#E8E0D8", margin: "0 auto", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <span style={{ fontSize: "24px" }}>💇</span>
                </div>
              </div>
            )}
            {content.showName !== false && (
              <h3 style={{ margin: "0 0 8px 0", fontSize: "20px", fontWeight: 600, color: "#8B7355", fontFamily: baseStyles.fontFamily }}>
                {content.salonName || "{salongnavn}"}
              </h3>
            )}
            {content.showHours && (
              <p style={{ margin: "8px 0 0 0", fontSize: "14px", color: "#6B6B6B", fontFamily: baseStyles.fontFamily }}>
                {content.hours || "Man-Fre: 09:00 - 18:00"}
              </p>
            )}
            {content.showAddress && content.address && (
              <p style={{ margin: "8px 0 0 0", fontSize: "14px", color: "#6B6B6B", fontFamily: baseStyles.fontFamily }}>
                {content.address}
              </p>
            )}
          </div>
        );

      case "campaign-price":
        return (
          <div 
            style={{ 
              background: "linear-gradient(135deg, #FEF3C7 0%, #FDE68A 100%)",
              borderRadius: "12px",
              padding: "24px",
              margin: styles.margin || "16px 32px",
              textAlign: "center" as const,
            }}
          >
            <p style={{ margin: "0 0 12px 0", fontSize: "18px", fontWeight: 600, color: "#78350F", fontFamily: baseStyles.fontFamily }}>
              {content.productName || "Behandling"}
            </p>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "16px" }}>
              <span style={{ fontSize: "20px", color: "#92400E", textDecoration: "line-through", fontFamily: baseStyles.fontFamily }}>
                kr {content.originalPrice || "999"}
              </span>
              <span style={{ fontSize: "32px", fontWeight: 700, color: "#78350F", fontFamily: baseStyles.fontFamily }}>
                kr {content.campaignPrice || "799"}
              </span>
            </div>
            {content.savings && (
              <p style={{ margin: "8px 0 0 0", fontSize: "14px", color: "#92400E", fontFamily: baseStyles.fontFamily }}>
                Du sparer kr {content.savings}!
              </p>
            )}
            {content.validUntil && (
              <p style={{ margin: "8px 0 0 0", fontSize: "12px", color: "#A16207", fontFamily: baseStyles.fontFamily }}>
                Gyldig til {content.validUntil}
              </p>
            )}
          </div>
        );

      case "treatment-list":
        const treatments = content.treatments || [];
        return (
          <div style={{ margin: styles.margin || "16px 32px" }}>
            {content.title && (
              <h3 style={{ margin: "0 0 16px 0", fontSize: "18px", fontWeight: 600, color: "#8B7355", fontFamily: baseStyles.fontFamily }}>
                {content.title}
              </h3>
            )}
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <tbody>
                {treatments.map((treatment: { name: string; price: string }, index: number) => (
                  <tr key={index} style={{ borderBottom: "1px solid #E8E0D8" }}>
                    <td style={{ padding: "12px 0", fontFamily: baseStyles.fontFamily, color: "#3D3D3D" }}>
                      {treatment.name}
                    </td>
                    <td style={{ padding: "12px 0", textAlign: "right" as const, fontWeight: 600, fontFamily: baseStyles.fontFamily, color: "#8B7355" }}>
                      kr {treatment.price}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );

      case "benefits-highlight":
        const benefits = content.benefits || [];
        return (
          <div 
            style={{ 
              background: "linear-gradient(135deg, #FAF7F2 0%, #F5EEE6 100%)",
              borderRadius: "12px",
              padding: "24px",
              margin: styles.margin || "16px 32px",
            }}
          >
            {content.title && (
              <h3 style={{ margin: "0 0 20px 0", fontSize: "18px", fontWeight: 600, color: "#8B7355", textAlign: "center" as const, fontFamily: baseStyles.fontFamily }}>
                {content.title}
              </h3>
            )}
            <div style={{ display: "flex", flexWrap: "wrap" as const, gap: "16px", justifyContent: "center" }}>
              {benefits.map((benefit: { icon: string; title: string; description: string }, index: number) => (
                <div key={index} style={{ flex: "1 1 140px", maxWidth: "200px", textAlign: "center" as const }}>
                  <div style={{ fontSize: "32px", marginBottom: "8px" }}>{benefit.icon}</div>
                  <h4 style={{ margin: "0 0 4px 0", fontSize: "16px", fontWeight: 600, color: "#3D3D3D", fontFamily: baseStyles.fontFamily }}>
                    {benefit.title}
                  </h4>
                  <p style={{ margin: 0, fontSize: "14px", color: "#6B6B6B", fontFamily: baseStyles.fontFamily }}>
                    {benefit.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        );

      case "event-card":
        return (
          <div 
            style={{ 
              background: "#FFFFFF",
              border: "1px solid #E8E0D8",
              borderRadius: "12px",
              overflow: "hidden",
              margin: styles.margin || "16px 32px",
            }}
          >
            <div style={{ background: "#8B7355", padding: "16px", color: "#FFFFFF", textAlign: "center" as const }}>
              <p style={{ margin: 0, fontSize: "14px", fontWeight: 500, fontFamily: baseStyles.fontFamily }}>
                {content.title || "Kommende kurs"}
              </p>
            </div>
            <div style={{ padding: "24px", textAlign: "center" as const }}>
              <h3 style={{ margin: "0 0 16px 0", fontSize: "22px", fontWeight: 600, color: "#3D3D3D", fontFamily: baseStyles.fontFamily }}>
                {content.eventName || "Arrangementnavn"}
              </h3>
              <p style={{ margin: "0 0 8px 0", fontSize: "16px", color: "#8B7355", fontFamily: baseStyles.fontFamily }}>
                📅 {content.date || "Dato"} • ⏰ {content.time || "Tid"}
              </p>
              {content.location && (
                <p style={{ margin: "0 0 16px 0", fontSize: "14px", color: "#6B6B6B", fontFamily: baseStyles.fontFamily }}>
                  📍 {content.location}
                </p>
              )}
              {content.ctaText && (
                <a
                  href={content.ctaUrl || "#"}
                  style={{
                    display: "inline-block",
                    padding: "12px 24px",
                    background: "linear-gradient(135deg, #8B7355 0%, #6B5440 100%)",
                    color: "#FFFFFF",
                    textDecoration: "none",
                    borderRadius: "8px",
                    fontWeight: 600,
                    fontSize: "14px",
                    fontFamily: baseStyles.fontFamily,
                  }}
                >
                  {content.ctaText}
                </a>
              )}
            </div>
          </div>
        );

      case "campaign-banner":
        const bannerBgColor = content.backgroundColor || "#8B7355";
        const bannerTextColor = content.textColor || "#FFFFFF";
        return (
          <div 
            style={{ 
              background: bannerBgColor,
              borderRadius: "12px",
              padding: "32px",
              margin: styles.margin || "16px 32px",
              textAlign: "center" as const,
            }}
          >
            <h2 style={{ margin: "0 0 8px 0", fontSize: "28px", fontWeight: 700, color: bannerTextColor, fontFamily: baseStyles.fontFamily }}>
              {content.title || "Kampanjetittel"}
            </h2>
            {content.subtitle && (
              <p style={{ margin: "0 0 16px 0", fontSize: "18px", color: bannerTextColor, opacity: 0.9, fontFamily: baseStyles.fontFamily }}>
                {content.subtitle}
              </p>
            )}
            {content.ctaText && (
              <a
                href={content.ctaUrl || "#"}
                style={{
                  display: "inline-block",
                  padding: "12px 28px",
                  background: "#FFFFFF",
                  color: bannerBgColor,
                  textDecoration: "none",
                  borderRadius: "8px",
                  fontWeight: 600,
                  fontSize: "16px",
                  fontFamily: baseStyles.fontFamily,
                }}
              >
                {content.ctaText}
              </a>
            )}
          </div>
        );

      case "otp-box":
        return (
          <div style={{ padding: styles.padding || "24px 32px", textAlign: "center" as const }}>
            <div 
              style={{ 
                background: "linear-gradient(135deg, #FAF7F2 0%, #F5EEE6 100%)",
                borderRadius: "16px",
                padding: "32px",
                display: "inline-block",
              }}
            >
              <p style={{ 
                margin: "0 0 12px 0",
                fontSize: "14px",
                color: "#8B7355",
                fontWeight: 500,
                textTransform: "uppercase" as const,
                letterSpacing: "1px",
                fontFamily: baseStyles.fontFamily,
              }}>
                {content.label || "Din engangskode"}
              </p>
              <p style={{ 
                margin: "16px 0",
                fontSize: "42px",
                fontWeight: 700,
                letterSpacing: "12px",
                color: "#3D3D3D",
                fontFamily: "monospace",
              }}>
                {content.code || "------"}
              </p>
              <p style={{ 
                margin: "16px 0 0 0",
                fontSize: "14px",
                color: "#888",
                fontFamily: baseStyles.fontFamily,
              }}>
                Koden er gyldig i {content.expiryMinutes || 10} minutter
              </p>
            </div>
          </div>
        );

      case "agreement-box":
        return (
          <div style={{ padding: styles.padding || "16px 32px" }}>
            <div 
              style={{ 
                background: "#F8F9FA",
                border: "2px dashed #E5E7EB",
                borderRadius: "12px",
                padding: "24px",
                textAlign: "center" as const,
              }}
            >
              <p style={{ 
                margin: "0 0 8px 0",
                fontSize: "13px",
                color: "#6B7280",
                textTransform: "uppercase" as const,
                letterSpacing: "1px",
                fontFamily: baseStyles.fontFamily,
              }}>
                {content.label || "Avtalenummer"}
              </p>
              <p style={{ 
                margin: 0,
                fontSize: "32px",
                fontWeight: 700,
                letterSpacing: "2px",
                color: "#3D3D3D",
                fontFamily: "monospace",
              }}>
                {content.value || "{avtalenummer}"}
              </p>
            </div>
          </div>
        );

      case "date-highlight":
        return (
          <div 
            style={{ 
              background: "linear-gradient(135deg, #FEF3C7 0%, #FDE68A 100%)",
              borderRadius: "12px",
              padding: "20px",
              margin: styles.margin || "16px 32px",
              textAlign: "center" as const,
            }}
          >
            <p style={{ margin: "0 0 4px 0", fontSize: "14px", color: "#92400E", fontWeight: 500, fontFamily: baseStyles.fontFamily }}>
              {content.label || ""}
            </p>
            <p style={{ margin: 0, fontSize: "24px", fontWeight: 700, color: "#78350F", fontFamily: baseStyles.fontFamily }}>
              {content.date || ""}
            </p>
          </div>
        );

      case "contact-box":
        return (
          <div style={{ padding: styles.padding || "24px 32px" }}>
            <div style={{ borderTop: "1px solid #E5E7EB", paddingTop: "24px" }}>
              <p style={{ margin: "0 0 8px 0", fontSize: "16px", color: "#8B7355", fontWeight: 600, fontFamily: baseStyles.fontFamily }}>
                💬 {content.title || "Spørsmål om helseforsikringen?"}
              </p>
              <p style={{ margin: 0, fontSize: "16px", color: "#3D3D3D", fontFamily: baseStyles.fontFamily }}>
                {content.description || "Kontakt ERGO på"} <strong>{content.phone || "800 83 313"}</strong> eller{" "}
                <a href={`mailto:${content.email || "infohelse@ergo.no"}`} style={{ color: "#8B7355" }}>
                  {content.email || "infohelse@ergo.no"}
                </a>
              </p>
            </div>
          </div>
        );

      case "salon-info":
        return (
          <div 
            style={{ 
              background: "#FAF7F2",
              borderRadius: "8px",
              padding: "20px",
              margin: styles.margin || "16px 32px",
            }}
          >
            {content.salonName && <p style={{ margin: "0 0 8px 0", fontFamily: baseStyles.fontFamily }}><strong>Salongnavn:</strong> {content.salonName}</p>}
            {content.orgNumber && <p style={{ margin: "0 0 8px 0", fontFamily: baseStyles.fontFamily }}><strong>Org.nummer:</strong> {content.orgNumber}</p>}
            {content.contactName && <p style={{ margin: "0 0 8px 0", fontFamily: baseStyles.fontFamily }}><strong>Kontaktperson:</strong> {content.contactName}</p>}
            {content.email && <p style={{ margin: "0 0 8px 0", fontFamily: baseStyles.fontFamily }}><strong>E-post:</strong> {content.email}</p>}
            {content.phone && <p style={{ margin: 0, fontFamily: baseStyles.fontFamily }}><strong>Telefon:</strong> {content.phone}</p>}
          </div>
        );

      default:
        return (
          <div style={{ padding: "24px", textAlign: "center" as const, color: "#8B8B8B" }}>
            Ukjent modultype: {type}
          </div>
        );
    }
  };

  return renderModule();
}
