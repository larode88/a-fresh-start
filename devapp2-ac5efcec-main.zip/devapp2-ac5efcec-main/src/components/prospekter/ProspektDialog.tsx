import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Loader2, Search, Building2, MapPin, User, BarChart3, FileText, TrendingUp, TrendingDown } from "lucide-react";
import { lookupOrgNumber, lookupFinancials, formatCurrency } from "@/lib/brreg";
import { useAuth } from "@/hooks/useAuth";
import { useUserRole } from "@/hooks/useUserRole";

type PipelineStatus = "identifisert" | "kontaktet" | "forste_mote" | "pagaende_dialog" | "forhandling" | "klar_for_innmelding";
type Sannsynlighet = "lav" | "medium" | "stor";
type TypeMedlemskap = "salong" | "skole" | "stol" | "hjemmesalong" | "barber";

interface ProspektDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  prospekt?: any;
  defaultDistrictId?: string;
}

const pipelineStatuses = [
  { value: "identifisert", label: "Identifisert" },
  { value: "kontaktet", label: "Kontaktet" },
  { value: "forste_mote", label: "Første møte" },
  { value: "pagaende_dialog", label: "Pågående dialog" },
  { value: "forhandling", label: "Forhandling" },
  { value: "klar_for_innmelding", label: "Klar for innmelding" },
];

const sannsynligheter = [
  { value: "lav", label: "Lav" },
  { value: "medium", label: "Medium" },
  { value: "stor", label: "Stor" },
];

const typeMedlemskap = [
  { value: "salong", label: "Salong" },
  { value: "skole", label: "Skole" },
  { value: "stol", label: "Stolleie" },
  { value: "hjemmesalong", label: "Hjemmesalong" },
  { value: "barber", label: "Barber" },
];

export function ProspektDialog({ open, onOpenChange, prospekt, defaultDistrictId }: ProspektDialogProps) {
  const { user } = useAuth();
  const { isAdmin } = useUserRole();
  const queryClient = useQueryClient();
  const [isLookingUp, setIsLookingUp] = useState(false);
  const [formData, setFormData] = useState({
    salongnavn: "",
    org_nummer: "",
    kontaktperson_navn: "",
    kontaktperson_epost: "",
    kontaktperson_telefon: "",
    adresse: "",
    postnummer: "",
    sted: "",
    district_id: defaultDistrictId || "",
    pipeline_status: "identifisert",
    sannsynlighet: "medium",
    forventet_innmeldingsdato: "",
    estimert_medlemsavgift: "",
    type_medlemskap: "",
    kilde: "",
    eksisterende_tjenester: "",
    notater: "",
    antall_ansatte: "",
    sum_driftsinntekter: "",
    sum_driftskostnad: "",
    driftsresultat: "",
    regnskapsaar: "",
  });

  // Fetch user's district
  const { data: userData } = useQuery({
    queryKey: ["user-district", user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      const { data, error } = await supabase
        .from("users")
        .select("district_id")
        .eq("id", user.id)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!user?.id,
  });

  useEffect(() => {
    if (prospekt) {
      setFormData({
        salongnavn: prospekt.salongnavn || "",
        org_nummer: prospekt.org_nummer || "",
        kontaktperson_navn: prospekt.kontaktperson_navn || "",
        kontaktperson_epost: prospekt.kontaktperson_epost || "",
        kontaktperson_telefon: prospekt.kontaktperson_telefon || "",
        adresse: prospekt.adresse || "",
        postnummer: prospekt.postnummer || "",
        sted: prospekt.sted || "",
        district_id: prospekt.district_id || defaultDistrictId || "",
        pipeline_status: prospekt.pipeline_status || "identifisert",
        sannsynlighet: prospekt.sannsynlighet || "medium",
        forventet_innmeldingsdato: prospekt.forventet_innmeldingsdato || "",
        estimert_medlemsavgift: prospekt.estimert_medlemsavgift?.toString() || "",
        type_medlemskap: prospekt.type_medlemskap || "",
        kilde: prospekt.kilde || "",
        eksisterende_tjenester: prospekt.eksisterende_tjenester || "",
        notater: prospekt.notater || "",
        antall_ansatte: prospekt.antall_ansatte?.toString() || "",
        sum_driftsinntekter: prospekt.sum_driftsinntekter?.toString() || "",
        sum_driftskostnad: prospekt.sum_driftskostnad?.toString() || "",
        driftsresultat: prospekt.driftsresultat?.toString() || "",
        regnskapsaar: prospekt.regnskapsaar?.toString() || "",
      });
    } else {
      const autoDistrictId = defaultDistrictId || userData?.district_id || "";
      setFormData({
        salongnavn: "",
        org_nummer: "",
        kontaktperson_navn: "",
        kontaktperson_epost: "",
        kontaktperson_telefon: "",
        adresse: "",
        postnummer: "",
        sted: "",
        district_id: autoDistrictId,
        pipeline_status: "identifisert",
        sannsynlighet: "medium",
        forventet_innmeldingsdato: "",
        estimert_medlemsavgift: "",
        type_medlemskap: "",
        kilde: "",
        eksisterende_tjenester: "",
        notater: "",
        antall_ansatte: "",
        sum_driftsinntekter: "",
        sum_driftskostnad: "",
        driftsresultat: "",
        regnskapsaar: "",
      });
    }
  }, [prospekt, defaultDistrictId, open, userData?.district_id]);

  const { data: districts } = useQuery({
    queryKey: ["districts"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("districts")
        .select("id, name")
        .order("name");
      if (error) throw error;
      return data;
    },
  });

  const saveMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const payload = {
        salongnavn: data.salongnavn,
        org_nummer: data.org_nummer || null,
        kontaktperson_navn: data.kontaktperson_navn || null,
        kontaktperson_epost: data.kontaktperson_epost || null,
        kontaktperson_telefon: data.kontaktperson_telefon || null,
        adresse: data.adresse || null,
        postnummer: data.postnummer || null,
        sted: data.sted || null,
        district_id: data.district_id || null,
        pipeline_status: data.pipeline_status as PipelineStatus,
        sannsynlighet: data.sannsynlighet as Sannsynlighet,
        forventet_innmeldingsdato: data.forventet_innmeldingsdato || null,
        estimert_medlemsavgift: data.estimert_medlemsavgift ? parseFloat(data.estimert_medlemsavgift) : null,
        type_medlemskap: (data.type_medlemskap || null) as TypeMedlemskap | null,
        kilde: data.kilde || null,
        eksisterende_tjenester: data.eksisterende_tjenester || null,
        notater: data.notater || null,
        antall_ansatte: data.antall_ansatte ? parseInt(data.antall_ansatte) : null,
        sum_driftsinntekter: data.sum_driftsinntekter ? parseFloat(data.sum_driftsinntekter) : null,
        sum_driftskostnad: data.sum_driftskostnad ? parseFloat(data.sum_driftskostnad) : null,
        driftsresultat: data.driftsresultat ? parseFloat(data.driftsresultat) : null,
        regnskapsaar: data.regnskapsaar ? parseInt(data.regnskapsaar) : null,
      };

      if (prospekt?.id) {
        const { error } = await supabase
          .from("prospekter")
          .update(payload)
          .eq("id", prospekt.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from("prospekter")
          .insert(payload);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["prospekter"] });
      toast.success(prospekt ? "Prospekt oppdatert" : "Prospekt opprettet");
      onOpenChange(false);
    },
    onError: (error) => {
      toast.error("Kunne ikke lagre prospekt: " + error.message);
    },
  });

  const handleBrregLookup = async () => {
    if (!formData.org_nummer || formData.org_nummer.replace(/\s/g, '').length < 9) {
      toast.error("Skriv inn et gyldig organisasjonsnummer");
      return;
    }

    setIsLookingUp(true);
    try {
      const cleanedOrg = formData.org_nummer.replace(/\s/g, "");
      
      const [company, financials] = await Promise.all([
        lookupOrgNumber(cleanedOrg),
        lookupFinancials(cleanedOrg)
      ]);

      if (company) {
        setFormData((prev) => ({
          ...prev,
          salongnavn: company.juridiskNavn || prev.salongnavn,
          adresse: company.adresse?.gate || prev.adresse,
          postnummer: company.adresse?.postnummer || prev.postnummer,
          sted: company.adresse?.poststed || prev.sted,
          sum_driftsinntekter: financials?.sumDriftsinntekter?.toString() || prev.sum_driftsinntekter,
          sum_driftskostnad: financials?.sumDriftskostnad?.toString() || prev.sum_driftskostnad,
          driftsresultat: financials?.driftsresultat?.toString() || prev.driftsresultat,
          regnskapsaar: financials?.regnskapsaar?.toString() || prev.regnskapsaar,
        }));
        
        if (financials?.regnskapsaar) {
          toast.success(`Hentet data fra BRREG (regnskap ${financials.regnskapsaar})`);
        } else {
          toast.success("Hentet bedriftsinfo fra BRREG (ingen regnskapsdata funnet)");
        }
      }
    } catch (error) {
      toast.error("Kunne ikke hente data fra BRREG");
    } finally {
      setIsLookingUp(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.salongnavn.trim()) {
      toast.error("Salongnavn er påkrevd");
      return;
    }
    saveMutation.mutate(formData);
  };

  const hasFinancialData = formData.regnskapsaar && (formData.sum_driftsinntekter || formData.driftsresultat);

  const SectionHeader = ({ icon: Icon, title }: { icon: any; title: string }) => (
    <div className="flex items-center gap-2 pb-2 border-b border-border/50">
      <Icon className="h-4 w-4 text-muted-foreground" />
      <span className="text-sm font-medium text-muted-foreground">{title}</span>
    </div>
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{prospekt ? "Rediger prospekt" : "Nytt prospekt"}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* SEKSJON 1: Bedriftsinformasjon */}
          <div className="space-y-3 bg-muted/30 rounded-lg p-4">
            <SectionHeader icon={Building2} title="Bedriftsinformasjon" />
            
            <div className="grid grid-cols-[1fr,auto] gap-2">
              <div className="space-y-1">
                <Label className="text-xs">Org.nummer</Label>
                <Input
                  value={formData.org_nummer}
                  onChange={(e) => setFormData({ ...formData, org_nummer: e.target.value })}
                  placeholder="123 456 789"
                  className="h-9"
                />
              </div>
              <div className="flex items-end">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={handleBrregLookup}
                  disabled={isLookingUp}
                  className="h-9"
                >
                  {isLookingUp ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
                </Button>
              </div>
            </div>

            <div className="space-y-1">
              <Label className="text-xs">Salongnavn *</Label>
              <Input
                value={formData.salongnavn}
                onChange={(e) => setFormData({ ...formData, salongnavn: e.target.value })}
                placeholder="Navn på salong"
                className="h-9"
                required
              />
            </div>

            {/* Regnskapsdata */}
            {hasFinancialData && (
              <div className="bg-background rounded-md p-3 border">
                <div className="text-xs text-muted-foreground mb-2">Regnskap {formData.regnskapsaar}</div>
                <div className="grid grid-cols-3 gap-3 text-xs">
                  <div>
                    <div className="text-muted-foreground">Omsetning</div>
                    <div className="font-medium">{formatCurrency(parseFloat(formData.sum_driftsinntekter || "0"))}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground">Kostnad</div>
                    <div className="font-medium">{formatCurrency(parseFloat(formData.sum_driftskostnad || "0"))}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground">Resultat</div>
                    <div className={`font-medium flex items-center gap-1 ${parseFloat(formData.driftsresultat || "0") >= 0 ? "text-green-600" : "text-red-600"}`}>
                      {parseFloat(formData.driftsresultat || "0") >= 0 ? (
                        <TrendingUp className="h-3 w-3" />
                      ) : (
                        <TrendingDown className="h-3 w-3" />
                      )}
                      {formatCurrency(parseFloat(formData.driftsresultat || "0"))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            <div className="space-y-1">
              <Label className="text-xs">Antall ansatte</Label>
              <Input
                type="number"
                value={formData.antall_ansatte}
                onChange={(e) => setFormData({ ...formData, antall_ansatte: e.target.value })}
                placeholder="0"
                className="h-9 w-24"
              />
            </div>
          </div>

          {/* SEKSJON 2: Lokasjon */}
          <div className="space-y-3 bg-muted/30 rounded-lg p-4">
            <SectionHeader icon={MapPin} title="Lokasjon" />
            
            <div className="grid grid-cols-[2fr,1fr,1fr] gap-2">
              <div className="space-y-1">
                <Label className="text-xs">Adresse</Label>
                <Input
                  value={formData.adresse}
                  onChange={(e) => setFormData({ ...formData, adresse: e.target.value })}
                  placeholder="Gateadresse"
                  className="h-9"
                />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Postnr.</Label>
                <Input
                  value={formData.postnummer}
                  onChange={(e) => setFormData({ ...formData, postnummer: e.target.value })}
                  placeholder="0000"
                  className="h-9"
                />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Sted</Label>
                <Input
                  value={formData.sted}
                  onChange={(e) => setFormData({ ...formData, sted: e.target.value })}
                  placeholder="By"
                  className="h-9"
                />
              </div>
            </div>
          </div>

          {/* SEKSJON 3: Kontaktperson */}
          <div className="space-y-3 bg-muted/30 rounded-lg p-4">
            <SectionHeader icon={User} title="Kontaktperson" />
            
            <div className="grid grid-cols-3 gap-2">
              <div className="space-y-1">
                <Label className="text-xs">Navn</Label>
                <Input
                  value={formData.kontaktperson_navn}
                  onChange={(e) => setFormData({ ...formData, kontaktperson_navn: e.target.value })}
                  placeholder="Navn"
                  className="h-9"
                />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">E-post</Label>
                <Input
                  type="email"
                  value={formData.kontaktperson_epost}
                  onChange={(e) => setFormData({ ...formData, kontaktperson_epost: e.target.value })}
                  placeholder="epost@eksempel.no"
                  className="h-9"
                />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Telefon</Label>
                <Input
                  value={formData.kontaktperson_telefon}
                  onChange={(e) => setFormData({ ...formData, kontaktperson_telefon: e.target.value })}
                  placeholder="12345678"
                  className="h-9"
                />
              </div>
            </div>
          </div>

          {/* SEKSJON 4: Pipeline & Kvalifisering */}
          <div className="space-y-3 bg-muted/30 rounded-lg p-4">
            <SectionHeader icon={BarChart3} title="Pipeline & Kvalifisering" />
            
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-xs">Type medlemskap</Label>
                <Select
                  value={formData.type_medlemskap}
                  onValueChange={(value) => setFormData({ ...formData, type_medlemskap: value })}
                >
                  <SelectTrigger className="h-9">
                    <SelectValue placeholder="Velg type" />
                  </SelectTrigger>
                  <SelectContent>
                    {typeMedlemskap.map((t) => (
                      <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Distrikt</Label>
                <Select
                  value={formData.district_id}
                  onValueChange={(value) => setFormData({ ...formData, district_id: value })}
                  disabled={!isAdmin && !!userData?.district_id}
                >
                  <SelectTrigger className="h-9">
                    <SelectValue placeholder="Velg distrikt" />
                  </SelectTrigger>
                  <SelectContent>
                    {districts?.map((d) => (
                      <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-xs">Pipeline-status</Label>
                <Select
                  value={formData.pipeline_status}
                  onValueChange={(value) => setFormData({ ...formData, pipeline_status: value })}
                >
                  <SelectTrigger className="h-9">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {pipelineStatuses.map((s) => (
                      <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Sannsynlighet</Label>
                <Select
                  value={formData.sannsynlighet}
                  onValueChange={(value) => setFormData({ ...formData, sannsynlighet: value })}
                >
                  <SelectTrigger className="h-9">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {sannsynligheter.map((s) => (
                      <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-xs">Forventet innmelding</Label>
                <Input
                  type="date"
                  value={formData.forventet_innmeldingsdato}
                  onChange={(e) => setFormData({ ...formData, forventet_innmeldingsdato: e.target.value })}
                  className="h-9"
                />
              </div>
              <div className="space-y-1">
                <Label className="text-xs">Estimert avgift (kr/år)</Label>
                <Input
                  type="number"
                  value={formData.estimert_medlemsavgift}
                  onChange={(e) => setFormData({ ...formData, estimert_medlemsavgift: e.target.value })}
                  placeholder="0"
                  className="h-9"
                />
              </div>
            </div>
          </div>

          {/* SEKSJON 5: Notater & Kilde */}
          <div className="space-y-3 bg-muted/30 rounded-lg p-4">
            <SectionHeader icon={FileText} title="Notater & Kilde" />
            
            <div className="space-y-1">
              <Label className="text-xs">Kilde</Label>
              <Input
                value={formData.kilde}
                onChange={(e) => setFormData({ ...formData, kilde: e.target.value })}
                placeholder="F.eks. messe, anbefaling, nettside..."
                className="h-9"
              />
            </div>

            <div className="space-y-1">
              <Label className="text-xs">Notater</Label>
              <Textarea
                value={formData.notater}
                onChange={(e) => setFormData({ ...formData, notater: e.target.value })}
                placeholder="Interne notater..."
                rows={2}
                className="resize-none"
              />
            </div>
          </div>

          <DialogFooter className="pt-2">
            <Button type="button" variant="outline" size="sm" onClick={() => onOpenChange(false)}>
              Avbryt
            </Button>
            <Button type="submit" size="sm" disabled={saveMutation.isPending}>
              {saveMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              {prospekt ? "Lagre" : "Opprett"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
