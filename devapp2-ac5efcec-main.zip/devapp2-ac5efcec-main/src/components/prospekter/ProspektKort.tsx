import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users, Calendar } from "lucide-react";
import { format } from "date-fns";
import { nb } from "date-fns/locale";
import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { formatCurrency } from "@/lib/brreg";

interface Prospekt {
  id: string;
  salongnavn: string;
  org_nummer?: string;
  kontaktperson_navn?: string;
  kontaktperson_epost?: string;
  kontaktperson_telefon?: string;
  pipeline_status: string;
  sannsynlighet?: string;
  forventet_innmeldingsdato?: string;
  estimert_medlemsavgift?: number;
  type_medlemskap?: string;
  sted?: string;
  districts?: { name: string } | null;
  antall_ansatte?: number;
  sum_driftsinntekter?: number;
  sum_driftskostnad?: number;
  driftsresultat?: number;
  regnskapsaar?: number;
}

interface ProspektKortProps {
  prospekt: Prospekt;
  onClick: () => void;
}

const sannsynlighetConfig: Record<string, { label: string; variant: "default" | "secondary" | "destructive" | "outline" }> = {
  stor: { label: "Stor", variant: "default" },
  medium: { label: "Medium", variant: "secondary" },
  lav: { label: "Lav", variant: "outline" },
};

export function ProspektKort({ prospekt, onClick }: ProspektKortProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: prospekt.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  return (
    <Card
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
      className="cursor-grab active:cursor-grabbing hover:shadow-md transition-shadow"
      onClick={onClick}
    >
      <CardContent className="p-2 space-y-1.5">
        {/* Header */}
        <div className="flex items-start justify-between gap-1">
          <div className="min-w-0 flex-1">
            <p className="font-medium text-xs leading-tight break-words hyphens-auto">{prospekt.salongnavn}</p>
            {prospekt.sted && (
              <p className="text-[10px] text-muted-foreground">{prospekt.sted}</p>
            )}
          </div>
          {prospekt.sannsynlighet && (
            <Badge 
              variant={sannsynlighetConfig[prospekt.sannsynlighet]?.variant || "outline"} 
              className="shrink-0 text-[10px] px-1.5 py-0 ml-1"
            >
              {sannsynlighetConfig[prospekt.sannsynlighet]?.label || prospekt.sannsynlighet}
            </Badge>
          )}
        </div>

        {/* Ansatte */}
        {prospekt.antall_ansatte && (
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <Users className="h-3 w-3" />
            <span>{prospekt.antall_ansatte} ansatte</span>
          </div>
        )}


        {/* Footer */}
        <div className="flex items-center justify-between text-[10px] text-muted-foreground pt-1 border-t">
          {prospekt.forventet_innmeldingsdato ? (
            <div className="flex items-center gap-1">
              <Calendar className="h-2.5 w-2.5" />
              <span>{format(new Date(prospekt.forventet_innmeldingsdato), "d. MMM", { locale: nb })}</span>
            </div>
          ) : (
            <span>-</span>
          )}
          {prospekt.estimert_medlemsavgift ? (
            <span className="font-medium">{formatCurrency(prospekt.estimert_medlemsavgift)}/år</span>
          ) : null}
        </div>
      </CardContent>
    </Card>
  );
}
