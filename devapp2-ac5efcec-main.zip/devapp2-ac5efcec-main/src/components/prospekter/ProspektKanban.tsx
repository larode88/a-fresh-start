import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { 
  DndContext, 
  DragEndEvent, 
  DragOverlay, 
  closestCenter,
  PointerSensor, 
  useSensor, 
  useSensors,
  useDroppable
} from "@dnd-kit/core";
import { SortableContext, verticalListSortingStrategy } from "@dnd-kit/sortable";
import { ProspektKort } from "./ProspektKort";
import { ProspektDialog } from "./ProspektDialog";
import { ProspektDetaljer } from "./ProspektDetaljer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Plus, Filter } from "lucide-react";
import { toast } from "sonner";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useUserRole } from "@/hooks/useUserRole";

interface ProspektKanbanProps {
  districtId?: string;
  userDistrictId?: string;
}

const pipelineColumns = [
  { id: "identifisert", label: "Identifisert", color: "bg-slate-100" },
  { id: "kontaktet", label: "Kontaktet", color: "bg-blue-50" },
  { id: "forste_mote", label: "Første møte", color: "bg-indigo-50" },
  { id: "pagaende_dialog", label: "Pågående dialog", color: "bg-purple-50" },
  { id: "klar_for_innmelding", label: "Klar for innmelding", color: "bg-green-50" },
];

// Droppable column component
function DroppableColumn({ 
  id, 
  label, 
  color, 
  prospekter, 
  onProspektClick 
}: { 
  id: string; 
  label: string; 
  color: string; 
  prospekter: any[]; 
  onProspektClick: (p: any) => void;
}) {
  const { setNodeRef, isOver } = useDroppable({ id });

  return (
    <div ref={setNodeRef} className="flex flex-col h-full">
      <Card className={`flex-1 ${color} ${isOver ? 'ring-2 ring-primary ring-offset-2' : ''} transition-all`}>
        <CardHeader className="pb-2 px-2 pt-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-xs font-medium">{label}</CardTitle>
            <Badge variant="secondary" className="text-[10px] h-5">
              {prospekter.length}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="px-1.5 pb-1.5">
          <SortableContext
            id={id}
            items={prospekter.map((p) => p.id)}
            strategy={verticalListSortingStrategy}
          >
            <ScrollArea className="h-[520px]">
              <div className="space-y-1.5 p-0.5">
                {prospekter.map((prospekt) => (
                  <ProspektKort
                    key={prospekt.id}
                    prospekt={prospekt}
                    onClick={() => onProspektClick(prospekt)}
                  />
                ))}
                {prospekter.length === 0 && (
                  <div className="text-center text-xs text-muted-foreground py-8">
                    Dra prospekter hit
                  </div>
                )}
              </div>
            </ScrollArea>
          </SortableContext>
        </CardContent>
      </Card>
    </div>
  );
}

export function ProspektKanban({ districtId, userDistrictId }: ProspektKanbanProps) {
  const queryClient = useQueryClient();
  const { isAdmin, isDistrictManager } = useUserRole();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedProspekt, setSelectedProspekt] = useState<any>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [activeId, setActiveId] = useState<string | null>(null);
  
  // For district managers, always use their own district. For admins, default to "all"
  const [filterDistrict, setFilterDistrict] = useState<string>(
    isDistrictManager && userDistrictId ? userDistrictId : (districtId || "all")
  );

  // Update filter when userDistrictId loads for district managers
  useEffect(() => {
    if (isDistrictManager && userDistrictId && filterDistrict === "all") {
      setFilterDistrict(userDistrictId);
    }
  }, [isDistrictManager, userDistrictId, filterDistrict]);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    })
  );

  const { data: districts } = useQuery({
    queryKey: ["districts"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("districts")
        .select("id, name")
        .order("name");
      if (error) throw error;
      return data;
    },
  });

  const { data: prospekter, isLoading } = useQuery({
    queryKey: ["prospekter", filterDistrict],
    queryFn: async () => {
      let query = supabase
        .from("prospekter")
        .select(`
          *,
          districts(name)
        `)
        .is("archived_at", null)
        .not("pipeline_status", "in", "(vunnet,tapt)")
        .order("created_at", { ascending: false });

      if (filterDistrict && filterDistrict !== "all") {
        query = query.eq("district_id", filterDistrict);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data;
    },
  });

  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: string; status: string }) => {
      const { error } = await supabase
        .from("prospekter")
        .update({ pipeline_status: status as any })
        .eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["prospekter"] });
      toast.success("Status oppdatert");
    },
    onError: (error) => {
      toast.error("Kunne ikke oppdatere status: " + error.message);
    },
  });

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    setActiveId(null);

    if (!over) return;

    const prospektId = active.id as string;
    const overId = over.id as string;
    
    // Check if dropped on a column
    const targetColumn = pipelineColumns.find(c => c.id === overId);
    if (targetColumn) {
      const prospekt = prospekter?.find((p) => p.id === prospektId);
      if (prospekt && prospekt.pipeline_status !== overId) {
        updateStatusMutation.mutate({ id: prospektId, status: overId });
      }
    }
  };

  const handleDragStart = (event: any) => {
    setActiveId(event.active.id);
  };

  const getProspekterByStatus = (status: string) => {
    return prospekter?.filter((p) => p.pipeline_status === status) || [];
  };

  const handleProspektClick = (prospekt: any) => {
    setSelectedProspekt(prospekt);
    setDetailsOpen(true);
  };

  const activeProspekt = activeId ? prospekter?.find((p) => p.id === activeId) : null;

  const totalEstimert = prospekter?.reduce((sum, p) => sum + (p.estimert_medlemsavgift || 0), 0) || 0;

  // Get district name for display
  const userDistrictName = districts?.find(d => d.id === userDistrictId)?.name;

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          {isAdmin ? (
            <Select value={filterDistrict} onValueChange={setFilterDistrict}>
              <SelectTrigger className="w-[180px]">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Alle distrikter" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Alle distrikter</SelectItem>
                {districts?.map((d) => (
                  <SelectItem key={d.id} value={d.id}>{d.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          ) : (
            <div className="flex items-center gap-2 px-3 py-2 bg-muted rounded-md">
              <Filter className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium">{userDistrictName || "Mitt distrikt"}</span>
            </div>
          )}
          <div className="text-sm text-muted-foreground">
            {prospekter?.length || 0} prospekter • Est. {totalEstimert.toLocaleString("nb-NO")} kr
          </div>
        </div>
        <Button onClick={() => { setSelectedProspekt(null); setDialogOpen(true); }}>
          <Plus className="h-4 w-4 mr-2" />
          Nytt prospekt
        </Button>
      </div>

      {/* Kanban Board */}
      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragStart={handleDragStart}
        onDragEnd={handleDragEnd}
      >
        <div className="grid grid-cols-5 gap-2 min-h-[600px]">
          {pipelineColumns.map((column) => (
            <DroppableColumn
              key={column.id}
              id={column.id}
              label={column.label}
              color={column.color}
              prospekter={getProspekterByStatus(column.id)}
              onProspektClick={handleProspektClick}
            />
          ))}
        </div>

        <DragOverlay>
          {activeProspekt && (
            <div className="opacity-80">
              <ProspektKort prospekt={activeProspekt} onClick={() => {}} />
            </div>
          )}
        </DragOverlay>
      </DndContext>

      {/* Dialogs */}
      <ProspektDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        prospekt={selectedProspekt}
        defaultDistrictId={filterDistrict !== "all" ? filterDistrict : undefined}
      />

      <ProspektDetaljer
        open={detailsOpen}
        onOpenChange={setDetailsOpen}
        prospekt={selectedProspekt}
        onEdit={() => {
          setDetailsOpen(false);
          setDialogOpen(true);
        }}
      />
    </div>
  );
}
