import { useState } from "react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { format } from "date-fns";
import { nb } from "date-fns/locale";
import { 
  Edit, Phone, Mail, MapPin, Calendar, TrendingUp, TrendingDown, Building2, 
  User, FileText, MessageSquare, CheckCircle2, Users,
  Trophy, XCircle, Loader2, Archive
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { formatCurrency } from "@/lib/brreg";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";

interface ProspektDetaljerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  prospekt: any;
  onEdit: () => void;
}

const aktivitetTyper = [
  { value: "notat", label: "Notat", icon: FileText },
  { value: "telefon", label: "Telefonsamtale", icon: Phone },
  { value: "epost", label: "E-post", icon: Mail },
  { value: "mote", label: "Møte", icon: Calendar },
  { value: "oppgave", label: "Oppgave", icon: CheckCircle2 },
];

const sannsynlighetConfig: Record<string, { label: string; variant: "default" | "secondary" | "outline" }> = {
  stor: { label: "Stor sannsynlighet", variant: "default" },
  medium: { label: "Medium sannsynlighet", variant: "secondary" },
  lav: { label: "Lav sannsynlighet", variant: "outline" },
};

export function ProspektDetaljer({ open, onOpenChange, prospekt, onEdit }: ProspektDetaljerProps) {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [newAktivitet, setNewAktivitet] = useState({ type: "notat", beskrivelse: "" });

  const { data: aktiviteter, isLoading: aktiviteterLoading } = useQuery({
    queryKey: ["prospekt-aktiviteter", prospekt?.id],
    queryFn: async () => {
      if (!prospekt?.id) return [];
      const { data, error } = await supabase
        .from("prospekt_aktiviteter")
        .select(`
          *,
          users:utfort_av(name)
        `)
        .eq("prospekt_id", prospekt.id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
    enabled: !!prospekt?.id,
  });

  const addAktivitetMutation = useMutation({
    mutationFn: async () => {
      if (!newAktivitet.beskrivelse.trim()) throw new Error("Beskrivelse er påkrevd");
      const { error } = await supabase.from("prospekt_aktiviteter").insert({
        prospekt_id: prospekt.id,
        type: newAktivitet.type as any,
        beskrivelse: newAktivitet.beskrivelse,
        utfort_av: user?.id,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["prospekt-aktiviteter", prospekt?.id] });
      setNewAktivitet({ type: "notat", beskrivelse: "" });
      toast.success("Aktivitet lagt til");
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const markAsWonMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase
        .from("prospekter")
        .update({ pipeline_status: "vunnet" })
        .eq("id", prospekt.id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["prospekter"] });
      toast.success("Prospekt markert som vunnet!");
      onOpenChange(false);
    },
  });

  const markAsLostMutation = useMutation({
    mutationFn: async (tapt_arsak: string) => {
      const { error } = await supabase
        .from("prospekter")
        .update({ pipeline_status: "tapt", tapt_arsak })
        .eq("id", prospekt.id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["prospekter"] });
      toast.success("Prospekt markert som tapt");
      onOpenChange(false);
    },
  });

  const archiveMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase
        .from("prospekter")
        .update({ archived_at: new Date().toISOString() })
        .eq("id", prospekt.id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["prospekter"] });
      toast.success("Prospekt arkivert");
      onOpenChange(false);
    },
  });

  if (!prospekt) return null;

  const hasFinancials = prospekt.regnskapsaar && (prospekt.sum_driftsinntekter || prospekt.driftsresultat);

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent className="w-[500px] sm:max-w-[500px] p-0">
        <ScrollArea className="h-full">
          <div className="p-6 space-y-4">
            {/* Header */}
            <SheetHeader className="pb-2">
              <div className="flex items-start justify-between">
                <div>
                  <SheetTitle className="text-xl">{prospekt.salongnavn}</SheetTitle>
                  {prospekt.sted && (
                    <p className="text-sm text-muted-foreground flex items-center gap-1 mt-1">
                      <MapPin className="h-3 w-3" />
                      {prospekt.sted}
                    </p>
                  )}
                </div>
                <Button variant="outline" size="sm" onClick={onEdit}>
                  <Edit className="h-4 w-4 mr-1" />
                  Rediger
                </Button>
              </div>
              <div className="flex gap-2 mt-2">
                {prospekt.sannsynlighet && (
                  <Badge variant={sannsynlighetConfig[prospekt.sannsynlighet]?.variant}>
                    {sannsynlighetConfig[prospekt.sannsynlighet]?.label}
                  </Badge>
                )}
                {prospekt.type_medlemskap && (
                  <Badge variant="outline">{prospekt.type_medlemskap}</Badge>
                )}
              </div>
            </SheetHeader>

            {/* Kontaktinfo */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <User className="h-4 w-4" />
                  Kontaktperson
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                {prospekt.kontaktperson_navn && (
                  <p className="font-medium">{prospekt.kontaktperson_navn}</p>
                )}
                {prospekt.kontaktperson_telefon && (
                  <a href={`tel:${prospekt.kontaktperson_telefon}`} className="flex items-center gap-2 text-muted-foreground hover:text-foreground">
                    <Phone className="h-3 w-3" />
                    {prospekt.kontaktperson_telefon}
                  </a>
                )}
                {prospekt.kontaktperson_epost && (
                  <a href={`mailto:${prospekt.kontaktperson_epost}`} className="flex items-center gap-2 text-muted-foreground hover:text-foreground">
                    <Mail className="h-3 w-3" />
                    {prospekt.kontaktperson_epost}
                  </a>
                )}
                {!prospekt.kontaktperson_navn && !prospekt.kontaktperson_telefon && !prospekt.kontaktperson_epost && (
                  <p className="text-muted-foreground text-xs">Ingen kontaktinfo registrert</p>
                )}
              </CardContent>
            </Card>

            {/* Detaljer med regnskapsdata */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Building2 className="h-4 w-4" />
                  Detaljer
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                {prospekt.org_nummer && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Org.nr:</span>
                    <span>{prospekt.org_nummer}</span>
                  </div>
                )}
                {prospekt.adresse && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Adresse:</span>
                    <span>{prospekt.adresse}, {prospekt.postnummer} {prospekt.sted}</span>
                  </div>
                )}
                {prospekt.antall_ansatte && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Antall ansatte:</span>
                    <span className="flex items-center gap-1">
                      <Users className="h-3 w-3" />
                      {prospekt.antall_ansatte}
                    </span>
                  </div>
                )}
                {prospekt.forventet_innmeldingsdato && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Forventet innmelding:</span>
                    <span>{format(new Date(prospekt.forventet_innmeldingsdato), "d. MMMM yyyy", { locale: nb })}</span>
                  </div>
                )}
                {prospekt.estimert_medlemsavgift && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Estimert avgift:</span>
                    <span className="font-medium">{prospekt.estimert_medlemsavgift.toLocaleString("nb-NO")} kr/år</span>
                  </div>
                )}
                {prospekt.kilde && (
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Kilde:</span>
                    <span>{prospekt.kilde}</span>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Regnskapsmatrise */}
            {hasFinancials && (
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <TrendingUp className="h-4 w-4" />
                    Regnskap {prospekt.regnskapsaar}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  {prospekt.sum_driftsinntekter !== undefined && prospekt.sum_driftsinntekter !== null && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Sum driftsinntekter:</span>
                      <span>{formatCurrency(prospekt.sum_driftsinntekter)} kr</span>
                    </div>
                  )}
                  {prospekt.sum_driftskostnad !== undefined && prospekt.sum_driftskostnad !== null && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Sum driftskostnad:</span>
                      <span>{formatCurrency(prospekt.sum_driftskostnad)} kr</span>
                    </div>
                  )}
                  {prospekt.driftsresultat !== undefined && prospekt.driftsresultat !== null && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Driftsresultat:</span>
                      <span className={`flex items-center gap-1 font-medium ${prospekt.driftsresultat >= 0 ? "text-green-600" : "text-red-600"}`}>
                        {prospekt.driftsresultat >= 0 ? (
                          <TrendingUp className="h-3 w-3" />
                        ) : (
                          <TrendingDown className="h-3 w-3" />
                        )}
                        {formatCurrency(prospekt.driftsresultat)} kr
                      </span>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Notater */}
            {(prospekt.eksisterende_tjenester || prospekt.notater) && (
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    Notater
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  {prospekt.eksisterende_tjenester && (
                    <div>
                      <p className="text-muted-foreground text-xs mb-1">Eksisterende tjenester:</p>
                      <p>{prospekt.eksisterende_tjenester}</p>
                    </div>
                  )}
                  {prospekt.notater && (
                    <div>
                      <p className="text-muted-foreground text-xs mb-1">Notater:</p>
                      <p>{prospekt.notater}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Handlinger */}
            <div className="flex gap-2">
              <Button
                variant="default"
                className="flex-1"
                onClick={() => markAsWonMutation.mutate()}
                disabled={markAsWonMutation.isPending}
              >
                <Trophy className="h-4 w-4 mr-2" />
                Vunnet
              </Button>
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => {
                  const arsak = prompt("Hva var årsaken til at prospektet ble tapt?");
                  if (arsak) markAsLostMutation.mutate(arsak);
                }}
                disabled={markAsLostMutation.isPending}
              >
                <XCircle className="h-4 w-4 mr-2" />
                Tapt
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => archiveMutation.mutate()}
                disabled={archiveMutation.isPending}
              >
                <Archive className="h-4 w-4" />
              </Button>
            </div>

            <Separator />

            {/* Aktiviteter */}
            <div className="space-y-3">
              <h3 className="text-sm font-medium flex items-center gap-2">
                <MessageSquare className="h-4 w-4" />
                Aktivitetslogg ({aktiviteter?.length || 0})
              </h3>

              {/* Ny aktivitet */}
              <Card>
                <CardContent className="p-3 space-y-2">
                  <Select
                    value={newAktivitet.type}
                    onValueChange={(value) => setNewAktivitet({ ...newAktivitet, type: value })}
                  >
                    <SelectTrigger className="h-8 text-xs">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {aktivitetTyper.map((t) => (
                        <SelectItem key={t.value} value={t.value}>
                          <div className="flex items-center gap-2">
                            <t.icon className="h-3 w-3" />
                            {t.label}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Textarea
                    placeholder="Beskriv aktiviteten..."
                    value={newAktivitet.beskrivelse}
                    onChange={(e) => setNewAktivitet({ ...newAktivitet, beskrivelse: e.target.value })}
                    rows={2}
                    className="text-sm"
                  />
                  <Button
                    size="sm"
                    className="w-full"
                    onClick={() => addAktivitetMutation.mutate()}
                    disabled={addAktivitetMutation.isPending || !newAktivitet.beskrivelse.trim()}
                  >
                    {addAktivitetMutation.isPending ? (
                      <Loader2 className="h-3 w-3 animate-spin mr-2" />
                    ) : (
                      <MessageSquare className="h-3 w-3 mr-2" />
                    )}
                    Legg til
                  </Button>
                </CardContent>
              </Card>

              {/* Aktivitetslogg */}
              <div className="space-y-2">
                {aktiviteterLoading ? (
                  <div className="text-center py-4 text-muted-foreground">
                    <Loader2 className="h-5 w-5 animate-spin mx-auto" />
                  </div>
                ) : aktiviteter?.length === 0 ? (
                  <div className="text-center py-4 text-muted-foreground text-sm">
                    Ingen aktiviteter registrert ennå
                  </div>
                ) : (
                  aktiviteter?.map((aktivitet) => {
                    const TypeIcon = aktivitetTyper.find((a) => a.value === aktivitet.type)?.icon || FileText;
                    return (
                      <div key={aktivitet.id} className="flex items-start gap-3 p-2 rounded-lg bg-muted/50">
                        <div className="h-6 w-6 rounded-full bg-background flex items-center justify-center shrink-0">
                          <TypeIcon className="h-3 w-3" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm">{aktivitet.beskrivelse}</p>
                          <div className="flex items-center gap-2 mt-0.5 text-xs text-muted-foreground">
                            <span>{aktivitet.users?.name || "Ukjent"}</span>
                            <span>•</span>
                            <span>{format(new Date(aktivitet.created_at), "d. MMM yyyy HH:mm", { locale: nb })}</span>
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          </div>
        </ScrollArea>
      </SheetContent>
    </Sheet>
  );
}
