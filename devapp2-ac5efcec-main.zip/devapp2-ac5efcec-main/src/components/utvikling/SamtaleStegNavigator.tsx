import { cn } from "@/lib/utils";
import { CheckCircle2 } from "lucide-react";
import type { StegNotat } from "@/pages/hr/SamtaleGjennomforing";

interface Steg {
  id: number;
  navn: string;
  ikon: string;
  key: string;
}

interface SamtaleStegNavigatorProps {
  steg: Steg[];
  aktivtSteg: number;
  onStegChange: (stegId: number) => void;
  stegNotater: Record<string, StegNotat>;
}

export function SamtaleStegNavigator({ 
  steg, 
  aktivtSteg, 
  onStegChange,
  stegNotater 
}: SamtaleStegNavigatorProps) {
  const hasContent = (stegKey: string) => {
    const notat = stegNotater[stegKey];
    return notat?.notat && notat.notat.length > 0;
  };

  return (
    <nav className="px-2 pb-4">
      <ul className="space-y-1">
        {steg.map((s) => {
          const isActive = s.id === aktivtSteg;
          const isCompleted = hasContent(s.key);
          
          return (
            <li key={s.id}>
              <button
                onClick={() => onStegChange(s.id)}
                className={cn(
                  "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-left transition-colors",
                  isActive 
                    ? "bg-primary text-primary-foreground" 
                    : "hover:bg-accent",
                  isCompleted && !isActive && "text-muted-foreground"
                )}
              >
                <span className="text-lg">{s.ikon}</span>
                <span className="flex-1 text-sm font-medium">{s.navn}</span>
                {isCompleted && (
                  <CheckCircle2 className={cn(
                    "h-4 w-4",
                    isActive ? "text-primary-foreground" : "text-green-500"
                  )} />
                )}
              </button>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
