// Pulsundersøkelse planning component
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { 
  Plus, Activity, TrendingUp, TrendingDown, Minus, 
  Users, Calendar, BarChart3, RefreshCw, AlertTriangle, Sparkles
} from "lucide-react";
import { format, subDays } from "date-fns";
import { nb } from "date-fns/locale";
import { PulsundersokelseDialog } from "./PulsundersokelseDialog";
import { PulsAIAnalyseDialog } from "./PulsAIAnalyseDialog";
import { PulsKpiCard } from "./PulsKpiCard";
import { PulsTrendChart } from "./PulsTrendChart";
import { PulsTemaKpiGrid } from "./PulsTemaKpiGrid";
import { PulsTemaTrendChart } from "./PulsTemaTrendChart";
import { PulsRisikoPanel } from "./PulsRisikoPanel";
import { AutomatiskPulsOppsett } from "./AutomatiskPulsOppsett";
import { 
  type PulsTema, 
  type PulsSvar, 
  type PulsRisiko,
  type TemaStats,
  TEMA_CONFIG,
  calculateTemaStats 
} from "@/lib/pulsUtils";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface PulsundersokelsePlanleggerProps {
  salonId: string;
  canManage: boolean;
}

interface PulsStats {
  stemning: { avg: number; trend: number };
  energi: { avg: number; trend: number };
  mestring: { avg: number; trend: number };
  antallSvar: number;
  svarprosent: number;
}

export function PulsundersokelsePlanlegger({ salonId, canManage }: PulsundersokelsePlanleggerProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [aiDialogOpen, setAiDialogOpen] = useState(false);
  const [undersokelser, setUndersokelser] = useState<any[]>([]);
  const [svar, setSvar] = useState<PulsSvar[]>([]);
  const [stats, setStats] = useState<PulsStats | null>(null);
  const [temaStats, setTemaStats] = useState<TemaStats[]>([]);
  const [risikoer, setRisikoer] = useState<PulsRisiko[]>([]);
  const [ansatte, setAnsatte] = useState<number>(0);
  const [selectedTema, setSelectedTema] = useState<PulsTema | 'alle'>('alle');
  const [visning, setVisning] = useState<'standard' | 'tema'>('tema');

  const fetchData = async () => {
    setLoading(true);
    try {
      // Fetch undersokelser
      const { data: undersokelserData } = await supabase
        .from("pulsundersokelser")
        .select("*")
        .eq("salon_id", salonId)
        .eq("aktiv", true)
        .order("created_at", { ascending: false });

      setUndersokelser(undersokelserData || []);

      // Fetch svar from last 30 days
      const thirtyDaysAgo = format(subDays(new Date(), 30), "yyyy-MM-dd");
      
      if (undersokelserData && undersokelserData.length > 0) {
        const undersokelseIds = undersokelserData.map(u => u.id);
        const { data: svarData } = await supabase
          .from("pulsundersokelse_svar")
          .select("*")
          .in("undersokelse_id", undersokelseIds)
          .gte("dato", thirtyDaysAgo);

        setSvar(svarData || []);

        // Calculate standard stats
        if (svarData && svarData.length > 0) {
          const avgStemning = svarData.reduce((sum, s) => sum + s.stemning, 0) / svarData.length;
          const avgEnergi = svarData.reduce((sum, s) => sum + s.energi, 0) / svarData.length;
          const avgMestring = svarData.reduce((sum, s) => sum + s.mestring, 0) / svarData.length;

          const oneWeekAgo = format(subDays(new Date(), 7), "yyyy-MM-dd");
          const twoWeeksAgo = format(subDays(new Date(), 14), "yyyy-MM-dd");
          
          const lastWeek = svarData.filter(s => s.dato >= oneWeekAgo);
          const prevWeek = svarData.filter(s => s.dato >= twoWeeksAgo && s.dato < oneWeekAgo);

          const trendStemning = lastWeek.length > 0 && prevWeek.length > 0
            ? (lastWeek.reduce((sum, s) => sum + s.stemning, 0) / lastWeek.length) -
              (prevWeek.reduce((sum, s) => sum + s.stemning, 0) / prevWeek.length)
            : 0;
          const trendEnergi = lastWeek.length > 0 && prevWeek.length > 0
            ? (lastWeek.reduce((sum, s) => sum + s.energi, 0) / lastWeek.length) -
              (prevWeek.reduce((sum, s) => sum + s.energi, 0) / prevWeek.length)
            : 0;
          const trendMestring = lastWeek.length > 0 && prevWeek.length > 0
            ? (lastWeek.reduce((sum, s) => sum + s.mestring, 0) / lastWeek.length) -
              (prevWeek.reduce((sum, s) => sum + s.mestring, 0) / prevWeek.length)
            : 0;

          setStats({
            stemning: { avg: avgStemning, trend: trendStemning },
            energi: { avg: avgEnergi, trend: trendEnergi },
            mestring: { avg: avgMestring, trend: trendMestring },
            antallSvar: svarData.length,
            svarprosent: 0,
          });
        }
      }

      // Fetch risikoer
      const { data: risikoData } = await supabase
        .from("puls_risikologg")
        .select("*")
        .eq("salon_id", salonId)
        .order("created_at", { ascending: false });

      const typedRisikoer = (risikoData || []).map(r => ({
        ...r,
        status: r.status as 'ny' | 'under_behandling' | 'lukket'
      })) as PulsRisiko[];
      setRisikoer(typedRisikoer);

      // Build tema stats - for now use standard KPIs mapped to temaer
      const temaer: PulsTema[] = ['trivsel', 'arbeidsbelastning', 'psykologisk_trygghet', 'ledelse', 'hms_sikkerhet', 'utvikling'];
      const computedTemaStats: TemaStats[] = temaer.map(tema => {
        const temaRisikoer = typedRisikoer.filter(r => r.tema === tema && r.status !== 'lukket');
        const temaStatsCalc = calculateTemaStats(svar, tema);
        
        // Fallback for older data without tema
        let avg = temaStatsCalc.avg;
        let trend = temaStatsCalc.trend;
        if (avg === 0 && svar.length > 0) {
          if (tema === 'trivsel') {
            avg = svar.reduce((sum, s) => sum + s.stemning, 0) / svar.length;
          } else if (tema === 'utvikling') {
            avg = svar.reduce((sum, s) => sum + s.mestring, 0) / svar.length;
          } else if (tema === 'arbeidsbelastning') {
            avg = svar.reduce((sum, s) => sum + s.energi, 0) / svar.length;
          }
        }
        
        return {
          tema,
          avg,
          trend,
          antallSvar: temaStatsCalc.count || (avg > 0 ? svar.length : 0),
          risikoCount: temaRisikoer.length,
        };
      });
      setTemaStats(computedTemaStats);

      // Fetch employee count
      const { count } = await supabase
        .from("users")
        .select("*", { count: "exact", head: true })
        .eq("salon_id", salonId);

      setAnsatte(count || 0);
    } catch (error) {
      console.error("Error fetching pulse data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [salonId]);

  const handleToggleRotasjon = async (undersokelseId: string, currentValue: boolean) => {
    try {
      const { error } = await supabase
        .from("pulsundersokelser")
        .update({ bruk_rotasjon: !currentValue })
        .eq("id", undersokelseId);

      if (error) throw error;
      toast({ title: !currentValue ? "Spørsmålsrotasjon aktivert" : "Spørsmålsrotasjon deaktivert" });
      fetchData();
    } catch (error) {
      toast({ title: "Feil", variant: "destructive" });
    }
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {[1, 2, 3, 4, 5, 6].map(i => <Skeleton key={i} className="h-28" />)}
        </div>
        <Skeleton className="h-64" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Visnings-toggle */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Select value={visning} onValueChange={(v) => setVisning(v as 'standard' | 'tema')}>
            <SelectTrigger className="w-[180px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="tema">Tema-basert visning</SelectItem>
              <SelectItem value="standard">Standard visning</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-center gap-2">
          {svar.length > 0 && (
            <Button variant="outline" size="sm" onClick={() => setAiDialogOpen(true)}>
              <Sparkles className="h-4 w-4 mr-2" />
              AI-analyse
            </Button>
          )}
          <Button variant="ghost" size="sm" onClick={fetchData}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Oppdater
          </Button>
        </div>
      </div>

      {/* Tema-basert KPI-grid (ny) */}
      {visning === 'tema' && (
        <PulsTemaKpiGrid 
          stats={temaStats} 
          onTemaClick={(t) => setSelectedTema(t === selectedTema ? 'alle' : t)}
          selectedTema={selectedTema === 'alle' ? null : selectedTema}
        />
      )}

      {/* Standard KPI-kort (original) */}
      {visning === 'standard' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <PulsKpiCard
            title="Stemning"
            icon="😊"
            value={stats?.stemning.avg || 0}
            trend={stats?.stemning.trend || 0}
            description="Hvordan er stemningen?"
          />
          <PulsKpiCard
            title="Energi"
            icon="⚡"
            value={stats?.energi.avg || 0}
            trend={stats?.energi.trend || 0}
            description="Hvordan er energinivået?"
          />
          <PulsKpiCard
            title="Mestring"
            icon="🎯"
            value={stats?.mestring.avg || 0}
            trend={stats?.mestring.trend || 0}
            description="Føler du mestring?"
          />
        </div>
      )}

      {/* Trend-graf og aktive undersøkelser */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                {visning === 'tema' ? 'Tema-trend' : 'Puls-trend'}
              </CardTitle>
              <CardDescription>Siste 30 dager</CardDescription>
            </div>
            {visning === 'tema' && selectedTema !== 'alle' && (
              <Badge variant="secondary" className="gap-1">
                {TEMA_CONFIG[selectedTema].icon} {TEMA_CONFIG[selectedTema].label}
              </Badge>
            )}
          </CardHeader>
          <CardContent>
            {svar.length > 0 ? (
              visning === 'tema' ? (
                <PulsTemaTrendChart data={svar} selectedTema={selectedTema} />
              ) : (
                <PulsTrendChart data={svar} />
              )
            ) : (
              <div className="flex flex-col items-center justify-center py-8 text-muted-foreground">
                <Activity className="h-12 w-12 mb-4 opacity-50" />
                <p>Ingen pulsdata ennå</p>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Aktive undersøkelser
              </CardTitle>
              <CardDescription>
                {undersokelser.length} aktiv{undersokelser.length !== 1 && "e"}
              </CardDescription>
            </div>
            {canManage && (
              <Button size="sm" onClick={() => setDialogOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Ny
              </Button>
            )}
          </CardHeader>
          <CardContent>
            {undersokelser.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-8 text-muted-foreground">
                <Activity className="h-12 w-12 mb-4 opacity-50" />
                <p>Ingen aktive undersøkelser</p>
                {canManage && (
                  <Button variant="link" onClick={() => setDialogOpen(true)}>
                    Opprett en ny undersøkelse
                  </Button>
                )}
              </div>
            ) : (
              <div className="space-y-3">
                {undersokelser.map(u => (
                  <div 
                    key={u.id}
                    className="flex items-center justify-between p-3 rounded-lg border"
                  >
                    <div className="flex-1">
                      <div className="font-medium">{u.navn}</div>
                      <div className="text-sm text-muted-foreground">
                        {u.frekvens === "ukentlig" && "Ukentlig"}
                        {u.frekvens === "annenhver_uke" && "Annenhver uke"}
                        {u.frekvens === "maanedlig" && "Månedlig"}
                        {u.puls_type === 'dyppuls' && ' • Dyppuls'}
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      {canManage && (
                        <div className="flex items-center gap-2">
                          <Switch
                            id={`rotasjon-${u.id}`}
                            checked={u.bruk_rotasjon || false}
                            onCheckedChange={() => handleToggleRotasjon(u.id, u.bruk_rotasjon || false)}
                          />
                          <Label htmlFor={`rotasjon-${u.id}`} className="text-xs">
                            Rotasjon
                          </Label>
                        </div>
                      )}
                      <Badge variant="default">Aktiv</Badge>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Risikopanel og automatiske pulser */}
      {visning === 'tema' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <PulsRisikoPanel 
            risikoer={risikoer} 
            canManage={canManage} 
            onUpdate={fetchData}
          />
          <AutomatiskPulsOppsett 
            salonId={salonId}
            canManage={canManage}
            onSurveyGenerated={fetchData}
          />
        </div>
      )}

      {/* Statistikk-kort */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Deltagelse
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.antallSvar || 0}</div>
            <p className="text-xs text-muted-foreground">
              svar siste 30 dager fra {ansatte} ansatte
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardDescription className="flex items-center gap-2">
              <Activity className="h-4 w-4" />
              Generell trend
            </CardDescription>
          </CardHeader>
          <CardContent>
            {stats && (
              <div className="flex items-center gap-2">
                {(stats.stemning.trend + stats.energi.trend + stats.mestring.trend) / 3 > 0 ? (
                  <>
                    <TrendingUp className="h-5 w-5 text-green-500" />
                    <span className="text-green-500 font-medium">Positiv</span>
                  </>
                ) : (stats.stemning.trend + stats.energi.trend + stats.mestring.trend) / 3 < 0 ? (
                  <>
                    <TrendingDown className="h-5 w-5 text-red-500" />
                    <span className="text-red-500 font-medium">Negativ</span>
                  </>
                ) : (
                  <>
                    <Minus className="h-5 w-5 text-muted-foreground" />
                    <span className="text-muted-foreground font-medium">Stabil</span>
                  </>
                )}
              </div>
            )}
            <p className="text-xs text-muted-foreground mt-1">
              Basert på alle KPI-er
            </p>
          </CardContent>
        </Card>
      </div>

      <PulsundersokelseDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        salonId={salonId}
        onSuccess={() => {
          setDialogOpen(false);
          fetchData();
        }}
      />

      <PulsAIAnalyseDialog
        open={aiDialogOpen}
        onOpenChange={setAiDialogOpen}
        svar={svar}
        risikoer={risikoer}
        temaStats={temaStats}
        antallAnsatte={ansatte}
      />
    </div>
  );
}
