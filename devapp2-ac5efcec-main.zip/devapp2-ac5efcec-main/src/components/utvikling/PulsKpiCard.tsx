import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";
import { cn } from "@/lib/utils";

interface PulsKpiCardProps {
  title: string;
  icon: string;
  value: number;
  trend: number;
  description: string;
}

export function PulsKpiCard({ title, icon, value, trend, description }: PulsKpiCardProps) {
  const getScoreColor = (score: number) => {
    if (score >= 4) return "text-green-500";
    if (score >= 3) return "text-yellow-500";
    return "text-red-500";
  };

  const getScoreBg = (score: number) => {
    if (score >= 4) return "bg-green-500/10";
    if (score >= 3) return "bg-yellow-500/10";
    return "bg-red-500/10";
  };

  const getTrendIcon = () => {
    if (trend > 0.1) return <TrendingUp className="h-4 w-4 text-green-500" />;
    if (trend < -0.1) return <TrendingDown className="h-4 w-4 text-red-500" />;
    return <Minus className="h-4 w-4 text-muted-foreground" />;
  };

  const getTrendLabel = () => {
    if (trend > 0.1) return `+${trend.toFixed(1)}`;
    if (trend < -0.1) return trend.toFixed(1);
    return "0";
  };

  return (
    <Card className={cn("overflow-hidden", getScoreBg(value))}>
      <CardHeader className="pb-2">
        <CardDescription className="flex items-center justify-between">
          <span className="flex items-center gap-2">
            <span className="text-lg">{icon}</span>
            {title}
          </span>
          <div className="flex items-center gap-1">
            {getTrendIcon()}
            <span className="text-xs">{getTrendLabel()}</span>
          </div>
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className={cn("text-3xl font-bold", getScoreColor(value))}>
          {value > 0 ? value.toFixed(1) : "-"}
        </div>
        <p className="text-xs text-muted-foreground mt-1">{description}</p>
        
        {/* Score visualisering */}
        <div className="flex gap-1 mt-3">
          {[1, 2, 3, 4, 5].map((score) => (
            <div
              key={score}
              className={cn(
                "h-2 flex-1 rounded-full",
                score <= Math.round(value)
                  ? value >= 4 ? "bg-green-500" : value >= 3 ? "bg-yellow-500" : "bg-red-500"
                  : "bg-muted"
              )}
            />
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
