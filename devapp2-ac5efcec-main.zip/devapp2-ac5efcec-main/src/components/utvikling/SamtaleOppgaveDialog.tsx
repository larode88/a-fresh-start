import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon, Loader2, ListTodo, User, UserCog } from "lucide-react";
import { format } from "date-fns";
import { nb } from "date-fns/locale";
import { cn } from "@/lib/utils";

interface SamtaleOppgaveDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  samtaleId: string;
  medarbeiderId: string;
  lederId: string;
  onSuccess: () => void;
}

const PRIORITET_OPTIONS = [
  { value: "lav", label: "Lav", color: "text-muted-foreground" },
  { value: "normal", label: "Normal", color: "text-foreground" },
  { value: "hoy", label: "Høy", color: "text-orange-500" },
  { value: "kritisk", label: "Kritisk", color: "text-destructive" },
];

export function SamtaleOppgaveDialog({
  open,
  onOpenChange,
  samtaleId,
  medarbeiderId,
  lederId,
  onSuccess,
}: SamtaleOppgaveDialogProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  
  const [tittel, setTittel] = useState("");
  const [beskrivelse, setBeskrivelse] = useState("");
  const [ansvarligType, setAnsvarligType] = useState<"medarbeider" | "leder">("medarbeider");
  const [prioritet, setPrioritet] = useState("normal");
  const [frist, setFrist] = useState<Date>();

  const handleSubmit = async () => {
    if (!tittel) {
      toast({ title: "Tittel er påkrevd", variant: "destructive" });
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase.from("mote_oppgaver").insert({
        samtale_id: samtaleId,
        tittel,
        beskrivelse: beskrivelse || null,
        ansvarlig_id: ansvarligType === "medarbeider" ? medarbeiderId : lederId,
        ansvarlig_type: ansvarligType,
        prioritet,
        frist: frist ? format(frist, "yyyy-MM-dd") : null,
      });

      if (error) throw error;

      toast({ title: "Oppgave opprettet", description: "Oppgaven er lagret" });
      onSuccess();
      onOpenChange(false);
      resetForm();
    } catch (error) {
      console.error("Error creating task:", error);
      toast({ title: "Feil", description: "Kunne ikke opprette oppgave", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setTittel("");
    setBeskrivelse("");
    setAnsvarligType("medarbeider");
    setPrioritet("normal");
    setFrist(undefined);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ListTodo className="h-5 w-5" />
            Ny oppgave
          </DialogTitle>
          <DialogDescription>
            Opprett en oppgave som følges opp etter samtalen
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Tittel *</Label>
            <Input
              placeholder="Kort beskrivelse av oppgaven"
              value={tittel}
              onChange={(e) => setTittel(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label>Beskrivelse</Label>
            <Textarea
              placeholder="Utfyllende beskrivelse (valgfritt)..."
              value={beskrivelse}
              onChange={(e) => setBeskrivelse(e.target.value)}
              rows={3}
            />
          </div>

          <div className="space-y-3">
            <Label>Ansvarlig</Label>
            <RadioGroup 
              value={ansvarligType} 
              onValueChange={(value) => setAnsvarligType(value as "medarbeider" | "leder")}
              className="flex gap-4"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="medarbeider" id="medarbeider" />
                <Label htmlFor="medarbeider" className="flex items-center gap-2 cursor-pointer">
                  <User className="h-4 w-4" />
                  Medarbeider
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="leder" id="leder" />
                <Label htmlFor="leder" className="flex items-center gap-2 cursor-pointer">
                  <UserCog className="h-4 w-4" />
                  Leder
                </Label>
              </div>
            </RadioGroup>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Prioritet</Label>
              <Select value={prioritet} onValueChange={setPrioritet}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PRIORITET_OPTIONS.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      <span className={option.color}>{option.label}</span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Frist</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !frist && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {frist ? format(frist, "d. MMM", { locale: nb }) : "Velg frist"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={frist}
                    onSelect={setFrist}
                    disabled={(date) => date < new Date()}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Avbryt
          </Button>
          <Button onClick={handleSubmit} disabled={loading}>
            {loading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Opprett oppgave
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
