import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar, Zap, Brain, RefreshCw, Play } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { format, addDays, startOfMonth, addMonths } from 'date-fns';
import { nb } from 'date-fns/locale';

interface AutomatiskPlan {
  id: string;
  salon_id: string;
  puls_type: 'hurtigpuls' | 'dyppuls';
  frekvens: string;
  neste_utsendelse: string;
  aktiv: boolean;
  siste_sporsmal_ids: string[];
}

interface AutomatiskPulsOppsettProps {
  salonId: string;
  canManage: boolean;
  onSurveyGenerated?: () => void;
}

export function AutomatiskPulsOppsett({ salonId, canManage, onSurveyGenerated }: AutomatiskPulsOppsettProps) {
  const [plans, setPlans] = useState<AutomatiskPlan[]>([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchPlans();
  }, [salonId]);

  const fetchPlans = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('puls_automatisk_plan')
      .select('*')
      .eq('salon_id', salonId);

    if (error) {
      console.error('Error fetching plans:', error);
    } else {
      setPlans((data as AutomatiskPlan[]) || []);
    }
    setLoading(false);
  };

  const togglePlan = async (planId: string, aktiv: boolean) => {
    const { error } = await supabase
      .from('puls_automatisk_plan')
      .update({ aktiv })
      .eq('id', planId);

    if (error) {
      toast({ title: 'Feil', description: 'Kunne ikke oppdatere plan', variant: 'destructive' });
    } else {
      setPlans(plans.map(p => p.id === planId ? { ...p, aktiv } : p));
      toast({ title: aktiv ? 'Aktivert' : 'Deaktivert' });
    }
  };

  const createPlan = async (pulsType: 'hurtigpuls' | 'dyppuls') => {
    const frekvens = pulsType === 'hurtigpuls' ? 'annenhver_uke' : 'maanedlig';
    const today = new Date();
    
    let nesteUtsendelse: Date;
    if (pulsType === 'hurtigpuls') {
      // Next Monday
      const daysUntilMonday = (8 - today.getDay()) % 7 || 7;
      nesteUtsendelse = addDays(today, daysUntilMonday);
    } else {
      // First of next month
      nesteUtsendelse = startOfMonth(addMonths(today, 1));
    }

    const { data, error } = await supabase
      .from('puls_automatisk_plan')
      .insert({
        salon_id: salonId,
        puls_type: pulsType,
        frekvens,
        neste_utsendelse: format(nesteUtsendelse, 'yyyy-MM-dd'),
        aktiv: true
      })
      .select()
      .single();

    if (error) {
      toast({ title: 'Feil', description: 'Kunne ikke opprette plan', variant: 'destructive' });
    } else {
      setPlans([...plans, data as AutomatiskPlan]);
      toast({ title: 'Plan opprettet' });
    }
  };

  const triggerManualGeneration = async () => {
    setGenerating(true);
    try {
      const { data, error } = await supabase.functions.invoke('generate-puls-survey');
      
      if (error) throw error;
      
      toast({ 
        title: 'Undersøkelse generert', 
        description: data.message 
      });
      
      fetchPlans();
      onSurveyGenerated?.();
    } catch (error) {
      console.error('Error generating survey:', error);
      toast({ 
        title: 'Feil', 
        description: 'Kunne ikke generere undersøkelse', 
        variant: 'destructive' 
      });
    } finally {
      setGenerating(false);
    }
  };

  const hurtigpulsPlan = plans.find(p => p.puls_type === 'hurtigpuls');
  const dyppulsPlan = plans.find(p => p.puls_type === 'dyppuls');

  if (loading) {
    return <div className="text-sm text-muted-foreground">Laster...</div>;
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-base flex items-center gap-2">
          <RefreshCw className="h-4 w-4" />
          Automatiske pulsundersøkelser
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Hurtigpuls */}
        <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-full bg-yellow-100 dark:bg-yellow-900/30">
              <Zap className="h-4 w-4 text-yellow-600" />
            </div>
            <div>
              <div className="font-medium text-sm">Hurtigpuls</div>
              <div className="text-xs text-muted-foreground">
                6 spørsmål annenhver uke
              </div>
              {hurtigpulsPlan && (
                <div className="flex items-center gap-1 mt-1">
                  <Calendar className="h-3 w-3 text-muted-foreground" />
                  <span className="text-xs text-muted-foreground">
                    Neste: {format(new Date(hurtigpulsPlan.neste_utsendelse), 'd. MMM', { locale: nb })}
                  </span>
                </div>
              )}
            </div>
          </div>
          {hurtigpulsPlan ? (
            <div className="flex items-center gap-2">
              <Badge variant={hurtigpulsPlan.aktiv ? 'default' : 'secondary'}>
                {hurtigpulsPlan.aktiv ? 'Aktiv' : 'Pause'}
              </Badge>
              {canManage && (
                <Switch
                  checked={hurtigpulsPlan.aktiv}
                  onCheckedChange={(checked) => togglePlan(hurtigpulsPlan.id, checked)}
                />
              )}
            </div>
          ) : canManage ? (
            <Button size="sm" variant="outline" onClick={() => createPlan('hurtigpuls')}>
              Aktiver
            </Button>
          ) : null}
        </div>

        {/* Dyppuls */}
        <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-full bg-purple-100 dark:bg-purple-900/30">
              <Brain className="h-4 w-4 text-purple-600" />
            </div>
            <div>
              <div className="font-medium text-sm">Dyppuls</div>
              <div className="text-xs text-muted-foreground">
                14-20 spørsmål månedlig
              </div>
              {dyppulsPlan && (
                <div className="flex items-center gap-1 mt-1">
                  <Calendar className="h-3 w-3 text-muted-foreground" />
                  <span className="text-xs text-muted-foreground">
                    Neste: {format(new Date(dyppulsPlan.neste_utsendelse), 'd. MMM', { locale: nb })}
                  </span>
                </div>
              )}
            </div>
          </div>
          {dyppulsPlan ? (
            <div className="flex items-center gap-2">
              <Badge variant={dyppulsPlan.aktiv ? 'default' : 'secondary'}>
                {dyppulsPlan.aktiv ? 'Aktiv' : 'Pause'}
              </Badge>
              {canManage && (
                <Switch
                  checked={dyppulsPlan.aktiv}
                  onCheckedChange={(checked) => togglePlan(dyppulsPlan.id, checked)}
                />
              )}
            </div>
          ) : canManage ? (
            <Button size="sm" variant="outline" onClick={() => createPlan('dyppuls')}>
              Aktiver
            </Button>
          ) : null}
        </div>

        {/* Manual trigger button */}
        {canManage && (hurtigpulsPlan?.aktiv || dyppulsPlan?.aktiv) && (
          <Button 
            variant="secondary" 
            size="sm" 
            className="w-full"
            onClick={triggerManualGeneration}
            disabled={generating}
          >
            {generating ? (
              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Play className="h-4 w-4 mr-2" />
            )}
            {generating ? 'Genererer...' : 'Generer nå (test)'}
          </Button>
        )}
      </CardContent>
    </Card>
  );
}
