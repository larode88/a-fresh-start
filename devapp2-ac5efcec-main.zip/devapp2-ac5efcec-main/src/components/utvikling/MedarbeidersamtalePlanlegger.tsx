import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Plus, Calendar, User, Clock, CheckCircle2, 
  FileEdit, Play, Eye, MoreHorizontal, XCircle 
} from "lucide-react";
import { format, isPast, isToday, addDays } from "date-fns";
import { nb } from "date-fns/locale";
import { PlanleggSamtaleDialog } from "./PlanleggSamtaleDialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface Samtale {
  id: string;
  user_id: string;
  utfort_av: string;
  samtale_type: string;
  dato: string;
  status: string;
  forberedelses_frist: string | null;
  users: {
    id: string;
    name: string;
    avatar_url: string | null;
  };
  leder: {
    id: string;
    name: string;
  };
  forberedelse_medarbeider?: boolean;
  forberedelse_leder?: boolean;
}

interface MedarbeidersamtalePlanleggerProps {
  salonId: string;
  userId?: string;
  canManage: boolean;
}

const STATUS_CONFIG: Record<string, { label: string; variant: "default" | "secondary" | "outline" | "destructive" }> = {
  planlagt: { label: "Planlagt", variant: "secondary" },
  forberedelse: { label: "Forberedelse", variant: "outline" },
  gjennomfores: { label: "Pågår", variant: "default" },
  fullfort: { label: "Fullført", variant: "secondary" },
  avlyst: { label: "Avlyst", variant: "destructive" },
};

const SAMTALE_TYPES: Record<string, string> = {
  medarbeidersamtale: "Medarbeidersamtale",
  oppfolging: "Oppfølgingssamtale",
  utviklingssamtale: "Utviklingssamtale",
  lønnssamtale: "Lønnssamtale",
};

export function MedarbeidersamtalePlanlegger({ salonId, userId, canManage }: MedarbeidersamtalePlanleggerProps) {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [samtaler, setSamtaler] = useState<Samtale[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);

  const fetchSamtaler = async () => {
    try {
      let query = supabase
        .from("ansatt_samtaler")
        .select(`
          id,
          user_id,
          utfort_av,
          samtale_type,
          dato,
          status,
          forberedelses_frist,
          users!ansatt_samtaler_user_id_fkey(id, name, avatar_url),
          leder:users!ansatt_samtaler_utfort_av_fkey(id, name)
        `)
        .eq("salon_id", salonId)
        .order("dato", { ascending: true });

      if (userId) {
        query = query.or(`user_id.eq.${userId},utfort_av.eq.${userId}`);
      }

      const { data, error } = await query;
      if (error) throw error;

      // Fetch forberedelse status for each samtale
      const samtaleIds = data?.map(s => s.id) || [];
      const { data: forberedelser } = await supabase
        .from("medarbeidersamtale_forberedelse")
        .select("samtale_id, utfylt_av_type, ferdig_utfylt")
        .in("samtale_id", samtaleIds);

      const samtaleWithForberedelse = data?.map(samtale => ({
        ...samtale,
        users: samtale.users as unknown as Samtale["users"],
        leder: samtale.leder as unknown as Samtale["leder"],
        forberedelse_medarbeider: forberedelser?.some(
          f => f.samtale_id === samtale.id && f.utfylt_av_type === "medarbeider" && f.ferdig_utfylt
        ),
        forberedelse_leder: forberedelser?.some(
          f => f.samtale_id === samtale.id && f.utfylt_av_type === "leder" && f.ferdig_utfylt
        ),
      })) || [];

      setSamtaler(samtaleWithForberedelse);
    } catch (error) {
      console.error("Error fetching samtaler:", error);
      toast({ title: "Feil", description: "Kunne ikke hente samtaler", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSamtaler();
  }, [salonId, userId]);

  const getStatusBadge = (status: string) => {
    const config = STATUS_CONFIG[status] || { label: status, variant: "outline" as const };
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  const getForberedelseStatus = (samtale: Samtale) => {
    const medarbeiderDone = samtale.forberedelse_medarbeider;
    const lederDone = samtale.forberedelse_leder;

    if (medarbeiderDone && lederDone) {
      return <Badge variant="default" className="bg-green-500">Klar</Badge>;
    }
    if (medarbeiderDone || lederDone) {
      return <Badge variant="outline">Delvis utfylt</Badge>;
    }
    return <Badge variant="secondary">Venter</Badge>;
  };

  const handleStartGjennomforing = (samtaleId: string) => {
    navigate(`/hr/samtale/${samtaleId}/gjennomfor`);
  };

  const handleOpenForberedelse = (samtaleId: string, isLeder: boolean) => {
    navigate(`/hr/samtale/${samtaleId}/forberedelse?type=${isLeder ? 'leder' : 'medarbeider'}`);
  };

  const handleDeleteSamtale = async (samtaleId: string) => {
    try {
      const { error } = await supabase
        .from("ansatt_samtaler")
        .delete()
        .eq("id", samtaleId);

      if (error) throw error;

      toast({ 
        title: "Samtale slettet", 
        description: "Samtalen er fjernet" 
      });
      fetchSamtaler();
    } catch (error) {
      console.error("Error deleting samtale:", error);
      toast({ 
        title: "Feil", 
        description: "Kunne ikke slette samtalen", 
        variant: "destructive" 
      });
    }
  };

  const upcomingSamtaler = samtaler.filter(s =>
    s.status !== "fullfort" && s.status !== "avlyst"
  );
  const completedSamtaler = samtaler.filter(s => 
    s.status === "fullfort"
  );

  if (loading) {
    return (
      <Card>
        <CardContent className="py-12">
          <div className="flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Kommende samtaler */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Kommende samtaler
            </CardTitle>
            <CardDescription>
              Planlagte medarbeidersamtaler og oppfølginger
            </CardDescription>
          </div>
          {canManage && (
            <Button onClick={() => setDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Planlegg samtale
            </Button>
          )}
        </CardHeader>
        <CardContent>
          {upcomingSamtaler.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Ingen planlagte samtaler</p>
              {canManage && (
                <Button variant="link" onClick={() => setDialogOpen(true)}>
                  Planlegg en ny samtale
                </Button>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              {upcomingSamtaler.map(samtale => (
                <div 
                  key={samtale.id} 
                  className="flex items-center justify-between p-4 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <Avatar>
                      <AvatarImage src={samtale.users?.avatar_url || undefined} />
                      <AvatarFallback>
                        {samtale.users?.name?.split(" ").map(n => n[0]).join("") || "?"}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-medium">{samtale.users?.name}</div>
                      <div className="text-sm text-muted-foreground flex items-center gap-2">
                        <span>{SAMTALE_TYPES[samtale.samtale_type] || samtale.samtale_type}</span>
                        <span>•</span>
                        <span className={isToday(new Date(samtale.dato)) ? "text-primary font-medium" : ""}>
                          {format(new Date(samtale.dato), "d. MMMM yyyy", { locale: nb })}
                        </span>
                      </div>
                      {samtale.forberedelses_frist && (
                        <div className="text-xs text-muted-foreground mt-1">
                          Forberedelse frist: {format(new Date(samtale.forberedelses_frist), "d. MMM", { locale: nb })}
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    {getStatusBadge(samtale.status)}
                    {getForberedelseStatus(samtale)}
                    
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        {canManage && (
                          <>
                            <DropdownMenuItem onClick={() => handleOpenForberedelse(samtale.id, true)}>
                              <FileEdit className="h-4 w-4 mr-2" />
                              Min forberedelse (leder)
                            </DropdownMenuItem>
                            {samtale.forberedelse_medarbeider && samtale.forberedelse_leder && (
                              <DropdownMenuItem onClick={() => handleStartGjennomforing(samtale.id)}>
                                <Play className="h-4 w-4 mr-2" />
                                Start gjennomføring
                              </DropdownMenuItem>
                            )}
                          </>
                        )}
                        {!canManage && samtale.user_id === userId && (
                          <DropdownMenuItem onClick={() => handleOpenForberedelse(samtale.id, false)}>
                            <FileEdit className="h-4 w-4 mr-2" />
                            Min forberedelse
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuItem onClick={() => navigate(`/hr/samtale/${samtale.id}`)}>
                          <Eye className="h-4 w-4 mr-2" />
                          Se detaljer
                        </DropdownMenuItem>
                        {canManage && (
                          <DropdownMenuItem 
                            onClick={() => handleDeleteSamtale(samtale.id)}
                            className="text-destructive"
                          >
                            <XCircle className="h-4 w-4 mr-2" />
                            Slett samtale
                          </DropdownMenuItem>
                        )}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Fullførte samtaler */}
      {completedSamtaler.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5" />
              Fullførte samtaler
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {completedSamtaler.slice(0, 5).map(samtale => (
                <div 
                  key={samtale.id}
                  className="flex items-center justify-between p-3 rounded-lg border cursor-pointer hover:bg-accent/50"
                  onClick={() => navigate(`/hr/samtale/${samtale.id}`)}
                >
                  <div className="flex items-center gap-3">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={samtale.users?.avatar_url || undefined} />
                      <AvatarFallback className="text-xs">
                        {samtale.users?.name?.split(" ").map(n => n[0]).join("") || "?"}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="text-sm font-medium">{samtale.users?.name}</div>
                      <div className="text-xs text-muted-foreground">
                        {format(new Date(samtale.dato), "d. MMM yyyy", { locale: nb })}
                      </div>
                    </div>
                  </div>
                  <Badge variant="secondary">Fullført</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <PlanleggSamtaleDialog 
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        salonId={salonId}
        onSuccess={fetchSamtaler}
      />
    </div>
  );
}
