import { useMemo } from "react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { format, parseISO } from "date-fns";
import { nb } from "date-fns/locale";

interface PulsSvar {
  stemning: number;
  energi: number;
  mestring: number;
  dato: string;
}

interface PulsTrendChartProps {
  data: PulsSvar[];
}

export function PulsTrendChart({ data }: PulsTrendChartProps) {
  const chartData = useMemo(() => {
    // Group by date and calculate averages
    const groupedByDate = data.reduce((acc, svar) => {
      const date = svar.dato;
      if (!acc[date]) {
        acc[date] = { stemning: [], energi: [], mestring: [] };
      }
      acc[date].stemning.push(svar.stemning);
      acc[date].energi.push(svar.energi);
      acc[date].mestring.push(svar.mestring);
      return acc;
    }, {} as Record<string, { stemning: number[]; energi: number[]; mestring: number[] }>);

    // Calculate averages and format for chart
    return Object.entries(groupedByDate)
      .map(([date, values]) => ({
        dato: date,
        label: format(parseISO(date), "d. MMM", { locale: nb }),
        stemning: values.stemning.reduce((a, b) => a + b, 0) / values.stemning.length,
        energi: values.energi.reduce((a, b) => a + b, 0) / values.energi.length,
        mestring: values.mestring.reduce((a, b) => a + b, 0) / values.mestring.length,
      }))
      .sort((a, b) => a.dato.localeCompare(b.dato));
  }, [data]);

  if (chartData.length === 0) {
    return (
      <div className="flex items-center justify-center h-64 text-muted-foreground">
        Ingen data å vise
      </div>
    );
  }

  return (
    <ResponsiveContainer width="100%" height={250}>
      <LineChart data={chartData} margin={{ top: 5, right: 5, left: -20, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
        <XAxis 
          dataKey="label" 
          tick={{ fontSize: 12 }} 
          className="text-muted-foreground"
        />
        <YAxis 
          domain={[1, 5]} 
          ticks={[1, 2, 3, 4, 5]} 
          tick={{ fontSize: 12 }}
          className="text-muted-foreground"
        />
        <Tooltip 
          contentStyle={{ 
            backgroundColor: "hsl(var(--card))",
            border: "1px solid hsl(var(--border))",
            borderRadius: "var(--radius)",
          }}
          labelStyle={{ color: "hsl(var(--foreground))" }}
        />
        <Legend />
        <Line 
          type="monotone" 
          dataKey="stemning" 
          name="Stemning"
          stroke="hsl(var(--chart-1))" 
          strokeWidth={2}
          dot={{ r: 4 }}
          activeDot={{ r: 6 }}
        />
        <Line 
          type="monotone" 
          dataKey="energi" 
          name="Energi"
          stroke="hsl(var(--chart-2))" 
          strokeWidth={2}
          dot={{ r: 4 }}
          activeDot={{ r: 6 }}
        />
        <Line 
          type="monotone" 
          dataKey="mestring" 
          name="Mestring"
          stroke="hsl(var(--chart-3))" 
          strokeWidth={2}
          dot={{ r: 4 }}
          activeDot={{ r: 6 }}
        />
      </LineChart>
    </ResponsiveContainer>
  );
}
