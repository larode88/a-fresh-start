import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ListTodo, Target, ArrowRight, ArrowLeft, CheckCircle2, Loader2 } from "lucide-react";
import type { Forberedelse, Samtale } from "@/pages/hr/SamtaleGjennomforing";

interface Steg {
  id: number;
  navn: string;
  ikon: string;
  key: string;
}

interface SamtaleStegInnholdProps {
  steg: Steg;
  medarbeiderForberedelse: Forberedelse | null;
  notat: string;
  onNotatChange: (notat: string) => void;
  onOpprettOppgave: () => void;
  onOpprettMal: () => void;
  samtale: Samtale;
  onFullfor: () => void;
  saving: boolean;
  aktivtSteg: number;
  setAktivtSteg: (steg: number) => void;
  totalSteg: number;
}

const SCORE_MAPPING: Record<string, { scoreField: string; kommentarField: string; label: string }> = {
  egen_innsats: { scoreField: "egen_innsats_score", kommentarField: "egen_innsats_kommentar", label: "Egen innsats" },
  arbeid_salong: { scoreField: "arbeid_salong_score", kommentarField: "arbeid_salong_kommentar", label: "Arbeid i salongen" },
  hjelp_leder: { scoreField: "hjelp_leder_score", kommentarField: "hjelp_leder_kommentar", label: "Hjelp fra leder" },
  kompetanse: { scoreField: "kompetanse_score", kommentarField: "kompetanse_kommentar", label: "Kompetansenivå" },
  stotte_leder: { scoreField: "stotte_leder_score", kommentarField: "stotte_leder_kommentar", label: "Støtte fra leder" },
};

const TEXT_MAPPING: Record<string, { field: string; label: string }> = {
  ferdigheter: { field: "ferdigheter_utvikle", label: "Ferdigheter å utvikle" },
  leder_hjelp: { field: "leder_hjelp_mal", label: "Hvordan kan leder hjelpe?" },
  framtidige_mal: { field: "framtidige_mal", label: "Fremtidige mål" },
  andre_tema: { field: "andre_tema", label: "Andre tema" },
};

export function SamtaleStegInnhold({
  steg,
  medarbeiderForberedelse,
  notat,
  onNotatChange,
  onOpprettOppgave,
  onOpprettMal,
  samtale,
  onFullfor,
  saving,
  aktivtSteg,
  setAktivtSteg,
  totalSteg,
}: SamtaleStegInnholdProps) {
  const getScoreLabel = (score: number | undefined) => {
    if (!score) return "Ikke utfylt";
    const labels = ["", "Svært misfornøyd", "Misfornøyd", "Nøytral", "Fornøyd", "Svært fornøyd"];
    return labels[score];
  };

  const getScoreColor = (score: number | undefined) => {
    if (!score) return "secondary";
    if (score >= 4) return "default";
    if (score >= 3) return "secondary";
    return "destructive";
  };

  const renderScoreContent = () => {
    const mapping = SCORE_MAPPING[steg.key];
    if (!mapping || !medarbeiderForberedelse) return null;

    const score = medarbeiderForberedelse[mapping.scoreField as keyof Forberedelse] as number | undefined;
    const kommentar = medarbeiderForberedelse[mapping.kommentarField as keyof Forberedelse] as string | undefined;

    return (
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            {steg.ikon} Medarbeiderens svar
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground">Score:</span>
            <Badge variant={getScoreColor(score) as "default" | "secondary" | "destructive"}>
              {score}/5 - {getScoreLabel(score)}
            </Badge>
          </div>
          {kommentar && (
            <div className="bg-muted p-4 rounded-lg">
              <p className="text-sm italic">"{kommentar}"</p>
            </div>
          )}
        </CardContent>
      </Card>
    );
  };

  const renderTextContent = () => {
    const mapping = TEXT_MAPPING[steg.key];
    if (!mapping || !medarbeiderForberedelse) return null;

    const text = medarbeiderForberedelse[mapping.field as keyof Forberedelse] as string | undefined;

    return (
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            {steg.ikon} Medarbeiderens svar
          </CardTitle>
        </CardHeader>
        <CardContent>
          {text ? (
            <div className="bg-muted p-4 rounded-lg">
              <p className="text-sm whitespace-pre-wrap">{text}</p>
            </div>
          ) : (
            <p className="text-sm text-muted-foreground italic">Ikke utfylt</p>
          )}
        </CardContent>
      </Card>
    );
  };

  const renderIntro = () => (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          👋 Velkommen til samtalen
        </CardTitle>
        <CardDescription>
          Start med å ønske velkommen og sett rammene for samtalen
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="bg-muted/50 p-4 rounded-lg space-y-2">
          <p className="text-sm">Tips til åpning:</p>
          <ul className="text-sm text-muted-foreground list-disc list-inside space-y-1">
            <li>Takk for at du tok deg tid til forberedelsen</li>
            <li>Forklar formålet med samtalen</li>
            <li>Bekreft at det som sies er konfidensielt</li>
            <li>Spør om det er noe spesielt medarbeideren ønsker å ta opp</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );

  const renderOppgaverMal = () => (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          ✅ Oppgaver og mål
        </CardTitle>
        <CardDescription>
          Oppsummer oppgaver og mål som er opprettet i samtalen
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-3">
          <Button onClick={onOpprettOppgave} variant="outline">
            <ListTodo className="h-4 w-4 mr-2" />
            Ny oppgave
          </Button>
          <Button onClick={onOpprettMal} variant="outline">
            <Target className="h-4 w-4 mr-2" />
            Nytt SMART-mål
          </Button>
        </div>
      </CardContent>
    </Card>
  );

  const renderOppsummering = () => (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          🏁 Oppsummering
        </CardTitle>
        <CardDescription>
          Oppsummer samtalen og planlegg neste
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="bg-muted/50 p-4 rounded-lg space-y-2">
          <p className="text-sm">Avslutt samtalen med å:</p>
          <ul className="text-sm text-muted-foreground list-disc list-inside space-y-1">
            <li>Oppsummer hovedpunktene</li>
            <li>Bekreft avtalte oppgaver og mål</li>
            <li>Avtal dato for neste samtale</li>
            <li>Takk for en god samtale</li>
          </ul>
        </div>
        
        <Separator />
        
        <Button onClick={onFullfor} className="w-full" size="lg" disabled={saving}>
          {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
          <CheckCircle2 className="h-4 w-4 mr-2" />
          Fullfør samtale
        </Button>
      </CardContent>
    </Card>
  );

  return (
    <div className="max-w-2xl mx-auto">
      {/* Steg-innhold basert på type */}
      {steg.key === "intro" && renderIntro()}
      {SCORE_MAPPING[steg.key] && renderScoreContent()}
      {TEXT_MAPPING[steg.key] && renderTextContent()}
      {steg.key === "oppgaver_mal" && renderOppgaverMal()}
      {steg.key === "oppsummering" && renderOppsummering()}

      {/* Lederens notater */}
      {steg.key !== "oppsummering" && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">📝 Dine notater</CardTitle>
            <CardDescription>
              Notater lagres automatisk
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea
              placeholder="Skriv dine notater her..."
              value={notat}
              onChange={(e) => onNotatChange(e.target.value)}
              rows={6}
              className="resize-none"
            />
            
            <div className="flex gap-2">
              <Button onClick={onOpprettOppgave} variant="outline" size="sm">
                <ListTodo className="h-4 w-4 mr-2" />
                Oppgave
              </Button>
              <Button onClick={onOpprettMal} variant="outline" size="sm">
                <Target className="h-4 w-4 mr-2" />
                SMART-mål
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Navigasjon */}
      <div className="flex justify-between mt-6">
        <Button 
          variant="outline" 
          onClick={() => setAktivtSteg(aktivtSteg - 1)}
          disabled={aktivtSteg === 1}
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Forrige
        </Button>
        <Button 
          onClick={() => setAktivtSteg(aktivtSteg + 1)}
          disabled={aktivtSteg === totalSteg}
        >
          Neste
          <ArrowRight className="h-4 w-4 ml-2" />
        </Button>
      </div>
    </div>
  );
}
