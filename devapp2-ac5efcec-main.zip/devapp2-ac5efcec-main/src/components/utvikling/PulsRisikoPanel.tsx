import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { 
  AlertTriangle, CheckCircle, Clock, ChevronDown, ChevronUp,
  MessageSquare
} from "lucide-react";
import { format } from "date-fns";
import { nb } from "date-fns/locale";
import { 
  TEMA_CONFIG, 
  type PulsRisiko, 
  type PulsTema,
  getForeslatteTiltak 
} from "@/lib/pulsUtils";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface PulsRisikoPanelProps {
  risikoer: PulsRisiko[];
  canManage: boolean;
  onUpdate: () => void;
}

export function PulsRisikoPanel({ risikoer, canManage, onUpdate }: PulsRisikoPanelProps) {
  const { toast } = useToast();
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [kommentar, setKommentar] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState<string | null>(null);

  const handleStatusChange = async (risiko: PulsRisiko, newStatus: string) => {
    setLoading(risiko.id);
    try {
      const updateData: Record<string, unknown> = { status: newStatus };
      
      if (newStatus === 'lukket') {
        updateData.behandlet_dato = new Date().toISOString();
      }
      
      if (kommentar[risiko.id]) {
        updateData.kommentar = kommentar[risiko.id];
      }

      const { error } = await supabase
        .from("puls_risikologg")
        .update(updateData)
        .eq("id", risiko.id);

      if (error) throw error;

      toast({ title: "Risiko oppdatert" });
      onUpdate();
    } catch (error) {
      console.error("Error updating risk:", error);
      toast({ title: "Feil", description: "Kunne ikke oppdatere", variant: "destructive" });
    } finally {
      setLoading(null);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'ny':
        return <Badge variant="destructive" className="gap-1"><AlertTriangle className="h-3 w-3" /> Ny</Badge>;
      case 'under_behandling':
        return <Badge variant="secondary" className="gap-1"><Clock className="h-3 w-3" /> Under behandling</Badge>;
      case 'lukket':
        return <Badge variant="default" className="gap-1 bg-green-600"><CheckCircle className="h-3 w-3" /> Lukket</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const groupedByTema = risikoer.reduce((acc, r) => {
    if (!acc[r.tema]) acc[r.tema] = [];
    acc[r.tema].push(r);
    return acc;
  }, {} as Record<PulsTema, PulsRisiko[]>);

  const activeCount = risikoer.filter(r => r.status !== 'lukket').length;

  if (risikoer.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <AlertTriangle className="h-5 w-5" />
            Risikoflagg
          </CardTitle>
          <CardDescription>Ingen risikoflagg registrert</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center py-6 text-muted-foreground">
            <CheckCircle className="h-10 w-10 mb-2 text-green-500" />
            <p>Alt ser bra ut!</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center gap-2 text-base">
            <AlertTriangle className="h-5 w-5 text-destructive" />
            Risikoflagg
          </span>
          {activeCount > 0 && (
            <Badge variant="destructive">{activeCount} aktive</Badge>
          )}
        </CardTitle>
        <CardDescription>
          Svar med score 1-2 som krever oppfølging
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {Object.entries(groupedByTema).map(([tema, items]) => {
          const temaConfig = TEMA_CONFIG[tema as PulsTema];
          const activeInTema = items.filter(i => i.status !== 'lukket').length;
          
          return (
            <div key={tema} className="space-y-2">
              <div className={`flex items-center gap-2 p-2 rounded-lg ${temaConfig.bgColor}`}>
                <span className="text-lg">{temaConfig.icon}</span>
                <span className="font-medium">{temaConfig.label}</span>
                {activeInTema > 0 && (
                  <Badge variant="secondary" className="ml-auto">{activeInTema}</Badge>
                )}
              </div>
              
              {items.map((risiko) => (
                <Collapsible
                  key={risiko.id}
                  open={expandedId === risiko.id}
                  onOpenChange={(open) => setExpandedId(open ? risiko.id : null)}
                >
                  <div className="border rounded-lg p-3 ml-4">
                    <CollapsibleTrigger asChild>
                      <div className="flex items-center justify-between cursor-pointer">
                        <div className="flex items-center gap-3">
                          <div className="flex items-center justify-center w-8 h-8 rounded-full bg-destructive/10 text-destructive font-bold">
                            {risiko.score}
                          </div>
                          <div>
                            <p className="text-sm">
                              {format(new Date(risiko.created_at), "d. MMM yyyy", { locale: nb })}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {getStatusBadge(risiko.status)}
                          {expandedId === risiko.id ? (
                            <ChevronUp className="h-4 w-4" />
                          ) : (
                            <ChevronDown className="h-4 w-4" />
                          )}
                        </div>
                      </div>
                    </CollapsibleTrigger>
                    
                    <CollapsibleContent className="mt-4 space-y-4">
                      {/* Foreslåtte tiltak */}
                      <div>
                        <h4 className="text-sm font-medium mb-2">Foreslåtte tiltak:</h4>
                        <ul className="space-y-1">
                          {(risiko.foreslatte_tiltak?.length > 0 
                            ? risiko.foreslatte_tiltak 
                            : getForeslatteTiltak(risiko.tema)
                          ).map((tiltak, i) => (
                            <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                              <span className="text-primary">•</span>
                              {tiltak}
                            </li>
                          ))}
                        </ul>
                      </div>

                      {canManage && risiko.status !== 'lukket' && (
                        <>
                          {/* Kommentar */}
                          <div>
                            <label className="text-sm font-medium flex items-center gap-1 mb-1">
                              <MessageSquare className="h-4 w-4" />
                              Kommentar
                            </label>
                            <Textarea
                              placeholder="Legg til kommentar om tiltak..."
                              value={kommentar[risiko.id] || risiko.kommentar || ''}
                              onChange={(e) => setKommentar({
                                ...kommentar,
                                [risiko.id]: e.target.value
                              })}
                              rows={2}
                            />
                          </div>

                          {/* Status-endring */}
                          <div className="flex items-center gap-2">
                            <Select
                              value={risiko.status}
                              onValueChange={(value) => handleStatusChange(risiko, value)}
                              disabled={loading === risiko.id}
                            >
                              <SelectTrigger className="w-[180px]">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="ny">Ny</SelectItem>
                                <SelectItem value="under_behandling">Under behandling</SelectItem>
                                <SelectItem value="lukket">Lukket</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </>
                      )}

                      {risiko.kommentar && risiko.status === 'lukket' && (
                        <div className="bg-muted/50 p-3 rounded-lg">
                          <p className="text-sm text-muted-foreground">{risiko.kommentar}</p>
                          {risiko.behandlet_dato && (
                            <p className="text-xs text-muted-foreground mt-1">
                              Lukket {format(new Date(risiko.behandlet_dato), "d. MMM yyyy", { locale: nb })}
                            </p>
                          )}
                        </div>
                      )}
                    </CollapsibleContent>
                  </div>
                </Collapsible>
              ))}
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}
