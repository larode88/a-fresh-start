import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon, Loader2, Activity } from "lucide-react";
import { format } from "date-fns";
import { nb } from "date-fns/locale";
import { cn } from "@/lib/utils";

interface PulsundersokelseDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  salonId: string;
  onSuccess: () => void;
}

const FREKVENS_OPTIONS = [
  { value: "ukentlig", label: "Ukentlig" },
  { value: "annenhver_uke", label: "Annenhver uke" },
  { value: "maanedlig", label: "Månedlig" },
];

export function PulsundersokelseDialog({
  open,
  onOpenChange,
  salonId,
  onSuccess,
}: PulsundersokelseDialogProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  
  const [navn, setNavn] = useState("");
  const [beskrivelse, setBeskrivelse] = useState("");
  const [frekvens, setFrekvens] = useState("ukentlig");
  const [startDato, setStartDato] = useState<Date>(new Date());
  const [sluttDato, setSluttDato] = useState<Date>();

  const handleSubmit = async () => {
    if (!navn) {
      toast({ title: "Navn er påkrevd", variant: "destructive" });
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase.from("pulsundersokelser").insert({
        salon_id: salonId,
        navn,
        beskrivelse: beskrivelse || null,
        frekvens,
        start_dato: format(startDato, "yyyy-MM-dd"),
        slutt_dato: sluttDato ? format(sluttDato, "yyyy-MM-dd") : null,
        aktiv: true,
      });

      if (error) throw error;

      toast({ title: "Pulsundersøkelse opprettet", description: "Ansatte vil bli varslet" });
      onSuccess();
      resetForm();
    } catch (error) {
      console.error("Error creating pulse survey:", error);
      toast({ title: "Feil", description: "Kunne ikke opprette undersøkelse", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setNavn("");
    setBeskrivelse("");
    setFrekvens("ukentlig");
    setStartDato(new Date());
    setSluttDato(undefined);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Ny pulsundersøkelse
          </DialogTitle>
          <DialogDescription>
            Opprett en regelmessig pulsundersøkelse for å måle trivsel
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Navn *</Label>
            <Input
              placeholder="F.eks. Ukentlig trivselspuls"
              value={navn}
              onChange={(e) => setNavn(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label>Beskrivelse</Label>
            <Textarea
              placeholder="Valgfri beskrivelse..."
              value={beskrivelse}
              onChange={(e) => setBeskrivelse(e.target.value)}
              rows={2}
            />
          </div>

          <div className="space-y-2">
            <Label>Frekvens *</Label>
            <Select value={frekvens} onValueChange={setFrekvens}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {FREKVENS_OPTIONS.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Startdato *</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {format(startDato, "d. MMM yyyy", { locale: nb })}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={startDato}
                    onSelect={(date) => date && setStartDato(date)}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label>Sluttdato (valgfritt)</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !sluttDato && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {sluttDato ? format(sluttDato, "d. MMM yyyy", { locale: nb }) : "Ingen slutt"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={sluttDato}
                    onSelect={setSluttDato}
                    month={sluttDato || startDato}
                    disabled={(date) => date < startDato}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          <div className="bg-muted/50 p-3 rounded-lg text-sm text-muted-foreground">
            💡 Pulsundersøkelsen måler tre ting: Stemning, Energi og Mestring. 
            Ansatte svarer på en skala fra 1-5.
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Avbryt
          </Button>
          <Button onClick={handleSubmit} disabled={loading}>
            {loading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Opprett undersøkelse
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
