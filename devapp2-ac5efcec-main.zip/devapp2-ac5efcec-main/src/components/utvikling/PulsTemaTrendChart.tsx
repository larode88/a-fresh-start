import { useMemo } from "react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { format, parseISO } from "date-fns";
import { nb } from "date-fns/locale";
import { TEMA_CONFIG, type PulsTema, type PulsSvar } from "@/lib/pulsUtils";

interface PulsTemaTrendChartProps {
  data: PulsSvar[];
  selectedTema?: PulsTema | 'alle';
}

const TEMA_COLORS: Record<PulsTema, string> = {
  trivsel: '#22c55e',
  arbeidsbelastning: '#f59e0b',
  psykologisk_trygghet: '#3b82f6',
  ledelse: '#a855f7',
  hms_sikkerhet: '#ef4444',
  utvikling: '#14b8a6',
};

export function PulsTemaTrendChart({ data, selectedTema = 'alle' }: PulsTemaTrendChartProps) {
  const chartData = useMemo(() => {
    // Grupper etter dato
    const groupedByDate = data.reduce((acc, svar) => {
      const date = svar.dato;
      if (!acc[date]) {
        acc[date] = {
          trivsel: [] as number[],
          arbeidsbelastning: [] as number[],
          psykologisk_trygghet: [] as number[],
          ledelse: [] as number[],
          hms_sikkerhet: [] as number[],
          utvikling: [] as number[],
          // Fallback for eldre data uten tema
          stemning: [] as number[],
          energi: [] as number[],
          mestring: [] as number[],
        };
      }
      
      // Hvis svar har tema, bruk det
      if (svar.tema) {
        acc[date][svar.tema].push(svar.stemning);
      } else {
        // Fallback til standard KPI-er for eldre data
        acc[date].stemning.push(svar.stemning);
        acc[date].energi.push(svar.energi);
        acc[date].mestring.push(svar.mestring);
      }
      
      return acc;
    }, {} as Record<string, Record<string, number[]>>);

    // Beregn gjennomsnitt og formater for chart
    return Object.entries(groupedByDate)
      .map(([date, values]) => {
        const result: Record<string, string | number> = {
          dato: date,
          label: format(parseISO(date), "d. MMM", { locale: nb }),
        };

        // Legg til tema-gjennomsnitt
        for (const tema of Object.keys(TEMA_CONFIG) as PulsTema[]) {
          const arr = values[tema] || [];
          result[tema] = arr.length > 0 
            ? arr.reduce((a, b) => a + b, 0) / arr.length 
            : 0;
        }

        // Fallback for eldre data - map til temaer
        if (values.stemning?.length > 0) {
          result.trivsel = values.stemning.reduce((a, b) => a + b, 0) / values.stemning.length;
        }
        if (values.mestring?.length > 0) {
          result.utvikling = values.mestring.reduce((a, b) => a + b, 0) / values.mestring.length;
        }
        if (values.energi?.length > 0) {
          result.arbeidsbelastning = values.energi.reduce((a, b) => a + b, 0) / values.energi.length;
        }

        return result;
      })
      .sort((a, b) => (a.dato as string).localeCompare(b.dato as string));
  }, [data]);

  if (chartData.length === 0) {
    return (
      <div className="flex items-center justify-center h-64 text-muted-foreground">
        Ingen data å vise
      </div>
    );
  }

  const temaerToShow = selectedTema === 'alle' 
    ? Object.keys(TEMA_CONFIG) as PulsTema[]
    : [selectedTema];

  return (
    <ResponsiveContainer width="100%" height={300}>
      <LineChart data={chartData} margin={{ top: 5, right: 5, left: -20, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
        <XAxis 
          dataKey="label" 
          tick={{ fontSize: 11 }} 
          className="text-muted-foreground"
        />
        <YAxis 
          domain={[1, 5]} 
          ticks={[1, 2, 3, 4, 5]} 
          tick={{ fontSize: 11 }}
          className="text-muted-foreground"
        />
        <Tooltip 
          contentStyle={{ 
            backgroundColor: "hsl(var(--card))",
            border: "1px solid hsl(var(--border))",
            borderRadius: "var(--radius)",
          }}
          labelStyle={{ color: "hsl(var(--foreground))" }}
          formatter={(value: number, name: string) => [
            value.toFixed(1), 
            TEMA_CONFIG[name as PulsTema]?.label || name
          ]}
        />
        <Legend 
          formatter={(value: string) => TEMA_CONFIG[value as PulsTema]?.label || value}
        />
        {temaerToShow.map((tema) => (
          <Line 
            key={tema}
            type="monotone" 
            dataKey={tema} 
            name={tema}
            stroke={TEMA_COLORS[tema]} 
            strokeWidth={2}
            dot={{ r: 3 }}
            activeDot={{ r: 5 }}
            connectNulls
          />
        ))}
      </LineChart>
    </ResponsiveContainer>
  );
}
