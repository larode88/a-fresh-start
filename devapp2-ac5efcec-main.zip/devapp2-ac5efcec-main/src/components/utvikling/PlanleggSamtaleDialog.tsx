import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon, Loader2 } from "lucide-react";
import { format, addDays } from "date-fns";
import { nb } from "date-fns/locale";
import { cn } from "@/lib/utils";

interface Employee {
  id: string;
  fornavn: string;
  etternavn: string | null;
  profilbilde_url: string | null;
}

interface PlanleggSamtaleDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  salonId: string;
  onSuccess: () => void;
}

const SAMTALE_TYPES = [
  { value: "medarbeidersamtale", label: "Medarbeidersamtale" },
  { value: "oppfolging", label: "Oppfølgingssamtale" },
  { value: "utviklingssamtale", label: "Utviklingssamtale" },
  { value: "lønnssamtale", label: "Lønnssamtale" },
];

export function PlanleggSamtaleDialog({ 
  open, 
  onOpenChange, 
  salonId,
  onSuccess 
}: PlanleggSamtaleDialogProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [employees, setEmployees] = useState<Employee[]>([]);
  
  const [selectedEmployee, setSelectedEmployee] = useState<string>("");
  const [samtaleType, setSamtaleType] = useState<string>("medarbeidersamtale");
  const [dato, setDato] = useState<Date>();
  const [tidspunkt, setTidspunkt] = useState<string>("10:00");
  const [varighet, setVarighet] = useState<string>("60");
  const [sted, setSted] = useState<string>("");
  const [notater, setNotater] = useState<string>("");

  useEffect(() => {
    const fetchEmployees = async () => {
      const { data, error } = await supabase
        .from("ansatte")
        .select("id, fornavn, etternavn, profilbilde_url")
        .eq("salong_id", salonId)
        .neq("status", "Arkivert")
        .order("fornavn");

      if (!error && data) {
        setEmployees(data);
      }
    };

    if (open && salonId) {
      fetchEmployees();
    }
  }, [open, salonId]);

  const handleSubmit = async () => {
    if (!selectedEmployee || !dato || !user) {
      toast({ title: "Feil", description: "Fyll ut alle påkrevde felt", variant: "destructive" });
      return;
    }

    setLoading(true);
    try {
      // Calculate forberedelse frist (2 days before samtale)
      const forberedelsesFrist = addDays(dato, -2);

      // Insert samtale
      const { data: samtale, error: samtaleError } = await supabase
        .from("ansatt_samtaler")
        .insert({
          ansatt_id: selectedEmployee,
          utfort_av: user.id,
          salon_id: salonId,
          samtale_type: samtaleType,
          dato: format(dato, "yyyy-MM-dd"),
          status: "planlagt",
          sted: sted || null,
          notater: notater || null,
          forberedelses_frist: format(forberedelsesFrist, "yyyy-MM-dd"),
        })
        .select()
        .single();

      if (samtaleError) throw samtaleError;

      // Create reminder for employee
      await supabase.from("medarbeidersamtale_paminnelser").insert({
        salon_id: salonId,
        samtale_id: samtale.id,
        ansatt_id: selectedEmployee,
        leder_id: user.id,
        type: "ny_samtale_planlagt",
        melding: `Du er innkalt til ${SAMTALE_TYPES.find(t => t.value === samtaleType)?.label || samtaleType} ${format(dato, "d. MMMM yyyy", { locale: nb })}. Vennligst fyll ut forberedelsen innen ${format(forberedelsesFrist, "d. MMMM", { locale: nb })}.`,
      });

      toast({ title: "Samtale planlagt", description: "Medarbeideren har fått varsel" });
      onSuccess();
      onOpenChange(false);
      resetForm();
    } catch (error) {
      console.error("Error creating samtale:", error);
      toast({ title: "Feil", description: "Kunne ikke opprette samtale", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setSelectedEmployee("");
    setSamtaleType("medarbeidersamtale");
    setDato(undefined);
    setTidspunkt("10:00");
    setVarighet("60");
    setSted("");
    setNotater("");
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Planlegg samtale</DialogTitle>
          <DialogDescription>
            Planlegg en ny medarbeidersamtale. Medarbeideren vil få varsel.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Medarbeider *</Label>
            <Select value={selectedEmployee} onValueChange={setSelectedEmployee}>
              <SelectTrigger>
                <SelectValue placeholder="Velg medarbeider" />
              </SelectTrigger>
              <SelectContent>
                {employees.map(emp => (
                  <SelectItem key={emp.id} value={emp.id}>
                    {emp.fornavn} {emp.etternavn || ''}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Type samtale *</Label>
            <Select value={samtaleType} onValueChange={setSamtaleType}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {SAMTALE_TYPES.map(type => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Dato *</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !dato && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {dato ? format(dato, "d. MMM yyyy", { locale: nb }) : "Velg dato"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={dato}
                    onSelect={setDato}
                    disabled={(date) => date < new Date()}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label>Tidspunkt</Label>
              <Input 
                type="time" 
                value={tidspunkt} 
                onChange={(e) => setTidspunkt(e.target.value)} 
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Varighet (min)</Label>
              <Select value={varighet} onValueChange={setVarighet}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="30">30 min</SelectItem>
                  <SelectItem value="45">45 min</SelectItem>
                  <SelectItem value="60">1 time</SelectItem>
                  <SelectItem value="90">1,5 time</SelectItem>
                  <SelectItem value="120">2 timer</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Sted</Label>
              <Input 
                placeholder="F.eks. Kontoret"
                value={sted}
                onChange={(e) => setSted(e.target.value)}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Notater til medarbeider</Label>
            <Textarea 
              placeholder="Valgfrie notater som vises i innkallingen..."
              value={notater}
              onChange={(e) => setNotater(e.target.value)}
              rows={3}
            />
          </div>

          {dato && (
            <div className="text-sm text-muted-foreground bg-muted p-3 rounded-lg">
              📅 Forberedelsesfrist: {format(addDays(dato, -2), "d. MMMM yyyy", { locale: nb })}
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Avbryt
          </Button>
          <Button onClick={handleSubmit} disabled={loading}>
            {loading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Planlegg samtale
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
