import { useState, useEffect } from "react";
import { useNavigate, useParams, useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { Loader2, Save, CheckCircle2, ArrowLeft } from "lucide-react";
import { AppLayout } from "@/components/AppLayout";

interface ScoreQuestion {
  id: string;
  scoreField: string;
  kommentarField: string;
  label: string;
  description: string;
}

const MEDARBEIDER_QUESTIONS: ScoreQuestion[] = [
  {
    id: "1",
    scoreField: "egen_innsats_score",
    kommentarField: "egen_innsats_kommentar",
    label: "Hvor fornøyd er du med egen innsats?",
    description: "Vurder din egen arbeidsinnsats den siste perioden",
  },
  {
    id: "2",
    scoreField: "arbeid_salong_score",
    kommentarField: "arbeid_salong_kommentar",
    label: "Hvor fornøyd er du med arbeidet i salongen?",
    description: "Vurder arbeidsmiljø, samarbeid og trivsel",
  },
  {
    id: "3",
    scoreField: "hjelp_leder_score",
    kommentarField: "hjelp_leder_kommentar",
    label: "Får du hjelpen du trenger fra leder?",
    description: "Vurder tilgjengelighet og støtte fra din leder",
  },
  {
    id: "4",
    scoreField: "kompetanse_score",
    kommentarField: "kompetanse_kommentar",
    label: "Hvordan vurderer du kompetansenivået ditt?",
    description: "Vurder dine faglige ferdigheter og kunnskap",
  },
  {
    id: "5",
    scoreField: "stotte_leder_score",
    kommentarField: "stotte_leder_kommentar",
    label: "Får du støtten du trenger fra leder?",
    description: "Vurder oppfølging, feedback og veiledning",
  },
];

const TEXT_QUESTIONS = [
  {
    id: "ferdigheter_utvikle",
    label: "Hvilke ferdigheter ønsker du å utvikle?",
    placeholder: "Beskriv områder du ønsker å bli bedre på...",
  },
  {
    id: "leder_hjelp_mal",
    label: "Hvordan kan leder hjelpe deg med å nå målene dine?",
    placeholder: "Beskriv hva slags støtte du ønsker...",
  },
  {
    id: "framtidige_mal",
    label: "Hvilke mål har du fremover?",
    placeholder: "Beskriv dine mål for neste periode...",
  },
  {
    id: "andre_tema",
    label: "Andre ting du vil ta opp?",
    placeholder: "Evt. andre tema du ønsker å diskutere...",
  },
];

export function MedarbeiderForberedelse() {
  const { samtaleId } = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [samtale, setSamtale] = useState<any>(null);
  const [formData, setFormData] = useState<Record<string, any>>({});

  const isLeder = searchParams.get("type") === "leder";

  useEffect(() => {
    const fetchData = async () => {
      if (!samtaleId || !user) return;

      try {
        // Fetch samtale
        const { data: samtaleData, error: samtaleError } = await supabase
          .from("ansatt_samtaler")
          .select(`
            *,
            users!ansatt_samtaler_user_id_fkey(id, name)
          `)
          .eq("id", samtaleId)
          .single();

        if (samtaleError) throw samtaleError;
        setSamtale(samtaleData);

        // Fetch existing forberedelse
        const { data: forberedelse } = await supabase
          .from("medarbeidersamtale_forberedelse")
          .select("*")
          .eq("samtale_id", samtaleId)
          .eq("utfylt_av_type", isLeder ? "leder" : "medarbeider")
          .single();

        if (forberedelse) {
          setFormData(forberedelse);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        toast({ title: "Feil", description: "Kunne ikke hente data", variant: "destructive" });
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [samtaleId, user, isLeder]);

  const handleScoreChange = (field: string, value: number[]) => {
    setFormData(prev => ({ ...prev, [field]: value[0] }));
  };

  const handleTextChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = async (markComplete: boolean = false) => {
    if (!samtaleId || !user) return;

    setSaving(true);
    try {
      const payload = {
        samtale_id: samtaleId,
        utfylt_av_type: isLeder ? "leder" : "medarbeider",
        ...formData,
        ferdig_utfylt: markComplete,
      };

      const { error } = await supabase
        .from("medarbeidersamtale_forberedelse")
        .upsert(payload, {
          onConflict: "samtale_id,utfylt_av_type",
        });

      if (error) throw error;

      toast({ 
        title: markComplete ? "Forberedelse fullført" : "Lagret", 
        description: markComplete ? "Din forberedelse er nå fullført" : "Endringene er lagret" 
      });

      if (markComplete) {
        navigate("/hr/utvikling");
      }
    } catch (error) {
      console.error("Error saving:", error);
      toast({ title: "Feil", description: "Kunne ikke lagre", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const getScoreLabel = (score: number) => {
    const labels = ["", "Svært misfornøyd", "Misfornøyd", "Nøytral", "Fornøyd", "Svært fornøyd"];
    return labels[score] || "";
  };

  if (loading) {
    return (
      <AppLayout title="Forberedelse" subtitle="">
        <div className="container mx-auto p-6 flex items-center justify-center min-h-[400px]">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
      </AppLayout>
    );
  }

  const questions = isLeder ? [] : MEDARBEIDER_QUESTIONS;
  const textQuestions = isLeder ? [
    { id: "styrker", label: "Hva er medarbeideren dyktig til?", placeholder: "Beskriv styrker..." },
    { id: "forbedringsomrader", label: "Hva kan medarbeideren bli bedre på?", placeholder: "Beskriv utviklingsområder..." },
    { id: "andre_tema_leder", label: "Andre tema du ønsker å ta opp?", placeholder: "Evt. andre tema..." },
  ] : TEXT_QUESTIONS;

  return (
    <AppLayout 
      title={isLeder ? "Lederens forberedelse" : "Min forberedelse"} 
      subtitle={`Samtale med ${samtale?.users?.name || ""}`}
    >
      <div className="container mx-auto p-6 max-w-3xl space-y-6">
        <Button variant="ghost" onClick={() => navigate("/hr/utvikling")}>
          <ArrowLeft className="h-4 w-4 mr-2" />
          Tilbake
        </Button>

        {/* Score-spørsmål (kun for medarbeider) */}
        {!isLeder && (
          <Card>
            <CardHeader>
              <CardTitle>Vurdering</CardTitle>
              <CardDescription>
                Svar på spørsmålene under. Dra slideren for å angi score 1-5.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-8">
              {questions.map((q) => (
                <div key={q.id} className="space-y-4">
                  <div>
                    <Label className="text-base">{q.label}</Label>
                    <p className="text-sm text-muted-foreground">{q.description}</p>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm text-muted-foreground">
                      <span>1</span>
                      <span className="font-medium">
                        {getScoreLabel(formData[q.scoreField] || 0)}
                      </span>
                      <span>5</span>
                    </div>
                    <Slider
                      value={[formData[q.scoreField] || 3]}
                      onValueChange={(value) => handleScoreChange(q.scoreField, value)}
                      min={1}
                      max={5}
                      step={1}
                      className="w-full"
                    />
                  </div>

                  <Textarea
                    placeholder="Legg til kommentar (valgfritt)..."
                    value={formData[q.kommentarField] || ""}
                    onChange={(e) => handleTextChange(q.kommentarField, e.target.value)}
                    rows={2}
                  />
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {/* Leder prestasjons-score */}
        {isLeder && (
          <Card>
            <CardHeader>
              <CardTitle>Vurdering av medarbeider</CardTitle>
              <CardDescription>
                Vurder medarbeiderens prestasjoner den siste perioden
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Hvor fornøyd er du med medarbeiderens prestasjoner?</Label>
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>1</span>
                  <span className="font-medium">
                    {getScoreLabel(formData.prestasjoner_score || 0)}
                  </span>
                  <span>5</span>
                </div>
                <Slider
                  value={[formData.prestasjoner_score || 3]}
                  onValueChange={(value) => handleScoreChange("prestasjoner_score", value)}
                  min={1}
                  max={5}
                  step={1}
                />
              </div>
              <Textarea
                placeholder="Kommentar til vurderingen..."
                value={formData.prestasjoner_kommentar || ""}
                onChange={(e) => handleTextChange("prestasjoner_kommentar", e.target.value)}
                rows={3}
              />
            </CardContent>
          </Card>
        )}

        {/* Tekstspørsmål */}
        <Card>
          <CardHeader>
            <CardTitle>{isLeder ? "Forberedelse" : "Refleksjon og mål"}</CardTitle>
            <CardDescription>
              {isLeder 
                ? "Dine notater er konfidensielle og ikke synlige for medarbeideren"
                : "Del dine tanker og mål for samtalen"
              }
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {textQuestions.map((q) => (
              <div key={q.id} className="space-y-2">
                <Label>{q.label}</Label>
                <Textarea
                  placeholder={q.placeholder}
                  value={formData[q.id] || ""}
                  onChange={(e) => handleTextChange(q.id, e.target.value)}
                  rows={3}
                />
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Handlinger */}
        <div className="flex justify-end gap-3">
          <Button variant="outline" onClick={() => handleSave(false)} disabled={saving}>
            {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            <Save className="h-4 w-4 mr-2" />
            Lagre utkast
          </Button>
          <Button onClick={() => handleSave(true)} disabled={saving}>
            {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            <CheckCircle2 className="h-4 w-4 mr-2" />
            Fullfør forberedelse
          </Button>
        </div>
      </div>
    </AppLayout>
  );
}
