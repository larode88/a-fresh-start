import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bell, Check, Calendar, Clock, MessageSquare, Activity } from "lucide-react";
import { format } from "date-fns";
import { nb } from "date-fns/locale";

interface Paminnelse {
  id: string;
  type: string;
  melding: string;
  lest: boolean;
  created_at: string;
}

interface PaminnelserPanelProps {
  userId: string;
}

const TYPE_ICONS: Record<string, React.ReactNode> = {
  ny_samtale_planlagt: <Calendar className="h-4 w-4" />,
  forberedelse_frist: <Clock className="h-4 w-4" />,
  samtale_i_dag: <MessageSquare className="h-4 w-4" />,
  oppgave_frist: <Clock className="h-4 w-4" />,
  puls_utsendt: <Activity className="h-4 w-4" />,
};

const TYPE_LABELS: Record<string, string> = {
  ny_samtale_planlagt: "Ny samtale",
  forberedelse_frist: "Forberedelse",
  samtale_i_dag: "Samtale i dag",
  oppgave_frist: "Oppgave",
  puls_utsendt: "Pulsundersøkelse",
};

export function PaminnelserPanel({ userId }: PaminnelserPanelProps) {
  const [paminnelser, setPaminnelser] = useState<Paminnelse[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPaminnelser = async () => {
      const { data, error } = await supabase
        .from("medarbeidersamtale_paminnelser")
        .select("*")
        .or(`ansatt_id.eq.${userId},leder_id.eq.${userId}`)
        .order("created_at", { ascending: false })
        .limit(50);

      if (!error && data) {
        setPaminnelser(data);
      }
      setLoading(false);
    };

    fetchPaminnelser();
  }, [userId]);

  const markAsRead = async (paminnelseId: string) => {
    await supabase
      .from("medarbeidersamtale_paminnelser")
      .update({ lest: true, lest_dato: new Date().toISOString() })
      .eq("id", paminnelseId);

    setPaminnelser(prev => 
      prev.map(p => p.id === paminnelseId ? { ...p, lest: true } : p)
    );
  };

  const markAllAsRead = async () => {
    const unreadIds = paminnelser.filter(p => !p.lest).map(p => p.id);
    if (unreadIds.length === 0) return;

    await supabase
      .from("medarbeidersamtale_paminnelser")
      .update({ lest: true, lest_dato: new Date().toISOString() })
      .in("id", unreadIds);

    setPaminnelser(prev => prev.map(p => ({ ...p, lest: true })));
  };

  const unreadCount = paminnelser.filter(p => !p.lest).length;

  if (loading) {
    return (
      <Card>
        <CardContent className="py-12">
          <div className="flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5" />
            Påminnelser
            {unreadCount > 0 && (
              <Badge variant="destructive">{unreadCount}</Badge>
            )}
          </CardTitle>
          <CardDescription>
            Varsler om samtaler, frister og pulsundersøkelser
          </CardDescription>
        </div>
        {unreadCount > 0 && (
          <Button variant="outline" size="sm" onClick={markAllAsRead}>
            <Check className="h-4 w-4 mr-2" />
            Marker alle som lest
          </Button>
        )}
      </CardHeader>
      <CardContent>
        {paminnelser.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Bell className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>Ingen påminnelser</p>
          </div>
        ) : (
          <div className="space-y-2">
            {paminnelser.map(paminnelse => (
              <div 
                key={paminnelse.id}
                className={`flex items-start gap-3 p-3 rounded-lg border transition-colors ${
                  !paminnelse.lest ? "bg-primary/5 border-primary/20" : "bg-card"
                }`}
              >
                <div className="flex-shrink-0 mt-0.5">
                  {TYPE_ICONS[paminnelse.type] || <Bell className="h-4 w-4" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-xs">
                      {TYPE_LABELS[paminnelse.type] || paminnelse.type}
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      {format(new Date(paminnelse.created_at), "d. MMM HH:mm", { locale: nb })}
                    </span>
                  </div>
                  <p className="text-sm mt-1">{paminnelse.melding}</p>
                </div>
                {!paminnelse.lest && (
                  <Button 
                    variant="ghost" 
                    size="icon"
                    onClick={() => markAsRead(paminnelse.id)}
                  >
                    <Check className="h-4 w-4" />
                  </Button>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
