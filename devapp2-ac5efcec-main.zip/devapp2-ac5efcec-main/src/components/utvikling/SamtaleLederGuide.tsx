import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Lock, Eye, AlertTriangle } from "lucide-react";
import type { Forberedelse, Samtale } from "@/pages/hr/SamtaleGjennomforing";

interface SamtaleLederGuideProps {
  lederForberedelse: Forberedelse | null;
  samtale: Samtale;
}

export function SamtaleLederGuide({ lederForberedelse, samtale }: SamtaleLederGuideProps) {
  const getScoreLabel = (score: number | undefined) => {
    if (!score) return "Ikke vurdert";
    const labels = ["", "Svært misfornøyd", "Misfornøyd", "Nøytral", "Fornøyd", "Svært fornøyd"];
    return labels[score];
  };

  return (
    <div className="p-4 space-y-4">
      {/* Konfidensialitets-varsel */}
      <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-3 flex items-start gap-2">
        <Lock className="h-4 w-4 text-amber-500 mt-0.5 flex-shrink-0" />
        <div>
          <p className="text-xs font-medium text-amber-600">Konfidensielt</p>
          <p className="text-xs text-muted-foreground">
            Denne informasjonen er kun synlig for deg som leder
          </p>
        </div>
      </div>

      {/* Din forberedelse */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <Eye className="h-4 w-4" />
            Din forberedelse
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {lederForberedelse ? (
            <>
              {lederForberedelse.prestasjoner_score && (
                <div>
                  <p className="text-xs text-muted-foreground">Prestasjonsvurdering</p>
                  <Badge variant="outline" className="mt-1">
                    {lederForberedelse.prestasjoner_score}/5 - {getScoreLabel(lederForberedelse.prestasjoner_score)}
                  </Badge>
                  {lederForberedelse.prestasjoner_kommentar && (
                    <p className="text-xs mt-2 italic">
                      "{lederForberedelse.prestasjoner_kommentar}"
                    </p>
                  )}
                </div>
              )}

              <Separator />

              {lederForberedelse.styrker && (
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Styrker</p>
                  <p className="text-sm">{lederForberedelse.styrker}</p>
                </div>
              )}

              {lederForberedelse.forbedringsomrader && (
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Forbedringsområder</p>
                  <p className="text-sm">{lederForberedelse.forbedringsomrader}</p>
                </div>
              )}

              {lederForberedelse.andre_tema_leder && (
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Andre tema</p>
                  <p className="text-sm">{lederForberedelse.andre_tema_leder}</p>
                </div>
              )}
            </>
          ) : (
            <div className="flex items-center gap-2 text-amber-600">
              <AlertTriangle className="h-4 w-4" />
              <p className="text-xs">Du har ikke fylt ut forberedelsen</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* KPI-resultater placeholder */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">📊 KPI-resultater</CardTitle>
          <CardDescription className="text-xs">
            Siste periode
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Omsetning</span>
              <span className="font-medium">-</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Varesalg %</span>
              <span className="font-medium">-</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Rebooking %</span>
              <span className="font-medium">-</span>
            </div>
          </div>
          <p className="text-xs text-muted-foreground mt-3 italic">
            KPI-data hentes fra rapporter
          </p>
        </CardContent>
      </Card>

      {/* Tidligere mål */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">🎯 Tidligere mål</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-xs text-muted-foreground italic">
            Ingen tidligere mål registrert
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
