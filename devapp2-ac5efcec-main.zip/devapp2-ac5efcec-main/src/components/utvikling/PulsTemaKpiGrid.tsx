import { Card, CardContent, CardDescription, CardHeader } from "@/components/ui/card";
import { TrendingUp, TrendingDown, Minus, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";
import { TEMA_CONFIG, type PulsTema, getScoreColor, getScoreBgColor } from "@/lib/pulsUtils";
import { Badge } from "@/components/ui/badge";

interface TemaStats {
  tema: PulsTema;
  avg: number;
  trend: number;
  antallSvar: number;
  risikoCount: number;
}

interface PulsTemaKpiGridProps {
  stats: TemaStats[];
  onTemaClick?: (tema: PulsTema) => void;
  selectedTema?: PulsTema | null;
}

export function PulsTemaKpiGrid({ stats, onTemaClick, selectedTema }: PulsTemaKpiGridProps) {
  const getTrendIcon = (trend: number) => {
    if (trend > 0.1) return <TrendingUp className="h-4 w-4 text-green-500" />;
    if (trend < -0.1) return <TrendingDown className="h-4 w-4 text-red-500" />;
    return <Minus className="h-4 w-4 text-muted-foreground" />;
  };

  const getTrendLabel = (trend: number) => {
    if (trend > 0.1) return `+${trend.toFixed(1)}`;
    if (trend < -0.1) return trend.toFixed(1);
    return "0";
  };

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
      {stats.map((stat) => {
        const config = TEMA_CONFIG[stat.tema];
        const isSelected = selectedTema === stat.tema;
        
        return (
          <Card 
            key={stat.tema}
            className={cn(
              "cursor-pointer transition-all hover:shadow-md overflow-hidden",
              getScoreBgColor(stat.avg),
              isSelected && "ring-2 ring-primary"
            )}
            onClick={() => onTemaClick?.(stat.tema)}
          >
            <CardHeader className="pb-2 pt-3 px-3">
              <CardDescription className="flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-xs">
                  <span className="text-base">{config.icon}</span>
                  <span className="hidden sm:inline">{config.label}</span>
                </span>
                {stat.risikoCount > 0 && (
                  <Badge variant="destructive" className="h-5 px-1.5 text-xs">
                    <AlertTriangle className="h-3 w-3 mr-0.5" />
                    {stat.risikoCount}
                  </Badge>
                )}
              </CardDescription>
            </CardHeader>
            <CardContent className="pb-3 px-3">
              <div className={cn("text-2xl font-bold", getScoreColor(stat.avg))}>
                {stat.avg > 0 ? stat.avg.toFixed(1) : "-"}
              </div>
              <div className="flex items-center justify-between mt-1">
                <span className="text-xs text-muted-foreground">
                  {stat.antallSvar} svar
                </span>
                <div className="flex items-center gap-1">
                  {getTrendIcon(stat.trend)}
                  <span className="text-xs">{getTrendLabel(stat.trend)}</span>
                </div>
              </div>
              
              {/* Mini-score bar */}
              <div className="flex gap-0.5 mt-2">
                {[1, 2, 3, 4, 5].map((score) => (
                  <div
                    key={score}
                    className={cn(
                      "h-1.5 flex-1 rounded-full",
                      score <= Math.round(stat.avg)
                        ? stat.avg >= 4 ? "bg-green-500" : stat.avg >= 3 ? "bg-yellow-500" : "bg-red-500"
                        : "bg-muted"
                    )}
                  />
                ))}
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
