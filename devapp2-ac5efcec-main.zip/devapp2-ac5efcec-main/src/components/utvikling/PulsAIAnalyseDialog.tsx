import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, Sparkles, CheckCircle, AlertTriangle, Calendar, TrendingUp, TrendingDown, Minus } from "lucide-react";
import { type PulsSvar, type PulsRisiko, type TemaStats, type PulsAIAnalyse, prepareAIAnalysisData } from "@/lib/pulsUtils";
import { useToast } from "@/hooks/use-toast";

interface PulsAIAnalyseDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  svar: PulsSvar[];
  risikoer: PulsRisiko[];
  temaStats: TemaStats[];
  antallAnsatte: number;
}

export function PulsAIAnalyseDialog({
  open,
  onOpenChange,
  svar,
  risikoer,
  temaStats,
  antallAnsatte,
}: PulsAIAnalyseDialogProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [analyse, setAnalyse] = useState<PulsAIAnalyse | null>(null);
  const [error, setError] = useState<string | null>(null);

  const generateAnalyse = async () => {
    setLoading(true);
    setError(null);

    try {
      const { temaData, overallScore } = prepareAIAnalysisData(svar, risikoer);
      
      const openRisikoer = risikoer
        .filter(r => r.status !== 'lukket')
        .map(r => ({
          tema: r.tema,
          score: r.score,
          foreslatte_tiltak: r.foreslatte_tiltak,
        }));

      const { data, error: fnError } = await supabase.functions.invoke('puls-ai-analyse', {
        body: {
          temaData,
          overallScore,
          antallSvar: svar.length,
          antallAnsatte,
          openRisikoer,
        }
      });

      if (fnError) throw fnError;
      if (data.error) throw new Error(data.error);

      setAnalyse(data as PulsAIAnalyse);
    } catch (err) {
      console.error("AI analyse error:", err);
      const message = err instanceof Error ? err.message : "Kunne ikke generere analyse";
      setError(message);
      toast({
        title: "Feil ved AI-analyse",
        description: message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const getSentimentIcon = (sentiment: string) => {
    switch (sentiment) {
      case 'positiv': return <TrendingUp className="h-5 w-5 text-green-500" />;
      case 'negativ': return <TrendingDown className="h-5 w-5 text-red-500" />;
      default: return <Minus className="h-5 w-5 text-amber-500" />;
    }
  };

  const getSentimentLabel = (sentiment: string) => {
    switch (sentiment) {
      case 'positiv': return 'Positivt';
      case 'negativ': return 'Krever oppmerksomhet';
      default: return 'Nøytralt';
    }
  };

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'positiv': return 'bg-green-50 border-green-200 text-green-800';
      case 'negativ': return 'bg-red-50 border-red-200 text-red-800';
      default: return 'bg-amber-50 border-amber-200 text-amber-800';
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" />
            AI-analyse av pulsundersøkelse
          </DialogTitle>
          <DialogDescription>
            Få innsikt og anbefalinger basert på teamets pulssvar
          </DialogDescription>
        </DialogHeader>

        {!analyse && !loading && (
          <div className="flex flex-col items-center py-8 gap-4">
            <div className="text-center space-y-2">
              <p className="text-muted-foreground">
                AI-analysen vil generere:
              </p>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Positive drivere i teamet</li>
                <li>• Risikoflagg som krever oppmerksomhet</li>
                <li>• 30/60/90-dagers tiltaksplan</li>
                <li>• Overordnet sentiment-vurdering</li>
              </ul>
            </div>
            <Button onClick={generateAnalyse} className="mt-4">
              <Sparkles className="h-4 w-4 mr-2" />
              Generer analyse
            </Button>
          </div>
        )}

        {loading && (
          <div className="flex flex-col items-center py-12 gap-4">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <p className="text-muted-foreground">Analyserer pulsdata...</p>
          </div>
        )}

        {error && !loading && (
          <div className="flex flex-col items-center py-8 gap-4">
            <AlertTriangle className="h-8 w-8 text-destructive" />
            <p className="text-destructive">{error}</p>
            <Button onClick={generateAnalyse} variant="outline">
              Prøv igjen
            </Button>
          </div>
        )}

        {analyse && !loading && (
          <div className="space-y-6">
            {/* Sentiment badge */}
            <div className={`p-4 rounded-lg border ${getSentimentColor(analyse.teamSentiment)}`}>
              <div className="flex items-center gap-2 mb-2">
                {getSentimentIcon(analyse.teamSentiment)}
                <span className="font-medium">Team-sentiment: {getSentimentLabel(analyse.teamSentiment)}</span>
              </div>
              <p className="text-sm">{analyse.sammendrag}</p>
            </div>

            {/* Positive drivere */}
            <div className="space-y-2">
              <h3 className="font-medium flex items-center gap-2 text-green-700">
                <CheckCircle className="h-4 w-4" />
                Positive drivere
              </h3>
              <div className="bg-green-50 rounded-lg p-4 space-y-2">
                {analyse.positiveDrivere.map((driver, i) => (
                  <div key={i} className="flex items-start gap-2 text-sm">
                    <span className="text-green-500 mt-0.5">✓</span>
                    <span>{driver}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Risikoflagg */}
            <div className="space-y-2">
              <h3 className="font-medium flex items-center gap-2 text-red-700">
                <AlertTriangle className="h-4 w-4" />
                Risikoflagg
              </h3>
              <div className="bg-red-50 rounded-lg p-4 space-y-2">
                {analyse.risikoFlagg.map((risiko, i) => (
                  <div key={i} className="flex items-start gap-2 text-sm">
                    <span className="text-red-500 mt-0.5">!</span>
                    <span>{risiko}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Tiltaksplan */}
            <div className="space-y-3">
              <h3 className="font-medium flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                Tiltaksplan
              </h3>
              
              <div className="grid gap-3">
                <div className="border rounded-lg p-4">
                  <Badge variant="outline" className="mb-2 bg-primary/10">30 dager</Badge>
                  <ul className="space-y-1 text-sm">
                    {analyse.tiltaksplan.dag30.map((tiltak, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="text-primary">•</span>
                        <span>{tiltak}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="border rounded-lg p-4">
                  <Badge variant="outline" className="mb-2 bg-secondary/50">60 dager</Badge>
                  <ul className="space-y-1 text-sm">
                    {analyse.tiltaksplan.dag60.map((tiltak, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="text-muted-foreground">•</span>
                        <span>{tiltak}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="border rounded-lg p-4">
                  <Badge variant="outline" className="mb-2">90 dager</Badge>
                  <ul className="space-y-1 text-sm">
                    {analyse.tiltaksplan.dag90.map((tiltak, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span className="text-muted-foreground">•</span>
                        <span>{tiltak}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            {/* Regenerate button */}
            <div className="flex justify-end pt-4 border-t">
              <Button onClick={generateAnalyse} variant="outline" size="sm">
                <Sparkles className="h-4 w-4 mr-2" />
                Generer ny analyse
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
