import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon, Loader2, Target } from "lucide-react";
import { format } from "date-fns";
import { nb } from "date-fns/locale";
import { cn } from "@/lib/utils";

interface SmartMalDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  samtaleId: string;
  userId: string;
  onSuccess: () => void;
}

export function SmartMalDialog({
  open,
  onOpenChange,
  samtaleId,
  userId,
  onSuccess,
}: SmartMalDialogProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  
  const [tittel, setTittel] = useState("");
  const [spesifikt, setSpesifikt] = useState("");
  const [maalbart, setMaalbart] = useState("");
  const [oppnaaelig, setOppnaaelig] = useState("");
  const [relevant, setRelevant] = useState("");
  const [tidsbestemt, setTidsbestemt] = useState("");
  const [frist, setFrist] = useState<Date>();

  const handleSubmit = async () => {
    if (!tittel || !spesifikt || !maalbart || !oppnaaelig || !relevant || !tidsbestemt) {
      toast({ 
        title: "Alle felt er påkrevd", 
        description: "Fyll ut alle SMART-kriteriene", 
        variant: "destructive" 
      });
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase.from("samtale_smart_mal").insert({
        samtale_id: samtaleId,
        user_id: userId,
        tittel,
        spesifikt,
        maalbart,
        oppnaaelig,
        relevant,
        tidsbestemt,
        frist: frist ? format(frist, "yyyy-MM-dd") : null,
      });

      if (error) throw error;

      toast({ title: "SMART-mål opprettet", description: "Målet er lagret" });
      onSuccess();
      onOpenChange(false);
      resetForm();
    } catch (error) {
      console.error("Error creating SMART goal:", error);
      toast({ title: "Feil", description: "Kunne ikke opprette mål", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setTittel("");
    setSpesifikt("");
    setMaalbart("");
    setOppnaaelig("");
    setRelevant("");
    setTidsbestemt("");
    setFrist(undefined);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            Nytt SMART-mål
          </DialogTitle>
          <DialogDescription>
            Opprett et mål som er Spesifikt, Målbart, Oppnåelig, Relevant og Tidsbestemt
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Tittel *</Label>
            <Input
              placeholder="Kort beskrivelse av målet"
              value={tittel}
              onChange={(e) => setTittel(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <span className="bg-primary text-primary-foreground px-2 py-0.5 rounded text-xs font-bold">S</span>
              Spesifikt - Hva skal oppnås? *
            </Label>
            <Textarea
              placeholder="Beskriv konkret hva som skal oppnås..."
              value={spesifikt}
              onChange={(e) => setSpesifikt(e.target.value)}
              rows={2}
            />
          </div>

          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <span className="bg-primary text-primary-foreground px-2 py-0.5 rounded text-xs font-bold">M</span>
              Målbart - Hvordan måles fremgang? *
            </Label>
            <Textarea
              placeholder="Beskriv hvordan du vet at målet er nådd..."
              value={maalbart}
              onChange={(e) => setMaalbart(e.target.value)}
              rows={2}
            />
          </div>

          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <span className="bg-primary text-primary-foreground px-2 py-0.5 rounded text-xs font-bold">A</span>
              Oppnåelig - Er det realistisk? *
            </Label>
            <Textarea
              placeholder="Beskriv hvorfor målet er realistisk å oppnå..."
              value={oppnaaelig}
              onChange={(e) => setOppnaaelig(e.target.value)}
              rows={2}
            />
          </div>

          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <span className="bg-primary text-primary-foreground px-2 py-0.5 rounded text-xs font-bold">R</span>
              Relevant - Hvorfor er det viktig? *
            </Label>
            <Textarea
              placeholder="Beskriv hvorfor dette målet er viktig..."
              value={relevant}
              onChange={(e) => setRelevant(e.target.value)}
              rows={2}
            />
          </div>

          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <span className="bg-primary text-primary-foreground px-2 py-0.5 rounded text-xs font-bold">T</span>
              Tidsbestemt - Når skal det være ferdig? *
            </Label>
            <Textarea
              placeholder="Beskriv tidsrammen for målet..."
              value={tidsbestemt}
              onChange={(e) => setTidsbestemt(e.target.value)}
              rows={2}
            />
          </div>

          <div className="space-y-2">
            <Label>Frist (valgfritt)</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !frist && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {frist ? format(frist, "d. MMMM yyyy", { locale: nb }) : "Velg frist"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={frist}
                  onSelect={setFrist}
                  disabled={(date) => date < new Date()}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Avbryt
          </Button>
          <Button onClick={handleSubmit} disabled={loading}>
            {loading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Opprett mål
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
