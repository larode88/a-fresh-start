import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { 
  ListTodo, Target, CheckCircle2, Clock, AlertTriangle,
  User, Calendar, MoreHorizontal
} from "lucide-react";
import { format, isPast, isToday } from "date-fns";
import { nb } from "date-fns/locale";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface Oppgave {
  id: string;
  tittel: string;
  beskrivelse: string | null;
  ansvarlig_id: string;
  ansvarlig_type: string;
  frist: string | null;
  prioritet: string;
  status: string;
  ansvarlig?: { name: string };
}

interface SmartMal {
  id: string;
  tittel: string;
  spesifikt: string;
  frist: string | null;
  status: string;
  fremgang: number;
  user?: { name: string };
}

interface AksjonspunktOversiktProps {
  salonId: string;
  userId?: string;
  canManage: boolean;
}

const PRIORITET_COLORS: Record<string, string> = {
  lav: "text-muted-foreground",
  normal: "text-foreground",
  hoy: "text-orange-500",
  kritisk: "text-destructive",
};

const STATUS_CONFIG: Record<string, { label: string; variant: "default" | "secondary" | "outline" | "destructive" }> = {
  aapen: { label: "Åpen", variant: "secondary" },
  pagaende: { label: "Pågår", variant: "default" },
  fullfort: { label: "Fullført", variant: "secondary" },
  avbrutt: { label: "Avbrutt", variant: "destructive" },
  ikke_startet: { label: "Ikke startet", variant: "secondary" },
};

export function AksjonspunktOversikt({ salonId, userId, canManage }: AksjonspunktOversiktProps) {
  const { toast } = useToast();
  const [oppgaver, setOppgaver] = useState<Oppgave[]>([]);
  const [smartMal, setSmartMal] = useState<SmartMal[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    try {
      // Fetch oppgaver via samtaler in this salon
      const { data: samtaler } = await supabase
        .from("ansatt_samtaler")
        .select("id")
        .eq("salon_id", salonId);

      if (samtaler && samtaler.length > 0) {
        const samtaleIds = samtaler.map(s => s.id);
        
        let oppgaverQuery = supabase
          .from("mote_oppgaver")
          .select(`
            *,
            ansvarlig:users!mote_oppgaver_ansvarlig_id_fkey(name)
          `)
          .in("samtale_id", samtaleIds)
          .neq("status", "fullfort")
          .order("frist", { ascending: true, nullsFirst: false });

        if (userId) {
          oppgaverQuery = oppgaverQuery.eq("ansvarlig_id", userId);
        }

        const { data: oppgaverData } = await oppgaverQuery;
        setOppgaver((oppgaverData as unknown as Oppgave[]) || []);

        // Fetch SMART-mål
        let malQuery = supabase
          .from("samtale_smart_mal")
          .select(`
            *,
            user:users!samtale_smart_mal_user_id_fkey(name)
          `)
          .in("samtale_id", samtaleIds)
          .neq("status", "fullfort")
          .order("frist", { ascending: true, nullsFirst: false });

        if (userId) {
          malQuery = malQuery.eq("user_id", userId);
        }

        const { data: malData } = await malQuery;
        setSmartMal((malData as unknown as SmartMal[]) || []);
      }
    } catch (error) {
      console.error("Error fetching aksjonspunkter:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [salonId, userId]);

  const updateOppgaveStatus = async (oppgaveId: string, status: string) => {
    try {
      await supabase
        .from("mote_oppgaver")
        .update({ status })
        .eq("id", oppgaveId);

      toast({ title: "Status oppdatert" });
      fetchData();
    } catch (error) {
      toast({ title: "Feil", description: "Kunne ikke oppdatere status", variant: "destructive" });
    }
  };

  const updateMalStatus = async (malId: string, status: string) => {
    try {
      await supabase
        .from("samtale_smart_mal")
        .update({ status })
        .eq("id", malId);

      toast({ title: "Status oppdatert" });
      fetchData();
    } catch (error) {
      toast({ title: "Feil", description: "Kunne ikke oppdatere status", variant: "destructive" });
    }
  };

  const isOverdue = (frist: string | null) => {
    if (!frist) return false;
    return isPast(new Date(frist)) && !isToday(new Date(frist));
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="py-12">
          <div className="flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Tabs defaultValue="oppgaver" className="space-y-4">
      <TabsList>
        <TabsTrigger value="oppgaver" className="flex items-center gap-2">
          <ListTodo className="h-4 w-4" />
          Oppgaver ({oppgaver.length})
        </TabsTrigger>
        <TabsTrigger value="mal" className="flex items-center gap-2">
          <Target className="h-4 w-4" />
          SMART-mål ({smartMal.length})
        </TabsTrigger>
      </TabsList>

      <TabsContent value="oppgaver">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ListTodo className="h-5 w-5" />
              Åpne oppgaver
            </CardTitle>
            <CardDescription>
              Oppgaver fra medarbeidersamtaler som ikke er fullført
            </CardDescription>
          </CardHeader>
          <CardContent>
            {oppgaver.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <CheckCircle2 className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Ingen åpne oppgaver</p>
              </div>
            ) : (
              <div className="space-y-3">
                {oppgaver.map(oppgave => (
                  <div 
                    key={oppgave.id}
                    className="flex items-center justify-between p-4 rounded-lg border"
                  >
                    <div className="flex items-center gap-4">
                      <div className="flex flex-col items-center gap-1">
                        {oppgave.ansvarlig_type === "medarbeider" ? (
                          <User className="h-4 w-4 text-muted-foreground" />
                        ) : (
                          <User className="h-4 w-4 text-primary" />
                        )}
                        <span className="text-xs text-muted-foreground">
                          {oppgave.ansvarlig_type === "medarbeider" ? "MA" : "LE"}
                        </span>
                      </div>
                      <div>
                        <div className={`font-medium ${PRIORITET_COLORS[oppgave.prioritet]}`}>
                          {oppgave.tittel}
                        </div>
                        {oppgave.beskrivelse && (
                          <p className="text-sm text-muted-foreground line-clamp-1">
                            {oppgave.beskrivelse}
                          </p>
                        )}
                        <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                          <span>{oppgave.ansvarlig?.name}</span>
                          {oppgave.frist && (
                            <>
                              <span>•</span>
                              <span className={isOverdue(oppgave.frist) ? "text-destructive" : ""}>
                                {isOverdue(oppgave.frist) && <AlertTriangle className="h-3 w-3 inline mr-1" />}
                                Frist: {format(new Date(oppgave.frist), "d. MMM", { locale: nb })}
                              </span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <Badge variant={STATUS_CONFIG[oppgave.status]?.variant || "outline"}>
                        {STATUS_CONFIG[oppgave.status]?.label || oppgave.status}
                      </Badge>
                      
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => updateOppgaveStatus(oppgave.id, "pagaende")}>
                            Sett til pågår
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => updateOppgaveStatus(oppgave.id, "fullfort")}>
                            <CheckCircle2 className="h-4 w-4 mr-2" />
                            Marker som fullført
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </TabsContent>

      <TabsContent value="mal">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5" />
              Aktive SMART-mål
            </CardTitle>
            <CardDescription>
              Mål opprettet i medarbeidersamtaler
            </CardDescription>
          </CardHeader>
          <CardContent>
            {smartMal.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Target className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Ingen aktive mål</p>
              </div>
            ) : (
              <div className="space-y-4">
                {smartMal.map(mal => (
                  <div 
                    key={mal.id}
                    className="p-4 rounded-lg border space-y-3"
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="font-medium">{mal.tittel}</div>
                        <p className="text-sm text-muted-foreground line-clamp-2">
                          {mal.spesifikt}
                        </p>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => updateMalStatus(mal.id, "pagaende")}>
                            Sett til pågår
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => updateMalStatus(mal.id, "fullfort")}>
                            <CheckCircle2 className="h-4 w-4 mr-2" />
                            Marker som fullført
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>

                    <div className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Fremgang</span>
                        <span>{mal.fremgang}%</span>
                      </div>
                      <Progress value={mal.fremgang} className="h-2" />
                    </div>

                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <span>{mal.user?.name}</span>
                      {mal.frist && (
                        <span className={isOverdue(mal.frist) ? "text-destructive" : ""}>
                          {isOverdue(mal.frist) && <AlertTriangle className="h-3 w-3 inline mr-1" />}
                          Frist: {format(new Date(mal.frist), "d. MMM yyyy", { locale: nb })}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>
  );
}
