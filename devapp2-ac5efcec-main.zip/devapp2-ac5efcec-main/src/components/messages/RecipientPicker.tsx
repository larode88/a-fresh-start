import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Search, Users, Building2, User, HeadphonesIcon, Truck } from "lucide-react";
import { cn } from "@/lib/utils";

interface Recipient {
  id: string;
  name: string;
  email: string;
  avatar_url: string | null;
  role: string;
  category: string;
}

interface RecipientPickerProps {
  selectedRecipients: Recipient[];
  onSelectRecipient: (recipient: Recipient) => void;
  onRemoveRecipient: (recipientId: string) => void;
}

const roleLabels: Record<string, string> = {
  admin: "Admin",
  district_manager: "Distriktssjef",
  salon_owner: "Salongeier",
  chain_owner: "Kjedeeier",
  daglig_leder: "Daglig leder",
  avdelingsleder: "Avdelingsleder",
  styreleder: "Styreleder",
  stylist: "Frisør",
  seniorfrisor: "Seniorfrisør",
  apprentice: "Lærling",
  supplier_admin: "Leverandør Admin",
  supplier_sales: "Leverandør Salg",
  supplier_business_dev: "Leverandør Forretning",
};

const categoryIcons: Record<string, React.ReactNode> = {
  team: <Users className="h-4 w-4" />,
  salon: <Building2 className="h-4 w-4" />,
  support: <HeadphonesIcon className="h-4 w-4" />,
  individual: <User className="h-4 w-4" />,
  supplier: <Truck className="h-4 w-4" />,
};

const categoryLabels: Record<string, string> = {
  team: "Mitt team",
  salon: "Salonger",
  support: "Hår1 Support",
  individual: "Kontakter",
  supplier: "Leverandører",
};

export const RecipientPicker = ({
  selectedRecipients,
  onSelectRecipient,
  onRemoveRecipient,
}: RecipientPickerProps) => {
  const { profile } = useAuth();
  const [search, setSearch] = useState("");
  const [contacts, setContacts] = useState<Recipient[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchContacts = async () => {
      if (!profile) return;

      try {
        const contactsList: Recipient[] = [];
        const userRole = profile.role;
        const addedUserIds = new Set<string>();

        const addContact = (user: any, category: string) => {
          if (user.id !== profile.id && !addedUserIds.has(user.id)) {
            addedUserIds.add(user.id);
            contactsList.push({
              id: user.id,
              name: user.name,
              email: user.email,
              avatar_url: user.avatar_url,
              role: user.role,
              category,
            });
          }
        };

        // ADMIN: Alle brukere
        if (userRole === "admin") {
          const { data: allUsers } = await supabase
            .from("users")
            .select("id, name, email, avatar_url, role")
            .neq("id", profile.id)
            .limit(200);

          allUsers?.forEach((user) => addContact(user, "individual"));
        }

        // DISTRICT MANAGER: Alle brukere i salonger i sitt distrikt + admins
        if (userRole === "district_manager" && profile.district_id) {
          // Hent alle salonger i distriktet
          const { data: salons } = await supabase
            .from("salons")
            .select("id, name")
            .eq("district_id", profile.district_id);

          if (salons?.length) {
            const salonIds = salons.map((s) => s.id);
            
            // Hent alle brukere i disse salongene
            const { data: salonUsers } = await supabase
              .from("users")
              .select("id, name, email, avatar_url, role")
              .in("salon_id", salonIds);

            salonUsers?.forEach((user) => addContact(user, "salon"));
          }

          // Hent andre admins
          const { data: admins } = await supabase
            .from("users")
            .select("id, name, email, avatar_url, role")
            .eq("role", "admin");

          admins?.forEach((admin) => addContact(admin, "support"));
        }

        // SALON OWNER: Team + leverandører + distriktssjef
        if (userRole === "salon_owner" && profile.salon_id) {
          // Hent teammedlemmer i salongen
          const { data: teamMembers } = await supabase
            .from("users")
            .select("id, name, email, avatar_url, role")
            .eq("salon_id", profile.salon_id)
            .neq("id", profile.id);

          teamMembers?.forEach((member) => addContact(member, "team"));

          // Hent distriktssjef for salongen
          const { data: salon } = await supabase
            .from("salons")
            .select("district_id")
            .eq("id", profile.salon_id)
            .single();

          if (salon?.district_id) {
            const { data: districtManagers } = await supabase
              .from("users")
              .select("id, name, email, avatar_url, role")
              .eq("district_id", salon.district_id)
              .eq("role", "district_manager");

            districtManagers?.forEach((dm) => addContact(dm, "support"));
          }

          // Hent leverandører koblet til salongen
          const { data: salonSuppliers } = await supabase
            .from("salon_suppliers")
            .select("supplier_id")
            .eq("salon_id", profile.salon_id);

          if (salonSuppliers?.length) {
            const supplierIds = salonSuppliers.map((ss) => ss.supplier_id).filter(Boolean);

            if (supplierIds.length) {
              // Hent alle team-medlemmer fra disse leverandørene
              const { data: supplierTeamUsers } = await supabase
                .from("supplier_team_users")
                .select("user_id")
                .in("supplier_id", supplierIds);

              if (supplierTeamUsers?.length) {
                const userIds = supplierTeamUsers.map((stu) => stu.user_id).filter(Boolean);

                const { data: supplierUsers } = await supabase
                  .from("users")
                  .select("id, name, email, avatar_url, role")
                  .in("id", userIds);

                supplierUsers?.forEach((user) => addContact(user, "supplier"));
              }
            }
          }

          // Hår1 admins
          const { data: admins } = await supabase
            .from("users")
            .select("id, name, email, avatar_url, role")
            .eq("role", "admin");

          admins?.forEach((admin) => addContact(admin, "support"));
        }

        // STYLIST/SENIORFRISØR/APPRENTICE: Team + distriktssjef
        if ((userRole === "stylist" || userRole === "seniorfrisor" || userRole === "apprentice") && profile.salon_id) {
          // Hent teammedlemmer i salongen
          const { data: teamMembers } = await supabase
            .from("users")
            .select("id, name, email, avatar_url, role")
            .eq("salon_id", profile.salon_id)
            .neq("id", profile.id);

          teamMembers?.forEach((member) => addContact(member, "team"));

          // Hent distriktssjef for salongen
          const { data: salon } = await supabase
            .from("salons")
            .select("district_id")
            .eq("id", profile.salon_id)
            .single();

          if (salon?.district_id) {
            const { data: districtManagers } = await supabase
              .from("users")
              .select("id, name, email, avatar_url, role")
              .eq("district_id", salon.district_id)
              .eq("role", "district_manager");

            districtManagers?.forEach((dm) => addContact(dm, "support"));
          }
        }

        // SUPPLIER ROLES: Brukere i dedikerte salonger + alle Hår1 (admin + district_manager)
        if (["supplier_admin", "supplier_sales", "supplier_business_dev"].includes(userRole)) {
          // Finn hvilken leverandør brukeren tilhører
          const { data: supplierMembership } = await supabase
            .from("supplier_team_users")
            .select("supplier_id")
            .eq("user_id", profile.id)
            .maybeSingle();

          if (supplierMembership?.supplier_id) {
            // Hent alle salonger koblet til denne leverandøren
            const { data: linkedSalons } = await supabase
              .from("salon_suppliers")
              .select("salon_id")
              .eq("supplier_id", supplierMembership.supplier_id);

            if (linkedSalons?.length) {
              const salonIds = linkedSalons.map((ls) => ls.salon_id).filter(Boolean);

              // Hent alle brukere i disse salongene
              const { data: salonUsers } = await supabase
                .from("users")
                .select("id, name, email, avatar_url, role")
                .in("salon_id", salonIds);

              salonUsers?.forEach((user) => addContact(user, "salon"));
            }
          }

          // Hent alle Hår1-ansatte (admin + district_manager)
          const { data: har1Staff } = await supabase
            .from("users")
            .select("id, name, email, avatar_url, role")
            .in("role", ["admin", "district_manager"]);

          har1Staff?.forEach((staff) => addContact(staff, "support"));
        }

        setContacts(contactsList);
      } catch (error) {
        console.error("Error fetching contacts:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchContacts();
  }, [profile]);

  const filteredContacts = contacts.filter(
    (contact) =>
      !selectedRecipients.find((r) => r.id === contact.id) &&
      (contact.name.toLowerCase().includes(search.toLowerCase()) ||
        contact.email.toLowerCase().includes(search.toLowerCase()))
  );

  const groupedContacts = filteredContacts.reduce((acc, contact) => {
    const category = contact.category;
    if (!acc[category]) acc[category] = [];
    acc[category].push(contact);
    return acc;
  }, {} as Record<string, Recipient[]>);

  // Sort categories in preferred order
  const categoryOrder = ["team", "salon", "supplier", "support", "individual"];
  const sortedCategories = Object.keys(groupedContacts).sort(
    (a, b) => categoryOrder.indexOf(a) - categoryOrder.indexOf(b)
  );

  return (
    <div className="space-y-3">
      {/* Selected recipients */}
      {selectedRecipients.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {selectedRecipients.map((recipient) => (
            <Badge
              key={recipient.id}
              variant="secondary"
              className="flex items-center gap-1 pr-1"
            >
              <span>{recipient.name}</span>
              <button
                type="button"
                onClick={() => onRemoveRecipient(recipient.id)}
                className="ml-1 rounded-full p-0.5 hover:bg-muted"
              >
                ×
              </button>
            </Badge>
          ))}
        </div>
      )}

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Søk etter mottaker..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      {/* Contact list */}
      <ScrollArea className="h-[200px] border rounded-md">
        {loading ? (
          <div className="p-4 text-center text-muted-foreground text-sm">
            Laster kontakter...
          </div>
        ) : filteredContacts.length === 0 ? (
          <div className="p-4 text-center text-muted-foreground text-sm">
            {search ? "Ingen treff" : "Ingen kontakter tilgjengelig"}
          </div>
        ) : (
          <div className="p-2">
            {sortedCategories.map((category) => (
              <div key={category} className="mb-3">
                <div className="flex items-center gap-2 px-2 py-1 text-xs font-medium text-muted-foreground uppercase">
                  {categoryIcons[category]}
                  {categoryLabels[category] || category}
                </div>
                {groupedContacts[category].map((contact) => (
                  <button
                    key={contact.id}
                    type="button"
                    onClick={() => onSelectRecipient(contact)}
                    className={cn(
                      "w-full flex items-center gap-3 p-2 rounded-md hover:bg-muted transition-colors text-left"
                    )}
                  >
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={contact.avatar_url || undefined} />
                      <AvatarFallback>
                        {contact.name.charAt(0).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{contact.name}</p>
                      <p className="text-xs text-muted-foreground truncate">
                        {roleLabels[contact.role] || contact.role}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            ))}
          </div>
        )}
      </ScrollArea>
    </div>
  );
};
