import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { nb } from "date-fns/locale";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Archive, Trash2, ArchiveRestore, MoreVertical } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useSwipe } from "@/hooks/useSwipe";
import { useIsMobile } from "@/hooks/use-mobile";
import { ThreadWithUnread } from "./ThreadList";

interface SwipeableThreadItemProps {
  thread: ThreadWithUnread;
  isSelected: boolean;
  showArchived: boolean;
  onSelect: () => void;
  onArchive?: () => void;
  onDelete?: () => void;
  onRestore?: () => void;
}

export const SwipeableThreadItem = ({
  thread,
  isSelected,
  showArchived,
  onSelect,
  onArchive,
  onDelete,
  onRestore,
}: SwipeableThreadItemProps) => {
  const isMobile = useIsMobile();
  
  const { offsetX, handlers, reset } = useSwipe({
    onSwipeLeft: () => {
      if (showArchived) {
        onRestore?.();
      } else {
        onArchive?.();
      }
      reset();
    },
    threshold: 80,
    maxSwipe: 120,
  });

  const swipeProgress = Math.min(Math.abs(offsetX) / 80, 1);
  const showAction = Math.abs(offsetX) > 30;

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  const participantNames = thread.participants?.map((p) => p.name).join(", ") || "Ukjent";

  return (
    <div
      className={cn(
        "relative overflow-hidden",
        isSelected && "bg-muted",
        thread.hasUnread && "bg-primary/5"
      )}
    >
      {/* Swipe action background */}
      {isMobile && (
        <div
          className={cn(
            "absolute inset-y-0 right-0 flex items-center justify-end px-4 transition-colors",
            showArchived ? "bg-blue-500" : "bg-blue-500",
            swipeProgress > 0.8 && !showArchived && "bg-destructive"
          )}
          style={{ width: Math.abs(offsetX) + 20 }}
        >
          {showAction && (
            <div className="flex items-center gap-2 text-white">
              {showArchived ? (
                <>
                  <ArchiveRestore className="h-5 w-5" />
                  <span className="text-sm font-medium">Gjenopprett</span>
                </>
              ) : (
                <>
                  <Archive className="h-5 w-5" />
                  <span className="text-sm font-medium">Arkiver</span>
                </>
              )}
            </div>
          )}
        </div>
      )}

      {/* Thread content */}
      <div
        className={cn(
          "relative bg-background transition-transform",
          !isMobile && "group"
        )}
        style={{
          transform: isMobile ? `translateX(${offsetX}px)` : undefined,
          transition: offsetX === 0 ? "transform 0.2s ease-out" : undefined,
        }}
        {...(isMobile ? handlers : {})}
      >
        <button
          onClick={onSelect}
          className={cn(
            "w-full text-left p-4 hover:bg-muted/50 transition-colors"
          )}
        >
          <div className="flex items-start gap-3">
            {/* Participant avatars */}
            <div className="flex-shrink-0">
              {!thread.participants || thread.participants.length === 0 ? (
                <Avatar className="h-10 w-10">
                  <AvatarFallback>?</AvatarFallback>
                </Avatar>
              ) : thread.participants.length === 1 ? (
                <Avatar className="h-10 w-10">
                  <AvatarImage src={thread.participants[0].avatar_url || undefined} />
                  <AvatarFallback>{getInitials(thread.participants[0].name)}</AvatarFallback>
                </Avatar>
              ) : (
                <div className="relative h-10 w-10">
                  <Avatar className="h-7 w-7 absolute top-0 left-0 border-2 border-background">
                    <AvatarImage src={thread.participants[0]?.avatar_url || undefined} />
                    <AvatarFallback className="text-xs">
                      {getInitials(thread.participants[0]?.name || "?")}
                    </AvatarFallback>
                  </Avatar>
                  <Avatar className="h-7 w-7 absolute bottom-0 right-0 border-2 border-background">
                    <AvatarImage src={thread.participants[1]?.avatar_url || undefined} />
                    <AvatarFallback className="text-xs">
                      {thread.participants.length > 2
                        ? `+${thread.participants.length - 1}`
                        : getInitials(thread.participants[1]?.name || "?")}
                    </AvatarFallback>
                  </Avatar>
                </div>
              )}
            </div>

            {/* Thread info */}
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-2">
                <p
                  className={cn(
                    "font-medium text-foreground truncate flex-1",
                    thread.hasUnread && "font-semibold"
                  )}
                >
                  {thread.subject}
                </p>
                {thread.hasUnread && (
                  <Badge
                    variant="default"
                    className="h-5 min-w-5 flex items-center justify-center text-xs flex-shrink-0"
                  >
                    Ny
                  </Badge>
                )}
              </div>
              <p className="text-sm text-muted-foreground truncate">{participantNames}</p>
              {thread.last_message && (
                <p className="text-sm text-muted-foreground truncate mt-1">
                  {thread.senderName && (
                    <span className="font-medium">{thread.senderName}: </span>
                  )}
                  {thread.last_message}
                </p>
              )}
              <p className="text-xs text-muted-foreground mt-1">
                {format(
                  new Date(thread.last_message_at || thread.created_at),
                  "d. MMM yyyy HH:mm",
                  { locale: nb }
                )}
              </p>
            </div>
          </div>
        </button>

        {/* Desktop dropdown menu */}
        {!isMobile && (
          <div className="absolute right-2 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8">
                  <MoreVertical className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {showArchived ? (
                  <DropdownMenuItem onClick={onRestore}>
                    <ArchiveRestore className="h-4 w-4 mr-2" />
                    Gjenopprett
                  </DropdownMenuItem>
                ) : (
                  <DropdownMenuItem onClick={onArchive}>
                    <Archive className="h-4 w-4 mr-2" />
                    Arkiver
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem
                  onClick={onDelete}
                  className="text-destructive focus:text-destructive"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Slett
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        )}
      </div>
    </div>
  );
};
