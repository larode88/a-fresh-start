import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { MessageThread } from "@/pages/Messages";
import { RecipientPicker } from "./RecipientPicker";

interface Recipient {
  id: string;
  name: string;
  email: string;
  avatar_url: string | null;
  role: string;
  category: string;
}

interface ComposeDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onThreadCreated: (thread: MessageThread) => void;
  userSalonId?: string | null;
  userDistrictId?: string | null;
}

export const ComposeDialog = ({
  open,
  onOpenChange,
  onThreadCreated,
  userSalonId,
  userDistrictId,
}: ComposeDialogProps) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [selectedRecipients, setSelectedRecipients] = useState<Recipient[]>([]);
  const [loading, setLoading] = useState(false);

  const handleSelectRecipient = (recipient: Recipient) => {
    setSelectedRecipients((prev) => [...prev, recipient]);
  };

  const handleRemoveRecipient = (recipientId: string) => {
    setSelectedRecipients((prev) => prev.filter((r) => r.id !== recipientId));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject.trim() || !message.trim() || !user || selectedRecipients.length === 0) return;

    setLoading(true);
    try {
      // Create thread
      const { data: thread, error: threadError } = await supabase
        .from("message_threads")
        .insert({
          subject: subject.trim(),
          created_by_user_id: user.id,
          salon_id: userSalonId,
          district_id: userDistrictId,
        })
        .select()
        .single();

      if (threadError) throw threadError;

      // Add both creator and recipients as participants
      const participantInserts = [
        { thread_id: thread.id, user_id: user.id }, // Creator
        ...selectedRecipients.map((recipient) => ({
          thread_id: thread.id,
          user_id: recipient.id,
        })),
      ];

      const { error: participantError } = await supabase
        .from("thread_participants")
        .insert(participantInserts);

      if (participantError) {
        console.error("Error adding participants:", participantError);
      }

      // Create first message
      const { error: messageError } = await supabase.from("messages").insert({
        thread_id: thread.id,
        sender_user_id: user.id,
        message_text: message.trim(),
      });

      if (messageError) throw messageError;

      toast({
        title: "Melding sendt",
        description: `Meldingen er sendt til ${selectedRecipients.map((r) => r.name).join(", ")}`,
      });

      onThreadCreated(thread);
      setSubject("");
      setMessage("");
      setSelectedRecipients([]);
    } catch (error) {
      console.error("Error creating thread:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke opprette melding",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setSubject("");
    setMessage("");
    setSelectedRecipients([]);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Ny melding</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label>Til</Label>
            <RecipientPicker
              selectedRecipients={selectedRecipients}
              onSelectRecipient={handleSelectRecipient}
              onRemoveRecipient={handleRemoveRecipient}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="subject">Emne</Label>
            <Input
              id="subject"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="Skriv et emne..."
              required
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="message">Melding</Label>
            <Textarea
              id="message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Skriv din melding..."
              rows={4}
              required
            />
          </div>
          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={handleClose}>
              Avbryt
            </Button>
            <Button
              type="submit"
              disabled={loading || !subject.trim() || !message.trim() || selectedRecipients.length === 0}
            >
              {loading ? "Sender..." : "Send"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};
