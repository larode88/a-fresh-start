import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { RecipientPicker } from "./RecipientPicker";

interface Recipient {
  id: string;
  name: string;
  email: string;
  avatar_url: string | null;
  role: string;
  category: string;
}

interface AddParticipantsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  threadId: string;
  existingParticipantIds: string[];
  onParticipantsAdded: () => void;
}

export const AddParticipantsDialog = ({
  open,
  onOpenChange,
  threadId,
  existingParticipantIds,
  onParticipantsAdded,
}: AddParticipantsDialogProps) => {
  const { toast } = useToast();
  const [selectedRecipients, setSelectedRecipients] = useState<Recipient[]>([]);
  const [loading, setLoading] = useState(false);

  const handleSelectRecipient = (recipient: Recipient) => {
    // Don't add if already a participant
    if (existingParticipantIds.includes(recipient.id)) {
      toast({
        title: "Allerede deltaker",
        description: `${recipient.name} er allerede med i samtalen`,
        variant: "destructive",
      });
      return;
    }
    setSelectedRecipients((prev) => [...prev, recipient]);
  };

  const handleRemoveRecipient = (recipientId: string) => {
    setSelectedRecipients((prev) => prev.filter((r) => r.id !== recipientId));
  };

  const handleSubmit = async () => {
    if (selectedRecipients.length === 0) return;

    setLoading(true);
    try {
      // Add all selected recipients as participants
      const participantInserts = selectedRecipients.map((recipient) => ({
        thread_id: threadId,
        user_id: recipient.id,
      }));

      const { error } = await supabase
        .from("thread_participants")
        .insert(participantInserts);

      if (error) throw error;

      toast({
        title: "Deltakere lagt til",
        description: `${selectedRecipients.length} deltaker${selectedRecipients.length > 1 ? "e" : ""} ble lagt til i samtalen`,
      });

      setSelectedRecipients([]);
      onParticipantsAdded();
      onOpenChange(false);
    } catch (error: any) {
      console.error("Error adding participants:", error);
      toast({
        title: "Feil",
        description: error.message || "Kunne ikke legge til deltakere",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setSelectedRecipients([]);
    onOpenChange(false);
  };

  // Filter out existing participants from selected
  const filteredSelectedRecipients = selectedRecipients.filter(
    (r) => !existingParticipantIds.includes(r.id)
  );

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Legg til deltakere</DialogTitle>
        </DialogHeader>

        <div className="py-4">
          <RecipientPicker
            selectedRecipients={filteredSelectedRecipients}
            onSelectRecipient={handleSelectRecipient}
            onRemoveRecipient={handleRemoveRecipient}
          />
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={handleClose}>
            Avbryt
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={loading || filteredSelectedRecipients.length === 0}
          >
            {loading ? "Legger til..." : "Legg til"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
