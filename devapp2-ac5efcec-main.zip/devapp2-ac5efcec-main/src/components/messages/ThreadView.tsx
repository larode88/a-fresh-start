import { useState, useEffect, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { MessageThread } from "@/pages/Messages";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Send, Paperclip, X, FileText, Image as ImageIcon, UserPlus } from "lucide-react";
import { format } from "date-fns";
import { nb } from "date-fns/locale";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { AddParticipantsDialog } from "./AddParticipantsDialog";

interface Participant {
  id: string;
  name: string;
  avatar_url: string | null;
}

interface Message {
  id: string;
  thread_id: string;
  sender_user_id: string;
  message_text: string;
  created_at: string;
  sender_name?: string;
  sender_avatar?: string | null;
  attachment_url?: string | null;
  attachment_name?: string | null;
}

interface ThreadViewProps {
  thread: MessageThread;
  currentUserId: string;
}

export const ThreadView = ({ thread, currentUserId }: ThreadViewProps) => {
  const { toast } = useToast();
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [attachment, setAttachment] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [participants, setParticipants] = useState<Participant[]>([]);
  const [allParticipantIds, setAllParticipantIds] = useState<string[]>([]);
  const [showAddParticipants, setShowAddParticipants] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const fetchParticipants = async () => {
    try {
      const { data: participantData } = await supabase
        .from("thread_participants")
        .select("user_id")
        .eq("thread_id", thread.id);

      if (participantData && participantData.length > 0) {
        const participantIds = participantData.map((p) => p.user_id);
        setAllParticipantIds(participantIds);

        const { data: usersData } = await supabase
          .from("users")
          .select("id, name, avatar_url")
          .in("id", participantIds);

        // Filter out current user for display
        const otherParticipants = (usersData || [])
          .filter((u) => u.id !== currentUserId)
          .map((u) => ({
            id: u.id,
            name: u.name,
            avatar_url: u.avatar_url,
          }));

        setParticipants(otherParticipants);
      }
    } catch (error) {
      console.error("Error fetching participants:", error);
    }
  };

  useEffect(() => {
    const fetchMessagesAndParticipants = async () => {
      setLoading(true);
      try {
        // Fetch participants
        await fetchParticipants();

        // Fetch messages
        const { data, error } = await supabase
          .from("messages")
          .select("*")
          .eq("thread_id", thread.id)
          .order("created_at", { ascending: true });

        if (error) throw error;

        // Fetch sender info (name + avatar)
        const userIds = [...new Set(data?.map((m) => m.sender_user_id) || [])];
        const { data: users } = await supabase
          .from("users")
          .select("id, name, avatar_url")
          .in("id", userIds);

        const userMap = new Map(users?.map((u) => [u.id, { name: u.name, avatar_url: u.avatar_url }]) || []);
        const messagesWithInfo = data?.map((m) => ({
          ...m,
          sender_name: userMap.get(m.sender_user_id)?.name || "Ukjent",
          sender_avatar: userMap.get(m.sender_user_id)?.avatar_url,
        }));

        setMessages(messagesWithInfo || []);
      } catch (error) {
        console.error("Error fetching messages:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchMessagesAndParticipants();
  }, [thread.id, currentUserId]);

  // Subscribe to realtime messages
  useEffect(() => {
    const channel = supabase
      .channel(`messages-${thread.id}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "messages",
          filter: `thread_id=eq.${thread.id}`,
        },
        async (payload) => {
          const newMsg = payload.new as Message;
          // Fetch sender info
          const { data: user } = await supabase
            .from("users")
            .select("name, avatar_url")
            .eq("id", newMsg.sender_user_id)
            .maybeSingle();

          setMessages((prev) => [
            ...prev,
            { ...newMsg, sender_name: user?.name || "Ukjent", sender_avatar: user?.avatar_url },
          ]);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [thread.id]);

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Limit file size to 10MB
      if (file.size > 10 * 1024 * 1024) {
        toast({
          title: "Filen er for stor",
          description: "Maks filstørrelse er 10MB",
          variant: "destructive",
        });
        return;
      }
      setAttachment(file);
    }
  };

  const removeAttachment = () => {
    setAttachment(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const uploadAttachment = async (file: File): Promise<{ url: string; name: string } | null> => {
    try {
      const fileExt = file.name.split(".").pop();
      const fileName = `${currentUserId}/${Date.now()}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from("message-attachments")
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from("message-attachments")
        .getPublicUrl(fileName);

      return { url: publicUrl, name: file.name };
    } catch (error) {
      console.error("Error uploading attachment:", error);
      return null;
    }
  };

  const handleSend = async () => {
    if ((!newMessage.trim() && !attachment) || sending) return;

    setSending(true);
    setUploading(!!attachment);

    try {
      let attachmentData: { url: string; name: string } | null = null;

      if (attachment) {
        attachmentData = await uploadAttachment(attachment);
        if (!attachmentData) {
          throw new Error("Kunne ikke laste opp vedlegg");
        }
      }

      // Get sender name for notification
      const { data: senderData } = await supabase
        .from("users")
        .select("name")
        .eq("id", currentUserId)
        .single();

      const { error } = await supabase.from("messages").insert({
        thread_id: thread.id,
        sender_user_id: currentUserId,
        message_text: newMessage.trim() || (attachment ? `Vedlegg: ${attachment.name}` : ""),
        attachment_url: attachmentData?.url || null,
        attachment_name: attachmentData?.name || null,
      });

      if (error) throw error;

      // Send email notification (fire and forget)
      supabase.functions.invoke("send-message-notification", {
        body: {
          threadId: thread.id,
          messageText: newMessage.trim() || `Vedlegg: ${attachment?.name}`,
          senderName: senderData?.name || "Ukjent",
          senderId: currentUserId,
        },
      }).catch(err => console.log("Notification error (non-critical):", err));

      setNewMessage("");
      setAttachment(null);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    } catch (error: any) {
      console.error("Error sending message:", error);
      toast({
        title: "Feil",
        description: error.message || "Kunne ikke sende melding",
        variant: "destructive",
      });
    } finally {
      setSending(false);
      setUploading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const isImageFile = (fileName: string) => {
    const ext = fileName.split(".").pop()?.toLowerCase();
    return ["jpg", "jpeg", "png", "gif", "webp"].includes(ext || "");
  };

  const renderAttachment = (message: Message) => {
    if (!message.attachment_url || !message.attachment_name) return null;

    const isImage = isImageFile(message.attachment_name);
    const isOwn = message.sender_user_id === currentUserId;

    if (isImage) {
      return (
        <a href={message.attachment_url} target="_blank" rel="noopener noreferrer" className="block mt-2">
          <img 
            src={message.attachment_url} 
            alt={message.attachment_name}
            className="max-w-[200px] max-h-[200px] rounded-md object-cover"
          />
        </a>
      );
    }

    return (
      <a 
        href={message.attachment_url} 
        target="_blank" 
        rel="noopener noreferrer"
        className={cn(
          "flex items-center gap-2 mt-2 p-2 rounded-md text-xs",
          isOwn ? "bg-primary-foreground/10" : "bg-background/50"
        )}
      >
        <FileText className="h-4 w-4" />
        <span className="truncate max-w-[150px]">{message.attachment_name}</span>
      </a>
    );
  };

  const handleParticipantsAdded = () => {
    fetchParticipants();
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="border-b border-border p-4">
        <div className="flex items-center justify-between">
          <h2 className="font-semibold text-foreground">{thread.subject}</h2>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowAddParticipants(true)}
            className="gap-2"
          >
            <UserPlus className="h-4 w-4" />
            <span className="hidden sm:inline">Legg til</span>
          </Button>
        </div>
        {participants.length > 0 && (
          <div className="flex items-center gap-2 mt-2">
            <div className="flex -space-x-2">
              {participants.slice(0, 5).map((p) => (
                <Avatar key={p.id} className="h-6 w-6 border-2 border-background">
                  <AvatarImage src={p.avatar_url || undefined} />
                  <AvatarFallback className="text-xs">{getInitials(p.name)}</AvatarFallback>
                </Avatar>
              ))}
              {participants.length > 5 && (
                <div className="h-6 w-6 rounded-full bg-muted flex items-center justify-center text-xs border-2 border-background">
                  +{participants.length - 5}
                </div>
              )}
            </div>
            <span className="text-sm text-muted-foreground truncate">
              {participants.slice(0, 3).map((p) => p.name).join(", ")}
              {participants.length > 3 && ` +${participants.length - 3} andre`}
            </span>
          </div>
        )}
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="h-16 bg-muted rounded-lg w-2/3"></div>
              </div>
            ))}
          </div>
        ) : messages.length === 0 ? (
          <p className="text-center text-muted-foreground text-sm">
            Ingen meldinger i denne samtalen ennå
          </p>
        ) : (
          messages.map((message) => {
            const isOwn = message.sender_user_id === currentUserId;
            return (
              <div
                key={message.id}
                className={cn("flex gap-2", isOwn ? "justify-end" : "justify-start")}
              >
                {!isOwn && (
                  <Avatar className="h-8 w-8 flex-shrink-0">
                    <AvatarImage src={message.sender_avatar || undefined} />
                    <AvatarFallback className="text-xs">
                      {getInitials(message.sender_name || "?")}
                    </AvatarFallback>
                  </Avatar>
                )}
                <div
                  className={cn(
                    "max-w-[75%] rounded-lg px-4 py-2",
                    isOwn
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted text-foreground"
                  )}
                >
                  {!isOwn && (
                    <p className="text-xs font-medium mb-1 opacity-70">
                      {message.sender_name}
                    </p>
                  )}
                  {message.message_text && (
                    <p className="text-sm whitespace-pre-wrap">{message.message_text}</p>
                  )}
                  {renderAttachment(message)}
                  <p
                    className={cn(
                      "text-xs mt-1",
                      isOwn ? "text-primary-foreground/70" : "text-muted-foreground"
                    )}
                  >
                    {format(new Date(message.created_at), "HH:mm", { locale: nb })}
                  </p>
                </div>
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Attachment preview */}
      {attachment && (
        <div className="border-t border-border px-4 py-2 flex items-center gap-2 bg-muted/50">
          {isImageFile(attachment.name) ? (
            <ImageIcon className="h-4 w-4 text-muted-foreground" />
          ) : (
            <FileText className="h-4 w-4 text-muted-foreground" />
          )}
          <span className="text-sm text-foreground truncate flex-1">{attachment.name}</span>
          <Button variant="ghost" size="sm" onClick={removeAttachment}>
            <X className="h-4 w-4" />
          </Button>
        </div>
      )}

      {/* Input */}
      <div className="border-t border-border p-4">
        <div className="flex gap-2">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileSelect}
            className="hidden"
            accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt"
          />
          <Button 
            variant="outline" 
            size="icon"
            onClick={() => fileInputRef.current?.click()}
            disabled={sending}
          >
            <Paperclip className="h-4 w-4" />
          </Button>
          <Textarea
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Skriv en melding..."
            className="min-h-[44px] max-h-32 resize-none"
            rows={1}
          />
          <Button 
            onClick={handleSend} 
            disabled={(!newMessage.trim() && !attachment) || sending}
          >
            {uploading ? (
              <span className="animate-spin">⏳</span>
            ) : (
              <Send className="h-4 w-4" />
            )}
          </Button>
        </div>
      </div>

      {/* Add Participants Dialog */}
      <AddParticipantsDialog
        open={showAddParticipants}
        onOpenChange={setShowAddParticipants}
        threadId={thread.id}
        existingParticipantIds={allParticipantIds}
        onParticipantsAdded={handleParticipantsAdded}
      />
    </div>
  );
};
