import { useState, useEffect } from "react";
import { MessageThread } from "@/pages/Messages";
import { supabase } from "@/integrations/supabase/client";
import { SwipeableThreadItem } from "./SwipeableThreadItem";

interface ThreadListProps {
  threads: MessageThread[];
  selectedThread: MessageThread | null;
  onSelectThread: (thread: MessageThread) => void;
  onArchiveThread?: (threadId: string) => void;
  onDeleteThread?: (threadId: string) => void;
  onRestoreThread?: (threadId: string) => void;
  loading: boolean;
  currentUserId: string;
  showArchived?: boolean;
}

interface Participant {
  id: string;
  name: string;
  avatar_url: string | null;
}

export interface ThreadWithUnread extends MessageThread {
  hasUnread: boolean;
  senderName?: string;
  participants: Participant[];
}

export const ThreadList = ({
  threads,
  selectedThread,
  onSelectThread,
  onArchiveThread,
  onDeleteThread,
  onRestoreThread,
  loading,
  currentUserId,
  showArchived = false,
}: ThreadListProps) => {
  const [threadsWithUnread, setThreadsWithUnread] = useState<ThreadWithUnread[]>([]);

  const checkUnread = async () => {
    if (!currentUserId || threads.length === 0) {
      setThreadsWithUnread(threads.map((t) => ({ ...t, hasUnread: false, participants: [] })));
      return;
    }

    const enrichedThreads: ThreadWithUnread[] = [];

    for (const thread of threads) {
      let hasUnread = false;
      let senderName: string | undefined;
      let participants: Participant[] = [];

      // Get all participants for this thread (excluding current user)
      const { data: participantData } = await supabase
        .from("thread_participants")
        .select("user_id")
        .eq("thread_id", thread.id)
        .neq("user_id", currentUserId);

      if (participantData && participantData.length > 0) {
        const participantIds = participantData.map((p: any) => p.user_id);
        const { data: usersData } = await supabase
          .from("users")
          .select("id, name, avatar_url")
          .in("id", participantIds);
        
        participants = (usersData || []).map((u) => ({
          id: u.id,
          name: u.name,
          avatar_url: u.avatar_url,
        }));
      }

      // Get participant's last_read_at
      const { data: participation } = await supabase
        .from("thread_participants")
        .select("last_read_at")
        .eq("thread_id", thread.id)
        .eq("user_id", currentUserId)
        .maybeSingle();

      if (participation) {
        const query = supabase
          .from("messages")
          .select("*", { count: "exact", head: true })
          .eq("thread_id", thread.id)
          .neq("sender_user_id", currentUserId);

        if (participation.last_read_at) {
          query.gt("created_at", participation.last_read_at);
        }

        const { count } = await query;
        hasUnread = (count || 0) > 0;
      }

      // Get sender name for last message
      if (thread.last_message) {
        const { data: lastMessage } = await supabase
          .from("messages")
          .select("sender_user_id")
          .eq("thread_id", thread.id)
          .order("created_at", { ascending: false })
          .limit(1)
          .maybeSingle();

        if (lastMessage && lastMessage.sender_user_id !== currentUserId) {
          const { data: sender } = await supabase
            .from("users")
            .select("name")
            .eq("id", lastMessage.sender_user_id)
            .maybeSingle();
          senderName = sender?.name;
        }
      }

      enrichedThreads.push({ ...thread, hasUnread, senderName, participants });
    }

    enrichedThreads.sort((a, b) => {
      if (a.hasUnread && !b.hasUnread) return -1;
      if (!a.hasUnread && b.hasUnread) return 1;
      const dateA = new Date(a.last_message_at || a.created_at).getTime();
      const dateB = new Date(b.last_message_at || b.created_at).getTime();
      return dateB - dateA;
    });

    setThreadsWithUnread(enrichedThreads);
  };

  useEffect(() => {
    checkUnread();
  }, [threads, currentUserId]);

  // Subscribe to realtime message updates to refresh unread status
  useEffect(() => {
    if (!currentUserId || threads.length === 0) return;

    const threadIds = threads.map(t => t.id);
    
    const channel = supabase
      .channel('thread-list-messages')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'messages',
        },
        (payload) => {
          const newMsg = payload.new as { thread_id: string };
          // Only refresh if the message is in one of our threads
          if (threadIds.includes(newMsg.thread_id)) {
            checkUnread();
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [threads, currentUserId]);

  if (loading) {
    return (
      <div className="p-4 space-y-3">
        {[1, 2, 3].map((i) => (
          <div key={i} className="animate-pulse">
            <div className="h-4 bg-muted rounded w-3/4 mb-2"></div>
            <div className="h-3 bg-muted rounded w-1/2"></div>
          </div>
        ))}
      </div>
    );
  }

  if (threads.length === 0) {
    return (
      <div className="p-4 text-center text-muted-foreground">
        <p className="text-sm">
          {showArchived ? "Ingen arkiverte meldinger" : "Ingen meldinger ennå"}
        </p>
      </div>
    );
  }

  return (
    <div className="divide-y divide-border overflow-y-auto h-full">
      {threadsWithUnread.map((thread) => (
        <SwipeableThreadItem
          key={thread.id}
          thread={thread}
          isSelected={selectedThread?.id === thread.id}
          showArchived={showArchived}
          onSelect={() => onSelectThread(thread)}
          onArchive={() => onArchiveThread?.(thread.id)}
          onDelete={() => onDeleteThread?.(thread.id)}
          onRestore={() => onRestoreThread?.(thread.id)}
        />
      ))}
    </div>
  );
};
