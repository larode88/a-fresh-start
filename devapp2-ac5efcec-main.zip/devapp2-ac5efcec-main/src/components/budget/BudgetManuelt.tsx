import { useState, useEffect } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import {
  getManualBudgets,
  bulkUpsertManualBudgets,
  deleteManualBudgetsForEmployee,
} from "@/integrations/supabase/budgetsService";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { Save, Copy, Trash2, UserPlus } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface BudgetManueltProps {
  salonId: string;
  versionId: string;
  year: number;
}

interface AnsattOption {
  id: string;
  fornavn: string;
  etternavn: string | null;
  frisorfunksjon: string | null;
}

interface MonthData {
  behandling: number;
  vare: number;
}

interface EmployeeBudgetRow {
  ansattId: string;
  ansattNavn: string;
  months: MonthData[]; // 12 months
  isModified: boolean;
}

const MONTHS = [
  "Jan", "Feb", "Mar", "Apr", "Mai", "Jun",
  "Jul", "Aug", "Sep", "Okt", "Nov", "Des"
];

export function BudgetManuelt({ salonId, versionId, year }: BudgetManueltProps) {
  const queryClient = useQueryClient();
  const [budgetRows, setBudgetRows] = useState<EmployeeBudgetRow[]>([]);
  const [selectedNewEmployee, setSelectedNewEmployee] = useState<string>("");
  const [isSaving, setIsSaving] = useState(false);

  // Fetch employees without frisørfunksjon (only lederstilling)
  const { data: availableEmployees, isLoading: loadingEmployees } = useQuery({
    queryKey: ["ansatte-uten-frisor", salonId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("ansatte")
        .select("id, fornavn, etternavn, frisorfunksjon")
        .eq("salong_id", salonId)
        .eq("status", "Aktiv");

      if (error) throw error;
      
      // Filter to employees without frisørfunksjon
      return (data || []).filter(e => !e.frisorfunksjon) as AnsattOption[];
    },
    enabled: !!salonId,
  });

  // Fetch existing manual budgets
  const { data: manualBudgets, isLoading: loadingBudgets } = useQuery({
    queryKey: ["manual-budgets", salonId, versionId],
    queryFn: () => getManualBudgets(salonId, versionId),
    enabled: !!salonId && !!versionId,
  });

  // Initialize budget rows from fetched data
  useEffect(() => {
    if (!manualBudgets) return;

    // Group by ansatt_id
    const grouped = new Map<string, { ansattNavn: string; months: MonthData[] }>();
    
    manualBudgets.forEach((mb) => {
      if (!grouped.has(mb.ansatt_id)) {
        const navn = mb.ansatte 
          ? `${mb.ansatte.fornavn} ${mb.ansatte.etternavn || ""}`.trim()
          : "Ukjent";
        grouped.set(mb.ansatt_id, {
          ansattNavn: navn,
          months: Array(12).fill(null).map(() => ({ behandling: 0, vare: 0 })),
        });
      }
      const entry = grouped.get(mb.ansatt_id)!;
      entry.months[mb.maned - 1] = {
        behandling: mb.behandling_budsjett || 0,
        vare: mb.vare_budsjett || 0,
      };
    });

    const rows: EmployeeBudgetRow[] = Array.from(grouped.entries()).map(
      ([ansattId, { ansattNavn, months }]) => ({
        ansattId,
        ansattNavn,
        months,
        isModified: false,
      })
    );

    setBudgetRows(rows);
  }, [manualBudgets]);

  // Get employees not yet added
  const employeesNotAdded = availableEmployees?.filter(
    (emp) => !budgetRows.some((row) => row.ansattId === emp.id)
  ) || [];

  const handleAddEmployee = () => {
    if (!selectedNewEmployee) return;
    
    const employee = availableEmployees?.find(e => e.id === selectedNewEmployee);
    if (!employee) return;

    const newRow: EmployeeBudgetRow = {
      ansattId: employee.id,
      ansattNavn: `${employee.fornavn} ${employee.etternavn || ""}`.trim(),
      months: Array(12).fill(null).map(() => ({ behandling: 0, vare: 0 })),
      isModified: true,
    };

    setBudgetRows([...budgetRows, newRow]);
    setSelectedNewEmployee("");
  };

  const handleMonthChange = (
    ansattId: string, 
    monthIndex: number, 
    field: 'behandling' | 'vare',
    value: string
  ) => {
    const numValue = parseFloat(value) || 0;
    setBudgetRows(prev =>
      prev.map(row =>
        row.ansattId === ansattId
          ? {
              ...row,
              months: row.months.map((m, i) => 
                i === monthIndex ? { ...m, [field]: numValue } : m
              ),
              isModified: true,
            }
          : row
      )
    );
  };

  const handleCopyToAllMonths = (ansattId: string) => {
    setBudgetRows(prev =>
      prev.map(row => {
        if (row.ansattId !== ansattId) return row;
        const firstMonth = row.months[0];
        return {
          ...row,
          months: Array(12).fill(null).map(() => ({ ...firstMonth })),
          isModified: true,
        };
      })
    );
    toast.success("Kopiert til alle måneder");
  };

  const handleRemoveEmployee = async (ansattId: string) => {
    try {
      await deleteManualBudgetsForEmployee(versionId, ansattId);
      setBudgetRows(prev => prev.filter(row => row.ansattId !== ansattId));
      queryClient.invalidateQueries({ queryKey: ["manual-budgets", salonId, versionId] });
      toast.success("Ansatt fjernet fra manuelt budsjett");
    } catch (error) {
      console.error("Failed to remove employee:", error);
      toast.error("Kunne ikke fjerne ansatt");
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    try {
      const modifiedRows = budgetRows.filter(row => row.isModified);
      
      const entries = modifiedRows.flatMap(row =>
        row.months.map((monthData, index) => ({
          versjon_id: versionId,
          salon_id: salonId,
          ansatt_id: row.ansattId,
          maned: index + 1,
          behandling_budsjett: monthData.behandling,
          vare_budsjett: monthData.vare,
        }))
      );

      await bulkUpsertManualBudgets(entries);
      
      // Reset modified flags
      setBudgetRows(prev =>
        prev.map(row => ({ ...row, isModified: false }))
      );
      
      queryClient.invalidateQueries({ queryKey: ["manual-budgets", salonId, versionId] });
      toast.success("Manuelt budsjett lagret");
    } catch (error) {
      console.error("Failed to save manual budgets:", error);
      toast.error("Kunne ikke lagre manuelt budsjett");
    } finally {
      setIsSaving(false);
    }
  };

  const hasModifications = budgetRows.some(row => row.isModified);
  const isLoading = loadingEmployees || loadingBudgets;

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-48" />
          <Skeleton className="h-4 w-96" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-64 w-full" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Manuelt budsjett</CardTitle>
        <CardDescription>
          Legg til behandlings- og varesalgsbudsjett for ansatte som ikke står i turnus (f.eks. ledere)
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Add employee section */}
        {employeesNotAdded.length > 0 && (
          <div className="flex items-end gap-4">
            <div className="flex-1 max-w-xs">
              <Label htmlFor="add-employee">Legg til ansatt</Label>
              <Select value={selectedNewEmployee} onValueChange={setSelectedNewEmployee}>
                <SelectTrigger id="add-employee">
                  <SelectValue placeholder="Velg ansatt..." />
                </SelectTrigger>
                <SelectContent>
                  {employeesNotAdded.map((emp) => (
                    <SelectItem key={emp.id} value={emp.id}>
                      {emp.fornavn} {emp.etternavn || ""}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Button
              variant="outline"
              onClick={handleAddEmployee}
              disabled={!selectedNewEmployee}
            >
              <UserPlus className="h-4 w-4 mr-2" />
              Legg til
            </Button>
          </div>
        )}

        {budgetRows.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <p>Ingen ansatte med manuelt budsjett ennå.</p>
            {employeesNotAdded.length === 0 && (
              <p className="text-sm mt-2">
                Det finnes ingen ansatte uten frisørfunksjon i denne salongen.
              </p>
            )}
          </div>
        ) : (
          <div className="space-y-6">
            {budgetRows.map((row) => {
              const behandlingTotal = row.months.reduce((a, b) => a + b.behandling, 0);
              const vareTotal = row.months.reduce((a, b) => a + b.vare, 0);
              const grandTotal = behandlingTotal + vareTotal;

              return (
                <Card key={row.ansattId} className="border-muted">
                  <CardHeader className="py-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <CardTitle className="text-base">
                          {row.ansattNavn}
                          {row.isModified && (
                            <span className="ml-2 text-xs text-amber-500">*</span>
                          )}
                        </CardTitle>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-muted-foreground">
                          Totalt: {grandTotal.toLocaleString("nb-NO")} kr
                        </span>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleCopyToAllMonths(row.ansattId)}
                          title="Kopier januar til alle måneder"
                        >
                          <Copy className="h-4 w-4" />
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="text-destructive hover:text-destructive"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Fjern ansatt?</AlertDialogTitle>
                              <AlertDialogDescription>
                                Er du sikker på at du vil fjerne {row.ansattNavn} fra
                                manuelt budsjett? Dette sletter alle budsjetterte
                                verdier.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Avbryt</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => handleRemoveEmployee(row.ansattId)}
                                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                              >
                                Fjern
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-[100px]">Type</TableHead>
                          {MONTHS.map((month) => (
                            <TableHead key={month} className="text-center min-w-[70px]">
                              {month}
                            </TableHead>
                          ))}
                          <TableHead className="text-right">Sum</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        <TableRow>
                          <TableCell className="font-medium text-sm">Behandling</TableCell>
                          {row.months.map((monthData, index) => (
                            <TableCell key={index} className="p-1">
                              <Input
                                type="number"
                                value={monthData.behandling || ""}
                                onChange={(e) =>
                                  handleMonthChange(row.ansattId, index, 'behandling', e.target.value)
                                }
                                className="h-8 text-center w-[70px] text-sm"
                                placeholder="0"
                              />
                            </TableCell>
                          ))}
                          <TableCell className="text-right font-medium text-sm">
                            {behandlingTotal.toLocaleString("nb-NO")}
                          </TableCell>
                        </TableRow>
                        <TableRow>
                          <TableCell className="font-medium text-sm">Vare</TableCell>
                          {row.months.map((monthData, index) => (
                            <TableCell key={index} className="p-1">
                              <Input
                                type="number"
                                value={monthData.vare || ""}
                                onChange={(e) =>
                                  handleMonthChange(row.ansattId, index, 'vare', e.target.value)
                                }
                                className="h-8 text-center w-[70px] text-sm"
                                placeholder="0"
                              />
                            </TableCell>
                          ))}
                          <TableCell className="text-right font-medium text-sm">
                            {vareTotal.toLocaleString("nb-NO")}
                          </TableCell>
                        </TableRow>
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        {budgetRows.length > 0 && (
          <div className="flex justify-end">
            <Button
              onClick={handleSave}
              disabled={!hasModifications || isSaving}
            >
              <Save className="h-4 w-4 mr-2" />
              {isSaving ? "Lagrer..." : "Lagre endringer"}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}