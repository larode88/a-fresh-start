import { useState, useEffect, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { getActiveAnsatte } from "@/integrations/supabase/employeesService";
import { getMonthlyKPIs, bulkUpsertMonthlyKPIs, getManualBudgets, MonthlyKPIWithEmployee, getPlannedHoursFromShifts, getVacationHoursFromFerie } from "@/integrations/supabase/budgetsService";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import {
  Table,
  TableBody,
  TableCell,
  TableFooter,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calculator, Loader2, Save, Copy, Info, Clock, CalendarDays, FileText, CheckCircle, Palmtree } from "lucide-react";

interface BudgetMonthlyKPIsProps {
  salonId: string;
  versionId: string;
  year: number;
}

interface EmployeeMonthlyData {
  ansatt_id: string;
  ansatt_name: string;
  base_effektivitet: number | null;
  base_omsetning: number | null;
  base_varesalg: number | null;
  hasShiftData: boolean; // Indicates if data comes from turnus_skift
  months: {
    [month: number]: {
      planlagte_timer: number;
      ferie_timer: number;
      fromShifts: boolean; // True if hours come from turnus_skift
      effektivitet: number | null;
      omsetning: number | null;
      varesalg: number | null;
    };
  };
}

const MONTHS = [
  { num: 1, name: "Jan" },
  { num: 2, name: "Feb" },
  { num: 3, name: "Mar" },
  { num: 4, name: "Apr" },
  { num: 5, name: "Mai" },
  { num: 6, name: "Jun" },
  { num: 7, name: "Jul" },
  { num: 8, name: "Aug" },
  { num: 9, name: "Sep" },
  { num: 10, name: "Okt" },
  { num: 11, name: "Nov" },
  { num: 12, name: "Des" },
];

export function BudgetMonthlyKPIs({ salonId, versionId, year }: BudgetMonthlyKPIsProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [employees, setEmployees] = useState<EmployeeMonthlyData[]>([]);
  const [selectedEmployee, setSelectedEmployee] = useState<string | null>(null);
  const [hasChanges, setHasChanges] = useState(false);
  const [manualBudgetEmployees, setManualBudgetEmployees] = useState<Set<string>>(new Set());

  // Fetch data
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        // Fetch employees, shift hours, vacation hours, existing KPIs, manual budgets in parallel
        const [ansatte, shiftHours, vacationHours, existingKPIs, manualBudgets] = await Promise.all([
          getActiveAnsatte(salonId),
          getPlannedHoursFromShifts(salonId, year),
          getVacationHoursFromFerie(salonId, year),
          getMonthlyKPIs(salonId, versionId),
          getManualBudgets(salonId, versionId),
        ]);

        // Build set of employees with manual budgets
        const manualEmployeeIds = new Set(manualBudgets.map(mb => mb.ansatt_id));
        setManualBudgetEmployees(manualEmployeeIds);

        // Filter out employees with manual budgets
        const filteredAnsatte = ansatte.filter(a => !manualEmployeeIds.has(a.id));

        // Build shift hours lookup: { ansatt_id-month: hours }
        const shiftHoursMap = new Map<string, number>();
        shiftHours.forEach(sh => {
          shiftHoursMap.set(`${sh.ansatt_id}-${sh.maned}`, sh.timer);
        });

        // Build vacation hours lookup: { ansatt_id-month: hours }
        const vacationHoursMap = new Map<string, number>();
        vacationHours.forEach(vh => {
          vacationHoursMap.set(`${vh.ansatt_id}-${vh.maned}`, vh.timer);
        });
        
        // Track which employees have any shift data
        const employeesWithShifts = new Set(shiftHours.map(sh => sh.ansatt_id));
        
        // Build existing KPIs map
        const kpiMap = new Map<string, MonthlyKPIWithEmployee>();
        existingKPIs.forEach(kpi => {
          kpiMap.set(`${kpi.ansatt_id}-${kpi.maned}`, kpi);
        });

        // Build employee data using turnus_skift as primary source
        const employeeData: EmployeeMonthlyData[] = filteredAnsatte.map(ansatt => {
          const months: EmployeeMonthlyData['months'] = {};
          const hasShiftData = employeesWithShifts.has(ansatt.id);
          
          for (let month = 1; month <= 12; month++) {
            const shiftKey = `${ansatt.id}-${month}`;
            const shiftTimer = shiftHoursMap.get(shiftKey);
            const ferieTimer = vacationHoursMap.get(shiftKey) ?? 0;
            const existingKPI = kpiMap.get(`${ansatt.id}-${month}`);
            
            // Use shift hours if available, otherwise 0
            const planlagteTimer = shiftTimer ?? 0;
            const fromShifts = shiftTimer !== undefined;
            
            months[month] = {
              planlagte_timer: planlagteTimer,
              ferie_timer: ferieTimer,
              fromShifts,
              effektivitet: existingKPI?.effektivitet_prosent ?? null,
              omsetning: existingKPI?.omsetning_per_time ?? null,
              varesalg: existingKPI?.varesalg_prosent ?? null,
            };
          }
          
          return {
            ansatt_id: ansatt.id,
            ansatt_name: `${ansatt.fornavn}${ansatt.etternavn ? ' ' + ansatt.etternavn : ''}`,
            base_effektivitet: ansatt.effektivitet_prosent,
            base_omsetning: ansatt.omsetning_per_time,
            base_varesalg: ansatt.varesalg_prosent,
            hasShiftData,
            months,
          };
        });

        setEmployees(employeeData);
        if (employeeData.length > 0) {
          setSelectedEmployee(employeeData[0].ansatt_id);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        toast({
          title: "Feil",
          description: "Kunne ikke hente data",
          variant: "destructive"
        });
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [salonId, versionId, year]);

  const selectedEmployeeData = useMemo(() => 
    employees.find(e => e.ansatt_id === selectedEmployee),
    [employees, selectedEmployee]
  );

  const updateKPI = (month: number, field: 'effektivitet' | 'omsetning' | 'varesalg', value: number | null) => {
    setEmployees(prev => prev.map(emp => {
      if (emp.ansatt_id !== selectedEmployee) return emp;
      return {
        ...emp,
        months: {
          ...emp.months,
          [month]: {
            ...emp.months[month],
            [field]: value
          }
        }
      };
    }));
    setHasChanges(true);
  };

  const copyFromBase = () => {
    if (!selectedEmployeeData) return;
    
    setEmployees(prev => prev.map(emp => {
      if (emp.ansatt_id !== selectedEmployee) return emp;
      const newMonths = { ...emp.months };
      for (let m = 1; m <= 12; m++) {
        newMonths[m] = {
          ...newMonths[m],
          effektivitet: emp.base_effektivitet,
          omsetning: emp.base_omsetning,
          varesalg: emp.base_varesalg,
        };
      }
      return { ...emp, months: newMonths };
    }));
    setHasChanges(true);
  };

  const copyFromFirstMonth = () => {
    if (!selectedEmployeeData) return;
    
    const firstMonth = selectedEmployeeData.months[1];
    setEmployees(prev => prev.map(emp => {
      if (emp.ansatt_id !== selectedEmployee) return emp;
      const newMonths = { ...emp.months };
      for (let m = 2; m <= 12; m++) {
        newMonths[m] = {
          ...newMonths[m],
          effektivitet: firstMonth.effektivitet,
          omsetning: firstMonth.omsetning,
          varesalg: firstMonth.varesalg,
        };
      }
      return { ...emp, months: newMonths };
    }));
    setHasChanges(true);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const entries = employees.flatMap(emp => 
        Object.entries(emp.months)
          .filter(([_, data]) => data.effektivitet !== null || data.omsetning !== null || data.varesalg !== null)
          .map(([month, data]) => ({
            salon_id: salonId,
            ansatt_id: emp.ansatt_id,
            versjon_id: versionId,
            aar: year,
            maned: parseInt(month),
            effektivitet_prosent: data.effektivitet,
            omsetning_per_time: data.omsetning,
            varesalg_prosent: data.varesalg,
          }))
      );

      await bulkUpsertMonthlyKPIs(entries);
      
      toast({
        title: "Lagret",
        description: `${entries.length} månedlige KPI-verdier lagret`
      });
      setHasChanges(false);
    } catch (error) {
      console.error("Error saving KPIs:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke lagre KPI-verdier",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-96 w-full" />
      </div>
    );
  }

  if (employees.length === 0 && manualBudgetEmployees.size === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center text-muted-foreground">
          Ingen ansatte funnet i salongen.
        </CardContent>
      </Card>
    );
  }

  if (employees.length === 0 && manualBudgetEmployees.size > 0) {
    return (
      <Card>
        <CardContent className="py-12">
          <Alert>
            <FileText className="h-4 w-4" />
            <AlertDescription>
              Alle ansatte i salongen har manuelt budsjett. KPI-verdier er ikke nødvendig for disse.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header with employee selector */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Calculator className="h-5 w-5" />
                Månedlige KPI-verdier
              </CardTitle>
              <CardDescription>
                Sett KPI-verdier per måned for nøyaktig budsjettberegning. Timer hentes fra vaktplan (turnus_skift).
              </CardDescription>
              {selectedEmployeeData && selectedEmployeeData.hasShiftData && (
                <Badge variant="secondary" className="mt-2">
                  <CheckCircle className="h-3.5 w-3.5 mr-1 text-green-600" />
                  Timer fra vaktplan
                </Badge>
              )}
              {selectedEmployeeData && !selectedEmployeeData.hasShiftData && (
                <Badge variant="outline" className="mt-2">
                  Ingen vakter generert for {year}
                </Badge>
              )}
            </div>
            <div className="flex items-center gap-2">
              <Select value={selectedEmployee || ""} onValueChange={setSelectedEmployee}>
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder="Velg ansatt" />
                </SelectTrigger>
                <SelectContent>
                  {employees.map(emp => (
                    <SelectItem key={emp.ansatt_id} value={emp.ansatt_id}>
                      {emp.ansatt_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        {manualBudgetEmployees.size > 0 && (
          <CardContent className="pt-0">
            <Alert>
              <FileText className="h-4 w-4" />
              <AlertDescription>
                {manualBudgetEmployees.size} ansatt{manualBudgetEmployees.size > 1 ? 'e' : ''} har manuelt budsjett og vises ikke her.
              </AlertDescription>
            </Alert>
          </CardContent>
        )}
      </Card>

      {/* Employee base KPIs info */}
      {selectedEmployeeData && (
        <Card>
          <CardContent className="py-4">
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div className="flex items-center gap-6">
                <div className="text-sm">
                  <span className="text-muted-foreground">Base Eff:</span>{" "}
                  <span className="font-medium">{selectedEmployeeData.base_effektivitet ?? "-"}%</span>
                </div>
                <div className="text-sm">
                  <span className="text-muted-foreground">Base Oms/t:</span>{" "}
                  <span className="font-medium">{selectedEmployeeData.base_omsetning ?? "-"} kr</span>
                </div>
                <div className="text-sm">
                  <span className="text-muted-foreground">Base Vare:</span>{" "}
                  <span className="font-medium">{selectedEmployeeData.base_varesalg ?? "-"}%</span>
                </div>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={copyFromBase}>
                  <Copy className="h-4 w-4 mr-1" />
                  Kopier base til alle
                </Button>
                <Button variant="outline" size="sm" onClick={copyFromFirstMonth}>
                  <Copy className="h-4 w-4 mr-1" />
                  Kopier jan til alle
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Monthly KPI table */}
      {selectedEmployeeData && (
        <Card>
          <CardContent className="p-0">
            <ScrollArea className="w-full">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[140px] sticky left-0 bg-background z-10">Måned</TableHead>
                    <TableHead className="text-center min-w-[100px]">
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger className="flex items-center gap-1 mx-auto">
                            <Clock className="h-3.5 w-3.5" />
                            Timer
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>Planlagte timer fra vaktplan (turnus_skift)</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </TableHead>
                    <TableHead className="text-center min-w-[100px]">
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger className="flex items-center gap-1 mx-auto">
                            <Palmtree className="h-3.5 w-3.5" />
                            Ferie
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>Godkjente/planlagte ferietimer</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </TableHead>
                    <TableHead className="text-center min-w-[90px]">Eff %</TableHead>
                    <TableHead className="text-center min-w-[100px]">Oms/time</TableHead>
                    <TableHead className="text-center min-w-[90px]">Vare %</TableHead>
                    <TableHead className="text-center min-w-[120px]">
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger className="flex items-center gap-1 mx-auto">
                            <Info className="h-3.5 w-3.5" />
                            Estimat
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>Beregnet: Timer × Eff × Oms/t</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {MONTHS.map(month => {
                    const data = selectedEmployeeData.months[month.num];
                    const eff = data.effektivitet ?? selectedEmployeeData.base_effektivitet ?? 70;
                    const oms = data.omsetning ?? selectedEmployeeData.base_omsetning ?? 1200;
                    const kundetimer = data.planlagte_timer * (eff / 100);
                    const estimat = kundetimer * oms;
                    
                    return (
                      <TableRow key={month.num}>
                        <TableCell className="font-medium sticky left-0 bg-background">
                          <div className="flex items-center gap-2">
                            {month.name}
                            {data.fromShifts && (
                              <TooltipProvider>
                                <Tooltip>
                                  <TooltipTrigger>
                                    <CheckCircle className="h-3.5 w-3.5 text-green-600" />
                                  </TooltipTrigger>
                                  <TooltipContent>
                                    <p>Fra vaktplan</p>
                                  </TooltipContent>
                                </Tooltip>
                              </TooltipProvider>
                            )}
                          </div>
                        </TableCell>
                        <TableCell className="text-center">
                          <span className="text-sm font-medium">
                            {data.planlagte_timer}t
                          </span>
                        </TableCell>
                        <TableCell className="text-center">
                          {data.ferie_timer > 0 ? (
                            <span className="text-sm font-medium text-sky-600 dark:text-sky-400">
                              {data.ferie_timer}t
                            </span>
                          ) : (
                            <span className="text-muted-foreground">-</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <Input
                            type="number"
                            min="0"
                            max="100"
                            value={data.effektivitet ?? ""}
                            onChange={(e) => updateKPI(month.num, 'effektivitet', e.target.value ? parseFloat(e.target.value) : null)}
                            placeholder={String(selectedEmployeeData.base_effektivitet ?? 70)}
                            className="w-20 mx-auto text-center [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none [-moz-appearance:textfield]"
                          />
                        </TableCell>
                        <TableCell>
                          <Input
                            type="number"
                            min="0"
                            value={data.omsetning ?? ""}
                            onChange={(e) => updateKPI(month.num, 'omsetning', e.target.value ? parseFloat(e.target.value) : null)}
                            placeholder={String(selectedEmployeeData.base_omsetning ?? 1200)}
                            className="w-24 mx-auto text-center [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none [-moz-appearance:textfield]"
                          />
                        </TableCell>
                        <TableCell>
                          <Input
                            type="number"
                            min="0"
                            max="100"
                            value={data.varesalg ?? ""}
                            onChange={(e) => updateKPI(month.num, 'varesalg', e.target.value ? parseFloat(e.target.value) : null)}
                            placeholder={String(selectedEmployeeData.base_varesalg ?? 15)}
                            className="w-20 mx-auto text-center [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none [-moz-appearance:textfield]"
                          />
                        </TableCell>
                        <TableCell className="text-center">
                          <span className="text-sm font-medium text-muted-foreground">
                            {new Intl.NumberFormat("nb-NO", { style: "currency", currency: "NOK", maximumFractionDigits: 0 }).format(estimat)}
                          </span>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
                {selectedEmployeeData && (() => {
                  let sumTimer = 0, sumFerie = 0, sumEstimat = 0;
                  const effValues: number[] = [];
                  const omsValues: number[] = [];
                  const vareValues: number[] = [];

                  MONTHS.forEach(month => {
                    const data = selectedEmployeeData.months[month.num];
                    sumTimer += data.planlagte_timer;
                    sumFerie += data.ferie_timer;

                    const eff = data.effektivitet ?? selectedEmployeeData.base_effektivitet ?? 70;
                    const oms = data.omsetning ?? selectedEmployeeData.base_omsetning ?? 1200;
                    const vare = data.varesalg ?? selectedEmployeeData.base_varesalg ?? 15;

                    effValues.push(eff);
                    omsValues.push(oms);
                    vareValues.push(vare);

                    const kundetimer = data.planlagte_timer * (eff / 100);
                    sumEstimat += kundetimer * oms;
                  });

                  const avgEff = effValues.length ? Math.round(effValues.reduce((a, b) => a + b, 0) / effValues.length) : 0;
                  const avgOms = omsValues.length ? Math.round(omsValues.reduce((a, b) => a + b, 0) / omsValues.length) : 0;
                  const avgVare = vareValues.length ? Math.round(vareValues.reduce((a, b) => a + b, 0) / vareValues.length) : 0;

                  return (
                    <TableFooter>
                      <TableRow className="bg-muted/50 font-semibold">
                        <TableCell className="sticky left-0 bg-muted/50">Totalt</TableCell>
                        <TableCell className="text-center">{sumTimer}t</TableCell>
                        <TableCell className="text-center text-sky-600">{sumFerie}t</TableCell>
                        <TableCell className="text-center">⌀ {avgEff}%</TableCell>
                        <TableCell className="text-center">⌀ {avgOms} kr</TableCell>
                        <TableCell className="text-center">⌀ {avgVare}%</TableCell>
                        <TableCell className="text-center font-bold">
                          {new Intl.NumberFormat("nb-NO", { style: "currency", currency: "NOK", maximumFractionDigits: 0 }).format(sumEstimat)}
                        </TableCell>
                      </TableRow>
                    </TableFooter>
                  );
                })()}
              </Table>
              <ScrollBar orientation="horizontal" />
            </ScrollArea>
          </CardContent>
        </Card>
      )}

      {/* Save button */}
      <div className="flex justify-center">
        <Button 
          size="lg" 
          onClick={handleSave} 
          disabled={saving || !hasChanges}
          className="min-w-[200px]"
        >
          {saving ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Lagrer...
            </>
          ) : (
            <>
              <Save className="h-4 w-4 mr-2" />
              Lagre KPI-verdier
            </>
          )}
        </Button>
      </div>
    </div>
  );
}