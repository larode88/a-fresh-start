import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { getActiveAnsatte } from "@/integrations/supabase/employeesService";
import { getBudgetsBySalon } from "@/integrations/supabase/budgetsService";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { CheckCircle, Save, Loader2, Target } from "lucide-react";
import { format } from "date-fns";
import { nb } from "date-fns/locale";

interface BudgetFastsattProps {
  salonId: string;
  versionId: string;
  year: number;
}

interface StylistFastsatt {
  id?: string;
  user_id: string;
  user_name: string;
  fastsatt_behandling: number;
  fastsatt_vare: number;
  fastsatt_arsbudsjett: number;
  fastsatt_timer: number | null;
  godkjent_av: string | null;
  godkjent_dato: string | null;
  generated_total?: number;
  isModified?: boolean;
}

export function BudgetFastsatt({ salonId, versionId, year }: BudgetFastsattProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [approving, setApproving] = useState<string | null>(null);
  const [fastsattData, setFastsattData] = useState<StylistFastsatt[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        // Use ansatte table as primary source
        const ansatte = await getActiveAnsatte(salonId);

        // Fetch existing fastsatt data
        const { data: fastsatt, error: fastsattError } = await supabase
          .from("budsjett_fastsatt")
          .select("*")
          .eq("versjon_id", versionId);

        if (fastsattError) throw fastsattError;

        // Use service to fetch budget data
        const budgetData = await getBudgetsBySalon(salonId, versionId);

        // Aggregate generated totals by user (using ansatt_id now)
        const generatedMap = new Map<string, { total: number; behandling: number; vare: number }>();
        budgetData?.forEach(entry => {
          if (!generatedMap.has(entry.user_id)) {
            generatedMap.set(entry.user_id, { total: 0, behandling: 0, vare: 0 });
          }
          const current = generatedMap.get(entry.user_id)!;
          current.total += entry.totalt_budsjett || 0;
          current.behandling += entry.behandling_budsjett || 0;
          current.vare += entry.vare_budsjett || 0;
        });

        const fastsattMap = new Map(fastsatt?.map(f => [f.user_id, f]) || []);

        // Build combined data
        const combined: StylistFastsatt[] = ansatte.map(ansatt => {
          const name = ansatt.etternavn 
            ? `${ansatt.fornavn} ${ansatt.etternavn}` 
            : ansatt.fornavn;
          const existing = fastsattMap.get(ansatt.id);
          const generated = generatedMap.get(ansatt.id);

          if (existing) {
            return {
              id: existing.id,
              user_id: ansatt.id,
              user_name: name,
              fastsatt_behandling: existing.fastsatt_behandling,
              fastsatt_vare: existing.fastsatt_vare,
              fastsatt_arsbudsjett: existing.fastsatt_arsbudsjett,
              fastsatt_timer: existing.fastsatt_timer,
              godkjent_av: existing.godkjent_av,
              godkjent_dato: existing.godkjent_dato,
              generated_total: generated?.total || 0,
              isModified: false
            };
          }

          return {
            user_id: ansatt.id,
            user_name: name,
            fastsatt_behandling: generated?.behandling || 0,
            fastsatt_vare: generated?.vare || 0,
            fastsatt_arsbudsjett: generated?.total || 0,
            fastsatt_timer: null,
            godkjent_av: null,
            godkjent_dato: null,
            generated_total: generated?.total || 0,
            isModified: false
          };
        });

        setFastsattData(combined);
      } catch (error) {
        console.error("Error fetching fastsatt data:", error);
        toast({
          title: "Feil",
          description: "Kunne ikke hente fastsatte budsjetter",
          variant: "destructive"
        });
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [salonId, versionId, year]);

  const updateValue = (userId: string, field: keyof StylistFastsatt, value: number) => {
    setFastsattData(prev => prev.map(item => {
      if (item.user_id !== userId) return item;
      
      const updated = { ...item, [field]: value, isModified: true };
      
      // Auto-calculate total when behandling or vare changes
      if (field === 'fastsatt_behandling' || field === 'fastsatt_vare') {
        updated.fastsatt_arsbudsjett = 
          (field === 'fastsatt_behandling' ? value : item.fastsatt_behandling) +
          (field === 'fastsatt_vare' ? value : item.fastsatt_vare);
      }
      
      return updated;
    }));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const modifiedItems = fastsattData.filter(item => item.isModified || !item.id);
      
      for (const item of modifiedItems) {
        if (item.id) {
          // Update existing
          await supabase
            .from("budsjett_fastsatt")
            .update({
              fastsatt_behandling: item.fastsatt_behandling,
              fastsatt_vare: item.fastsatt_vare,
              fastsatt_arsbudsjett: item.fastsatt_arsbudsjett,
              fastsatt_timer: item.fastsatt_timer
            })
            .eq("id", item.id);
        } else {
          // Insert new
          const { data } = await supabase
            .from("budsjett_fastsatt")
            .insert({
              versjon_id: versionId,
              salon_id: salonId,
              user_id: item.user_id,
              fastsatt_behandling: item.fastsatt_behandling,
              fastsatt_vare: item.fastsatt_vare,
              fastsatt_arsbudsjett: item.fastsatt_arsbudsjett,
              fastsatt_timer: item.fastsatt_timer
            })
            .select()
            .single();

          if (data) {
            setFastsattData(prev => prev.map(f => 
              f.user_id === item.user_id ? { ...f, id: data.id, isModified: false } : f
            ));
          }
        }
      }

      setFastsattData(prev => prev.map(f => ({ ...f, isModified: false })));

      toast({
        title: "Lagret",
        description: "Fastsatte budsjetter er oppdatert"
      });
    } catch (error) {
      console.error("Error saving fastsatt:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke lagre",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const handleApprove = async (userId: string) => {
    setApproving(userId);
    try {
      const item = fastsattData.find(f => f.user_id === userId);
      if (!item?.id) {
        toast({
          title: "Feil",
          description: "Lagre budsjettet først",
          variant: "destructive"
        });
        return;
      }

      await supabase
        .from("budsjett_fastsatt")
        .update({
          godkjent_av: user?.id,
          godkjent_dato: new Date().toISOString()
        })
        .eq("id", item.id);

      setFastsattData(prev => prev.map(f => 
        f.user_id === userId 
          ? { ...f, godkjent_av: user?.id || null, godkjent_dato: new Date().toISOString() }
          : f
      ));

      toast({
        title: "Godkjent",
        description: "Budsjettet er nå godkjent"
      });
    } catch (error) {
      console.error("Error approving:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke godkjenne",
        variant: "destructive"
      });
    } finally {
      setApproving(null);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("nb-NO", {
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value);
  };

  const hasModifications = fastsattData.some(f => f.isModified);

  const totals = fastsattData.reduce((acc, item) => ({
    behandling: acc.behandling + item.fastsatt_behandling,
    vare: acc.vare + item.fastsatt_vare,
    total: acc.total + item.fastsatt_arsbudsjett,
    generated: acc.generated + (item.generated_total || 0)
  }), { behandling: 0, vare: 0, total: 0, generated: 0 });

  if (loading) {
    return <Skeleton className="h-96" />;
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Fastsatte årsbudsjetter
              </CardTitle>
              <CardDescription>
                Juster og godkjenn endelige budsjettmål per stylist
              </CardDescription>
            </div>
            <Button onClick={handleSave} disabled={saving || !hasModifications}>
              {saving ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Save className="h-4 w-4 mr-2" />
              )}
              Lagre endringer
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {fastsattData.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">
              Ingen stylister funnet. Generer budsjett først.
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Stylist</TableHead>
                  <TableHead className="text-right">Generert</TableHead>
                  <TableHead className="text-right">Behandling</TableHead>
                  <TableHead className="text-right">Vare</TableHead>
                  <TableHead className="text-right">Totalt</TableHead>
                  <TableHead className="text-center">Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {fastsattData.map(item => (
                  <TableRow key={item.user_id}>
                    <TableCell className="font-medium">
                      {item.user_name}
                      {item.isModified && (
                        <Badge variant="outline" className="ml-2 text-xs">
                          Endret
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-right text-muted-foreground">
                      {formatCurrency(item.generated_total || 0)}
                    </TableCell>
                    <TableCell className="text-right">
                      <Input
                        type="number"
                        value={item.fastsatt_behandling}
                        onChange={(e) => updateValue(item.user_id, 'fastsatt_behandling', parseFloat(e.target.value) || 0)}
                        className="w-28 text-right ml-auto"
                      />
                    </TableCell>
                    <TableCell className="text-right">
                      <Input
                        type="number"
                        value={item.fastsatt_vare}
                        onChange={(e) => updateValue(item.user_id, 'fastsatt_vare', parseFloat(e.target.value) || 0)}
                        className="w-28 text-right ml-auto"
                      />
                    </TableCell>
                    <TableCell className="text-right font-bold">
                      {formatCurrency(item.fastsatt_arsbudsjett)}
                    </TableCell>
                    <TableCell className="text-center">
                      {item.godkjent_dato ? (
                        <Badge className="bg-green-600">
                          <CheckCircle className="h-3 w-3 mr-1" />
                          Godkjent
                        </Badge>
                      ) : (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleApprove(item.user_id)}
                          disabled={!item.id || item.isModified || approving === item.user_id}
                        >
                          {approving === item.user_id ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            "Godkjenn"
                          )}
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
                <TableRow className="bg-muted/50 font-bold">
                  <TableCell>Totalt</TableCell>
                  <TableCell className="text-right">{formatCurrency(totals.generated)}</TableCell>
                  <TableCell className="text-right">{formatCurrency(totals.behandling)}</TableCell>
                  <TableCell className="text-right">{formatCurrency(totals.vare)}</TableCell>
                  <TableCell className="text-right">{formatCurrency(totals.total)}</TableCell>
                  <TableCell></TableCell>
                </TableRow>
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
