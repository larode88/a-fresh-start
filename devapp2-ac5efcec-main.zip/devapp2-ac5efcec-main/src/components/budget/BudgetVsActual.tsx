import { useState, useEffect } from "react";
import { getBudgetVsActual } from "@/integrations/supabase/budgetsService";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { TrendingUp, TrendingDown, Minus, Calendar } from "lucide-react";
import { cn } from "@/lib/utils";

interface BudgetVsActualProps {
  salonId: string;
  versionId: string;
  year: number;
}

interface StylistComparison {
  user_id: string;
  user_name: string;
  budsjett_behandling: number;
  budsjett_vare: number;
  budsjett_total: number;
  faktisk_behandling: number;
  faktisk_vare: number;
  faktisk_total: number;
  avvik_behandling: number;
  avvik_vare: number;
  avvik_total: number;
  oppnaaelse_prosent: number;
}

const monthOptions = [
  { value: "1", label: "Januar" },
  { value: "2", label: "Februar" },
  { value: "3", label: "Mars" },
  { value: "4", label: "April" },
  { value: "5", label: "Mai" },
  { value: "6", label: "Juni" },
  { value: "7", label: "Juli" },
  { value: "8", label: "August" },
  { value: "9", label: "September" },
  { value: "10", label: "Oktober" },
  { value: "11", label: "November" },
  { value: "12", label: "Desember" },
];

export function BudgetVsActual({ salonId, versionId, year }: BudgetVsActualProps) {
  const currentMonth = new Date().getMonth() + 1;
  const [selectedMonth, setSelectedMonth] = useState<string>(currentMonth.toString());
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<StylistComparison[]>([]);
  const [totals, setTotals] = useState({
    budsjett: 0,
    faktisk: 0,
    avvik: 0,
    oppnaaelse: 0
  });

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const result = await getBudgetVsActual(
          salonId,
          versionId,
          parseInt(selectedMonth),
          year
        );
        
        setData(result);
        
        // Calculate totals
        const totalBudsjett = result.reduce((sum, r) => sum + r.budsjett_total, 0);
        const totalFaktisk = result.reduce((sum, r) => sum + r.faktisk_total, 0);
        const totalAvvik = totalFaktisk - totalBudsjett;
        const oppnaaelse = totalBudsjett > 0 
          ? Math.round((totalFaktisk / totalBudsjett) * 100) 
          : 0;
        
        setTotals({
          budsjett: totalBudsjett,
          faktisk: totalFaktisk,
          avvik: totalAvvik,
          oppnaaelse
        });
      } catch (error) {
        console.error("Error fetching budget vs actual:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [salonId, versionId, year, selectedMonth]);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("nb-NO", {
      style: "currency",
      currency: "NOK",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value);
  };

  const getStatusColor = (percent: number) => {
    if (percent >= 100) return "text-green-600";
    if (percent >= 80) return "text-yellow-600";
    return "text-red-600";
  };

  const getStatusBadge = (percent: number) => {
    if (percent >= 100) {
      return <Badge variant="default" className="bg-green-600">Over mål</Badge>;
    }
    if (percent >= 80) {
      return <Badge variant="outline" className="border-yellow-600 text-yellow-600">Nært mål</Badge>;
    }
    return <Badge variant="destructive">Under mål</Badge>;
  };

  const getTrendIcon = (avvik: number) => {
    if (avvik > 0) return <TrendingUp className="h-4 w-4 text-green-600" />;
    if (avvik < 0) return <TrendingDown className="h-4 w-4 text-red-600" />;
    return <Minus className="h-4 w-4 text-muted-foreground" />;
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-12 w-48" />
        <Skeleton className="h-64" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Month selector and summary */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <Select value={selectedMonth} onValueChange={setSelectedMonth}>
          <SelectTrigger className="w-[180px]">
            <Calendar className="h-4 w-4 mr-2" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {monthOptions.map(opt => (
              <SelectItem key={opt.value} value={opt.value}>
                {opt.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <div className="flex items-center gap-4">
          <div className="text-right">
            <p className="text-sm text-muted-foreground">Total oppnåelse</p>
            <p className={cn("text-2xl font-bold", getStatusColor(totals.oppnaaelse))}>
              {totals.oppnaaelse}%
            </p>
          </div>
          <Progress 
            value={Math.min(totals.oppnaaelse, 100)} 
            className="w-32 h-3"
          />
        </div>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Budsjettert</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{formatCurrency(totals.budsjett)}</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Faktisk</CardDescription>
          </CardHeader>
          <CardContent>
            <p className={cn("text-2xl font-bold", getStatusColor(totals.oppnaaelse))}>
              {formatCurrency(totals.faktisk)}
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Avvik</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              {getTrendIcon(totals.avvik)}
              <p className={cn(
                "text-2xl font-bold",
                totals.avvik >= 0 ? "text-green-600" : "text-red-600"
              )}>
                {totals.avvik >= 0 ? "+" : ""}{formatCurrency(totals.avvik)}
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed comparison table */}
      <Card>
        <CardHeader>
          <CardTitle>Avvik per stylist</CardTitle>
          <CardDescription>
            Sammenligning av budsjett mot faktiske tall for {monthOptions.find(m => m.value === selectedMonth)?.label}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {data.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">
              Ingen data for denne perioden. Sjekk at det er registrert historiske tall.
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Stylist</TableHead>
                  <TableHead className="text-right">Budsjett</TableHead>
                  <TableHead className="text-right">Faktisk</TableHead>
                  <TableHead className="text-right">Avvik</TableHead>
                  <TableHead className="text-right">Oppnåelse</TableHead>
                  <TableHead className="text-center">Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {data.map(row => (
                  <TableRow key={row.user_id}>
                    <TableCell className="font-medium">{row.user_name}</TableCell>
                    <TableCell className="text-right">
                      {formatCurrency(row.budsjett_total)}
                    </TableCell>
                    <TableCell className="text-right">
                      {formatCurrency(row.faktisk_total)}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1">
                        {getTrendIcon(row.avvik_total)}
                        <span className={row.avvik_total >= 0 ? "text-green-600" : "text-red-600"}>
                          {row.avvik_total >= 0 ? "+" : ""}{formatCurrency(row.avvik_total)}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <span className={getStatusColor(row.oppnaaelse_prosent)}>
                        {row.oppnaaelse_prosent}%
                      </span>
                    </TableCell>
                    <TableCell className="text-center">
                      {getStatusBadge(row.oppnaaelse_prosent)}
                    </TableCell>
                  </TableRow>
                ))}
                <TableRow className="bg-muted/50 font-bold">
                  <TableCell>Totalt</TableCell>
                  <TableCell className="text-right">{formatCurrency(totals.budsjett)}</TableCell>
                  <TableCell className="text-right">{formatCurrency(totals.faktisk)}</TableCell>
                  <TableCell className="text-right">
                    <span className={totals.avvik >= 0 ? "text-green-600" : "text-red-600"}>
                      {totals.avvik >= 0 ? "+" : ""}{formatCurrency(totals.avvik)}
                    </span>
                  </TableCell>
                  <TableCell className="text-right">{totals.oppnaaelse}%</TableCell>
                  <TableCell className="text-center">
                    {getStatusBadge(totals.oppnaaelse)}
                  </TableCell>
                </TableRow>
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}