import { useState, useEffect, useMemo } from "react";
import { getBudgetsBySalon, getBudgetSummary, getManualBudgets } from "@/integrations/supabase/budgetsService";
import { getAnsatteBySalong } from "@/integrations/supabase/ansatteService";
import { exportBudgetToExcel } from "@/lib/budgetExportUtils";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { TrendingUp, Users, Calendar, DollarSign, Download, FileSpreadsheet, Filter, X } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { format, getISOWeek, parseISO } from "date-fns";
import { nb } from "date-fns/locale";
import { cn } from "@/lib/utils";
import { Label } from "@/components/ui/label";

interface BudgetOverviewProps {
  salonId: string;
  versionId: string;
  year: number;
  salonName?: string;
  versionName?: string;
}

interface StylistBudget {
  ansatt_id: string;
  ansatt_name: string;
  total_behandling: number;
  total_vare: number;
  total_budsjett: number;
  total_kundetimer: number;
  total_planlagte_timer: number;
  entries_count: number;
  is_manual?: boolean;
}

interface MonthlyTotal {
  month: number;
  behandling: number;
  vare: number;
  total: number;
  kundetimer: number;
}

interface WeeklyTotal {
  week: number;
  behandling: number;
  vare: number;
  total: number;
  kundetimer: number;
}

interface DailyTotal {
  dato: string;
  behandling: number;
  vare: number;
  total: number;
  kundetimer: number;
}

interface AnsattOption {
  id: string;
  navn: string;
}

type PeriodType = 'mnd' | 'uke' | 'dag';

export function BudgetOverview({ salonId, versionId, year, salonName = "Salong", versionName = "Budsjett" }: BudgetOverviewProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [exporting, setExporting] = useState(false);
  const [budgetData, setBudgetData] = useState<any[]>([]);
  const [manualBudgetData, setManualBudgetData] = useState<any[]>([]);
  const [stylistBudgets, setStylistBudgets] = useState<StylistBudget[]>([]);
  const [ansattOptions, setAnsattOptions] = useState<AnsattOption[]>([]);
  const [totals, setTotals] = useState({
    behandling: 0,
    vare: 0,
    total: 0,
    kundetimer: 0,
    planlagte_timer: 0
  });

  // Filter states
  const [selectedAnsatt, setSelectedAnsatt] = useState<string>("all");
  const [periodType, setPeriodType] = useState<PeriodType>('mnd');
  const [selectedMonth, setSelectedMonth] = useState<string>("all");
  const [selectedWeek, setSelectedWeek] = useState<string>("all");
  const [fromDate, setFromDate] = useState<Date | undefined>(undefined);
  const [toDate, setToDate] = useState<Date | undefined>(undefined);

  const monthNames = [
    "Januar", "Februar", "Mars", "April", "Mai", "Juni",
    "Juli", "August", "September", "Oktober", "November", "Desember"
  ];

  const shortMonthNames = [
    "Jan", "Feb", "Mar", "Apr", "Mai", "Jun",
    "Jul", "Aug", "Sep", "Okt", "Nov", "Des"
  ];

  useEffect(() => {
    const fetchBudgetData = async () => {
      setLoading(true);
      try {
        // Fetch budgets, manual budgets, and ansatte in parallel
        const [budgetDataResult, manualBudgets, ansatte] = await Promise.all([
          getBudgetsBySalon(salonId, versionId),
          getManualBudgets(salonId, versionId),
          getAnsatteBySalong(salonId, true) // activeOnly = true
        ]);

        // Build ansatt options for filter
        const options: AnsattOption[] = ansatte.map(a => ({
          id: a.id,
          navn: `${a.fornavn}${a.etternavn ? ' ' + a.etternavn : ''}`
        })).sort((a, b) => a.navn.localeCompare(b.navn));
        setAnsattOptions(options);

        if ((!budgetDataResult || budgetDataResult.length === 0) && manualBudgets.length === 0) {
          setBudgetData([]);
          setManualBudgetData([]);
          setStylistBudgets([]);
          setTotals({ behandling: 0, vare: 0, total: 0, kundetimer: 0, planlagte_timer: 0 });
          return;
        }

        setBudgetData(budgetDataResult || []);
        setManualBudgetData(manualBudgets);

        // Aggregate by stylist (regular budgets)
        const stylistMap = new Map<string, StylistBudget>();
        (budgetDataResult || []).forEach(entry => {
          const ansattId = entry.ansatt_id;
          if (!ansattId) return;
          
          const ansattName = entry.ansatte 
            ? `${entry.ansatte.fornavn}${entry.ansatte.etternavn ? ' ' + entry.ansatte.etternavn : ''}`
            : "Ukjent";
          
          if (!stylistMap.has(ansattId)) {
            stylistMap.set(ansattId, {
              ansatt_id: ansattId,
              ansatt_name: ansattName,
              total_behandling: 0,
              total_vare: 0,
              total_budsjett: 0,
              total_kundetimer: 0,
              total_planlagte_timer: 0,
              entries_count: 0,
              is_manual: false
            });
          }
          
          const current = stylistMap.get(ansattId)!;
          current.total_behandling += entry.behandling_budsjett || 0;
          current.total_vare += entry.vare_budsjett || 0;
          current.total_budsjett += entry.totalt_budsjett || 0;
          current.total_kundetimer += entry.kundetimer || 0;
          current.total_planlagte_timer += entry.planlagte_timer || 0;
          current.entries_count += 1;
        });

        // Add manual budgets to stylist map
        const manualStylistMap = new Map<string, StylistBudget>();
        manualBudgets.forEach(entry => {
          const ansattId = entry.ansatt_id;
          const ansattName = entry.ansatte 
            ? `${entry.ansatte.fornavn}${entry.ansatte.etternavn ? ' ' + entry.ansatte.etternavn : ''}`
            : "Ukjent";
          
          if (!manualStylistMap.has(ansattId)) {
            manualStylistMap.set(ansattId, {
              ansatt_id: ansattId,
              ansatt_name: ansattName,
              total_behandling: 0,
              total_vare: 0,
              total_budsjett: 0,
              total_kundetimer: 0,
              total_planlagte_timer: 0,
              entries_count: 0,
              is_manual: true
            });
          }
          
          const current = manualStylistMap.get(ansattId)!;
          current.total_behandling += entry.behandling_budsjett || 0;
          current.total_vare += entry.vare_budsjett || 0;
          current.total_budsjett += (entry.behandling_budsjett || 0) + (entry.vare_budsjett || 0);
          current.entries_count += 1;
        });

        // Merge manual stylists into main map (only if not already present from regular budgets)
        manualStylistMap.forEach((value, key) => {
          if (!stylistMap.has(key)) {
            stylistMap.set(key, value);
          }
        });

        const stylistArray = Array.from(stylistMap.values())
          .sort((a, b) => b.total_budsjett - a.total_budsjett);
        setStylistBudgets(stylistArray);

        // Calculate totals including manual budgets
        const summary = await getBudgetSummary(salonId, versionId);
        const manualTotals = manualBudgets.reduce((acc, entry) => {
          acc.behandling += entry.behandling_budsjett || 0;
          acc.vare += entry.vare_budsjett || 0;
          return acc;
        }, { behandling: 0, vare: 0 });

        setTotals({
          behandling: summary.total_behandling + manualTotals.behandling,
          vare: summary.total_vare + manualTotals.vare,
          total: summary.total_budsjett + manualTotals.behandling + manualTotals.vare,
          kundetimer: summary.total_kundetimer,
          planlagte_timer: summary.total_planlagte_timer
        });

      } catch (error) {
        console.error("Error fetching budget data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchBudgetData();
  }, [salonId, versionId, year]);

  // Filter budget data based on selected filters
  const filteredBudgetData = useMemo(() => {
    let data = [...budgetData];
    
    // Ansatt filter
    if (selectedAnsatt !== "all") {
      data = data.filter(d => d.ansatt_id === selectedAnsatt);
    }
    
    // Date range filter (overrides other period filters)
    if (fromDate && toDate) {
      data = data.filter(d => {
        const date = parseISO(d.dato);
        return date >= fromDate && date <= toDate;
      });
    } else if (periodType === 'mnd' && selectedMonth !== "all") {
      data = data.filter(d => d.maned === parseInt(selectedMonth));
    } else if (periodType === 'uke' && selectedWeek !== "all") {
      data = data.filter(d => d.uke === parseInt(selectedWeek));
    }
    
    return data;
  }, [budgetData, selectedAnsatt, periodType, selectedMonth, selectedWeek, fromDate, toDate]);

  // Calculate aggregated data based on period type
  const periodData = useMemo(() => {
    if (periodType === 'mnd') {
      // Monthly aggregation
      const monthMap = new Map<number, MonthlyTotal>();
      for (let m = 1; m <= 12; m++) {
        monthMap.set(m, { month: m, behandling: 0, vare: 0, total: 0, kundetimer: 0 });
      }
      
      filteredBudgetData.forEach(entry => {
        const month = entry.maned;
        const current = monthMap.get(month)!;
        current.behandling += entry.behandling_budsjett || 0;
        current.vare += entry.vare_budsjett || 0;
        current.total += entry.totalt_budsjett || 0;
        current.kundetimer += entry.kundetimer || 0;
      });

      // Add manual budgets (filtered by ansatt if selected)
      let filteredManual = manualBudgetData;
      if (selectedAnsatt !== "all") {
        filteredManual = filteredManual.filter(d => d.ansatt_id === selectedAnsatt);
      }
      if (selectedMonth !== "all") {
        filteredManual = filteredManual.filter(d => d.maned === parseInt(selectedMonth));
      }
      
      filteredManual.forEach(entry => {
        const month = entry.maned;
        const current = monthMap.get(month)!;
        current.behandling += entry.behandling_budsjett || 0;
        current.vare += entry.vare_budsjett || 0;
        current.total += (entry.behandling_budsjett || 0) + (entry.vare_budsjett || 0);
      });

      return Array.from(monthMap.values()).filter(m => 
        selectedMonth === "all" || m.month === parseInt(selectedMonth)
      );
    } else if (periodType === 'uke') {
      // Weekly aggregation
      const weekMap = new Map<number, WeeklyTotal>();
      
      filteredBudgetData.forEach(entry => {
        const week = entry.uke;
        if (!weekMap.has(week)) {
          weekMap.set(week, { week, behandling: 0, vare: 0, total: 0, kundetimer: 0 });
        }
        const current = weekMap.get(week)!;
        current.behandling += entry.behandling_budsjett || 0;
        current.vare += entry.vare_budsjett || 0;
        current.total += entry.totalt_budsjett || 0;
        current.kundetimer += entry.kundetimer || 0;
      });

      return Array.from(weekMap.values()).sort((a, b) => a.week - b.week);
    } else {
      // Daily view
      const dayMap = new Map<string, DailyTotal>();
      
      filteredBudgetData.forEach(entry => {
        const dato = entry.dato;
        if (!dayMap.has(dato)) {
          dayMap.set(dato, { dato, behandling: 0, vare: 0, total: 0, kundetimer: 0 });
        }
        const current = dayMap.get(dato)!;
        current.behandling += entry.behandling_budsjett || 0;
        current.vare += entry.vare_budsjett || 0;
        current.total += entry.totalt_budsjett || 0;
        current.kundetimer += entry.kundetimer || 0;
      });

      return Array.from(dayMap.values()).sort((a, b) => a.dato.localeCompare(b.dato));
    }
  }, [filteredBudgetData, manualBudgetData, periodType, selectedAnsatt, selectedMonth]);

  // Calculate filtered totals
  const filteredTotals = useMemo(() => {
    const t = { behandling: 0, vare: 0, total: 0, kundetimer: 0 };
    
    if (Array.isArray(periodData)) {
      periodData.forEach((p: any) => {
        t.behandling += p.behandling || 0;
        t.vare += p.vare || 0;
        t.total += p.total || 0;
        t.kundetimer += p.kundetimer || 0;
      });
    }
    
    return t;
  }, [periodData]);

  // Check if any filters are active
  const hasActiveFilters = selectedAnsatt !== "all" || selectedMonth !== "all" || selectedWeek !== "all" || fromDate || toDate;

  const clearFilters = () => {
    setSelectedAnsatt("all");
    setSelectedMonth("all");
    setSelectedWeek("all");
    setFromDate(undefined);
    setToDate(undefined);
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat("nb-NO", {
      style: "currency",
      currency: "NOK",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value);
  };

  const formatNumber = (value: number) => {
    return new Intl.NumberFormat("nb-NO", {
      minimumFractionDigits: 1,
      maximumFractionDigits: 1
    }).format(value);
  };

  const handleExport = async () => {
    if (budgetData.length === 0) {
      toast({
        title: "Ingen data",
        description: "Ingen budsjettdata å eksportere",
        variant: "destructive"
      });
      return;
    }

    setExporting(true);
    try {
      exportBudgetToExcel(budgetData, salonName, versionName, year);
      toast({
        title: "Eksport fullført",
        description: "Budsjettdata er lastet ned som Excel-fil"
      });
    } catch (error) {
      console.error("Export error:", error);
      toast({
        title: "Eksportfeil",
        description: "Kunne ikke eksportere budsjettdata",
        variant: "destructive"
      });
    } finally {
      setExporting(false);
    }
  };

  // Generate week options
  const weekOptions = useMemo(() => {
    const weeks = new Set<number>();
    budgetData.forEach(d => {
      if (d.uke) weeks.add(d.uke);
    });
    return Array.from(weeks).sort((a, b) => a - b);
  }, [budgetData]);

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => (
            <Skeleton key={i} className="h-24" />
          ))}
        </div>
        <Skeleton className="h-64" />
      </div>
    );
  }

  if (stylistBudgets.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <Calendar className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
          <p className="text-muted-foreground">
            Ingen budsjettdata for denne versjonen ennå.
          </p>
          <p className="text-sm text-muted-foreground mt-2">
            Gå til "Generer"-fanen for å opprette budsjetter.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Export button */}
      <div className="flex justify-end">
        <Button 
          variant="outline" 
          onClick={handleExport}
          disabled={exporting || budgetData.length === 0}
        >
          {exporting ? (
            <>
              <Download className="h-4 w-4 mr-2 animate-spin" />
              Eksporterer...
            </>
          ) : (
            <>
              <FileSpreadsheet className="h-4 w-4 mr-2" />
              Eksporter til Excel
            </>
          )}
        </Button>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription className="flex items-center gap-2">
              <DollarSign className="h-4 w-4" />
              Totalt budsjett
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{formatCurrency(totals.total)}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Behandling
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{formatCurrency(totals.behandling)}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription className="flex items-center gap-2">
              <DollarSign className="h-4 w-4" />
              Varesalg
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{formatCurrency(totals.vare)}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Kundetimer
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{formatNumber(totals.kundetimer)}</p>
          </CardContent>
        </Card>
      </div>

      {/* Per stylist breakdown */}
      <Card>
        <CardHeader>
          <CardTitle>Budsjett per stylist</CardTitle>
          <CardDescription>
            Årsbudsjett fordelt på stylister
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Stylist</TableHead>
                <TableHead className="text-right">Timer</TableHead>
                <TableHead className="text-right">Behandling</TableHead>
                <TableHead className="text-right">Vare</TableHead>
                <TableHead className="text-right">Totalt</TableHead>
                <TableHead className="text-right">Kr/time</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {stylistBudgets.map(stylist => {
                const krPerTime = stylist.total_planlagte_timer > 0 
                  ? stylist.total_budsjett / stylist.total_planlagte_timer 
                  : 0;
                return (
                  <TableRow key={stylist.ansatt_id}>
                    <TableCell className="font-medium">
                      {stylist.ansatt_name}
                      {stylist.is_manual ? (
                        <Badge variant="secondary" className="ml-2 text-xs">
                          Manuelt
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="ml-2 text-xs">
                          {stylist.entries_count} dager
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      {formatNumber(stylist.total_planlagte_timer)}
                    </TableCell>
                    <TableCell className="text-right">
                      {formatCurrency(stylist.total_behandling)}
                    </TableCell>
                    <TableCell className="text-right">
                      {formatCurrency(stylist.total_vare)}
                    </TableCell>
                    <TableCell className="text-right font-medium">
                      {formatCurrency(stylist.total_budsjett)}
                    </TableCell>
                    <TableCell className="text-right">
                      {formatNumber(krPerTime)}
                    </TableCell>
                  </TableRow>
                );
              })}
              <TableRow className="bg-muted/50 font-bold">
                <TableCell>Totalt</TableCell>
                <TableCell className="text-right">{formatNumber(totals.planlagte_timer)}</TableCell>
                <TableCell className="text-right">{formatCurrency(totals.behandling)}</TableCell>
                <TableCell className="text-right">{formatCurrency(totals.vare)}</TableCell>
                <TableCell className="text-right">{formatCurrency(totals.total)}</TableCell>
                <TableCell className="text-right">
                  {formatNumber(totals.planlagte_timer > 0 ? totals.total / totals.planlagte_timer : 0)}
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Monthly/Weekly/Daily breakdown with filters */}
      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Filter className="h-5 w-5" />
                {periodType === 'mnd' ? 'Månedlig oversikt' : periodType === 'uke' ? 'Ukentlig oversikt' : 'Daglig oversikt'}
              </CardTitle>
              <CardDescription>
                Budsjett fordelt per {periodType === 'mnd' ? 'måned' : periodType === 'uke' ? 'uke' : 'dag'}
                {hasActiveFilters && (
                  <span className="ml-2 text-primary">(filtrert)</span>
                )}
              </CardDescription>
            </div>
            {hasActiveFilters && (
              <Button variant="ghost" size="sm" onClick={clearFilters} className="text-muted-foreground">
                <X className="h-4 w-4 mr-1" />
                Nullstill filtre
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Filter controls */}
          <div className="flex flex-wrap items-end gap-4 p-4 bg-muted/30 rounded-lg border">
            {/* Ansatt filter */}
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">Ansatt</Label>
              <Select value={selectedAnsatt} onValueChange={setSelectedAnsatt}>
                <SelectTrigger className="w-[180px] bg-background">
                  <SelectValue placeholder="Alle ansatte" />
                </SelectTrigger>
                <SelectContent className="bg-background z-50">
                  <SelectItem value="all">Alle ansatte</SelectItem>
                  {ansattOptions.map(a => (
                    <SelectItem key={a.id} value={a.id}>{a.navn}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Period type toggle */}
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">Periode</Label>
              <ToggleGroup 
                type="single" 
                value={periodType} 
                onValueChange={(value) => value && setPeriodType(value as PeriodType)}
                className="bg-background border rounded-md"
              >
                <ToggleGroupItem value="mnd" className="px-4">Mnd</ToggleGroupItem>
                <ToggleGroupItem value="uke" className="px-4">Uke</ToggleGroupItem>
                <ToggleGroupItem value="dag" className="px-4">Dag</ToggleGroupItem>
              </ToggleGroup>
            </div>

            {/* Month filter (when period type is month) */}
            {periodType === 'mnd' && (
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">Måned</Label>
                <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                  <SelectTrigger className="w-[140px] bg-background">
                    <SelectValue placeholder="Alle måneder" />
                  </SelectTrigger>
                  <SelectContent className="bg-background z-50">
                    <SelectItem value="all">Alle måneder</SelectItem>
                    {monthNames.map((name, i) => (
                      <SelectItem key={i + 1} value={String(i + 1)}>{name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {/* Week filter (when period type is week) */}
            {periodType === 'uke' && (
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">Uke</Label>
                <Select value={selectedWeek} onValueChange={setSelectedWeek}>
                  <SelectTrigger className="w-[120px] bg-background">
                    <SelectValue placeholder="Alle uker" />
                  </SelectTrigger>
                  <SelectContent className="bg-background z-50 max-h-[300px]">
                    <SelectItem value="all">Alle uker</SelectItem>
                    {weekOptions.map(week => (
                      <SelectItem key={week} value={String(week)}>Uke {week}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {/* Date range */}
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">Fra dato</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-[130px] justify-start text-left font-normal bg-background",
                      !fromDate && "text-muted-foreground"
                    )}
                  >
                    <Calendar className="mr-2 h-4 w-4" />
                    {fromDate ? format(fromDate, "dd.MM.yy") : "Velg"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0 bg-background z-50" align="start">
                  <CalendarComponent
                    mode="single"
                    selected={fromDate}
                    onSelect={setFromDate}
                    initialFocus
                    className="pointer-events-auto"
                    locale={nb}
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">Til dato</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    className={cn(
                      "w-[130px] justify-start text-left font-normal bg-background",
                      !toDate && "text-muted-foreground"
                    )}
                  >
                    <Calendar className="mr-2 h-4 w-4" />
                    {toDate ? format(toDate, "dd.MM.yy") : "Velg"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0 bg-background z-50" align="start">
                  <CalendarComponent
                    mode="single"
                    selected={toDate}
                    onSelect={setToDate}
                    initialFocus
                    className="pointer-events-auto"
                    locale={nb}
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          {/* Data table */}
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>
                  {periodType === 'mnd' ? 'Måned' : periodType === 'uke' ? 'Uke' : 'Dato'}
                </TableHead>
                <TableHead className="text-right">Behandling</TableHead>
                <TableHead className="text-right">Vare</TableHead>
                <TableHead className="text-right">Totalt</TableHead>
                <TableHead className="text-right">Timer</TableHead>
                <TableHead className="text-right">Kr/time</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {periodType === 'mnd' && (periodData as MonthlyTotal[]).map(month => (
                <TableRow key={month.month}>
                  <TableCell className="font-medium">
                    {shortMonthNames[month.month - 1]}
                  </TableCell>
                  <TableCell className="text-right">
                    {formatCurrency(month.behandling)}
                  </TableCell>
                  <TableCell className="text-right">
                    {formatCurrency(month.vare)}
                  </TableCell>
                  <TableCell className="text-right font-medium">
                    {formatCurrency(month.total)}
                  </TableCell>
                  <TableCell className="text-right">
                    {formatNumber(month.kundetimer)}
                  </TableCell>
                  <TableCell className="text-right">
                    {month.kundetimer > 0 ? formatCurrency(month.total / month.kundetimer) : "-"}
                  </TableCell>
                </TableRow>
              ))}
              {periodType === 'uke' && (periodData as WeeklyTotal[]).map(week => (
                <TableRow key={week.week}>
                  <TableCell className="font-medium">
                    Uke {week.week}
                  </TableCell>
                  <TableCell className="text-right">
                    {formatCurrency(week.behandling)}
                  </TableCell>
                  <TableCell className="text-right">
                    {formatCurrency(week.vare)}
                  </TableCell>
                  <TableCell className="text-right font-medium">
                    {formatCurrency(week.total)}
                  </TableCell>
                  <TableCell className="text-right">
                    {formatNumber(week.kundetimer)}
                  </TableCell>
                  <TableCell className="text-right">
                    {week.kundetimer > 0 ? formatCurrency(week.total / week.kundetimer) : "-"}
                  </TableCell>
                </TableRow>
              ))}
              {periodType === 'dag' && (periodData as DailyTotal[]).map(day => (
                <TableRow key={day.dato}>
                  <TableCell className="font-medium">
                    {format(parseISO(day.dato), "dd.MM.yyyy", { locale: nb })}
                  </TableCell>
                  <TableCell className="text-right">
                    {formatCurrency(day.behandling)}
                  </TableCell>
                  <TableCell className="text-right">
                    {formatCurrency(day.vare)}
                  </TableCell>
                  <TableCell className="text-right font-medium">
                    {formatCurrency(day.total)}
                  </TableCell>
                  <TableCell className="text-right">
                    {formatNumber(day.kundetimer)}
                  </TableCell>
                  <TableCell className="text-right">
                    {day.kundetimer > 0 ? formatCurrency(day.total / day.kundetimer) : "-"}
                  </TableCell>
                </TableRow>
              ))}
              <TableRow className="bg-muted/50 font-bold">
                <TableCell>Totalt</TableCell>
                <TableCell className="text-right">{formatCurrency(filteredTotals.behandling)}</TableCell>
                <TableCell className="text-right">{formatCurrency(filteredTotals.vare)}</TableCell>
                <TableCell className="text-right">{formatCurrency(filteredTotals.total)}</TableCell>
                <TableCell className="text-right">{formatNumber(filteredTotals.kundetimer)}</TableCell>
                <TableCell className="text-right">
                  {filteredTotals.kundetimer > 0 ? formatCurrency(filteredTotals.total / filteredTotals.kundetimer) : "-"}
                </TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
