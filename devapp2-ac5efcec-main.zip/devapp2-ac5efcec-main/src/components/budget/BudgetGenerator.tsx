import { useState, useEffect, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { getActiveAnsatte, updateAnsattKPIs, AnsattForBudget } from "@/integrations/supabase/employeesService";
import { getMonthlyKPIs, getManualBudgets, ManualBudgetWithEmployee, getShiftsForBudget, getVacationDatesForBudget } from "@/integrations/supabase/budgetsService";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Calculator, Loader2, Users, Settings, Pencil, CheckCircle2, AlertCircle, CircleDot, Save, Info, CalendarDays } from "lucide-react";
import { 
  KPIParams,
  BudsjettArsak,
} from "@/lib/budsjettUtils";
import {
  beregnGjennomsnittTurnus,
  getTurnusTypeLabel,
  FULL_STILLING_TIMER,
  type TurnusType,
  type WeekPreference
} from "@/lib/turnusUtils";

interface BudgetGeneratorProps {
  salonId: string;
  versionId: string;
  year: number;
  onGenerated: () => void;
  refreshKey?: number;
}

interface Stylist {
  id: string;
  user_id: string | null;
  name: string;
  stillingsprosent: number; // Avtalt
  beregnetStillingsprosent: number | null; // Fra turnus
  gjennomsnittTimer: number | null;
  turnusType: TurnusType | null;
  selected: boolean;
  frisorfunksjon: string | null;
  lederstilling: string | null;
  effektivitet_prosent: number | null;
  omsetning_per_time: number | null;
  varesalg_prosent: number | null;
  rebooking_prosent: number | null;
  hasMonthlyKPIs: boolean;
}

interface GenerationParams extends KPIParams {}

// Get display name for role
function getRolleDisplay(frisorfunksjon: string | null, lederstilling: string | null): string {
  const roles: string[] = [];
  
  if (frisorfunksjon) {
    const funcMap: Record<string, string> = {
      'frisor': 'Frisør',
      'senior_frisor': 'Senior Frisør',
      'laerling': 'Lærling'
    };
    roles.push(funcMap[frisorfunksjon] || frisorfunksjon);
  }
  
  if (lederstilling) {
    const lederMap: Record<string, string> = {
      'daglig_leder': 'Daglig leder',
      'avdelingsleder': 'Avd.leder',
      'styreleder': 'Styreleder'
    };
    roles.push(lederMap[lederstilling] || lederstilling);
  }
  
  return roles.length > 0 ? roles.join(' + ') : 'Ansatt';
}

// Get KPI status: green = all individual, yellow = using defaults, red = missing data
function getKpiStatus(stylist: Stylist, defaults: GenerationParams): 'complete' | 'partial' | 'missing' {
  const hasEff = stylist.effektivitet_prosent !== null && stylist.effektivitet_prosent > 0;
  const hasOms = stylist.omsetning_per_time !== null && stylist.omsetning_per_time > 0;
  const hasVare = stylist.varesalg_prosent !== null && stylist.varesalg_prosent > 0;
  
  if (hasEff && hasOms && hasVare) return 'complete';
  if (hasEff || hasOms || hasVare) return 'partial';
  return 'missing';
}

export function BudgetGenerator({ salonId, versionId, year, onGenerated, refreshKey }: BudgetGeneratorProps) {
  const { toast } = useToast();
  
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [progress, setProgress] = useState(0);
  const [stylists, setStylists] = useState<Stylist[]>([]);
  const [defaultParams, setDefaultParams] = useState<GenerationParams>({
    effektivitet: 70,
    omsetningPerTime: 1200,
    varesalgProsent: 15,
    timerPerDag: 7.5
  });
  const [selectedMonth, setSelectedMonth] = useState<string>("all");
  
  // Edit dialog state
  const [editingStylist, setEditingStylist] = useState<Stylist | null>(null);
  const [editForm, setEditForm] = useState({
    effektivitet_prosent: 0,
    omsetning_per_time: 0,
    varesalg_prosent: 0
  });
  const [saving, setSaving] = useState(false);

  // Fetch stylists with KPI data from ansatte table
  useEffect(() => {
    const fetchStylists = async () => {
      setLoading(true);
      try {
        const ansatte = await getActiveAnsatte(salonId);

        // Fetch turnus data and monthly KPIs in parallel
        const [turnusResult, monthlyKPIs] = await Promise.all([
          supabase
            .from("ansatt_turnus")
            .select("*")
            .eq("salon_id", salonId)
            .is("gyldig_til", null),
          getMonthlyKPIs(salonId, versionId)
        ]);

        const turnusData = turnusResult.data;

        // Build set of employees with monthly KPIs
        const employeesWithMonthlyKPIs = new Set(monthlyKPIs.map(k => k.ansatt_id));

        // Calculate turnus-based stillingsprosent for each employee
        const stylistsWithKPIs: Stylist[] = ansatte.map(ansatt => {
          // Get unique turnus templates for this employee
          const ansattTurnus = (turnusData || []).filter(t => t.ansatt_id === ansatt.id);
          
          let beregnetStillingsprosent: number | null = null;
          let gjennomsnittTimer: number | null = null;
          let turnusType: TurnusType | null = null;
          
          if (ansattTurnus.length > 0) {
            // Deduplicate by uke_type + ukedag
            const uniqueTemplates = new Map<string, typeof ansattTurnus[0]>();
            ansattTurnus.forEach(t => {
              const key = `${t.uke_type || 'alle'}-${t.ukedag}`;
              if (!uniqueTemplates.has(key)) {
                uniqueTemplates.set(key, t);
              }
            });
            
            const uniqueList = Array.from(uniqueTemplates.values());
            
            // Detect turnus type
            const hasUke1 = uniqueList.some(t => t.uke_type === 'uke1');
            const hasUke2 = uniqueList.some(t => t.uke_type === 'uke2');
            const hasUke3 = uniqueList.some(t => t.uke_type === 'uke3');
            const hasPartall = uniqueList.some(t => t.uke_type === 'partall');
            const hasOddetall = uniqueList.some(t => t.uke_type === 'oddetall');

            turnusType = 'enkel';
            if (hasUke1 || hasUke2 || hasUke3) {
              turnusType = 'treuke';
            } else if (hasPartall || hasOddetall) {
              turnusType = 'touke';
            }

            // Group preferences per week type
            const preferanserPerUke: Record<string, WeekPreference[]> = {};
            for (const turnus of uniqueList) {
              const ukeType = turnus.uke_type || 'alle';
              if (!preferanserPerUke[ukeType]) {
                preferanserPerUke[ukeType] = [];
              }
              preferanserPerUke[ukeType].push({
                ukedag: turnus.ukedag,
                jobber: !turnus.fridag,
                onsket_start_tid: turnus.start_tid,
                onsket_slutt_tid: turnus.slutt_tid
              });
            }

            const beregning = beregnGjennomsnittTurnus(turnusType, preferanserPerUke);
            beregnetStillingsprosent = beregning.stillingsprosent;
            gjennomsnittTimer = beregning.gjennomsnittTimer;
          }

          return {
            id: ansatt.id,
            user_id: ansatt.user_id,
            name: ansatt.etternavn 
              ? `${ansatt.fornavn} ${ansatt.etternavn}` 
              : ansatt.fornavn,
            stillingsprosent: ansatt.stillingsprosent || 100,
            beregnetStillingsprosent,
            gjennomsnittTimer,
            turnusType,
            selected: true,
            frisorfunksjon: ansatt.frisorfunksjon,
            lederstilling: ansatt.lederstilling,
            effektivitet_prosent: ansatt.effektivitet_prosent,
            omsetning_per_time: ansatt.omsetning_per_time,
            varesalg_prosent: ansatt.varesalg_prosent,
            rebooking_prosent: ansatt.rebooking_prosent,
            hasMonthlyKPIs: employeesWithMonthlyKPIs.has(ansatt.id)
          };
        });

        setStylists(stylistsWithKPIs);
      } catch (error) {
        console.error("Error fetching stylists:", error);
        toast({
          title: "Feil",
          description: "Kunne ikke hente frisører",
          variant: "destructive"
        });
      } finally {
        setLoading(false);
      }
    };

    fetchStylists();
  }, [salonId, versionId, refreshKey]);

  const toggleStylist = (id: string) => {
    setStylists(prev => prev.map(s => 
      s.id === id ? { ...s, selected: !s.selected } : s
    ));
  };

  const selectAll = () => {
    setStylists(prev => prev.map(s => ({ ...s, selected: true })));
  };

  const selectNone = () => {
    setStylists(prev => prev.map(s => ({ ...s, selected: false })));
  };

  const openEditDialog = (stylist: Stylist) => {
    setEditingStylist(stylist);
    setEditForm({
      effektivitet_prosent: stylist.effektivitet_prosent ?? defaultParams.effektivitet,
      omsetning_per_time: stylist.omsetning_per_time ?? defaultParams.omsetningPerTime,
      varesalg_prosent: stylist.varesalg_prosent ?? defaultParams.varesalgProsent
    });
  };

  const handleSaveKPIs = async () => {
    if (!editingStylist) return;
    
    setSaving(true);
    try {
      await updateAnsattKPIs(editingStylist.id, {
        effektivitet_prosent: editForm.effektivitet_prosent,
        omsetning_per_time: editForm.omsetning_per_time,
        varesalg_prosent: editForm.varesalg_prosent
      });
      
      // Update local state
      setStylists(prev => prev.map(s => 
        s.id === editingStylist.id 
          ? { 
              ...s, 
              effektivitet_prosent: editForm.effektivitet_prosent,
              omsetning_per_time: editForm.omsetning_per_time,
              varesalg_prosent: editForm.varesalg_prosent
            } 
          : s
      ));
      
      toast({
        title: "KPIs lagret",
        description: `KPI-verdier for ${editingStylist.name} er oppdatert`
      });
      
      setEditingStylist(null);
    } catch (error) {
      console.error("Error saving KPIs:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke lagre KPI-verdier",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const handleGenerate = async () => {
    const selectedStylists = stylists.filter(s => s.selected);
    
    if (selectedStylists.length === 0) {
      toast({
        title: "Ingen frisører valgt",
        description: "Velg minst én frisør for å generere budsjett",
        variant: "destructive"
      });
      return;
    }

    setGenerating(true);
    setProgress(0);

    try {
      // Fetch all required data in parallel (including vacation dates)
      const [monthlyKPIs, manualBudgets, shiftsData, vacationDates] = await Promise.all([
        getMonthlyKPIs(salonId, versionId),
        getManualBudgets(salonId, versionId),
        getShiftsForBudget(salonId, year),
        getVacationDatesForBudget(salonId, year)
      ]);

      // Build manual budget lookup: ansatt_id -> month -> budget
      const manualBudgetMap = new Map<string, Map<number, ManualBudgetWithEmployee>>();
      manualBudgets.forEach(mb => {
        if (!manualBudgetMap.has(mb.ansatt_id)) {
          manualBudgetMap.set(mb.ansatt_id, new Map());
        }
        manualBudgetMap.get(mb.ansatt_id)!.set(mb.maned, mb);
      });

      // Build monthly KPI lookup map: ansatt_id -> month -> KPIs
      const monthlyKPIMap = new Map<string, Map<number, { eff: number | null; oms: number | null; vare: number | null }>>();
      monthlyKPIs.forEach(kpi => {
        if (!monthlyKPIMap.has(kpi.ansatt_id)) {
          monthlyKPIMap.set(kpi.ansatt_id, new Map());
        }
        monthlyKPIMap.get(kpi.ansatt_id)!.set(kpi.maned, {
          eff: kpi.effektivitet_prosent,
          oms: kpi.omsetning_per_time,
          vare: kpi.varesalg_prosent
        });
      });

      // Build shift lookup per stylist: ansatt_id -> array of {dato, timer, maned, uke, ukedag}
      interface ShiftDay {
        dato: string;
        timer: number;
        maned: number;
        uke: number;
        ukedag: number;
      }
      
      const shiftsByEmployee = new Map<string, ShiftDay[]>();
      shiftsData.forEach(shift => {
        const date = new Date(shift.dato);
        const isoWeekday = date.getDay() === 0 ? 7 : date.getDay(); // ISO: Mon=1, Sun=7
        const shiftDay: ShiftDay = {
          dato: shift.dato,
          timer: shift.timer_planlagt,
          maned: date.getMonth() + 1,
          uke: Math.ceil((date.getDate() + new Date(date.getFullYear(), date.getMonth(), 1).getDay()) / 7),
          ukedag: isoWeekday
        };
        
        if (!shiftsByEmployee.has(shift.ansatt_id)) {
          shiftsByEmployee.set(shift.ansatt_id, []);
        }
        shiftsByEmployee.get(shift.ansatt_id)!.push(shiftDay);
      });

      // Calculate total operations for progress
      let totalShifts = 0;
      selectedStylists.forEach(s => {
        const shifts = shiftsByEmployee.get(s.id) || [];
        const filteredShifts = selectedMonth !== "all" 
          ? shifts.filter(d => d.maned === parseInt(selectedMonth))
          : shifts;
        totalShifts += filteredShifts.length;
      });
      
      // Add manual budget months
      selectedStylists.forEach(s => {
        const mb = manualBudgetMap.get(s.id);
        if (mb) {
          if (selectedMonth !== "all") {
            if (mb.has(parseInt(selectedMonth))) totalShifts++;
          } else {
            totalShifts += mb.size;
          }
        }
      });

      let completed = 0;

      // Delete existing budget entries for selected stylists in this version
      for (const stylist of selectedStylists) {
        let deleteQuery = supabase
          .from("budsjett")
          .delete()
          .eq("versjon_id", versionId)
          .eq("ansatt_id", stylist.id);

        if (selectedMonth !== "all") {
          deleteQuery = deleteQuery.eq("maned", parseInt(selectedMonth));
        }

        await deleteQuery;
      }

      // Generate budget entries
      const budgetEntries: any[] = [];
      let turnusBasedCount = 0;
      let monthlyKPIUsedCount = 0;
      let manualBudgetCount = 0;

      // First: Insert manual budgets for stylists that have them
      for (const stylist of selectedStylists) {
        const stylistManualBudgets = manualBudgetMap.get(stylist.id);
        if (!stylistManualBudgets) continue;

        for (const [month, mb] of stylistManualBudgets) {
          // Skip if filtering by specific month
          if (selectedMonth !== "all" && month !== parseInt(selectedMonth)) continue;

          // Create a date for this month to get uke/ukedag info
          const monthDate = new Date(year, month - 1, 1);
          const isoWeekday = monthDate.getDay() === 0 ? 7 : monthDate.getDay();
          const weekNum = Math.ceil((monthDate.getDate() + new Date(year, month - 1, 1).getDay()) / 7);
          
          budgetEntries.push({
            versjon_id: versionId,
            salon_id: salonId,
            ansatt_id: stylist.id,
            aar: year,
            maned: month,
            uke: weekNum,
            dag: isoWeekday,
            dato: monthDate.toISOString().split('T')[0],
            planlagte_timer: 0,
            kundetimer: 0,
            behandling_budsjett: mb.behandling_budsjett || 0,
            vare_budsjett: mb.vare_budsjett || 0,
            totalt_budsjett: (mb.behandling_budsjett || 0) + (mb.vare_budsjett || 0),
            arsak_null_timer: 'manuelt' as const
          });
          manualBudgetCount++;
          completed++;
          setProgress(Math.round((completed / Math.max(totalShifts, 1)) * 100));
        }
      }

      // Filter out stylists with manual budgets from turnus-based generation
      const turnusStylists = selectedStylists.filter(s => !manualBudgetMap.has(s.id));

      // Iterate over turnus_skift shifts directly (not calendar days)
      for (const stylist of turnusStylists) {
        const employeeShifts = shiftsByEmployee.get(stylist.id) || [];
        
        // Filter by month if needed
        const filteredShifts = selectedMonth !== "all" 
          ? employeeShifts.filter(s => s.maned === parseInt(selectedMonth))
          : employeeShifts;
        
        for (const shift of filteredShifts) {
          const datoStr = shift.dato;
          
          // Skip vacation days - don't generate budget for days when employee is on vacation
          const ansattVacationDates = vacationDates.get(stylist.id);
          if (ansattVacationDates?.has(datoStr)) {
            completed++;
            setProgress(Math.round((completed / Math.max(totalShifts, 1)) * 100));
            continue;
          }
          
          const month = shift.maned;
          const planlagteTimer = shift.timer;
          
          // Check for monthly KPIs first, then fall back to employee base, then to defaults
          const monthKPIs = monthlyKPIMap.get(stylist.id)?.get(month);
          
          const params: KPIParams = {
            effektivitet: monthKPIs?.eff ?? stylist.effektivitet_prosent ?? defaultParams.effektivitet,
            omsetningPerTime: monthKPIs?.oms ?? stylist.omsetning_per_time ?? defaultParams.omsetningPerTime,
            varesalgProsent: monthKPIs?.vare ?? stylist.varesalg_prosent ?? defaultParams.varesalgProsent,
            timerPerDag: defaultParams.timerPerDag
          };
          
          // Track if monthly KPIs were used
          if (monthKPIs && (monthKPIs.eff !== null || monthKPIs.oms !== null || monthKPIs.vare !== null)) {
            monthlyKPIUsedCount++;
          }
          
          const arsak: BudsjettArsak = planlagteTimer > 0 ? 'arbeid' : 'turnus_fridag';
          if (planlagteTimer > 0) {
            turnusBasedCount++;
          }
          
          // Calculate budget from planned hours
          const kundetimer = planlagteTimer * (params.effektivitet / 100);
          const totaltBudsjett = kundetimer * params.omsetningPerTime;
          const vareBudsjett = totaltBudsjett * (params.varesalgProsent / 100);
          const behandlingBudsjett = totaltBudsjett - vareBudsjett;

          budgetEntries.push({
            versjon_id: versionId,
            salon_id: salonId,
            ansatt_id: stylist.id,
            aar: year,
            maned: shift.maned,
            uke: shift.uke,
            dag: shift.ukedag,
            dato: datoStr,
            planlagte_timer: planlagteTimer,
            kundetimer,
            behandling_budsjett: behandlingBudsjett,
            vare_budsjett: vareBudsjett,
            totalt_budsjett: totaltBudsjett,
            arsak_null_timer: planlagteTimer === 0 ? arsak : null
          });

          completed++;
          setProgress(Math.round((completed / Math.max(totalShifts, 1)) * 100));
        }
      }

      // Insert in batches of 500
      const batchSize = 500;
      for (let i = 0; i < budgetEntries.length; i += batchSize) {
        const batch = budgetEntries.slice(i, i + batchSize);
        const { error: insertError } = await supabase
          .from("budsjett")
          .insert(batch);

        if (insertError) throw insertError;
      }

      const turnusInfo = turnusBasedCount > 0 
        ? `${turnusBasedCount} dager fra turnus` 
        : '';
      const monthlyKPIInfo = monthlyKPIUsedCount > 0
        ? `${monthlyKPIUsedCount} dager med månedlige KPI`
        : '';
      const manualInfo = manualBudgetCount > 0
        ? `${manualBudgetCount} manuelt budsjett`
        : '';
      const detailParts = [manualInfo, turnusInfo, monthlyKPIInfo].filter(Boolean).join(', ');

      toast({
        title: "Budsjett generert",
        description: `${budgetEntries.length} budsjettoppføringer for ${selectedStylists.length} frisør(er)${detailParts ? ` (${detailParts})` : ''}`
      });

      onGenerated();

    } catch (error) {
      console.error("Error generating budget:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke generere budsjett",
        variant: "destructive"
      });
    } finally {
      setGenerating(false);
      setProgress(0);
    }
  };

  const monthOptions = [
    { value: "all", label: "Hele året" },
    { value: "1", label: "Januar" },
    { value: "2", label: "Februar" },
    { value: "3", label: "Mars" },
    { value: "4", label: "April" },
    { value: "5", label: "Mai" },
    { value: "6", label: "Juni" },
    { value: "7", label: "Juli" },
    { value: "8", label: "August" },
    { value: "9", label: "September" },
    { value: "10", label: "Oktober" },
    { value: "11", label: "November" },
    { value: "12", label: "Desember" },
  ];

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-48" />
        <Skeleton className="h-64" />
      </div>
    );
  }

  const selectedCount = stylists.filter(s => s.selected).length;
  const kpiStats = {
    complete: stylists.filter(s => getKpiStatus(s, defaultParams) === 'complete').length,
    partial: stylists.filter(s => getKpiStatus(s, defaultParams) === 'partial').length,
    missing: stylists.filter(s => getKpiStatus(s, defaultParams) === 'missing').length
  };

  return (
    <div className="space-y-6">
      {/* Fallback parameters */}
      <Card>
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2 text-lg">
            <Settings className="h-5 w-5" />
            Fallback-verdier
          </CardTitle>
          <CardDescription>
            Brukes for frisører uten individuelle KPI-verdier
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="space-y-1.5">
              <Label className="text-xs">Effektivitet %</Label>
              <Input
                type="number"
                min="0"
                max="100"
                value={defaultParams.effektivitet}
                onChange={(e) => setDefaultParams(prev => ({ 
                  ...prev, 
                  effektivitet: parseFloat(e.target.value) || 0 
                }))}
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Omsetning/time (kr)</Label>
              <Input
                type="number"
                min="0"
                value={defaultParams.omsetningPerTime}
                onChange={(e) => setDefaultParams(prev => ({ 
                  ...prev, 
                  omsetningPerTime: parseFloat(e.target.value) || 0 
                }))}
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Varesalg %</Label>
              <Input
                type="number"
                min="0"
                max="100"
                value={defaultParams.varesalgProsent}
                onChange={(e) => setDefaultParams(prev => ({ 
                  ...prev, 
                  varesalgProsent: parseFloat(e.target.value) || 0 
                }))}
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs">Periode</Label>
              <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {monthOptions.map(opt => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stylist table with KPI editing */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Frisører ({stylists.length})
              </CardTitle>
              <CardDescription className="flex items-center gap-4 mt-1">
                <span>{selectedCount} valgt</span>
                <span className="flex items-center gap-1">
                  <CheckCircle2 className="h-3.5 w-3.5 text-green-500" />
                  {kpiStats.complete}
                </span>
                <span className="flex items-center gap-1">
                  <CircleDot className="h-3.5 w-3.5 text-amber-500" />
                  {kpiStats.partial}
                </span>
                <span className="flex items-center gap-1">
                  <AlertCircle className="h-3.5 w-3.5 text-muted-foreground" />
                  {kpiStats.missing}
                </span>
              </CardDescription>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={selectAll}>
                Velg alle
              </Button>
              <Button variant="outline" size="sm" onClick={selectNone}>
                Velg ingen
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {stylists.length === 0 ? (
            <p className="text-center text-muted-foreground py-8">
              Ingen frisører funnet i denne salongen
            </p>
          ) : (
            <div className="border rounded-lg overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[50px]"></TableHead>
                    <TableHead>Navn</TableHead>
                    <TableHead className="hidden sm:table-cell">Rolle</TableHead>
                    <TableHead className="text-center">
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger className="flex items-center gap-1 mx-auto">
                            Stilling
                            <Info className="h-3 w-3 text-muted-foreground" />
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>Beregnet fra turnus (avtalt i parentes)</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </TableHead>
                    <TableHead className="text-center hidden lg:table-cell">Timer/uke</TableHead>
                    <TableHead className="text-center">Eff %</TableHead>
                    <TableHead className="text-center hidden md:table-cell">Oms/t</TableHead>
                    <TableHead className="text-center hidden md:table-cell">Vare %</TableHead>
                    <TableHead className="w-[60px]"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {stylists.map(stylist => {
                    const status = getKpiStatus(stylist, defaultParams);
                    const harTurnus = stylist.beregnetStillingsprosent !== null;
                    const avvik = harTurnus 
                      ? stylist.beregnetStillingsprosent! - stylist.stillingsprosent 
                      : 0;
                    const harAvvik = Math.abs(avvik) > 5;
                    
                    return (
                      <TableRow 
                        key={stylist.id}
                        className={stylist.selected ? "bg-primary/5" : ""}
                      >
                        <TableCell>
                          <Checkbox
                            checked={stylist.selected}
                            onCheckedChange={() => toggleStylist(stylist.id)}
                          />
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {status === 'complete' && (
                              <CheckCircle2 className="h-4 w-4 text-green-500 shrink-0" />
                            )}
                            {status === 'partial' && (
                              <CircleDot className="h-4 w-4 text-amber-500 shrink-0" />
                            )}
                            {status === 'missing' && (
                              <AlertCircle className="h-4 w-4 text-muted-foreground shrink-0" />
                            )}
                            <span className="font-medium">{stylist.name}</span>
                          </div>
                        </TableCell>
                        <TableCell className="hidden sm:table-cell">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <Badge variant="secondary" className="font-normal">
                              {getRolleDisplay(stylist.frisorfunksjon, stylist.lederstilling)}
                            </Badge>
                            {stylist.hasMonthlyKPIs && (
                              <TooltipProvider>
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Badge variant="outline" className="text-xs bg-blue-50 text-blue-700 border-blue-200">
                                      <CalendarDays className="h-3 w-3 mr-1" />
                                      MND
                                    </Badge>
                                  </TooltipTrigger>
                                  <TooltipContent>
                                    <p>Har månedsspesifikke KPI-verdier</p>
                                    <p className="text-xs text-muted-foreground">Disse brukes ved generering</p>
                                  </TooltipContent>
                                </Tooltip>
                              </TooltipProvider>
                            )}
                          </div>
                        </TableCell>
                        <TableCell className="text-center">
                          {harTurnus ? (
                            <TooltipProvider>
                              <Tooltip>
                                <TooltipTrigger>
                                  <span className={`font-medium ${harAvvik ? 'text-amber-600' : ''}`}>
                                    {stylist.beregnetStillingsprosent}%
                                  </span>
                                  <span className="text-muted-foreground text-xs ml-1">
                                    ({stylist.stillingsprosent}%)
                                  </span>
                                </TooltipTrigger>
                                <TooltipContent>
                                  <p>Turnus: {stylist.beregnetStillingsprosent}%</p>
                                  <p>Avtalt: {stylist.stillingsprosent}%</p>
                                  {harAvvik && (
                                    <p className="text-amber-500">Avvik: {avvik > 0 ? '+' : ''}{avvik.toFixed(1)}%</p>
                                  )}
                                </TooltipContent>
                              </Tooltip>
                            </TooltipProvider>
                          ) : (
                            <span className="text-muted-foreground">
                              {stylist.stillingsprosent}%
                              <span className="text-xs ml-1">(avtalt)</span>
                            </span>
                          )}
                        </TableCell>
                        <TableCell className="text-center hidden lg:table-cell">
                          {stylist.gjennomsnittTimer !== null ? (
                            <span className="font-mono text-sm">
                              {stylist.gjennomsnittTimer}t
                            </span>
                          ) : (
                            <span className="text-muted-foreground">–</span>
                          )}
                        </TableCell>
                        <TableCell className="text-center">
                          <span className={stylist.effektivitet_prosent === null ? "text-muted-foreground" : ""}>
                            {stylist.effektivitet_prosent ?? defaultParams.effektivitet}%
                          </span>
                        </TableCell>
                        <TableCell className="text-center hidden md:table-cell">
                          <span className={stylist.omsetning_per_time === null ? "text-muted-foreground" : ""}>
                            {stylist.omsetning_per_time ?? defaultParams.omsetningPerTime} kr
                          </span>
                        </TableCell>
                        <TableCell className="text-center hidden md:table-cell">
                          <span className={stylist.varesalg_prosent === null ? "text-muted-foreground" : ""}>
                            {stylist.varesalg_prosent ?? defaultParams.varesalgProsent}%
                          </span>
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => openEditDialog(stylist)}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Generate button */}
      <div className="flex flex-col items-center gap-4">
        {generating && (
          <div className="w-full max-w-md space-y-2">
            <Progress value={progress} />
            <p className="text-sm text-center text-muted-foreground">
              Genererer budsjett... {progress}%
            </p>
          </div>
        )}
        
        <Button
          size="lg"
          onClick={handleGenerate}
          disabled={generating || selectedCount === 0}
          className="min-w-[200px]"
        >
          {generating ? (
            <>
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              Genererer...
            </>
          ) : (
            <>
              <Calculator className="h-4 w-4 mr-2" />
              Generer budsjett for {year}
            </>
          )}
        </Button>

        {selectedCount > 0 && !generating && (
          <p className="text-sm text-muted-foreground text-center">
            {selectedCount} frisør(er) ×{" "}
            {selectedMonth === "all" ? "hele året" : monthOptions.find(m => m.value === selectedMonth)?.label}
          </p>
        )}
      </div>

      {/* KPI Edit Dialog */}
      <Dialog open={!!editingStylist} onOpenChange={(open) => !open && setEditingStylist(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Rediger KPI for {editingStylist?.name}</DialogTitle>
            <DialogDescription>
              Sett individuelle KPI-verdier for budsjettberegning
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Effektivitet (%)</Label>
              <Input
                type="number"
                min="0"
                max="100"
                value={editForm.effektivitet_prosent}
                onChange={(e) => setEditForm(prev => ({
                  ...prev,
                  effektivitet_prosent: parseFloat(e.target.value) || 0
                }))}
              />
              <p className="text-xs text-muted-foreground">
                Andel av arbeidstid som brukes på kundebehandling
              </p>
            </div>
            
            <div className="space-y-2">
              <Label>Omsetning per time (kr)</Label>
              <Input
                type="number"
                min="0"
                value={editForm.omsetning_per_time}
                onChange={(e) => setEditForm(prev => ({
                  ...prev,
                  omsetning_per_time: parseFloat(e.target.value) || 0
                }))}
              />
              <p className="text-xs text-muted-foreground">
                Forventet behandlingsinntekt per kundetime
              </p>
            </div>
            
            <div className="space-y-2">
              <Label>Varesalg (%)</Label>
              <Input
                type="number"
                min="0"
                max="100"
                value={editForm.varesalg_prosent}
                onChange={(e) => setEditForm(prev => ({
                  ...prev,
                  varesalg_prosent: parseFloat(e.target.value) || 0
                }))}
              />
              <p className="text-xs text-muted-foreground">
                Andel av omsetning fra produktsalg
              </p>
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditingStylist(null)}>
              Avbryt
            </Button>
            <Button onClick={handleSaveKPIs} disabled={saving}>
              {saving ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Lagrer...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  Lagre
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
