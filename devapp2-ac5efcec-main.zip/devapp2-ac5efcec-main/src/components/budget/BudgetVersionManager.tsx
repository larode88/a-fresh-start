import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { 
  Plus, 
  CheckCircle, 
  Copy, 
  Trash2, 
  Star,
  Calendar,
  Loader2
} from "lucide-react";
import { format } from "date-fns";
import { nb } from "date-fns/locale";

interface BudgetVersion {
  id: string;
  versjon_navn: string;
  versjon_nummer: number;
  aar: number;
  er_aktiv: boolean;
  godkjent_av: string | null;
  godkjent_dato: string | null;
  beskrivelse: string | null;
  created_at: string;
}

interface BudgetVersionManagerProps {
  salonId: string;
  year: number;
  versions: BudgetVersion[];
  activeVersion: BudgetVersion | null;
  onVersionsChange: (versions: BudgetVersion[]) => void;
}

export function BudgetVersionManager({
  salonId,
  year,
  versions,
  activeVersion,
  onVersionsChange
}: BudgetVersionManagerProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [newVersionName, setNewVersionName] = useState("");
  const [newVersionDescription, setNewVersionDescription] = useState("");
  const [newVersionYear, setNewVersionYear] = useState(year);
  const [creating, setCreating] = useState(false);
  const [activating, setActivating] = useState<string | null>(null);

  // Generate year options (5 years back, 3 years forward)
  const currentYear = new Date().getFullYear();
  const yearOptions = Array.from({ length: 9 }, (_, i) => currentYear - 5 + i);

  // Reset year to prop value when dialog opens
  useEffect(() => {
    if (createDialogOpen) {
      setNewVersionYear(year);
    }
  }, [createDialogOpen, year]);

  const handleCreateVersion = async () => {
    if (!newVersionName.trim()) {
      toast({
        title: "Feil",
        description: "Versjonsnavn er påkrevd",
        variant: "destructive"
      });
      return;
    }

    setCreating(true);
    try {
      // Get versions for the selected year to determine version number
      const { data: existingVersions } = await supabase
        .from("budsjett_versjoner")
        .select("versjon_nummer")
        .eq("salon_id", salonId)
        .eq("aar", newVersionYear);

      const nextVersionNumber = existingVersions && existingVersions.length > 0
        ? Math.max(...existingVersions.map(v => v.versjon_nummer)) + 1
        : 1;

      const isFirstForYear = !existingVersions || existingVersions.length === 0;

      const { data, error } = await supabase
        .from("budsjett_versjoner")
        .insert({
          salon_id: salonId,
          aar: newVersionYear,
          versjon_navn: newVersionName.trim(),
          versjon_nummer: nextVersionNumber,
          beskrivelse: newVersionDescription.trim() || null,
          er_aktiv: isFirstForYear, // First version for that year is active by default
          opprettet_av: user?.id
        })
        .select()
        .single();

      if (error) throw error;

      // Only add to current list if same year, otherwise just show success
      if (newVersionYear === year) {
        onVersionsChange([data, ...versions]);
      }
      setCreateDialogOpen(false);
      setNewVersionName("");
      setNewVersionDescription("");
      
      toast({
        title: "Versjon opprettet",
        description: `${newVersionName} er nå opprettet`
      });
    } catch (error) {
      console.error("Error creating version:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke opprette versjon",
        variant: "destructive"
      });
    } finally {
      setCreating(false);
    }
  };

  const handleSetActive = async (versionId: string) => {
    setActivating(versionId);
    try {
      // First, deactivate all versions for this salon/year
      await supabase
        .from("budsjett_versjoner")
        .update({ er_aktiv: false })
        .eq("salon_id", salonId)
        .eq("aar", year);

      // Then activate the selected one
      const { error } = await supabase
        .from("budsjett_versjoner")
        .update({ er_aktiv: true })
        .eq("id", versionId);

      if (error) throw error;

      const updatedVersions = versions.map(v => ({
        ...v,
        er_aktiv: v.id === versionId
      }));
      onVersionsChange(updatedVersions);

      toast({
        title: "Versjon aktivert",
        description: "Budsjettversjonen er nå aktiv"
      });
    } catch (error) {
      console.error("Error activating version:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke aktivere versjon",
        variant: "destructive"
      });
    } finally {
      setActivating(null);
    }
  };

  const handleDeleteVersion = async (versionId: string) => {
    try {
      // First delete all budget entries for this version
      await supabase
        .from("budsjett")
        .delete()
        .eq("versjon_id", versionId);

      // Delete fastsatt entries
      await supabase
        .from("budsjett_fastsatt")
        .delete()
        .eq("versjon_id", versionId);

      // Then delete the version
      const { error } = await supabase
        .from("budsjett_versjoner")
        .delete()
        .eq("id", versionId);

      if (error) throw error;

      const updatedVersions = versions.filter(v => v.id !== versionId);
      onVersionsChange(updatedVersions);

      toast({
        title: "Versjon slettet",
        description: "Budsjettversjonen og alle tilhørende data er slettet"
      });
    } catch (error) {
      console.error("Error deleting version:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke slette versjon",
        variant: "destructive"
      });
    }
  };

  const handleDuplicateVersion = async (version: BudgetVersion) => {
    setCreating(true);
    try {
      const nextVersionNumber = Math.max(...versions.map(v => v.versjon_nummer)) + 1;
      const newName = `${version.versjon_navn} (kopi)`;

      // Create new version
      const { data: newVersion, error: versionError } = await supabase
        .from("budsjett_versjoner")
        .insert({
          salon_id: salonId,
          aar: year,
          versjon_navn: newName,
          versjon_nummer: nextVersionNumber,
          beskrivelse: version.beskrivelse,
          er_aktiv: false,
          opprettet_av: user?.id
        })
        .select()
        .single();

      if (versionError) throw versionError;

      // Copy budget entries
      const { data: budgetEntries } = await supabase
        .from("budsjett")
        .select("*")
        .eq("versjon_id", version.id);

      if (budgetEntries && budgetEntries.length > 0) {
        const newEntries = budgetEntries.map(entry => ({
          ...entry,
          id: undefined,
          versjon_id: newVersion.id,
          created_at: undefined,
          updated_at: undefined
        }));

        await supabase.from("budsjett").insert(newEntries);
      }

      // Copy fastsatt entries
      const { data: fastsattEntries } = await supabase
        .from("budsjett_fastsatt")
        .select("*")
        .eq("versjon_id", version.id);

      if (fastsattEntries && fastsattEntries.length > 0) {
        const newFastsatt = fastsattEntries.map(entry => ({
          ...entry,
          id: undefined,
          versjon_id: newVersion.id,
          godkjent_av: null,
          godkjent_dato: null,
          created_at: undefined,
          updated_at: undefined
        }));

        await supabase.from("budsjett_fastsatt").insert(newFastsatt);
      }

      onVersionsChange([newVersion, ...versions]);

      toast({
        title: "Versjon duplisert",
        description: `${newName} er opprettet med alle budsjettdata`
      });
    } catch (error) {
      console.error("Error duplicating version:", error);
      toast({
        title: "Feil",
        description: "Kunne ikke duplisere versjon",
        variant: "destructive"
      });
    } finally {
      setCreating(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Budsjettversjoner for {year}</h3>
          <p className="text-sm text-muted-foreground">
            Administrer ulike budsjettversjoner og scenarioer
          </p>
        </div>
        
        <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Ny versjon
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Opprett ny budsjettversjon</DialogTitle>
              <DialogDescription>
                Velg år og opprett en ny budsjettversjon
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="version-year" className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-primary" />
                  Budsjettår
                </Label>
                <Select
                  value={newVersionYear.toString()}
                  onValueChange={(value) => setNewVersionYear(parseInt(value))}
                >
                  <SelectTrigger id="version-year" className="w-full">
                    <SelectValue placeholder="Velg år" />
                  </SelectTrigger>
                  <SelectContent>
                    {yearOptions.map((y) => (
                      <SelectItem key={y} value={y.toString()}>
                        {y} {y === currentYear && "(inneværende)"}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground">
                  Versjonen opprettes for dette året
                </p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="version-name">Versjonsnavn</Label>
                <Input
                  id="version-name"
                  placeholder={`f.eks. Hovedbudsjett ${newVersionYear}`}
                  value={newVersionName}
                  onChange={(e) => setNewVersionName(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="version-description">Beskrivelse (valgfritt)</Label>
                <Textarea
                  id="version-description"
                  placeholder="Beskriv denne budsjettversjonen..."
                  value={newVersionDescription}
                  onChange={(e) => setNewVersionDescription(e.target.value)}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setCreateDialogOpen(false)}>
                Avbryt
              </Button>
              <Button onClick={handleCreateVersion} disabled={creating}>
                {creating && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                Opprett
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {versions.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-muted-foreground mb-4">
              Ingen budsjettversjoner for {year} ennå.
            </p>
            <Button onClick={() => setCreateDialogOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Opprett første versjon
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {versions.map((version) => (
            <Card 
              key={version.id}
              className={version.er_aktiv ? "border-primary/50 bg-primary/5" : ""}
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <CardTitle className="text-lg">{version.versjon_navn}</CardTitle>
                      <Badge variant="outline">v{version.versjon_nummer}</Badge>
                      {version.er_aktiv && (
                        <Badge className="bg-green-600">
                          <Star className="h-3 w-3 mr-1" />
                          Aktiv
                        </Badge>
                      )}
                      {version.godkjent_dato && (
                        <Badge variant="secondary">
                          <CheckCircle className="h-3 w-3 mr-1" />
                          Godkjent
                        </Badge>
                      )}
                    </div>
                    {version.beskrivelse && (
                      <CardDescription>{version.beskrivelse}</CardDescription>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-2">
                    {!version.er_aktiv && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleSetActive(version.id)}
                        disabled={activating === version.id}
                      >
                        {activating === version.id ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <>
                            <Star className="h-4 w-4 mr-1" />
                            Aktiver
                          </>
                        )}
                      </Button>
                    )}
                    
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDuplicateVersion(version)}
                      disabled={creating}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>

                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="outline" size="sm" className="text-destructive">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Slett budsjettversjon?</AlertDialogTitle>
                          <AlertDialogDescription>
                            Dette vil slette "{version.versjon_navn}" og alle tilhørende budsjettdata. 
                            Denne handlingen kan ikke angres.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Avbryt</AlertDialogCancel>
                          <AlertDialogAction
                            onClick={() => handleDeleteVersion(version.id)}
                            className="bg-destructive text-destructive-foreground"
                          >
                            Slett
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Calendar className="h-4 w-4" />
                    Opprettet {format(new Date(version.created_at), "d. MMM yyyy", { locale: nb })}
                  </span>
                  {version.godkjent_dato && (
                    <span className="flex items-center gap-1">
                      <CheckCircle className="h-4 w-4" />
                      Godkjent {format(new Date(version.godkjent_dato), "d. MMM yyyy", { locale: nb })}
                    </span>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
