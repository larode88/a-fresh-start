import React, { useState, useEffect } from 'react';
import { Eye, EyeOff } from 'lucide-react';
import { cn } from '@/lib/utils';

interface SensitiveFieldProps {
  value: string | number | null | undefined;
  label?: string;
  className?: string;
  autoHideDelay?: number; // ms before auto-hiding again
  placeholder?: string;
}

export const SensitiveField: React.FC<SensitiveFieldProps> = ({
  value,
  label,
  className,
  autoHideDelay = 5000,
  placeholder = '••••••••',
}) => {
  const [isRevealed, setIsRevealed] = useState(false);

  useEffect(() => {
    if (isRevealed && autoHideDelay > 0) {
      const timer = setTimeout(() => setIsRevealed(false), autoHideDelay);
      return () => clearTimeout(timer);
    }
  }, [isRevealed, autoHideDelay]);

  if (value === null || value === undefined || value === '') {
    return <span className="text-muted-foreground">-</span>;
  }

  const displayValue = String(value);

  return (
    <div className={cn('inline-flex items-center gap-2', className)}>
      {label && <span className="text-muted-foreground text-sm">{label}:</span>}
      <button
        type="button"
        onClick={() => setIsRevealed(!isRevealed)}
        className="inline-flex items-center gap-1.5 group cursor-pointer hover:opacity-80 transition-opacity"
      >
        <span
          className={cn(
            'font-mono transition-all duration-200',
            !isRevealed && 'blur-sm select-none'
          )}
        >
          {isRevealed ? displayValue : placeholder}
        </span>
        {isRevealed ? (
          <EyeOff className="h-3.5 w-3.5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
        ) : (
          <Eye className="h-3.5 w-3.5 text-muted-foreground" />
        )}
      </button>
    </div>
  );
};
