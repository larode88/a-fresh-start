import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

export const useUnreadMessages = () => {
  const { user } = useAuth();
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUnreadCount = async () => {
      if (!user) {
        setUnreadCount(0);
        setLoading(false);
        return;
      }

      try {
        // Get threads where user is a participant using raw query
        const { data: participations, error } = await supabase
          .from("thread_participants")
          .select("thread_id, last_read_at")
          .eq("user_id", user.id);

        if (error || !participations || participations.length === 0) {
          setUnreadCount(0);
          setLoading(false);
          return;
        }

        // Count threads with unread messages
        let unread = 0;
        for (const participation of participations) {
          const query = supabase
            .from("messages")
            .select("*", { count: "exact", head: true })
            .eq("thread_id", participation.thread_id)
            .neq("sender_user_id", user.id);

          if (participation.last_read_at) {
            query.gt("created_at", participation.last_read_at);
          }

          const { count } = await query;

          if (count && count > 0) {
            unread++;
          }
        }

        setUnreadCount(unread);
      } catch (error) {
        console.error("Error fetching unread count:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchUnreadCount();

    // Subscribe to new messages
    const channel = supabase
      .channel("unread-messages")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "messages",
        },
        () => {
          fetchUnreadCount();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  return { unreadCount, loading };
};
