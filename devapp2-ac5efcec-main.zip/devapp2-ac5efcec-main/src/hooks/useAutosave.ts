import { useState, useEffect, useRef, useCallback } from "react";

export type AutosaveStatus = "idle" | "saving" | "saved" | "error";

interface UseAutosaveOptions<T> {
  data: T;
  onSave: (data: T) => Promise<void>;
  interval?: number;
  enabled?: boolean;
}

export function useAutosave<T>({
  data,
  onSave,
  interval = 30000, // 30 seconds
  enabled = true,
}: UseAutosaveOptions<T>) {
  const [status, setStatus] = useState<AutosaveStatus>("idle");
  const [lastSavedAt, setLastSavedAt] = useState<Date | null>(null);
  const dataRef = useRef(data);
  const lastSavedDataRef = useRef<string>("");
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Update ref when data changes
  useEffect(() => {
    dataRef.current = data;
  }, [data]);

  const save = useCallback(async () => {
    const currentDataString = JSON.stringify(dataRef.current);
    
    // Don't save if data hasn't changed
    if (currentDataString === lastSavedDataRef.current) {
      return;
    }

    setStatus("saving");
    
    try {
      await onSave(dataRef.current);
      lastSavedDataRef.current = currentDataString;
      setLastSavedAt(new Date());
      setStatus("saved");
      
      // Reset to idle after 3 seconds
      setTimeout(() => {
        setStatus((current) => current === "saved" ? "idle" : current);
      }, 3000);
    } catch (error) {
      console.error("Autosave failed:", error);
      setStatus("error");
    }
  }, [onSave]);

  // Debounced autosave
  useEffect(() => {
    if (!enabled) return;

    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }

    timeoutRef.current = setTimeout(() => {
      save();
    }, interval);

    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
    };
  }, [data, interval, enabled, save]);

  // Save to localStorage as backup
  useEffect(() => {
    if (!enabled) return;
    
    const backupKey = "email-editor-backup";
    try {
      localStorage.setItem(backupKey, JSON.stringify({
        data,
        timestamp: Date.now(),
      }));
    } catch (error) {
      console.warn("Failed to save backup to localStorage:", error);
    }
  }, [data, enabled]);

  // Force save function
  const forceSave = useCallback(async () => {
    await save();
  }, [save]);

  return {
    status,
    lastSavedAt,
    forceSave,
  };
}
