// User Role Hook
// Provides role-based access control for the application

import { useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export type AppRole = 
  | 'admin'
  | 'district_manager'
  | 'salon_owner'
  | 'daglig_leder'
  | 'avdelingsleder'
  | 'styreleder'
  | 'seniorfrisor'
  | 'stylist'
  | 'apprentice'
  | 'supplier_admin'
  | 'supplier_sales'
  | 'supplier_business_dev';

export interface UserRoleResult {
  role: AppRole | null;
  isLoading: boolean;
  isAdmin: boolean;
  isDistrictManager: boolean;
  isSalonOwner: boolean;
  isDagligLeder: boolean;
  isAvdelingsleder: boolean;
  isManager: boolean; // Any manager role
  isHR: boolean; // Can access HR/salary data
  isStylist: boolean;
  isApprentice: boolean;
  isSupplier: boolean;
  canManageEmployees: boolean;
  canViewSalary: boolean;
  canEditBudget: boolean;
  canApproveLeave: boolean;
  canAccessInsurance: boolean;
}

export const useUserRole = (): UserRoleResult => {
  const { data: session } = useQuery({
    queryKey: ['session'],
    queryFn: async () => {
      const { data } = await supabase.auth.getSession();
      return data.session;
    },
    staleTime: 1000 * 60 * 5, // 5 minutes
  });

  const { data: userRole, isLoading } = useQuery({
    queryKey: ['user-role', session?.user?.id],
    queryFn: async () => {
      if (!session?.user?.id) return null;
      
      const { data, error } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', session.user.id)
        .single();
      
      if (error) {
        console.error('Error fetching user role:', error);
        return null;
      }
      
      return data?.role as AppRole | null;
    },
    enabled: !!session?.user?.id,
    staleTime: 1000 * 60 * 5,
  });

  return useMemo(() => {
    const role = userRole || null;
    
    // Role checks
    const isAdmin = role === 'admin';
    const isDistrictManager = role === 'district_manager';
    const isSalonOwner = role === 'salon_owner';
    const isDagligLeder = role === 'daglig_leder';
    const isAvdelingsleder = role === 'avdelingsleder';
    const isStylist = role === 'stylist' || role === 'seniorfrisor';
    const isApprentice = role === 'apprentice';
    const isSupplier = role?.startsWith('supplier_') || false;
    
    // Combined checks
    const isManager = isAdmin || isDistrictManager || isSalonOwner || isDagligLeder || isAvdelingsleder;
    const isHR = isAdmin || isSalonOwner || isDagligLeder;
    
    // Permission checks
    const canManageEmployees = isManager;
    const canViewSalary = isHR;
    const canEditBudget = isAdmin || isSalonOwner || isDagligLeder;
    const canApproveLeave = isManager;
    const canAccessInsurance = isAdmin || isDistrictManager || isSalonOwner || isDagligLeder;
    
    return {
      role,
      isLoading,
      isAdmin,
      isDistrictManager,
      isSalonOwner,
      isDagligLeder,
      isAvdelingsleder,
      isManager,
      isHR,
      isStylist,
      isApprentice,
      isSupplier,
      canManageEmployees,
      canViewSalary,
      canEditBudget,
      canApproveLeave,
      canAccessInsurance,
    };
  }, [userRole, isLoading]);
};

/**
 * Hook to check if user has a specific role
 */
export const useHasRole = (requiredRole: AppRole): boolean => {
  const { role } = useUserRole();
  return role === requiredRole;
};

/**
 * Hook to check if user has any of the specified roles
 */
export const useHasAnyRole = (requiredRoles: AppRole[]): boolean => {
  const { role } = useUserRole();
  return role !== null && requiredRoles.includes(role);
};
