import { useState, useRef, useCallback } from "react";

interface SwipeState {
  offsetX: number;
  isSwiping: boolean;
}

interface UseSwipeOptions {
  onSwipeLeft?: () => void;
  onSwipeRight?: () => void;
  threshold?: number;
  maxSwipe?: number;
}

export function useSwipe({
  onSwipeLeft,
  onSwipeRight,
  threshold = 80,
  maxSwipe = 120,
}: UseSwipeOptions = {}) {
  const [state, setState] = useState<SwipeState>({
    offsetX: 0,
    isSwiping: false,
  });
  
  const startX = useRef<number>(0);
  const startY = useRef<number>(0);
  const isHorizontalSwipe = useRef<boolean | null>(null);

  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    startX.current = e.touches[0].clientX;
    startY.current = e.touches[0].clientY;
    isHorizontalSwipe.current = null;
    setState((prev) => ({ ...prev, isSwiping: true }));
  }, []);

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (!state.isSwiping) return;

    const currentX = e.touches[0].clientX;
    const currentY = e.touches[0].clientY;
    const diffX = currentX - startX.current;
    const diffY = currentY - startY.current;

    // Determine swipe direction on first significant movement
    if (isHorizontalSwipe.current === null) {
      if (Math.abs(diffX) > 10 || Math.abs(diffY) > 10) {
        isHorizontalSwipe.current = Math.abs(diffX) > Math.abs(diffY);
      }
    }

    // Only handle horizontal swipes
    if (isHorizontalSwipe.current) {
      e.preventDefault();
      // Only allow left swipe (negative offset)
      const newOffset = Math.min(0, Math.max(-maxSwipe, diffX));
      setState((prev) => ({ ...prev, offsetX: newOffset }));
    }
  }, [state.isSwiping, maxSwipe]);

  const handleTouchEnd = useCallback(() => {
    if (Math.abs(state.offsetX) >= threshold) {
      if (state.offsetX < 0 && onSwipeLeft) {
        onSwipeLeft();
      } else if (state.offsetX > 0 && onSwipeRight) {
        onSwipeRight();
      }
    }
    
    setState({ offsetX: 0, isSwiping: false });
    isHorizontalSwipe.current = null;
  }, [state.offsetX, threshold, onSwipeLeft, onSwipeRight]);

  const reset = useCallback(() => {
    setState({ offsetX: 0, isSwiping: false });
  }, []);

  return {
    offsetX: state.offsetX,
    isSwiping: state.isSwiping,
    handlers: {
      onTouchStart: handleTouchStart,
      onTouchMove: handleTouchMove,
      onTouchEnd: handleTouchEnd,
    },
    reset,
  };
}
