// Current Ansatt Hook
// Provides the currently logged-in user's employee record

import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

export interface CurrentAnsatt {
  id: string;
  fornavn: string;
  etternavn: string | null;
  navn: string;
  salong_id: string | null;
  salong_navn: string | null;
  user_id: string | null;
  status: string;
  frisorfunksjon: string | null;
  lederstilling: string | null;
  rolle_display: string;
  stillingsprosent: number;
  epost: string | null;
  telefon: string | null;
  profilbilde_url: string | null;
  ansatt_dato: string | null;
  ansiennitet_aar: number | null;
  fodselsdato: string | null;
  alder: number | null;
  feriekrav_timer_per_aar: number | null;
}

export interface UseCurrentAnsattResult {
  ansatt: CurrentAnsatt | null;
  isLoading: boolean;
  isError: boolean;
  error: Error | null;
  refetch: () => void;
}

export const useCurrentAnsatt = (): UseCurrentAnsattResult => {
  const { data: session } = useQuery({
    queryKey: ['session'],
    queryFn: async () => {
      const { data } = await supabase.auth.getSession();
      return data.session;
    },
    staleTime: 1000 * 60 * 5,
  });

  const {
    data: ansatt,
    isLoading,
    isError,
    error,
    refetch,
  } = useQuery({
    queryKey: ['current-ansatt', session?.user?.id],
    queryFn: async () => {
      if (!session?.user?.id) return null;
      
      // First try to get from ansatte_utvidet view
      const { data, error } = await supabase
        .from('ansatte_utvidet')
        .select('*')
        .eq('user_id', session.user.id)
        .single();
      
      if (error) {
        // If not found in ansatte, return null (user might not be an employee)
        if (error.code === 'PGRST116') {
          return null;
        }
        throw error;
      }
      
      return data as CurrentAnsatt;
    },
    enabled: !!session?.user?.id,
    staleTime: 1000 * 60 * 5,
  });

  return {
    ansatt: ansatt || null,
    isLoading,
    isError,
    error: error as Error | null,
    refetch,
  };
};

/**
 * Hook to get the current user's salong_id
 */
export const useCurrentSalongId = (): string | null => {
  const { ansatt } = useCurrentAnsatt();
  return ansatt?.salong_id || null;
};

/**
 * Hook to check if current user is an employee
 */
export const useIsEmployee = (): boolean => {
  const { ansatt, isLoading } = useCurrentAnsatt();
  return !isLoading && ansatt !== null;
};

/**
 * Hook to check if current user has a frisør role (included in budget)
 */
export const useIsFrisor = (): boolean => {
  const { ansatt } = useCurrentAnsatt();
  return ansatt?.frisorfunksjon !== null;
};

/**
 * Hook to check if current user has a manager role
 */
export const useIsLeder = (): boolean => {
  const { ansatt } = useCurrentAnsatt();
  return ansatt?.lederstilling !== null;
};
