# Entity-Relationship Diagram

This document contains the ER diagram for the HR and Min Salong integration using Mermaid syntax.

## HR and Min Salong Database Schema

```mermaid
erDiagram
    users ||--o{ ansatt_mal : "has goals"
    users ||--o{ ansatt_samtaler : "has conversations"
    users ||--o{ ansatt_kurs : "attends courses"
    users ||--o{ lonn_historikk : "has salary history"
    users ||--o{ ferie : "requests vacation"
    users ||--o{ fravaer : "has absences"
    users ||--o{ turnus_skift : "works shifts"
    users ||--o{ budsjett : "has budgets"
    
    salons ||--o{ users : "employs"
    salons ||--o{ ansatt_mal : "has goals"
    salons ||--o{ ansatt_samtaler : "conducts"
    salons ||--o{ ferie : "approves"
    salons ||--o{ fravaer : "tracks"
    salons ||--o{ turnus_skift : "schedules"
    salons ||--o{ budsjett : "budgets"
    salons ||--o{ budsjett_versjoner : "versions"
    
    budsjett_versjoner ||--o{ budsjett : "contains"
    budsjett_versjoner ||--o{ ansatt_mal : "linked to goals"
    
    tariff_maler ||--o{ lonn_historikk : "defines rates"
    
    users {
        uuid id PK
        text name
        text email
        text role
        uuid salon_id FK
        boolean aktiv
        date ansettelsesdato
        numeric stillingsprosent
        numeric timesats
        boolean fagbrev
        text frisorfunksjon
    }
    
    salons {
        uuid id PK
        text name
        text org_number
        text address
        text city
        int employee_count
    }
    
    ansatt_mal {
        uuid id PK
        uuid user_id FK
        uuid salon_id FK
        text mal_type
        text mal_beskrivelse
        numeric mal_verdi
        text enhet
        date periode_start
        date periode_slutt
        text status
        numeric oppnaadd_verdi
        uuid budsjett_id FK
        uuid opprettet_av FK
    }
    
    ansatt_samtaler {
        uuid id PK
        uuid user_id FK
        uuid salon_id FK
        text samtale_type
        date dato
        int varighet_minutter
        uuid samtale_leder FK
        text notater
        text handlingsplan
        date oppfolging_dato
        text status
        text[] dokumenter_url
    }
    
    ansatt_kurs {
        uuid id PK
        uuid user_id FK
        text kurs_navn
        text kurs_type
        text leverandor
        date startdato
        date sluttdato
        numeric varighet_timer
        numeric kostnad
        uuid godkjent_av FK
        text status
        text resultat
        text sertifikat_url
    }
    
    lonn_historikk {
        uuid id PK
        uuid user_id FK
        date gyldig_fra
        date gyldig_til
        numeric timesats
        numeric fastlonn
        numeric stillingsprosent
        uuid tariff_id FK
        text begrunnelse
        uuid godkjent_av FK
    }
    
    ferie {
        uuid id PK
        uuid user_id FK
        uuid salon_id FK
        int aar
        date startdato
        date sluttdato
        int antall_dager
        text status
        numeric timer
        uuid godkjent_av FK
        text kommentar
    }
    
    fravaer {
        uuid id PK
        uuid user_id FK
        uuid salon_id FK
        text fravaerstype
        date startdato
        date sluttdato
        numeric prosent
        numeric timer
        text status
        text kommentar
        text dokumentasjon_url
        uuid registrert_av FK
    }
    
    turnus_skift {
        uuid id PK
        uuid user_id FK
        uuid salon_id FK
        date dato
        time start_tid
        time slutt_tid
        numeric timer_planlagt
        text kilde
        text notat
    }
    
    budsjett {
        uuid id PK
        uuid versjon_id FK
        uuid user_id FK
        uuid salon_id FK
        date dato
        int aar
        int maned
        int uke
        int dag
        numeric planlagte_timer
        numeric kundetimer
        numeric behandling_budsjett
        numeric vare_budsjett
        numeric totalt_budsjett
    }
    
    budsjett_versjoner {
        uuid id PK
        uuid salon_id FK
        int aar
        text versjon_navn
        int versjon_nummer
        boolean er_aktiv
        text beskrivelse
        uuid godkjent_av FK
        date godkjent_dato
    }
    
    tariff_maler {
        uuid id PK
        int aar
        text navn
        numeric timesats
        numeric maanedslonn
        int ansiennitet_min
        int ansiennitet_max
        text fagbrev_status
        date gyldig_fra
        date gyldig_til
    }
```

## Key Relationships

### Employee Central
- **users** is the central table for all employee-related data
- Links to HR functions: goals, conversations, courses, salary
- Links to operational data: vacation, absence, shifts, budgets

### Salon Structure
- **salons** organizes employees and all salon-specific data
- Manages versions of budgets through **budsjett_versjoner**
- Tracks all employee activities within the salon

### Budget Integration
- **budsjett_versjoner** provides versioning for budgets
- **budsjett** contains daily budget items per employee
- **ansatt_mal** can be linked to budget versions for goal alignment

### HR Workflow
- **ansatt_samtaler** tracks development conversations
- **ansatt_kurs** manages training and development
- **lonn_historikk** provides audit trail for salary changes
- **tariff_maler** standardizes salary structures

## Table Categories

### Core Tables (Existing)
- `users` - Employee master data
- `salons` - Salon master data
- `budsjett` - Budget line items
- `budsjett_versjoner` - Budget versions
- `ferie` - Vacation requests
- `fravaer` - Absence tracking
- `turnus_skift` - Shift schedules
- `tariff_maler` - Salary tariff templates

### New HR Tables
- `ansatt_mal` - Employee goals and targets
- `ansatt_samtaler` - Employee conversations
- `ansatt_kurs` - Training and courses
- `lonn_historikk` - Salary history

## Indexes

Performance indexes are created on:
- Foreign keys (user_id, salon_id, versjon_id, etc.)
- Status fields for filtering
- Date fields for range queries
- Frequently queried columns

## RPC Functions

The following database functions provide business logic:

1. **get_vacation_days_remaining** - Calculate remaining vacation days
2. **get_budget_summary** - Aggregate budget statistics
3. **get_shift_hours_summary** - Shift working hours analysis
4. **get_goal_progress** - Goal completion tracking
5. **get_current_salary** - Current salary information
6. **get_employee_count_by_salon** - Employee statistics
7. **get_absence_summary** - Absence breakdown by type
8. **get_budget_vs_actual** - Budget vs actual comparison

## Security

All tables have:
- Row Level Security (RLS) enabled
- Policies for SELECT, INSERT, UPDATE, DELETE
- Role-based access control
- Audit timestamps (created_at, updated_at)
