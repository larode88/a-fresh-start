# Migration and Seed Data - How to Run

This document provides step-by-step instructions for running the database migrations and seed data for the HR and Min Salong integration.

## Prerequisites

Before running migrations, ensure you have:

1. **Supabase Project**: An active Supabase project
2. **Database Access**: Either:
   - Supabase Dashboard access (easiest)
   - Direct PostgreSQL connection string
   - Supabase CLI installed

3. **Environment Variables**: Set up in your `.env` file:
```bash
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=your-anon-key
```

## Migration Files

The migrations are located in `supabase/migrations/` and must be run in order:

1. `20251208001500_001_create_hr_and_min_salong_tables.sql` - Creates tables and schema
2. `20251208001501_002_seed_hr_and_min_salong_data.sql` - Populates demo data
3. `20251208001502_003_supabase_rpcs_hr_and_budget_reports.sql` - Creates RPC functions

## Method 1: Supabase Dashboard (Recommended)

### Steps:

1. **Navigate to SQL Editor**
   - Log in to [Supabase Dashboard](https://app.supabase.com)
   - Select your project
   - Go to **SQL Editor** in the left sidebar

2. **Run Migration 001 - Create Tables**
   - Click **New Query**
   - Copy contents of `20251208001500_001_create_hr_and_min_salong_tables.sql`
   - Paste into the SQL editor
   - Click **Run** or press `Ctrl/Cmd + Enter`
   - Verify success (should see "Success. No rows returned")

3. **Run Migration 002 - Seed Data**
   - Click **New Query**
   - Copy contents of `20251208001501_002_seed_hr_and_min_salong_data.sql`
   - Paste into the SQL editor
   - Click **Run**
   - Verify success

4. **Run Migration 003 - RPC Functions**
   - Click **New Query**
   - Copy contents of `20251208001502_003_supabase_rpcs_hr_and_budget_reports.sql`
   - Paste into the SQL editor
   - Click **Run**
   - Verify success

### Verification:

After running migrations, verify in the **Table Editor**:
- Check that new tables exist: `ansatt_mal`, `ansatt_samtaler`, `ansatt_kurs`, `lonn_historikk`
- Verify seed data by viewing rows in tables
- Check **Database** > **Functions** for new RPC functions

## Method 2: Using psql (PostgreSQL CLI)

### Prerequisites:
```bash
# Install PostgreSQL client if not already installed
# macOS
brew install postgresql

# Ubuntu/Debian
sudo apt-get install postgresql-client

# Windows
# Download from https://www.postgresql.org/download/windows/
```

### Steps:

1. **Get Connection String**
   - In Supabase Dashboard, go to **Project Settings** > **Database**
   - Copy the **Connection String** (URI format)
   - Replace `[YOUR-PASSWORD]` with your database password

2. **Run Migrations**
```bash
# Navigate to project root
cd /path/to/devapp2

# Run migrations in order
psql "your-connection-string" -f supabase/migrations/20251208001500_001_create_hr_and_min_salong_tables.sql

psql "your-connection-string" -f supabase/migrations/20251208001501_002_seed_hr_and_min_salong_data.sql

psql "your-connection-string" -f supabase/migrations/20251208001502_003_supabase_rpcs_hr_and_budget_reports.sql
```

### Verification:
```sql
-- Connect to database
psql "your-connection-string"

-- List new tables
\dt ansatt_*
\dt lonn_*

-- Check row counts
SELECT COUNT(*) FROM ansatt_mal;
SELECT COUNT(*) FROM ansatt_samtaler;
SELECT COUNT(*) FROM ansatt_kurs;
SELECT COUNT(*) FROM lonn_historikk;

-- List RPC functions
\df get_*

-- Exit
\q
```

## Method 3: Supabase CLI

### Prerequisites:
```bash
# Install Supabase CLI
npm install -g supabase

# Or using Homebrew (macOS)
brew install supabase/tap/supabase
```

### Steps:

1. **Initialize Supabase (if not already done)**
```bash
cd /path/to/devapp2
supabase init
```

2. **Link to Your Project**
```bash
supabase link --project-ref your-project-ref
```

3. **Run Migrations**
```bash
# The migrations in supabase/migrations/ will be applied automatically
supabase db push
```

### Verification:
```bash
# Check migration status
supabase db status

# Run a query to verify
supabase db query "SELECT COUNT(*) FROM ansatt_mal"
```

## Validating the Installation

### Sample Queries to Test

Run these queries in the SQL Editor to validate the installation:

```sql
-- 1. Check demo salon exists
SELECT * FROM salons WHERE id = '550e8400-e29b-41d4-a716-446655440000';

-- 2. Check demo employees
SELECT name, email, role FROM users 
WHERE salon_id = '550e8400-e29b-41d4-a716-446655440000';

-- 3. Check employee goals
SELECT 
  u.name,
  am.mal_type,
  am.mal_beskrivelse,
  am.mal_verdi,
  am.status
FROM ansatt_mal am
JOIN users u ON am.user_id = u.id;

-- 4. Test RPC function - vacation days
SELECT * FROM get_vacation_days_remaining(
  '550e8400-e29b-41d4-a716-446655440001'::uuid,
  2025
);

-- 5. Test RPC function - budget summary
SELECT * FROM get_budget_summary(
  '550e8400-e29b-41d4-a716-446655440000'::uuid,
  '550e8400-e29b-41d4-a716-446655440010'::uuid,
  NULL,
  NULL
);

-- 6. Check salary history
SELECT 
  u.name,
  lh.timesats,
  lh.stillingsprosent,
  lh.gyldig_fra,
  lh.gyldig_til
FROM lonn_historikk lh
JOIN users u ON lh.user_id = u.id
ORDER BY u.name, lh.gyldig_fra DESC;

-- 7. Check shift schedules
SELECT 
  u.name,
  ts.dato,
  ts.start_tid,
  ts.slutt_tid,
  ts.timer_planlagt
FROM turnus_skift ts
JOIN users u ON ts.user_id = u.id
ORDER BY ts.dato, u.name;
```

## Troubleshooting

### Common Issues:

**Issue: "relation already exists"**
```sql
-- Drop tables if you need to re-run
DROP TABLE IF EXISTS ansatt_mal CASCADE;
DROP TABLE IF EXISTS ansatt_samtaler CASCADE;
DROP TABLE IF EXISTS ansatt_kurs CASCADE;
DROP TABLE IF EXISTS lonn_historikk CASCADE;
```

**Issue: "foreign key constraint violation"**
- Make sure migrations run in order
- Check that referenced tables exist (users, salons, budsjett_versjoner)

**Issue: "permission denied"**
- Ensure you're using a database user with sufficient privileges
- Check RLS policies are correctly set up

**Issue: Demo data conflicts**
- If IDs conflict with existing data, update the UUIDs in migration 002

### Checking RLS Policies:

```sql
-- View all policies for a table
SELECT * FROM pg_policies WHERE tablename = 'ansatt_mal';

-- Test if you can query as a user
SET LOCAL role TO authenticated;
SELECT * FROM ansatt_mal;
RESET role;
```

## Rolling Back

If you need to rollback the migrations:

```sql
-- Drop RPC functions
DROP FUNCTION IF EXISTS get_vacation_days_remaining CASCADE;
DROP FUNCTION IF EXISTS get_budget_summary CASCADE;
DROP FUNCTION IF EXISTS get_shift_hours_summary CASCADE;
DROP FUNCTION IF EXISTS get_goal_progress CASCADE;
DROP FUNCTION IF EXISTS get_current_salary CASCADE;
DROP FUNCTION IF EXISTS get_employee_count_by_salon CASCADE;
DROP FUNCTION IF EXISTS get_absence_summary CASCADE;
DROP FUNCTION IF EXISTS get_budget_vs_actual CASCADE;

-- Drop tables
DROP TABLE IF EXISTS lonn_historikk CASCADE;
DROP TABLE IF EXISTS ansatt_kurs CASCADE;
DROP TABLE IF EXISTS ansatt_samtaler CASCADE;
DROP TABLE IF EXISTS ansatt_mal CASCADE;

-- Note: This won't remove data from existing tables (users, salons, etc.)
```

## Next Steps

After successfully running migrations:

1. **Update TypeScript Types**
   - Run Supabase type generation (if using Supabase CLI):
   ```bash
   supabase gen types typescript --local > src/integrations/supabase/types.ts
   ```

2. **Test the Application**
   ```bash
   npm install
   npm run dev
   ```

3. **Navigate to HR Pages**
   - Visit `/hr/employees` to see employee list
   - Visit `/min-salong/budsjett` to see budget overview

4. **Test Service Functions**
   - Open browser console
   - Test service calls from components
   - Verify data loads correctly

## Support

For issues or questions:
- Check Supabase documentation: https://supabase.com/docs
- Review migration files for comments
- Check application logs in browser console
- Verify RLS policies allow your user access
